﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;
using System.Drawing;

public partial class Guest_ProjectInfo : System.Web.UI.Page
{
    string strConn = ConfigurationManager.ConnectionStrings["TCMSConn"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
           // Session["PrjID"] = "2628";
            getProjectInfo(Session["PrjID"].ToString());

            GetBiddersInfo(Session["PrjID"].ToString());

            GetStage1(Session["PrjID"].ToString());

            GetStage2(Session["PrjID"].ToString());

            GetStage3(Session["PrjID"].ToString());

            GetStage4(Session["PrjID"].ToString());

            //getChart_ProjectStatusWise();

            //getChart_ProjectTypeWise();

            //getChart_DepartmentWise();

            //getChart_ProjectTypeWise();

            //getChart_TenderTypeWise();

            //getChart_TenderStatusWise();

            //getChart_CommeetteeWise();

        }
    }

    private void getProjectInfo(string prjID)
    {
        string sqlQuery = string.Empty;

        sqlQuery = "sp_GetProjectInfo";
        
        SqlConnection objCon = new SqlConnection(strConn);
        objCon.Open();
        SqlCommand sqlCom = new SqlCommand(sqlQuery, objCon);

        sqlCom.CommandType = System.Data.CommandType.StoredProcedure;
        sqlCom.CommandText = sqlQuery;
        sqlCom.Parameters.AddWithValue("@prjID", prjID);
        SqlDataReader sqlReader = sqlCom.ExecuteReader();
        while (sqlReader.Read())
        {
            txtPrjTitle.Text = sqlReader["project_newname_en"].ToString();

            txtPrjCode.Text = sqlReader["project_code"].ToString();

            txtReceivedDate.Text = sqlReader["ts_tender_invitation"].ToString();

            txtTenderNo.Text = sqlReader["tender_no"].ToString();

            txtCntrNo.Text = sqlReader["contract_no"].ToString();

            txtMinistry.Text = sqlReader["Ministry_Code"].ToString();

            txtBudRef.Text = sqlReader["Budget_Reference_No"].ToString();

            txtProvNo.Text = sqlReader["Provision_Number"].ToString();

            txtCntrStatus.Text = sqlReader["ContractStatus"].ToString();

            txtCntrStartDate.Text = sqlReader["cp_sent_dep_sign"].ToString();

            txtCntrName.Text = sqlReader["co_name"].ToString();

            txtCntrAmount.Text = sqlReader["ContractAmount"].ToString();

            txtTndrType.Text = sqlReader["tender_type_name"].ToString();

            txtTndrStatus.Text = sqlReader["Status_Name"].ToString();

            txtCmtName.Text = sqlReader["committee_name"].ToString();

            txtDept.Text = sqlReader["Department"].ToString();

            txtCntrAmount.Text = sqlReader["ContractAmount"].ToString();

            txtCntrName.Text = sqlReader["co_name"].ToString();

            txtTndrBond.Text = sqlReader["tender_bond"].ToString();

            txtDocFee.Text = sqlReader["doc_fee"].ToString();

            txtPBondFee.Text = sqlReader["PerformanceBond"].ToString();

            txtBudgetCost.Text = sqlReader["budgeted_cost"].ToString();

            txtEstimated.Text = sqlReader["estimated_cost"].ToString();

            txtAwardDt.Text = sqlReader["cp_tender_award"].ToString();

            txtRecFromFinance.Text = sqlReader["cp_sent_dep_sign"].ToString();

            // txtRecTechnical.Text = sqlReader["cp_tender_award"].ToString();

            txtClsDt.Text = sqlReader["ts_closing_s1"].ToString();

            txtTndrOpenDt.Text = sqlReader["ts_receive_on"].ToString(); // 

            txtTndrIssuedt.Text = sqlReader["ts_tender_invitation"].ToString();

            txtRecTechnical.Text = sqlReader["eval_tech_receive1"].ToString();

            txtRecFinan.Text = sqlReader["eval_com_sent1"].ToString();

            //  eval_tender_opening

            // txtSeTechnical.Text = sqlReader["eval_tech_receive1"].ToString();

            txtAwardApprovalDt.Text = sqlReader["eval_tender_award_approval"].ToString();
        }

        sqlReader.Close(); 
    }
    private void GetBiddersInfo(string prjID)
    {
        string sqlQuery = "SELECT  COMPANY.co_name as BidderName, TenderDatesInfo.ts_tender_issue FROM COMPANY INNER JOIN TenderDatesInfo ON COMPANY.co_id = TenderDatesInfo.co_id LEFT OUTER JOIN PROJECTS ON TenderDatesInfo.proj_id = PROJECTS.proj_id " + 
                            " WHERE   (@prjID IS NULL) OR (PROJECTS.proj_id = @prjID)";

        SqlConnection objCon = new SqlConnection(strConn);
        objCon.Open();
        SqlCommand sqlCom = new SqlCommand(sqlQuery, objCon);

        sqlCom.CommandType = System.Data.CommandType.Text;
        sqlCom.CommandText = sqlQuery;
        sqlCom.Parameters.AddWithValue("@prjID", prjID);

        SqlDataAdapter da = new SqlDataAdapter(sqlCom);

        System.Data.DataSet ds = new System.Data.DataSet();       
        da.Fill(ds);

        GridView3.DataSource = ds.Tables[0];
        GridView3.DataBind();
    }

    private void GetStage1(string prjID)
    {
        string sqlQuery = "SELECT  ptd_receive_on, ptd_purpose, ptd_assign_qs, ptd_sent_for_rev, ptd_qs_working_status, ptd_tendec_doc_cur_status, ptd_forwarded_to_dep FROM TenderDatesInfo WHERE (@prjID IS NULL) OR  (stage_id = 1) AND (proj_id = @prjID)";

        SqlConnection objCon = new SqlConnection(strConn);
        objCon.Open();
        SqlCommand sqlCom = new SqlCommand(sqlQuery, objCon);

        sqlCom.CommandType = System.Data.CommandType.Text;
        sqlCom.CommandText = sqlQuery;
        sqlCom.Parameters.AddWithValue("@prjID", prjID);

        SqlDataAdapter da = new SqlDataAdapter(sqlCom);

        System.Data.DataSet ds = new System.Data.DataSet();
        da.Fill(ds);

        grvStage1.DataSource = ds.Tables[0];
        grvStage1.DataBind();
    
    }
    private void GetStage2(string prjID)
    {
        string sqlQuery = "SELECT ts_receive_on, ts_issue_handling, ts_return_to_dept, ts_receive_from_dept, ts_pr_advertise, ts_tender_invitation, ts_closing_s1, ts_closing_s2, ts_modified_closing FROM   TenderDatesInfo  WHERE (stage_id = 2) AND (proj_id = @prjID) AND (ts_tender_issue IS NULL)";

        SqlConnection objCon = new SqlConnection(strConn);
        objCon.Open();
        SqlCommand sqlCom = new SqlCommand(sqlQuery, objCon);

        sqlCom.CommandType = System.Data.CommandType.Text;
        sqlCom.CommandText = sqlQuery;
        sqlCom.Parameters.AddWithValue("@prjID", prjID);

        SqlDataAdapter da = new SqlDataAdapter(sqlCom);

        System.Data.DataSet ds = new System.Data.DataSet();
        da.Fill(ds);

        grvStage2.DataSource = ds.Tables[0];
        grvStage2.DataBind();

    }
    private void GetStage3(string prjID)
    {
        string sqlQuery = "SELECT eval_tender_opening, eval_tech_sent1, eval_tech_receive1, eval_com_sent1, eval_com_receive1, eval_tender_award_approval, remarks FROM  TenderDatesInfo WHERE (stage_id = 3) AND (proj_id = @prjID)";

        SqlConnection objCon = new SqlConnection(strConn);
        objCon.Open();
        SqlCommand sqlCom = new SqlCommand(sqlQuery, objCon);

        sqlCom.CommandType = System.Data.CommandType.Text;
        sqlCom.CommandText = sqlQuery;
        sqlCom.Parameters.AddWithValue("@prjID", prjID);

        SqlDataAdapter da = new SqlDataAdapter(sqlCom);

        System.Data.DataSet ds = new System.Data.DataSet();
        da.Fill(ds);

        grvStage3.DataSource = ds.Tables[0];
        grvStage3.DataBind();

    }
    private void GetStage4(string prjID)
    {
        string sqlQuery = "SELECT  CONTRACTORS.contract_no, COMPANY.co_name, CONTRACTORS.ContractTitle, COMPANY_TYPE.co_type_name, CONTRACTORS.ContractAmount, CONTRACTORS.ContractDuration, CONTRACTORS.cp_tender_award, CONTRACTORS.cp_sent_dep_sign, CONTRACTORS.StaffInCharge " + 
                     " FROM CONTRACTORS INNER JOIN COMPANY ON CONTRACTORS.co_id = COMPANY.co_id INNER JOIN COMPANY_TYPE ON COMPANY.co_type_id = COMPANY_TYPE.co_type_id WHERE (@prjID IS NULL) OR (CONTRACTORS.proj_id = @prjID)";

        SqlConnection objCon = new SqlConnection(strConn);
        objCon.Open();
        SqlCommand sqlCom = new SqlCommand(sqlQuery, objCon);

        sqlCom.CommandType = System.Data.CommandType.Text;
        sqlCom.CommandText = sqlQuery;
        sqlCom.Parameters.AddWithValue("@prjID", prjID);

        SqlDataAdapter da = new SqlDataAdapter(sqlCom);

        System.Data.DataSet ds = new System.Data.DataSet();
        da.Fill(ds);

        grvStage4.DataSource = ds.Tables[0];
        grvStage4.DataBind();

    }
    protected void btnIssueTndr_Click(object sender, EventArgs e)
    {
        Response.Redirect("IssueTender.aspx",false);
    }
    private void GeteBookData(string prjID)
    {
        string sqlQuery = "SELECT        Job.jobNo, Job.jobReceivedDate, JobType.jobTypeName AS Job_Type, Document_1.referenceNo AS ref_no, Document_1.docSubject, " +
        " REPLACE(CONVERT(NVARCHAR, Job.jobClosedDate, 106), ' ', '-') AS DateClosed, Contact_2.userShortName AS CENAME, Contact.userShortName AS PENAME, Contact_1.userShortName AS QSNAME, Job.remarks, Job.addendumNO, JobStatus.jobStatusName AS Job_Status " +
                " FROM            Contact AS Contact_2 RIGHT OUTER JOIN Job INNER JOIN JobStatus ON Job.jobStatusID = JobStatus.jobStatusID INNER JOIN JobType ON Job.jobTypeID = JobType.jobTypeID LEFT OUTER JOIN " +
                        " Contact AS Contact_1 ON Job.qsID = Contact_1.contactID ON Contact_2.contactID = Job.ceID LEFT OUTER JOIN Contact ON Job.peID = Contact.contactID LEFT OUTER JOIN [Document] AS Document_1 ON Job.docRefID = Document_1.documentID " +
                      " WHERE        (Job.contractNo = 'EBD/2018/CS/001/S') ";


      //  string sqlQuery = "SELECT  COUNT(proj_id) AS PrjCnt, YEAR(create_date) AS Year FROM   PROJECTS GROUP BY YEAR(create_date) ORDER BY Year";

        SqlConnection objCon = new SqlConnection(strConn);
        objCon.Open();
        SqlCommand sqlCom = new SqlCommand(sqlQuery, objCon);

        sqlCom.CommandType = System.Data.CommandType.Text;
        sqlCom.CommandText = sqlQuery;
        sqlCom.Parameters.AddWithValue("@prjID", prjID);

        SqlDataAdapter da = new SqlDataAdapter(sqlCom);

        System.Data.DataSet ds = new System.Data.DataSet();
        da.Fill(ds);

        //GridView4.DataSource = ds.Tables[0];
        //GridView4.DataBind();
    }

    
    
    protected void btnsave_Click(object sender, EventArgs e)
    {
        
    }

    //private void getChart_ProjectStatusWise()
    //{
    //    DataSet dsDoc = new DataSet();

    //    string sqlQuery = null;

    //    sqlQuery = "SELECT  STAGES.Stage_Name AS PrjStatus, COUNT(PROJECTS.proj_id) AS PrjCnt FROM   PROJECTS INNER JOIN   STAGES ON PROJECTS.stage_id = STAGES.stage_id  WHERE  (YEAR(PROJECTS.create_date) = 2018) GROUP BY STAGES.Stage_Name, YEAR(PROJECTS.create_date)";

       
    //    SqlDataAdapter daDoc = new SqlDataAdapter(sqlQuery, strConn);
    //    daDoc.Fill(dsDoc);
    //    if (dsDoc.Tables[0].Rows.Count != 0)
    //    {
    //        projectsStatusWise.DataSource = dsDoc.Tables[0].DefaultView;
    //        projectsStatusWise.Series["Series1"].XValueMember = "PrjStatus";
    //        projectsStatusWise.Series["Series1"].YValueMembers = "prjCnt";

    //        dsDoc.Tables.Clear();

    //        projectsStatusWise.ChartAreas[0].AxisX.MajorGrid.Enabled = false;
    //        projectsStatusWise.ChartAreas[0].AxisX.MinorGrid.Enabled = false;
    //        projectsStatusWise.ChartAreas[0].AxisY.MajorGrid.Enabled = false;
    //        projectsStatusWise.ChartAreas[0].AxisY.MinorGrid.Enabled = false;

    //        projectsStatusWise.ChartAreas[0].AxisX.LabelStyle.Angle = 30;
    //        projectsStatusWise.ChartAreas[0].AxisX.LabelStyle.ForeColor = Color.Maroon;

    //        projectsStatusWise.ChartAreas[0].AxisX.Interval = 1;
    //    }
    //}


    //private void getChart_ProjectTypeWise()
    //{
    //    DataSet dsDoc = new DataSet();

    //    string sqlQuery = null;
     
    //    sqlQuery = "SELECT   COUNT(PROJECTS.proj_id) AS PrjCnt, ContractTypes.TypeofContract FROM   PROJECTS INNER JOIN  ContractTypes ON PROJECTS.contract_type_id = ContractTypes.contract_type_id " +
    //            "WHERE  (YEAR(PROJECTS.create_date) = 2018) GROUP BY ContractTypes.TypeofContract, YEAR(PROJECTS.create_date)";

    //    SqlDataAdapter daDoc = new SqlDataAdapter(sqlQuery, strConn);
    //    daDoc.Fill(dsDoc);
    //    if (dsDoc.Tables[0].Rows.Count != 0)
    //    {
    //        projectTypeWise.DataSource = dsDoc.Tables[0].DefaultView;
    //        projectTypeWise.Series["Series1"].XValueMember = "TypeofContract";
    //        projectTypeWise.Series["Series1"].YValueMembers = "prjCnt";

    //        dsDoc.Tables.Clear();

    //        projectTypeWise.ChartAreas[0].AxisX.MajorGrid.Enabled = false;
    //        projectTypeWise.ChartAreas[0].AxisX.MinorGrid.Enabled = false;
    //        projectTypeWise.ChartAreas[0].AxisY.MajorGrid.Enabled = false;
    //        projectTypeWise.ChartAreas[0].AxisY.MinorGrid.Enabled = false;

    //        projectTypeWise.ChartAreas[0].AxisX.LabelStyle.Angle = 30;
    //        projectTypeWise.ChartAreas[0].AxisX.LabelStyle.ForeColor = Color.Maroon;

    //        projectTypeWise.ChartAreas[0].AxisX.Interval = 1;
    //    }
    //}
    //private void getChart_DepartmentWise()
    //{
    //    DataSet dsDoc = new DataSet();

    //    string sqlQuery = null;
    //    sqlQuery = " SELECT        COUNT(PROJECTS.proj_id) AS PrjCnt, Department.Department FROM    PROJECTS INNER JOIN    Department ON PROJECTS.department_id = Department.department_id " +
    //          " WHERE        (YEAR(PROJECTS.create_date) = 2018) GROUP BY YEAR(PROJECTS.create_date), Department.Department ";

    //    SqlDataAdapter daDoc = new SqlDataAdapter(sqlQuery, strConn);
    //    daDoc.Fill(dsDoc);
    //    if (dsDoc.Tables[0].Rows.Count != 0)
    //    {
    //        projectDepartmentWise.DataSource = dsDoc.Tables[0].DefaultView;
    //        projectDepartmentWise.Series["Series1"].XValueMember = "Department";
    //        projectDepartmentWise.Series["Series1"].YValueMembers = "prjCnt";

    //        dsDoc.Tables.Clear();

    //        projectDepartmentWise.ChartAreas[0].AxisX.MajorGrid.Enabled = false;
    //        projectDepartmentWise.ChartAreas[0].AxisX.MinorGrid.Enabled = false;
    //        projectDepartmentWise.ChartAreas[0].AxisY.MajorGrid.Enabled = false;
    //        projectDepartmentWise.ChartAreas[0].AxisY.MinorGrid.Enabled = false;

    //        projectDepartmentWise.ChartAreas[0].AxisX.LabelStyle.Angle = 30;
    //        projectDepartmentWise.ChartAreas[0].AxisX.LabelStyle.ForeColor = Color.Maroon;

    //        projectDepartmentWise.ChartAreas[0].AxisX.Interval = 1;
    //    }
    //}
    //private void getChart_TenderTypeWise()
    //{
    //    DataSet dsDoc = new DataSet();

    //    string sqlQuery = null;
    //    sqlQuery = "  SELECT   COUNT(PROJECTS.proj_id) AS PrjCnt, TenderTypes.tender_type_name FROM    PROJECTS INNER JOIN   TenderTypes ON PROJECTS.tender_type_id = TenderTypes.tender_type_id " +
    //                 " WHERE   (YEAR(PROJECTS.create_date) = 2018) GROUP BY YEAR(PROJECTS.create_date), TenderTypes.tender_type_name ";

    //    SqlDataAdapter daDoc = new SqlDataAdapter(sqlQuery, strConn);
    //    daDoc.Fill(dsDoc);
    //    if (dsDoc.Tables[0].Rows.Count != 0)
    //    {
    //        chartTenderTypes.DataSource = dsDoc.Tables[0].DefaultView;
    //        chartTenderTypes.Series["Series1"].XValueMember = "tender_type_name";
    //        chartTenderTypes.Series["Series1"].YValueMembers = "prjCnt";

    //        dsDoc.Tables.Clear();

    //        chartTenderTypes.ChartAreas[0].AxisX.MajorGrid.Enabled = false;
    //        chartTenderTypes.ChartAreas[0].AxisX.MinorGrid.Enabled = false;
    //        chartTenderTypes.ChartAreas[0].AxisY.MajorGrid.Enabled = false;
    //        chartTenderTypes.ChartAreas[0].AxisY.MinorGrid.Enabled = false;

    //        chartTenderTypes.ChartAreas[0].AxisX.LabelStyle.Angle = 30;
    //        chartTenderTypes.ChartAreas[0].AxisX.LabelStyle.ForeColor = Color.Maroon;

    //        chartTenderTypes.ChartAreas[0].AxisX.Interval = 1;
    //    }
    //}
    //private void getChart_TenderStatusWise()
    //{
        

    // DataSet dsDoc = new DataSet();

    //    string sqlQuery = null;
    //    sqlQuery = "SELECT        COUNT(PROJECTS.proj_id) AS PrjCnt, TenderStatus.Status_Name FROM PROJECTS INNER JOIN TenderStatus ON PROJECTS.Tender_Status_id = TenderStatus.Tender_Status_id" +
    //                " WHERE        (YEAR(PROJECTS.create_date) = 2018) GROUP BY YEAR(PROJECTS.create_date), TenderStatus.Status_Name";

    //    SqlDataAdapter daDoc = new SqlDataAdapter(sqlQuery, strConn);
    //    daDoc.Fill(dsDoc);
    //    if (dsDoc.Tables[0].Rows.Count != 0)
    //    {
    //        chartStatus.DataSource = dsDoc.Tables[0].DefaultView;
    //        chartStatus.Series["Series1"].XValueMember = "Status_Name";
    //        chartStatus.Series["Series1"].YValueMembers = "prjCnt";

    //        dsDoc.Tables.Clear();

    //        chartStatus.ChartAreas[0].AxisX.MajorGrid.Enabled = false;
    //        chartStatus.ChartAreas[0].AxisX.MinorGrid.Enabled = false;
    //        chartStatus.ChartAreas[0].AxisY.MajorGrid.Enabled = false;
    //        chartStatus.ChartAreas[0].AxisY.MinorGrid.Enabled = false;

    //        chartStatus.ChartAreas[0].AxisX.LabelStyle.Angle = 30;
    //        chartStatus.ChartAreas[0].AxisX.LabelStyle.ForeColor = Color.Maroon;

    //        chartStatus.ChartAreas[0].AxisX.Interval = 1;
    //    }
    //}
    //private void getChart_CommeetteeWise()
    //{
    //    DataSet dsDoc = new DataSet();
    //    string sqlQuery = null;
    //    sqlQuery = "SELECT        COUNT(PROJECTS.proj_id) AS PrjCnt, Committee.committee_name FROM            PROJECTS INNER JOIN   Committee ON PROJECTS.committee_id = Committee.committee_id " + 
    //          " WHERE        (YEAR(PROJECTS.create_date) = 2018) GROUP BY YEAR(PROJECTS.create_date), Committee.committee_name";

    //    SqlDataAdapter daDoc = new SqlDataAdapter(sqlQuery, strConn);
    //    daDoc.Fill(dsDoc);
    //    if (dsDoc.Tables[0].Rows.Count != 0)
    //    {
    //        chartCommeetee.DataSource = dsDoc.Tables[0].DefaultView;
    //        chartCommeetee.Series["Series1"].XValueMember = "committee_name";
    //        chartCommeetee.Series["Series1"].YValueMembers = "prjCnt";

    //        dsDoc.Tables.Clear();

    //        chartCommeetee.ChartAreas[0].AxisX.MajorGrid.Enabled = false;
    //        chartCommeetee.ChartAreas[0].AxisX.MinorGrid.Enabled = false;
    //        chartCommeetee.ChartAreas[0].AxisY.MajorGrid.Enabled = false;
    //        chartCommeetee.ChartAreas[0].AxisY.MinorGrid.Enabled = false;

    //        chartCommeetee.ChartAreas[0].AxisX.LabelStyle.Angle = 30;
    //        chartCommeetee.ChartAreas[0].AxisX.LabelStyle.ForeColor = Color.Maroon;

    //        chartCommeetee.ChartAreas[0].AxisX.Interval = 1;
    //    }
    //}   
    protected void btnHome_Click(object sender, EventArgs e)
    {
        

        Response.Redirect("~/Guest/Default9.aspx", false);
    }
}