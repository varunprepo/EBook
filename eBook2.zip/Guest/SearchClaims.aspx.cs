﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using Datalayer;
using System.Web.UI.HtmlControls;
using System.IO;
using System.Drawing;

public partial class Guest_SearchClaims : System.Web.UI.Page
{
    string connValue = System.Configuration.ConfigurationManager.ConnectionStrings["EBSDEBookConn"].ConnectionString;
    string _prjCode = string.Empty; string flag = string.Empty;
    int jobType = 0;
    string _userName = string.Empty; int cntID = 0;
    static IList<string> userRightsColl = null;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["UserName"] == null)
        {
            Response.Redirect("~/LoginPage.aspx", false);
            return;
        }

        string chartStatus = string.Empty;

        userRightsColl = (IList<string>)Session["UserRightsColl"];
        lblUser.Text = Session["UserDisplayName"].ToString();
        lblUserProfile.Text = Session["ProfileName"].ToString();
        if (Session["ProjectCode"] != null)
            _prjCode = Session["ProjectCode"].ToString(); // Request.QueryString["ProjCode"];      

        if (Session["Flag"] != null)
            flag = Session["Flag"].ToString();

        cntID = new JobOrderData().getUserID(_userName);

        DataTable dt = new DataTable();

        if (!IsPostBack)
        {
            int sectionID = Convert.ToInt16(Session["SectionID"]);
           // FillDropBox(sectionID);
            DataView dvCommitted = new DataView();
            if (_prjCode == null)
            {
                dt = FillTab2(0, "");     //  SearchJob
                Session["ChartJobs"] = dt;
                gvJoborder.DataSource = dt;
                gvJoborder.DataBind();

                FillTabByJobNo(0, "","");

                lblCnt.Text = dt.Rows.Count.ToString();
            }
            else
            {
                dt = FillTab2(0, _prjCode);
                Session["ChartJobs"] = dt;
                gvJoborder.DataSource = dt;
                gvJoborder.DataBind();

                lblCnt.Text = dt.Rows.Count.ToString();
            }
        }
    }
    //protected void lnkProjectCodeCmted_Click(object sender, EventArgs e)     //ForCommitted
    //{
    //    try
    //    {
    //        LinkButton lnkJobID = (LinkButton)sender;
    //        GridViewRow gvr = (GridViewRow)lnkJobID.NamingContainer;
    //        Session["ProjectCode"] = ((HtmlGenericControl)gvr.FindControl("divProjectCodeCmted")).InnerText;

    //        Session["UrlRef"] = Request.Url.AbsoluteUri;
    //        Response.Redirect("~/JobOrder/SearchJobMstr.aspx?Project_Code = " + Session["ProjectCode"] + "", false);
    //    }
    //    catch
    //    {

    //    }
    //}
    protected void lnkJobOrderJobNo_Click(object sender, EventArgs e)     //ForCommitted
    {
        try
        {
            LinkButton lnkJobID = (LinkButton)sender;
            GridViewRow gvr = (GridViewRow)lnkJobID.NamingContainer;

            Session["JobID"] = ((HtmlGenericControl)gvr.FindControl("divJobID")).InnerText;

            Session["UrlRef"] = Request.Url.AbsoluteUri;
            Response.Redirect("~/Contracts/ClaimDetails.aspx?JobID= " + Session["JobID"] + "", false);

        }
        catch
        {

        }
    }
    private DataTable FillTab2(int searchType, string _prjCode)
    {
        DataSet ds = new DataSet();
        try
        {
            Int16 jobid;
            Int16.TryParse("0", out jobid);

            Int16 afrID;
            Int16.TryParse("0", out afrID);

            Int16 dptID;
            Int16.TryParse("0", out dptID);

            Int16 consID;
            Int16.TryParse("0", out consID);

            Int16 jobType;
            Int16.TryParse("0", out jobType);

            Int16 jobStatus;
            Int16.TryParse("0", out jobStatus);

            Int16 docRefID;
            Int16.TryParse("0", out docRefID);

            Int16 docClsRefID;
            Int16.TryParse("0", out docClsRefID);

            Int16 qsID;
            Int16.TryParse("0", out qsID);

            Int16 ceID;
            Int16.TryParse("0", out ceID);

            Int16 peID;
            Int16.TryParse("0", out peID);

            string prjTitle = string.Empty;


            string docSubject = string.Empty;


            Int16 cntrID;
            Int16.TryParse("0", out cntrID);

            Int16 consultID;
            Int16.TryParse("0", out consultID);

            string prjCode = string.Empty;

            string txtfrom = string.Empty;

            string txtTo = string.Empty;

            Int16 VOID;
            Int16.TryParse("0", out VOID);

            Int16 EOTID;
            Int16.TryParse("0", out EOTID);


            string _jobNo = string.Empty;
            if (txtJobNo.Text != "")
                _jobNo = "%" + txtJobNo.Text + "%";

            string _refNo = string.Empty;

            string _ClsrefNo = string.Empty;

            string _contractNo = string.Empty;
            if (jobStatus==0)
            {
                jobStatus = 3;
            }
            if ((!userRightsColl.Contains("17")))       // View All On-Going List of Job Orders
            {
                ds = (new JobOrderData().GetJobOrderDetails_Claim(searchType, jobid, jobType, jobStatus, afrID, dptID, docRefID, qsID, ceID, peID, prjTitle, cntrID, consultID, prjCode, txtfrom, VOID, EOTID, docSubject, docClsRefID, txtTo, 0, 0, Convert.ToInt32(Session["SectionID"])));
            }
            else
            {
                ds = (new JobOrderData().GetJobOrderDetails_Claim(searchType, jobid, jobType, jobStatus, afrID, dptID, docRefID, qsID, ceID, peID, prjTitle, cntrID, consultID, prjCode, txtfrom, VOID, EOTID, docSubject, docClsRefID, txtTo, 0, Convert.ToInt32(Session["UserID"]), Convert.ToInt32(Session["SectionID"])));
            }

            //if (Session["IsSearchedClicked"].ToString() == "1")
            //{
            //    ds = (new JobOrderData().GetJobOrderDetails_Claim(searchType, jobid, jobType, jobStatus, afrID, dptID, docRefID, qsID, ceID, peID, prjTitle, cntrID, consultID, prjCode, txtfrom, VOID, EOTID, docSubject, docClsRefID, txtTo, 0, 0, Convert.ToInt32(Session["SectionID"])));
            //}
            //else if (Session["ShortName"] != null)
            //{
            //    ds = (new JobOrderData().GetJobOrderDetails_Claim(searchType, jobid, jobType, jobStatus, afrID, dptID, docRefID, qsID, ceID, peID, prjTitle, cntrID, consultID, prjCode, txtfrom, VOID, EOTID, docSubject, docClsRefID, txtTo, 0, new JobOrderData().getContactID(Session["ShortName"].ToString()), Convert.ToInt32(Session["SectionID"])));
            //}
            //else
            //{
            //    ds = (new JobOrderData().GetJobOrderDetails_Claim(searchType, jobid, jobType, jobStatus, afrID, dptID, docRefID, qsID, ceID, peID, prjTitle, cntrID, consultID, prjCode, txtfrom, VOID, EOTID, docSubject, docClsRefID, txtTo, 0, 0, Convert.ToInt32(Session["SectionID"])));
            //}            

        }
        catch (Exception ex)
        {

        }
        return ds.Tables[0];
    }   
    protected void gvJoborder_RowDataBound(object sender, GridViewRowEventArgs e)
    {

    }
    protected void gvJoborder_RowCommand(object sender, GridViewCommandEventArgs e)
    {

    }
    protected void gvJoborder_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {

    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/Contracts/CreateClaim.aspx", false);
    }
    protected void btnDcLog_Click(object sender, EventArgs e)
    {

    }
    protected void txtJobNo_TextChanged(object sender, EventArgs e)
    {
        Session["OnGoingJobStatus"] = null;

        DataTable dt = new DataTable();
        dt = FillTabByJobNo(0, "","");

        Session["OnGoingJobStatus"] = dt;

        gvJoborder.DataSource = dt;
        gvJoborder.DataBind();

        lblCnt.Text = dt.Rows.Count.ToString();
    }
    private DataTable FillTabByJobNo(int searchType, string _prjCode,string prjTitle)
    {
        DataSet ds = new DataSet();
        try
        {
            Int16 jobid;
            Int16.TryParse("0", out jobid);

            Int16 afrID;
            Int16.TryParse("0", out afrID);

            Int16 dptID;
            Int16.TryParse("0", out dptID);

            Int16 consID;
            Int16.TryParse("0", out consID);

            Int16 jobType;
            Int16.TryParse("0", out jobType);

            Int16 jobStatus;
            Int16.TryParse("0", out jobStatus);

            Int16 docRefID;
            Int16.TryParse("0", out docRefID);

            Int16 docClsRefID;
            Int16.TryParse("0", out docClsRefID);

            Int16 qsID;
            Int16.TryParse("0", out qsID);

            Int16 ceID;
            Int16.TryParse("0", out ceID);

            Int16 peID;
            Int16.TryParse("0", out peID);

            string _prjTitle = string.Empty;
            

            string docSubject = string.Empty;
           

            Int16 cntrID;
            Int16.TryParse("0", out cntrID);

            Int16 consultID;
            Int16.TryParse("0", out consultID);

            string prjCode = string.Empty;

            string txtfrom = string.Empty;
         

            Int16 VOID;
            Int16.TryParse("0", out VOID);

            Int16 EOTID;
            Int16.TryParse("0", out EOTID);


            string _jobNo = string.Empty;
            if (txtJobNo.Text != "")
                _jobNo = "%" + txtJobNo.Text + "%";

            
            if (txtJobTitle.Text != "")
                _prjTitle = "%" + txtJobTitle.Text + "%";

            string _refNo = string.Empty;           

            string _ClsrefNo = string.Empty;            

            string _contractNo = string.Empty;

            // Cntr_SearchJobByJobNO
            //ds = (new JobOrderData().Cntr_GetJobOrderDetailsByJobNo(searchType, jobid, jobType, jobStatus, afrID, dptID, docRefID, qsID, ceID, peID, _prjTitle, cntrID, consultID, prjCode, txtfrom, docSubject, docClsRefID, _jobNo, _refNo, _contractNo, _ClsrefNo));   //sp_SearchJobByJobNO
            ds = (new JobOrderData().GetJobOrderDetailsByJobNo(searchType, jobid, jobType, jobStatus, afrID, dptID, docRefID, qsID, ceID, peID, _prjTitle, cntrID, consultID, prjCode, txtfrom, docSubject, docClsRefID, _jobNo, _refNo, _contractNo, _ClsrefNo));

        }
        catch (Exception ex)
        {

        }
        return ds.Tables[0];
    }
    protected void btnHome_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/Contracts/ClaimsHomePage.aspx", false);
    }
    protected void btnExcel_Click(object sender, EventArgs e)
    {
        ExportToExcel_Sree();
    }
    #region MyRegion

    private void ExportToExcel_Sree()
    {
        Response.Clear();
        Response.Buffer = true;
        Response.AddHeader("content-disposition", "attachment;filename=GridViewExport.xls");
        Response.Charset = "";
        Response.ContentType = "application/vnd.ms-excel";
        using (StringWriter sw = new StringWriter())
        {
            HtmlTextWriter hw = new HtmlTextWriter(sw);

            //To Export all pages
            gvJoborder.AllowPaging = false;

            gvJoborder.DataSource = Session["ChartJobs"];
            gvJoborder.DataBind();

            gvJoborder.HeaderRow.BackColor = Color.White;
            foreach (TableCell cell in gvJoborder.HeaderRow.Cells)
            {
                cell.BackColor = gvJoborder.HeaderStyle.BackColor;
            }
            foreach (GridViewRow row in gvJoborder.Rows)
            {
                row.BackColor = Color.White;
                foreach (TableCell cell in row.Cells)
                {
                    if (row.RowIndex % 2 == 0)
                    {
                        cell.BackColor = gvJoborder.AlternatingRowStyle.BackColor;
                    }
                    else
                    {
                        cell.BackColor = gvJoborder.RowStyle.BackColor;
                    }
                    cell.CssClass = "textmode";
                }
            }

            gvJoborder.RenderControl(hw);

            //style to format numbers to string
            string style = @"<style> .textmode { } </style>";
            Response.Write(style);
            Response.Output.Write(sw.ToString());
            Response.Flush();
            Response.End();
        }
    }
    public override void VerifyRenderingInServerForm(Control control)
    {
        /* Verifies that the control is rendered */
    }

    #endregion
    protected void txtJobTitle_TextChanged(object sender, EventArgs e)
    {
       //  Cntr_SearchJobByJobNO

        Session["OnGoingJobStatus"] = null;

        DataTable dt = new DataTable();
        dt = FillTabByJobNo(0, "", "");

        Session["OnGoingJobStatus"] = dt;

        gvJoborder.DataSource = dt;
        gvJoborder.DataBind();

        lblCnt.Text = dt.Rows.Count.ToString();
    }
    protected void lnkLogOutBtn_Click(object sender, EventArgs e)
    {
        // Added by Varun on 01/Dec/2019
        Response.Redirect("~/LoginPage.aspx", false);
    }
}