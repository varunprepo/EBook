﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using Datalayer;
using System.Data;
using System.Text;
using System.Net.Mail;
using System.Net;
using System.Security.Cryptography.X509Certificates;
using System.Net.Security;
using System.Text;
using System.Globalization;
public partial class Guest_TenderStages : System.Web.UI.Page
{
    string strConn = ConfigurationManager.ConnectionStrings["TCMSConn"].ConnectionString;

    string connStr = ConfigurationManager.ConnectionStrings["TCMSConn"].ConnectionString;   

    static string _userName = string.Empty;
     string _projID = string.Empty;
    TCMS_Stage1 clsStage1 = new TCMS_Stage1();

    
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
           

          Tab1.CssClass = "Clicked";
          MainView.ActiveViewIndex = 0;

          lblProjID.Text = Session["PrjID"].ToString();

          Stage1_Data();

          Stage2_Data();

          Stage3_Data();

          GetStage3(Session["PrjID"].ToString());

          WorkOrderData();

          _projID = Session["PrjID"].ToString();

        //  _userName = Session["UserName"].ToString();

            int q =0; string str ="";

            FillTenderStageInfo(ref q, ref str);

            FillTenderEvaluationInfo(ref q);

            FillProjectInfo();

            

            Stage4();

        }
    }

    

    #region Stage-1 Data

    // ======================================================            Stage -1   ====================================================================================================================
    
    private void Stage1_Data()
    {
       // TCMS_Stage1 clsStage1 = new TCMS_Stage1();


        FillCombo_PTD();
        dgvPTD.DataSource = clsStage1.GetStage1_grid(1, Session["PrjID"].ToString());
        dgvPTD.DataBind();

       // commCls.FillGridReceivedDocsInfo(_projID, dgvPTD_Rec, 1);
       // commCls.FillGridSentDocsInfo(_projID, dgvPTD_Sent, 1);
    }
    private void FillCombo_PTD()
    {
        cmbPurpose.Items.Add("Preparation");
        cmbPurpose.Items.Add("Review");
        cmbPurpose.Items.Add("Amendment");
        cmbPurpose.Items.Add("Re-Tender");
        cmbPurpose.Items.Add("Tender");

        cmbPurpose.SelectedIndex = -1;

        PopulateDropDownBox(cmbAssignedQs, "SELECT employee_id, shortname from Contacts where shortname is not null order by shortname asc", "employee_id", "shortname");
        cmbAssignedQs.SelectedIndex = -1;

        cmbQsWorkingStatus.Items.Add("On-going");
        cmbQsWorkingStatus.Items.Add("Completed");
        cmbQsWorkingStatus.Items.Add("On Hold");
        cmbQsWorkingStatus.SelectedIndex = -1;

        cmbTenderDocStatus.Items.Add("Approved");
        cmbTenderDocStatus.Items.Add("Disapproved");
        cmbTenderDocStatus.SelectedIndex = -1;
    }

    
    protected void grvStage1_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName.Equals("SelectStaff"))
        {
            string arguments = e.CommandArgument.ToString();

            if (arguments == "")
                return;

            string[] args = arguments.Split(';');
            int dateID = Convert.ToInt32(args[0]);
            Stage1_SelectedRow(dateID);
        }
    }
    private void Stage1_SelectedRow(int dateID)
    {
        string qry = "SELECT  date_ID,ptd_receive_on, ptd_purpose, ptd_assign_qs, ptd_sent_for_rev, ptd_qs_working_status, ptd_tendec_doc_cur_status, ptd_forwarded_to_dep FROM TenderDatesInfo WHERE (date_ID = " + dateID + ")";

        using (SqlConnection cn = new SqlConnection(strConn))
        {
            cn.Open();
            using (SqlCommand cmd = new SqlCommand(qry, cn))
            {
                using (SqlDataReader dr = cmd.ExecuteReader())
                {
                    while (dr.Read())
                    {
                        msk_dtpRecievedOn.Text = Convert.ToDateTime(dr["ptd_receive_on"]).ToString("dd/MMM/yyyy");

                        cmbPurpose.Text = dr["ptd_purpose"].ToString();

                        cmbAssignedQs.SelectedItem.Text = dr["ptd_assign_qs"].ToString();

                        cmbQsWorkingStatus.Text = dr["ptd_qs_working_status"].ToString();

                        cmbTenderDocStatus.Text = dr["ptd_tendec_doc_cur_status"].ToString();

                        msk_dtpFrwdDept.Text = dr["ptd_forwarded_to_dep"].ToString();

                        //  txtRemarks.Text = dr["ptd_forwarded_to_dep"].ToString();

                        lblDateID.Text = dr["date_ID"].ToString();

                    }
                }
            }
        }
    }
    private void InsertTenderPreparationInfo(int _dateID)
    {
        if (msk_dtpRecievedOn.Text == "")
        {
            msk_dtpRecievedOn.Focus();
            return;
        }

        try
        {
            using (SqlConnection sqlConn = new SqlConnection(connStr))
            {
                sqlConn.Open();
                string insertQuery = "INSERT INTO TenderDatesInfo(date_id,proj_id, stage_id, ptd_receive_on, ptd_purpose, ptd_assign_qs," +
                " ptd_sent_for_rev, ptd_qs_working_status, ptd_tendec_doc_cur_status,ptd_forwarded_to_dep, remarks,Create_Date,Create_User) VALUES " +
                " (@dateId,@projId,@stageId,@PTDreceiveOn,@PTDPurpose,@PTDassignQs,@PTDForReview,@PTDQsStatus,@PTDdocStatus,@PTDfrwdDept,@PTDRemarks,@CreateDate,@CreateUser)";

                SqlCommand cmd = new SqlCommand(insertQuery, sqlConn);
                cmd.Parameters.AddWithValue("@dateId", _dateID);
                cmd.Parameters.AddWithValue("@projId", Convert.ToInt32(Session["PrjID"].ToString())); // lblprjID.Text
                cmd.Parameters.AddWithValue("@stageId", 1);

                //Modified by Varun on 12/02/2014 for inserting dates when the regional settings of the system is Arabic, this will work for en-US settings 
                if (msk_dtpRecievedOn.Text != "")
                    cmd.Parameters.AddWithValue("@PTDreceiveOn", Convert.ToDateTime(msk_dtpRecievedOn.Text + " " + DateTime.Now.Hour + ":" + DateTime.Now.Minute + ":" + DateTime.Now.Second)); //Convert.ToDateTime(msk_dtpRecievedOn.Text).ToString("dd/MMM/yyyy")
                else
                    cmd.Parameters.AddWithValue("@PTDreceiveOn", DBNull.Value);

                if (cmbPurpose.SelectedIndex != -1)
                    cmd.Parameters.AddWithValue("@PTDPurpose", cmbPurpose.SelectedItem.ToString());
                else
                    cmd.Parameters.AddWithValue("@PTDPurpose", DBNull.Value);

                if (cmbTenderDocStatus.SelectedIndex != -1)
                    cmd.Parameters.AddWithValue("@PTDdocStatus", cmbTenderDocStatus.SelectedItem.ToString());
                else
                    cmd.Parameters.AddWithValue("@PTDdocStatus", DBNull.Value);

                if (cmbAssignedQs.SelectedIndex != -1)
                    cmd.Parameters.AddWithValue("@PTDassignQs", cmbAssignedQs.Text.ToString());
                else
                    cmd.Parameters.AddWithValue("@PTDassignQs", DBNull.Value);

                string[] formats = { "dd/MMM/yyyy hh:mm:ss tt", "dd-MMM-yyyy hh:mm:ss tt" };

                //DateTime value;
                // DateTime.TryParseExact(msk_dtpReview.Text, formats, CultureInfo.InvariantCulture, DateTimeStyles.None, out value);

                if (msk_dtpReview.Text != "")
                    cmd.Parameters.AddWithValue("@PTDForReview", Convert.ToDateTime(msk_dtpReview.Text)); //.ToString("dd/MMM/yyyy")
                else
                    cmd.Parameters.AddWithValue("@PTDForReview", DBNull.Value);

                if (cmbQsWorkingStatus.SelectedIndex != -1)
                    cmd.Parameters.AddWithValue("@PTDQsStatus", cmbQsWorkingStatus.SelectedItem.ToString());
                else
                    cmd.Parameters.AddWithValue("@PTDQsStatus", DBNull.Value);

                //Modified by Varun on 12/02/2014 for inserting dates when the regional settings of the system is Arabic, this will work for en-US settings 
                if (msk_dtpFrwdDept.Text != "")
                    cmd.Parameters.AddWithValue("@PTDfrwdDept", Convert.ToDateTime(msk_dtpFrwdDept.Text));//.ToString("dd/MMM/yyyy")
                else
                    cmd.Parameters.AddWithValue("@PTDfrwdDept", DBNull.Value);

                cmd.Parameters.AddWithValue("@PTDRemarks", txtRemarks.Text);

                cmd.Parameters.AddWithValue("@CreateDate", System.DateTime.Now);
                cmd.Parameters.AddWithValue("@CreateUser", _userName);

                cmd.ExecuteNonQuery();
                cmd.Parameters.Clear();
                cmd.CommandText = @"UPDATE PROJECTS set last_Modified_Date=@UpdateDate,Update_User = @UpdateUser where proj_id=@projId";
                cmd.Parameters.AddWithValue("@UpdateDate", System.DateTime.Now);
                cmd.Parameters.AddWithValue("@UpdateUser", _userName);
                cmd.Parameters.AddWithValue("@projId", _projID);
                cmd.ExecuteNonQuery();

            }
        }
        catch (Exception ex)
        {

        }
        finally
        {

        }

        //For update Assigned QS in Projects Table
        //  clsStaff.update_AssignedQs(cmbAssignedQs.Text.ToString(), projId);

    }

    private void Update_Stage1()
    {
        try
        {
            using (SqlConnection sqlConn = new SqlConnection(strConn))
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    sqlConn.Open();
                    cmd.Connection = sqlConn;

                    cmd.CommandText = @"UPDATE TenderDatesInfo set ptd_receive_on=@ptdreceivedate,ptd_purpose=@ptdpurpose,ptd_assign_qs=@ptdassignqs,ptd_sent_for_rev=@ptdReview," +
                    "ptd_qs_working_status=@ptdQsstatus,ptd_tendec_doc_cur_status=@ptdCurrentStatus,ptd_forwarded_to_dep=@ptdFrwdToDep where date_id=@dateId";

                    cmd.Parameters.AddWithValue("@ptdreceivedate", Convert.ToDateTime(msk_dtpRecievedOn.Text).ToString("dd/MMM/yyyy"));
                    cmd.Parameters.AddWithValue("@ptdpurpose", cmbPurpose.SelectedItem.ToString());
                    cmd.Parameters.AddWithValue("@ptdassignqs", cmbAssignedQs.SelectedItem.ToString());
                    cmd.Parameters.AddWithValue("@ptdReview", Convert.ToDateTime(msk_dtpReview.Text).ToString("dd/MMM/yyyy"));
                    cmd.Parameters.AddWithValue("@ptdQsstatus", cmbQsWorkingStatus.SelectedItem.ToString());
                    cmd.Parameters.AddWithValue("@ptdCurrentStatus", cmbTenderDocStatus.SelectedItem.ToString());
                    cmd.Parameters.AddWithValue("@ptdFrwdToDep", Convert.ToDateTime(msk_dtpFrwdDept.Text).ToString("dd/MMM/yyyy")); 
                    cmd.Parameters.AddWithValue("@dateId", Convert.ToInt16(lblDateID.Text));

                    int exUpdated = cmd.ExecuteNonQuery();
                    cmd.Parameters.Clear();

                }
            }
        }
        catch (Exception ex)
        {

        }

       // GridViewRefresh_PTD();
    }

    #endregion

    

    
    
    
    
    

    
   
   
    

   

    private void stage1_SelectedRow()
    {
        int iCnt = 0;
        if (dgvPTD.Rows[iCnt].Cells[0].Text != DBNull.Value.ToString())
        {
            //dtpRecievedOn.CustomFormat = "dd/MMM/yyyy";
            msk_dtpRecievedOn.Text = Convert.ToDateTime(dgvPTD.Rows[iCnt].Cells[0].Text).ToString("dd/MMM/yyyy");
        }
        else
        {
            msk_dtpRecievedOn.Text = "";
        }       

        if (dgvPTD.Rows[iCnt].Cells[3].Text.ToString() != "")
        {
            //dtpReview.CustomFormat = "dd/MMM/yyyy";
            msk_dtpRecievedOn.Text = Convert.ToDateTime(dgvPTD.Rows[iCnt].Cells[3].Text).ToString("dd/MMM/yyyy");
        }
        else
        {
            msk_dtpRecievedOn.Text = "";
        }     

        if (dgvPTD.Rows[iCnt].Cells[6].Text.ToString() != "")
        {
            //dtpFrwdDept.CustomFormat = "dd/MMM/yyyy";
            msk_dtpFrwdDept.Text = Convert.ToDateTime(dgvPTD.Rows[iCnt].Cells[6].Text).ToString("dd/MMM/yyyy");
        }
        else
        {
            msk_dtpFrwdDept.Text = "";
        }

        txtRemarks.Text = Convert.ToString(dgvPTD.Rows[iCnt].Cells[7].Text);

        lblDateID.Text = Convert.ToString(dgvPTD.Rows[iCnt].Cells[8].Text);
    }
    private void PopulateDropDownBox(DropDownList ddlBox, string sqlQuery, string valueMember, string displayName)
    {
        DataTable table = new DataTable();
        try
        {
            using (SqlConnection sqlConn = new SqlConnection(strConn))
            {
                using (SqlDataAdapter da = new SqlDataAdapter(sqlQuery, sqlConn))
                {
                    sqlConn.Open();
                    da.Fill(table);
                }
            }
            //cmbBox.Items.Add("Select");

            ddlBox.DataSource = table;
            ddlBox.DataTextField = displayName;
            ddlBox.DataValueField = valueMember;

            ddlBox.SelectedIndex = -1;
            ddlBox.DataBind();

            ddlBox.Items.Insert(0, new ListItem(""));
        }
        catch (System.Exception ex)
        {
            throw ex;
        }
    }
   

    // ======================================================    ====================================================================================================================


    protected void Tab1_Click(object sender, EventArgs e)
    {
        Tab1.CssClass = "Clicked";
        Tab2.CssClass = "Initial";
        Tab3.CssClass = "Initial";
        Tab4.CssClass = "Initial";
        MainView.ActiveViewIndex = 0;
    }

    protected void Tab2_Click(object sender, EventArgs e)
    {
        Tab1.CssClass = "Initial";
        Tab2.CssClass = "Clicked";
        Tab3.CssClass = "Initial";
        Tab4.CssClass = "Initial";
        MainView.ActiveViewIndex = 1;
    }

    protected void Tab3_Click(object sender, EventArgs e)
    {
        Tab1.CssClass = "Initial";
        Tab2.CssClass = "Initial";
        Tab3.CssClass = "Clicked";
        Tab4.CssClass = "Initial";
        MainView.ActiveViewIndex = 2;
    }

    protected void Tab4_Click(object sender, EventArgs e)
    {
        Tab1.CssClass = "Initial";
        Tab2.CssClass = "Initial";
        Tab3.CssClass = "Initial";
        Tab4.CssClass = "Clicked";
        MainView.ActiveViewIndex = 3;
    }

    private void GetStage2(string prjID)
    {
        string sqlQuery = "SELECT ts_receive_on, ts_issue_handling, ts_return_to_dept, ts_receive_from_dept, ts_pr_advertise, ts_tender_invitation, ts_closing_s1, ts_closing_s2, ts_modified_closing FROM   TenderDatesInfo  WHERE (stage_id = 2) AND (proj_id = @prjID) AND (ts_tender_issue IS NULL)";

        SqlConnection objCon = new SqlConnection(strConn);
        objCon.Open();
        SqlCommand sqlCom = new SqlCommand(sqlQuery, objCon);

        sqlCom.CommandType = System.Data.CommandType.Text;
        sqlCom.CommandText = sqlQuery;
        sqlCom.Parameters.AddWithValue("@prjID", prjID);

        SqlDataAdapter da = new SqlDataAdapter(sqlCom);

        System.Data.DataSet ds = new System.Data.DataSet();
        da.Fill(ds);

        //grvStage3.DataSource = ds.Tables[0];
        //grvStage3.DataBind();

    }
    private void GetStage3(string prjID)
    {
        string sqlQuery = "SELECT eval_tender_opening, eval_tech_sent1, eval_tech_receive1, eval_com_sent1, eval_com_receive1, eval_tender_award_approval, remarks FROM  TenderDatesInfo WHERE (stage_id = 3) AND (proj_id = @prjID)";

        SqlConnection objCon = new SqlConnection(strConn);
        objCon.Open();
        SqlCommand sqlCom = new SqlCommand(sqlQuery, objCon);

        sqlCom.CommandType = System.Data.CommandType.Text;
        sqlCom.CommandText = sqlQuery;
        sqlCom.Parameters.AddWithValue("@prjID", prjID);

        SqlDataAdapter da = new SqlDataAdapter(sqlCom);

        System.Data.DataSet ds = new System.Data.DataSet();
        da.Fill(ds);

        //grvStage3.DataSource = ds.Tables[0];
        //grvStage3.DataBind();

    }
    protected void btnStage1_Click(object sender, EventArgs e)
    {
        if (lblDateID.Text != "")
        {
            //Update_Stage1();
        }
        else
        {
            int dateID = clsStage1.MaxDateID();
            InsertTenderPreparationInfo(dateID);
        }
    }
    protected void btnHome_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/Guest/Default9.aspx", false); 
    }




    #region Stage2_Data


    private void Stage2_Data()
    {
        GetStage2(Session["PrjID"].ToString());

        int _bidCnt = GetbidderCount(Convert.ToInt32(Session["PrjID"].ToString()));

        int _circularCnt = GetCircularCount(Convert.ToInt32(Session["PrjID"].ToString()));

        txt_bidders.Text = _bidCnt.ToString();
        txtCircular.Text = _circularCnt.ToString();

        FillProjectCostDetailsOfTenderStage();
    }
    private void FillProjectCostDetailsOfTenderStage()
    {
        string strQuery = "SELECT tender_bond,doc_fee FROM PROJECTCOST WHERE proj_id = " + Convert.ToInt16(lblProjID.Text) + " and Stage_id = 4";
        using (SqlConnection sqlCn = new SqlConnection(connStr))
        {
            sqlCn.Open();
            using (SqlCommand sqlCmd = new SqlCommand(strQuery, sqlCn))
            {
                sqlCmd.CommandTimeout = 80;
                using (SqlDataReader sqlDr = sqlCmd.ExecuteReader())
                {
                    if (sqlDr.HasRows)
                    {
                        while (sqlDr.Read())
                        {
                            if (sqlDr[0].ToString() != "")
                            {
                                txtTenderBond.Text = string.Format("{0:#,##0.00}", double.Parse((sqlDr[0]).ToString()));
                            }
                            if (sqlDr[1].ToString() != "")
                            {
                                txtDocumentFee.Text = string.Format("{0:#,##0.00}", double.Parse((sqlDr[1]).ToString())); //Convert.ToDouble(sqlDr[1]).ToString();
                            }
                        }
                    }
                }
            }
            sqlCn.Close();
        }
    }
    public int GetCircularCount(int prjId)
    {
        int circularCnt = 0;
        try
        {    
            using (SqlConnection sqlConn = new SqlConnection(connStr))
            {
                string sqlquery = "SELECT CircularNo FROM DOCUMENTS WHERE (doc_type_id = 2) and stage_id=2 AND (proj_id = " + prjId + ") and (CircularNo is not NULL) and (date_id IS NULL)";          
                //circularCnt = dalObj.GetDataFromDB("DocCount", sqlquery).Rows.Count;
                sqlConn.Open();

                SqlCommand cmd = new SqlCommand(sqlquery, sqlConn);
                cmd.CommandTimeout = 80;
                circularCnt = Convert.ToInt16(cmd.ExecuteScalar());
             }
        }
        catch (Exception ex)
        {
            return circularCnt;
        }
        finally
        {
        }
        return circularCnt;
    }
    public int GetbidderCount(int prjId)
    {
        Int16 bidCnt = 0;
        try
        {
            using (SqlConnection sqlConn = new SqlConnection(connStr))
            {
                sqlConn.Open();
                // Modified by Varun
                string sqlquery = "SELECT COUNT(ts_tender_issue) AS Expr1 FROM TenderDatesInfo WHERE (proj_id = " + prjId + ") and stage_id=2 and Tender_Issued=1"; //(ts_tender_issue IS NOT NULL) AND 
                SqlCommand cmd = new SqlCommand(sqlquery, sqlConn);
                cmd.CommandTimeout = 80;
                bidCnt = Convert.ToInt16(cmd.ExecuteScalar());
            }
        }
        catch (Exception ex)
        {
            return bidCnt;
        }
        finally
        {
        }
        return bidCnt;
    }

    private Boolean FillTenderStageInfo(ref int dateiDofTS, ref string mdfExistDate)
    {
        Boolean statusChk = false;

        string strQuery = "SELECT  ts_receive_on,ts_issue_handling, ts_return_to_dept, ts_receive_from_dept, ts_pr_advertise, ts_tender_invitation, ts_closing_s1, ts_closing_s2, " +
        " ts_modified_closing,ts_modified_closing_s2, date_id, proj_id, stage_id,remarks FROM TenderDatesInfo WHERE (proj_id = " + Convert.ToInt16(lblProjID.Text) + ") AND (stage_id = 2) AND (ts_tender_issue is null) AND (co_ID is NULL)";

        using (SqlConnection sqlCn = new SqlConnection(connStr))
        {
            sqlCn.Open();
            using (SqlCommand sqlCmd = new SqlCommand(strQuery, sqlCn))
            {
                sqlCmd.CommandTimeout = 80;
                using (SqlDataReader sqlDr = sqlCmd.ExecuteReader())
                {
                    if (sqlDr.HasRows)
                    {
                        statusChk = true;
                        while (sqlDr.Read())
                        {
                            if (sqlDr[0].ToString() != "")
                            {
                                DateTime dt_tsRecOn = Convert.ToDateTime(sqlDr[0].ToString());
                                msk_dtp_tsRecOn.Text = dt_tsRecOn.ToString("dd/MMM/yyyy");
                            }

                           // cmb_tstenderHandle.Text = sqlDr[1].ToString();  // By Sree

                            if (sqlDr[2].ToString() != "")
                            {
                                DateTime dt_tsReturnDept = Convert.ToDateTime(sqlDr[2].ToString());
                                msk_dtp_tsReturnDept.Text = dt_tsReturnDept.ToString("dd/MMM/yyyy");
                            }
                            if (sqlDr[3].ToString() != "")
                            {
                                DateTime dt_tsRecFromDept = Convert.ToDateTime(sqlDr[3].ToString());
                                msk_dtp_tsRecFromDept.Text = dt_tsRecFromDept.ToString("dd/MMM/yyyy");
                            }
                            if (sqlDr[4].ToString() != "")
                            {
                                DateTime dt_tsAdvertisement = Convert.ToDateTime(sqlDr[4].ToString());
                                msk_dtp_tsAdvertisement.Text = dt_tsAdvertisement.ToString("dd/MMM/yyyy");
                            }
                            if (sqlDr[5].ToString() != "")
                            {
                                DateTime dt_tsInvitation = Convert.ToDateTime(sqlDr[5].ToString());
                                msk_dtp_tsInvitation.Text = dt_tsInvitation.ToString("dd/MMM/yyyy");
                            }
                            if (sqlDr[6].ToString() != "")
                            {
                                DateTime dt_tsStage1 = Convert.ToDateTime(sqlDr[6].ToString());
                                msk_dtp_tsStage1.Text = dt_tsStage1.ToString("dd/MMM/yyyy");
                            }
                            if (sqlDr[7].ToString() != "")
                            {
                                msk_dtp_tsStage2.Text = Convert.ToDateTime(sqlDr[7]).ToString("dd/MMM/yyyy");
                            }
                            if (sqlDr[8].ToString() != "")
                            {
                                DateTime dt_tsModifiedDate = Convert.ToDateTime(sqlDr[8]);
                                msk_dtp_tsModifiedDate_Stage1.Text = dt_tsModifiedDate.ToString("dd/MMM/yyyy");
                                mdfExistDate = dt_tsModifiedDate.ToString("dd/MMM/yyyy");
                            }

                            if (sqlDr[9].ToString() != "")
                            {
                                msk_dtp_tsModifiedDate_Stage2.Text = Convert.ToDateTime(sqlDr[9]).ToString("dd/MMM/yyyy"); // dt_tsModifiedDate_S2.ToString("dd/MMM/yyyy");                                                                          
                            }
                            // cmb_tstenderHandle.Text = sqlDr[11].ToString();

                            txt_tsRemarks.Text = sqlDr[13].ToString();
                            dateiDofTS = Convert.ToInt16(sqlDr[12]);
                        }
                    }
                }
            }
            sqlCn.Close();
        }
        return statusChk;
    }

    #endregion




    #region Stage3_Data


    private void Stage3_Data()
    {
        GetTenderStageClosingDates();

        Get_original_TenderDates();

        FillCp_ContractsInformation();

        FillProjectCostDetailsOfTenderEvaluation();

        getBidders();
    }
    private void FillProjectCostDetailsOfTenderEvaluation()
    {
        string strQuery = "SELECT budgeted_cost,estimated_cost FROM PROJECTCOST WHERE proj_id = " + Convert.ToInt16(lblProjID.Text) + " and Stage_id = 4";
        using (SqlConnection sqlCn = new SqlConnection(connStr))
        {
            sqlCn.Open();
            using (SqlCommand sqlCmd = new SqlCommand(strQuery, sqlCn))
            {

                using (SqlDataReader sqlDr = sqlCmd.ExecuteReader())
                {
                    if (sqlDr.HasRows)
                    {
                        while (sqlDr.Read())
                        {
                            if (sqlDr[0].ToString() != "") //&& sqlDr[0].ToString() != "0.0000"
                            {
                                txtBudjetAmnt.Text = string.Format("{0:#,##0.00}", double.Parse(sqlDr[0].ToString())); //#,##0
                            }
                            else
                                txtBudjetAmnt.Text = "";

                            if (sqlDr[1].ToString() != "" && sqlDr[1].ToString() != "0.0000")
                            {
                                txtEstimatedAmnt.Text = string.Format("{0:#,##0.00}", double.Parse(sqlDr[1].ToString())); //#,##0
                            }
                            else
                                txtEstimatedAmnt.Text = "";

                        }
                    }
                }
            }
            sqlCn.Close();
        }
    }

    private void FillCp_ContractsInformation()
    {
       
        FillContractsGrid_TE(Convert.ToInt32(lblProjID.Text), 4);
        
    }
    public void FillContractsGrid_TE(int cp_prjiD, int statusID)
    {       
        string strQuery = "";

        strQuery = "SELECT CONTRACTORS.co_id,COMPANY.co_name, COMPANY_TYPE.co_type_name, CONTRACTORS.ContractAmount, " +
        " CONTRACTORS.cp_tender_award,CONTRACTORS.bidder_id, CONTRACTORS.proj_id,CONTRACTORS.contract_no FROM CONTRACTORS INNER JOIN COMPANY ON CONTRACTORS.co_id = COMPANY.co_id INNER JOIN COMPANY_TYPE ON COMPANY.co_type_id = COMPANY_TYPE.co_type_id " +
        " WHERE (CONTRACTORS.proj_id = " + cp_prjiD + ") AND (CONTRACTORS.stage_id = 4)";

        using (SqlConnection sqlCn = new SqlConnection(connStr))
        {
            sqlCn.Open();
            using (SqlCommand sqlCmd = new SqlCommand(strQuery, sqlCn))
            {
                sqlCmd.CommandTimeout = 80;
                SqlDataAdapter sqlda = new SqlDataAdapter(sqlCmd);
                DataSet ds = new DataSet();
                sqlda.Fill(ds);

              

                gvStudentList.DataSource = ds.Tables[0];
                gvStudentList.DataBind();

            }
            sqlCn.Close();
        }        
    }

    private void getBidders()
    {
        string strQuery = "";

        strQuery = "SELECT  TenderDatesInfo.co_id, TenderDatesInfo.employee_id, TenderDatesInfo.proj_id, TenderDatesInfo.stage_id, COMPANY.co_name, COMPANY.co_country, " +
                         " COMPANY.nationality, COMPANY.qatari_share,TenderDatesInfo.ts_tender_issue FROM   TenderDatesInfo INNER JOIN COMPANY ON TenderDatesInfo.co_id = COMPANY.co_id WHERE  (TenderDatesInfo.proj_id = " + Convert.ToInt16(lblProjID.Text) + ") ";

        using (SqlConnection sqlCn = new SqlConnection(connStr))
        {
            sqlCn.Open();
            using (SqlCommand sqlCmd = new SqlCommand(strQuery, sqlCn))
            {
                sqlCmd.CommandTimeout = 80;
                SqlDataAdapter sqlda = new SqlDataAdapter(sqlCmd);
                DataSet ds = new DataSet();
                sqlda.Fill(ds);               

                gvBidders.DataSource = ds.Tables[0];
                gvBidders.DataBind();

            }
            sqlCn.Close();
        }        

    }
    private Boolean FillTenderEvaluationInfo(ref int dateiDofTEA)
    {
        Boolean statusTEAChk = false;
        string strQuery = "SELECT eval_tender_opening,eval_tender_doc_receive_from_cd, eval_tech_sent1, eval_tech_receive1, eval_com_sent1, " +
        " eval_com_receive1, eval_tender_award_approval,tender_validity_ext1,tender_validity_ext2,tenderbond_validity_ext1,tenderbond_validity_ext2,date_id, proj_id, stage_id,eval_no_of_meetings,remarks,TPWD1,FPWD1,TPWD2,FPWD2, " +
        "eval_tech_sent2,eval_tech_receive2,eval_com_sent2,eval_com_receive2 FROM TenderDatesInfo WHERE (proj_id = " + Convert.ToInt16(lblProjID.Text) + ") AND (stage_id = 3)";

        using (SqlConnection sqlCn = new SqlConnection(connStr))
        {
            sqlCn.Open();
            using (SqlCommand sqlCmd = new SqlCommand(strQuery, sqlCn))
            {
                sqlCmd.CommandTimeout = 80;
                using (SqlDataReader sqlDr = sqlCmd.ExecuteReader())
                {

                    if (sqlDr.HasRows)
                    {
                        statusTEAChk = true;
                        while (sqlDr.Read())
                        {
                            if (sqlDr[3].ToString() != "")
                            {
                                DateTime dt_EA_daterec = Convert.ToDateTime(sqlDr[3].ToString());
                                msk_dtpFE_datesentfin1.Text = dt_EA_daterec.ToString("dd/MMM/yyyy");
                            }
                            else
                            {
                                msk_dtpFE_datesentfin1.Text = "";
                            }
                            if (sqlDr["eval_tech_receive2"].ToString() != "")
                            {
                                DateTime dt_EA_daterec2 = Convert.ToDateTime(sqlDr["eval_tech_receive2"].ToString());
                               // msk_dtpTE_daterec2.Text = dt_EA_daterec2.ToString("dd/MMM/yyyy");
                            }
                            else
                            {
                                // msk_dtpTE_daterec2.Text = "";
                            }
                            if (sqlDr[5].ToString() != "")
                            {
                                DateTime dt_EA_daterecFin = Convert.ToDateTime(sqlDr[5].ToString());
                                msk_dtpFE_daterecFin1.Text = dt_EA_daterecFin.ToString("dd/MMM/yyyy");
                            }
                            else
                            {
                                msk_dtpFE_daterecFin1.Text = "";
                            }
                            if (sqlDr["eval_com_receive2"].ToString() != "")
                            {
                                DateTime dt_EA_daterecFin2 = Convert.ToDateTime(sqlDr["eval_com_receive2"].ToString());
                                msk_dtpFE_daterecFin2.Text = dt_EA_daterecFin2.ToString("dd/MMM/yyyy");
                            }
                            else
                            {
                                msk_dtpFE_daterecFin2.Text = "";
                            }
                            if (sqlDr[2].ToString() != "")
                            {
                                DateTime dt_EA_datesent = Convert.ToDateTime(sqlDr[2].ToString());
                                msk_dtpTE_datesent1.Text = dt_EA_datesent.ToString("dd/MMM/yyyy");
                            }
                            else
                            {
                                msk_dtpTE_datesent1.Text = "";
                            }
                            if (sqlDr["eval_tech_sent2"].ToString() != "")
                            {
                                DateTime dt_EA_datesent2 = Convert.ToDateTime(sqlDr["eval_tech_sent2"].ToString());
                                txtTechEval1ProposedWorkDays.Text = dt_EA_datesent2.ToString("dd/MMM/yyyy");
                            }
                            else
                            {
                                txtTechEval1ProposedWorkDays.Text = "";
                            }
                            if (sqlDr[4].ToString() != "")
                            {
                                DateTime dt_EA_datesentfin = Convert.ToDateTime(sqlDr[4].ToString());
                                msk_dtpFE_datesentfin1.Text = dt_EA_datesentfin.ToString("dd/MMM/yyyy");
                            }
                            else
                            {
                                msk_dtpFE_datesentfin1.Text = "";
                            }
                            if (sqlDr["eval_com_sent2"].ToString() != "")
                            {
                                DateTime dt_EA_datesentfin2 = Convert.ToDateTime(sqlDr["eval_com_sent2"].ToString());
                                txtFinEval1ProposedWorkDays.Text = dt_EA_datesentfin2.ToString("dd/MMM/yyyy");
                            }
                            else
                            {
                                txtFinEval1ProposedWorkDays.Text = "";
                            }
                            if (sqlDr[1].ToString() != "")
                            {
                                DateTime dt_EA_recfromcd = Convert.ToDateTime(sqlDr[1].ToString());
                                msk_dtpEA_recfromcd.Text = dt_EA_recfromcd.ToString("dd/MMM/yyyy");
                            }
                            else
                            {
                                msk_dtpEA_recfromcd.Text = "";
                            }
                            if (sqlDr[0].ToString() != "")
                            {
                                DateTime dt_EA_reqdate = Convert.ToDateTime(sqlDr[0].ToString());
                                msk_dtpEA_reqdate.Text = dt_EA_reqdate.ToString("dd/MMM/yyyy");
                            }
                            else
                            {
                                msk_dtpEA_reqdate.Text = "";
                            }
                            if (sqlDr[6].ToString() != "")
                            {
                                DateTime dt_EA_apprDate = Convert.ToDateTime(sqlDr[6].ToString());
                                msk_dtpEA_apprDate0.Text = dt_EA_apprDate.ToString("dd/MMM/yyyy");
                            }
                            else
                            {
                                msk_dtpEA_apprDate0.Text = "";
                            }
                            if (isCpContractorSign == false)
                            {
                                if (sqlDr[7].ToString() != "")
                                {
                                    DateTime dt_TV_FEdate = Convert.ToDateTime(sqlDr[7].ToString());
                                    msk_dtpTV_FEdate.Text = dt_TV_FEdate.ToString("dd/MMM/yyyy");
                                }
                                else
                                {
                                    msk_dtpTV_FEdate.Text = "";
                                }
                                if (sqlDr[8].ToString() != "")
                                {
                                    DateTime dt_TV_SEdate = Convert.ToDateTime(sqlDr[8].ToString());
                                    msk_dtpTV_SEdate.Text = dt_TV_SEdate.ToString("dd/MMM/yyyy");
                                }
                                else
                                {
                                    msk_dtpTV_SEdate.Text = "";
                                }
                                if (sqlDr[9].ToString() != "")
                                {
                                    DateTime dt_TBV_FEdate = Convert.ToDateTime(sqlDr[9].ToString());
                                    msk_dtpTBV_FEdate.Text = dt_TBV_FEdate.ToString("dd/MMM/yyyy");
                                }
                                else
                                {
                                    msk_dtpTBV_FEdate.Text = "";
                                }
                                if (sqlDr[10].ToString() != "")
                                {
                                    DateTime dt_TBV_SEdate = Convert.ToDateTime(sqlDr[10].ToString());
                                    msk_dtpTBV_SEdate.Text = dt_TBV_SEdate.ToString("dd/MMM/yyyy");
                                }
                                else
                                {
                                    msk_dtpTBV_SEdate.Text = "";
                                }
                            }
                            else
                            {
                                msk_dtpTV_FEdate.Text = "";
                                msk_dtpTV_SEdate.Text = "";
                                msk_dtpTBV_FEdate.Text = "";
                                msk_dtpTBV_SEdate.Text = "";
                                txtTV_exipre.Text = "";
                                txtTBV_exipre.Text = "";
                            }
                            txtEA_Noofmeetings.Text = sqlDr[14].ToString();

                            txtTE_remarks.Text = sqlDr[15].ToString();

                            txtTechEval1ProposedWorkDays.Text = sqlDr[16].ToString();
                            txtTechEval1ProposedWorkDays.Text = sqlDr[17].ToString();
                            txtTechEval2ProposedWorkDays.Text = sqlDr["TPWD2"].ToString();
                            // txtFinEval2ProposedWorkDays.Text = sqlDr["FPWD2"].ToString();

                            dateiDofTEA = Convert.ToInt16(sqlDr[11].ToString());
                        }
                    }
                }
            }
            sqlCn.Close();
        }
        return statusTEAChk;
    }


    private void fillBidderInfo()
    {
       // grvBidders
    }

    int tndrDate_ID = 0;
    private void Get_original_TenderDates()
    {
        // if (msk_dtpTV_OrgDate.Text != "")

        DateTime? validityDate;
        validityDate = null;

        DateTime? bondValidityDate;
        bondValidityDate = null;

        using (SqlConnection sqlConn = new SqlConnection(connStr))
        {

            sqlConn.Open();
            SqlCommand sqlCom = new SqlCommand("SELECT org_tender_validity,org_tenderbond_validity,date_ID FROM TenderDatesInfo Where proj_id = " + lblProjID.Text + " and stage_id = 2 and ts_tender_issue is null", sqlConn);
            using (SqlDataReader sqlReader = sqlCom.ExecuteReader())
            {
                if (sqlReader.HasRows)
                {
                    while (sqlReader.Read())
                    {
                        if (sqlReader[0].ToString() != "")
                        {
                            validityDate = Convert.ToDateTime(sqlReader[0].ToString());
                            msk_dtpTV_OrgDate.Text = validityDate.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture);
                            //msk_dtpTV_FEdate.Text = dt_dtpEA_TV_FstExt.ToString("dd/MMM/yyyy");
                        }
                        if (sqlReader[1].ToString() != "")
                        {
                            bondValidityDate = Convert.ToDateTime(sqlReader[1].ToString());
                            msk_dtpTBV_OrgDate.Text = bondValidityDate.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture);
                        }

                        tndrDate_ID = Convert.ToInt16(sqlReader[2].ToString());
                    }
                }
            }
        }
        // Delete the code which will update the tender bond validity dates, because not required to retrieve and then update by Varun 5 Feb 2014

    }

    private void GetTenderStageClosingDates()
    {
        SqlConnection sqlConn = new SqlConnection(connStr);
        sqlConn.Open();
        SqlCommand sqlCom = new SqlCommand("SELECT ts_closing_s1,ts_closing_s2,ts_modified_closing,ts_modified_closing_s2 FROM TenderDatesInfo Where proj_id = " + lblProjID.Text + " and stage_id = 2 AND (ts_tender_issue IS NULL)", sqlConn);
        SqlDataReader sqlReader = sqlCom.ExecuteReader();
        if (sqlReader.HasRows)
        {
            sqlReader.Read();

            if (sqlReader[0].ToString() != "")
            {
                DateTime dt_dtpEA_stage1 = Convert.ToDateTime(sqlReader[0].ToString());
                msk_dtpEA_stage1.Text = dt_dtpEA_stage1.ToString("dd-MMM-yyyy", CultureInfo.InvariantCulture);
            }
            if (sqlReader[1].ToString() != "")
            {
                DateTime dt_dtpEA_stage2 = Convert.ToDateTime(sqlReader[1].ToString());
                msk_dtpEA_stage2.Text = dt_dtpEA_stage2.ToString("dd-MMM-yyyy", CultureInfo.InvariantCulture);
            }
            if (sqlReader[2].ToString() != "")
            {
                DateTime dt_dtpEA_closeDate = Convert.ToDateTime(sqlReader[2].ToString());
                //msk_dtpEA_closeDate.Text = dt_dtpEA_closeDate.ToString("dd-MMM-yyyy", CultureInfo.InvariantCulture);
            }
            if (sqlReader[3].ToString() != "")
            {
                DateTime dt_dtpEA_closeDate_s2 = Convert.ToDateTime(sqlReader[3].ToString());
                msk_dtpEA_closeDate_Stage2.Text = dt_dtpEA_closeDate_s2.ToString("dd-MMM-yyyy", CultureInfo.InvariantCulture);
            }
        }
        sqlReader.Close();
        sqlConn.Close();
    }

    clsTs_Stage clsForTS = new clsTs_Stage(_userName);

    bool isCpContractorSign = false;
    protected void msk_dtpTBV_FEdate_TextChanged(object sender, EventArgs e)
    {
        clsDatabase clsDB = new clsDatabase(ConfigurationManager.AppSettings["TCMSConnString"].ToString());
        clsDB.ConnectDB();
        if (clsDB.ExecuteReader1("select proj_id from PROJECTS where Tender_Status_id in(7,14,15) and proj_id=" + _projID))
            isCpContractorSign = true;
        clsDB.DisconnectDB();


        if (msk_dtpTBV_FEdate.Text != "")
        {
            if (ValidateDate(msk_dtpTBV_FEdate) == false)
            {
                msk_dtpTBV_FEdate.Text = "";
                msk_dtpTBV_FEdate.Focus();
                return;
            }
        }       

        if (msk_dtpTBV_FEdate.Text != "" && isCpContractorSign == false)

            if (msk_dtpTBV_SEdate.Text == "" & msk_dtpTBV_OrgDate.Text != "")
            {
                if (Convert.ToDateTime(msk_dtpTBV_OrgDate.Text) > Convert.ToDateTime(msk_dtpTBV_FEdate.Text))
                {
                   // MessageBox.Show("Extension Date Should be greater than Original Date");
                    msk_dtpTBV_FEdate.Text = "";
                    msk_dtpTBV_FEdate.Focus();
                    return;
                }
                if (msk_dtpTBV_FEdate.Text != "")
                {
                    int iDays = (Convert.ToDateTime(msk_dtpTBV_FEdate.Text) - System.DateTime.Now.Date).Days;
                    txtTBV_exipre.Text = iDays.ToString();
                }
            }
       
        if (msk_dtpTBV_SEdate.Text == "" && isCpContractorSign == false)
        {
            if (msk_dtpTBV_FEdate.Text != "")
            {
                int iDays = (Convert.ToDateTime(msk_dtpTBV_FEdate.Text) - System.DateTime.Now.Date).Days;
                txtTBV_exipre.Text = iDays.ToString();
            }
        }

        if (txtTBV_exipre.Text != "" && isCpContractorSign == false)
        {
            // clsForTS.UpdateTBV_FirstExtension(msk_dtpTBV_FEdate.Text, _projID, Convert.ToInt16(txtTBV_exipre.Text));     // by Sree
        }

    }

    public bool ValidateDate(Control ctrl)
    {
        return true;
        //if (string.IsNullOrEmpty(ctrl.Text))    // By Sree
        //{
        //    return false;
        //}
        //else
        //{
        //    return true;
        //}
    }
    #endregion



    protected void btnsave_Click(object sender, EventArgs e)
    {

    }
    protected void btnreset_Click(object sender, EventArgs e)
    {

    }
    protected void btnSearch_Click(object sender, EventArgs e)
    {

    }


    string _prjCode = string.Empty;
    string proj_Title = string.Empty;
   ////  int _projID = 0; // By Sree
    string ministryCode = string.Empty;
    string budjetRefNo = string.Empty;
    string provisionNo = string.Empty;
    string tenderStatus = string.Empty;
    string _cmtName = string.Empty;
    string _tndrType = string.Empty;
    string _fiscalYear = string.Empty;
    string _profileName = null;
    string mSelectedTab = null;
    string mCommitteeShortName = null;

    string _tndrTypeName = string.Empty;
    string _userDept = string.Empty;
    string _AffairsName = string.Empty;

    static short _commId = 0;

   // string _tndrType = string.Empty;

    private void FillProjectInfo()
    {
        try
        {
            ////   DAL dalObj = new DAL(); By Sree

            DAL dalObj = new DAL("");

            IEnumerable<object> iEnum = null;
            DataTable dtProject = dalObj.GetDataFromDB("Project", "SELECT proj_id,project_code,replace(project_newname_en,',',' ') as project_newname,tender_no,Ministry_Code,Budget_Reference_No," +
            "Provision_Number,committee_id,Affair_id,department_id,Tender_Status_id,FYID,tender_type_id from PROJECTS where proj_id=" + _projID);

            DataTable dtCommittee = dalObj.GetDataFromDB("Committee", "SELECT committee_id,committee_short_name,committee_name from Committee");

            DataTable dtAffairs = dalObj.GetDataFromDB("AFFAIRS", "SELECT Affair_id,Affairs_Name from AFFAIRS");

            DataTable dtDepartment = dalObj.GetDataFromDB("Department", "SELECT department_id,Department from Department");

            DataTable dtTenderTypes = dalObj.GetDataFromDB("TenderTypes", "SELECT tender_type_id,tender_type_name,tender_type_short_name from TenderTypes");

            DataTable dtTenderStatus = dalObj.GetDataFromDB("TenderStatus", "SELECT Tender_Status_id,Status_Name from TenderStatus");

            DataTable dtFiscalYear = dalObj.GetDataFromDB("FiscalYear", "SELECT FYID,FiscalYear from FiscalYear");

            iEnum = (from p in dtProject.AsEnumerable()
                     join cmt in dtCommittee.AsEnumerable() on p.Field<int>("committee_id") equals cmt.Field<int>("committee_id")
                     join tt in dtTenderTypes.AsEnumerable() on p.Field<int>("tender_type_id") equals tt.Field<int>("tender_type_id")
                     join fy in dtFiscalYear.AsEnumerable() on p.Field<int>("FYID") equals fy.Field<int>("FYID")
                     join ts in dtTenderStatus.AsEnumerable() on p.Field<int>("Tender_Status_id") equals ts.Field<int>("Tender_Status_id")
                     join dpt in dtDepartment.AsEnumerable() on p.Field<int>("department_id") equals dpt.Field<int>("department_id")
                     join aff in dtAffairs.AsEnumerable() on p.Field<int>("Affair_id") equals aff.Field<int>("Affair_id")
                     select new
                     {
                         ProjectId = p.Field<int>("proj_id"),
                         ProjectCode = p.Field<string>("project_code"),
                         ProjectTitle = p.Field<string>("project_newname"),
                         TenderNo = p.Field<string>("tender_no"),
                         CommitteeShortName = cmt.Field<string>("committee_short_name"),
                         CommitteeName = cmt.Field<string>("committee_name"),
                         FiscalYear = fy.Field<string>("FiscalYear"),
                         TenderTypeShortName = tt.Field<string>("tender_type_short_name"),
                         MinistryCode = p.Field<string>("Ministry_Code"),
                         BudgetReferenceNo = p.Field<string>("Budget_Reference_No"),
                         ProvisionNumber = p.Field<string>("Provision_Number"),
                         StatusName = ts.Field<string>("Status_Name"),
                         CommitteeId = p.Field<int>("committee_id"),
                         AffairsName = aff.Field<string>("Affairs_Name"),
                         UserDepartment = dpt.Field<string>("Department")
                     }).ToList(); // AsEnumerable();//.ToList();


            foreach (object drProj in iEnum)
            {
                //dr[1] = strProj;    //ProjectId
                _prjCode = drProj.ToString().Split(',')[1].Split('=')[1].Trim();  //ProjectId
                txtProjCode.Text = _prjCode;
                proj_Title = drProj.ToString().Split(',')[2].Split('=')[1].Trim();  //ProjectCode
                lblProjID.Text = drProj.ToString().Split(',')[0].Split('=')[1].Trim();
                txtproj.Text = drProj.ToString().Split(',')[2].Split('=')[1].Trim();
                txtTenderNo.Text = drProj.ToString().Split(',')[3].Split('=')[1].Trim();

                txtProvisionNo.Text = drProj.ToString().Split(',')[10].Split('=')[1].Trim().Replace(" ", "-").Replace("/", "-").Replace(".", "-").Trim();
                cmbMinistryCode.Text = drProj.ToString().Split(',')[8].Split('=')[1].Trim();
                cmbBudgetRef.Text = drProj.ToString().Split(',')[9].Split('=')[1].Trim();
                // Added by Varun on 3rd Nov 2015
                if (mSelectedTab != null)
                {
                    if (mSelectedTab == "Archives")
                    {
                        if (drProj.ToString().Split(',')[11].Split('=')[1].Trim() == "Cancelled" || drProj.ToString().Split(',')[11].Split('=')[1].Trim() == "Re-Tender" ||
                            drProj.ToString().Split(',')[11].Split('=')[1].Trim() == "Transferred To Other Committee" || drProj.ToString().Split(',')[11].Split('=')[1].Trim() == "On Hold")
                        {
                            txt_tsRemarks.Enabled = false;
                            txtTE_remarks.Enabled = false;
                        }
                    }
                }
                if (mSelectedTab != "Deleted Projects")
                    cmbTenderStatus.Text = drProj.ToString().Split(',')[11].Split('=')[1].Trim();
                else
                    cmbTenderStatus.Text = "Revert Deleted Project";
                _cmtName = drProj.ToString().Split(',')[4].Split('=')[1].Trim();
                _tndrType = drProj.ToString().Split(',')[7].Split('=')[1].Trim();
                _fiscalYear = drProj.ToString().Split(',')[6].Split('=')[1].Trim();
                if (txtTenderNo.Text != "")
                {
                   // //   btnAssignTender.Visible = false; // By Sree

                }
                _commId = Convert.ToSByte(drProj.ToString().Split(',')[12].Split('=')[1].Trim());
                _userDept = drProj.ToString().Split(',')[14].Split('=')[1].Replace('}', ' ').Trim();
                _AffairsName = drProj.ToString().Split(',')[13].Trim().Split('=')[1];

            }//For end

        } //Try End                            
        catch (Exception ex)
        {
            //// MessageBox.Show("Error While Reading Project Data" + ex.Message);
        }

    }





    IList<string> mUserRightsColl = new List<string>();
   

    bool isException = false;
    private void GenarateTenderNo()
    {
        if (mUserRightsColl.Contains("41"))    //      * Assign Tender No.
        {
            // MessageBox.Show("You have no privilege to assign Tender No. Please Contact system administrator.");
            return;
        }

        if (dgvPTD.Rows.Count == 0) //[0].Cells[0].Value == null
        {
            // MessageBox.Show("Document Received Date cannot be blank. Cannot Assign Tender Number");
            return;
        }
        else if (dgvPTD.Rows.Count != 0)
        {
           // var bindingSource = (BindingSource)dgvPTD.DataSource; // BY Sree

           // DataTable dtPTD = (DataTable)bindingSource.DataSource;

            //if (!(dtPTD.Rows[dtPTD.Rows.Count - 1]["TenderDocumentCurrentStatus"].ToString().ToLower().Equals("approved")) || dtPTD.Rows[dtPTD.Rows.Count - 1]["TenderDocumentCurrentStatus"].ToString().Trim().Equals(""))
            //{
            //    //// MessageBox.Show("You cannot assign Tender No. because Tender Document CurrentStatus in Prepare Document is not Approved");
            //    return;
            //}
        }
        try
        {
            // Test Email for checking the SMTP Server is up and running Added By Varun on 31st Jan 2016
            MailMessage mailMessage = new MailMessage();

            mailMessage.From = new MailAddress(ConfigurationManager.AppSettings["From"].ToString());
            mailMessage.To.Add(new MailAddress(ConfigurationManager.AppSettings["To"].ToString()));
            mailMessage.Subject = "Test TCMS Alert: Tender No. was going to be assigned";
            mailMessage.IsBodyHtml = true;

            mailMessage.Body = "<html><body><i style='font-family:Calibri; font-size:15'>Dear Sir/Madam,</i><br/><br/><i style='font-family:Calibri; font-size:15'>This is an automated alert from Tender & Contract Management System.</i><br/><br/><i style='font-family:Calibri;font-size:15'>" +
            "Please be noted that</i><i style='color:Maroon;font-family:Calibri; font-size:15'> New Tender No. </i><i style='font-family:Calibri; font-size:15'> has created and the details are as follows:-</i><br /><br />" +
            "<table style='width:80%' border='1'><tr><td align='center' colspan='2' style='background-color:Maroon;color:White;font-family:Calibri;font-size:18;font-weight:bold'>TENDER NO: </td>" +
            "</tr><tr><td style='background-color:#B58AA5;font-family:Calibri;font-size:15'><i>Project Code</i></td><td style='font-family:Calibri;font-size:15'>" + _prjCode + "</td></tr>" +
            "<tr><td style='background-color:#B58AA5;font-family:Calibri;font-size:15'><i>Project Title</i></td><td style='font-family:Calibri;font-size:15'>" + proj_Title + "</td></tr>" +
            "<tr><td style='background-color:#B58AA5;font-family:Calibri;font-size:15'><i>Type of Tender</i></td><td style='font-family:Calibri;font-size:15'>" + _tndrTypeName + "</td></tr>" +
            "<tr><td style='background-color:#B58AA5;font-family:Calibri;font-size:15'><i>Tender Committee</i></td><td style='font-family:Calibri;font-size:15'>" + _cmtName + "</td></tr>" +
            "<tr><td style='background-color:#B58AA5;font-family:Calibri;font-size:15'><i>Financial Year</i></td><td style='font-family:Calibri;font-size:15'>" + _fiscalYear + "</td></tr>" +       //+ "(" + _AffairsName + ")
            "<tr><td style='background-color:#B58AA5;font-family:Calibri;font-size:15'><i>User Dept.</i></td><td style='font-family:Calibri;font-size:15'>" + _userDept + " / " + _AffairsName + " </td></tr>" +
            "<tr><td style='background-color:#B58AA5;font-family:Calibri;font-size:15'><i>Date of Creation</i></td><td style='font-family:Calibri;font-size:15'>" + System.DateTime.Now + "</td></tr>" +
            "</table><br/><br/><div style='font-family:Calibri; font-size:15'>Best Regards,<br/>TCMS Team</div></body></html>";



            SmtpClient client = new SmtpClient();
            client.EnableSsl = true;
            //client.UseDefaultCredentials = true;
            client.Credentials = new System.Net.NetworkCredential(@"Ashghal\tcms", ConfigurationManager.AppSettings["emailPass"].ToString());
            ServicePointManager.ServerCertificateValidationCallback = delegate(object s, X509Certificate certificate, X509Chain chain, SslPolicyErrors sslPolicyErrors) { return true; };
            client.Host = ConfigurationManager.AppSettings["SmtpHostIP"].ToString();
            client.Port = Convert.ToInt32(ConfigurationManager.AppSettings["SmtpHostPort"]);
            client.Send(mailMessage);
            //SendEmail myAction = new SendEmail(SendCompletedCallback);
            //myAction.BeginInvoke(client, mailMessage, null, null);

        }
        catch (Exception ex)
        {
            // MessageBox.Show("Unable to assign Tender Number, Error occurred while sending the email notification to Tender Committee, Please inform them Personally", "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            isException = true;
        }

        if (isException == false)
        {
            UserList_ForAlert(1,"");
            if (isException == false)
            {
                if (emailIds.Length == 0)
                {
                    ////MessageBox.Show("Information for Tender No.assignment is required to be sent to a user who handles " + _cmtName + " projects, " +
                    ////  " but there is no identified user to receive the email. Please contact system administrator for information.");
                    return;
                }

              //  DialogResult dlgResult = DialogResult.No;
              //  dlgResult = MessageBox.Show("Do you want to create new Tender Number. ", "Assign Tender No.", MessageBoxButtons.YesNo);

              //  if (dlgResult.ToString() == "Yes") // By Sree
                {

                    string _prjCreaedOn = string.Empty;

                   CommonClass comCls = new CommonClass(_userName);

                   string strTenderNo = string.Empty;
                  //  string strTenderNo = comCls.AssignTenderNo(mUserRightsColl, _projID, _tndrType, txtProjCode.Text, txtproj.Text, 'A', null, null, ref _tndrTypeName, ref _userDept, ref _prjCreaedOn, ref _AffairsName);
                    // Added by Varun on 10 Feb 2014 for checking the exception occurence and to stop sending email alerts if there is a problem in assigning the Tender No.
                    if (!strTenderNo.Contains("Exception"))
                    {
                        if (strTenderNo != "")
                        {
                            ////btnAssignTender.Visible = false;
                            ////lblTenderNo.Visible = true;     // By Sree
                            txtTenderNo.Text = strTenderNo;
                            //txtTenderNo.Enabled = false;
                        }


                        //string DisplayName = ""; string Email = ""; string Department = ""; string Title = "";                         
                        // AlertOnNewTenderNo(tenderNo, _projID.ToString(), "New Project");

                        string fromUser = null;
                        fromUser = comCls.getUserEmailID(_userName);

                        try
                        {
                            //if (GetUserInformation4rmActiveDirectory(fromUser, "ashghal.gov.qa", ref user_DisplayName, ref user_Email, ref  user_Department, ref user_Title) == true)
                            //{
                            //foreach (string strname in userListColl)
                            //{
                            // if (GetUserInformation4rmActiveDirectory(strname, "ashghal.gov.qa", ref DisplayName, ref Email, ref  Department, ref Title) == true)

                            MailMessage mailMessage = new MailMessage();
                            //mailMessage.From = new MailAddress(ConfigurationManager.AppSettings["MailFrom"].ToString());

                            mailMessage.From = new MailAddress(ConfigurationManager.AppSettings["From"].ToString());
                            mailMessage.To.Add(emailIds.ToString() + fromUser); //.Substring(0, emailIds.ToString().Length - 1)
                            if (!_tndrType.Equals("PQ"))
                            {
                                mailMessage.Subject = "TCMS Alert: Tender No. " + strTenderNo + " was assigned";
                            }
                            else
                            {
                                mailMessage.Subject = "TCMS Alert: Pre-Qualification No. " + strTenderNo + " was assigned";
                            }
                            mailMessage.IsBodyHtml = true;

                            string emailBodyText = null;

                            emailBodyText = "<html><body><i style='font-family:Calibri; font-size:15'>Dear Sir/Madam,</i><br/><br/><i style='font-family:Calibri; font-size:15'>This is an automated alert from Tender & Contract Management System.</i><br/><br/><i style='font-family:Calibri;font-size:15'>";
                            if (!_tndrType.Equals("PQ") && !_tndrType.Equals("A"))
                            {
                                emailBodyText = emailBodyText + "Please be noted that</i><i style='color:Maroon;font-family:Calibri; font-size:15'> New Tender No. " + strTenderNo + "</i><i style='font-family:Calibri; font-size:15'> has created and the details are as follows:-</i><br /><br />";
                            }
                            else if (_tndrType.Equals("PQ"))
                            {
                                emailBodyText = emailBodyText + "Please be noted that</i><i style='color:Blue;font-family:Calibri; font-size:15'> New Pre-Qualification No. " + strTenderNo + "</i><i style='font-family:Calibri; font-size:15'> has created and the details are as follows:-</i><br /><br />";
                            }
                            else
                            {
                                emailBodyText = emailBodyText + "Please be noted that</i><i style='color:#1F4E79;font-family:Calibri; font-size:15'> New Tender No. " + strTenderNo + "</i><i style='font-family:Calibri; font-size:15'> has created and the details are as follows:-</i><br /><br />";
                            }

                            if (!_tndrType.Equals("PQ") && !_tndrType.Equals("A"))
                            {
                                emailBodyText = emailBodyText + "<table style='width:80%' border='1'><tr><td align='center' colspan='2' style='background-color:Maroon;color:White;font-family:Calibri;font-size:18;font-weight:bold'>TENDER No. : " + strTenderNo + "</td>" +
                                "</tr><tr><td style='background-color:#B58AA5;font-family:Calibri;font-size:15'><i>Project Code</i></td><td style='font-family:Calibri;font-size:15'>" + _prjCode + "</td></tr>" +
                                "<tr><td style='background-color:#B58AA5;font-family:Calibri;font-size:15'><i>Project Title</i></td><td style='font-family:Calibri;font-size:15'>" + proj_Title + "</td></tr>" +
                                "<tr><td style='background-color:#B58AA5;font-family:Calibri;font-size:15'><i>Type of Tender</i></td><td style='font-family:Calibri;font-size:15'>" + _tndrTypeName + "</td></tr>" +
                                "<tr><td style='background-color:#B58AA5;font-family:Calibri;font-size:15'><i>Tender Committee</i></td><td style='font-family:Calibri;font-size:15'>" + _cmtName + "</td></tr>" +
                                "<tr><td style='background-color:#B58AA5;font-family:Calibri;font-size:15'><i>Financial Year</i></td><td style='font-family:Calibri;font-size:15'>" + _fiscalYear + "</td></tr>" +       //+ "(" + _AffairsName + ")
                                "<tr><td style='background-color:#B58AA5;font-family:Calibri;font-size:15'><i>User Dept.</i></td><td style='font-family:Calibri;font-size:15'>" + _userDept + " / " + _AffairsName + " </td></tr>" +
                                "<tr><td style='background-color:#B58AA5;font-family:Calibri;font-size:15'><i>Date of Creation</i></td><td style='font-family:Calibri;font-size:15'>" + System.DateTime.Now + "</td></tr>" +
                                "</table>";

                            }
                            else if (_tndrType.Equals("PQ"))
                            {
                                emailBodyText = emailBodyText + "<table style='width:80%' border='1'><tr><td align='center' colspan='2' style='background-color:#A9A9A9;color:Black;font-family:Calibri;font-size:18;font-weight:bold'>PQ No. : " + strTenderNo + "</td>" +
                                "</tr><tr><td style='font-family:Calibri;font-size:15'><i>Project Code</i></td><td style='font-family:Calibri;font-size:15'>" + _prjCode + "</td></tr>" +
                                "<tr><td style='font-family:Calibri;font-size:15'><i>Project Title</i></td><td style='font-family:Calibri;font-size:15'>" + proj_Title + "</td></tr>" +
                                "<tr><td style='font-family:Calibri;font-size:15'><i>Tender Committee</i></td><td style='font-family:Calibri;font-size:15'>" + _cmtName + "</td></tr>" +
                                "<tr><td style='font-family:Calibri;font-size:15'><i>Financial Year</i></td><td style='font-family:Calibri;font-size:15'>" + _fiscalYear + "</td></tr>" +       //+ "(" + _AffairsName + ")
                                "<tr><td style='font-family:Calibri;font-size:15'><i>User Dept.</i></td><td style='font-family:Calibri;font-size:15'>" + _AffairsName + " </td></tr>" +
                                "<tr><td style='font-family:Calibri;font-size:15'><i>Date of Creation</i></td><td style='font-family:Calibri;font-size:15'>" + System.DateTime.Now + "</td></tr>" +
                                "</table>";
                            }
                            else
                            {
                                emailBodyText = emailBodyText + "<table style='width:80%' border='1'><tr><td align='center' colspan='2' style='background-color:#1F4E79;color:White;font-family:Calibri;font-size:18;font-weight:bold'>TENDER No. : " + strTenderNo + "</td>" +
                                "</tr><tr><td style='background-color:#B58AA5;font-family:Calibri;font-size:15'><i>Project Code</i></td><td style='font-family:Calibri;font-size:15'>" + _prjCode + "</td></tr>" +
                                "<tr><td style='background-color:#B58AA5;font-family:Calibri;font-size:15'><i>Project Title</i></td><td style='font-family:Calibri;font-size:15'>" + proj_Title + "</td></tr>" +
                                "<tr><td style='background-color:#B58AA5;font-family:Calibri;font-size:15'><i>Type of Tender</i></td><td style='font-family:Calibri;font-size:15'>" + _tndrTypeName + "</td></tr>" +
                                "<tr><td style='background-color:#B58AA5;font-family:Calibri;font-size:15'><i>Tender Committee</i></td><td style='font-family:Calibri;font-size:15'>" + _cmtName + "</td></tr>" +
                                "<tr><td style='background-color:#B58AA5;font-family:Calibri;font-size:15'><i>Financial Year</i></td><td style='font-family:Calibri;font-size:15'>" + _fiscalYear + "</td></tr>" +       //+ "(" + _AffairsName + ")
                                "<tr><td style='background-color:#B58AA5;font-family:Calibri;font-size:15'><i>User Dept.</i></td><td style='font-family:Calibri;font-size:15'>" + _userDept + " / " + _AffairsName + " </td></tr>" +
                                "<tr><td style='background-color:#B58AA5;font-family:Calibri;font-size:15'><i>Date of Creation</i></td><td style='font-family:Calibri;font-size:15'>" + System.DateTime.Now + "</td></tr>" +
                                "</table>";
                            }

                            emailBodyText = emailBodyText + "<br/><br/><div style='font-family:Calibri; font-size:15'>Best Regards,<br/>TCMS Team</div></body></html>";

                            mailMessage.Body = emailBodyText;
                            //mailMessage.Body = "This is an automated alert from TCMS." + "\n" + "\n" + "Project Code     : " + _prjCode + "\n" + "Project Title    : " + proj_Title + "\n" +   "Type of Tender   : " + _tndrTypeName + " " +
                            // "\n"  + "Tender Committee : " + _cmtName + " " +
                            // "\n" +  "User Department  : " + _userDept + " " +
                            // "\n" +  "Date Created     : " + System.DateTime.Now.ToString() + " " +
                            //" \n" +  "\n" + "Tender No. " + strTenderNo + " was assigned to above project.";

                            SmtpClient client = new SmtpClient();
                            client.EnableSsl = true;
                            //client.UseDefaultCredentials = true;
                            client.Credentials = new System.Net.NetworkCredential(@"Ashghal\tcms", ConfigurationManager.AppSettings["emailPass"].ToString());
                            ServicePointManager.ServerCertificateValidationCallback = delegate(object s, X509Certificate certificate, X509Chain chain, SslPolicyErrors sslPolicyErrors) { return true; };
                            client.Host = ConfigurationManager.AppSettings["SmtpHostIP"].ToString();
                            client.Port = Convert.ToInt32(ConfigurationManager.AppSettings["SmtpHostPort"]);
                            client.Send(mailMessage);
                            //SendEmail myAction = new SendEmail(SendCompletedCallback);
                            //myAction.BeginInvoke(client, mailMessage, null, null);

                            //}
                            //}
                            ////  MessageBox.Show("Tender Alert E-mail send to the users", "Create Tender Number");
                        }
                        catch (Exception ex)
                        {
                            //// MessageBox.Show("Exception occurred while sending the email notification to Tender Committee, Please inform them Personally", "Exception", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                        }
                    }
                    else
                    {
                        //// MessageBox.Show("Error occurred while assigning Tender Number", "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    }
                }
            }
        }
        isException = false;

    }

    StringBuilder emailIds = new StringBuilder();
    private void UserList_ForAlert(int categryID, string _cmtName)
    {

        //userListColl.Clear();
        try
        {
            using (SqlConnection sqlConn = new SqlConnection(strConn))
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    sqlConn.Open();

                    string sqlQuery = "SELECT DISTINCT EmailAlertRecipients.user_id, USERS.email_address, USERS.user_name, EmailAlertCategory.AlertCategory, EmailAlertRecipients.alert_cat_id, " +
                                         " Committee.committee_short_name FROM EmailAlertCategory INNER JOIN EmailAlertRecipients ON EmailAlertCategory.alert_cat_id = EmailAlertRecipients.alert_cat_id INNER JOIN " +
                                         " USERS ON EmailAlertRecipients.user_id = USERS.user_id INNER JOIN Committee ON EmailAlertRecipients.committee_id = Committee.committee_id " +
                                         " WHERE (EmailAlertRecipients.alert_cat_id = " + categryID + ") AND (USERS.email_address <> N'') AND (Committee.committee_short_name ='" + _cmtName + "')";

                    cmd.Connection = sqlConn;
                    cmd.CommandText = sqlQuery;
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        while (dr.Read())
                        {
                            emailIds.Append(dr[1].ToString() + ",");
                            //if (!userListColl.Contains(strData))                                    
                            //    userListColl.Add(strData);
                        }
                        dr.Close();
                    }
                }
            }
        }
        catch (Exception ex)
        {
            // MessageBox.Show("Error occurred while retrieving the email ids of a particular committee.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            isException = true;
        }
    }

    protected void btnHome_Click1(object sender, EventArgs e)
    {
        Response.Redirect("~/Guest/Default9.aspx", false); 
    }
    #region MyRegion

    private void Stage4()
    {
        FillContractsGrid(Convert.ToInt32(_projID));
    }
    public void FillContractsGrid(int cp_prjiD)
    {
        string strQuery = "";       
        
        strQuery = "SELECT        COMPANY.co_name, CONTRACTORS.ContractAmount, CONVERT(varchar, CONTRACTORS.cp_tender_award, 106) AS cp_tender_award, CONTRACTORS.StaffInCharge, " + 
                        " CONVERT(varchar, CONTRACTORS.cp_received_of_doc, 106) AS cp_received_of_doc, CONVERT(varchar, CONTRACTORS.cp_request_start_date, 106) " +
                        " AS cp_request_start_date, CONVERT(varchar, CONTRACTORS.cp_start_date_receive, 106) AS cp_start_date_receive, CONVERT(varchar, " + 
                        " CONTRACTORS.cp_notice_contractor_to_sign, 106) AS cp_notice_contractor_to_sign, CONVERT(varchar, CONTRACTORS.cp_due_date_pb, 106) AS cp_due_date_pb, " +
                        " CONTRACTORS.bidder_id, CONTRACTORS.proj_id, CONVERT(varchar, CONTRACTORS.cp_receive_dep_sent_prsd, 106) AS cp_receive_dep_sent_prsd, " + 
                        " CONVERT(varchar, CONTRACTORS.cp_receive_fd_commit, 106) AS cp_receive_fd_commit,  " +
                        " CONTRACTORS.cp_notice_contractor_to_sign AS Expr2, CONVERT(varchar, CONTRACTORS.cp_distribution, 106) AS cp_distribution,CONVERT(varchar, CONTRACTORS.cp_sent_fd_commit, 106) AS cp_sent_fd_commit, CONTRACTORS.Remarks " +
" FROM            CONTRACTORS INNER JOIN    COMPANY ON CONTRACTORS.co_id = COMPANY.co_id WHERE (CONTRACTORS.proj_ID = " + cp_prjiD + "  )  AND    (CONTRACTORS.stage_Id = 4) AND (CONTRACTORS.cp_tender_award IS NOT NULL)";

        using (SqlConnection sqlCn = new SqlConnection(connStr))
        {
            sqlCn.Open();            
            using (SqlCommand sqlCmd = new SqlCommand(strQuery, sqlCn))
            {
                SqlDataReader sqlReader = sqlCmd.ExecuteReader();

                while (sqlReader.Read())
                {
                  //  txtCntrName.Text = sqlReader["co_name"].ToString();
                    txtCntrAmount.Text = sqlReader["ContractAmount"].ToString();

                    txtTndrAwrd.Text = sqlReader["cp_tender_award"].ToString();

                    txtCntrAwardDoc.Text =  sqlReader["cp_tender_award"].ToString();

                    txtStaffIncharge.Text = sqlReader["StaffInCharge"].ToString();

                    txtCntrReqDeptToStart.Text = sqlReader["cp_request_start_date"].ToString();

                    

                    //txtCntrRecFromFinan.Text = sqlReader["ContractAmount"].ToString();
                   // txtCntrRemarks.Text = sqlReader["ContractAmount"].ToString();

                    txtCntrSignContract.Text = sqlReader["cp_notice_contractor_to_sign"].ToString();

                    txtCntrStartDt.Text = sqlReader["cp_request_start_date"].ToString();

                    txtCntrDueBondDt.Text = sqlReader["cp_due_date_pb"].ToString();

                    txtCntrFinanceCommitment.Text = sqlReader["cp_sent_fd_commit"].ToString();

                    txtCntrRecFromFinan.Text = sqlReader["cp_receive_fd_commit"].ToString();                    

                    txtCntrPRSDSign.Text = sqlReader["cp_receive_dep_sent_prsd"].ToString();

                    txtCntrDistribution.Text = sqlReader["cp_distribution"].ToString();

                    txtCntrRemarks.Text = sqlReader["Remarks"].ToString();
                }



                sqlReader.Close();                
            }
            sqlCn.Close();
        }       
    }
    #endregion



    protected void dgvPTD_SelectedIndexChanged(object sender, EventArgs e)
    {

    }


    protected void gvStudentList_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {

    }
    protected void btnStage3_Click(object sender, EventArgs e)
    {

    }

    private void WorkOrderData()
    {
        string strQuery = "";
        strQuery = "SELECT DISTINCT proj_id, workOrderNo, workOrderTitle, workOrderAmount, workOrderClosingDate, workOrderStatus FROM   WorkOrders WHERE proj_id = " + Convert.ToInt16(lblProjID.Text) + " ";

        using (SqlConnection sqlCn = new SqlConnection(connStr))
        {
            sqlCn.Open();
            using (SqlCommand sqlCmd = new SqlCommand(strQuery, sqlCn))
            {
                sqlCmd.CommandTimeout = 80;
                SqlDataAdapter sqlda = new SqlDataAdapter(sqlCmd);
                DataSet ds = new DataSet();
                sqlda.Fill(ds);

                gvWorkOrder.DataSource = ds.Tables[0];
                gvWorkOrder.DataBind();

            }

            sqlCn.Close();
        }     
    }
}