﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using Datalayer;

using System.Data.SqlClient;
using System.Configuration;

public partial class Guest_ViewProjects : System.Web.UI.Page
{
    
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {           
            string strQS = "SELECT Tender_Status_id,Status_Name from TenderStatus Order By Tender_Status_id";
            PopulateDropDownBox_TCMS(ddlDCU, strQS, "Tender_Status_id", "Status_Name");
        }
    }
    private void PopulateDropDownBox(DropDownList ddlBox, string sqlQuery, string valueMember, string displayName)
    {
        ddlBox.DataSource = new JobOrderData().FillDropdown(sqlQuery);
        ddlBox.DataTextField = displayName;
        ddlBox.DataValueField = valueMember;
        ddlBox.SelectedIndex = -1;
        ddlBox.DataBind();

        ListItem emptyItem = new ListItem("", "");
        ddlBox.Items.Insert(0, emptyItem);
    }
    private void PopulateDropDownBox_TCMS(DropDownList ddlBox, string sqlQuery, string valueMember, string displayName)
    {
        ddlBox.DataBound += new EventHandler(this.ddlBox_DataBound);
        ddlBox.DataSource = new JobOrderData().FillDropdown_TCMS(sqlQuery);
        ddlBox.DataTextField = displayName;
        ddlBox.DataValueField = valueMember;
        ddlBox.SelectedIndex = -1;
        ddlBox.DataBind();
    }
    protected void ddlBox_DataBound(object sender, EventArgs e)
    {
        DropDownList ddl = (DropDownList)sender;
        ListItem emptyItem = new ListItem("", "");
        ddl.Items.Insert(0, emptyItem);
    }
    private DataSet ViewProjectsLog()
    {
        DataSet ds = new DataSet();

        try
        {
            using (SqlConnection sqlConn = new SqlConnection())
            {
                sqlConn.ConnectionString = ConfigurationManager.ConnectionStrings["TCMSConn"].ConnectionString;
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = sqlConn;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "sp_GetProjectData";

                if (ddlDCU.SelectedIndex!=0)
                 cmd.Parameters.AddWithValue("@statusID",ddlDCU.SelectedValue);
                else
                 cmd.Parameters.AddWithValue("@statusID", DBNull.Value);

                using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                {
                    sqlConn.Open();
                    da.Fill(ds);
                }
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
        return ds;
    }
    private void BindData()
    {
       DataSet dSet = ViewProjectsLog();
       DataTable dt = dSet.Tables[0];

       gvProjectsView.DataSource = dt;
       gvProjectsView.DataBind();
    }
    protected void gvProjectsView_RowDataBound(object sender, GridViewRowEventArgs e)
    {

    }
    protected void gvProjectsView_RowCommand(object sender, GridViewCommandEventArgs e)
    {

    }
    protected void lnkJobOrderJobNo_Click()
    {

    }


    protected void ddlDCU_SelectedIndexChanged(object sender, EventArgs e)
    {
        int statusID = 0;
        statusID = Convert.ToInt32(ddlDCU.SelectedValue);
        BindData();
    }
}