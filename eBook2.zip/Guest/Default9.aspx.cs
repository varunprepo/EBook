﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;
using System.Drawing;

public partial class Guest_Default9 : System.Web.UI.Page
{
    string strConn = ConfigurationManager.ConnectionStrings["TCMSConn"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            getChart_ProjectStatusWise();

            getChart_ProjectTypeWise();

            getChart_DepartmentWise();

            getChart_ProjectTypeWise();

            getChart_TenderTypeWise();

            getChart_TenderStatusWise();

            getChart_CommeetteeWise();

            GetCompanyInfo(400);

            GetCompanyInfobyDates();

            projects_IntiateByYear("1");

            chart_projectsStatusWise("2");


            lblUser.Text = Session["UserDisplayName"].ToString();

            lblUserProfile.Text = Session["ProfileName"].ToString();

            getProjectStatus();

           // mUserRightsColl = userRightsCollPrjState;
        }
    }

    private void getChart_ProjectStatusWise()
    {
        DataSet dsDoc = new DataSet();

        string sqlQuery = null;

        sqlQuery = "SELECT  STAGES.Stage_Name AS PrjStatus, COUNT(PROJECTS.proj_id) AS PrjCnt FROM   PROJECTS INNER JOIN   STAGES ON PROJECTS.stage_id = STAGES.stage_id  WHERE  (YEAR(PROJECTS.create_date) = " + ddlYaer.SelectedItem.Text + ") GROUP BY STAGES.Stage_Name, YEAR(PROJECTS.create_date)";


        SqlDataAdapter daDoc = new SqlDataAdapter(sqlQuery, strConn);
        daDoc.Fill(dsDoc);
        if (dsDoc.Tables[0].Rows.Count != 0)
        {
            projectsStatusWise.DataSource = dsDoc.Tables[0].DefaultView;
            projectsStatusWise.Series["Series1"].XValueMember = "PrjStatus";
            projectsStatusWise.Series["Series1"].YValueMembers = "prjCnt";

            dsDoc.Tables.Clear();

            projectsStatusWise.ChartAreas[0].AxisX.MajorGrid.Enabled = false;
            projectsStatusWise.ChartAreas[0].AxisX.MinorGrid.Enabled = false;
            projectsStatusWise.ChartAreas[0].AxisY.MajorGrid.Enabled = false;
            projectsStatusWise.ChartAreas[0].AxisY.MinorGrid.Enabled = false;

            projectsStatusWise.ChartAreas[0].AxisX.LabelStyle.Angle = 30;
            projectsStatusWise.ChartAreas[0].AxisX.LabelStyle.ForeColor = Color.Maroon;

            projectsStatusWise.ChartAreas[0].AxisX.Interval = 1;
        }
    }


    private void getChart_ProjectTypeWise()
    {
        DataSet dsDoc = new DataSet();

        string sqlQuery = null;

        sqlQuery = "SELECT   COUNT(PROJECTS.proj_id) AS PrjCnt, ContractTypes.TypeofContract FROM   PROJECTS INNER JOIN  ContractTypes ON PROJECTS.contract_type_id = ContractTypes.contract_type_id " +
                "WHERE  (YEAR(PROJECTS.create_date) = " + ddlYaer.SelectedItem.Text + ") GROUP BY ContractTypes.TypeofContract, YEAR(PROJECTS.create_date)";

        SqlDataAdapter daDoc = new SqlDataAdapter(sqlQuery, strConn);
        daDoc.Fill(dsDoc);
        if (dsDoc.Tables[0].Rows.Count != 0)
        {
            projectTypeWise.DataSource = dsDoc.Tables[0].DefaultView;
            projectTypeWise.Series["Series1"].XValueMember = "TypeofContract";
            projectTypeWise.Series["Series1"].YValueMembers = "prjCnt";

            dsDoc.Tables.Clear();

            projectTypeWise.ChartAreas[0].AxisX.MajorGrid.Enabled = false;
            projectTypeWise.ChartAreas[0].AxisX.MinorGrid.Enabled = false;
            projectTypeWise.ChartAreas[0].AxisY.MajorGrid.Enabled = false;
            projectTypeWise.ChartAreas[0].AxisY.MinorGrid.Enabled = false;

            projectTypeWise.ChartAreas[0].AxisX.LabelStyle.Angle = 30;
            projectTypeWise.ChartAreas[0].AxisX.LabelStyle.ForeColor = Color.Maroon;

            projectTypeWise.ChartAreas[0].AxisX.Interval = 1;
        }
    }
    private void getChart_DepartmentWise()
    {
        DataSet dsDoc = new DataSet();

        string sqlQuery = null;
        sqlQuery = " SELECT        COUNT(PROJECTS.proj_id) AS PrjCnt, Department.Department FROM    PROJECTS INNER JOIN    Department ON PROJECTS.department_id = Department.department_id " +
              " WHERE        (YEAR(PROJECTS.create_date) = " + ddlYaer.SelectedItem.Text + ") GROUP BY YEAR(PROJECTS.create_date), Department.Department ";

        SqlDataAdapter daDoc = new SqlDataAdapter(sqlQuery, strConn);
        daDoc.Fill(dsDoc);
        if (dsDoc.Tables[0].Rows.Count != 0)
        {
            projectDepartmentWise.DataSource = dsDoc.Tables[0].DefaultView;
            projectDepartmentWise.Series["Series1"].XValueMember = "Department";
            projectDepartmentWise.Series["Series1"].YValueMembers = "prjCnt";

            dsDoc.Tables.Clear();

            projectDepartmentWise.ChartAreas[0].AxisX.MajorGrid.Enabled = false;
            projectDepartmentWise.ChartAreas[0].AxisX.MinorGrid.Enabled = false;
            projectDepartmentWise.ChartAreas[0].AxisY.MajorGrid.Enabled = false;
            projectDepartmentWise.ChartAreas[0].AxisY.MinorGrid.Enabled = false;

            projectDepartmentWise.ChartAreas[0].AxisX.LabelStyle.Angle = 30;
            projectDepartmentWise.ChartAreas[0].AxisX.LabelStyle.ForeColor = Color.Maroon;

            projectDepartmentWise.ChartAreas[0].AxisX.Interval = 1;
        }
    }
    private void getChart_TenderTypeWise()
    {
        DataSet dsDoc = new DataSet();

        string sqlQuery = null;
        sqlQuery = "  SELECT   COUNT(PROJECTS.proj_id) AS PrjCnt, TenderTypes.tender_type_name FROM    PROJECTS INNER JOIN   TenderTypes ON PROJECTS.tender_type_id = TenderTypes.tender_type_id " +
                     " WHERE   (YEAR(PROJECTS.create_date) = " + ddlYaer.SelectedItem.Text + ") GROUP BY YEAR(PROJECTS.create_date), TenderTypes.tender_type_name ";

        SqlDataAdapter daDoc = new SqlDataAdapter(sqlQuery, strConn);
        daDoc.Fill(dsDoc);
        if (dsDoc.Tables[0].Rows.Count != 0)
        {
            chartTenderTypes.DataSource = dsDoc.Tables[0].DefaultView;
            chartTenderTypes.Series["Series1"].XValueMember = "tender_type_name";
            chartTenderTypes.Series["Series1"].YValueMembers = "prjCnt";

            dsDoc.Tables.Clear();

            chartTenderTypes.ChartAreas[0].AxisX.MajorGrid.Enabled = false;
            chartTenderTypes.ChartAreas[0].AxisX.MinorGrid.Enabled = false;
            chartTenderTypes.ChartAreas[0].AxisY.MajorGrid.Enabled = false;
            chartTenderTypes.ChartAreas[0].AxisY.MinorGrid.Enabled = false;

            chartTenderTypes.ChartAreas[0].AxisX.LabelStyle.Angle = 30;
            chartTenderTypes.ChartAreas[0].AxisX.LabelStyle.ForeColor = Color.Maroon;

            chartTenderTypes.ChartAreas[0].AxisX.Interval = 1;
        }
    }
    private void getChart_TenderStatusWise()
    {


        DataSet dsDoc = new DataSet();

        string sqlQuery = null;
        sqlQuery = "SELECT        COUNT(PROJECTS.proj_id) AS PrjCnt, TenderStatus.Status_Name FROM PROJECTS INNER JOIN TenderStatus ON PROJECTS.Tender_Status_id = TenderStatus.Tender_Status_id" +
                    " WHERE        (YEAR(PROJECTS.create_date) = " + ddlYaer.SelectedItem.Text + ") GROUP BY YEAR(PROJECTS.create_date), TenderStatus.Status_Name";

        SqlDataAdapter daDoc = new SqlDataAdapter(sqlQuery, strConn);
        daDoc.Fill(dsDoc);
        if (dsDoc.Tables[0].Rows.Count != 0)
        {
            chartStatus.DataSource = dsDoc.Tables[0].DefaultView;
            chartStatus.Series["Series1"].XValueMember = "Status_Name";
            chartStatus.Series["Series1"].YValueMembers = "prjCnt";

            dsDoc.Tables.Clear();

            chartStatus.ChartAreas[0].AxisX.MajorGrid.Enabled = false;
            chartStatus.ChartAreas[0].AxisX.MinorGrid.Enabled = false;
            chartStatus.ChartAreas[0].AxisY.MajorGrid.Enabled = false;
            chartStatus.ChartAreas[0].AxisY.MinorGrid.Enabled = false;

            chartStatus.ChartAreas[0].AxisX.LabelStyle.Angle = 30;
            chartStatus.ChartAreas[0].AxisX.LabelStyle.ForeColor = Color.Maroon;

            chartStatus.ChartAreas[0].AxisX.Interval = 1;
        }
    }
    private void getChart_CommeetteeWise()
    {
        DataSet dsDoc = new DataSet();
        string sqlQuery = null;
        sqlQuery = "SELECT        COUNT(PROJECTS.proj_id) AS PrjCnt, Committee.committee_name FROM            PROJECTS INNER JOIN   Committee ON PROJECTS.committee_id = Committee.committee_id " +
              " WHERE        (YEAR(PROJECTS.create_date) = " + ddlYaer.SelectedItem.Text + ") GROUP BY YEAR(PROJECTS.create_date), Committee.committee_name";

        SqlDataAdapter daDoc = new SqlDataAdapter(sqlQuery, strConn);
        daDoc.Fill(dsDoc);
        if (dsDoc.Tables[0].Rows.Count != 0)
        {
            chartCommeetee.DataSource = dsDoc.Tables[0].DefaultView;
            chartCommeetee.Series["Series1"].XValueMember = "committee_name";
            chartCommeetee.Series["Series1"].YValueMembers = "prjCnt";

            dsDoc.Tables.Clear();

            chartCommeetee.ChartAreas[0].AxisX.MajorGrid.Enabled = false;
            chartCommeetee.ChartAreas[0].AxisX.MinorGrid.Enabled = false;
            chartCommeetee.ChartAreas[0].AxisY.MajorGrid.Enabled = false;
            chartCommeetee.ChartAreas[0].AxisY.MinorGrid.Enabled = false;

            chartCommeetee.ChartAreas[0].AxisX.LabelStyle.Angle = 30;
            chartCommeetee.ChartAreas[0].AxisX.LabelStyle.ForeColor = Color.Maroon;

            chartCommeetee.ChartAreas[0].AxisX.Interval = 1;
        }
    }
    private void getChart_BidderWise()
    {
        DataSet dsDoc = new DataSet();
        string sqlQuery = null;

        if (ddlYaer.SelectedIndex == 0)
        {
            sqlQuery = "SELECT    COUNT(PROJECTS.proj_id) AS PrjCnt, CONTRACTORS.co_id, COMPANY.co_name FROM   PROJECTS INNER JOIN   CONTRACTORS ON PROJECTS.proj_id = CONTRACTORS.proj_id INNER JOIN " +
                         " COMPANY ON CONTRACTORS.co_id = COMPANY.co_id  GROUP BY CONTRACTORS.co_id, COMPANY.co_name  HAVING  (COUNT(PROJECTS.proj_id) > 20)";
        }
        else
        {

            sqlQuery = "SELECT     Top 9   COUNT(PROJECTS.proj_id) AS PrjCnt, CONTRACTORS.co_id, COMPANY.co_name FROM    PROJECTS INNER JOIN   CONTRACTORS ON PROJECTS.proj_id = CONTRACTORS.proj_id INNER JOIN " +
                             " COMPANY ON CONTRACTORS.co_id = COMPANY.co_id  WHERE (YEAR(PROJECTS.create_date) = " + ddlYaer.SelectedItem.Text + ") GROUP BY YEAR(PROJECTS.create_date), CONTRACTORS.co_id, COMPANY.co_name HAVING (COUNT(PROJECTS.proj_id) > 2)";
        }
        SqlDataAdapter daDoc = new SqlDataAdapter(sqlQuery, strConn);
        daDoc.Fill(dsDoc);
        if (dsDoc.Tables[0].Rows.Count != 0)
        {
            chartBiddersAward.DataSource = dsDoc.Tables[0].DefaultView;
            chartBiddersAward.Series["Series1"].XValueMember = "co_name";
            chartBiddersAward.Series["Series1"].YValueMembers = "prjCnt";

            dsDoc.Tables.Clear();

            chartBiddersAward.ChartAreas[0].AxisX.MajorGrid.Enabled = false;
            chartBiddersAward.ChartAreas[0].AxisX.MinorGrid.Enabled = false;
            chartBiddersAward.ChartAreas[0].AxisY.MajorGrid.Enabled = false;
            chartBiddersAward.ChartAreas[0].AxisY.MinorGrid.Enabled = false;

            chartBiddersAward.ChartAreas[0].AxisX.LabelStyle.Angle = 30;
            chartBiddersAward.ChartAreas[0].AxisX.LabelStyle.ForeColor = Color.Maroon;

            chartBiddersAward.ChartAreas[0].AxisX.Interval = 1;
        }
    }
    private void getChart_AwardAmountWise()
    {
        DataSet dsDoc = new DataSet();
        string sqlQuery = null;

        if (ddlYaer.SelectedIndex == 0)
        {
            sqlQuery = "SELECT        SUM(CONTRACTORS.ContractAmount) AS AwardAmount, Committee.committee_name FROM   PROJECTS INNER JOIN   CONTRACTORS ON PROJECTS.proj_id = CONTRACTORS.proj_id INNER JOIN " +
                        " Committee ON PROJECTS.committee_id = Committee.committee_id GROUP BY Committee.committee_name";
        }
        else
        {
            sqlQuery = "SELECT        SUM(CONTRACTORS.ContractAmount) AS AwardAmount, Committee.committee_name FROM   PROJECTS INNER JOIN   CONTRACTORS ON PROJECTS.proj_id = CONTRACTORS.proj_id INNER JOIN " +
                        " Committee ON PROJECTS.committee_id = Committee.committee_id WHERE (YEAR(PROJECTS.create_date) = " + ddlYaer.SelectedItem.Text + ") GROUP BY Committee.committee_name";
           
        }
        SqlDataAdapter daDoc = new SqlDataAdapter(sqlQuery, strConn);
        daDoc.Fill(dsDoc);
        if (dsDoc.Tables[0].Rows.Count != 0)
        {
            chartBiddersAward.DataSource = dsDoc.Tables[0].DefaultView;
            chartBiddersAward.Series["Series1"].XValueMember = "committee_name";
            chartBiddersAward.Series["Series1"].YValueMembers = "AwardAmount";

            dsDoc.Tables.Clear();

            chartBiddersAward.ChartAreas[0].AxisX.MajorGrid.Enabled = false;
            chartBiddersAward.ChartAreas[0].AxisX.MinorGrid.Enabled = false;
            chartBiddersAward.ChartAreas[0].AxisY.MajorGrid.Enabled = false;
            chartBiddersAward.ChartAreas[0].AxisY.MinorGrid.Enabled = false;

            chartBiddersAward.ChartAreas[0].AxisX.LabelStyle.Angle = 30;
            chartBiddersAward.ChartAreas[0].AxisX.LabelStyle.ForeColor = Color.Maroon;

            chartBiddersAward.ChartAreas[0].AxisX.Interval = 1;
        }
    }
    private void getChart_StaffWise()
    {
        DataSet dsDoc = new DataSet();
        string sqlQuery = null;

        if (ddlYaer.SelectedIndex == 0)
        {
            sqlQuery = "SELECT    ptd_assign_qs, COUNT(*) AS jCnt FROM   TenderDatesInfo WHERE    (stage_id = 1) AND (ptd_qs_working_status = N'On-going') GROUP BY ptd_assign_qs, ptd_purpose HAVING  (ptd_purpose = N'Preparation')";
        }
        else
        {
            sqlQuery= "SELECT  ptd_assign_qs, COUNT(*) AS jCnt FROM   TenderDatesInfo WHERE    (stage_id = 1) AND (ptd_qs_working_status = N'On-going') GROUP BY ptd_assign_qs, ptd_purpose HAVING  (ptd_purpose = N'Preparation') ";
                    

        }
        SqlDataAdapter daDoc = new SqlDataAdapter(sqlQuery, strConn);
        daDoc.Fill(dsDoc);
        if (dsDoc.Tables[0].Rows.Count != 0)
        {
            chartBiddersAward.DataSource = dsDoc.Tables[0].DefaultView;
            chartBiddersAward.Series["Series1"].XValueMember = "ptd_assign_qs";
            chartBiddersAward.Series["Series1"].YValueMembers = "jCnt";

            dsDoc.Tables.Clear();

            chartBiddersAward.ChartAreas[0].AxisX.MajorGrid.Enabled = false;
            chartBiddersAward.ChartAreas[0].AxisX.MinorGrid.Enabled = false;
            chartBiddersAward.ChartAreas[0].AxisY.MajorGrid.Enabled = false;
            chartBiddersAward.ChartAreas[0].AxisY.MinorGrid.Enabled = false;

            chartBiddersAward.ChartAreas[0].AxisX.LabelStyle.Angle = 30;
            chartBiddersAward.ChartAreas[0].AxisX.LabelStyle.ForeColor = Color.Maroon;

            chartBiddersAward.ChartAreas[0].AxisX.Interval = 1;
        }
    }
    protected void ddlTeam_SelectedIndexChanged(object sender, EventArgs e)
    {
        
    }
    protected void ddlYaer_SelectedIndexChanged(object sender, EventArgs e)
    {
            if (ddlYaer.SelectedIndex!=0)
            {
                getChart_ProjectStatusWise();

                getChart_ProjectTypeWise();

                getChart_DepartmentWise();

                getChart_ProjectTypeWise();

                getChart_TenderTypeWise();

                getChart_TenderStatusWise();

                getChart_CommeetteeWise();

                getChart_BidderWise();

                getChart_AwardAmountWise();

                projects_IntiateByYear("1");

                   
            }
    }
    protected void ddlCompany_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlCompany.SelectedIndex!=0)
          GetCompanyInfo(1);
        else
          GetCompanyInfo(Convert.ToInt32(ddlCompany.SelectedValue));
    }
    private void GetCompanyInfo(int _cmpID)
    {
        string sqlQuery = "SELECT COMPANY.co_name, CONTRACTORS.contract_no, CONTRACTORS.ContractTitle, CONTRACTORS.ContractAmount, CONTRACTORS.cp_tender_award, " +
                         " CONTRACTORS.StartDate, CONTRACTORS.FinishDate  FROM COMPANY INNER JOIN  CONTRACTORS ON COMPANY.co_id = CONTRACTORS.co_id  WHERE (COMPANY.co_id = @cmpID)";

        SqlConnection objCon = new SqlConnection(strConn);
        objCon.Open();
        SqlCommand sqlCom = new SqlCommand(sqlQuery, objCon);

        sqlCom.CommandType = System.Data.CommandType.Text;
        sqlCom.CommandText = sqlQuery;
        sqlCom.Parameters.AddWithValue("@cmpID", _cmpID);

        SqlDataAdapter da = new SqlDataAdapter(sqlCom);
        System.Data.DataSet ds = new System.Data.DataSet();
        da.Fill(ds);

        grvCompany.DataSource = ds.Tables[0];
        grvCompany.DataBind();
    }
    private void GetCompanyInfobyDates()
    {       
        string sqlQuery = "SELECT    COMPANY.co_name, CONTRACTORS.contract_no, CONTRACTORS.ContractTitle, CONTRACTORS.ContractAmount, CONTRACTORS.cp_tender_award AS Award_Date, " +
                        " CONTRACTORS.StartDate, CONTRACTORS.FinishDate FROM COMPANY INNER JOIN CONTRACTORS ON COMPANY.co_id = CONTRACTORS.co_id WHERE (CONTRACTORS.cp_tender_award > '12/31/2017') AND (CONTRACTORS.cp_tender_award < '12/31/2018') ";


        SqlConnection objCon = new SqlConnection(strConn);
        objCon.Open();
        SqlCommand sqlCom = new SqlCommand(sqlQuery, objCon);

        sqlCom.CommandType = System.Data.CommandType.Text;
        sqlCom.CommandText = sqlQuery;

        //sqlCom.Parameters.AddWithValue("@cmpID", _cmpID);

        SqlDataAdapter da = new SqlDataAdapter(sqlCom);
        System.Data.DataSet ds = new System.Data.DataSet();
        da.Fill(ds);

        grvCompanyAwrd.DataSource = ds.Tables[0];
        grvCompanyAwrd.DataBind();
    }
    private void projects_IntiateByYear(string prjID)
    {
        //string sqlQuery = "SELECT  COUNT(proj_id) AS PrjCnt, YEAR(create_date) AS Year FROM   PROJECTS GROUP BY YEAR(create_date) ORDER BY Year";

        string sqlQuery = "SELECT COUNT(proj_id) AS PrjCnt, MONTH(create_date) AS Year FROM PROJECTS WHERE (YEAR(create_date) = 2019) GROUP BY MONTH(create_date)";

        // sqlQuery = "SELECT    COUNT(PROJECTS.proj_id) AS PrjCnt, Department.Department FROM  PROJECTS INNER JOIN   Department ON PROJECTS.department_id = Department.department_id " + 
        //" WHERE        (YEAR(PROJECTS.create_date) = 2018) GROUP BY Department.Department";


        //sqlQuery = "SELECT  COUNT(PROJECTS.proj_id) AS PrjCnt, TenderTypes.tender_type_name FROM  PROJECTS INNER JOIN " +
        //                 "TenderTypes ON PROJECTS.tender_type_id = TenderTypes.tender_type_id WHERE (YEAR(PROJECTS.create_date) = 2018) GROUP BY TenderTypes.tender_type_name";

        DataSet dsDoc = new DataSet();

        SqlDataAdapter daDoc = new SqlDataAdapter(sqlQuery, strConn);
        daDoc.Fill(dsDoc);
        if (dsDoc.Tables[0].Rows.Count != 0)
        {
            chartProjectWise.DataSource = dsDoc.Tables[0].DefaultView;
            chartProjectWise.Series["Series1"].XValueMember = "Year";
            chartProjectWise.Series["Series1"].YValueMembers = "prjCnt";

            dsDoc.Tables.Clear();

            chartProjectWise.ChartAreas[0].AxisX.MajorGrid.Enabled = false;
            chartProjectWise.ChartAreas[0].AxisX.MinorGrid.Enabled = false;
            chartProjectWise.ChartAreas[0].AxisY.MajorGrid.Enabled = false;
            chartProjectWise.ChartAreas[0].AxisY.MinorGrid.Enabled = false;

            chartProjectWise.ChartAreas[0].AxisX.LabelStyle.Angle = 30;
            chartProjectWise.ChartAreas[0].AxisX.LabelStyle.ForeColor = Color.Maroon;

            chartProjectWise.ChartAreas[0].AxisX.Interval = 1;
        }
    }

    private void chart_projectsTypeWise(string prjID)
    {
      string sqlQuery = "SELECT  COUNT(PROJECTS.proj_id) AS PrjCnt, TenderTypes.tender_type_name FROM  PROJECTS INNER JOIN " +
                        "TenderTypes ON PROJECTS.tender_type_id = TenderTypes.tender_type_id WHERE (YEAR(PROJECTS.create_date) = 2018) GROUP BY TenderTypes.tender_type_name";


      //string sqlQuery = "SELECT COUNT(PROJECTS.proj_id) AS PrjCnt, ContractTypes.TypeofContract FROM       PROJECTS INNER JOIN " +
      //                " ContractTypes ON PROJECTS.contract_type_id = ContractTypes.contract_type_id WHERE        (YEAR(PROJECTS.create_date) = 2018) GROUP BY ContractTypes.TypeofContract";

        DataSet dsDoc = new DataSet();

        SqlDataAdapter daDoc = new SqlDataAdapter(sqlQuery, strConn);
        daDoc.Fill(dsDoc);
        if (dsDoc.Tables[0].Rows.Count != 0)
        {
            chartPrjTypeWise.DataSource = dsDoc.Tables[0].DefaultView;
            chartPrjTypeWise.Series["Series1"].XValueMember = "tender_type_name";
            chartPrjTypeWise.Series["Series1"].YValueMembers = "prjCnt";

            dsDoc.Tables.Clear();

            chartPrjTypeWise.ChartAreas[0].AxisX.MajorGrid.Enabled = false;
            chartPrjTypeWise.ChartAreas[0].AxisX.MinorGrid.Enabled = false;
            chartPrjTypeWise.ChartAreas[0].AxisY.MajorGrid.Enabled = false;
            chartPrjTypeWise.ChartAreas[0].AxisY.MinorGrid.Enabled = false;

            chartPrjTypeWise.ChartAreas[0].AxisX.LabelStyle.Angle = 30;
            chartPrjTypeWise.ChartAreas[0].AxisX.LabelStyle.ForeColor = Color.Maroon;

            chartPrjTypeWise.ChartAreas[0].AxisX.Interval = 1;
        }
    }

    private void chart_projectsStatusWise(string prjID)
    { 
        string sqlQuery = "SELECT COUNT(PROJECTS.proj_id) AS PrjCnt, TenderStatus.Status_Name FROM PROJECTS INNER JOIN " + 
                        " TenderStatus ON PROJECTS.Tender_Status_id = TenderStatus.Tender_Status_id WHERE  (YEAR(PROJECTS.create_date) = 2018) GROUP BY TenderStatus.Status_Name";

        DataSet dsDoc = new DataSet();
        SqlDataAdapter daDoc = new SqlDataAdapter(sqlQuery, strConn);
        daDoc.Fill(dsDoc);
        if (dsDoc.Tables[0].Rows.Count != 0)
        {
            chartPrjStatusWise.DataSource = dsDoc.Tables[0].DefaultView;
            chartPrjStatusWise.Series["Series1"].XValueMember = "Status_Name";
            chartPrjStatusWise.Series["Series1"].YValueMembers = "prjCnt";

            dsDoc.Tables.Clear();

            chartPrjStatusWise.ChartAreas[0].AxisX.MajorGrid.Enabled = false;
            chartPrjStatusWise.ChartAreas[0].AxisX.MinorGrid.Enabled = false;
            chartPrjStatusWise.ChartAreas[0].AxisY.MajorGrid.Enabled = false;
            chartPrjStatusWise.ChartAreas[0].AxisY.MinorGrid.Enabled = false;

            chartPrjStatusWise.ChartAreas[0].AxisX.LabelStyle.Angle = 30;
            chartPrjStatusWise.ChartAreas[0].AxisX.LabelStyle.ForeColor = Color.Maroon;

            chartPrjStatusWise.ChartAreas[0].AxisX.Interval = 1;
        }
    }
    protected void btnSearch_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/Guest/ViewProjects.aspx", false);
    }
    protected void btnNewPrj_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/Guest/AddUpdateProject.aspx", false);
    }
    protected void chartStatus_Load(object sender, EventArgs e)
    {

    }
    protected void lnkLogOutBtn_Click(object sender, EventArgs e)
    {
        Session.Abandon();
     
        Response.Redirect("~/LoginPage.aspx", false);
    }
    protected void btnTndrNo_Click(object sender, EventArgs e)
    {

    }

   

    private void getProjectStatus()
    {
        string sqlQuery = "SELECT        TenderStatus.Status_Name, COUNT(PROJECTS.proj_id) AS PrjCnt FROM  PROJECTS INNER JOIN   TenderStatus ON PROJECTS.Tender_Status_id = TenderStatus.Tender_Status_id GROUP BY TenderStatus.Status_Name, TenderStatus.Tender_Status_id " +
                             " ORDER BY TenderStatus.Tender_Status_id";

        SqlConnection objCon = new SqlConnection(strConn);
        objCon.Open();
        SqlCommand sqlCom = new SqlCommand(sqlQuery, objCon);

        sqlCom.CommandType = System.Data.CommandType.Text;
        sqlCom.CommandText = sqlQuery;

        //sqlCom.Parameters.AddWithValue("@cmpID", _cmpID);

        SqlDataAdapter da = new SqlDataAdapter(sqlCom);
        System.Data.DataSet ds = new System.Data.DataSet();
        da.Fill(ds);

        grvPrjStatus.DataSource = ds.Tables[0];
        grvPrjStatus.DataBind();


    }


    protected void btnDele_Click(object sender, EventArgs e)
    {
        
    }
}