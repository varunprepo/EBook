﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Text;
using System.Web.UI.HtmlControls;

public partial class DocumetAttachments : System.Web.UI.Page
{
    private SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["EBSDEBookConn"].ConnectionString);
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            BindGridviewData();
        }
    }
    private void BindGridviewData()
    {
        con.Open();
        SqlCommand cmd = new SqlCommand("select  fileID, FileName, FilePath, docID from FilesTable where docID = " + Convert.ToInt32(Session["Dist_docID"]), con);
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        DataSet ds = new DataSet();
        da.Fill(ds);
        con.Close();
        gvDetails.DataSource = ds;
        gvDetails.DataBind();
    }
    protected void btnUpload_Click(object sender, EventArgs e)
    {
        string filename = Path.GetFileName(fileUpload1.PostedFile.FileName);
        fileUpload1.SaveAs(Server.MapPath("Files/" + filename));
        con.Open();
        SqlCommand cmd = new SqlCommand("insert into FilesTable(FileName,FilePath,docID) values(@Name,@Path,@docID)", con);
        cmd.Parameters.AddWithValue("@Name", filename);
        cmd.Parameters.AddWithValue("@Path", "Files/" + filename);
        cmd.Parameters.AddWithValue("@docID", Convert.ToInt32(Session["Dist_docID"]));
        cmd.ExecuteNonQuery();
        con.Close();
        BindGridviewData();
    }
    protected void lnkDownload_Click(object sender, EventArgs e)
    {
        LinkButton lnkbtn = sender as LinkButton;
        GridViewRow gvrow = lnkbtn.NamingContainer as GridViewRow;
        string filePath = gvDetails.DataKeys[gvrow.RowIndex].Value.ToString();

        filePath = filePath.Replace("C:", "E:");

        Response.ContentType = "image/jpg";
        Response.AddHeader("Content-Disposition", "attachment;filename=\"" + filePath + "\"");
        Response.TransmitFile(Server.MapPath(filePath));
        Response.End();
    }
    protected void lnkDelete_Click(object sender, EventArgs e)
    {
        try
        {

            LinkButton lnkJobID = (LinkButton)sender;
            GridViewRow gvr = (GridViewRow)lnkJobID.NamingContainer;
            //string filePath = ((HtmlGenericControl)gvr.FindControl("divFilePath")).InnerText;
            Response.ContentType = "image/jpg";

            //if (File.Exists(Server.MapPath(filePath)))    
            //    File.Delete(Server.MapPath(filePath));

            con.Open();
            SqlCommand cmd = new SqlCommand("Update FilesTable Set isFileActive = 0 where fileID =" + lnkJobID.ToolTip, con);
            cmd.ExecuteNonQuery();
            con.Close();

            BindGridviewData();
           
        }
        catch (Exception ex)
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Error occurred while processing the request')</script>", false);
        }        
    }
    protected void btnBack_Click(object sender, EventArgs e)
    {
       // this.ClientScript.RegisterClientScriptBlock(this.GetType(), "Close", "window.close()", true);

       // Response.Redirect("~/Documents/DocumetAttachments.aspx", false);
    }


    private void getData()
    {
        if (!IsPostBack)
        {
            using (SqlConnection scon = new SqlConnection())
            {
                using (SqlCommand scmd = new SqlCommand())
                {
                    string strQuery = "SELECT JobOwner.jobNo, JobStatus.jobStatusName, Section.sectionName, JobType.jobTypeName " +
                                " FROM   JobOwner INNER JOIN  JobStatus ON JobOwner.jobOwnerStatusID = JobStatus.jobStatusID INNER JOIN " +
                      " Section ON JobOwner.sectionID = Section.sectionID INNER JOIN JobType ON JobOwner.jobOwnerCatID = JobType.jobTypeID FULL OUTER JOIN " +
            " DocumentDistribution ON JobOwner.jobOwnerID = DocumentDistribution.jobOwnerID";

                    scmd.Connection = con;
                    scmd.CommandType = CommandType.Text;
                    scmd.CommandText = strQuery;
                    scon.Open();
                    SqlDataReader articleReader = scmd.ExecuteReader();

                    StringBuilder htmlTable = new StringBuilder();

                    htmlTable.Append("<table border='1'>");
                    htmlTable.Append("<tr><th>jobNo.</th><th>jobStatusName</th><th>sectionName</th><th>jobTypeName</th></tr>");

                    if (articleReader.HasRows)
                    {
                        while (articleReader.Read())
                        {
                            htmlTable.Append("<tr>");
                            htmlTable.Append("<td>" + articleReader["jobNo"] + "</td>");
                            htmlTable.Append("<td>" + articleReader["jobStatusName"] + "</td>");
                            htmlTable.Append("<td>" + articleReader["sectionName"] + "</td>");
                            htmlTable.Append("<td>" + articleReader["jobTypeName"] + "</td>");
                            htmlTable.Append("</tr>");
                        }
                        htmlTable.Append("</table>");

                       // PlaceHolder1.Controls.Add(new Literal { Text = htmlTable.ToString() });

                        articleReader.Close();
                        articleReader.Dispose();
                    }
                }
            }
        }
    }

   
    public void DeleteAttributeData(int attrID)
    {
        Response.ContentType = "image/jpg";
        //string filePath = gvDetails.DataKeys[gvrow.RowIndex].Value.ToString();
       

        SqlConnection sqlConn = new SqlConnection();
        string deleteQuery = "Update FilesTable Set isFileActive = 0 where fileID =" + attrID;
        try
        {
            sqlConn.Open();
            SqlCommand sqlCom = new SqlCommand(deleteQuery, con);
            sqlCom.ExecuteNonQuery();

            //if (File.Exists(filePath))
            //{
            //    File.Delete(filePath);
            //}

        }
        catch (Exception ex)
        {
            //Response.Write("Error getting while reading data !" + ex.Message);
        }
        finally
        {
            sqlConn.Close();
        }
    }



    //<asp:TemplateField HeaderText="Delete" ItemStyle-Width="65" HeaderStyle-Width="65" HeaderStyle-HorizontalAlign="Center">
    //    <ItemTemplate>
    //        <asp:LinkButton ID="btnDelete2" CommandName="DeleteDocid" CausesValidation="false"
    //            CssClass="btnEdit" CommandArgument='<%#Eval("fileID")%>' runat="server"
    //            ForeColor="red"> Delete </asp:LinkButton>
    //    </ItemTemplate>
    //    <HeaderStyle HorizontalAlign="Center" Width="65px"></HeaderStyle>
    //    <ItemStyle Width="65px"></ItemStyle>
    //</asp:TemplateField>
    protected void gvDetails_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandArgument != "")
        {
            int attributeID = Convert.ToInt32(e.CommandArgument);
            switch (e.CommandName)
            {
                case "DeleteDocid":
                    DeleteAttributeData(attributeID);
                    BindGridviewData();
                    break;
            }
        }
    }
}