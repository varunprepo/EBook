﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;


public partial class Guest_AddUpdateProject : System.Web.UI.Page
{
    string strCon = ConfigurationManager.ConnectionStrings["TCMSConn"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack == true)
        {
             PopulateDropDownBox(cmbNonMohUserDept, @"Select department_id,department_short_name,Department from Department", "department_id", "Department");          

             PopulateDropDownBox(cmbMozPrjID, @"SELECT moazanah_proj_id, moazanah_proj_id FROM MOAZANAH", "moazanah_proj_id", "moazanah_proj_id");

             PopulateDropDownBox(cmbNonMohAffairs, @"Select Affair_id,Affairs_Short_name,[Affairs_Name]as AffairName from AFFAIRS where isActive=1", "Affair_id", "AffairName");

             PopulateDropDownBox(cmbNonMohTenderCommittee, @"Select committee_id,committee_short_name,committee_name from Committee WHERE committee_id<>8", "committee_id", "committee_name");

             PopulateDropDownBox(cmbNonMohTypeOfTender, @"select tender_type_id,tender_type_short_name,[tender_type_name] as TenderTypeName from [TenderTypes] where tender_type_id <> 2 and tender_type_id <> 4", "tender_type_id", "TenderTypeName");

             PopulateDropDownBox(cmbNonMohFiscalYr, @"select FYID,[FiscalYear] as fiscalYear from [FiscalYear] ORDER BY FiscalYear", "FYID", "fiscalYear");

             PopulateDropDownBox(cmbMohTypeContract, @"select contract_type_id,type_short_name,[TypeofContract] as TypeOfContract from [ContractTypes]", "contract_type_id", "TypeOfContract");

             PopulateDropDownBox(cmbMozMinistryCode, @"SELECT Ministry_id,[MinistryCode] as MinistryCode FROM [MinistryCodes] where (MinistryCode is not NULL OR MinistryCode<>'') ORDER BY MinistryCode", "Ministry_id", "MinistryCode");

             PopulateDropDownBox(cmbMozBudjetRefNo, @"SELECT [BudgetRef_id] as BudRefID, [BudgetRefNumber] as BudgeRefCode FROM [BudgetReferenceCodes] ORDER BY BudgeRefCode", "BudRefID", "BudgeRefCode"); 
        }
    }
    private void PopulateDropDownBox(DropDownList ddlBox, string sqlQuery, string valueMember, string displayName)
    {
        DataTable table = new DataTable();
        try
        {
            using (SqlConnection sqlConn = new SqlConnection(strCon))
            {
                using (SqlDataAdapter da = new SqlDataAdapter(sqlQuery, sqlConn))
                {
                    sqlConn.Open();
                    da.Fill(table);
                }
            }
            
            ddlBox.DataSource = table;
            ddlBox.DataTextField = displayName;
            ddlBox.DataValueField = valueMember;

            ddlBox.SelectedIndex = -1;
            ddlBox.DataBind();

            ddlBox.Items.Insert(0, new ListItem(""));
        }
        catch (System.Exception ex)
        {
            throw ex;
        }
    }
    protected void btnStage2_Click(object sender, EventArgs e)
    {
        InsertNonMoazanahProj();
    }
    private void InsertNonMoazanahProj()
    {        
        try
        {
             using (SqlConnection sqlInnerConn = new SqlConnection(strCon))
             {
                    sqlInnerConn.Open();               

                    using (SqlCommand cmd = new SqlCommand())
                    {
                        cmd.CommandText = "TCM_CreateProject";
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Connection = sqlInnerConn;

                    //   cmd.Parameters.AddWithValue("@prjID", Convert.ToInt16(prjID)); 

                        cmd.Parameters.AddWithValue("@PrjCode", txtNonMohProjCode.Text);  //  .Text.Replace(" ", "").Trim()
                        cmd.Parameters.AddWithValue("@PrjTitleEnNew", txtNonMohProjTitleEn.Text); 
                        cmd.Parameters.AddWithValue("@CmtId", cmbNonMohTenderCommittee.SelectedValue); 

                        cmd.Parameters.AddWithValue("@FiscalID", cmbNonMohFiscalYr.SelectedValue); 
                        cmd.Parameters.AddWithValue("@AffairID", cmbNonMohAffairs.SelectedValue); 
                        cmd.Parameters.AddWithValue("@UserDept", cmbNonMohUserDept.SelectedValue); 
                        cmd.Parameters.AddWithValue("@TypeOfPrj", cmbMohTypeContract.SelectedValue); 
                        cmd.Parameters.AddWithValue("@TypeOfTndr", cmbNonMohTypeOfTender.SelectedValue); 

                        cmd.Parameters.AddWithValue("@PrjTitleEn", txtNonMohProjTitleEn.Text); 
                        cmd.Parameters.AddWithValue("@PrjTitleArb", txtNonMohProjTitleAr.Text); 

                        cmd.Parameters.AddWithValue("@StatusID", 1);
                        cmd.Parameters.AddWithValue("@SelPrj", 1);
                        cmd.Parameters.AddWithValue("@TndrStatusId", 1);

                        cmd.Parameters.AddWithValue("@MinistryCode", cmbMozMinistryCode.Text); 
                        cmd.Parameters.AddWithValue("@BudgetRefNo", cmbMozBudjetRefNo.Text); 

                        if (txtNonProvisionNo.Text != "")
                            cmd.Parameters.AddWithValue("@ProvisionNo", txtNonProvisionNo.Text); 
                        else
                            cmd.Parameters.AddWithValue("@ProvisionNo", DBNull.Value);

                        cmd.Parameters.AddWithValue("@dummy_field", System.DateTime.Now);

                        cmd.Parameters.AddWithValue("@CreateDate", System.DateTime.Now);
                        cmd.Parameters.AddWithValue("@CreateUser", Session["UserName"]);
                        cmd.Parameters.AddWithValue("@isDeleted", 0);

                        if (txtBudgetAmnt.Text != "")
                        {
                            if (txtBudgetAmnt.Text.Contains("QAR"))
                            {
                                cmd.Parameters.AddWithValue("@budgetAmnt", Convert.ToDouble(txtBudgetAmnt.Text.Substring(3, txtBudgetAmnt.Text.Length - 3)));
                            }
                            else
                            {
                                cmd.Parameters.AddWithValue("@budgetAmnt", Convert.ToDouble(txtBudgetAmnt.Text));
                            }
                        }
                        else
                        {
                            cmd.Parameters.AddWithValue("@budgetAmnt", DBNull.Value);
                        }

                        int exUpdated = cmd.ExecuteNonQuery();
                        cmd.Parameters.Clear();
                    } 
                }
        }
        catch (Exception ex)
        {
            
        }
        finally
        {
           
        }        
    }
    protected void btnHome_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/Guest/Default9.aspx", false);         
    }
}