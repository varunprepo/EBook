﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

public partial class ManagerTask_CreateItems : System.Web.UI.Page
{
    string connValue = System.Configuration.ConfigurationManager.ConnectionStrings["EBSDEBookConn"].ConnectionString;
    private SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["EBSDEBookConn"].ConnectionString);
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnAdd_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(connValue);
        SqlCommand cmd = new SqlCommand();
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Connection = con;

        cmd.CommandText = "INSERT INTO SERVICE Values(@ServiceCode,@ServiceDesc,@Qnty,@Units,@ServiceReqDate)";  

        cmd.Parameters.AddWithValue("@ServiceCode", txtCode.Text);

        cmd.Parameters.AddWithValue("@ServiceDesc", txtDesc.Text);

        cmd.Parameters.AddWithValue("@Qnty", txtQnty.Text);

        cmd.Parameters.AddWithValue("@Units", txtUnits.Text);

        cmd.Parameters.AddWithValue("@ServiceReqDate", Convert.ToDateTime(System.DateTime.Now).ToString("dd/MMM/yyyy"));      

        try
        {
            con.Open();
            cmd.ExecuteNonQuery();
            con.Dispose();
        }
        catch (Exception ex)
        {

            throw ex;
        }
        finally
        {
            con.Close();
        }       
    }
}