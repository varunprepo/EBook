﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

public partial class ManagerTask_ProjectSummary : System.Web.UI.Page
{
    string connValue = System.Configuration.ConfigurationManager.ConnectionStrings["EBSDEBookConn"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void txtProjectID_TextChanged(object sender, EventArgs e)
    {

    }
    protected void btnData_Click(object sender, EventArgs e)
    {
        if (txtProjectID.Text != "")
        {
           // getContractData();     

            getProjectData();
        }
    }

    public void getProjectData()
    {
        try
        {
            SqlConnection sqlConn = new SqlConnection(connValue);
            sqlConn.Open();

            string strValue = "SELECT  Job.jobNo, Job.jobTypeID, Job.jobPriorityID, Job.jobStatusID, Job.remarks AS Instruction, Job.deptID, Job.contractNo, Job.qsID, Job.ceID, Job.peID, Job.dcID,    Job.contractTypeID AS Contract_Type_id, Job.projectTitle, Job.remarks, Job.contractorID, Job.consultantID, Job.jobID, Job.addendumNO, Job.jobTypeID AS Expr1, " +
                        " Job.jobDesc, Job.docRefID, Job.workDays, Job.jobDueDate, Job.jobReceivedDate, Job.jobStatusClosedDate, Job.jobClosedDate, Job.docRefID AS Expr2,      JobType.CategoryID AS JobCatID, Job.projectCode, Job.committmentNo, Job.attRcvdDateDC, Job.reviewDateDC, Job.sentToSurveyTeamDC, " +
                        " Job.receivedBySurveyTeamDC, Job.reqStatusID, Job.submissionNoDC, Job.projCoordinatorID, ProjCoordinator.coordName, Job.dcRejectionID, Job.closedDocRefID,  Job.jobPriorityID AS Expr3, Job.reqServiceID, Job.jobRequester, Job.taskSubTypeID, Contact.jobPosition FROM    Job INNER JOIN " +
                        " JobType ON Job.jobTypeID = JobType.jobTypeID INNER JOIN   Contact ON Job.requestedBy = Contact.contactID LEFT OUTER JOIN ProjCoordinator ON Job.projCoordinatorID = ProjCoordinator.prjCoordID Where (Job.jobID = " + "170001" + ")";

          
            SqlCommand sqlCom = new SqlCommand(strValue, sqlConn);
            sqlCom.CommandText = strValue;

            sqlCom.Parameters.AddWithValue("@JobID", "170001");

            SqlDataReader sqlReader = sqlCom.ExecuteReader();

            while (sqlReader.Read())
            {
                txtProjectID.Text = sqlReader["JobNo"].ToString();

                txtPrjTitle.Value = sqlReader["projectTitle"].ToString();   

                txtPrjStrDate.Value = Convert.ToDateTime(sqlReader["jobReceivedDate"]).ToString("dd/MMM/yyyy");                            

                txtEBSDAmt.Value = sqlReader["jobPosition"].ToString();
             
                txtCntrClsDate.Value = sqlReader["JobDueDate"].ToString();

                txtMinCode.Value = "";

                    txtProv.Value = "";
                    txtBudRefCode.Value = "";

                    txtCntrAmt.Value = "";
                    txtCntr.Value = "";

                    txtConsul.Value = "";

                    txtPrjStrDate.Value = "";
                    txtPrjEndDate.Value = "";

                    txtAprvedAmt.Value = "";
                    txtAdjAmt.Value = "";

                    txtActualAmt.Value = "";

                    txtReqAmt.Value = "";
                    txtRevDate.Value = "";

               

            }

            sqlReader.Close();
            sqlConn.Close();
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
  
}