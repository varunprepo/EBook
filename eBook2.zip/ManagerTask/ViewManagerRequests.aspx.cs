﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using Datalayer;
using System.IO;
using System.Drawing;
using System.Web.UI.HtmlControls;
public partial class ManagerTask_ViewManagerRequests : System.Web.UI.Page
{
    string _prjCode = string.Empty;
    IList<string> userRightsColl = new List<string>();
    int _userID = 0;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["UserName"] == null)
        {
            Response.Redirect("~/LoginPage.aspx", false);
        }
        else
        {
            if (Session["ProjectCode"] != null)         // On Click of Project code link within same page
                _prjCode = Session["ProjectCode"].ToString();

             userRightsColl = (IList<string>)Session["UserRightsColl"];

            _userID = Convert.ToInt32(Session["UserID"]);

            if (!IsPostBack)
            {
                string strQS = "SELECT Distinct jobOwner.contactID, Contact.userShortName AS UserName FROM JobOwner INNER JOIN  Contact ON jobOwner.contactID = Contact.contactID Where jobOwner.SectionID =10 and jobOwner.jobOwnerStatusID <>7 and Contact.userShortName <>''  Order by Contact.userShortName ";
               
                PopulateDropDownBox(ddlDCU, strQS, "contactID", "UserName");

               // PopulateDropDownBox(ddlPrj, "SELECT prjCoordID, coordName FROM ProjCoordinator Where sectionID = 10 ORDER BY coordName", "prjCoordID", "coordName");

               // PopulateDropDownBox(ddlPrj, "SELECT DISTINCT Contact.contactID, (Contact.firstName + '  ' + Contact.lastName) AS UserName FROM Job INNER JOIN   Contact ON Job.projCoordinatorID = Contact.contactID WHERE (Job.sectionID = 10)", "contactID", "UserName");

                  PopulateDropDownBox(ddlPrj, "SELECT DISTINCT Contact.contactID, Contact.UserShortName FROM Job INNER JOIN   Contact ON Job.projCoordinatorID = Contact.contactID WHERE (Job.sectionID = 10)", "contactID", "UserShortName");


                if (Session["CoordName"] != null)
                {
                    string str = Session["CoordName"].ToString();
                    string QSID = ddlPrj.Items.FindByText(str).Value;
                    ddlPrj.SelectedValue = QSID;
                }

                if (Session["ActionBy"]!= null)
                {
                    string strActionBy = Session["ActionBy"].ToString();
                    string staffID = ddlDCU.Items.FindByText(strActionBy).Value;
                    ddlDCU.SelectedValue = staffID;
                }

                GetOngoingMngrData();
            }
        }
    }


    private void PopulateDropDownBox(DropDownList ddlBox, string sqlQuery, string valueMember, string displayName)
    {
        ddlBox.DataSource = new JobOrderData().FillDropdown(sqlQuery);
        ddlBox.DataTextField = displayName;
        ddlBox.DataValueField = valueMember;
        ddlBox.SelectedIndex = -1;
        ddlBox.DataBind();

        ListItem emptyItem = new ListItem("", "");
        ddlBox.Items.Insert(0, emptyItem);
    }

    protected void gvDCLogView_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        gvMngrLogView.PageIndex = e.NewPageIndex;
        DataTable dt = new DataTable();
        dt = Session["getDCJobs"] as DataTable;

        BindData(dt);
    }

    private void BindData(DataTable dt)
    {
        lblCnt.Text = "Job Count :   " + dt.Rows.Count.ToString();

        gvMngrLogView.DataSource = dt;
        gvMngrLogView.DataBind();
    }
    

    // Function call On-going jobs and project code selection jobs
    private void GetOngoingMngrData()
    {
        int _userID = 0;
        int _coordID = 0;

        if (ddlPrj.SelectedIndex != 0)
            _coordID = Convert.ToInt32(ddlPrj.SelectedValue);

        if (ddlDCU.SelectedIndex != 0)
            _userID = Convert.ToInt32(ddlDCU.SelectedValue);


        DataTable dt = new DataTable();
        if (Session["SectionID"].Equals("10"))        // DCU Section
        {
            if ((_userID != 0) || (_coordID != 0))  // View Payment Request Log
            {
                dt = ViewOngoingMngrJobs(0, "", _userID.ToString(), _coordID.ToString());
                Session["getDCJobs"] = dt;
                lblCnt.Text = "Job Count : -  " + dt.Rows.Count.ToString();
            }
            else if ((!userRightsColl.Contains("17")))       // View All On-Going List of Job Orders
            {
                dt = ViewOngoingMngrJobs(0, "", "0", "0");

                Session["getDCJobs"] = dt;
                lblCnt.Text = "Job Count : -  " + dt.Rows.Count.ToString();
            }
            else               // Only Current User Jobs which is Ongoing
            {
                dt = ViewOngoingMngrJobs(0, "", Session["UserID"].ToString(), "0");
                Session["getDCJobs"] = dt;
                lblCnt.Text = "Job Count : -  " + dt.Rows.Count.ToString();
            }
        }
        else if (Session["userProfileID"].Equals("1"))   // Admin    
        {
            dt = ViewOngoingMngrJobs(0, "", "0", "0");
            Session["getDCJobs"] = dt;
            lblCnt.Text = "Job Count : -  " + dt.Rows.Count.ToString();
        }
        else
        {

        }
        BindData(dt);
    }

    // Function used to call ongoing DC jobs
    private DataTable ViewOngoingMngrJobs(int searchType, string _prjCode, string userID, string _CoordID)
    {
        DataSet ds = new DataSet();

        Int32 qsID;
        Int32.TryParse(userID, out qsID);

        Int32 CoordID;
        Int32.TryParse(_CoordID, out CoordID);

        try
        {
            ds = (new JobOrderData().ViewMngrLog(qsID, _prjCode, CoordID,10));    // SpName - dcu_ViewDCLog //mngr_ViewMngrLog
        }
        catch (Exception ex)
        {

        }
        return ds.Tables[0];
    }
   

    // When user click on JobNo Link Button For view DC Job Details
    protected void lnkJobOrderJobNo_Click(object sender, EventArgs e)
    {
        try
        {
            LinkButton lnkJobID = (LinkButton)sender;
            GridViewRow gvr = (GridViewRow)lnkJobID.NamingContainer;

            Session["JobID"] = ((HtmlGenericControl)gvr.FindControl("divJobID")).InnerText;
            Session["UrlRef"] = Request.Url.AbsoluteUri;

            Response.Redirect("~/ManagerTask/MngrTaskDetails.aspx?JobID= " + Session["JobID"] + "", false);
        }
        catch
        {

        }
    }

    protected void btnNewDCLog_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/ManagerTask/CreateTask.aspx", false);
    }
    protected void btnSearchDCLog_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/ManagerTask/SerachTask.aspx", false);
    }
    
    int flag;
    protected void gvDCLogView_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandArgument != "")
        {
            int jobid = Convert.ToInt32(e.CommandArgument);
            switch (e.CommandName)
            {
                case "DeleteJobid":
                    AccessRightsForDelete();
                    if (!userRightsColl.Contains("3"))
                    {
                        // Planning to put in Sp Name Like dcu_DeleteJob

                        // DeleteJob -spName

                        flag = (new JobOrderData().DeleteJobOrder(jobid));             //  Delete DC Job
                        new JobOrderData().DeactivateDocumentForJobDelete(jobid);      //  Release docID from Job table for using same document for next job                    
                        new JobOrderData().UpdateIsConfirmFalseOnJobDelete(jobid);     //  User Session Task for TempJobNo

                        if (flag > 0)
                            GetOngoingMngrData();      // After delete job reload Job Data again               
                    }
                    break;
            }
        }
    }
    private void AccessRightsForDelete()
    {
        if (userRightsColl.Contains("3"))   //Delete Job Order
        {
            Session["lblText"] = "You are not allowed to delete a Job Order.Please contact system Administrator for further inquiry.";
            Session["lblSub"] = "Restricted Access to delete a Job Order.";
            Session["lblBody"] = "This is in reference to Restricted Access to delete a Job Order. I would like to inquire about the restriction.";


            string url = "RestrictedMsgWindow.aspx";
            string s = "window.open('" + url + "', 'popup_window', 'width=500,height=250,left=100,top=100,resizable=yes,scrollbars=yes');";
            ClientScript.RegisterStartupScript(this.GetType(), "script", s, true);
        }
    }
    protected void gvDCLogView_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            LinkButton l = (LinkButton)e.Row.FindControl("btnDelete");
            l.Attributes.Add("onclick", "javascript:return " + "confirm('Are you sure you want to delete this Job')");
            l.CssClass = "btndelete";
        }
    }

    // Based On User selected DC User it will give related user Info
    protected void ddlDCU_SelectedIndexChanged(object sender, EventArgs e)
    {
        getDataByUserSelection();
    }
    private void getDataByUserSelection()
    {
        DataTable dt = new DataTable();

        string _staffID = string.Empty;

        if (ddlDCU.SelectedIndex != 0)
            _staffID = ddlDCU.SelectedValue;   // Selected staff from dropdown
        else if ((Session["userProfileID"].Equals("1")) || (!userRightsColl.Contains("17")))
            _staffID = "0"; // Admin and the person who have rights -17 
        else
            _staffID = Session["UserID"].ToString();  // Login User

        string _CoordID = string.Empty;
        if (ddlPrj.SelectedIndex != 0)
            _CoordID = ddlPrj.SelectedValue;

        dt = ViewOngoingMngrJobs(0, "", _staffID, _CoordID);      

        Session["getDCJobs"] = dt;
        lblCnt.Text = "Job Count : -  " + dt.Rows.Count.ToString();
        gvMngrLogView.DataSource = dt;
        gvMngrLogView.DataBind();
    }

    #region Export to excel

    // Export to excel

    protected void btnExelDcLog_Click(object sender, EventArgs e)
    {
        ExportToExcel();
    }
    private void ExportToExcel()
    {
        Response.Clear();
        Response.Buffer = true;
        Response.AddHeader("content-disposition", "attachment;filename=GridViewExport.xls");
        Response.Charset = "";
        Response.ContentType = "application/vnd.ms-excel";
        using (StringWriter sw = new StringWriter())
        {
            HtmlTextWriter hw = new HtmlTextWriter(sw);

            //To Export all pages
            gvMngrLogView.AllowPaging = false;

            gvMngrLogView.DataSource = Session["getDCJobs"];
            gvMngrLogView.DataBind();

            gvMngrLogView.HeaderRow.BackColor = Color.White;
            foreach (TableCell cell in gvMngrLogView.HeaderRow.Cells)
            {
                cell.BackColor = gvMngrLogView.HeaderStyle.BackColor;
            }
            foreach (GridViewRow row in gvMngrLogView.Rows)
            {
                row.BackColor = Color.White;
                foreach (TableCell cell in row.Cells)
                {
                    if (row.RowIndex % 2 == 0)
                    {
                        cell.BackColor = gvMngrLogView.AlternatingRowStyle.BackColor;
                    }
                    else
                    {
                        cell.BackColor = gvMngrLogView.RowStyle.BackColor;
                    }
                    cell.CssClass = "textmode";
                }
            }
            gvMngrLogView.RenderControl(hw);

            //style to format numbers to string
            string style = @"<style> .textmode { } </style>";
            Response.Write(style);
            Response.Output.Write(sw.ToString());
            Response.Flush();
            Response.End();
        }
    }
    public override void VerifyRenderingInServerForm(Control control)
    {
        /* Verifies that the control is rendered */
    }

    #endregion

    protected void ddlPrj_SelectedIndexChanged(object sender, EventArgs e)
    {
        getDataByUserSelection();

    }
}