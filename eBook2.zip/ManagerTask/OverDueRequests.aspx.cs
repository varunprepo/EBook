﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Data.SqlClient;
using System.Data;
using Datalayer;
using System.Globalization;
using System.Web.UI.HtmlControls;

public partial class ManagerTask_OverDueRequests : System.Web.UI.Page
{
    string connValue = System.Configuration.ConfigurationManager.ConnectionStrings["EBSDEBookConn"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["UserName"] == null)
        {
            Response.Redirect("~/LoginPage.aspx", false);
            return;
        }

        DataTable dt = new DataTable();
        string prjType = string.Empty;


        if (Session["OverDueName"] == null)
            prjType = "0";
        else
        {
            prjType = Session["OverDueName"].ToString();
        }

        if (!IsPostBack)
        {
            string strQuery = string.Empty;

            if (!Session["UserProfileID"].Equals("1"))
            {
                if (Convert.ToInt16((Session["SectionID"])) == 3)
                    strQuery = "SELECT DISTINCT JobType.jobTypeID, JobType.jobTypeName FROM  JobType INNER JOIN    Job ON JobType.jobTypeID = Job.jobCatID " +
                          " WHERE (JobType.jobTypeID IN (8)) AND (Job.jobStatusID IN (3, 8)) AND (Job.jobDueDate < GETDATE()-1) ORDER BY JobType.jobTypeName";
                else if (Convert.ToInt16((Session["SectionID"])) == 1)
                    strQuery = "SELECT DISTINCT JobType.jobTypeID, JobType.jobTypeName FROM  JobType INNER JOIN    Job ON JobType.jobTypeID = Job.jobCatID " +
                          " WHERE (JobType.jobTypeID IN (1, 3, 4, 5, 6, 7, 8)) AND (Job.jobStatusID IN (3, 8)) AND (Job.jobDueDate < GETDATE()-1) ORDER BY JobType.jobTypeName";
                else
                    strQuery = "SELECT DISTINCT JobType.jobTypeID, JobType.jobTypeName FROM  JobType INNER JOIN    Job ON JobType.jobTypeID = Job.jobCatID " +
                       " WHERE (JobType.jobTypeID IN (46)) AND (Job.jobStatusID IN (3, 8)) AND (Job.jobDueDate < GETDATE()-1) ORDER BY JobType.jobTypeName";
            }
            else
            {
                if (prjType.Equals("Document Control"))
                    strQuery = "SELECT DISTINCT JobType.jobTypeID, JobType.jobTypeName FROM  JobType INNER JOIN    Job ON JobType.jobTypeID = Job.jobCatID " +
                          " WHERE (JobType.jobTypeID IN (8)) AND (Job.jobStatusID IN (3, 8)) AND (Job.jobDueDate < GETDATE()-1) ORDER BY JobType.jobTypeName";
                else if (prjType.Equals("Cost Control Section"))
                    strQuery = "SELECT DISTINCT JobType.jobTypeID, JobType.jobTypeName FROM  JobType INNER JOIN    Job ON JobType.jobTypeID = Job.jobCatID " +
                          " WHERE (JobType.jobTypeID IN (1, 3, 4, 5, 6, 7, 8)) AND (Job.jobStatusID IN (3, 8)) AND (Job.jobDueDate < GETDATE()-1) ORDER BY JobType.jobTypeName";
                else
                    strQuery = "SELECT DISTINCT JobType.jobTypeID, JobType.jobTypeName FROM  JobType INNER JOIN    Job ON JobType.jobTypeID = Job.jobCatID " +
                       " WHERE (JobType.jobTypeID IN (46)) AND (Job.jobStatusID IN (3, 8)) AND (Job.jobDueDate < GETDATE()-1) ORDER BY JobType.jobTypeName";
            }


            // SELECT jobTypeID, jobTypeName FROM JobType WHERE (jobTypeID IN (1,2,3,4,5,6,7,8)) ORDER BY JobType.jobTypeName

            PopulateDropDownBox(drpJobType, strQuery, "jobTypeID", "jobTypeName");

            PopulateDropDownBox(drpPrjCoord, "SELECT DISTINCT Contact.contactID, Contact.firstName + '  ' + Contact.lastName AS UserName FROM   Job INNER JOIN  Contact ON Job.projCoordinatorID = Contact.contactID WHERE (Job.sectionID = 10) AND (Job.jobDueDate < GETDATE())", "contactID", "UserName");
          
            //PopulateDropDownBox(drpPrjCoord, "SELECT DISTINCT ProjCoordinator.prjCoordID, ProjCoordinator.coordName FROM  Job INNER JOIN ProjCoordinator ON Job.projCoordinatorID = ProjCoordinator.prjCoordID WHERE  (Job.sectionID = 10)", "prjCoordID", "coordName");

            string strQS = "SELECT Distinct jobOwner.contactID, Contact.userShortName AS UserName FROM JobOwner INNER JOIN  Contact ON jobOwner.contactID = Contact.contactID Where jobOwner.SectionID =10 and jobOwner.jobOwnerStatusID <>7 and Contact.userShortName <>''  Order by Contact.userShortName ";

            PopulateDropDownBox(drpStaff, strQS, "contactID", "UserName");

            //  dt = FillTab2(0, "");


            // -----------------------------------------------------
            int secID = 0;
            if (prjType.Equals("0"))
            {
                if (Convert.ToInt16((Session["SectionID"])) == 7)
                    secID = 1;
                else
                    secID = Convert.ToInt16((Session["SectionID"]));

                dt = FillTab2(0, "", secID);

                Session["getOverDueJobs"] = dt;
                gvOverDueJobs.DataSource = dt;
                gvOverDueJobs.DataBind();
            }
            else if (prjType.Equals("Cost Control Section"))
            {
                if (Session["UserProfileID"].Equals("1"))
                    secID = 1;
                else if (Convert.ToInt16((Session["SectionID"])) == 7)
                    secID = 1;
                else
                    secID = Convert.ToInt16((Session["SectionID"]));

                dt = FillTab2(0, "", secID);

                Session["getOverDueJobs"] = dt;
                gvOverDueJobs.DataSource = dt;
                gvOverDueJobs.DataBind();
            }
            else if (prjType.Contains("Data") || prjType.Contains("DC"))
            {
                drpJobType.SelectedValue = "8";  // DCU LOg    
                if (Session["UserProfileID"].Equals("1"))
                    secID = 3;
                else if (Convert.ToInt16((Session["SectionID"])) == 7)
                    secID = 3;
                else
                    secID = Convert.ToInt16((Session["SectionID"]));

                dt = LoadDataByJobType(secID);
            }
            else if (prjType.Equals("Payment Section"))
            {

            }
            else if (prjType.Trim().Equals("Document Control"))
            {
                if (Session["UserProfileID"].Equals("1"))
                    secID = 3;
                else if (Convert.ToInt16((Session["SectionID"])) == 7)
                    secID = 3;
                else
                    secID = Convert.ToInt16((Session["SectionID"]));

                drpJobType.SelectedValue = "8";  // DCU LOg
                dt = LoadDataByJobType(secID);
            }
            else if (Session["SectionID"].Equals("10"))
            {
                if (Session["UserProfileID"].Equals("1"))
                    secID = 10;
                else if (Convert.ToInt16((Session["SectionID"])) == 7)
                    secID = 10;
                else
                    secID = Convert.ToInt16((Session["SectionID"]));

                drpJobType.SelectedValue = "46";  // DCU LOg
                dt = LoadDataByJobType(secID);
            }
            else
            {
                string QSID = drpJobType.Items.FindByText(prjType).Value;
                drpJobType.SelectedValue = QSID;
                dt = LoadDataByJobType(Convert.ToInt16((Session["SectionID"])));
            }



            // ----------------------------------------------------------------


            //  Session["getOverDueJobs"] = dt;



            lblCnt.Text = " Over Due Jobs Count : " + dt.Rows.Count.ToString();
        }
    }
    private DataTable LoadDataByJobType(int userSecID)
    {
        DataTable dtGrid = FillByJobType(userSecID);      // Sp-Name FillStaffData
        Session["getOverDueJobs"] = dtGrid;
        gvOverDueJobs.DataSource = dtGrid;
        gvOverDueJobs.DataBind();

        return dtGrid;

        // lblStaffCnt.Text = dtGrid.Rows.Count.ToString();
    }
    private DataTable FillByJobType(int secID)
    {
        int catID = 0;

        if (drpJobType.SelectedIndex != 0)
            catID = Convert.ToInt16(drpJobType.SelectedValue);

         int coordID = 0;

        if (drpPrjCoord.SelectedIndex != 0)
            coordID = Convert.ToInt16(drpPrjCoord.SelectedValue);

        int qsID = 0;

        if (drpStaff.SelectedIndex != 0)
            qsID = Convert.ToInt16(drpStaff.SelectedValue);

        DataSet ds = new DataSet();
        try
        {
            ds = (new JobOrderData().GetOverDueMngrDetails(secID, catID, coordID, qsID));
        }
        catch (Exception ex)
        {

        }
        return ds.Tables[0];
    }
    private DataTable FillTab2(int searchType, string _prjCode, int userSecID)
    {
        int catID = 0;
        if (drpJobType.SelectedIndex != 0)
            catID = Convert.ToInt16(drpJobType.SelectedValue);

        int coordID = 0;
        if (drpPrjCoord.SelectedIndex != 0)
            coordID = Convert.ToInt16(drpPrjCoord.SelectedValue);

        int qsID = 0;
        if (drpStaff.SelectedIndex != 0)
            qsID = Convert.ToInt16(drpStaff.SelectedValue);


        DataSet ds = new DataSet();
        try
        {
            ds = (new JobOrderData().GetOverDueMngrDetails(userSecID, catID, coordID, qsID));
        }
        catch (Exception ex)
        {

        }
        return ds.Tables[0];
    }

    //protected void lnkJobOrderJobNo_Click(object sender, EventArgs e)     //ForCommitted
    //{
    //    try
    //    {
    //        LinkButton lnkJobID = (LinkButton)sender;
    //        GridViewRow gvr = (GridViewRow)lnkJobID.NamingContainer;

    //        Session["JobID"] = ((HtmlGenericControl)gvr.FindControl("divJobID")).InnerText;

    //        Session["UrlRef"] = Request.Url.AbsoluteUri;
    //        Response.Redirect("~/DCLog/DCDetails.aspx?JobID= " + Session["JobID"] + "", false);
    //    }
    //    catch
    //    {

    //    }
    //}
    protected void lnkJobOrderJobNo_Click(object sender, EventArgs e)
    {
        Session["PayID"] = null;
        Session["JobID"] = null;

        string strUpdateJob = Request.Url.AbsoluteUri;
        Session["UrlRef"] = strUpdateJob;
        try
        {
            LinkButton lnkJobID = (LinkButton)sender;
            GridViewRow gvr = (GridViewRow)lnkJobID.NamingContainer;
            Session["JobID"] = ((HtmlGenericControl)gvr.FindControl("divJobID")).InnerText;

            if (Session["JobID"] == null)
                Session["PayID"] = ((HtmlGenericControl)gvr.FindControl("divPayID")).InnerText;

            if (Session["JobID"].ToString() == "")
                Session["PayID"] = ((HtmlGenericControl)gvr.FindControl("divPayID")).InnerText;

            Session["JobInchargeID"] = lnkJobID.ToolTip;

            if ((Session["PayID"] == null))
            {
                Session["JobCatID"] = ((HtmlGenericControl)gvr.FindControl("divJobCatID")).InnerText;

                string catID = ((HtmlGenericControl)gvr.FindControl("divJobCatID")).InnerText.Trim();

                if (catID.Equals("1"))
                    Response.Redirect("~/JobOrder/PSAJobDetails.aspx?JobID= " + Session["JobID"] + "", false);
                else if (catID.Equals("8"))
                    Response.Redirect("~/DCLog/DCDetails.aspx?JobID= " + Session["JobID"] + "", false);
                else if (catID.Equals("46"))
                    Response.Redirect("~/ManagerTask/MngrTaskDetails.aspx?JobID= " + Session["JobID"] + "", false);
                else
                    Response.Redirect("~/JobOrder/DefaultGrid.aspx?JobID= " + Session["JobID"] + "", false);
            }
            else
            {
                Response.Redirect("~/Payments/PaymentDetails.aspx?PayID= " + Session["PayID"] + "", false);
            }


        }
        catch (Exception ex)
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Error occurred while processing the request')</script>", false);
        }
    }
    protected void gvOverDueJobs_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        gvOverDueJobs.PageIndex = e.NewPageIndex;
        DataTable dt = new DataTable();
        dt = Session["getOverDueJobs"] as DataTable;

        lblCnt.Text = " Over Due Jobs Count : " + dt.Rows.Count.ToString();

        gvOverDueJobs.DataSource = dt;
        gvOverDueJobs.DataBind();
    }
    protected void gvOverDueJobs_RowCommand(object sender, GridViewCommandEventArgs e)
    {

    }
    protected void gvOverDueJobs_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        //if (e.Row.RowType == DataControlRowType.DataRow)
        //{
        //    Label jobNo = (Label)e.Row.FindControl("lblJobNo"); //          

        //    Label lblJobRecDate = (Label)e.Row.FindControl("lblCmtRecDate");
        //    if ((lblJobRecDate.Text != ""))
        //    {
        //        string elapsedDays = getDaysByGivenEndDate(lblJobRecDate.Text, System.DateTime.Now.ToString());
        //        Label WorkDays = (Label)e.Row.FindControl("lblDays");
        //        int extraDays = Convert.ToInt16(WorkDays.Text);
        //        extraDays = (extraDays / 2);

        //        int totalDays = Convert.ToInt16(WorkDays.Text) + extraDays;

        //        if (totalDays < Convert.ToInt16(elapsedDays))
        //        {
        //            e.Row.BackColor = System.Drawing.Color.LightPink;
        //            e.Row.ForeColor = System.Drawing.Color.Red;

        //            e.Row.Font.Bold = true;

        //            jobNo.BackColor = System.Drawing.Color.Yellow;
        //            e.Row.Cells[1].BackColor = System.Drawing.Color.White;
        //        }
        //    }
        //}
    }
    private string getDaysByGivenEndDate(string strDate, string endDate)
    {
        strDate = Convert.ToDateTime(strDate).ToString("MM/dd/yyyy", CultureInfo.InvariantCulture);
        endDate = Convert.ToDateTime(endDate).ToString("MM/dd/yyyy", CultureInfo.InvariantCulture);

        DateTime strDt = DateTime.ParseExact(strDate, "MM/dd/yyyy", CultureInfo.InvariantCulture);
        DateTime endDt = DateTime.ParseExact(endDate, "MM/dd/yyyy", CultureInfo.InvariantCulture);

        SqlConnection con = new SqlConnection(connValue);
        SqlCommand cmd = new SqlCommand();

        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Connection = con;

        cmd.CommandText = "testSP";

        SqlParameter prm = cmd.Parameters.Add("@ad_startDate", SqlDbType.DateTime);
        prm.Value = strDt;

        prm = cmd.Parameters.Add("@ad_endDate", SqlDbType.DateTime);
        prm.Value = endDt;

        prm = cmd.Parameters.Add("@ai_workDays", SqlDbType.Int);
        prm.Direction = ParameterDirection.Output;

        //prm = cmd.Parameters.Add("@as_errMsg", SqlDbType.VarChar);
        //prm.Direction = ParameterDirection.Output;

        con.Open();
        SqlDataReader dr = cmd.ExecuteReader();
        while (dr.Read())
            Console.WriteLine(dr.GetString(0));
        con.Dispose();
        con.Close();

        return cmd.Parameters[2].Value.ToString();
    }

    private void PopulateDropDownBox(DropDownList ddlBox, string sqlQuery, string valueMember, string displayName)
    {

        ddlBox.DataSource = new JobOrderData().FillDropdown(sqlQuery);
        ddlBox.DataTextField = displayName;
        ddlBox.DataValueField = valueMember;
        ddlBox.SelectedIndex = -1;
        ddlBox.DataBind();


        ListItem emptyItem = new ListItem("", "");
        ddlBox.Items.Insert(0, emptyItem);

    }
    protected void drpJobType_SelectedIndexChanged(object sender, EventArgs e)
    {
        DataTable dt = FillTab2(0, "", Convert.ToInt16(Session["SectionID"]));

        Session["getOverDueJobs"] = dt;

        gvOverDueJobs.DataSource = dt;
        gvOverDueJobs.DataBind();

        lblCnt.Text = " Over Due Jobs Count : " + dt.Rows.Count.ToString();
    }
    protected void btnPrint_Click(object sender, EventArgs e)
    {
        try
        {
            ScriptManager.RegisterStartupScript(this, typeof(Page), "printGrid", "printGrid();", true);
        }
        catch { }
    }

    protected void drpPrjCoord_SelectedIndexChanged(object sender, EventArgs e)
    {
        DataTable dt = LoadDataByJobType(10);
    }
    protected void drpStaff_SelectedIndexChanged(object sender, EventArgs e)
    {
        DataTable dt = LoadDataByJobType(10);
    }
}