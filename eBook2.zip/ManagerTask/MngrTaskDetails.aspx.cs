﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Data.SqlClient;
using Datalayer;
using System.Data;
using System.IO;
using System.Configuration;
using System.Net;
using System.Net.Mail;

using System.Security.Cryptography.X509Certificates;
using System.Threading;
using System.Globalization;
using System.Net.Security;
using System.Text;



public partial class ManagerTask_MngrTaskDetails : System.Web.UI.Page
{
    string connValue = System.Configuration.ConfigurationManager.ConnectionStrings["EBSDEBookConn"].ConnectionString;
    string _jobNo = string.Empty;
    int _jobID = 0;
    IList<string> userRightsColl = new List<string>();
    string profile_Name = string.Empty;
    int _tabType = 0;


    #region MyRegion



    protected void Page_Init(object sender, EventArgs e)
    {
        if (Session["UserName"] == null)
        {
            Response.Redirect("~/LoginPage.aspx", false);
            return;
        }

        if (_jobID == 0)
            _jobID = Convert.ToInt32(Request.QueryString["JobID"]);

        if (_jobID == 0)
            _jobID = Convert.ToInt32(Session["Mngr_JobID"]);

        //Session["StaffJobID"] = Convert.ToInt32(Request.QueryString["JobID"]);

        _tabType = Convert.ToInt32(Request.QueryString["tabType"]);

        // _jobID = 17621;

        if (!IsPostBack)
        {
            PopulateDropDownBox(drpTaskType, "SELECT  jobTypeID, jobTypeName, CategoryID, sectionID FROM   JobType WHERE (sectionID = 10) AND (jobTypeID <> CategoryID)", "jobTypeID", "jobTypeName");

            PopulateDropDownBox(drpSubTaskType, "SELECT  subTypeID, subTypeName, typeID FROM  SubTaskType ", "subTypeID", "subTypeName");

            //PopulateDropDownBox(drpRequestedBy, "SELECT contactID, firstName FROM Contact ", "contactID", "firstName");  
            PopulateDropDownBox(drpReqVia, "SELECT ReqID, ReqVia FROM RequestService", "ReqID", "ReqVia");

            // PopulateDropDownBox(drpCoordinator, "SELECT prjCoordID, coordName FROM ProjCoordinator Where sectionID = 10 ORDER BY coordName", "prjCoordID", "coordName");

            PopulateDropDownBox(drpCoordinator, "SELECT contactID, firstName FROM Contact where isCoordinator = 1", "contactID", "firstName");

            PopulateDropDownBox(drpActionBy, "SELECT contactID, firstName FROM Contact where isAuthRepres = 1", "contactID", "firstName");

            PopulateDropDownBox(ddlJobStatus, "SELECT JobStatusID, JobStatusName FROM JobStatus Where JobStatusID in(1,3,5) ORDER BY JobStatusName", "JobStatusID", "JobStatusName");   //4, Ongoing and Pending

            ddlQS.DataSource = null;

            string getStaff = "SELECT  contactID, (firstName + ' ' + lastName) as UserName FROM  Contact WHERE (userShortName IS NOT NULL) AND (contactID <> 1) AND (isActive = 1) AND isAuthRepres =1 ORDER BY userShortName";

            PopulateDropDownBox(ddlQS, getStaff, "contactID", "UserName");

            PopulateDropDownBox(ddlTask, "SELECT jobPurposeID, jobPurposeName FROM JobPurpose ", "jobPurposeID", "jobPurposeName");

            PopulateDropDownBox(ddlDept, "SELECT departmentID, deptName FROM  Department where affairID is not null ORDER BY deptName ", "departmentID", "deptName");

            Fill_JobOrder_Information(_jobID);

            if (fileUpload1.PostedFile == null)
            {
                UploadFile(CreateFolder(false));
            }
        }

        gvSRJoborder.DataSource = new JobOrderData().GetMngrJobOwnerDetails(_jobID);
        gvSRJoborder.DataBind();
    }
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    private void getFiles()
    {

    }

    private void PopulateDropDownBox(DropDownList ddlBox, string sqlQuery, string valueMember, string displayName)
    {
        DataTable table = new DataTable();
        try
        {
            using (SqlConnection sqlConn = new SqlConnection(connValue))
            {
                using (SqlDataAdapter da = new SqlDataAdapter(sqlQuery, sqlConn))
                {
                    sqlConn.Open();
                    da.Fill(table);
                }
            }
            //cmbBox.Items.Add("Select");

            ddlBox.DataSource = table;
            ddlBox.DataTextField = displayName;
            ddlBox.DataValueField = valueMember;

            ddlBox.SelectedIndex = -1;
            ddlBox.DataBind();

            ddlBox.Items.Insert(0, new ListItem("--Select--"));
        }
        catch (System.Exception ex)
        {
            throw ex;
        }
    }
    private void PopulateDropDownBox_Staff(DropDownList ddlBox, string sqlQuery, string valueMember, string displayName)
    {
        DataTable table = new DataTable();
        try
        {
            using (SqlConnection sqlConn = new SqlConnection(connValue))
            {
                using (SqlDataAdapter da = new SqlDataAdapter(sqlQuery, sqlConn))
                {
                    sqlConn.Open();
                    da.Fill(table);
                }
            }
            //cmbBox.Items.Add("Select");

            ddlBox.DataSource = table;
            ddlBox.DataTextField = displayName;
            ddlBox.DataValueField = valueMember;

            ddlBox.SelectedIndex = -1;
            ddlBox.DataBind();

            // ddlBox.Items.Insert(0, new ListItem("--Select--"));
        }
        catch (System.Exception ex)
        {
            throw ex;
        }
    }

    private void PopulateDropDownBoxForStaffRole(DropDownList ddlBox, string sqlQuery, string valueMember, string displayName)
    {
        DataTable table = new DataTable();
        try
        {
            using (SqlConnection sqlConn = new SqlConnection(connValue))
            {
                using (SqlDataAdapter da = new SqlDataAdapter(sqlQuery, sqlConn))
                {
                    sqlConn.Open();
                    da.Fill(table);
                }
            }

            //cmbBox.Items.Add("Select");

            ddlBox.DataSource = table;
            ddlBox.DataTextField = displayName;
            ddlBox.DataValueField = valueMember;

            ddlBox.SelectedIndex = -1;
            ddlBox.DataBind();

        }
        catch (System.Exception ex)
        {
            throw ex;
        }
    }
    protected void gvSRJoborder_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName.Equals("SelectStaff"))
        {
            string arguments = e.CommandArgument.ToString();

            if (arguments == "")
                return;

            string[] args = arguments.Split(';');

            int staffID = Convert.ToInt32(args[0]);


            FillstaffData(staffID);

            btnAddUpdate.Text = " Update Data";
        }
    }
    private void FillstaffData(int staffID)
    {
        string qry = "SELECT  jobOwnerID, jobID, contactID, jobNo,REPLACE(CONVERT(NVARCHAR, actionDueDate, 106), ' ', '/') AS actionDueDate,  daysToAct, REPLACE(CONVERT(NVARCHAR, completionDate, 106), ' ', '/') AS completionDate, jobOwnerStatusID, jobPurposeID, JobTypeID, " +
        "REPLACE(CONVERT(NVARCHAR, staffIssueDate, 106), ' ', '/') AS staffIssueDate , distributedBy,   remarks, REPLACE(CONVERT(NVARCHAR, staffStartDate, 106), ' ', '/') AS staffStartDate  FROM  JobOwner WHERE (jobOwnerID = " + staffID + ")";

        using (SqlConnection cn = new SqlConnection(connValue))
        {
            cn.Open();
            using (SqlCommand cmd = new SqlCommand(qry, cn))
            {
                using (SqlDataReader dr = cmd.ExecuteReader())
                {
                    while (dr.Read())
                    {
                        lblInchargeID.Text = dr["JobOwnerID"].ToString();
                        lblDistributedBy.Text = "95";

                        ddlTask.SelectedValue = dr["jobPurposeID"].ToString();
                        txtStartDate.Text = dr["staffIssueDate"].ToString();

                        //  txtWorkDays.Text = dr["daysToAct"].ToString();
                        txtDueDate.Text = dr["actionDueDate"].ToString();
                        txtRemarks.Text = dr["remarks"].ToString();

                        try
                        {
                            ddlQS.SelectedValue = dr["contactID"].ToString();
                        }
                        catch (Exception ex)
                        {

                        }
                    }
                }
            }
        }
    }
    protected void txtdate_TextChanged(object sender, EventArgs e)
    {
        TextBox tdate = (TextBox)sender;
        //string format = "dd/mm/yyyy";

        string dfs = tdate.Text;


        DateTime dd = new DateTime();
        Thread.CurrentThread.CurrentCulture = new CultureInfo("en-GB");
        CultureInfo ci = System.Threading.Thread.CurrentThread.CurrentCulture;
        DateTime dt;

        //dt = DateTime.Parse(tdate.Text, ci); 
        // DateTime dt = DateTime.Parse(tdate.Text, CultureInfo.GetCultureInfo("en-gb"));
        // new JobOrderData().UpdateJobDate(Convert.ToInt32(tdate.ToolTip), dd.ToString());

        new JobOrderData().UpdateJobDate(Convert.ToInt32(tdate.ToolTip), dfs);

        gvSRJoborder.DataSource = new JobOrderData().GetJobOwnerDetails(_jobID);
        gvSRJoborder.DataBind();
    }
    protected void chkstate_CheckedChanged(object sender, EventArgs e)
    {
        System.Web.UI.WebControls.CheckBox chk = (System.Web.UI.WebControls.CheckBox)sender;

        int inchargeID = Convert.ToInt32(chk.ToolTip);

        Session["_InchargeID"] = inchargeID;

        new JobOrderData().UpdateStatus(inchargeID, Convert.ToBoolean(chk.Checked));
        new JobOrderData().UpdateCompletionDate(inchargeID, Convert.ToBoolean(chk.Checked));

        IList<int> docIDColl = new List<int>();

        if (chk.Checked) // true
        {
            Boolean chkDoc = false;

            string _staffName = string.Empty; string _userName = string.Empty;
            string eMail = getMailAddress(Convert.ToInt32(Session["_InchargeID"]), ref _staffName, ref _userName);
            OutLookAlertJobComplete(eMail, "", _staffName, _userName);

            if (chkDoc == true)
            {
                string url = "RestrictedAccessWindow.aspx";
                string s = "window.open('" + url + "', 'popup_window', 'width=520,height=200,left=100,top=100,resizable=no');";
                Page.ClientScript.RegisterStartupScript(this.GetType(), "script", s, true);
            }
        }
        else
        {
            Boolean chkDoc = false;
            if (chkDoc == false)
            {
                string url = "Restricted.aspx";
                string s = "window.open('" + url + "', 'popup_window', 'width=520,height=200,left=100,top=100,resizable=no');";
                Page.ClientScript.RegisterStartupScript(this.GetType(), "script", s, true);
            }
        }

        gvSRJoborder.DataSource = new JobOrderData().GetJobOwnerDetails(_jobID);
        gvSRJoborder.DataBind();
    }
    protected void chkstateTL_CheckedChanged(object sender, EventArgs e)
    {
        System.Web.UI.WebControls.CheckBox chk = (System.Web.UI.WebControls.CheckBox)sender;
        int inchargeID = Convert.ToInt32(chk.ToolTip);
        if (chk.Checked) // true
        {
            new JobOrderData().UpdateTLApproveStatus(Convert.ToInt32(inchargeID), Convert.ToBoolean(chk.Checked));
        }
        else
        {
            new JobOrderData().UpdateTLApproveStatus(Convert.ToInt32(inchargeID), Convert.ToBoolean(chk.Checked));
        }

        gvSRJoborder.DataSource = new JobOrderData().GetJobOwnerDetails(_jobID);
        gvSRJoborder.DataBind();
    }
    public IList<int> getDocIDCollection()
    {
        IList<int> docIDColl = new List<int>();
        IList<int> docStatusColl = new List<int>();

        try
        {
            SqlConnection sqlConn = new SqlConnection(connValue);
            sqlConn.Open();

            string strQuery = "SELECT DISTINCT DocumentDistribution.documentID,DocumentDistribution.docStatusID, [Document].jobID FROM  [Document] INNER JOIN DocumentDistribution ON [Document].documentID = DocumentDistribution.documentID  WHERE  ([Document].jobID = " + _jobID + ")";

            SqlCommand sqlCom = new SqlCommand(strQuery, sqlConn);
            SqlDataReader sqlReader = sqlCom.ExecuteReader();
            while (sqlReader.Read())
            {
                docIDColl.Add(Convert.ToInt32(sqlReader["DocumentID"]));
                docStatusColl.Add(Convert.ToInt32(sqlReader["docStatusID"]));
            }
            Session["docStatusColl"] = docStatusColl;

            sqlReader.Close();
            sqlConn.Close();
        }
        catch (System.Exception ex)
        {
            throw ex;
        }
        return docIDColl;
    }
    protected void SelectedIndexChanged(object sender, EventArgs e)
    {
        DropDownList ddl = (DropDownList)sender;
        if (ddl.SelectedIndex != 0)
        {
            string ID = ddl.ID;
            string g = ddl.SelectedValue;
            string inchargeID = ddl.ToolTip;

            Session["_InchargeID"] = inchargeID;
            Session["StatusValCurrent"] = ddl.SelectedValue;

            if (ddl.SelectedValue != "3")
            {
                int rowFnd = getandChkData(Convert.ToInt32(inchargeID), Convert.ToInt32(ddl.SelectedValue));
                if (rowFnd != 0)
                {
                    ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Action By Staff not yet completed')</script>", false);
                    ddl.SelectedValue = "3";
                }
                else
                {
                    gvSRJoborder.DataSource = new JobOrderData().GetJobOwnerDetails(_jobID);
                    gvSRJoborder.DataBind();
                }
            }
            else
            {
                updateOngoingStatus(Convert.ToInt32(inchargeID), Convert.ToInt32(ddl.SelectedValue));

                //if (ddl.SelectedValue == "3")
                //{
                //    new JobOrderData().UpdateCompletionDate(Convert.ToInt32(inchargeID));
                //}


                //if (ddl.SelectedValue == "3" || ddl.SelectedValue == "7")
                //    new JobOrderData().UpdateJobDoneCheckBox(Convert.ToInt32(inchargeID), Convert.ToInt32(ddl.SelectedValue)); //cmldaten jobdone

                //if (ddl.SelectedValue != "7")
                //{
                //    new JobOrderData().UpdateCompletionDate(Convert.ToInt32(inchargeID));
                //}

                // new JobOrderData().UpdateJobStatus(Convert.ToInt32(inchargeID), Convert.ToInt32(ddl.SelectedValue), Session["UserName"].ToString());

                gvSRJoborder.DataSource = new JobOrderData().GetJobOwnerDetails(_jobID);
                gvSRJoborder.DataBind();
            }
        }
    }

    private Boolean checkJobLevelStaff()
    {
        Boolean chkMainStaff = false;
        string strQuery = "SELECT jobID, projCoordinatorID, dcID FROM  Job  WHERE  (sectionID = 10) AND (jobID = " + _jobID + ")";

        SqlConnection cnn = new SqlConnection(connValue);
        cnn.Open();
        SqlCommand cmm = new SqlCommand();
        cmm.Connection = cnn;
        cmm.CommandText = strQuery;
        SqlDataReader sqlDtReader = cmm.ExecuteReader();
        if (sqlDtReader.HasRows)
        {
            while (sqlDtReader.Read())
            {
                if (Session["UserID"].Equals(sqlDtReader["projCoordinatorID"].ToString()))
                {
                    chkMainStaff = true;
                }
                if (Session["UserID"].Equals(sqlDtReader["dcID"].ToString()))
                {
                    chkMainStaff = true;
                }
            }
        }

        sqlDtReader.Close();
        cnn.Close();

        return chkMainStaff;
    }
    private string getMailAddress(int _inchargeID, ref string staffName, ref string userName)
    {
        string _eMail = string.Empty;
        SqlConnection cnn = new SqlConnection(connValue);
        cnn.Open();
        SqlCommand cmm = new SqlCommand();
        cmm.Connection = cnn;
        cmm.CommandText = "SELECT  Contact.firstName, Contact_1.emailAddress,Contact_1.firstName as UserName  FROM JobOwner INNER JOIN    Contact ON JobOwner.contactID = Contact.contactID INNER JOIN  Contact AS Contact_1 ON JobOwner.distributedBy = Contact_1.contactID WHERE   (JobOwner.jobOwnerID = " + _inchargeID + ")"; //open n Follwup
        SqlDataReader sqlDtReader = cmm.ExecuteReader();
        if (sqlDtReader.HasRows)
        {
            while (sqlDtReader.Read())
            {
                _eMail = sqlDtReader["emailAddress"].ToString();
                staffName = sqlDtReader["firstName"].ToString();
                userName = sqlDtReader["UserName"].ToString();
            }
        }
        sqlDtReader.Close();
        cnn.Close();
        return _eMail;
    }



    private void OutLookAlertJobComplete(string eMail, string mailBody, string _staffName, string _userName)
    {
        string jobNo = "";
        SmtpClient smtpclient = new SmtpClient("10.250.50.201", 587);
        System.Net.Mail.MailMessage mail = new System.Net.Mail.MailMessage();
        MailAddress fromaddress = new MailAddress("EBSD@ashghal.gov.qa");
        mail.From = fromaddress;
        mail.To.Add(eMail);
        mail.Subject = ("eBook Job No. " + jobNo);
        mail.IsBodyHtml = true;

        mail.Body = "<html><body><i style='font-family:Calibri; font-size:15'>Dear " + _userName + " ,</i><br/><br/><i style='font-family:Calibri; font-size:15'>This is an automated alert from Document & Task Management System.</i><br/><br/><i style='font-family:Calibri;font-size:15'>" +
                           "Please be noted that</i><i style='color:Maroon;font-family:Calibri; font-size:15'> Job No. " + Session["jobNo"].ToString() + "</i><i style='font-family:Calibri; font-size:15'> was completed by " + _staffName + " . Please log in to eBook on the following link:-</i><br /><br />" +
                           "<table style='width:80%' border='1'><tr><td align='center' colspan='2' style='background-color:Maroon;color:White;font-family:Calibri;font-size:18;font-weight:bold'>JOB NO: " + Session["jobNo"].ToString() + "</td>" +
                           "</tr><tr><td style='background-color:#B58AA5;font-family:Calibri;font-size:15'><i>Contract No / Project Code </i></td><td style='font-family:Calibri;font-size:15'>" + Session["contractNo"].ToString() + "</td></tr>" +
                           "<tr><td style='background-color:#B58AA5;font-family:Calibri;font-size:15'><i>eBook URL</i></td><td style='font-family:Calibri;font-size:15'>  http://mv2ebdbookp01/eBook/LoginPage.aspx </td></tr>" +
                           "<tr><td style='background-color:#B58AA5;font-family:Calibri;font-size:15'><i>Date of Creation</i></td><td style='font-family:Calibri;font-size:15'>" + System.DateTime.Now + "</td></tr>" +
                           "</table><br/><br/><div style='font-family:Calibri; font-size:15'>Best Regards,<br/>eBook Team</div></body></html>";


        smtpclient.EnableSsl = true;
        smtpclient.UseDefaultCredentials = true;

        try
        {
            smtpclient.Credentials = new System.Net.NetworkCredential(@"Ashghal\EBSD", ConfigurationManager.AppSettings["passWordForReport"].ToString());
            ServicePointManager.ServerCertificateValidationCallback = delegate(object s, X509Certificate certificate, X509Chain chain, SslPolicyErrors sslPolicyErrors) { return true; };
            smtpclient.Send(mail);
        }
        catch (System.Exception ex)
        {
            Console.WriteLine(ex);
            if (ex.InnerException != null)
            {
                Console.WriteLine("InnerException is: {0}", ex.InnerException);
            }
        }
        finally
        {
            mail.Dispose();
            mail = null;
            smtpclient = null;
        }
    }
    private string getMailAddress(int _inchargeID)
    {
        string _eMail = string.Empty;
        SqlConnection cnn = new SqlConnection(connValue);
        cnn.Open();
        SqlCommand cmm = new SqlCommand();
        cmm.Connection = cnn;
        cmm.CommandText = "SELECT   Contact.emailAddress, Contact_1.emailAddress AS distBy  FROM   JobOwner INNER JOIN    Contact ON JobOwner.contactID = Contact.contactID INNER JOIN  Contact AS Contact_1 ON JobOwner.distributedBy = Contact_1.contactID WHERE   (JobOwner.jobOwnerID = " + _inchargeID + ")"; //open n Follwup
        SqlDataReader sqlDtReader = cmm.ExecuteReader();
        if (sqlDtReader.HasRows)
        {
            while (sqlDtReader.Read())
                _eMail = sqlDtReader["emailAddress"].ToString();
        }
        sqlDtReader.Close();
        cnn.Close();
        return _eMail;
    }
    private void OutLookAlert(string eMail, string mailBody)
    {
        string jobNo = "";
        SmtpClient smtpclient = new SmtpClient("10.250.50.201", 587);
        System.Net.Mail.MailMessage mail = new System.Net.Mail.MailMessage();
        MailAddress fromaddress = new MailAddress("EBSD@ashghal.gov.qa");
        mail.From = fromaddress;
        mail.To.Add(eMail);
        mail.Subject = ("eBook Job No. " + jobNo);
        mail.IsBodyHtml = true;

        mail.Body = "<html><body><i style='font-family:Calibri; font-size:15'>Dear eBook Team,</i><br/><br/><i style='font-family:Calibri; font-size:15'>This is an automated alert from Document & Task Management System.</i><br/><br/><i style='font-family:Calibri;font-size:15'>" +
                           "Please be noted that</i><i style='color:Maroon;font-family:Calibri; font-size:15'> Job No. " + Session["jobNo"].ToString() + "</i><i style='font-family:Calibri; font-size:15'> a new Job Order was assigned to you and the details are as follows:-</i><br /><br />" +
                           "<table style='width:80%' border='1'><tr><td align='center' colspan='2' style='background-color:Maroon;color:White;font-family:Calibri;font-size:18;font-weight:bold'>JOB NO: " + Session["jobNo"].ToString() + "</td>" +
                           "</tr><tr><td style='background-color:#B58AA5;font-family:Calibri;font-size:15'><i>Contract No / Project Code </i></td><td style='font-family:Calibri;font-size:15'>" + Session["contractNo"].ToString() + "</td></tr>" +
                           "<tr><td style='background-color:#B58AA5;font-family:Calibri;font-size:15'><i>eBook URL</i></td><td style='font-family:Calibri;font-size:15'>  http://mv2ebdbookp01/eBook/LoginPage.aspx  </td></tr>" +
                           "<tr><td style='background-color:#B58AA5;font-family:Calibri;font-size:15'><i>Date of Creation</i></td><td style='font-family:Calibri;font-size:15'>" + System.DateTime.Now + "</td></tr>" +
                           "</table><br/><br/><div style='font-family:Calibri; font-size:15'>Best Regards,<br/>eBook Team</div></body></html>";


        smtpclient.EnableSsl = true;
        smtpclient.UseDefaultCredentials = true;

        try
        {
            smtpclient.Credentials = new System.Net.NetworkCredential(@"Ashghal\EBSD", ConfigurationManager.AppSettings["passWordForReport"].ToString());
            ServicePointManager.ServerCertificateValidationCallback = delegate(object s, X509Certificate certificate, X509Chain chain, SslPolicyErrors sslPolicyErrors) { return true; };
            smtpclient.Send(mail);
        }
        catch (System.Exception ex)
        {
            Console.WriteLine(ex);
            if (ex.InnerException != null)
            {
                Console.WriteLine("InnerException is: {0}", ex.InnerException);
            }
        }
        finally
        {
            mail.Dispose();
            mail = null;
            smtpclient = null;
        }
    }

    public void Fill_JobOrder_Information(int _jobID)
    {
        try
        {
            SqlConnection sqlConn = new SqlConnection(connValue);
            sqlConn.Open();

            string strValue = "SELECT Job.jobNo, Job.jobTypeID, Job.jobPriorityID, Job.jobStatusID, Job.remarks AS Instruction, Job.deptID, Job.contractNo, Job.qsID, Job.ceID, Job.peID, Job.dcID, " +
                        " Job.contractTypeID AS Contract_Type_id, Job.projectTitle, Job.remarks, Job.contractorID, Job.consultantID, Job.jobID, Job.addendumNO, Job.jobTypeID AS Expr1, " +
                        " Job.jobDesc, Job.docRefID, Job.workDays, Job.jobDueDate, Job.jobReceivedDate, Job.jobStatusClosedDate, Job.jobClosedDate, Job.docRefID AS Expr2, " +
                         " JobType.CategoryID AS JobCatID, Job.projectCode, Job.committmentNo, Job.attRcvdDateDC, Job.reviewDateDC, Job.sentToSurveyTeamDC, " +
                       "  Job.receivedBySurveyTeamDC, Job.reqStatusID, Job.submissionNoDC, Job.projCoordinatorID, Job.dcRejectionID, Job.closedDocRefID, Job.jobPriorityID AS Expr3, " +
                        " Job.reqServiceID, Job.jobRequester, Job.taskSubTypeID, Contact.jobPosition, Contact_1.firstName + '  ' + Contact_1.lastName AS coordName, " +
                        " Department.deptName,Job.externalDept,Job.taskPct FROM Job INNER JOIN JobType ON Job.jobTypeID = JobType.jobTypeID INNER JOIN Contact ON Job.requestedBy = Contact.contactID INNER JOIN Contact AS Contact_1 ON Job.projCoordinatorID = Contact_1.contactID INNER JOIN " +
                        " Department ON Job.deptID = Department.departmentID Where (Job.jobID = " + _jobID + ")";

            //SELECT Job.jobNo, Job.jobTypeID, Job.jobPriorityID, Job.jobStatusID, Job.remarks AS Instruction, Job.deptID, Job.contractNo, Job.qsID, Job.ceID, Job.peID, Job.dcID, Job.contractTypeID AS Contract_Type_id, Job.projectTitle, Job.remarks, Job.contractorID, Job.consultantID, Job.jobID, Job.addendumNO, Job.jobTypeID AS Expr1, " +
            //            " Job.jobDesc, Job.docRefID, Job.workDays, Job.jobDueDate, Job.jobReceivedDate, Job.jobStatusClosedDate, Job.jobClosedDate, Job.docRefID AS Expr2,   JobType.CategoryID AS JobCatID, Job.projectCode, Job.committmentNo, Job.attRcvdDateDC, Job.reviewDateDC, Job.sentToSurveyTeamDC, Job.receivedBySurveyTeamDC, " +
            //            " Job.reqStatusID, Job.submissionNoDC, Job.projCoordinatorID, ProjCoordinator.CoordName,Job.dcRejectionID, Job.closedDocRefID,job.jobPriorityID,job.reqServiceID,job.jobRequester,job.taskSubTypeID,job.JobPosition FROM  Job INNER JOIN  JobType ON Job.jobTypeID = JobType.jobTypeID LEFT OUTER JOIN   ProjCoordinator ON Job.projCoordinatorID = ProjCoordinator.prjCoordID  WHERE  (Job.jobID = " + _jobID + ")";

            SqlCommand sqlCom = new SqlCommand(strValue, sqlConn);

            // SqlCommand sqlCom = new SqlCommand();
            // sqlCom.Connection = sqlConn;
            // sqlCom.CommandType = CommandType.StoredProcedure;

            sqlCom.CommandText = strValue;

            sqlCom.Parameters.AddWithValue("@JobID", _jobID);

            SqlDataReader sqlReader = sqlCom.ExecuteReader();

            while (sqlReader.Read())
            {
                txtJobNo.Text = sqlReader["JobNo"].ToString();

                Session["jobNo"] = txtJobNo.Text;

                ddlJobStatus.SelectedValue = sqlReader["jobStatusID"].ToString();

                drpTaskType.SelectedValue = sqlReader["jobTypeID"].ToString();

                if (sqlReader["projCoordinatorID"].ToString() != "")
                    drpCoordinator.SelectedValue = sqlReader["projCoordinatorID"].ToString();

                txtDescription.Text = sqlReader["projectTitle"].ToString();    //jobDesc

                txtRecDate.Text = Convert.ToDateTime(sqlReader["jobReceivedDate"]).ToString("dd/MMM/yyyy");

                if (sqlReader["jobStatusClosedDate"].ToString() != "")
                    txtCloseDate.Text = Convert.ToDateTime(sqlReader["jobStatusClosedDate"]).ToString("dd/MMM/yyyy");

                drpReqVia.SelectedValue = sqlReader["reqServiceID"].ToString();

                txtRequester.Text = sqlReader["jobPosition"].ToString();

                drpActionBy.SelectedValue = sqlReader["DCID"].ToString();

                if (sqlReader["JobDueDate"].ToString() != "")
                    txtTaskDueDate.Text = Convert.ToDateTime(sqlReader["JobDueDate"]).ToString("dd/MMM/yyyy");

                if (sqlReader["taskSubTypeID"].ToString() != "")
                    drpSubTaskType.SelectedValue = sqlReader["taskSubTypeID"].ToString();

                txtTaskRemarks.Text = sqlReader["remarks"].ToString();

                if (sqlReader["jobClosedDate"].ToString() != "")
                    txtCloseDate.Text = Convert.ToDateTime(sqlReader["jobClosedDate"]).ToString("dd/MMM/yyyy");

                txtCntrNO.Text = sqlReader["contractNo"].ToString();

                Session["contractNo"] = txtCntrNO.Text;

                if (sqlReader["deptID"].ToString() != "")
                    ddlDept.SelectedValue = sqlReader["deptID"].ToString();

                //  txtOthers.Text = sqlReader["externalDept"].ToString();

                txtWt.Text = sqlReader["taskPct"].ToString();

                if (ddlDept.SelectedValue == "35")
                {
                    trOthers.Visible = true;
                    txtOthers.Text = sqlReader["externalDept"].ToString();
                }
                else
                {
                    trOthers.Visible = false;
                    txtOthers.Text = "";
                }

            }

            sqlReader.Close();
            sqlConn.Close();
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    protected void btnAdd_Click(object sender, EventArgs e)
    {
        int InchargeID = 0;

        if (lblInchargeID.Text != "")
            InchargeID = Convert.ToInt32(lblInchargeID.Text);

        if (InchargeID == 0)
        {
            InsertStaffData();




            new JobOrderData().SendEmailAlert(new JobOrderData().getEmail(ddlQS.SelectedValue), Session["jobNo"].ToString(), Session["contractNo"].ToString(), "a new Job Order was assigned to you and the details are as follows");



        }
        else
        {
            UpdateRemarks(InchargeID, txtRemarks.Text.Trim());

            //UpdateManagerComments(InchargeID, txtMngrComments.Text.Trim());
            //UpdateInchargeData(InchargeID);
        }

        gvSRJoborder.DataSource = new JobOrderData().GetJobOwnerDetails(_jobID);
        gvSRJoborder.DataBind();

        ClearStaffData();
    }
    private void SendCalanderAlert(string dueDate)
    {
        SmtpClient smtpclient = new SmtpClient("10.250.50.201", 587);
        MailMessage msg = new MailMessage();
        msg.From = new MailAddress("EBSD@ashghal.gov.qa");
        msg.To.Add(new MailAddress("svadakapuram@ashghal.gov.qa"));
        msg.Subject = "Send Calendar Appointment Email";
        msg.Body = "Here is the Body Content";

        StringBuilder str = new StringBuilder();
        str.AppendLine("BEGIN:VCALENDAR");
        str.AppendLine("PRODID:-//" + Session["Username"].ToString());

        str.AppendLine("VERSION:2.0");
        str.AppendLine("METHOD:REQUEST");
        str.AppendLine("BEGIN:VEVENT");

        str.AppendLine(string.Format("DTSTART:{0:yyyyMMddTHHmmssZ}", DateTime.Now.ToString())); //_Parse("02-Apr-2017"))
        str.AppendLine(string.Format("DTSTAMP:{0:yyyyMMddTHHmmssZ}", DateTime.UtcNow));
        str.AppendLine(string.Format("DTEND:{0:yyyyMMddTHHmmssZ}", DateTime.Parse("02-Apr-2017")));

        str.AppendLine("LOCATION: Doha");

        str.AppendLine(string.Format("UID:{0}", Guid.NewGuid()));
        str.AppendLine(string.Format("DESCRIPTION:{0}", msg.Body));
        str.AppendLine(string.Format("X-ALT-DESC;FMTTYPE=text/html:{0}", msg.Body));
        str.AppendLine(string.Format("SUMMARY:{0}", msg.Subject));
        str.AppendLine(string.Format("ORGANIZER:MAILTO:{0}", msg.From.Address));

        str.AppendLine(string.Format("ATTENDEE;CN=\"{0}\";RSVP=TRUE:mailto:{1}", msg.To[0].DisplayName, msg.To[0].Address));

        str.AppendLine("BEGIN:VALARM");
        str.AppendLine("TRIGGER:-PT15M");
        str.AppendLine("ACTION:DISPLAY");
        str.AppendLine("DESCRIPTION:Reminder");
        str.AppendLine("END:VALARM");
        str.AppendLine("END:VEVENT");
        str.AppendLine("END:VCALENDAR");
        System.Net.Mime.ContentType ct = new System.Net.Mime.ContentType("text/calendar");
        ct.Parameters.Add("method", "REQUEST");
        AlternateView avCal = AlternateView.CreateAlternateViewFromString(str.ToString(), ct);
        msg.AlternateViews.Add(avCal);

        try
        {
            smtpclient.Credentials = new System.Net.NetworkCredential(@"Ashghal\EBSD", ConfigurationManager.AppSettings["passWordForReport"].ToString());
            ServicePointManager.ServerCertificateValidationCallback = delegate(object s, X509Certificate certificate, X509Chain chain, SslPolicyErrors sslPolicyErrors) { return true; };

            SendEmail myAction = new SendEmail(SendCompletedCallback);
            myAction.BeginInvoke(smtpclient, msg, null, null);

            smtpclient.Send(msg);
        }
        catch (System.Exception ex)
        {
            Console.WriteLine(ex);
            if (ex.InnerException != null)
            {
                Console.WriteLine("InnerException is: {0}", ex.InnerException);
            }
        }
        finally
        {
            msg.Dispose();
            msg = null;
            smtpclient = null;
        }

    }
    //private void SendCompletedCallback(SmtpClient smtpclient, System.Net.Mail.MailMessage mail) //private static void SendCompletedCallback(object sender, AsyncCompletedEventArgs e
    //{
    //    try
    //    {
    //        smtpclient.Send(mail);
    //    }
    //    catch (System.Exception ex)
    //    {
    //        Console.WriteLine(ex);
    //        if (ex.InnerException != null)
    //        {
    //            Console.WriteLine("InnerException is: {0}", ex.InnerException);
    //        }
    //    }
    //    //finally
    //    //{
    //    //    mail.Dispose();
    //    //    mail = null;
    //    //    // smtpclient = null;
    //    //}
    //}

    //private delegate void SendEmail(SmtpClient smtpclient, System.Net.Mail.MailMessage mail);


    private void OutLookAlertQuick(string eMail, string mailBody)
    {
        SmtpClient smtpclient = new SmtpClient("10.250.50.201", 587);
        System.Net.Mail.MailMessage mail = new System.Net.Mail.MailMessage();
        MailAddress fromaddress = new MailAddress("EBSD@ashghal.gov.qa");
        mail.From = fromaddress;
        mail.To.Add(eMail);
        mail.Subject = ("eBook Job No. " + Session["jobNo"].ToString());
        mail.IsBodyHtml = true;

        // mail.Body = "Please be informed that a new Job Order was assigned to you under the above subject. Please log on to eBook Application to see the details of the Job Order.";

        mail.Body = "<html><body><i style='font-family:Calibri; font-size:15'>Dear eBook Team,</i><br/><br/><i style='font-family:Calibri; font-size:15'>This is an automated alert from Document & Task Management System.</i><br/><br/><i style='font-family:Calibri;font-size:15'>" +
                            "Please be noted that</i><i style='color:Maroon;font-family:Calibri; font-size:15'> Job No. " + Session["jobNo"].ToString() + "</i><i style='font-family:Calibri; font-size:15'> a new Job Order was assigned to you and the details are as follows:-</i><br /><br />" +
                            "<table style='width:80%' border='1'><tr><td align='center' colspan='2' style='background-color:Maroon;color:White;font-family:Calibri;font-size:18;font-weight:bold'>JOB NO: " + Session["jobNo"].ToString() + "</td>" +
                            "</tr><tr><td style='background-color:#B58AA5;font-family:Calibri;font-size:15'><i>Contract No / Project Code </i></td><td style='font-family:Calibri;font-size:15'>" + Session["contractNo"].ToString() + "</td></tr>" +
                            "<tr><td style='background-color:#B58AA5;font-family:Calibri;font-size:15'><i>eBook URL</i></td><td style='font-family:Calibri;font-size:15'>   http://ebsd-testpc/eBook/LoginPage.aspx   </td></tr>" +
                            "<tr><td style='background-color:#B58AA5;font-family:Calibri;font-size:15'><i>Date of Creation</i></td><td style='font-family:Calibri;font-size:15'>" + System.DateTime.Now + "</td></tr>" +
                            "</table><br/><br/><div style='font-family:Calibri; font-size:15'>Best Regards,<br/>eBook Team</div></body></html>";


        smtpclient.EnableSsl = true;
        smtpclient.UseDefaultCredentials = true;

        try
        {
            smtpclient.Credentials = new System.Net.NetworkCredential(@"Ashghal\EBSD", ConfigurationManager.AppSettings["passWordForReport"].ToString());
            ServicePointManager.ServerCertificateValidationCallback = delegate(object s, X509Certificate certificate, X509Chain chain, SslPolicyErrors sslPolicyErrors) { return true; };

            // Added code for qucik mail

            SendEmail myAction = new SendEmail(SendCompletedCallback);
            myAction.BeginInvoke(smtpclient, mail, null, null);
        }
        catch (System.Exception ex)
        {
            Console.WriteLine(ex);
            if (ex.InnerException != null)
            {
                Console.WriteLine("InnerException is: {0}", ex.InnerException);
            }
        }
        //finally
        //{
        //    //mail.Dispose();
        //    //mail = null;
        //    //// smtpclient = null;
        //}

    }
    private void SendCompletedCallback(SmtpClient smtpclient, System.Net.Mail.MailMessage mail) //private static void SendCompletedCallback(object sender, AsyncCompletedEventArgs e
    {
        try
        {
            smtpclient.Send(mail);
        }
        catch (Exception ex)
        {
            Console.WriteLine(ex);
            if (ex.InnerException != null)
            {
                Console.WriteLine("InnerException is: {0}", ex.InnerException);
            }
        }
        //finally
        //{
        //    mail.Dispose();
        //    mail = null;
        //    // smtpclient = null;
        //}
    }



    public void UpdateInchargeData(int inchargeID)
    {
        int _ownerID = 0;
        using (SqlConnection con = new SqlConnection(connValue))
        {
            using (SqlCommand cmd = new SqlCommand())
            {
                try
                {
                    cmd.CommandType = CommandType.Text;
                    cmd.Connection = con;

                    if (lblDistributedBy.Text.Equals(Session["UserID"].ToString()))
                    {
                        cmd.CommandText = "Update JobOwner Set daysToAct =@daysToAct,remarks =@inchargeRemarks,jobPurposeID = @jobPurposeID,StaffRoleID = @StaffRoleID,actionDueDate =@actionDueDate,staffStartDate = @startDate where jobOwnerID = " + inchargeID;

                        cmd.Parameters.AddWithValue("@actionDueDate", Convert.ToDateTime(txtDueDate.Text).ToString("dd/MMM/yyyy"));

                        cmd.Parameters.AddWithValue("@startDate", Convert.ToDateTime(txtStartDate.Text).ToString("dd/MMM/yyyy"));

                        cmd.Parameters.AddWithValue("@daysToAct", 1);
                    }
                    else
                    {
                        cmd.CommandText = "Update JobOwner Set remarks =@inchargeRemarks,jobPurposeID = @jobPurposeID,StaffRoleID = @StaffRoleID where jobOwnerID = " + inchargeID;
                    }

                    //isTLApprove = @isTLApprove ,

                    // cmd.Parameters.AddWithValue("@contactID", _InchargeData.contactID);

                    //cmd.Parameters.AddWithValue("@distributedBy", _currentUserID);


                    cmd.Parameters.AddWithValue("@inchargeRemarks", txtRemarks.Text);
                    cmd.Parameters.AddWithValue("@StaffRoleID", 1);
                    cmd.Parameters.AddWithValue("@jobPurposeID", ddlTask.SelectedValue);
                    cmd.Parameters.AddWithValue("@jobOwnerID", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                    //  cmd.Parameters.AddWithValue("@isTLApprove", chkTLApprove.Checked);

                    con.Open();
                    cmd.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
        }
    }
    private void ClearStaffData()
    {
        ddlQS.SelectedIndex = -1;
        ddlTask.SelectedIndex = -1;

        txtStartDate.Text = "";
        txtDueDate.Text = "";
        // txtWorkDays.Text = "";

        txtRemarks.Text = "";

        lblDistributedBy.Text = "";

        lblInchargeID.Text = "";





        txtMngrComments.Text = "";
        lblDistributedBy.Text = "";




    }

    private void InsertStaffData()
    {
        int _ownerID = 0;

        _ownerID = AddInchargeDataDC(Session["Username"].ToString(), Convert.ToInt32(Session["UserID"]), Convert.ToInt32(Session["SectionID"]), txtDueDate.Text);
    }
    public int AddInchargeDataDC(string userName, int _currentUserID, int _currentSecID, string staffStartDate)
    {
        int _ownerID = 0;
        using (SqlConnection con = new SqlConnection(connValue))
        {
            using (SqlCommand cmd = new SqlCommand())
            {
                try
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Connection = con;

                    cmd.CommandText = "AddJobInchargeDC";

                    cmd.Parameters.AddWithValue("@jobID", _jobID);

                    cmd.Parameters.AddWithValue("@contactID", ddlQS.SelectedValue);
                    cmd.Parameters.AddWithValue("@distributedBy", _currentUserID);

                    cmd.Parameters.AddWithValue("@actionDueDate", txtDueDate.Text);
                    cmd.Parameters.AddWithValue("@daysToAct", 1);

                    cmd.Parameters.AddWithValue("@createUser", userName);

                    cmd.Parameters.AddWithValue("@StaffRoleID", 1);
                    cmd.Parameters.AddWithValue("@jobPurposeID", ddlTask.SelectedValue);

                    cmd.Parameters.AddWithValue("@sectionID", _currentSecID);
                    cmd.Parameters.AddWithValue("@jobOwnerID", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                    if (staffStartDate != "")
                        cmd.Parameters.AddWithValue("@startDate", Convert.ToDateTime(staffStartDate).ToString("dd/MMM/yyyy"));
                    else
                        cmd.Parameters.AddWithValue("@startDate", System.DBNull.Value);


                    con.Open();
                    cmd.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    throw ex;
                }

                return _ownerID = (int)cmd.Parameters["@jobOwnerID"].Value;
            }
        }
    }
    protected void btnUpload_Click1(object sender, EventArgs e)
    {
        UploadFile(CreateFolder(true));
    }


    #region FileUpload

    private void downloadAndViewAttachedFile()
    {
        string filePath = HyperLink1.NavigateUrl;

        if (!File.Exists((string)filePath))
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('File not available at specific path')</script>", false);
            return;
        }
        Response.AddHeader("Content-Disposition", "attachment;filename=\"" + HyperLink1.Text + "\"");
        Response.TransmitFile(filePath);
        Response.End();
    }

    protected void btnDownload_Click(object sender, EventArgs e)
    {
        downloadAndViewAttachedFile();
    }
    protected void lnkFile_Click1(object sender, EventArgs e)
    {
        downloadAndViewAttachedFile();
    }
    string filename = string.Empty;
    private void UploadFile(string newfolderNme)
    {
        string _requestID = txtJobNo.Text;
        if (fileUpload1.PostedFile != null)
        {
            filename = Path.GetFileName(fileUpload1.PostedFile.FileName);

            string filePath = string.Empty;
            if (fileUpload1.HasFile)
            {
                try
                {
                    //  string folderName = ConfigurationManager.AppSettings["NonEBDfolderName"].ToString();
                    filePath = Path.Combine(newfolderNme, filename);

                    HyperLink1.NavigateUrl = filePath;
                    HyperLink1.Text = filename;

                    fileUpload1.SaveAs(filePath);
                }
                catch (Exception ex)
                {
                    Response.Write(ex.Message);

                    string script = "<script type=\"text/javascript\"> displayPopup('" + ex.Message + "'); </script>";
                    ClientScript.RegisterClientScriptBlock(this.GetType(), "myscript", script);

                    return;
                }
            }
            else
            {
                ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Please select file for upload.')</script>", false);
                return;
            }
        }
    }


    private string CreateFolder(bool isUpload)
    {
        string requestID = string.Empty;
        requestID = txtJobNo.Text;
        string newfolderName = null;

        if (!Directory.Exists(ConfigurationManager.AppSettings["ManagerRequestFolderPath"].ToString()))
            Directory.CreateDirectory(ConfigurationManager.AppSettings["ManagerRequestFolderPath"].ToString());

        newfolderName = ConfigurationManager.AppSettings["ManagerRequestFolderPath"].ToString() + "\\" + requestID;
        Directory.CreateDirectory(newfolderName);

        if (newfolderName != null)
        {
            if (!isUpload)
            {
                string fullFilePath = getAllFiles(newfolderName);
                if (fullFilePath != "")
                {
                    HyperLink1.NavigateUrl = fullFilePath;
                    HyperLink1.Text = fullFilePath.Substring(fullFilePath.LastIndexOf("\\") + 1);
                }
                else
                {
                    HyperLink1.Visible = false;
                    lnkFile.Visible = false;
                }
            }
        }
        else
        {
            HyperLink1.Text = "";
            HyperLink1.Visible = false;
            lnkFile.Visible = false;
        }
        return newfolderName;
    }









    //private string CreateFolder(bool isUpload)
    //{
    //    string foldername = "Year_2016";
    //    string requestID = string.Empty;
    //    requestID = txtJobNo.Text;
    //    string newfolderNme = null;
    //    string app_Data = "Applicant Data";

    //    if (!Directory.Exists(@"\\ebsd-sreedhar\SurveyUnit\Backup_Data\" + foldername))
    //        Directory.CreateDirectory(@"\\ebsd-sreedhar\SurveyUnit\Backup_Data\" + foldername);
    //    else
    //    {
    //        newfolderNme = @"\\ebsd-sreedhar\SurveyUnit\Backup_Data\Year_2016\" + requestID + "\\" + app_Data;
    //        Directory.CreateDirectory(newfolderNme);
    //    }
    //    if (newfolderNme != null)
    //    {
    //        if (!isUpload)
    //        {
    //            string fullFilePath = getAllFiles(newfolderNme);
    //            if (fullFilePath != "")
    //            {
    //                HyperLink1.NavigateUrl = fullFilePath;
    //                HyperLink1.Text = fullFilePath.Substring(fullFilePath.LastIndexOf("\\") + 1);
    //            }
    //        }
    //    }
    //    else
    //    {
    //        HyperLink1.Text = "";
    //    }
    //    return newfolderNme;
    //}
    private string getAllFiles(string newPath)
    {
        String[] allfiles = System.IO.Directory.GetFiles(newPath, "*.*", System.IO.SearchOption.AllDirectories);
        string foldrfileName = string.Empty;
        if (allfiles.Length != 0)
        {
            //foreach (var file in allfiles)
            //{
            FileInfo info = new FileInfo(allfiles[0]);
            foldrfileName = info.FullName;
        }

        return foldrfileName;
    }
    private void getFile(string subPath)
    {
        //string subPath = "@"\\ebsd-sreedhar\SurveyUnit\Backup_Data\Year_2016""; // your code goes here

        bool IsExists = System.IO.Directory.Exists(Server.MapPath(subPath));
        if (!IsExists)
            System.IO.Directory.CreateDirectory(Server.MapPath(subPath));
        else
            Directory.CreateDirectory(Path.GetDirectoryName(subPath));


        //if (!Directory.Exists(Path.GetDirectoryName(fileName)))
        //{
        //    Directory.CreateDirectory(Path.GetDirectoryName(fileName));
        //}
    }




    #endregion


    protected void btnSubmit_Click(object sender, EventArgs e)
    {

    }
    public void UpdateJobStatusByUserSelection(int _jobID, int statusID)
    {
        string upDateQuery = string.Empty;

        upDateQuery = "UPDATE Job SET jobStatusID =@jobStatusID WHERE JobID = @JobID";          // jobClosedDate =@jobClosedDate,


        using (SqlConnection sqlCon = new SqlConnection(connValue))
        {
            using (SqlCommand cmd = new SqlCommand())
            {
                cmd.CommandText = upDateQuery;
                cmd.Connection = sqlCon;

                cmd.Parameters.AddWithValue("@JobID", _jobID);
                cmd.Parameters.AddWithValue("@jobStatusID", statusID);

                try
                {
                    sqlCon.Open();
                    cmd.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
        }
    }


    public void UpdateJobStatuCompletedsDate(int _jobID, int statusID)
    {
        string upDateQuery = string.Empty;

        upDateQuery = "UPDATE Job SET jobStatusID =@jobStatusID,jobStatusClosedDate=@jobStatusClosedDate WHERE JobID = @JobID";          // jobClosedDate =@jobClosedDate,


        SqlConnection sqlCon = new SqlConnection(connValue);
        SqlCommand cmd = new SqlCommand();
        cmd.CommandText = upDateQuery;
        cmd.Connection = sqlCon;

        cmd.Parameters.AddWithValue("@JobID", _jobID);


        if (statusID == 3) // On going
            cmd.Parameters.AddWithValue("@jobStatusClosedDate", System.DBNull.Value);
        else
            cmd.Parameters.AddWithValue("@jobStatusClosedDate", System.DateTime.Now.ToString("dd/MMM/yyyy"));

        if (statusID == 3)
            cmd.Parameters.AddWithValue("@jobStatusID", 3);
        else
            cmd.Parameters.AddWithValue("@jobStatusID", 7);

        try
        {
            sqlCon.Open();
            cmd.ExecuteNonQuery();
            sqlCon.Close();
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    public void UpdateJobClosedDate(int _jobID, int statusID)
    {
        string upDateQuery = string.Empty;

        upDateQuery = "UPDATE Job SET jobStatusID =@jobStatusID,jobStatusClosedDate=@jobStatusClosedDate WHERE JobID = @JobID";          // jobClosedDate =@jobClosedDate,


        SqlConnection sqlCon = new SqlConnection(connValue);
        SqlCommand cmd = new SqlCommand();
        cmd.CommandText = upDateQuery;
        cmd.Connection = sqlCon;

        cmd.Parameters.AddWithValue("@JobID", _jobID);


        if (statusID == 3) // On going
            cmd.Parameters.AddWithValue("@jobStatusClosedDate", System.DBNull.Value);
        else
            cmd.Parameters.AddWithValue("@jobStatusClosedDate", System.DateTime.Now.ToString("dd/MMM/yyyy"));

        if (statusID == 3)
            cmd.Parameters.AddWithValue("@jobStatusID", 3);
        else
            cmd.Parameters.AddWithValue("@jobStatusID", 1);

        try
        {
            sqlCon.Open();
            cmd.ExecuteNonQuery();
            sqlCon.Close();
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    private void CloseJob()
    {
        string strUpdateJob = Request.Url.AbsoluteUri;

        Session["UrlRef"] = strUpdateJob;
        Session["JobID"] = _jobID;

        //AccessRightsForReply();
        //if ((checkJobStatusCompleteDate(_jobID) == "") & (!userRightsColl.Contains("9")))
        //{
        //    ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Request Status is still In Progress. Please update the Request Status before closing this Job Order.')</script>", false);
        //}
        //else
        //{
        //    ReplytoCloseCommittedJobs(_jobID);
        //}
    }

    protected void ddlJobStatus_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (userRightsColl.Contains("6")) // Access Right is 6
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Don't have the permission to edit this field ')</script>", false);
        }
        else if (getStaffStatus() == true)
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Action By Staff not yet completed')</script>", false);
            ddlJobStatus.SelectedValue = "3";
        }
        else
        {
            if (ddlJobStatus.SelectedIndex != 0)
            {
                Session["lnkJobID"] = _jobID;

                if ((ddlJobStatus.SelectedValue == "2") || (ddlJobStatus.SelectedValue == "5"))     //Rej or Cancelleted 2 n 5
                {
                    UpdateJobStatusByUserSelection(_jobID, Convert.ToInt32(ddlJobStatus.SelectedValue));
                }
                else if ((ddlJobStatus.SelectedValue == "3"))  // ongoing
                {
                    UpdateJobStatusByUserSelection(_jobID, Convert.ToInt32(ddlJobStatus.SelectedValue));
                }
                else if ((ddlJobStatus.SelectedValue == "7"))               // Close n Completed 7
                {
                    UpdateJobStatuCompletedsDate(_jobID, Convert.ToInt32(ddlJobStatus.SelectedValue));
                    txtWt.Text = "100";
                }
                else if (ddlJobStatus.SelectedValue == "1")
                {
                    // CloseJob();

                    UpdateJobClosedDate(_jobID, Convert.ToInt32(ddlJobStatus.SelectedValue));

                    txtWt.Text = "100";
                }
                else
                {
                    UpdateJobStatusByUserSelection(_jobID, Convert.ToInt32(ddlJobStatus.SelectedValue));
                }

                Fill_JobOrder_Information(_jobID);
            }
        }
    }
    private Boolean getStaffStatus()
    {
        Boolean chkStaffStatus = false;

        try
        {
            SqlConnection sqlConn = new SqlConnection(connValue);
            sqlConn.Open();

            string strValue = "SELECT jobOwnerID FROM  JobOwner WHERE (jobID = @JobID) AND (jobOwnerStatusID = 3)";

            SqlCommand sqlCom = new SqlCommand(strValue, sqlConn);
            sqlCom.CommandText = strValue;

            sqlCom.Parameters.AddWithValue("@JobID", _jobID);
            SqlDataReader sqlReader = sqlCom.ExecuteReader();

            if (sqlReader.HasRows)
                chkStaffStatus = true;
            else
                chkStaffStatus = false;

            sqlReader.Close();
            sqlConn.Close();
        }
        catch (Exception ex)
        {
            throw ex;
        }

        return chkStaffStatus;
    }
    protected void btnUpdate_Click(object sender, EventArgs e)
    {
        UpdateJobOrder(_jobID);
    }
    public void UpdateJobOrder(int upd_JobID)
    {
        SqlConnection sqlCon = new SqlConnection(connValue);
        SqlCommand cmd = new SqlCommand();
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.CommandText = "Task_UpdateMngrLog";
        cmd.Connection = sqlCon;

        cmd.Parameters.AddWithValue("@Job_id", upd_JobID);

        if (drpTaskType.SelectedIndex != 0)
            cmd.Parameters.AddWithValue("@Job_Type_id", drpTaskType.SelectedValue);
        else
            cmd.Parameters.AddWithValue("@Job_Type_id", drpTaskType.SelectedValue);

        if (ddlJobStatus.SelectedIndex != 0)
            cmd.Parameters.AddWithValue("@Job_Status_id", ddlJobStatus.SelectedValue);
        else
            cmd.Parameters.AddWithValue("@Job_Status_id", System.DBNull.Value);

        cmd.Parameters.AddWithValue("@Project_Code", "");

        cmd.Parameters.AddWithValue("@jobDesc", txtDescription.Text);

        cmd.Parameters.AddWithValue("@Project_Title", txtDescription.Text);

        cmd.Parameters.AddWithValue("@ContractorID", System.DBNull.Value);

        cmd.Parameters.AddWithValue("@ConsultantID", System.DBNull.Value);

        if (ddlDept.SelectedIndex != 0)
            cmd.Parameters.AddWithValue("@DepartmentID", ddlDept.SelectedValue);  // Not Applicable
        else
            cmd.Parameters.AddWithValue("@DepartmentID", 22);  // EBD

        cmd.Parameters.AddWithValue("@QSID", System.DBNull.Value);

        cmd.Parameters.AddWithValue("@PEID", System.DBNull.Value);

        cmd.Parameters.AddWithValue("@CEID", System.DBNull.Value);

        cmd.Parameters.AddWithValue("@gradeID", System.DBNull.Value);

        cmd.Parameters.AddWithValue("@remarks", txtTaskRemarks.Text);

        cmd.Parameters.AddWithValue("@addendumNO", System.DBNull.Value);

        cmd.Parameters.AddWithValue("@contractTypeID", System.DBNull.Value);

        cmd.Parameters.AddWithValue("@workDays", 1);

        cmd.Parameters.AddWithValue("@dueDate", Convert.ToDateTime(txtTaskDueDate.Text).ToString("dd/MMM/yyyy"));

        cmd.Parameters.AddWithValue("@updateUser", Session["UserName"]);

        cmd.Parameters.AddWithValue("@submissionNo", System.DBNull.Value);

        cmd.Parameters.AddWithValue("@attRecDate", System.DBNull.Value);

        cmd.Parameters.AddWithValue("@dcRejectionID", System.DBNull.Value);

        cmd.Parameters.AddWithValue("@projStstusID", System.DBNull.Value);

        cmd.Parameters.AddWithValue("@receivedSurveyTeamOn", System.DBNull.Value);

        cmd.Parameters.AddWithValue("@sentOnSurveyTeam", System.DBNull.Value);

        cmd.Parameters.AddWithValue("@reviewDate", System.DBNull.Value);

        cmd.Parameters.AddWithValue("@committmentNo", txtCntrNO.Text);

        cmd.Parameters.AddWithValue("@projectCode", System.DBNull.Value);

        if (drpCoordinator.SelectedIndex != 0)
            cmd.Parameters.AddWithValue("@projCoordinatorID", drpCoordinator.SelectedValue);
        else
            cmd.Parameters.AddWithValue("@projCoordinatorID", System.DBNull.Value);

        cmd.Parameters.AddWithValue("@requesterName", txtRequester.Text);

        if (drpActionBy.SelectedIndex != 0)
            cmd.Parameters.AddWithValue("@dcID", drpActionBy.SelectedValue);
        else
            cmd.Parameters.AddWithValue("@dcID", System.DBNull.Value);

        if (drpReqVia.SelectedIndex != 0)
            cmd.Parameters.AddWithValue("@recVia", drpReqVia.SelectedValue);
        else
            cmd.Parameters.AddWithValue("@recVia", System.DBNull.Value);

        if (drpSubTaskType.SelectedIndex != 0)
            cmd.Parameters.AddWithValue("@subTypeID", drpSubTaskType.SelectedValue);
        else
            cmd.Parameters.AddWithValue("@subTypeID", System.DBNull.Value);

        cmd.Parameters.AddWithValue("@taskPct", txtWt.Text);

        cmd.Parameters.AddWithValue("@externalDept", txtOthers.Text);

        try
        {
            sqlCon.Open();
            cmd.ExecuteNonQuery();
            sqlCon.Close();
        }
        catch (Exception ex)
        {
            throw ex;
        }
        //lblResult.Text = "Data Updated Successfully";
        // Response.Write();
    }
    protected void drpTaskType_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void btnDelete_Click(object sender, EventArgs e)
    {
        int InchargeID = Convert.ToInt32(lblInchargeID.Text);
        new JobOrderData().DeleteIncharge(InchargeID);

        gvSRJoborder.DataSource = new JobOrderData().GetMngrJobOwnerDetails(_jobID);
        gvSRJoborder.DataBind();

        btnAddUpdate.Text = "Add Staff";
        ClearStaffData();

    }
    protected void btnSearch_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/ManagerTask/SerachTask.aspx", false);
    }
    protected void gvSRJoborder_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            DropDownList l = (DropDownList)e.Row.FindControl("ddljobtype");

            PopulateDropDownBox_Staff(l, "SELECT JobStatusid,JobStatusName as JobStatus FROM jobStatus where JobStatusid in(2,3,6,7) ", "JobStatusid", "JobStatus");  // where JobStatusid in(5,6,7,8)

            TextBox lm = (TextBox)e.Row.FindControl("jobid");
            TextBox afr = (TextBox)e.Row.FindControl("TextBox1");
            TextBox InchargeID = (TextBox)e.Row.FindControl("txtInchargeID");

            Session["InchargeID"] = InchargeID.Text;

            string lk = lm.Text;

            l.ToolTip = InchargeID.Text;

            l.SelectedValue = afr.Text;

            Session["StatusVal"] = l.SelectedValue;

            l.SelectedIndexChanged += new EventHandler(SelectedIndexChanged);

            TextBox txtdate = (TextBox)e.Row.FindControl("lblJoindate");
            txtdate.ToolTip = InchargeID.Text;
            txtdate.TextChanged += new EventHandler(txtdate_TextChanged);
            Session["JobActionDueDate"] = txtdate.Text;

            Label lblStaff = (Label)e.Row.FindControl("txtStaff");

            Label lblDistributedBy = (Label)e.Row.FindControl("txtDistrubed");

            Label lblConactID = (Label)e.Row.FindControl("txtCnctID");

            TextBox _txtDocID = (TextBox)e.Row.FindControl("txtDocID");
            Session["statusdocID"] = _txtDocID.Text;
            Session["contactID"] = lblConactID.Text;

            Label lblDistribID = (Label)e.Row.FindControl("txtDistributedBy");
            Label lblTeamLeadID = (Label)e.Row.FindControl("lblTeamLead");

            //Label lblRoleID = (Label)e.Row.FindControl("txtRoleID");
            // chkDelete.CheckedChanged += new EventHandler(chkstate_CheckedChanged);                        

            if ((!lblConactID.Text.Equals(Session["userID"])))
            {
                l.Enabled = false;
            }
            if (lblConactID.Text.Equals(Session["userID"]))
            {
                //  btnOutlook.Enabled = true;
                Session["ActionDate"] = txtdate.Text;
            }
            if (!lblDistribID.Text.Equals(Session["userID"]))
            {
                txtdate.Enabled = false;
            }

        }
    }
    protected void btnStaffDelete_Click(object sender, EventArgs e)
    {
        int InchargeID = Convert.ToInt32(lblInchargeID.Text);
        new JobOrderData().DeleteIncharge(InchargeID);
    }

    private int getStaff_Key(ref int _contactID, ref int _ownerID)
    {
        //  int _contactID = 0;
        // int _ownerID = 0;

        int _coordID = 0;

        SqlConnection cnn = new SqlConnection(connValue);
        cnn.Open();
        SqlCommand cmm = new SqlCommand();
        cmm.Connection = cnn;
        cmm.CommandText = "SELECT TOP (1)  JobOwner.contactID, JobOwner.jobOwnerID, JobOwner.jobID,Job.projCoordinatorID FROM  Job INNER JOIN JobOwner ON Job.jobID = JobOwner.jobID AND Job.dcID = JobOwner.contactID where Job.jobID = @jobID";
        cmm.Parameters.AddWithValue("@jobID", _jobID);
        SqlDataReader sqlDtReader = cmm.ExecuteReader();
        if (sqlDtReader.HasRows)
        {
            while (sqlDtReader.Read())
            {
                _contactID = Convert.ToInt32(sqlDtReader["contactID"]);
                _ownerID = Convert.ToInt32(sqlDtReader["jobOwnerID"]);
                _coordID = Convert.ToInt32(sqlDtReader["projCoordinatorID"]);
            }
        }
        sqlDtReader.Close();
        cnn.Close();

        return _coordID;
    }
    private Boolean getStatus_KeyDown(int _inchargeID)
    {
        Boolean chkSatus = false;
        int _staffID = 0; int _jobOwnerID = 0; int _coordID = 0;

        _coordID = getStaff_Key(ref _staffID, ref _jobOwnerID);


        SqlConnection cnn = new SqlConnection(connValue);
        cnn.Open();
        SqlCommand cmm = new SqlCommand();
        cmm.Connection = cnn;


        string strQuery = string.Empty;

        if (Session["UserID"].Equals(_coordID))
        {
            strQuery = "Select jobOwnerStatusID from JobOwner where jobid = @jobID and jobOwnerID > @jobOwnerID and jobOwnerStatusID <>7"; ;
        }
        else
        {
            strQuery = "Select jobOwnerStatusID from JobOwner where jobid = @jobID and jobOwnerID <> @jobOwnerID and jobOwnerStatusID <>7"; ;
        }
        cmm.CommandText = strQuery;

        cmm.Parameters.AddWithValue("@jobID", _jobID);
        cmm.Parameters.AddWithValue("@jobOwnerID", _jobOwnerID);

        SqlDataReader sqlDtReader = cmm.ExecuteReader();
        if (sqlDtReader.HasRows)
        {
            chkSatus = true;
        }

        sqlDtReader.Close();
        cnn.Close();

        return chkSatus;
    }


    #region MyRegion

    private int getKeyStaff(ref int _actionBy, ref int _coordID)
    {
        int _ownerID = 0;

        SqlConnection cnn = new SqlConnection(connValue);
        cnn.Open();
        SqlCommand cmm = new SqlCommand();
        cmm.Connection = cnn;
        cmm.CommandText = "SELECT TOP (1)  JobOwner.contactID, JobOwner.jobOwnerID, JobOwner.jobID,Job.projCoordinatorID FROM  Job INNER JOIN JobOwner ON Job.jobID = JobOwner.jobID AND Job.dcID = JobOwner.contactID where Job.jobID = @jobID";
        cmm.Parameters.AddWithValue("@jobID", _jobID);
        SqlDataReader sqlDtReader = cmm.ExecuteReader();
        if (sqlDtReader.HasRows)
        {
            while (sqlDtReader.Read())
            {
                _actionBy = Convert.ToInt32(sqlDtReader["contactID"]);
                _ownerID = Convert.ToInt32(sqlDtReader["jobOwnerID"]);
                _coordID = Convert.ToInt32(sqlDtReader["projCoordinatorID"]);
            }
        }
        sqlDtReader.Close();
        cnn.Close();

        return _ownerID;
    }

    private Boolean UnderCoord_Records(int _ownerID)
    {
        Boolean chkSatus_Coord = false;
        string strQuery = "select * from JobOwner where jobid = @jobID and jobOwnerID >@jobOwnerID and jobOwnerStatusID = 3";

        SqlConnection cnn = new SqlConnection(connValue);
        cnn.Open();
        SqlCommand cmm = new SqlCommand();
        cmm.Connection = cnn;
        cmm.CommandText = strQuery;
        cmm.Parameters.AddWithValue("@jobID", _jobID);
        cmm.Parameters.AddWithValue("@jobOwnerID", _ownerID);

        SqlDataReader sqlDtReader = cmm.ExecuteReader();
        if (sqlDtReader.HasRows)
        {
            chkSatus_Coord = false;
        }

        sqlDtReader.Close();
        cnn.Close();

        return chkSatus_Coord;
    }

    private Boolean CheckCoordStatus(int _coordID)
    {
        Boolean chkSatus_Coord = false;

        SqlConnection cnn = new SqlConnection(connValue);
        cnn.Open();
        SqlCommand cmm = new SqlCommand();
        cmm.Connection = cnn;

        string strQuery = string.Empty;
        //  strQuery = "select * from JobOwner where jobID = @jobID and jobOwnerStatusID =3 and contactID<> " + _coordID + ""; 

        strQuery = "Select * from JobOwner where jobID = @jobID and jobOwnerStatusID =3 and jobPurposeID != 18 ";

        cmm.CommandText = strQuery;
        cmm.Parameters.AddWithValue("@jobID", _jobID);

        SqlDataReader sqlDtReader = cmm.ExecuteReader();
        if (sqlDtReader.HasRows)
        {
            chkSatus_Coord = true;
        }

        sqlDtReader.Close();
        cnn.Close();

        return chkSatus_Coord;
    }

    private Boolean CheckIsStaff(int _coordID, int _actionBy, int _ownerID)
    {
        Boolean chkSatus_ActoinBy = false;

        SqlConnection cnn = new SqlConnection(connValue);
        cnn.Open();
        SqlCommand cmm = new SqlCommand();
        cmm.Connection = cnn;

        string strQuery = string.Empty;

        strQuery = "Select contactID,jobPurposeID,jobOwnerStatusID from JobOwner where jobOwnerID = @jobOwnerID";

        cmm.CommandText = strQuery;
        cmm.Parameters.AddWithValue("@jobOwnerID", _ownerID);

        SqlDataReader sqlDtReader = cmm.ExecuteReader();
        if (sqlDtReader.HasRows)
        {
            chkSatus_ActoinBy = true;
        }

        sqlDtReader.Close();
        cnn.Close();

        return chkSatus_ActoinBy;
    }


    private Boolean CheckActionByStatus(int _coordID, int _actionBy)
    {
        Boolean chkSatus_ActoinBy = false;

        SqlConnection cnn = new SqlConnection(connValue);
        cnn.Open();
        SqlCommand cmm = new SqlCommand();
        cmm.Connection = cnn;

        string strQuery = string.Empty;
        strQuery = "select * from JobOwner where jobID = @jobID and jobOwnerStatusID =3 and contactID not in(" + _coordID + "," + _actionBy + ")";

        cmm.CommandText = strQuery;
        cmm.Parameters.AddWithValue("@jobID", _jobID);

        SqlDataReader sqlDtReader = cmm.ExecuteReader();
        if (sqlDtReader.HasRows)
        {
            chkSatus_ActoinBy = true;
        }

        sqlDtReader.Close();
        cnn.Close();

        return chkSatus_ActoinBy;
    }


    private string getEmail(string contactID)
    {
        string streMail = string.Empty;
        try
        {
            SqlConnection sqlConn = new SqlConnection(connValue);
            sqlConn.Open();
            SqlCommand sqlCom = new SqlCommand("Select emailAddress from Contact where ContactID = " + Convert.ToInt32(contactID) + "", sqlConn);
            SqlDataReader sqlReader = sqlCom.ExecuteReader();
            while (sqlReader.Read())
            {
                streMail = sqlReader["emailAddress"].ToString();
            }
            sqlReader.Close();
            sqlConn.Close();
        }
        catch (System.Exception ex)
        {
            throw ex;
        }

        return streMail;
    }
    private delegate void SendEmail(SmtpClient smtpclient, System.Net.Mail.MailMessage mail);


    #endregion




    private int getandChkData(int _ownerID, int _statusID)
    {
        SqlConnection cnn = new SqlConnection(connValue);
        cnn.Open();
        SqlCommand cmm = new SqlCommand();
        cmm.Connection = cnn;
        cmm.CommandText = "BBB_ChkSt";
        cmm.CommandType = CommandType.StoredProcedure;

        cmm.Parameters.AddWithValue("@jobID", _jobID);
        cmm.Parameters.AddWithValue("@userID", Convert.ToInt32(Session["UserID"]));
        cmm.Parameters.AddWithValue("@ownerID", _ownerID);
        cmm.Parameters.AddWithValue("@statID", _statusID);
        cmm.Parameters.AddWithValue("@rCnt", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

        cmm.ExecuteNonQuery();
        cnn.Close();

        return (int)cmm.Parameters["@rCnt"].Value;
    }
    private void updateOngoingStatus(int _ownerID, int _statusID)
    {
        SqlConnection cnn = new SqlConnection(connValue);
        cnn.Open();
        SqlCommand cmm = new SqlCommand();
        cmm.Connection = cnn;
        cmm.CommandText = "update JobOwner set jobOwnerStatusID = @statID,completionDate = @completionDate where jobOwnerID =@ownerID";
        cmm.CommandType = CommandType.Text;

        cmm.Parameters.AddWithValue("@ownerID", _ownerID);
        cmm.Parameters.AddWithValue("@statID", _statusID);
        cmm.Parameters.AddWithValue("@completionDate", System.DBNull.Value);

        cmm.ExecuteNonQuery();
        cnn.Close();
    }

    private void Temp()
    {
        //1	Closed	 ,        2	Rejected	,        3	On-going	,        4	Pending	PEN	
        //5	Cancelled	,        6	On Hold	,        7	Completed	COM	,        8	Under Process with EBSD	UPE	
        //9	Waiting Consultant Signature	WCS	,        10	Pending with the Committee	PWC	,        11	Waiting Dept. Manager Signature	WMS,  
        // 12	Waiting PB From Consultant	WPB	,        13	Waiting President Signature	WPS	


        DropDownList ddl = new DropDownList();
        if (ddl.SelectedIndex != 0)
        {
            string ID = ddl.ID;
            string g = ddl.SelectedValue;
            string inchargeID = ddl.ToolTip;

            Session["_InchargeID"] = inchargeID;
            Session["StatusValCurrent"] = ddl.SelectedValue;

            if (ddl.SelectedValue == "7")
            {
                int _CoordID = 0; int _actionByID = 0; int _actionOwnerID = 0;
                _actionOwnerID = getKeyStaff(ref _actionByID, ref _CoordID);

                // execStatusChk(Convert.ToInt32(inchargeID));

                int rowFnd = getandChkData(Convert.ToInt32(inchargeID), Convert.ToInt32(ddl.SelectedValue));
                if (rowFnd != 0)
                {
                    // ddlJobStatus.SelectedValue = "3";
                    ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Action By Staff not yet completed')</script>", false);
                    ddl.SelectedValue = "3";
                }
                else
                {
                    gvSRJoborder.DataSource = new JobOrderData().GetJobOwnerDetails(_jobID);
                    gvSRJoborder.DataBind();
                }

                //if (Session["UserID"].Equals(_CoordID.ToString()))
                //{
                //    if (UnderCoord_Records(Convert.ToInt32(inchargeID)) == true)
                //    {
                //        ddl.SelectedValue = "3";
                //        ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Under ActionBy,Action By Staff not yet completed')</script>", false);
                //    }
                //    //else if (CheckCoordStatus(_CoordID) == true)
                //    //{
                //    //    ddl.SelectedValue = "3";
                //    //    ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Under Coordination,Action By Staff not yet completed')</script>", false);
                //    //}
                //    else
                //    {
                //        new JobOrderData().UpdateJobDoneCheckBox(Convert.ToInt32(inchargeID), Convert.ToInt32(ddl.SelectedValue));
                //        new JobOrderData().UpdateJobStatus(Convert.ToInt32(inchargeID), Convert.ToInt32(ddl.SelectedValue), Session["UserName"].ToString());

                //        gvSRJoborder.DataSource = new JobOrderData().GetJobOwnerDetails(_jobID);
                //        gvSRJoborder.DataBind();
                //    }
                //}
                //else if (Session["UserID"].Equals(_actionByID.ToString()))
                //{
                //    if (CheckActionByStatus(_CoordID, _actionByID) == true)
                //    {
                //        ddl.SelectedValue = "3";
                //        ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Under ActionBy,Action By Staff not yet completed')</script>", false);
                //    }
                //    else
                //    {
                //        new JobOrderData().UpdateJobDoneCheckBox(Convert.ToInt32(inchargeID), Convert.ToInt32(ddl.SelectedValue));
                //        new JobOrderData().UpdateJobStatus(Convert.ToInt32(inchargeID), Convert.ToInt32(ddl.SelectedValue), Session["UserName"].ToString());

                //        gvSRJoborder.DataSource = new JobOrderData().GetJobOwnerDetails(_jobID);
                //        gvSRJoborder.DataBind();
                //    }
                //}
                ////else if (Session["UserID"].Equals(_CoordID.ToString()))
                ////{


                ////    if (CheckCoordStatus(_CoordID) == true)
                ////    {                        
                ////        ddl.SelectedValue = "3";
                ////        ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Under Coordination,Action By Staff not yet completed')</script>", false);                       
                ////    }
                ////    else
                ////    {
                ////        new JobOrderData().UpdateJobDoneCheckBox(Convert.ToInt32(inchargeID), Convert.ToInt32(ddl.SelectedValue));
                ////        new JobOrderData().UpdateJobStatus(Convert.ToInt32(inchargeID), Convert.ToInt32(ddl.SelectedValue), Session["UserName"].ToString());

                ////        gvSRJoborder.DataSource = new JobOrderData().GetJobOwnerDetails(_jobID);
                ////        gvSRJoborder.DataBind();
                ////    }
                ////}                
                //else
                //{
                //    new JobOrderData().UpdateJobDoneCheckBox(Convert.ToInt32(inchargeID), Convert.ToInt32(ddl.SelectedValue));
                //    new JobOrderData().UpdateJobStatus(Convert.ToInt32(inchargeID), Convert.ToInt32(ddl.SelectedValue), Session["UserName"].ToString());

                //    gvSRJoborder.DataSource = new JobOrderData().GetJobOwnerDetails(_jobID);
                //    gvSRJoborder.DataBind();
                //}



                ////if (checkJobLevelStaff() == false)
                ////{
                ////    new JobOrderData().UpdateJobDoneCheckBox(Convert.ToInt32(inchargeID), Convert.ToInt32(ddl.SelectedValue));

                ////    new JobOrderData().UpdateJobStatus(Convert.ToInt32(inchargeID), Convert.ToInt32(ddl.SelectedValue), Session["UserName"].ToString());
                ////    gvSRJoborder.DataSource = new JobOrderData().GetJobOwnerDetails(_jobID);
                ////    gvSRJoborder.DataBind();

                ////}
                ////else if (getStatus_KeyDown(Convert.ToInt32(inchargeID)) == true)
                ////{
                ////    ddl.SelectedValue = "3";
                ////    ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Action By Staff not yet completed')</script>", false);
                ////}
                ////else
                ////{
                ////    new JobOrderData().UpdateJobDoneCheckBox(Convert.ToInt32(inchargeID), Convert.ToInt32(ddl.SelectedValue));
                ////    new JobOrderData().UpdateJobStatus(Convert.ToInt32(inchargeID), Convert.ToInt32(ddl.SelectedValue), Session["UserName"].ToString());

                ////    gvSRJoborder.DataSource = new JobOrderData().GetJobOwnerDetails(_jobID);
                ////    gvSRJoborder.DataBind();
                ////}

            }
            else
            {
                if (ddl.SelectedValue == "3" || ddl.SelectedValue == "7")
                    new JobOrderData().UpdateJobDoneCheckBox(Convert.ToInt32(inchargeID), Convert.ToInt32(ddl.SelectedValue));

                if (ddl.SelectedValue != "7")
                {
                    new JobOrderData().UpdateCompletionDate(Convert.ToInt32(inchargeID));
                    //string eMail = getMailAddress(Convert.ToInt32(inchargeID));
                    //OutLookAlert(eMail, "");
                }

                new JobOrderData().UpdateJobStatus(Convert.ToInt32(inchargeID), Convert.ToInt32(ddl.SelectedValue), Session["UserName"].ToString());

                gvSRJoborder.DataSource = new JobOrderData().GetJobOwnerDetails(_jobID);
                gvSRJoborder.DataBind();
            }
        }
    }
    protected void btnClr_Click(object sender, EventArgs e)
    {
        lblInchargeID.Text = "";
        btnAddUpdate.Text = "Add Staff";
        ddlQS.SelectedIndex = 0;
        ddlTask.SelectedIndex = 0;

        txtStartDate.Text = "";
        txtDueDate.Text = "";

        txtRemarks.Text = "";
        txtMngrComments.Text = "";



    }
    private void UpdateRemarks(int jobOwnerID, string remarks)
    {
        if (txtRemarks.Text.Trim() != "" && lblInchargeID.Text.Trim() != "")
        {
            SqlConnection con = new SqlConnection(connValue);
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.Text;
            cmd.Connection = con;

            cmd.CommandText = "Update JobOwner set remarks=@remarks,remarksDate=@remarksDate Where jobOwnerID=@jobOwnerID";
            cmd.Parameters.AddWithValue("@remarks", remarks);
            cmd.Parameters.AddWithValue("@remarksDate", DateTime.Now.ToString());
            cmd.Parameters.AddWithValue("@jobOwnerID", jobOwnerID);

            try
            {
                con.Open();
                cmd.ExecuteNonQuery();
                con.Dispose();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                con.Close();
            }
        }

    }

    private void UpdateManagerComments(int jobOwnerID, string remarks)
    {
        if (txtMngrComments.Text.Trim() != "" && lblInchargeID.Text.Trim() != "")
        {
            SqlConnection con = new SqlConnection(connValue);
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.Text;
            cmd.Connection = con;

            cmd.CommandText = "Update JobOwner set coordRemarks=@coordRemarks,coordRemarksDate=@coordRemarksDate Where jobOwnerID=@jobOwnerID";
            cmd.Parameters.AddWithValue("@coordRemarks", remarks);
            cmd.Parameters.AddWithValue("@coordRemarksDate", DateTime.Now.ToString());
            cmd.Parameters.AddWithValue("@jobOwnerID", jobOwnerID);

            try
            {
                con.Open();
                cmd.ExecuteNonQuery();
                con.Dispose();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                con.Close();
            }
        }

    }
    protected void txtRemarks_TextChanged(object sender, EventArgs e)
    {
        if (lblInchargeID.Text != "")
        {
            UpdateRemarks(Convert.ToUInt16(lblInchargeID.Text), txtRemarks.Text.Trim());
        }
    }
    protected void txtMngrComments_TextChanged(object sender, EventArgs e)
    {
        if (lblInchargeID.Text != "")
        {
            UpdateManagerComments(Convert.ToUInt16(lblInchargeID.Text), txtMngrComments.Text.Trim());
        }
    }

    protected void ddlDept_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlDept.SelectedValue == "35")
        {
            trOthers.Visible = true;
        }
        else
        {
            trOthers.Visible = false;
        }
    }

    #endregion


}