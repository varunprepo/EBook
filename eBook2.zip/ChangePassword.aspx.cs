﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
public partial class ChangePassword : System.Web.UI.Page
{
    UtilityClass uCls = null;
    string connValue = ConfigurationManager.ConnectionStrings["EBSDEBookConn"].ToString();
    DAL dal = null;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["UserName"] == null)
        {
            Response.Redirect("~/LoginPage.aspx", false);
            return;
        }
        else
        {
            if (!IsPostBack)
            {
                uCls = new UtilityClass(this.Page);
                dal = new DAL(connValue);
                if (dal.ConnectDB(this.Page) == 'E')
                    return;
                //uCls.DisplayLabels(dal, true);
                dal.DisconnectDB();
            }
        }
    }
    
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        if (Session["UserName"] == null)
        {
            Response.Redirect("~/LoginPage.aspx", false);
            return;
        }
        else
        {
            UtilityClass uCls = new UtilityClass(this.Page);
            dal = new DAL(connValue);
            if (dal.ConnectDB(this.Page) == 'E')
                return;
            // uCls.DisplayLabels(dal, true);
            bool isPwdValidated = uCls.AuthenticateUserPassword(Session["UserName"].ToString(), Session["IssuedByEmailAddress"].ToString(), txtOldPassword.Text, dal);
            if (isPwdValidated == false)
            {
                ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Entered old password is an invalid password, Enter a valid password');</script>", false);
                txtOldPassword.Text = "";
                txtOldPassword.Focus();
                txtNewPassword.Value = "";
                txtConfirmPassword.Value = "";
                return;
            }
            //else
            //{                 
            //    txtNewPassword.Disabled = false;
            //    txtConfirmPassword.Disabled = false;
            //}
            using (SqlConnection sqlConn = new SqlConnection(connValue))
            {
                try
                {
                    sqlConn.Open();
                    SqlCommand sqlCmd = new SqlCommand();
                    uCls = new UtilityClass(this.Page);
                    sqlCmd.Connection = sqlConn;
                    sqlCmd.CommandType = CommandType.StoredProcedure;
                    sqlCmd.CommandText = "UpdateUserPwd";

                    sqlCmd.Parameters.AddWithValue("@contactID", Convert.ToInt32(Session["UserID"]));

                    sqlCmd.Parameters.AddWithValue("@userName", Session["UserName"].ToString());
                    sqlCmd.Parameters.AddWithValue("@emailAddress", Session["IssuedByEmailAddress"].ToString());
                    sqlCmd.Parameters.AddWithValue("@pwd", txtConfirmPassword.Value);
                    sqlCmd.Parameters.AddWithValue("@updateUser", Session["UserName"].ToString());
                    sqlCmd.Parameters.AddWithValue("@updateDate", DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss"));

                    sqlCmd.ExecuteNonQuery();

                    string script = "this.window.close();";
                    ClientScript.RegisterClientScriptBlock(typeof(string), "REFRESH_PARENT", script, true);



                    //Response.Redirect("~/LoginPage.aspx", false);
                    //if (sqlCmd.ExecuteNonQuery() == 1)
                    //{
                    //    //ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Password is changed successfully')</script>", false);
                    //    string script = "this.window.close();";
                    //    ClientScript.RegisterClientScriptBlock(typeof(string), "REFRESH_PARENT", script, true);
                    //    //Response.Redirect("~/LoginPage.aspx", false);
                    //}
                }
                catch (Exception ex)
                {
                    ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Error occurred while performing database operation')</script>", false);
                }
                finally
                {
                    sqlConn.Close();
                }
            }
        }
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/LoginPage.aspx", false);
    }
}