﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Data.SqlClient;
using System.Data;

public partial class ChangePassword : System.Web.UI.Page
{
    string connValue = System.Configuration.ConfigurationManager.ConnectionStrings["EBSDEBookConn"].ConnectionString;
    int upd_UserID = 0;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["UserName"] != null)
            {
                txtUserName.Text = Session["UserName"].ToString();
                
            }
            else
            {
                Response.Redirect("~/LoginPage.aspx", false);
            }
            //ViewUsersData(upd_UserID);

            //if (upd_UserID != 0)
            //{               
            //    Session["upd_UserID"] = upd_UserID.ToString();
            //}           
        }
    }
    protected void btnUpdate_Click(object sender, EventArgs e)
    {
        if (Session["UserID"] != null)
            UpdateContactData(Convert.ToInt32(Session["UserID"]));   // UpdateUserProfile

        this.ClientScript.RegisterClientScriptBlock(this.GetType(), "Close", "window.close()", true);

        ScriptManager.RegisterStartupScript(this, typeof(string), "script",
                 "<script type=text/javascript> parent.location.href = parent.location.href;</script>", false);
    } 

    private void ViewUsersData(int userID)
    {
        try
        {
            SqlConnection sqlConn = new SqlConnection(connValue);
            sqlConn.Open();

            string viewSql = "SELECT  Contact.UserName, UserSecurityProfile.profilename, Contact.EmailAddress, Contact.BusinessPhone, " +
                          " (Contact.firstName + ' ' + Contact.lastName) AS ActualName, Contact.LogOn,Contact.sectionID,Contact.teamLeaderID,Contact.userProfileID,Contact.password,Contact.isActive  " +
                       " FROM Contact INNER JOIN UserSecurityProfile ON Contact.userProfileID = UserSecurityProfile.userProfileID  WHERE CONTACTID = " + userID + "";

            SqlCommand sqlCom = new SqlCommand(viewSql, sqlConn);
            SqlDataReader sqlReader = sqlCom.ExecuteReader();

            while (sqlReader.Read())
            {
                txtUserName.Text = sqlReader["userName"].ToString();
                txtPswrd.Text = sqlReader["password"].ToString();
                hiddpassword.Value = sqlReader["password"].ToString();
                if (txtPswrd.TextMode == TextBoxMode.Password)
                {
                    txtPswrd.Attributes.Add("value", txtPswrd.Text);
                }               
            }
            sqlReader.Close();
            sqlConn.Close();
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    private void UpdateContactData(int upd_UserID)
    {
        UtilityClass uCls = new UtilityClass(this.Page);     

        try
        {
            using (SqlConnection sqlCon = new SqlConnection(connValue))
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Parameters.AddWithValue("@userID",upd_UserID); 
                    cmd.Parameters.AddWithValue("@userName", txtUserName.Text);
                    cmd.Parameters.AddWithValue("@password", txtPswrd.Text);
                    cmd.Parameters.AddWithValue("@updUser", Session["UserName"]);
                    cmd.Parameters.AddWithValue("@updDate", System.DateTime.Now.ToString("dd/MMM/yyyy"));                  

                    sqlCon.Open();
                    cmd.Connection = sqlCon;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "UpdatePassword";
                    cmd.ExecuteNonQuery();
                }
            }

        }
        catch (Exception ex)
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "alert('Error Occurred while Updating the password')", true);             
        }
    }
  
    
}