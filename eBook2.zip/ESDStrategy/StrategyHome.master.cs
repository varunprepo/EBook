﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class StrategyHome : System.Web.UI.MasterPage
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if(!IsPostBack)
        {
            if (Session["SectionID"]==null)
            {
                Response.Redirect("~/LoginPage.aspx", false);
                return;
            }
            if(!Session["SectionID"].Equals("7"))
            {
                //addNewCorpObj.Visible = false;
                //updateCorpObj.Visible = false;
                //addNewDeptObj.Visible = false;
                //updateDeptObj.Visible = false;
                deptObj.Visible = false;
                corpObj.Visible = false;
                addSectObj.Visible = false;
                updateSectObj.Visible = false;
                addKpi.Visible = false;
                addKpiTarget.Visible = false;
            }
             
        }
    }

     
    protected void imgLogOut_Click(object sender, EventArgs e)
    {
        Session["SectionID"] = null;
        Response.Redirect("~/LoginPage.aspx", false);
    }

    protected void lnkProfile_Click(object sender, EventArgs e)
    {
        UtilityClass utils = null;
        try
        {
            utils = new UtilityClass(this.Page);
            string url = Request.Url.AbsoluteUri;
            //if (url.Contains(":"))
                url = url.Substring(0, utils.GetNthIndex(url, '/', 4));
            //else
            //    url = url.Substring(0, utils.GetNthIndex(url, '/', 2));
            // url = url + "/Directory/AddContactsInfo.aspx?contactID=" + Session["UserID"] + "";

            url = url + "/ChangePassword.aspx?contactID=" + Session["UserID"] + "";

            //OpenPageByUsingJS(url, "800", "421");

            OpenPageByUsingJS(url, "581", "351");              //"781", "651"
        }
        catch (Exception ex)
        {
            this.Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Error occurred while processing the request')</script>", false);
        }
    }

    private void OpenPageByUsingJS(string url, string width, string height)
    {
        string s = "window.open('" + url + "', 'popup_window', 'width=" + width + ",height=" + height + "left=100,top=100,resizable=yes');";
        Page.ClientScript.RegisterStartupScript(this.GetType(), "script", s, true);
    }
}
