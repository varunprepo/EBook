﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class AddKPI : System.Web.UI.Page
{
    UtilityClass ulCls = null;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["SectionID"] != null)
        {
            if (!IsPostBack)
            {
                ulCls = new UtilityClass(this.Page);
                ulCls.PopulateDropDownBox(ddlStrategyTheme, "SELECT DISTINCT themeID,CAST(themeID AS nvarchar(10))+'-'+themeName AS themeName FROM StrategyTheme", "themeID", "themeName", false);
                ulCls.PopulateDropDownBox(ddlDataSource, "SELECT distinct dataSourceID, dataSource FROM StrategyDataSource where dataSource is not Null and dataSource<>''", "dataSourceID", "dataSource", false);
                Session["IsSRLoaded"] = "0";
            }
        }
        else
        {
            Response.Redirect("~/LoginPage.aspx", false);
        } 
    }
    protected void ddlStrategyTheme_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlStrategyTheme.SelectedValue != "")
        {
            ulCls = new UtilityClass(this.Page);
            ulCls.PopulateDropDownBox(ddlCorpObjective, "SELECT corpObjectiveID, objectiveNo+'-'+objectiveTitle AS objectiveTitle FROM StrategyCorpObjective where themeID=" + ddlStrategyTheme.SelectedValue + " and objectiveTitle is not Null", "corpObjectiveID", "objectiveTitle", false);
        }
        else
        {
            ddlCorpObjective.Items.Clear();
        }
    }

    protected void ddlDeptObjective_SelectedIndexChanged(object sender, EventArgs e)
    {         
        if (Session["UserName"] != null)
        {            
            if (ddlDeptObjective.SelectedValue != "")
            {
                ulCls = new UtilityClass(this.Page);
                ulCls.PopulateDropDownBox(ddlSectionObjective, "SELECT sectObjID, sectObjNo+' '+sectObjDesc AS sectObjDesc FROM StrategySectObjective where deptObjID=" + ddlDeptObjective.SelectedValue + " and sectObjDesc is not Null", "sectObjID", "sectObjDesc", false);
            }
            else
            {
                ddlDeptObjective.Items.Clear();
            }            
        }
        else
        {
            Response.Redirect("~/LoginPage.aspx", false);
        }

    }
    protected void ddlCorpObjective_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlCorpObjective.SelectedValue != "")
        {
            ulCls = new UtilityClass(this.Page);
            ulCls.PopulateDropDownBox(ddlDeptObjective, "SELECT deptObjID, deptObjNo+' '+deptObjDesc AS deptObjDesc FROM StrategyDeptObjective where corpObjectiveID=" + ddlCorpObjective.SelectedValue + " and deptObjDesc is not Null", "deptObjID", "deptObjDesc", false);
        }
        else
        {
            ddlDeptObjective.Items.Clear();
        }
    }

    static DataTable dtStrategyKPI = null;
    protected void ddlSectionObjective_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlSectionObjective.SelectedValue != "")
        {
            ulCls = new UtilityClass(this.Page);
            txtAreaKpiDef.InnerText = "";             
        }
    }     

    private void FillKPIs()
    {
        if (ddlSectionObjective.SelectedValue != "" && ddlDeptObjective.SelectedValue != "")
        {
            DAL dal = new DAL(ConfigurationManager.ConnectionStrings["EBSDEBookConn"].ToString());

            if (dal.ConnectDB(this.Page) == 'E')
            {
                ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "alert('Error occurred while establishing connection to the database')");
                return;
            }

            DataTable dtStrategyKPI = dal.GetDataFromDB("KPIDetails", "SELECT StrategyKPI.kpiID, StrategyKPI.kpiNo, REPLACE(REPLACE(StrategyKPI.kpiName, CHAR(13), ''), CHAR(10), '') as kpiName, StrategyKPI.kpiDefinition,StrategyKPI.uom,StrategyKPI.period " +
            ",StrategyKPI.sectionID,StrategyDeptObjective.themeID,StrategyDeptObjective.corpObjectiveID,StrategyKPI.deptObjID,StrategyKPI.sectObjID,StrategyKPI.strategyDataSourceID FROM StrategyKPI join StrategyDeptObjective on StrategyKPI.deptObjID=StrategyDeptObjective.deptObjID WHERE " +
            "StrategyKPI.sectObjID =" + ddlSectionObjective.SelectedValue + " and StrategyKPI.deptObjID =" + ddlDeptObjective.SelectedValue);
             
            if (dtStrategyKPI.Rows.Count != 0)
            {
                if (dtStrategyKPI.Rows[0]["sectionID"].ToString() != "")
                {
                    //ddlSection.SelectedValue = dtStrategyKPI.Rows[0]["sectionID"].ToString();
                }
            }
        }
        else
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "alert('Section and Department Objective cannot be left blank')");
        }
    }
     
    protected void save_Click(object sender, EventArgs e)
    {
        if (Session["UserName"] != null)
        {
            try
            {
                using (SqlConnection objCon = new SqlConnection(ConfigurationManager.ConnectionStrings["EBSDEBookConn"].ToString()))
                {
                    objCon.Open();
                     
                    string kpiName = null;
                     
                    kpiName = txtAreaKpiName.InnerText;
                    

                    string kpiDefinition = txtAreaKpiDef.InnerText;
                    string kpiUom = txtAreaUnitOfMeasure.InnerText;
                    
                    string kpiPeriod = txtAreaGoalType.InnerText;

                    string kpiDef = kpiDefinition.Trim().Replace("\r", " ").Replace("\n", " ");
                    string sqlQuery = "select kpiID from StrategyKPI where (kpiName='" + kpiName + "' or kpiDefinition='" + kpiDef + "') and sectObjID=" + ddlSectionObjective.SelectedValue; //  ddlDeptObjective.SelectedValue where deptObjID=@deptObjID and sectObjID=@sectObjID";
                    SqlCommand objCmd = new SqlCommand(sqlQuery, objCon);
                    SqlDataReader sqlDtReader = objCmd.ExecuteReader();
                    if (!sqlDtReader.HasRows)
                    {
                        
                        sqlDtReader.Close();
                         
                        string sectObjNoAfterPoint = ddlSectionObjective.SelectedItem.Text.Split(' ')[0].Split('.')[1];
                        sqlQuery = "insert into StrategyKPI(kpiNo,deptObjID,sectObjID,kpiName,kpiDefinition,strategyDataSourceID,uom,period,createUser,createDate,themeID) " + //,sectionID
                        "values(@kpiNo,@deptObjID,@sectObjID,@kpiName,@kpiDefinition,@strategyDataSourceID,@uom,@period,@createUser,@createDate,@themeID)"; //,@sectionID
                        objCmd = new SqlCommand(sqlQuery, objCon);
                        
                        objCmd.Parameters.AddWithValue("@kpiNo", "ESD " + ddlDeptObjective.SelectedValue + "-" + sectObjNoAfterPoint);
                        objCmd.Parameters.AddWithValue("@kpiName", kpiName);
                        

                        objCmd.Parameters.AddWithValue("@deptObjID", ddlDeptObjective.SelectedValue);
                        objCmd.Parameters.AddWithValue("@sectObjID", ddlSectionObjective.SelectedValue);

                        objCmd.Parameters.AddWithValue("@kpiDefinition", kpiDef);
                        if (ddlDataSource.SelectedValue != "")
                        {
                            objCmd.Parameters.AddWithValue("@strategyDataSourceID", ddlDataSource.SelectedValue);
                        }
                        else
                        {
                            objCmd.Parameters.AddWithValue("@strategyDataSourceID", 0);
                        }
                        objCmd.Parameters.AddWithValue("@uom", kpiUom);
                        objCmd.Parameters.AddWithValue("@period", kpiPeriod);
                        objCmd.Parameters.AddWithValue("@createUser", Session["UserName"].ToString());
                        objCmd.Parameters.AddWithValue("@createDate", DateTime.Now);
                        objCmd.Parameters.AddWithValue("@themeID", ddlStrategyTheme.SelectedValue);
                         
                        objCmd.Parameters.AddWithValue("@corpObjectiveID", ddlCorpObjective.SelectedValue);
                        objCmd.ExecuteNonQuery();
                        objCon.Close();
                        ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "alert('Strategy KPI created successfully')", true);
                        save.Visible = false;
                    }
                    else
                    {
                        sqlDtReader.Close();
                        objCon.Close();
                        ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "alert('KPI Definition already exists')", true);
                    }
                     
                }
            }
            catch (Exception ex)
            {
                ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "alert('Error Occurred while creating Strategy KPI')", true);
                save.Visible = false;
            }
        }
        else
        {
            Response.Redirect("~/LoginPage.aspx", false);
        }
    }
    protected void cancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/Strategy/StrategyHome.aspx", false);
    }

}