﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class UpdateSectionObjective : System.Web.UI.Page
{
    UtilityClass utCls = null;
    protected void Page_Load(object sender, EventArgs e)    
    {        
        if (Session["SectionID"] != null)
        {
            if (!IsPostBack)
            {
                utCls = new UtilityClass(this.Page);                 
                utCls.PopulateDropDownBox(ddlStrategyTheme, "SELECT DISTINCT themeID,CAST(themeID AS nvarchar(10))+'-'+themeName AS themeName FROM StrategyTheme", "themeID", "themeName", false);
                Session["IsSRLoaded"] = "0";
            }
        }
        else
        {
            Response.Redirect("~/LoginPage.aspx", false);
        } 
    }

    protected void ddlDeptObjective_SelectedIndexChanged(object sender, EventArgs e)
    {
        FillSectionObjective();         
    }


    //static DataTable dtSectionObj = null;
    private void FillSectionObjective()
    {       
        try
        {
            DAL dal = new DAL(ConfigurationManager.ConnectionStrings["EBSDEBookConn"].ToString());

            if (dal.ConnectDB(this.Page) == 'E')
            {
                ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "alert('Error occurred while establishing connection to the database')");
                return;
            }

            DataTable dtSectionObj = dal.GetDataFromDB("SectionObjs", "SELECT DISTINCT sectObjID,sectObjNo,sectObjDesc FROM StrategySectObjective WHERE " + //e.sectionID =" + ddlSection.SelectedValue +
            " deptObjID=" + ddlDeptObjective.SelectedValue);
            gvEditSectionObj.DataSource = dtSectionObj;
            gvEditSectionObj.DataBind();
        }
        catch (Exception ex)
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "alert('Error occurred while displaying the Section Objectives')");
        }        
    }
    protected void ddlStrategyTheme_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlStrategyTheme.SelectedValue != "")
        {
            utCls = new UtilityClass(this.Page);
            utCls.PopulateDropDownBox(ddlCorpObjective, "SELECT corpObjectiveID, objectiveNo+'-'+objectiveTitle AS objectiveTitle FROM StrategyCorpObjective where themeID=" + ddlStrategyTheme.SelectedValue + " and objectiveTitle is not Null and objectiveTitle<>''", "corpObjectiveID", "objectiveTitle", false);            
        }
        else
        {
            ddlCorpObjective.Items.Clear();
            gvEditSectionObj.DataSource = null;
            gvEditSectionObj.DataBind();
        }
    }
    protected void ddlCorpObjective_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlCorpObjective.SelectedValue != "")
        {
            utCls = new UtilityClass(this.Page);
            utCls.PopulateDropDownBox(ddlDeptObjective, "SELECT deptObjID, deptObjNo+' '+deptObjDesc AS deptObjDesc FROM StrategyDeptObjective where corpObjectiveID=" + ddlCorpObjective.SelectedValue + " and deptObjDesc is not Null and deptObjDesc<>''", "deptObjID", "deptObjDesc", false);
        }
        else
        {
            ddlDeptObjective.Items.Clear();
            gvEditSectionObj.DataSource = null;
            gvEditSectionObj.DataBind();
        }
    }
    protected void gvEditSectionObj_OnPageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        gvEditSectionObj.PageIndex = e.NewPageIndex;
        FillSectionObjective();
    }

    protected void gvEditSectionObj_RowEditing(object sender, GridViewEditEventArgs e)
    {
        if (Session["UserName"] != null)
        {
            try
            {
                gvEditSectionObj.EditIndex = e.NewEditIndex;
                FillSectionObjective();
                GridViewRow row = gvEditSectionObj.Rows[e.NewEditIndex];
                (row.FindControl("txtSectionObjective") as TextBox).Enabled = true;
                (row.FindControl("txtSectionObjective") as TextBox).BackColor = System.Drawing.Color.FromName("#ffffff");
                //gvStrategyKPI.EditIndex = -1;                                        
                //FillKPIs();
            }
            catch (Exception ex)
            {
                ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "alert('Error Occurred while Editing Strategy KPI')", true);
            }
        }
        else
        {
            Response.Redirect("~/LoginPage.aspx", false);
        }
    }
    protected void gvEditSectionObj_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        if (Session["UserName"] != null)
        {
            try
            {
                using (SqlConnection objCon = new SqlConnection(ConfigurationManager.ConnectionStrings["EBSDEBookConn"].ToString()))
                {
                    objCon.Open();
                    GridViewRow row = gvEditSectionObj.Rows[e.RowIndex];
                    string sectObjID = (row.FindControl("lblKpiSectObjID") as Label).Text;
                    string sectionObjective = (row.FindControl("txtSectionObjective") as TextBox).Text.Replace("\n", "").Replace("\r", "");
                     
                    SqlCommand objCmd = null;
                     
                    string sqlQuery = "update StrategySectObjective set sectObjDesc=@sectObjDesc,updateUser=@updateUser,updateDate=@updateDate where sectObjID=@sectObjID";
                     
                    objCmd = new SqlCommand(sqlQuery, objCon);
                    
                    objCmd.Parameters.AddWithValue("@sectObjDesc", sectionObjective.TrimStart());
                    objCmd.Parameters.AddWithValue("@sectObjID", sectObjID);
                    objCmd.Parameters.AddWithValue("@updateUser", Session["UserName"].ToString());
                    objCmd.Parameters.AddWithValue("@updateDate", DateTime.Now);
                    objCmd.ExecuteNonQuery();
                    ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "alert('Section Objective updated successfully')", true);
                    
                    gvEditSectionObj.EditIndex = -1;
                    FillSectionObjective();
                }

            }
            catch (Exception ex)
            {
                ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "alert('Error Occurred while updating section objective')", true);
            }
        }
        else
        {
            Response.Redirect("~/LoginPage.aspx", false);
        }
    }
    protected void gvEditSectionObj_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
    {
        gvEditSectionObj.EditIndex = -1;
        FillSectionObjective();
    }

}