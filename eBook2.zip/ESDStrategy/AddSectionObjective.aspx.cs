﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class AddSectionObjective : System.Web.UI.Page
{
    UtilityClass utCls = null;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["SectionID"] != null)
        {
            if (!IsPostBack)
            {
                utCls = new UtilityClass(this.Page);
                utCls.PopulateDropDownBox(ddlStrategyTheme, "SELECT DISTINCT themeID,CAST(themeID AS nvarchar(10))+'-'+themeName AS themeName FROM StrategyTheme", "themeID", "themeName", false);
                Session["IsSRLoaded"] = "0";
            }
        }
        else
        {
            Response.Redirect("~/LoginPage.aspx", false);
        }
    }
    protected void ddlStrategyTheme_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlStrategyTheme.SelectedValue != "")
        {
            utCls = new UtilityClass(this.Page);
            utCls.PopulateDropDownBox(ddlCorpObjective, "SELECT corpObjectiveID, objectiveNo+'-'+objectiveTitle AS objectiveTitle FROM StrategyCorpObjective where themeID=" + ddlStrategyTheme.SelectedValue + " and objectiveTitle is not Null", "corpObjectiveID", "objectiveTitle", false);
        }
        else
        {
            ddlCorpObjective.Items.Clear();
        }
    }

    protected void ddlCorpObjective_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlCorpObjective.SelectedValue != "")
        {
            utCls = new UtilityClass(this.Page);
            utCls.PopulateDropDownBox(ddlDeptObjective, "SELECT deptObjID, deptObjNo+' '+deptObjDesc AS deptObjDesc FROM StrategyDeptObjective where corpObjectiveID=" + ddlCorpObjective.SelectedValue, "deptObjID", "deptObjDesc", false);
        }
        else
        {
            ddlDeptObjective.Items.Clear();
        }
    }
    private void FillSectionObjective(string sectObjID)
    {
        //if (ddlCorpObjective.SelectedValue != "" && ddlDeptObjective.SelectedValue != "")
        //{
        try
        {
            DAL dal = new DAL(ConfigurationManager.ConnectionStrings["EBSDEBookConn"].ToString());

            if (dal.ConnectDB(this.Page) == 'E')
            {
                ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "alert('Error occurred while establishing connection to the database')");
                return;
            }
                
            DataTable dtCorpObj = dal.GetDataFromDB("SectionObjs", "SELECT DISTINCT sectObjID,sectObjNo,sectObjDesc FROM StrategySectObjective WHERE " + //e.sectionID =" + ddlSection.SelectedValue +
            "sectObjID=" + sectObjID); // ddlDeptObjective.SelectedValue + " and corpObjID=" + ddlCorpObjective.SelectedValue);
            //gvEditSectionObj.DataSource = dtSectionObj;
            //gvEditSectionObj.DataBind();
        }
        catch (Exception ex)
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "alert('Error occurred while displaying the Section Objectives')");
        }

        //if (gvEditSectionObj.Rows[0]["sectionID"].ToString() != "")
        //{
        //    ddlSection.SelectedValue = dtStrategyKPI.Rows[0]["sectionID"].ToString();
        //}
        //}
        //else
        //{
        //    ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "alert('Section and Department Objective cannot be left blank')");
        //}
    }
    protected void save_Click(object sender, EventArgs e)
    {
        if (Session["UserName"] != null)
        {
            if (ddlDeptObjective.SelectedValue != "")
            {
                try
                {
                    using (SqlConnection objCon = new SqlConnection(ConfigurationManager.ConnectionStrings["EBSDEBookConn"].ToString()))
                    {
                        objCon.Open();
                        string secObjDescrip = txtAreaSectObj.InnerText.Trim().Replace("\r", "").Replace("\n", "");
                        string sqlQuery = "select sectObjNo from StrategySectObjective where sectObjDesc=@sectObjDesc and deptObjID=@deptObjID"; // txtSectionObjective.Text.Trim().Replace("\r", " ").Replace("\n", " ") + "'"; // where deptObjID=@deptObjID and sectObjID=@sectObjID";
                        SqlCommand objCmd = new SqlCommand(sqlQuery, objCon); //"; //
                        objCmd.Parameters.AddWithValue("@sectObjDesc", secObjDescrip);
                        objCmd.Parameters.AddWithValue("@deptObjID", ddlDeptObjective.SelectedValue);
                        SqlDataReader sqlDtReader = objCmd.ExecuteReader();
                        if (!sqlDtReader.HasRows)
                        {
                            sqlDtReader.Close();
                            sqlQuery = "select sectObjNo from StrategySectObjective where sectObjID=(select max(sectObjID) from StrategySectObjective where deptObjID=@deptObjID)"; // in(select max(sectObjID) from StrategySectObjective)";
                            objCmd = new SqlCommand(sqlQuery, objCon);
                            objCmd.Parameters.AddWithValue("@deptObjID", ddlDeptObjective.SelectedValue);
                            sqlDtReader = objCmd.ExecuteReader();
                            string sectObjNoAfterPoint = null;
                            if (sqlDtReader.HasRows)
                            {
                                sqlDtReader.Read();
                                string sectObjNo = sqlDtReader["sectObjNo"].ToString();
                                sectObjNoAfterPoint = (Convert.ToInt16(sectObjNo.Split('.')[1]) + 1).ToString();
                            }
                            sqlDtReader.Close();

                            objCmd = new SqlCommand();
                            objCmd.CommandType = CommandType.StoredProcedure;
                            objCmd.Connection = objCon;
                            objCmd.CommandText = "GetSectObjID";   // SP                    

                            objCmd.Parameters.AddWithValue("@sectObjID", SqlDbType.Int).Direction = ParameterDirection.Output;

                            //sqlQuery = "insert into StrategySectObjective(themeID,deptObjID,sectObjNo,sectObjDesc,corpObjID,createUser,createDate) " +
                            //"values(@themeID,@deptObjID,@sectObjNo,@sectObjDesc,@corpObjID,@createUser,@createDate)";

                            objCmd.Parameters.AddWithValue("@themeID", ddlStrategyTheme.SelectedValue);
                            objCmd.Parameters.AddWithValue("@deptObjID", ddlDeptObjective.SelectedValue);
                            if (sectObjNoAfterPoint != null)
                            {
                                objCmd.Parameters.AddWithValue("@sectObjNo", ddlDeptObjective.SelectedValue + "." + sectObjNoAfterPoint);
                            }
                            else
                            {
                                objCmd.Parameters.AddWithValue("@sectObjNo", ddlDeptObjective.SelectedValue + ".1");
                            }
                            objCmd.Parameters.AddWithValue("@sectObjDesc", secObjDescrip);
                            objCmd.Parameters.AddWithValue("@corpObjID", ddlCorpObjective.SelectedValue);
                            objCmd.Parameters.AddWithValue("@createUser", Session["UserName"].ToString());
                            objCmd.Parameters.AddWithValue("@createDate", DateTime.Now);
                            objCmd.ExecuteNonQuery();
                            string sectObjID = objCmd.Parameters["@sectObjID"].Value.ToString();
                            Session["SectObjID"] = sectObjID;
                            objCon.Close();
                            ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "alert('Section Objective created successfully')", true);
                            save.Visible = false;
                            FillSectionObjective(sectObjID);
                        }
                        else
                        {
                            sqlDtReader.Close();
                            objCon.Close();
                            ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "alert('Section Objective Description already exists')", true);
                        }
                    }
                }
                catch (Exception ex)
                {
                    ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "alert('Error Occurred while Adding Section Objective')", true);
                }
            }
            else
            {
                ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "alert('Department Objective cannot be left blank')", true);
            }
        }
        else
        {
            Response.Redirect("~/LoginPage.aspx", false);
        }
    } 
}