﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class CreateCorpObjective1 : System.Web.UI.Page
{    
    protected void Page_Load(object sender, EventArgs e)
    {
         if (Session["SectionID"] != null)
        {
            if (!IsPostBack)
            {
                // getUnReadInchargeData();
            
                    UtilityClass utCls = new UtilityClass(this.Page);
                    //if (Session["SectionID"].ToString().Equals("7"))
                    //{
                        utCls.PopulateDropDownBox(ddlAshghalTheme, "SELECT DISTINCT themeID,CAST(themeID AS nvarchar(10))+'-'+themeName AS themeName FROM StrategyTheme", "themeID", "themeName",false);       
                    //}
                    //else
                    //{
                    //    utCls.PopulateDropDownBox(ddlAshghalTheme, "SELECT DISTINCT st.themeID,CAST(st.themeID AS nvarchar(10))+'-'+st.themeName AS themeName FROM StrategyTheme st INNER JOIN StrategyCorpObjective sco ON st.themeID = sco.themeID INNER JOIN StrategyDeptObjective sdo ON sco.corpObjectiveID = sdo.corpObjectiveID " +
                    //    "INNER JOIN StrategySectObjective ssb ON sdo.deptObjID = ssb.deptObjID INNER JOIN StrategyObjSect sos ON ssb.sectObjID = sos.sectObjID WHERE sos.sectionID=" + Session["SectionID"].ToString(), "themeID", "themeName",false);              
                    //}                             
            }
        }
        else
        {
            Response.Redirect("~/LoginPage.aspx", false);
        }
    }

    protected void save_Click(object sender, EventArgs e)
    {
        if (Session["UserName"] != null)
        {
            try
            {
                string corpObjective = txtAreaCorpObj.InnerText.Replace("\r", "").Replace("\n", "");
                string objectiveNo = null;
                //if (corpObjective.Contains("-"))
                //{
                //    objectiveNo = corpObjective.Split('-')[0].TrimEnd();
                //    corpObjective = corpObjective.Split('-')[1].TrimStart();
                //}
                using (SqlConnection objCon = new SqlConnection(ConfigurationManager.ConnectionStrings["EBSDEBookConn"].ToString()))
                {
                    objCon.Open();
                    string sqlQuery = "select themeID from StrategyCorpObjective where objectiveTitle=@objectiveTitle and themeID=@themeID";
                    SqlCommand objCmd = new SqlCommand(sqlQuery, objCon);
                    objCmd.Parameters.AddWithValue("@objectiveTitle", corpObjective.TrimStart());
                    objCmd.Parameters.AddWithValue("@themeID", ddlAshghalTheme.SelectedValue);
                    SqlDataReader sqlDtReader = objCmd.ExecuteReader();
                    if (!sqlDtReader.HasRows)
                    {
                        sqlDtReader.Close();
                        sqlQuery = "select objectiveNo from StrategyCorpObjective where corpObjectiveID=(select max(corpObjectiveID) from StrategyCorpObjective)";
                        objCmd = new SqlCommand(sqlQuery, objCon);
                        sqlDtReader = objCmd.ExecuteReader();
                        sqlDtReader.Read();
                        objectiveNo = sqlDtReader["objectiveNo"].ToString();
                        sqlDtReader.Close();

                        sqlQuery = "insert into StrategyCorpObjective (themeID,objectiveNo,objectiveTitle,createUser,createDate) values(@themeID,@objectiveNo,@objectiveTitle,@createUser,@createDate)";
                        objCmd = new SqlCommand(sqlQuery, objCon);
                        objCmd.Parameters.AddWithValue("@themeID", ddlAshghalTheme.SelectedValue);
                        objCmd.Parameters.AddWithValue("@objectiveNo", "C" + (Convert.ToInt16(objectiveNo.Substring(1)) + 1).ToString());
                        objCmd.Parameters.AddWithValue("@objectiveTitle", corpObjective.TrimStart());
                        objCmd.Parameters.AddWithValue("@createUser", Session["UserName"].ToString());
                        objCmd.Parameters.AddWithValue("@createDate", DateTime.Now);
                        objCmd.ExecuteNonQuery();
                        objCon.Close();
                        ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "alert('Corporate Objective added successfully')", true);
                        save.Enabled = false;
                    }
                    else
                    {
                        sqlDtReader.Close();
                        objCon.Close();
                        ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "alert('Corporate Objective already exists')", true);
                    }
                }

            }
            catch (Exception ex)
            {
                ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "alert('Error Occurred while creating Corporate Objective')", true);
            }
        }
        else
        {
            Response.Redirect("~/LoginPage.aspx", false);
        }
    }
}