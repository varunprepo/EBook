﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class UpdateCorpObjective : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        UtilityClass utCls = null;
        if (Session["SectionID"] != null)
        {
            if (!IsPostBack)
            {
                // getUnReadInchargeData();

                utCls = new UtilityClass(this.Page);
                //if (Session["SectionID"].ToString().Equals("7"))
                //{                    
                //    utCls.PopulateDropDownBox(ddlStrategyTheme, "SELECT DISTINCT st.themeID,st.themeName FROM StrategyTheme st INNER JOIN StrategyCorpObjective sco ON st.themeID = sco.themeID INNER JOIN StrategyDeptObjective sdo ON sco.corpObjectiveID = sdo.corpObjectiveID " +
                //    "INNER JOIN StrategySectObjective ssb ON sdo.deptObjID = ssb.deptObjID INNER JOIN StrategyObjSect sos ON ssb.sectObjID = sos.sectObjID WHERE sos.sectionID in(1,5,9,11,13,14,100)", "themeID", "themeName");

                //    //utCls.PopulateDropDownBox(ddlCorpObjective, "SELECT corpObjectiveID, objectiveTitle FROM StrategyCorpObjective where themeID=" + ddlStrategyTheme.SelectedValue + " and objectiveTitle is not Null", "corpObjectiveID", "objectiveTitle");

                //    utCls.PopulateDropDownBox(ddlCorpObjective, "SELECT corpObjectiveID, objectiveTitle FROM StrategyCorpObjective where objectiveTitle is not Null", "corpObjectiveID", "objectiveTitle");

                //    //utCls.PopulateDropDownBox(ddlCorpObjective, "SELECT DISTINCT st.themeID,st.themeName FROM StrategyCorpObjective st INNER JOIN StrategyCorpObjective sco ON st.themeID = sco.themeID INNER JOIN StrategyDeptObjective sdo ON sco.corpObjectiveID = sdo.corpObjectiveID " +
                //    //"INNER JOIN StrategySectObjective ssb ON sdo.deptObjID = ssb.deptObjID INNER JOIN StrategyObjSect sos ON ssb.sectObjID = sos.sectObjID WHERE sos.sectionID in(1,5,9,11,13,14,100)", "themeID", "themeName");
                //}
                //else
                //{
                //if (Session["SectionID"].ToString().Equals("7"))
                //{
                utCls.PopulateDropDownBox(ddlStrategyTheme, "SELECT DISTINCT themeID,CAST(themeID AS nvarchar(10))+'-'+themeName AS themeName FROM StrategyTheme", "themeID", "themeName", false);
                //}
                //else
                //{
                //    utCls.PopulateDropDownBox(ddlStrategyTheme, "SELECT DISTINCT st.themeID,CAST(st.themeID AS nvarchar(10))+'-'+st.themeName AS themeName FROM StrategyTheme st INNER JOIN StrategyCorpObjective sco ON st.themeID = sco.themeID INNER JOIN StrategyDeptObjective sdo ON sco.corpObjectiveID = sdo.corpObjectiveID " +
                //    "INNER JOIN StrategySectObjective ssb ON sdo.deptObjID = ssb.deptObjID INNER JOIN StrategyObjSect sos ON ssb.sectObjID = sos.sectObjID WHERE sos.sectionID=" + Session["SectionID"].ToString(), "themeID", "themeName", false);
                //}

                //utCls.PopulateDropDownBox(ddlCorpObjective, "SELECT corpObjectiveID, objectiveTitle FROM StrategyCorpObjective where objectiveTitle is not Null and corpObjectiveID=" + Session["CorpObjectiveID"].ToString(), "corpObjectiveID", "objectiveTitle");
                //}
                //FillCorpObjectiveTitle();           
                Session["IsSRLoaded"] = "0";
            }
        }
        else
        {
            Response.Redirect("~/LoginPage.aspx", false);
        }
    }

    protected void gvEditCorpObj_OnPageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        gvEditCorpObj.PageIndex = e.NewPageIndex;
        FillCorpObjectiveTitle();
    }
    protected void gvEditCorpObj_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
    {
        gvEditCorpObj.EditIndex = -1;
        FillCorpObjectiveTitle();
    }
    private void FillCorpObjectiveTitle()
    {
        try
        {
            DAL dal = new DAL(ConfigurationManager.ConnectionStrings["EBSDEBookConn"].ToString());

            if (dal.ConnectDB(this.Page) == 'E')
            {
                ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "alert('Error occurred while establishing connection to the database')");
                return;
            }
                
            DataTable dtCorpObj = dal.GetDataFromDB("SectionObjs", "SELECT corpObjectiveID,objectiveNo,objectiveTitle FROM StrategyCorpObjective WHERE" + //objectiveNo+'-'+
            " themeID =" + ddlStrategyTheme.SelectedValue + " and objectiveTitle is not Null");
            gvEditCorpObj.DataSource = dtCorpObj;
            gvEditCorpObj.DataBind();
        }
        catch (Exception)
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "alert('Error occurred while displaying the Strategy Corp. Objective')");
        }
    }

     
    protected void gvEditCorpObj_RowEditing(object sender, GridViewEditEventArgs e)
    {
        if (Session["UserName"] != null)
        {
            try
            {
                gvEditCorpObj.EditIndex = e.NewEditIndex;
                FillCorpObjectiveTitle();
                GridViewRow row = gvEditCorpObj.Rows[e.NewEditIndex];
                (row.FindControl("txtCorpObjTitle") as TextBox).Enabled = true;
                (row.FindControl("txtCorpObjTitle") as TextBox).BackColor = System.Drawing.Color.FromName("#ffffff");
            }
            catch (Exception ex)
            {
                ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "alert('Error Occurred while Editing Corporative Objective')", true);
            }
        }
        else
        {
            Response.Redirect("~/LoginPage.aspx", false);
        }
    }
    protected void gvEditCorpObj_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        if (Session["UserName"] != null)
        {
            try
            {
                using (SqlConnection objCon = new SqlConnection(ConfigurationManager.ConnectionStrings["EBSDEBookConn"].ToString()))
                {
                    objCon.Open();
                    GridViewRow row = gvEditCorpObj.Rows[e.RowIndex];
                    string corpObjID = (row.FindControl("lblCorpObjID") as Label).Text;
                    string corpObjectiveTitle = (row.FindControl("txtCorpObjTitle") as TextBox).Text.Replace("\n", "").Replace("\r", "");
                    //string corpObjectiveNo = null;
                    //if(corpObjectiveTitle.Contains("-"))
                    //{
                    //    corpObjectiveNo = corpObjectiveTitle.Split('-')[0].TrimEnd();
                    //    corpObjectiveTitle = corpObjectiveTitle.Split('-')[1].TrimStart();
                    //}
                    string sqlQuery = null;
                    SqlCommand objCmd = null;
                    //sqlQuery = "select corpObjectiveID from StrategyCorpObjective where objectiveTitle=@objectiveTitle";
                    //objCmd = new SqlCommand(sqlQuery, objCon);
                    //objCmd.Parameters.AddWithValue("@objectiveTitle", corpObjectiveTitle);
                    //SqlDataReader sqlDtReader = objCmd.ExecuteReader();
                    //if (!sqlDtReader.HasRows)
                    //{
                    //    sqlDtReader.Close();
                    //if (corpObjectiveNo != null)
                    //{
                    //    sqlQuery = "update StrategyCorpObjective set objectiveNo=@objectiveNo,objectiveTitle=@objectiveTitle,updateUser=@updateUser,updateDate=@updateDate where corpObjectiveID=@corpObjID";
                    //}
                    //else
                    //{
                    sqlQuery = "update StrategyCorpObjective set objectiveTitle=@objectiveTitle,updateUser=@updateUser,updateDate=@updateDate where corpObjectiveID=@corpObjID";
                    //}
                    objCmd = new SqlCommand(sqlQuery, objCon);
                    //if (corpObjectiveNo != null)
                    //{
                    //objCmd.Parameters.AddWithValue("@objectiveNo", corpObjectiveNo);
                    //}
                    objCmd.Parameters.AddWithValue("@objectiveTitle", corpObjectiveTitle);
                    objCmd.Parameters.AddWithValue("@corpObjID", corpObjID);
                    objCmd.Parameters.AddWithValue("@updateUser", Session["UserName"].ToString());
                    objCmd.Parameters.AddWithValue("@updateDate", DateTime.Now);
                    objCmd.ExecuteNonQuery();
                    objCon.Close();
                    //ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "alert('Corp. Objective updated successfully')", true);
                    //}
                    //else
                    //{
                    //    sqlDtReader.Close();
                    //    objCon.Close();
                    //    ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "alert('Corp. Objective already exists')", true);
                    //}
                    gvEditCorpObj.EditIndex = -1;
                    FillCorpObjectiveTitle();
                }

            }
            catch (Exception ex)
            {
                ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "alert('Error Occurred while updating section objective')", true);
            }
        }
        else
        {
            Response.Redirect("~/LoginPage.aspx", false);
        }
    }

    private void ClearGV()
    {
        gvEditCorpObj.DataSource = null;
        gvEditCorpObj.DataBind();
    }
    protected void ddlStrategyTheme_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlStrategyTheme.SelectedValue != "")
        {
            FillCorpObjectiveTitle();
        }
        else
        {
            ClearGV();
        }
    }
}