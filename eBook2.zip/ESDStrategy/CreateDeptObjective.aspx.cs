﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class CreateDeptObjective : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["SectionID"] != null)
        {
            if (!IsPostBack)
            {
                UtilityClass utCls = new UtilityClass(this.Page);
                utCls.PopulateDropDownBox(ddlStrategyTheme, "SELECT DISTINCT themeID,CAST(themeID AS nvarchar(10))+'-'+themeName AS themeName FROM StrategyTheme", "themeID", "themeName", false);
                Session["IsSRLoaded"] = "0";
            }
        }
        else
        {
            Response.Redirect("~/LoginPage.aspx", false);
        }
    }

    protected void save_Click(object sender, EventArgs e)
    {
        if (Session["UserName"] != null)
        {
            try
            {
                string deptObjective = txtDptObj.InnerText.Replace("\r", "").Replace("\n", "");
                string deptObjNo = null;
                //if (deptObjective.Contains("-"))
                //{
                //    deptObjNo = deptObjective.Split(' ')[0].TrimEnd();
                //    deptObjective = deptObjective.Substring(deptObjective.LastIndexOf("-" + deptObjNo.Split('-')[1]) + deptObjNo.Split('-')[1].Length+1).TrimStart();
                //}
                using (SqlConnection objCon = new SqlConnection(ConfigurationManager.ConnectionStrings["EBSDEBookConn"].ToString()))
                {
                    objCon.Open();
                    string sqlQuery = "select deptObjNo from StrategyDeptObjective where deptObjDesc=@deptObjDesc and corpObjectiveID=@corpObjectiveID";
                    SqlCommand objCmd = new SqlCommand(sqlQuery, objCon);
                    objCmd.Parameters.AddWithValue("@deptObjDesc", deptObjective);
                    objCmd.Parameters.AddWithValue("@corpObjectiveID", ddlCorpObj.SelectedValue);
                    SqlDataReader sqlDtReader = objCmd.ExecuteReader();
                    if (!sqlDtReader.HasRows)
                    {
                        sqlDtReader.Close();
                        sqlQuery = "select deptObjNo from StrategyDeptObjective where deptObjID=(select max(deptObjID) from StrategyDeptObjective)";
                        objCmd = new SqlCommand(sqlQuery, objCon);
                        sqlDtReader = objCmd.ExecuteReader();
                        sqlDtReader.Read();
                        deptObjNo = sqlDtReader["deptObjNo"].ToString();
                        deptObjNo = "ESD-" + (Convert.ToInt16(deptObjNo.Split('-')[1]) + 1).ToString();
                        sqlDtReader.Close();
                        sqlQuery = "insert into StrategyDeptObjective(themeID,deptObjNo,deptObjDesc,corpObjectiveID,createUser,createDate) values(@themeID,@deptObjNo,@deptObjDesc,@corpObjectiveID,@createUser,@createDate)";
                        objCmd = null;
                        objCmd = new SqlCommand(sqlQuery, objCon);
                        objCmd.Parameters.AddWithValue("@themeID", ddlStrategyTheme.SelectedValue);
                        objCmd.Parameters.AddWithValue("@deptObjNo", deptObjNo);
                        objCmd.Parameters.AddWithValue("@deptObjDesc", deptObjective.TrimStart());
                        objCmd.Parameters.AddWithValue("@corpObjectiveID", ddlCorpObj.SelectedValue);
                        objCmd.Parameters.AddWithValue("@createUser", Session["UserName"].ToString());
                        objCmd.Parameters.AddWithValue("@createDate", DateTime.Now);
                        objCmd.ExecuteNonQuery();
                        objCon.Close();
                        ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "alert('Department Objective added successfully')", true);
                        save.Enabled = false;
                    }
                    else
                    {
                        sqlDtReader.Close();
                        objCon.Close();
                        ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "alert('Department Objective already exists')", true);
                    }
                }

            }
            catch (Exception ex)
            {
                ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "alert('Error Occurred while creating Department Objective')", true);
            }
        }
        else
        {
            Response.Redirect("~/LoginPage.aspx", false);
        }
    }
    protected void ddlStrategyTheme_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlStrategyTheme.SelectedValue != "")
        {
            UtilityClass ulCls = new UtilityClass(this.Page);

            //straTheme2
            ulCls.PopulateDropDownBox(ddlCorpObj, "SELECT corpObjectiveID, objectiveNo+'-'+objectiveTitle AS objectiveTitle FROM StrategyCorpObjective where themeID=" + ddlStrategyTheme.SelectedValue + " and objectiveTitle is not Null", "corpObjectiveID", "objectiveTitle", false);
        }
        else
        {
            ddlCorpObj.Items.Clear();
        }
    }
     
}