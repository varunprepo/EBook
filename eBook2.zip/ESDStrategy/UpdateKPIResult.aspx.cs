﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;

public partial class UpdateKPIResult : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["SectionID"] != null)
        {
            if (!IsPostBack)
            {

                if (Session["SectionID"].ToString().Equals("7"))
                {
                    PopulateDropDownBox(ddlSection, "select sectionID,sectionName from Section WHERE sectionID in(1,5,9,11,13,14,100)", "sectionID", "sectionName");
                }
                else
                {
                    PopulateDropDownBox(ddlSection, "select sectionID,sectionName from Section WHERE sectionID=" + Session["SectionID"].ToString(), "sectionID", "sectionName");
                }
                Session["IsKPIResultLoaded"] = "1";
                Session["IsSRLoaded"] = "0";
            }
            else
            {
                Session["IsKPIResultLoaded"] = "0";
                Session["IsPageLoaded"] = "0";
            }
        }
        else
        {
            Response.Redirect("~/LoginPage.aspx", false);
        }
    }

    private void PopulateDropDownBox(DropDownList ddlBox, string sqlQuery, string valueMember, string displayName)
    {
        DataTable table = new DataTable();
        try
        {
            using (SqlConnection sqlConn = new SqlConnection(ConfigurationManager.ConnectionStrings["EBSDEBookConn"].ToString()))
            {
                using (SqlDataAdapter da = new SqlDataAdapter(sqlQuery, sqlConn))
                {
                    sqlConn.Open();
                    da.Fill(table);
                }
            }
            //cmbBox.Items.Add("Select");
            ddlBox.Items.Clear();
            ddlBox.DataSource = table;
            ddlBox.DataTextField = displayName;
            ddlBox.DataValueField = valueMember;

            ddlBox.SelectedIndex = -1;
            ddlBox.DataBind();

            ddlBox.Items.Insert(0, new ListItem(""));
        }
        catch (System.Exception ex)
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "alert('Error Occurred while filling the " + ddlBox.ID + " dropdownlist')", true);
        }
    }
    protected void ddlYear_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            queryStrategyKPIResults();
        }
        catch (System.Exception ex)
        {
            if (ex.Message.Equals("The source contains no DataRows."))
            {
                ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "alert('No record(s) found')", true);
            }
            else
            {
                ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "alert('Error Occurred while querying the Strategy KPI result')", true);
            }
        }
    }
    protected void gvStrategyKPIResult_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        if (Session["UserName"] != null)
        {
            GridViewRow row = gvStrategyKPIResult.Rows[e.RowIndex];
            //if ((row.FindControl("txtTargetValue") as TextBox).Text.Trim()=="")
            //{
            //    ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "alert('Target Value cannot be blank')", true);
            //    return;
            //}
            //if ((row.FindControl("txtActualValue") as TextBox).Text.Trim() == "")
            //{
            //    ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "alert('Actual Value cannot be blank')", true);
            //    return;
            //}
            if ((row.FindControl("txtTargetValue") as TextBox).Text.Trim() != "")
            {
                if (!(Convert.ToInt32((row.FindControl("txtTargetValue") as TextBox).Text) >= 0 && Convert.ToInt32((row.FindControl("txtTargetValue") as TextBox).Text) <= 100))
                {
                    ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "alert('Target Value cannot be less than 0(Zero) or greater than 100(Hundred)')", true);
                    return;
                }
            }
            if ((row.FindControl("txtActualValue") as TextBox).Text.Trim() != "")
            {
                if (!(Convert.ToInt32((row.FindControl("txtActualValue") as TextBox).Text) >= 0 && Convert.ToInt32((row.FindControl("txtActualValue") as TextBox).Text) <= 100))
                {
                    ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "alert('Actual Value cannot be less than 0(Zero) or greater than 100(Hundred)')", true);
                    return;
                }
            }
            try
            {
                using (SqlConnection objCon = new SqlConnection(ConfigurationManager.ConnectionStrings["EBSDEBookConn"].ToString()))
                {
                    objCon.Open();
                    row = gvStrategyKPIResult.Rows[e.RowIndex];
                    //int customerId = Convert.ToInt32(gvStrategyKPI.DataKeys[e.RowIndex].Values[0]);
                    string kpiResultID = (row.FindControl("lblKpiResultID") as Label).Text;
                    //string kpiName = (row.FindControl("txtKpiName") as TextBox).Text;
                    string sqlQuery = "update StrategyKPIResult set sectionID=@sectionID,targetValue=@targetValue,actualValue=@actualValue,majorAchievement=@majorAchievement,causeOfDelay=@causeOfDelay," +
                    "updateUser=@updateUser,updateDate=@updateDate where kpiResultID=@kpiResultID"; //,periodYear=@periodYear,period=@period,periodQtr=@periodQtr,                                                             

                    SqlCommand objCmd = new SqlCommand(sqlQuery, objCon);
                    objCmd.Parameters.AddWithValue("@kpiResultID", kpiResultID);
                    objCmd.Parameters.AddWithValue("@sectionID", ddlSection.SelectedValue);
                    //objCmd.Parameters.AddWithValue("@periodQtr", (row.FindControl("txtPeriodQtr") as TextBox).Text);
                    if ((row.FindControl("txtTargetValue") as TextBox).Text == "")
                    {
                        objCmd.Parameters.AddWithValue("@targetValue", 0);
                    }
                    else
                    {
                        objCmd.Parameters.AddWithValue("@targetValue", (row.FindControl("txtTargetValue") as TextBox).Text);
                    }
                    if ((row.FindControl("txtActualValue") as TextBox).Text == "")
                    {
                        objCmd.Parameters.AddWithValue("@actualValue", 0);
                    }
                    else
                    {
                        objCmd.Parameters.AddWithValue("@actualValue", (row.FindControl("txtActualValue") as TextBox).Text);
                    }
                    //objCmd.Parameters.AddWithValue("@period", (row.FindControl("txtPeriodAbbr") as TextBox).Text);
                    //if (((Label)row.Cells[6].FindControl("periodAbbrValue")).Text.Equals("Annually"))
                    //{
                    //    objCmd.Parameters.AddWithValue("@period", "A");
                    //}
                    //else if (((Label)row.Cells[6].FindControl("periodAbbrValue")).Text.Equals("Quaterly"))
                    //{
                    //    objCmd.Parameters.AddWithValue("@period", "Q");
                    //}
                    //else
                    //{
                    //    objCmd.Parameters.AddWithValue("@period", "");
                    //}
                    objCmd.Parameters.AddWithValue("@majorAchievement", (row.FindControl("lstAchievementsTxtArea") as HtmlTextArea).Value);
                    objCmd.Parameters.AddWithValue("@causeOfDelay", (row.FindControl("causeOfDelayTxtArea") as HtmlTextArea).Value);
                    objCmd.Parameters.AddWithValue("@updateUser", Session["UserName"].ToString());
                    objCmd.Parameters.AddWithValue("@updateDate", Convert.ToDateTime(System.DateTime.Now));
                    objCmd.ExecuteNonQuery();
                    //objCmd.Close();                             
                    gvStrategyKPIResult.EditIndex = -1;
                    //gvStrategyKPI.EditIndex = -1;
                    objCon.Close();
                    ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "alert('Strategy KPI results updated successfully')", true);
                    queryStrategyKPIResults();
                }

            }
            catch (Exception ex)
            {
                ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "alert('Error Occurred while updating Strategy KPI results')", true);
            }
        }
        else
        {
            Response.Redirect("~/LoginPage.aspx", false);
        }
    }

    private void GridViewDataBind()
    {
        gvStrategyKPIResult.DataSource = dtStrategyKPIResult;
        gvStrategyKPIResult.DataBind();
    }

    static DataTable dtStrategyKPIResult = null;
    private void queryStrategyKPIResults()
    {
        DAL dal = new DAL(ConfigurationManager.ConnectionStrings["EBSDEBookConn"].ToString());

        if (dal.ConnectDB(this.Page) == 'E')
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "alert('Error occurred while establishing connection to the database')");
            return;
        }
        if (ddlSection.SelectedValue != "" && ddlSectionObjective.SelectedValue != "")
        {
            if (ddlQuarter.Visible)
            {
                if (ddlYear.SelectedValue != "" && ddlPeriod.SelectedValue != "" && ddlQuarter.SelectedValue != "")
                {                   
                     
                    dtStrategyKPIResult = dal.GetDataFromDB("KPIDetails", "SELECT StrategyKPIResult.kpiResultID, StrategyKPI.kpiNo, StrategyKPI.kpiName,StrategyKPI.kpiDefinition, StrategyKPIResult.periodYear, StrategyKPIResult.periodQtr, StrategyKPIResult.targetValue, " +
                    "StrategyKPIResult.actualValue, StrategyKPIResult.period,StrategyKPIResult.majorAchievement,StrategyKPIResult.causeOfDelay FROM StrategyKPI INNER JOIN StrategyKPIResult ON StrategyKPI.kpiID = StrategyKPIResult.kpiID WHERE StrategyKPIResult.sectionID=" + ddlSection.SelectedValue +
                    " and StrategyKPIResult.periodYear='" + ddlYear.SelectedValue + "' and StrategyKPIResult.period='" + ddlPeriod.SelectedValue + "' and StrategyKPIResult.periodQtr='" + ddlQuarter.SelectedValue + "' and StrategyKPI.sectObjID=" + ddlSectionObjective.SelectedValue.Split(',')[0]);
                    GridViewDataBind();
                }
                else if (ddlYear.SelectedValue != "" && ddlPeriod.SelectedValue == "" && ddlQuarter.SelectedValue != "")
                {
                    dtStrategyKPIResult = dal.GetDataFromDB("KPIDetails", "SELECT StrategyKPIResult.kpiResultID, StrategyKPI.kpiNo, StrategyKPI.kpiName,StrategyKPI.kpiDefinition, StrategyKPIResult.periodYear, StrategyKPIResult.periodQtr, StrategyKPIResult.targetValue, " +
                    "StrategyKPIResult.actualValue, StrategyKPIResult.period,StrategyKPIResult.majorAchievement,StrategyKPIResult.causeOfDelay FROM StrategyKPI INNER JOIN StrategyKPIResult ON StrategyKPI.kpiID = StrategyKPIResult.kpiID WHERE StrategyKPIResult.sectionID=" + ddlSection.SelectedValue +
                    " and StrategyKPIResult.periodYear='" + ddlYear.SelectedValue + "' and StrategyKPIResult.periodQtr='" + ddlQuarter.SelectedValue + "' and StrategyKPI.sectObjID=" + ddlSectionObjective.SelectedValue.Split(',')[0]);
                    GridViewDataBind();
                }
                else if (ddlYear.SelectedValue == "" && ddlPeriod.SelectedValue != "" && ddlQuarter.SelectedValue != "")
                {
                    dtStrategyKPIResult = dal.GetDataFromDB("KPIDetails", "SELECT StrategyKPIResult.kpiResultID, StrategyKPI.kpiNo, StrategyKPI.kpiName,StrategyKPI.kpiDefinition, StrategyKPIResult.periodYear, StrategyKPIResult.periodQtr, StrategyKPIResult.targetValue, " +
                    "StrategyKPIResult.actualValue, StrategyKPIResult.period,StrategyKPIResult.majorAchievement,StrategyKPIResult.causeOfDelay FROM StrategyKPI INNER JOIN StrategyKPIResult ON StrategyKPI.kpiID = StrategyKPIResult.kpiID WHERE StrategyKPIResult.sectionID=" + ddlSection.SelectedValue +
                    " and StrategyKPIResult.period='" + ddlPeriod.SelectedValue + "' and StrategyKPIResult.periodQtr='" + ddlQuarter.SelectedValue + "' and StrategyKPI.sectObjID=" + ddlSectionObjective.SelectedValue.Split(',')[0]);
                    GridViewDataBind();
                }
                else if (ddlYear.SelectedValue == "" && ddlPeriod.SelectedValue == "" && ddlQuarter.SelectedValue != "")
                {
                    dtStrategyKPIResult = dal.GetDataFromDB("KPIDetails", "SELECT StrategyKPIResult.kpiResultID, StrategyKPI.kpiNo, StrategyKPI.kpiName,StrategyKPI.kpiDefinition, StrategyKPIResult.periodYear, StrategyKPIResult.periodQtr, StrategyKPIResult.targetValue, " +
                    "StrategyKPIResult.actualValue, StrategyKPIResult.period,StrategyKPIResult.majorAchievement,StrategyKPIResult.causeOfDelay FROM StrategyKPI INNER JOIN StrategyKPIResult ON StrategyKPI.kpiID = StrategyKPIResult.kpiID WHERE StrategyKPIResult.sectionID=" + ddlSection.SelectedValue +
                    " and StrategyKPIResult.periodQtr='" + ddlQuarter.SelectedValue + "' and StrategyKPI.sectObjID=" + ddlSectionObjective.SelectedValue.Split(',')[0]);
                    GridViewDataBind();
                }
                else if (ddlYear.SelectedValue == "" && ddlPeriod.SelectedValue != "" && ddlQuarter.SelectedValue == "")
                {
                    dtStrategyKPIResult = dal.GetDataFromDB("KPIDetails", "SELECT StrategyKPIResult.kpiResultID, StrategyKPI.kpiNo, StrategyKPI.kpiName,StrategyKPI.kpiDefinition, StrategyKPIResult.periodYear, StrategyKPIResult.periodQtr, StrategyKPIResult.targetValue, " +
                    "StrategyKPIResult.actualValue, StrategyKPIResult.period,StrategyKPIResult.majorAchievement,StrategyKPIResult.causeOfDelay FROM StrategyKPI INNER JOIN StrategyKPIResult ON StrategyKPI.kpiID = StrategyKPIResult.kpiID WHERE StrategyKPIResult.sectionID=" + ddlSection.SelectedValue +
                    " and StrategyKPIResult.period='" + ddlPeriod.SelectedValue + "' and StrategyKPI.sectObjID=" + ddlSectionObjective.SelectedValue.Split(',')[0]);
                    GridViewDataBind();
                }
                else if (ddlYear.SelectedValue != "" && ddlPeriod.SelectedValue != "" && ddlQuarter.SelectedValue == "")
                {
                    dtStrategyKPIResult = dal.GetDataFromDB("KPIDetails", "SELECT StrategyKPIResult.kpiResultID, StrategyKPI.kpiNo, StrategyKPI.kpiName,StrategyKPI.kpiDefinition, StrategyKPIResult.periodYear, StrategyKPIResult.periodQtr, StrategyKPIResult.targetValue, " +
                    "StrategyKPIResult.actualValue, StrategyKPIResult.period,StrategyKPIResult.majorAchievement,StrategyKPIResult.causeOfDelay FROM StrategyKPI INNER JOIN StrategyKPIResult ON StrategyKPI.kpiID = StrategyKPIResult.kpiID WHERE StrategyKPIResult.sectionID=" + ddlSection.SelectedValue +
                    " and StrategyKPIResult.periodYear='" + ddlYear.SelectedValue + "' and StrategyKPIResult.period='" + ddlPeriod.SelectedValue + "' and StrategyKPI.sectObjID=" + ddlSectionObjective.SelectedValue.Split(',')[0]);
                    GridViewDataBind();
                }
                else if (ddlYear.SelectedValue != "" && ddlPeriod.SelectedValue == "" && ddlQuarter.SelectedValue == "")
                {
                    dtStrategyKPIResult = dal.GetDataFromDB("KPIDetails", "SELECT StrategyKPIResult.kpiResultID, StrategyKPI.kpiNo, StrategyKPI.kpiName,StrategyKPI.kpiDefinition, StrategyKPIResult.periodYear, StrategyKPIResult.periodQtr, StrategyKPIResult.targetValue, " +
                    "StrategyKPIResult.actualValue, StrategyKPIResult.period,StrategyKPIResult.majorAchievement,StrategyKPIResult.causeOfDelay FROM StrategyKPI INNER JOIN StrategyKPIResult ON StrategyKPI.kpiID = StrategyKPIResult.kpiID WHERE StrategyKPIResult.sectionID=" + ddlSection.SelectedValue +
                    " and StrategyKPIResult.periodYear='" + ddlYear.SelectedValue + "' and StrategyKPI.sectObjID=" + ddlSectionObjective.SelectedValue.Split(',')[0]);
                    GridViewDataBind();
                }
                else
                {
                    FillKPIs();
                }
            }
            else
            {
                if (ddlYear.SelectedValue != "" && ddlPeriod.SelectedValue == "")
                {
                    dtStrategyKPIResult = dal.GetDataFromDB("KPIDetails", "SELECT StrategyKPIResult.kpiResultID, StrategyKPI.kpiNo, StrategyKPI.kpiName,StrategyKPI.kpiDefinition, StrategyKPIResult.periodYear, StrategyKPIResult.periodQtr, StrategyKPIResult.targetValue, " +
                    "StrategyKPIResult.actualValue, StrategyKPIResult.period,StrategyKPIResult.majorAchievement,StrategyKPIResult.causeOfDelay FROM StrategyKPI INNER JOIN StrategyKPIResult ON StrategyKPI.kpiID = StrategyKPIResult.kpiID WHERE StrategyKPIResult.sectionID=" + ddlSection.SelectedValue +
                    " and StrategyKPIResult.periodYear='" + ddlYear.SelectedValue + "' and StrategyKPI.sectObjID=" + ddlSectionObjective.SelectedValue.Split(',')[0]);
                    GridViewDataBind();
                }
                else if (ddlYear.SelectedValue == "" && ddlPeriod.SelectedValue != "")
                {
                    dtStrategyKPIResult = dal.GetDataFromDB("KPIDetails", "SELECT StrategyKPIResult.kpiResultID, StrategyKPI.kpiNo, StrategyKPI.kpiName,StrategyKPI.kpiDefinition, StrategyKPIResult.periodYear, StrategyKPIResult.periodQtr, StrategyKPIResult.targetValue, " +
                    "StrategyKPIResult.actualValue, StrategyKPIResult.period,StrategyKPIResult.majorAchievement,StrategyKPIResult.causeOfDelay FROM StrategyKPI INNER JOIN StrategyKPIResult ON StrategyKPI.kpiID = StrategyKPIResult.kpiID WHERE StrategyKPIResult.sectionID=" + ddlSection.SelectedValue +
                    " and StrategyKPIResult.period='" + ddlPeriod.SelectedValue + "' and StrategyKPI.sectObjID=" + ddlSectionObjective.SelectedValue.Split(',')[0]);
                    GridViewDataBind();
                }
                else if (ddlYear.SelectedValue != "" && ddlPeriod.SelectedValue != "")
                {
                    dtStrategyKPIResult = dal.GetDataFromDB("KPIDetails", "SELECT StrategyKPIResult.kpiResultID, StrategyKPI.kpiNo, StrategyKPI.kpiName,StrategyKPI.kpiDefinition,StrategyKPIResult.periodYear, StrategyKPIResult.periodQtr, StrategyKPIResult.targetValue, " +
                    "StrategyKPIResult.actualValue, StrategyKPIResult.period,StrategyKPIResult.majorAchievement,StrategyKPIResult.causeOfDelay FROM StrategyKPI INNER JOIN StrategyKPIResult ON StrategyKPI.kpiID = StrategyKPIResult.kpiID WHERE StrategyKPIResult.sectionID=" + ddlSection.SelectedValue +
                    " and StrategyKPIResult.periodYear='" + ddlYear.SelectedValue + "' and StrategyKPIResult.period='" + ddlPeriod.SelectedValue + "' and StrategyKPI.sectObjID=" + ddlSectionObjective.SelectedValue.Split(',')[0]);
                    GridViewDataBind();
                }
                else
                {
                    FillKPIs();
                }
            }
        }
    }
    protected void gvStrategyKPIResult_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
    {
        gvStrategyKPIResult.EditIndex = -1;
        queryStrategyKPIResults();
    }
    //protected void gvStrategyKPIResult_OnPageIndexChanging(object sender, GridViewPageEventArgs e)
    //{
    //    gvStrategyKPIResult.PageIndex = e.NewPageIndex;
    //    //FillKPIs();
    //    queryStrategyKPIResults();
    //}
    protected void ddlSectionObjective_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (Session["UserName"] != null)
        {
            if (ddlSection.SelectedValue != "" && ddlSectionObjective.SelectedValue != "")
            {
                FillKPIs();
                if (dtStrategyKPIResult.Rows.Count != 0)
                {
                    
                    strategyRow.Style.Value = "display:block";
                    corpObjRow.Style.Value = "display:block";
                    deptObjRow.Style.Value = "display:block";
                    DataTable dtPeriodYear = dtStrategyKPIResult.DefaultView.ToTable(true, "periodYear");
                    ddlYear.DataTextField = "periodYear";
                    ddlYear.DataValueField = "periodYear";
                    ddlYear.DataSource = dtPeriodYear;
                    ddlYear.SelectedIndex = -1;
                    ddlYear.DataBind();
                    ddlYear.Items.Insert(0, new ListItem(""));
                    ddlYear.Items.FindByText(DateTime.Now.Year.ToString()).Selected = true;

                    if (dtStrategyKPIResult.Select("periodAbbr<>''").Count() != 0)
                    {
                        string[] colNames = new string[2];
                        colNames[0] = "period";
                        colNames[1] = "periodAbbr";
                        DataTable dtPeriod = dtStrategyKPIResult.Select("periodAbbr<>''").AsEnumerable().CopyToDataTable().DefaultView.ToTable(true, colNames).Copy();
                        ddlPeriod.DataTextField = "period";
                        ddlPeriod.DataValueField = "periodAbbr";
                        ddlPeriod.DataSource = dtPeriod;
                        ddlPeriod.SelectedIndex = -1;
                        ddlPeriod.DataBind();
                        ddlPeriod.Items.Insert(0, new ListItem(""));
                        ddlPeriod.Items.FindByText("Annual").Selected = true;
                    }

                    if (dtStrategyKPIResult.Select("periodQtr<>''").Count() != 0)
                    {
                        DataTable dtPeriodQtr = dtStrategyKPIResult.Select("periodQtr<>''").AsEnumerable().CopyToDataTable().DefaultView.ToTable(true, "periodQtr").Copy();
                        ddlQuarter.DataTextField = "periodQtr";
                        ddlQuarter.DataValueField = "periodQtr";
                        ddlQuarter.DataSource = dtPeriodQtr;
                        ddlQuarter.SelectedIndex = -1;
                        ddlQuarter.DataBind();
                        ddlQuarter.Items.Insert(0, new ListItem(""));
                        ddlQuarter.Visible = false;
                        quarter.Visible = false;
                    }
                }
                queryStrategyKPIResults();
                if (ddlSectionObjective.SelectedValue != "")
                {
                    UtilityClass ulCls = new UtilityClass(this.Page); ;
                    ulCls.PopulateDropDownBox(ddlDeptObjective, "SELECT corpObjectiveID, deptObjNo+' '+deptObjDesc AS deptObjDesc FROM StrategyDeptObjective where deptObjID=" + ddlSectionObjective.SelectedValue.Split(',')[1] + " and deptObjDesc is not Null", "corpObjectiveID", "deptObjDesc", true);
                    if (ddlDeptObjective.Items.Count != 0)
                    {
                        ulCls.PopulateDropDownBox(ddlCorpObjective, "SELECT themeID, objectiveNo+'-'+objectiveTitle AS objectiveTitle FROM StrategyCorpObjective where corpObjectiveID=" + ddlDeptObjective.SelectedValue + " and objectiveTitle is not Null and objectiveTitle<>''", "themeID", "objectiveTitle", true);
                    }
                    if (ddlCorpObjective.Items.Count != 0)
                    {
                        ulCls.PopulateDropDownBox(ddlStrategyTheme, "SELECT DISTINCT themeID,CAST(themeID AS nvarchar(10))+'-'+themeName AS themeName FROM StrategyTheme where themeID=" + ddlCorpObjective.SelectedValue, "themeID", "themeName", true);
                    }
                }
                else
                {
                    ddlDeptObjective.Items.Clear();
                    ddlCorpObjective.Items.Clear();
                    ddlStrategyTheme.Items.Clear();
                }

                //string sqlQuery = "SELECT DISTINCT Section.sectionID, Section.sectionName FROM StrategyKPIResult INNER JOIN StrategyObjSect ON StrategyKPIResult.sectionID = StrategyObjSect.sectionID " +
                //"INNER JOIN StrategySectObjective ON StrategyObjSect.sectObjID = StrategySectObjective.sectObjID            
            }
            else
            {
                strategyRow.Style.Value = "display:none";
                corpObjRow.Style.Value = "display:none";
                deptObjRow.Style.Value = "display:none";
                ddlDeptObjective.Items.Clear();
                ddlCorpObjective.Items.Clear();
                ddlStrategyTheme.Items.Clear();
                ddlSectionObjective.Items.Clear();
                ddlYear.Items.Clear();
                ddlPeriod.Items.Clear();
                ddlQuarter.Items.Clear();
                gvStrategyKPIResult.DataSource = null;
                gvStrategyKPIResult.DataBind();
            }
        }
        else
        {
            Response.Redirect("~/LoginPage.aspx", false);
        }

        //PopulateDropDownBox(ddlKPIName, "SELECT CAST(kpiID AS nvarchar(10)) +','+kpiNo as kpiIDNo , kpiName FROM StrategyKPI where sectObjID=" + ddlSectionObjective.SelectedValue, "kpiIDNo", "kpiName");
        //FillKPIDefinition();
    }
    protected void ddlSection_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            if (ddlSection.SelectedValue != "") //ddlSectionObjective.SelectedValue != "" && 
            {
                ddlStrategyTheme.Items.Clear();
                ddlCorpObjective.Items.Clear();
                ddlDeptObjective.Items.Clear();
                ddlSectionObjective.Items.Clear();
                ddlYear.SelectedIndex = -1;
                ddlPeriod.SelectedIndex = -1;
                ddlQuarter.SelectedIndex = -1;                
                UtilityClass ulCls = new UtilityClass(this.Page);
                ulCls.PopulateDropDownBox(ddlSectionObjective, "SELECT distinct CAST(StrategySectObjective.sectObjID AS nvarchar(10))+','+CAST(StrategySectObjective.deptObjID AS nvarchar(10)) As sectDeptObjIDs, sectObjNo+' '+sectObjDesc AS sectObjDesc FROM StrategySectObjective join StrategyKPI ON StrategySectObjective.sectObjID = StrategyKPI.sectObjID join StrategyKPIResult ON StrategyKPIResult.kpiID = StrategyKPI.kpiID where StrategyKPIResult.sectionID=" + ddlSection.SelectedValue, "sectDeptObjIDs", "sectObjDesc", false);
                //queryStrategyKPIResults();     
                strategyRow.Style.Value = "display:none";
                corpObjRow.Style.Value = "display:none";
                deptObjRow.Style.Value = "display:none";
                Session["IsKPIResultLoaded"] = "1";
            }
            else
            {
                ddlYear.Items.Clear();
                ddlPeriod.Items.Clear();
                ddlQuarter.Items.Clear();
                gvStrategyKPIResult.DataSource = null;
                gvStrategyKPIResult.DataBind();
            }
        }
        catch (Exception ex)
        {
            //update.Visible = false;
            if (ex.Message.Equals("The source contains no DataRows."))
            {
                ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "alert('No record(s) found')", true);
            }
            else
            {
                ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Error Occurred while populating the Strategy KPI Result')</script>", false);
            }
        }

        //if (ddlSection.SelectedValue != "")
        //{
        //    PopulateDropDownBox(ddlSectionObjective, "SELECT distinct ssb.sectObjID,ssb.sectObjNo+' '+ssb.sectObjDesc AS sectObjDesc FROM StrategyTheme st INNER JOIN StrategyCorpObjective sco ON st.themeID = sco.themeID INNER JOIN StrategyDeptObjective sdo ON sco.corpObjectiveID = sdo.corpObjectiveID " +
        //    "INNER JOIN StrategySectObjective ssb ON sdo.deptObjID = ssb.deptObjID INNER JOIN StrategyKPI sk ON ssb.sectObjID = sk.sectObjID INNER JOIN StrategyKPIResult skr ON sk.kpiID = skr.kpiID INNER JOIN Section sec ON skr.sectionID = sec.sectionID "+
        //    "WHERE sec.sectionID="+ddlSection.SelectedValue+" and st.themeID="+ddlStrategyTheme.SelectedValue+ " and sco.corpObjectiveID="+ ddlCorpObjective.SelectedValue +" and sdo.deptObjID=" + ddlDeptObjective.SelectedValue,"sectObjID", "sectObjDesc");

        //    //PopulateDropDownBox(ddlSectionObjective, "SELECT DISTINCT d.sectObjID,d.sectObjNo+' '+d.sectObjDesc AS sectObjDesc FROM StrategySectObjective d INNER JOIN StrategyObjSect e ON d.sectObjID = e.sectObjID WHERE e.sectionID =" + ddlSection.SelectedValue,
        //    //"sectObjID", "sectObjDesc");
        //    //Session["DeptObjectiveID"] = ddlSectionObjective.SelectedValue;
        //}
        //else
        //{               
        //    ddlSectionObjective.Items.Clear();
        //    ddlYear.Items.Clear();
        //    ddlPeriod.Items.Clear();
        //    ddlQuarter.Items.Clear();
        //    gvStrategyKPIResult.DataSource = null;
        //    gvStrategyKPIResult.DataBind();
        //}
    }
    protected void ddlPeriod_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            if (ddlPeriod.SelectedValue.Equals("A") || ddlPeriod.SelectedValue.Equals(""))
            {
                quarter.Visible = false;
                ddlQuarter.Visible = false;
            }
            else
            {
                quarter.Visible = true;
                ddlQuarter.Visible = true;
            }
            queryStrategyKPIResults();
        }
        catch (System.Exception ex)
        {
            if (ex.Message.Equals("The source contains no DataRows."))
            {
                ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "alert('No record(s) found')", true);
            }
            else
            {
                ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "alert('Error Occurred while querying the Strategy KPI result')", true);
            }
        }

    }

    protected void ddlQuarter_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            queryStrategyKPIResults();
        }
        catch (System.Exception ex)
        {
            if (ex.Message.Equals("The source contains no DataRows."))
            {
                ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "alert('No record(s) found')", true);
            }
            else
            {
                ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "alert('Error Occurred while querying the Strategy KPI result')", true);
            }
        }
    }
     
    protected void gvStrategyKPIResult_RowEditing(object sender, GridViewEditEventArgs e)
    {
        if (Session["UserName"] != null)
        {
            try
            {
                gvStrategyKPIResult.EditIndex = e.NewEditIndex;
                gvStrategyKPIResult.DataSource = dtStrategyKPIResult;
                gvStrategyKPIResult.DataBind();
                GridViewRow row = gvStrategyKPIResult.Rows[e.NewEditIndex];

                //(row.FindControl("txtPeriodQtr") as TextBox).Enabled = true;
                //(row.FindControl("txtPeriodQtr") as TextBox).BackColor = System.Drawing.Color.FromName("#ffffff");
                if ((row.FindControl("txtTargetValue") as TextBox).Text.Trim() == "")
                {
                    (row.FindControl("txtTargetValue") as TextBox).Enabled = true;
                    (row.FindControl("txtTargetValue") as TextBox).BackColor = System.Drawing.Color.FromName("#ffffff");
                }
                else
                {
                    (row.FindControl("txtTargetValue") as TextBox).Enabled = false;
                }
                (row.FindControl("txtActualValue") as TextBox).Enabled = true;
                (row.FindControl("txtActualValue") as TextBox).BackColor = System.Drawing.Color.FromName("#ffffff");
                //(row.FindControl("txtPeriodQtr") as TextBox).Enabled = true;
                //(row.FindControl("txtPeriodQtr") as TextBox).BackColor = System.Drawing.Color.FromName("#ffffff");
                (row.FindControl("lstAchievementsTxtArea") as HtmlTextArea).Disabled = false;
                (row.FindControl("lstAchievementsTxtArea") as HtmlTextArea).Style.Add("background-color", "#ffffff");
                (row.FindControl("causeOfDelayTxtArea") as HtmlTextArea).Disabled = false;
                (row.FindControl("causeOfDelayTxtArea") as HtmlTextArea).Style.Add("background-color", "#ffffff");
                //gvStrategyKPI.EditIndex = -1;         
                //kpiResultID = (row.FindControl("lblKpiResultID") as Label).Text;              

            }
            catch (Exception ex)
            {
                ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "alert('Error Occurred while Editing Strategy KPI')", true);
            }
        }
        else
        {
            Response.Redirect("~/LoginPage.aspx", false);
        }
    }
    private void FillKPIs()
    {
        DAL dal = new DAL(ConfigurationManager.ConnectionStrings["EBSDEBookConn"].ToString());

        if (dal.ConnectDB(this.Page) == 'E')
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "alert('Error occurred while establishing connection to the database')");
            return;
        }
        dtStrategyKPIResult = dal.GetDataFromDB("KPIDetails", "SELECT StrategyKPIResult.kpiResultID, StrategyKPI.kpiNo, StrategyKPI.kpiName, StrategyKPI.kpiDefinition,StrategyKPIResult.periodYear, StrategyKPIResult.periodQtr, StrategyKPIResult.targetValue, " +
        "StrategyKPIResult.actualValue, StrategyKPIResult.period As periodAbbr, Case WHEN CAST(StrategyKPIResult.period AS char(1))='A' THEN 'Annual' ELSE 'Quater' End As period,StrategyKPIResult.majorAchievement,StrategyKPIResult.causeOfDelay FROM StrategyKPI INNER JOIN StrategyKPIResult ON StrategyKPI.kpiID  = StrategyKPIResult.kpiID " +
        " WHERE StrategyKPI.sectObjID=" + ddlSectionObjective.SelectedValue.Split(',')[0] + " and StrategyKPIResult.sectionID=" + ddlSection.SelectedValue);
        GridViewDataBind();
    }
}