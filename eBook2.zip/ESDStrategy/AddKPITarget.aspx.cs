﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;

public partial class AddKPITarget : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["SectionID"] != null)
        {
            if (!IsPostBack)
            {
                // getUnReadInchargeData();
                UtilityClass ulCls = new UtilityClass(this.Page);
                ulCls.PopulateDropDownBox(ddlStrategyTheme, "SELECT DISTINCT themeID,CAST(themeID AS nvarchar(10))+'-'+themeName AS themeName FROM StrategyTheme", "themeID", "themeName", false);
                Session["IsSRLoaded"] = "0";
            }
        }
        else
        {
            Response.Redirect("~/LoginPage.aspx", false);
        }
    }
    protected void gvStrategyKPIResult_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        if (Session["UserName"] != null)
        {
            try
            {
                using (SqlConnection objCon = new SqlConnection(ConfigurationManager.ConnectionStrings["EBSDEBookConn"].ToString()))
                {
                    objCon.Open();
                    GridViewRow row = gvStrategyKPIResult.Rows[e.RowIndex];
                    //int customerId = Convert.ToInt32(gvStrategyKPI.DataKeys[e.RowIndex].Values[0]);
                    string kpiResultID = (row.FindControl("lblKpiResultID") as Label).Text;
                    //string kpiName = (row.FindControl("txtKpiName") as TextBox).Text;
                    string sqlQuery = "update StrategyKPIResult set targetValue=@targetValue,updateUser=@updateUser,updateDate=@updateDate where kpiResultID=@kpiResultID"; //,periodYear=@periodYear,period=@period,periodQtr=@periodQtr,                     


                    SqlCommand objCmd = new SqlCommand(sqlQuery, objCon);
                    objCmd.Parameters.AddWithValue("@kpiResultID", kpiResultID);
                    //objCmd.Parameters.AddWithValue("@sectionID", ddlSection.SelectedValue);
                    //objCmd.Parameters.AddWithValue("@periodQtr", (row.FindControl("txtPeriodQtr") as TextBox).Text);
                    objCmd.Parameters.AddWithValue("@targetValue", (row.FindControl("txtTargetValue") as TextBox).Text);
                    //objCmd.Parameters.AddWithValue("@period", (row.FindControl("txtPeriodAbbr") as TextBox).Text);
                    //if (((Label)row.Cells[6].FindControl("periodAbbrValue")).Text.Equals("Annually"))
                    //{
                    //    objCmd.Parameters.AddWithValue("@period", "A");
                    //}
                    //else if (((Label)row.Cells[6].FindControl("periodAbbrValue")).Text.Equals("Quaterly"))
                    //{
                    //    objCmd.Parameters.AddWithValue("@period", "Q");
                    //}
                    //else
                    //{
                    //    objCmd.Parameters.AddWithValue("@period", "");
                    //}                     
                    objCmd.Parameters.AddWithValue("@updateUser", Session["UserName"].ToString());
                    objCmd.Parameters.AddWithValue("@updateDate", Convert.ToDateTime(System.DateTime.Now));
                    objCmd.ExecuteNonQuery();
                    //objCmd.Close();                             
                    gvStrategyKPIResult.EditIndex = -1;
                    //gvStrategyKPI.EditIndex = -1;
                    objCon.Close();
                    ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "alert('Strategy KPI results updated successfully')", true);
                    FillKPIs();
                    //queryStrategyKPIResults();
                }

            }
            catch (Exception ex)
            {
                ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "alert('Error Occurred while updating Strategy KPI results')", true);
            }
        }
        else
        {
            Response.Redirect("~/LoginPage.aspx", false);
        }
    }
    protected void gvStrategyKPIResult_RowEditing(object sender, GridViewEditEventArgs e)
    {
        if (Session["UserName"] != null)
        {
            try
            {
                gvStrategyKPIResult.EditIndex = e.NewEditIndex;
                gvStrategyKPIResult.DataSource = dtStrategyKPIResult;
                gvStrategyKPIResult.DataBind();
                GridViewRow row = gvStrategyKPIResult.Rows[e.NewEditIndex];

                //(row.FindControl("txtPeriodQtr") as TextBox).Enabled = true;
                //(row.FindControl("txtPeriodQtr") as TextBox).BackColor = System.Drawing.Color.FromName("#ffffff");
                (row.FindControl("txtTargetValue") as TextBox).Enabled = true;
                (row.FindControl("txtTargetValue") as TextBox).BackColor = System.Drawing.Color.FromName("#ffffff");

                //gvStrategyKPI.EditIndex = -1;         
                //kpiResultID = (row.FindControl("lblKpiResultID") as Label).Text;              

            }
            catch (Exception ex)
            {
                ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "alert('Error Occurred while Editing KPI Target')", true);
            }
        }
        else
        {
            Response.Redirect("~/LoginPage.aspx", false);
        }
    }
    protected void ddlSectionObjective_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            if (ddlSectionObjective.SelectedValue != "")
            {
                UtilityClass utCls = new UtilityClass(this.Page);
                utCls.PopulateDropDownBox(ddlKPI, "SELECT distinct StrategyKPI.kpiID, StrategyKPI.kpiName " + //REPLACE(REPLACE(StrategyKPI.kpiName, CHAR(13), ''), CHAR(10), '') as kpiName,
                " FROM StrategyKPI join StrategyDeptObjective on StrategyKPI.deptObjID=StrategyDeptObjective.deptObjID WHERE " +
                "StrategyKPI.sectObjID =" + ddlSectionObjective.SelectedValue + " and StrategyKPI.deptObjID =" + ddlDeptObjective.SelectedValue, "kpiID", "kpiName", false);
            }
            else
            {
                ddlKPI.Items.Clear();
                ddlSection.Items.Clear();
                ddlYear.Items.Clear();
                 
                txtTarget.Text = "";
            }
        }
        catch (Exception ex)
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Error Occurred while populating the Section Objective')</script>", false);
        }
    }
    protected void ddlDeptObjective_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (Session["UserName"] != null)
        {
            if (ddlStrategyTheme.SelectedValue != "" && ddlDeptObjective.SelectedValue != "" && ddlCorpObjective.SelectedValue != "")
            {
                UtilityClass ulCls = new UtilityClass(this.Page);
                ulCls.PopulateDropDownBox(ddlSectionObjective, "SELECT sectObjID, sectObjNo+' '+sectObjDesc AS sectObjDesc FROM StrategySectObjective where deptObjID=" + ddlDeptObjective.SelectedValue, "sectObjID", "sectObjDesc", false);                 
            }
            else
            {
                ddlSectionObjective.Items.Clear();
                ddlKPI.Items.Clear();
                ddlSection.Items.Clear();
                ddlYear.Items.Clear();
                txtTarget.Text = "";
               
            }
        }
        else
        {
            Response.Redirect("~/LoginPage.aspx", false);
        }

    }
    protected void ddlStrategyTheme_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlStrategyTheme.SelectedValue != "")
        {
            UtilityClass ulCls = new UtilityClass(this.Page);
            ulCls.PopulateDropDownBox(ddlCorpObjective, "SELECT corpObjectiveID, objectiveNo+'-'+objectiveTitle AS objectiveTitle FROM StrategyCorpObjective where themeID=" + ddlStrategyTheme.SelectedValue + " and objectiveTitle is not Null", "corpObjectiveID", "objectiveTitle", false);
            save.Enabled = true;
        }
        else
        {
            ddlCorpObjective.Items.Clear();
            ddlDeptObjective.Items.Clear();
            ddlSectionObjective.Items.Clear();
            ddlKPI.Items.Clear();
            ddlSection.Items.Clear();
            ddlYear.Items.Clear();
            txtTarget.Text = "";
        }
    }
    protected void ddlCorpObjective_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlCorpObjective.SelectedValue != "")
        {
            UtilityClass utCls = new UtilityClass(this.Page);
            utCls.PopulateDropDownBox(ddlDeptObjective, "SELECT deptObjID, deptObjNo+' '+deptObjDesc AS deptObjDesc FROM StrategyDeptObjective where corpObjectiveID=" + ddlCorpObjective.SelectedValue, "deptObjID", "deptObjDesc", false);
        }
        else
        {
            ddlCorpObjective.Items.Clear();
            ddlDeptObjective.Items.Clear();
            ddlSectionObjective.Items.Clear();
            ddlKPI.Items.Clear();
            ddlSection.Items.Clear();
            ddlYear.Items.Clear();
            txtTarget.Text = "";
        }
    }
    protected void gvStrategyKPIResult_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            if ((e.Row.FindControl("txtPeriod") as TextBox) != null)
            {
                string period = (e.Row.FindControl("txtPeriod") as TextBox).Text;
                //TextBox txtPeriod = (TextBox)e.Row.FindControl("txtPeriod");
                //Label periodValue = (Label)e.Row.FindControl("periodAbbrValue");
                if (period != "")
                {
                    if (period.Equals("A"))
                    {
                        (e.Row.FindControl("txtPeriod") as TextBox).Text = "Annual";
                    }
                    else
                    {
                        (e.Row.FindControl("txtPeriod") as TextBox).Text = "Quarter";
                    }
                }
            }
        }
    }
    protected void gvStrategyKPIResult_OnPageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        gvStrategyKPIResult.PageIndex = e.NewPageIndex;
        FillKPIs();
    }
    protected void gvStrategyKPIResult_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
    {
        gvStrategyKPIResult.EditIndex = -1;
        FillKPIs();
    }
    private void DisableControls()
    {
        ddlStrategyTheme.Enabled = false;
        ddlCorpObjective.Enabled = false;
        ddlDeptObjective.Enabled = false;
        ddlSectionObjective.Enabled = false;
        ddlKPI.Enabled = false;
        ddlSection.Enabled = false;
        ddlYear.Enabled = false;
        txtTarget.Enabled = false;
    }
    static DataTable dtStrategyKPIResult = null; 
    private void FillKPIs()
    {
         DAL dal = new DAL(ConfigurationManager.ConnectionStrings["EBSDEBookConn"].ToString());

        if (dal.ConnectDB(this.Page) == 'E')
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "alert('Error occurred while establishing connection to the database')");
            return;
        }

        dtStrategyKPIResult = dal.GetDataFromDB("KPIDetails", "SELECT StrategyKPIResult.kpiResultID, StrategyKPI.kpiNo, StrategyKPI.kpiName, StrategyKPIResult.periodYear, StrategyKPIResult.periodQtr, StrategyKPIResult.targetValue, " +
        "StrategyKPIResult.period FROM StrategyKPI INNER JOIN StrategyKPIResult ON StrategyKPI.kpiID = StrategyKPIResult.kpiID WHERE StrategyKPIResult.kpiID=" + ddlKPI.SelectedValue + " and StrategyKPIResult.sectionID=" + ddlSection.SelectedValue +
        " and StrategyKPIResult.periodYear=" + ddlYear.SelectedValue);
        GridViewDataBind();
    }
    private void GridViewDataBind()
    {
        gvStrategyKPIResult.DataSource = dtStrategyKPIResult;
        gvStrategyKPIResult.DataBind();
    }
    protected void ddlKPI_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            if (ddlKPI.SelectedValue != "")
            {
                UtilityClass utCls = new UtilityClass(this.Page);              

                string sqlQuery = null;
                if (Session["SectionID"].ToString().Equals("7"))
                {
                    sqlQuery = "SELECT DISTINCT sectionID, sectionName FROM Section where sectionID in(1,5,9,11,13,14,100)";
                }
                else
                {
                    sqlQuery = "SELECT DISTINCT sectionID, sectionName FROM Section WHERE (sectionID = " + Session["SectionID"].ToString() + ")";
                }
                utCls.PopulateDropDownBox(ddlSection, sqlQuery, "sectionID", "sectionName", false);
               
                ddlYear.Items.Add(new ListItem(DateTime.Now.Year.ToString(), DateTime.Now.Year.ToString()));
                for (short iCounter = 1; iCounter <= 10; iCounter++)
                {
                    string year = (DateTime.Now.Year + iCounter).ToString();
                    ddlYear.Items.Add(new ListItem(year, year));
                }
                ddlYear.Items.FindByText(DateTime.Now.Year.ToString()).Selected = true;                            
            }
            else
            {
                ddlSection.Items.Clear();
                ddlYear.Items.Clear();
                txtTarget.Text = "";
            }
        }
        catch (Exception ex)
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Error Occurred while populating the Strategy KPI Result')</script>", false);
        }
    }
    protected void save_Click(object sender, EventArgs e)
    {
        if (Session["UserName"] != null)
        {
            bool isSuccess = false;
            try
            {
                if (ddlKPI.SelectedValue != "" && ddlSection.SelectedValue != "" && ddlYear.SelectedValue != "")
                {
                    using (SqlConnection objCon = new SqlConnection(ConfigurationManager.ConnectionStrings["EBSDEBookConn"].ConnectionString))
                    {
                        objCon.Open();
                        short iCounter = 1;
                        string period = null;
                        string periodQtr = null;
                        while (iCounter < 6)
                        {
                            string sqlQuery = "select kpiID,targetValue from StrategyKPIResult where kpiID=@kpiID and sectionID=@sectionID and (period=@period) and periodYear=@periodYear and (periodQtr=@periodQtr or @periodQtr is Null)"; //sectObjDesc='" + txtSectionObjDescription.Text.Trim().Replace("\r", " ").Replace("\n", " ") + "'"; // where deptObjID=@deptObjID and sectObjID=@sectObjID";
                            SqlCommand objCmd = new SqlCommand(sqlQuery, objCon);
                            objCmd.Parameters.AddWithValue("@sectionID", ddlSection.SelectedValue);
                            objCmd.Parameters.AddWithValue("@kpiID", ddlKPI.SelectedValue);
                            if (iCounter == 1)
                            {
                                period = "A";
                                objCmd.Parameters.AddWithValue("@period", period);
                                objCmd.Parameters.AddWithValue("@periodQtr", DBNull.Value);
                            }
                            else if (iCounter == 2)
                            {
                                periodQtr = "Q1";
                                objCmd.Parameters.AddWithValue("@period", "Q");
                                objCmd.Parameters.AddWithValue("@periodQtr", periodQtr);
                            }
                            else if (iCounter == 3)
                            {
                                periodQtr = "Q2";
                                objCmd.Parameters.AddWithValue("@period", "Q");
                                objCmd.Parameters.AddWithValue("@periodQtr", periodQtr);
                            }
                            else if (iCounter == 4)
                            {
                                periodQtr = "Q3";
                                objCmd.Parameters.AddWithValue("@period", "Q");
                                objCmd.Parameters.AddWithValue("@periodQtr", periodQtr);
                            }
                            else if (iCounter == 5)
                            {
                                periodQtr = "Q4";
                                objCmd.Parameters.AddWithValue("@period", "Q");
                                objCmd.Parameters.AddWithValue("@periodQtr", periodQtr);
                            }
                            objCmd.Parameters.AddWithValue("@periodYear", ddlYear.SelectedValue);
                            SqlDataReader sqlDtReader = objCmd.ExecuteReader();
                            if (!sqlDtReader.HasRows)
                            {
                                sqlDtReader.Close();
                                //objCmd.Parameters.Clear();
                                sqlQuery = "insert into StrategyKPIResult(kpiID,sectionID,period,periodQtr,periodYear,targetValue,createUser,createDate) " +
                                "values(@kpiID,@sectID,@period,@periodQtr,@periodYear,@targetValue,@createUser,@createDate)";
                                objCmd = new SqlCommand(sqlQuery, objCon);

                                objCmd.Parameters.AddWithValue("@kpiID", ddlKPI.SelectedValue);
                                objCmd.Parameters.AddWithValue("@sectID", ddlSection.SelectedValue);
                                if (iCounter == 1)
                                {
                                    objCmd.Parameters.AddWithValue("@period", period);
                                    objCmd.Parameters.AddWithValue("@periodQtr", DBNull.Value);
                                }
                                else if (iCounter == 2)
                                {
                                    objCmd.Parameters.AddWithValue("@period", "Q");
                                    objCmd.Parameters.AddWithValue("@periodQtr", periodQtr);
                                }
                                else if (iCounter == 3)
                                {
                                    objCmd.Parameters.AddWithValue("@period", "Q");
                                    objCmd.Parameters.AddWithValue("@periodQtr", periodQtr);
                                }
                                else if (iCounter == 4)
                                {
                                    objCmd.Parameters.AddWithValue("@period", "Q");
                                    objCmd.Parameters.AddWithValue("@periodQtr", periodQtr);
                                }
                                else if (iCounter == 5)
                                {
                                    objCmd.Parameters.AddWithValue("@period", "Q");
                                    objCmd.Parameters.AddWithValue("@periodQtr", periodQtr);
                                }
                                objCmd.Parameters.AddWithValue("@periodYear", ddlYear.SelectedValue);
                                objCmd.Parameters.AddWithValue("@targetValue", txtTarget.Text);
                                objCmd.Parameters.AddWithValue("@createUser", Session["UserName"].ToString());
                                objCmd.Parameters.AddWithValue("@createDate", DateTime.Now);

                                objCmd.ExecuteNonQuery();
                                isSuccess = true;
                            }
                            else
                            {
                                sqlDtReader.Close();
                            }
                            //objCmd.Parameters.Clear();
                            iCounter++;
                        }
                        objCon.Close();
                    }
                }
                if (!isSuccess)
                {
                    ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "alert('Cannot insert KPI. KPI already exists')", true);
                    save.Visible = false;
                }
                else
                {
                    ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "alert('Strategy KPI created successfully')", true);
                    DisableControls();
                    FillKPIs();
                    save.Visible = false;
                }
            }
            catch (Exception ex)
            {
                ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "alert('Error Occurred while creating Strategy KPI')", true);
                save.Visible = false;
            }
        }
        else
        {
            Response.Redirect("~/LoginPage.aspx", false);
        }

    }
}