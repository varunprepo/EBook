﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class UpdateDeptObjective : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        UtilityClass utCls = null;
        if (Session["SectionID"] != null)
        {
            if (!IsPostBack)
            {

                utCls = new UtilityClass(this.Page);
                //if (Session["SectionID"].ToString().Equals("7"))
                //{
                utCls.PopulateDropDownBox(ddlStrategyTheme, "SELECT DISTINCT themeID,CAST(themeID AS nvarchar(10))+'-'+themeName AS themeName FROM StrategyTheme", "themeID", "themeName", false);
                //}
                //else
                //{
                //    utCls.PopulateDropDownBox(ddlStrategyTheme, "SELECT DISTINCT st.themeID,CAST(st.themeID AS nvarchar(10))+'-'+st.themeName AS themeName FROM StrategyTheme st INNER JOIN StrategyCorpObjective sco ON st.themeID = sco.themeID INNER JOIN StrategyDeptObjective sdo ON sco.corpObjectiveID = sdo.corpObjectiveID " +
                //    "INNER JOIN StrategySectObjective ssb ON sdo.deptObjID = ssb.deptObjID INNER JOIN StrategyObjSect sos ON ssb.sectObjID = sos.sectObjID WHERE sos.sectionID=" + Session["SectionID"].ToString(), "themeID", "themeName",false);
                //}    
                Session["IsSRLoaded"] = "0";
            }
        }
        else
        {
            Response.Redirect("~/LoginPage.aspx", false);
        } 
    }

    protected void ddlStrategyTheme_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlStrategyTheme.SelectedValue != "")
        {
            UtilityClass ulCls = new UtilityClass(this.Page);
            ulCls.PopulateDropDownBox(ddlCorpObj, "SELECT corpObjectiveID, objectiveNo+'-'+objectiveTitle AS objectiveTitle FROM StrategyCorpObjective where themeID=" + ddlStrategyTheme.SelectedValue + " and objectiveTitle is not Null and objectiveTitle<>''", "corpObjectiveID", "objectiveTitle", false);
        }
        else
        {
            ddlCorpObj.Items.Clear();
            ClearGV();
        }
    }
    protected void ddlCorpObj_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlCorpObj.SelectedValue != "")
        {
            FillDeptObjectiveTitle();
        }
        else
        {
            ClearGV();
        }
    }

    private void ClearGV()
    {
        gvEditDeptObj.DataSource = null;
        gvEditDeptObj.DataBind();
    }

    private void FillDeptObjectiveTitle()
    {
        try
        {
            DAL dal = new DAL(ConfigurationManager.ConnectionStrings["EBSDEBookConn"].ToString());

            if (dal.ConnectDB(this.Page) == 'E')
            {
                ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "alert('Error occurred while establishing connection to the database')");
                return;
            }
                
            DataTable dtCorpObj = dal.GetDataFromDB("StrategyDeptObjective", "SELECT deptObjID,deptObjNo,deptObjDesc FROM StrategyDeptObjective WHERE" +
            " corpObjectiveID =" + ddlCorpObj.SelectedValue);
            gvEditDeptObj.DataSource = dtCorpObj;
            gvEditDeptObj.DataBind();
        }
        catch (Exception)
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "alert('Error occurred while displaying the Strategy Corp. Objective')");
        }
    }

    protected void gvEditDeptObj_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        if (Session["UserName"] != null)
        {
            try
            {
                using (SqlConnection objCon = new SqlConnection(ConfigurationManager.ConnectionStrings["EBSDEBookConn"].ToString()))
                {
                    objCon.Open();
                    GridViewRow row = gvEditDeptObj.Rows[e.RowIndex];
                    string deptObjID = (row.FindControl("lblDeptObjID") as Label).Text;
                    string deptObjDesc = (row.FindControl("txtDeptObjDesc") as TextBox).Text.Replace("\n", "").Replace("\r", "");
                    //string deptObjNo = null;
                    //if (deptObjDesc.Contains("-"))
                    //{
                    //    deptObjNo = deptObjDesc.Split(' ')[0];
                    //    deptObjDesc = deptObjDesc.Substring(deptObjDesc.LastIndexOf(deptObjNo.Split('-')[1]) + deptObjNo.Split('-')[1].Length).TrimStart();                      
                    //}
                    string sqlQuery = null;
                    SqlCommand objCmd = null;
                    //sqlQuery = "select deptObjID from StrategyDeptObjective where deptObjDesc=@deptObjDesc";
                    //objCmd = new SqlCommand(sqlQuery, objCon);
                    //objCmd.Parameters.AddWithValue("@deptObjDesc", deptObjDesc.TrimStart());
                    //SqlDataReader sqlDtReader = objCmd.ExecuteReader();
                    //if (!sqlDtReader.HasRows)
                    //{
                    //    sqlDtReader.Close();
                    //if (deptObjNo != null)
                    //{
                    //    sqlQuery = "update StrategyDeptObjective set deptObjNo=@deptObjNo,deptObjDesc=@deptObjDesc,updateUser=@updateUser,updateDate=@updateDate where deptObjID=@deptObjID";
                    //}
                    //else
                    //{
                    sqlQuery = "update StrategyDeptObjective set deptObjDesc=@deptObjDesc,updateUser=@updateUser,updateDate=@updateDate where deptObjID=@deptObjID";
                    //}
                    objCmd = new SqlCommand(sqlQuery, objCon);
                    //if (deptObjNo != null)
                    //{
                    //    objCmd.Parameters.AddWithValue("@deptObjNo", deptObjNo);
                    //}
                    objCmd.Parameters.AddWithValue("@deptObjDesc", deptObjDesc);
                    objCmd.Parameters.AddWithValue("@deptObjID", deptObjID);
                    objCmd.Parameters.AddWithValue("@updateUser", Session["UserName"].ToString());
                    objCmd.Parameters.AddWithValue("@updateDate", DateTime.Now);
                    objCmd.ExecuteNonQuery();
                    objCon.Close();
                    ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "alert('Department objective updated successfully')", true);
                    //}
                    //else
                    //{
                    //    sqlDtReader.Close();
                    //    objCon.Close();
                    //    ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "alert('Department Objective already exists')", true);
                    //}
                    gvEditDeptObj.EditIndex = -1;
                    FillDeptObjectiveTitle();
                }

            }
            catch (Exception ex)
            {
                ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "alert('Error Occurred while updating Department objective')", true);
            }
        }
        else
        {
            Response.Redirect("~/LoginPage.aspx", false);
        }
    }

    protected void gvEditDeptObj_OnPageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        gvEditDeptObj.PageIndex = e.NewPageIndex;
        FillDeptObjectiveTitle();
    }
    protected void gvEditDeptObj_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
    {
        gvEditDeptObj.EditIndex = -1;
        FillDeptObjectiveTitle();
    }
    protected void gvEditDeptObj_RowEditing(object sender, GridViewEditEventArgs e)
    {
        if (Session["UserName"] != null)
        {
            try
            {
                gvEditDeptObj.EditIndex = e.NewEditIndex;
                FillDeptObjectiveTitle();
                GridViewRow row = gvEditDeptObj.Rows[e.NewEditIndex];
                (row.FindControl("txtDeptObjDesc") as TextBox).Enabled = true;
                (row.FindControl("txtDeptObjDesc") as TextBox).BackColor = System.Drawing.Color.FromName("#ffffff");
            }
            catch (Exception ex)
            {
                ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "alert('Error Occurred while Editing Corporative Objective')", true);
            }
        }
        else
        {
            Response.Redirect("~/LoginPage.aspx", false);
        }
    }
}