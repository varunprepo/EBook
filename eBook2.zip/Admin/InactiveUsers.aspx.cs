﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using Datalayer;


public partial class Admin_InactiveUsers : System.Web.UI.Page
{
    string connValue = System.Configuration.ConfigurationManager.ConnectionStrings["EBSDEBookConn"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {           
            ViewUsersDetails();  
        }
    }
    private void ViewUsersDetails()
    { 
        string viewSql = "SELECT TOP (20) Contact.userName, UserSecurityProfile.profileName, Contact.emailAddress, Contact.officePhone, Contact.firstName + ' ' + Contact.lastName AS ActualName, " + 
                         " Contact.userShortName, Contact.isLogIn, Contact.contactID, Contact.isActive, Contact.createDate, Contact.createUser FROM " +
                         " Contact INNER JOIN  UserSecurityProfile ON Contact.userProfileID = UserSecurityProfile.userProfileID ORDER BY Contact.createDate DESC ";

        SqlConnection objCon = new SqlConnection(connValue);
        SqlCommand objCmd = new SqlCommand(viewSql, objCon);
        SqlDataAdapter objDA = new SqlDataAdapter(objCmd);

        objDA.SelectCommand.CommandText = objCmd.CommandText.ToString();
        DataTable dt = new DataTable();
        objDA.Fill(dt);

        Session["getDCJobs"] = dt;

        gridDocStatus.DataSource = dt.DefaultView;
        gridDocStatus.DataBind();
    }
    private void PopulateDropDownBox(DropDownList ddlBox, string sqlQuery, string valueMember, string displayName)
    {
        ddlBox.DataBound += new EventHandler(this.ddlBox_DataBound);
        ddlBox.DataSource = new JobOrderData().FillDropdown(sqlQuery);
        ddlBox.DataTextField = displayName;
        ddlBox.DataValueField = valueMember;
        ddlBox.SelectedIndex = -1;
        ddlBox.DataBind();
    }
    protected void ddlBox_DataBound(object sender, EventArgs e)
    {
        DropDownList ddl = (DropDownList)sender;
        ListItem emptyItem = new ListItem("", "");
        ddl.Items.Insert(0, emptyItem);
    }
    protected void gvorders_RowCommand(object sender, GridViewCommandEventArgs e)
    {

    }
    protected void gvorders_RowDataBound(object sender, GridViewRowEventArgs e)
    {

    }
    protected void gridDocStatus_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void btnAdd_Click(object sender, EventArgs e)
    {
        Response.Write("<script language='javascript'> window.open('UserDetailsWindow.aspx','','width=830,Height=550,fullscreen=1,location=0,scrollbars=0,menubar=1,toolbar=1, align=center,top=100,left=500'); </script>");
    }
    protected void Button1_Click(object sender, EventArgs e)
    {

    }
    private void UpdateLoginUsers()
    {
        string updQuery = "Update Contact Set isLogIn = 0";

        using (SqlConnection cn = new SqlConnection(connValue))
        {
            cn.Open();
            using (SqlCommand cmd = new SqlCommand())
            {
                cmd.Connection = cn;
                cmd.CommandText = updQuery;
                cmd.CommandType = CommandType.Text;
                cmd.ExecuteNonQuery();
            }
        }
    } 
   
    protected void gridDocStatus_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        gridDocStatus.PageIndex = e.NewPageIndex;
        DataTable dt = new DataTable();
        dt = Session["getDCJobs"] as DataTable;

        BindData(dt);
    }
    private void BindData(DataTable dt)
    {
        gridDocStatus.DataSource = dt;
        gridDocStatus.DataBind();
    }
    protected void gridDocStatus_Sorting(object sender, GridViewSortEventArgs e)
    {
        DataTable dataTable = gridDocStatus.DataSource as DataTable;
        if (dataTable != null)
        {
            DataView dataView = new DataView(dataTable);
            dataView.Sort = e.SortExpression + " " + ConvertSortDirectionToSql(e.SortDirection);

            gridDocStatus.DataSource = dataView;
            gridDocStatus.DataBind();
        }
    }

    private string ConvertSortDirectionToSql(SortDirection sortDirection)
    {
        string newSortDirection = String.Empty;

        switch (sortDirection)
        {
            case SortDirection.Ascending:
                newSortDirection = "ASC";
                break;

            case SortDirection.Descending:
                newSortDirection = "DESC";
                break;
        }
        return newSortDirection;
    }

    protected void Button1_Click1(object sender, EventArgs e)
    {
        if (Session["UserID"].ToString() == "1" || Session["UserID"].ToString() == "95") // Admin n sree
        {
            UpdateLoginUsers();
        }
    }
}