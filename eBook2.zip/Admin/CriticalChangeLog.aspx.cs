﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

public partial class Admin_CriticalChangeLog : System.Web.UI.Page
{
    string connValue = System.Configuration.ConfigurationManager.ConnectionStrings["EBSDEBookConn"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
    {

        if (!IsPostBack)
        {
            string sql = "SELECT  changeData, windowName, oldData, newData, updateUser, updateDate FROM  ChangeLog order by updateDate Desc";

            SqlConnection objCon = new SqlConnection(connValue);
            SqlCommand objCmd = new SqlCommand(sql, objCon);
            SqlDataAdapter objDA = new SqlDataAdapter(objCmd);

            objDA.SelectCommand.CommandText = objCmd.CommandText.ToString();
            DataTable dt = new DataTable();
            objDA.Fill(dt);

            gridDocStatus.DataSource = dt.DefaultView;
            gridDocStatus.DataBind();
        }
    }
    protected void gvorders_RowCommand(object sender, GridViewCommandEventArgs e)
    {

    }
    protected void gvorders_RowDataBound(object sender, GridViewRowEventArgs e)
    {

    }
    protected void gridDocStatus_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
}