﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

using System.Data;

public partial class Admin_ProfileAccess : System.Web.UI.Page
{
    string connValue = System.Configuration.ConfigurationManager.ConnectionStrings["EBSDEBookConn"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
           showgrid();
        }
    }
    protected void GridView1_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        DataRowView drv = e.Row.DataItem as DataRowView;
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            if ((e.Row.RowState & DataControlRowState.Edit) > 0)
            {
                DropDownList dp = (DropDownList)e.Row.FindControl("DropDownList1");
                DataTable dt = load_department();
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    ListItem lt = new ListItem();
                    lt.Text = dt.Rows[i][0].ToString();
                    dp.Items.Add(lt);
                }

                dp.SelectedValue = drv[3].ToString();
                RadioButtonList rbtnl = (RadioButtonList)e.Row.FindControl("RadioButtonList1");

                //rbtnl.SelectedValue = drv[5].ToString();

                //CheckBoxList chkb = (CheckBoxList)e.Row.FindControl("CheckBoxList2");
                //chkb.SelectedValue = drv[6].ToString();

               

                CheckBox chkb = (CheckBox)e.Row.FindControl("chkBS");
                chkb.Checked = Convert.ToBoolean(drv["IsBSAccess"].ToString());

                CheckBox chkb_MO = (CheckBox)e.Row.FindControl("chkMO");
                chkb_MO.Checked = Convert.ToBoolean(drv["IsMOAccess"].ToString());


                CheckBox chkb_DC = (CheckBox)e.Row.FindControl("chkDC");
                chkb_DC.Checked = Convert.ToBoolean(drv["IsDCAccess"].ToString());
            }
        }
    }
    public DataTable load_department()
    {
       DataTable dt = new DataTable();
       SqlConnection sqlcon = new SqlConnection(connValue);
       sqlcon.Open();
      // string sql = "SELECT AccessID, ContactID, ModuleID, IsCCAccess, IsPaymentAccess, IsDCAccess, IsSurveyAccess, IsBSAccess, IsMOAccess FROM  ModuleAccess";

       string sql = "SELECT profileName, profileName FROM UserSecurityProfile where userProfileID In(17,18) ";

       SqlCommand cmd = new SqlCommand(sql);
       cmd.CommandType = CommandType.Text;
       cmd.Connection = sqlcon;
       SqlDataAdapter sd = new SqlDataAdapter(cmd);
       sd.Fill(dt);
       return dt;
    }
    protected void GridView1_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
           Label lb = (Label)GridView1.Rows[e.RowIndex].FindControl("Label6");

           Label lbUserID = (Label)GridView1.Rows[e.RowIndex].FindControl("lblContactID");
        
           DropDownList ddl = 
	        (DropDownList)GridView1.Rows[e.RowIndex].FindControl("DropDownList1");
           //RadioButtonList rbl = 
           // (RadioButtonList)GridView1.Rows[e.RowIndex].FindControl("RadioButtonList1");

          // CheckBoxList chb =   (CheckBoxList)GridView1.Rows[e.RowIndex].FindControl("CheckBoxList2");

           CheckBox chbBS = (CheckBox)GridView1.Rows[e.RowIndex].FindControl("ChkBS");

           CheckBox chbMO = (CheckBox)GridView1.Rows[e.RowIndex].FindControl("ChkMO");

           CheckBox chbDC = (CheckBox)GridView1.Rows[e.RowIndex].FindControl("ChkDC");

         //  CheckBox chb = (CheckBox)GridView1.Rows[e.RowIndex].FindControl("CheckBoxList2");

           TextBox tx1 = (TextBox)GridView1.Rows[e.RowIndex].FindControl("TextBox1");
           TextBox tx2 = (TextBox)GridView1.Rows[e.RowIndex].FindControl("TextBox2");
          // TextBox tx3 = (TextBox)GridView1.Rows[e.RowIndex].FindControl("TextBox3");

           SqlConnection sqlcon = new SqlConnection(connValue);
           sqlcon.Open();
          // string sql = "update ModuleAccess set emp_name='" tx1.Text + "',emp_address='" + tx2.Text + "',salary='" tx3.Text + "',department='" + ddl.SelectedValue.ToString() + "',maritalstatus='" + rbl.SelectedValue.ToString() + "',Active_status='" + chb.SelectedValue.ToString() + "' where emp_id='" + lb.Text + "'";

           int profileID = 17; int mod_ProfileID = 2;

          if (ddl.SelectedItem.Text.Equals("BS TeamLead"))
          {
              profileID = 18;
              mod_ProfileID = 1;
          }

           int iChk_BS = 0;
           if (chbBS.Checked.ToString().Equals("True"))
           {
               iChk_BS = 1;
           }
           int iChk_MO = 0;
           if (chbMO.Checked.ToString().Equals("True"))
           {
               iChk_MO = 1;
           }
           int iChk_DC = 0;
           if (chbDC.Checked.ToString().Equals("True"))
           {
               iChk_DC = 1;
           }           


         // Member -17 lead -18          

           if (ddl.SelectedItem.Text.Equals("BS TeamLead"))
           {
               profileID = 18;

               string sqlUpdate = "Update ModuleAccess set ProfileID  = 2 ,ProfileName ='BS TeamMember'";  //where ContactID != '" + Convert.ToInt32(lbUserID.Text) + "'
               SqlConnection cn = new SqlConnection(connValue);
               cn.Open();
               SqlCommand sqlCmd = new SqlCommand(sqlUpdate);
               sqlCmd.CommandType = CommandType.Text;
               sqlCmd.Connection = cn;
               sqlCmd.ExecuteNonQuery();
               cn.Close();
           }


           string sql = "update ModuleAccess set IsBSAccess = " + iChk_BS + " ,IsMOAccess = " + iChk_MO + ",IsDCAccess = " + iChk_DC + ", ProfileName = '" + ddl.SelectedItem.Text + "',ProfileID = " + mod_ProfileID + "   where AccessID='" + lb.Text + "'";

           SqlConnection sqlcn2 = new SqlConnection(connValue);
           sqlcn2.Open();
           SqlCommand cmd = new SqlCommand(sql);

           cmd.CommandType = CommandType.Text;
           cmd.Connection = sqlcn2;
           cmd.ExecuteNonQuery();
           sqlcn2.Close();

        
           string sqlQuery = "update Contact set userProfileID = " + profileID + " where ContactID = " + Convert.ToInt32(lbUserID.Text) + "";
           SqlConnection sqlcn = new SqlConnection(connValue);
           sqlcn.Open();
           SqlCommand sqlCmdNew = new SqlCommand(sqlQuery);
           sqlCmdNew.CommandType = CommandType.Text;
           sqlCmdNew.Connection = sqlcn;
           sqlCmdNew.ExecuteNonQuery();
           sqlcn.Close();


           GridView1.EditIndex = -1;
           showgrid();
    }

   protected void GridView1_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
   {
       GridView1.EditIndex = -1;
       showgrid();  
   } 

   protected void GridView1_RowEditing(object sender, GridViewEditEventArgs e)
   {   
       GridView1.EditIndex = e.NewEditIndex;
       showgrid();
   } 

   public void showgrid()
   {
       DataTable dt = new DataTable();
       SqlConnection sqlcon = new SqlConnection(connValue);
       sqlcon.Open();
       SqlDataAdapter sda = new SqlDataAdapter();

       string strQuery = "SELECT        ModuleAccess.AccessID, ModuleAccess.ContactID, ModuleAccess.ModuleID, ModuleAccess.IsCCAccess, ModuleAccess.IsPaymentAccess, " +
                        " ModuleAccess.IsDCAccess, ModuleAccess.IsSurveyAccess, ModuleAccess.IsBSAccess, ModuleAccess.IsMOAccess, ModuleAccess.ProfileName, " +
                        " Contact.firstName + ' ' + Contact.lastName AS UserName FROM  ModuleAccess INNER JOIN  Contact ON ModuleAccess.ContactID = Contact.contactID";


       //string strQuery = "SELECT ModuleAccess.AccessID, ModuleAccess.ContactID, ModuleAccess.ModuleID, ModuleAccess.IsCCAccess, ModuleAccess.IsPaymentAccess, " + 
       //                  " ModuleAccess.IsDCAccess, ModuleAccess.IsSurveyAccess, ModuleAccess.IsBSAccess, ModuleAccess.IsMOAccess, ModuleAccess.ProfileName, Contact.firstName FROM ModuleAccess INNER JOIN " + 
       //                   " Contact ON ModuleAccess.ContactID = Contact.contactID";


       SqlCommand cmd = new SqlCommand(strQuery);
       cmd.CommandType = CommandType.Text;
       cmd.Connection = sqlcon;
       sda.SelectCommand = cmd;
       sda.Fill(dt);
       GridView1.DataSource = dt;
       GridView1.DataBind();
   }
}