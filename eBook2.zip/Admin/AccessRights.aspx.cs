﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

public partial class Admin_AccessRights : System.Web.UI.Page
{
    string connValue = System.Configuration.ConfigurationManager.ConnectionStrings["EBSDEBookConn"].ConnectionString;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            lvEmployee.DataSource = GetEmployee("Select * from UserAccessRights");
            lvEmployee.DataBind();
        }   
    }
    public DataTable GetEmployee(string query)
    {
        SqlConnection con = new SqlConnection(connValue);
        SqlDataAdapter ada = new SqlDataAdapter(query, con);
        DataTable dtEmp = new DataTable();
        ada.Fill(dtEmp);
        return dtEmp;
    }
    private void BindListView()
    {
        // string constr = ConfigurationManager.ConnectionStrings["constr"].ConnectionString;
        using (SqlConnection con = new SqlConnection(connValue))
        {
            using (SqlCommand cmd = new SqlCommand())
            {
                cmd.CommandText = "SELECT AccessID,AccessRights FROM UserAccessRights";
                cmd.Connection = con;
                using (SqlDataAdapter sda = new SqlDataAdapter(cmd))
                {
                    DataTable dt = new DataTable();
                    sda.Fill(dt);
                    lvEmployee.DataSource = dt;
                    lvEmployee.DataBind();
                }
            }
        }
    }

    protected void OnPagePropertiesChanging(object sender, PagePropertiesChangingEventArgs e)
    {
        (lvEmployee.FindControl("DataPager1") as DataPager).SetPageProperties(e.StartRowIndex, e.MaximumRows, false);
        this.BindListView();
    }
    protected void lvEmployee_ItemCanceling(object sender, ListViewCancelEventArgs e)
    {
        lvEmployee.EditIndex = -1;
    }
    protected void lvEmployee_ItemDeleting(object sender, ListViewDeleteEventArgs e)
    {
        string empid = "";
        Label lbl = (lvEmployee.Items[e.ItemIndex].FindControl("EmpIDLabel")) as Label;
        if (lbl != null)
            empid = lbl.Text;
        //string DeleteQuery = "Delete from UserAccessRights WHERE [AccessID] = '" + empid + "'";
        //SqlConnection con = new SqlConnection(connValue);
        //con.Open();
        //SqlCommand com = new SqlCommand(DeleteQuery, con);
        //com.ExecuteNonQuery();
        //con.Close();
        lvEmployee.DataSource = GetEmployee("Select * from UserAccessRights");
        lvEmployee.DataBind();
        lvEmployee.EditIndex = -1;
    }
    protected void lvEmployee_ItemEditing(object sender, ListViewEditEventArgs e)
    {
        lvEmployee.EditIndex = e.NewEditIndex;
    }
    protected void lvEmployee_ItemInserting(object sender, ListViewInsertEventArgs e)
    {
        string name = "";
        TextBox txt = (e.Item.FindControl("EmpNameTextBox")) as TextBox;
        if (txt != null)
            name = txt.Text;

        string INSERTQuery = "INSERT INTO [UserAccessRights] (AccessRights) VALUES ('" + name + "')";
        SqlConnection con = new SqlConnection(connValue);
        con.Open();
        SqlCommand com = new SqlCommand(INSERTQuery, con);
        com.ExecuteNonQuery();
        con.Close();
        lvEmployee.DataSource = GetEmployee("Select * from UserAccessRights");
        lvEmployee.DataBind();
        lvEmployee.EditIndex = -1;
    }
    protected void lvEmployee_ItemUpdating(object sender, ListViewUpdateEventArgs e)
    {
        string empid = "", name = "";
        Label lbl = (lvEmployee.Items[e.ItemIndex].FindControl("EmpIDLabel1")) as Label;
        if (lbl != null)
            empid = lbl.Text;
        TextBox txt = (lvEmployee.Items[e.ItemIndex].FindControl("EmpNameTextBox")) as TextBox;

        string UpdateQuery = "UPDATE [UserAccessRights] SET [AccessRights] = '" + txt.Text + "' WHERE [AccessID] = '" + empid + "'";
        SqlConnection con = new SqlConnection(connValue);
        con.Open();
        SqlCommand com = new SqlCommand(UpdateQuery, con);
        com.ExecuteNonQuery();
        con.Close();
        lvEmployee.DataSource = GetEmployee("Select * from UserAccessRights");
        lvEmployee.DataBind();
        lvEmployee.EditIndex = -1;
    }
    protected void DataPager1_PreRender(object sender, EventArgs e)
    {
        lvEmployee.DataSource = GetEmployee("Select * from UserAccessRights");
        lvEmployee.DataBind();
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        Response.Redirect("UserSecurityProfiles.aspx");
    }
}