﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
public partial class Admin_UserDetailsWindow : System.Web.UI.Page
{
    string connValue = System.Configuration.ConfigurationManager.ConnectionStrings["EBSDEBookConn"].ConnectionString;
    int upd_UserID = 0;
    protected void Page_Load(object sender, EventArgs e)
    {
        upd_UserID = Convert.ToInt32(Request.QueryString["ContactID"]);

        if (!IsPostBack)
        {
            PopulateDropDownBox(ddlSection, "SELECT sectionID, sectionName FROM Section; ", "sectionID", "sectionName");
            PopulateDropDownBox(ddlTeam, "SELECT teamLeaderID, teamLeaderName FROM  EBSDTeamLeaders", "teamLeaderID", "teamLeaderName");

            PopulateDropDownBox(DropDownList1, "SELECT userProfileID, profileName FROM  UserSecurityProfile", "userProfileID", "profileName");

            ViewUsersData(upd_UserID);

            if (upd_UserID != 0)
            {
               // ViewUsersData(upd_UserID);
                Session["upd_UserID"] = upd_UserID.ToString();
            }

            if ((!CheckDistributeData(upd_UserID)) & (!CheckDistributeData(upd_UserID)))
            {
                btnDelete.Enabled = true;
            }
        }
    }    
    protected void btnSave_Click(object sender, EventArgs e)
    {
        if (Convert.ToInt32(Session["upd_UserID"]) != 0)
            UpdateContactData(upd_UserID);   // UpdateUserProfile
        
        this.ClientScript.RegisterClientScriptBlock(this.GetType(), "Close", "window.close()", true);

        ScriptManager.RegisterStartupScript(this, typeof(string), "script",
                 "<script type=text/javascript> parent.location.href = parent.location.href;</script>", false);
    }

    //private void UpdateContactDetails(int upd_UserID)
    //{
    //    // password = @pswrd,
    //    string updateQuery = "UPDATE Contact SET sectionID = @section,teamleaderID =@teamleaderID,userProfileID=@userProfileID WHERE CONTACTID = @CntID";

    //    SqlConnection sqlCon = new SqlConnection(connValue);
    //    SqlCommand cmd = new SqlCommand();
    //    cmd.CommandText = updateQuery;
    //    cmd.Connection = sqlCon;

    //    try
    //    {
    //        cmd.Parameters.AddWithValue("@CntID", Convert.ToInt32(Session["upd_UserID"]));

    //        if (ddlSection.SelectedIndex != 0)
    //            cmd.Parameters.AddWithValue("@section", ddlSection.SelectedValue);
    //        else
    //            cmd.Parameters.AddWithValue("@section", System.DBNull.Value);

    //        if (ddlTeam.SelectedIndex != 0)
    //            cmd.Parameters.AddWithValue("@teamleaderID", ddlTeam.SelectedValue);
    //        else
    //            cmd.Parameters.AddWithValue("@teamleaderID", System.DBNull.Value);

    //        if (DropDownList1.SelectedIndex != 0)
    //            cmd.Parameters.AddWithValue("@userProfileID", DropDownList1.SelectedValue);
    //        else
    //            cmd.Parameters.AddWithValue("@userProfileID", System.DBNull.Value);

    //        sqlCon.Open();
    //        cmd.ExecuteNonQuery();
    //        sqlCon.Close();
    //    }
    //    catch (Exception ex)
    //    {
    //        throw ex;
    //    }
    //}
   
    private void ViewUsersData(int userID)
    {       
        try
        {
            SqlConnection sqlConn = new SqlConnection(connValue);
            sqlConn.Open();

            string viewSql = "SELECT  Contact.UserName, UserSecurityProfile.profilename, Contact.EmailAddress, Contact.BusinessPhone, " +
                          " (Contact.firstName + ' ' + Contact.lastName) AS ActualName, Contact.LogOn,Contact.sectionID,Contact.teamLeaderID,Contact.userProfileID,Contact.password,Contact.isActive  " +
                       " FROM Contact INNER JOIN UserSecurityProfile ON Contact.userProfileID = UserSecurityProfile.userProfileID  WHERE CONTACTID = " + userID + "";

            SqlCommand sqlCom = new SqlCommand(viewSql, sqlConn);      
            SqlDataReader sqlReader = sqlCom.ExecuteReader();

            while (sqlReader.Read())
            {
                txtUserName.Text = sqlReader["userName"].ToString();
                txtPswrd.Text = sqlReader["password"].ToString();
                hiddpassword.Value = sqlReader["password"].ToString();
                if (txtPswrd.TextMode == TextBoxMode.Password)
                {
                    txtPswrd.Attributes.Add("value", txtPswrd.Text);
                }
                txtEmail.Text = sqlReader["EmailAddress"].ToString();
                txtPhone.Text = sqlReader["BusinessPhone"].ToString();
                txtActualName.Text = sqlReader["ActualName"].ToString();

                if (sqlReader["sectionID"].ToString()!="")
                      ddlSection.SelectedValue = sqlReader["sectionID"].ToString();
                else
                    ddlTeam.SelectedIndex = 0;

                if (sqlReader["teamLeaderID"].ToString() != "")
                    ddlTeam.SelectedValue = sqlReader["teamLeaderID"].ToString();
                else
                    ddlTeam.SelectedIndex = 0;

                DropDownList1.Text = sqlReader["userProfileID"].ToString();
                if (sqlReader["isActive"].ToString()!="")
                 CheckBox1.Checked = Convert.ToBoolean(sqlReader["isActive"].ToString());
            }
            sqlReader.Close();
            sqlConn.Close();
        }
        catch (Exception ex)
        {
            throw ex;
        }
    } 
    private void UpdateContactData(int upd_UserID)
    {
        UtilityClass uCls = new UtilityClass(this.Page);

        //
        string updateQuery;

        //if (txtPswrd.Text == hiddpassword.Value)
        //{
        //    updateQuery = "UPDATE Contact SET UserName = @userName, emailAddress = @emailID,BusinessPhone = @busPhone, " +
        //    " sectionID = @section,teamLeaderID = @team,userProfileID = @secProfID,isActive=@chkActive,displayName =@ActualName,updateUser =@updUser,updateDate= @updDate " +
        //    " WHERE CONTACTID = @userID";
        //}
        //else
        //{
        //    updateQuery = "UPDATE Contact SET UserName = @userName, emailAddress = @emailID,BusinessPhone = @busPhone, " +
        //   " sectionID = @section,teamLeaderID = @team,userProfileID = @secProfID, password=HashBytes('SHA1', @password),isActive=@chkActive,displayName =@ActualName,updateUser =@updUser,updateDate= @updDate " +
        //   " WHERE CONTACTID = @userID";
        //}

       // UpdateUserProfile

       

        try
        {
            using (SqlConnection sqlCon = new SqlConnection(connValue))
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Parameters.AddWithValue("@userID", Convert.ToInt32(Session["upd_UserID"]));   //upd_UserID
                    cmd.Parameters.AddWithValue("@userName", txtUserName.Text);

                    cmd.Parameters.AddWithValue("@password", txtPswrd.Text);

                    cmd.Parameters.AddWithValue("@emailID", txtEmail.Text);
                    cmd.Parameters.AddWithValue("@busPhone", txtPhone.Text);
                    cmd.Parameters.AddWithValue("@ActualName", txtActualName.Text);

                    if (ddlSection.SelectedIndex != 0)
                        cmd.Parameters.AddWithValue("@section", ddlSection.SelectedValue);
                    else
                        cmd.Parameters.AddWithValue("@section", System.DBNull.Value);

                    if (ddlTeam.SelectedIndex != 0)
                        cmd.Parameters.AddWithValue("@team", ddlTeam.SelectedValue);
                    else
                        cmd.Parameters.AddWithValue("@team", System.DBNull.Value);

                    if (DropDownList1.SelectedIndex != 0)
                        cmd.Parameters.AddWithValue("@secProfID", DropDownList1.SelectedValue);
                    else
                        cmd.Parameters.AddWithValue("@secProfID", System.DBNull.Value);

                    if (CheckBox1.Checked == true)
                        cmd.Parameters.AddWithValue("@chkActive", 1);
                    else
                        cmd.Parameters.AddWithValue("@chkActive", 0);

                    cmd.Parameters.AddWithValue("@updUser", Session["UserName"]);
                    cmd.Parameters.AddWithValue("@updDate", System.DateTime.Now.ToString("dd/MMM/yyyy"));

                   // cmd.Parameters.AddWithValue("@isAuthRepres", CheckBox2.Checked);

                    sqlCon.Open();
                    cmd.Connection = sqlCon;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "UpdateUserProfile";
                    cmd.ExecuteNonQuery();
                }
            }     
           
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    private void InsertUserDetails()
    {

    }
    private void PopulateDropDownBox(DropDownList ddlBox, string sqlQuery, string valueMember, string displayName)
    {
        DataTable table = new DataTable();
        try
        {
            using (SqlConnection sqlConn = new SqlConnection(connValue))
            {
                using (SqlDataAdapter da = new SqlDataAdapter(sqlQuery, sqlConn))
                {
                    sqlConn.Open();
                    da.Fill(table);
                }
            }
            //cmbBox.Items.Add("Select");
            ddlBox.DataSource = table;

            ddlBox.DataTextField = displayName;
            ddlBox.DataValueField = valueMember;

            ddlBox.DataBind();
            ddlBox.Items.Insert(0, new ListItem("--Select--"));
            //ddlBox.SelectedIndex = -1;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    protected void btnDelete_Click(object sender, EventArgs e)
    {
        if (!CheckDistributeData(upd_UserID))
        {
            if ((!CheckDistributeData(upd_UserID)))
            {
               
                DeleteContact(upd_UserID);
            }
        }
        else
            ClientScript.RegisterClientScriptBlock(this.GetType(), "Popup", "<script>alert('You have no privilege to Delete this User,Contact administrator.')</script>", false);

        ScriptManager.RegisterStartupScript(this, typeof(string), "script",
                "<script type=text/javascript> parent.location.href = parent.location.href;</script>", false);
       
    }   
   
    private void DeleteContact(int upd_UserID)
    {
        // password = @pswrd,
        string updateQuery = "Delete From Contact where CONTACTID = @CntID";

        SqlConnection sqlCon = new SqlConnection(connValue);
        SqlCommand cmd = new SqlCommand();
        cmd.CommandText = updateQuery;
        cmd.Connection = sqlCon;

        try
        {
            cmd.Parameters.AddWithValue("@CntID", Convert.ToInt32(Session["upd_UserID"]));

            sqlCon.Open();
            cmd.ExecuteNonQuery();
            sqlCon.Close();
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    private Boolean CheckInchargeData(int _ContactID)
    {
        try
        {
            SqlConnection sqlConn = new SqlConnection(connValue);
            sqlConn.Open();

            string viewSql = "SELECT  * From JobOwner WHERE CONTACTID = " + _ContactID + "";

            SqlCommand sqlCom = new SqlCommand(viewSql, sqlConn);
            SqlDataReader sqlReader = sqlCom.ExecuteReader();

            if (sqlReader.HasRows)
            {
                return true;
            }  
          
            sqlReader.Close();
            sqlConn.Close();
        }
        catch (Exception ex)
        {
            throw ex;
        }

        return false;
    }
    private Boolean CheckDistributeData(int _ContactID)
    {
        try
        {
            SqlConnection sqlConn = new SqlConnection(connValue);
            sqlConn.Open();

            string viewSql = "SELECT  * From DocumentDistribution WHERE CONTACTID = " + _ContactID + "";

            SqlCommand sqlCom = new SqlCommand(viewSql, sqlConn);
            SqlDataReader sqlReader = sqlCom.ExecuteReader();

            if (sqlReader.HasRows)
            {
                return true;
            }

            sqlReader.Close();
            sqlConn.Close();
        }
        catch (Exception ex)
        {
            throw ex;
        }

        return false;
    }
   
}