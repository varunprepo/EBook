﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using Datalayer;
public partial class Admin_ViewUserInfo : System.Web.UI.Page
{
    string connValue = System.Configuration.ConfigurationManager.ConnectionStrings["EBSDEBookConn"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            PopulateDropDownBox(ddlSection, "SELECT SectionID, SectionName FROM  Section Where departmentID = 22 ORDER BY SectionName  ", "SectionID", "SectionName");
            ViewUsersDetails();

            if (Session["UserID"].ToString() == "1" || Session["UserID"].ToString() == "95") // Admin 
            {
                btnLoginUsers.Enabled = true;
                getUserCnt();

                getUserLogCnt();
            }
        }
    }
    private void ViewUsersDetails()
    {
        //string viewSql = "SELECT Users.UserName, UserSecurityProfile.profilename, Users.EmailAddress, Users.BusinessPhone, " +
        //                  " Users.DisplayName AS ActualName, Users.isLogIn,Users.contactID  " +
        //               " FROM Users INNER JOIN UserSecurityProfile ON Users.userProfileID = UserSecurityProfile.userProfileID ";

        string viewSql = "SELECT Contact.UserName, UserSecurityProfile.profilename, Contact.EmailAddress, Contact.officePhone, " +
                          " (Contact.firstName + ' ' + Contact.lastName)  AS ActualName, Contact.UserShortName,Contact.isLogIn,Contact.contactID  " +
                       " FROM Contact INNER JOIN UserSecurityProfile ON Contact.userProfileID = UserSecurityProfile.userProfileID ORDER BY Contact.userName DESC, ActualName ";

        SqlConnection objCon = new SqlConnection(connValue);
        SqlCommand objCmd = new SqlCommand(viewSql, objCon);
        SqlDataAdapter objDA = new SqlDataAdapter(objCmd);

        objDA.SelectCommand.CommandText = objCmd.CommandText.ToString();
        DataTable dt = new DataTable();
        objDA.Fill(dt);

        Session["getDCJobs"] = dt;

        gridDocStatus.DataSource = dt.DefaultView;
        gridDocStatus.DataBind();
    }
    private void PopulateDropDownBox(DropDownList ddlBox, string sqlQuery, string valueMember, string displayName)
    {
        ddlBox.DataBound += new EventHandler(this.ddlBox_DataBound);
        ddlBox.DataSource = new JobOrderData().FillDropdown(sqlQuery);
        ddlBox.DataTextField = displayName;
        ddlBox.DataValueField = valueMember;
        ddlBox.SelectedIndex = -1;
        ddlBox.DataBind();
    }
    protected void ddlBox_DataBound(object sender, EventArgs e)
    {
        DropDownList ddl = (DropDownList)sender;
        ListItem emptyItem = new ListItem("", "");
        ddl.Items.Insert(0, emptyItem);
    }
    protected void gvorders_RowCommand(object sender, GridViewCommandEventArgs e)
    {

    }
    protected void gvorders_RowDataBound(object sender, GridViewRowEventArgs e)
    {

    }
    protected void gridDocStatus_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void btnAdd_Click(object sender, EventArgs e)
    {
        Response.Write("<script language='javascript'> window.open('UserDetailsWindow.aspx','','width=830,Height=550,fullscreen=1,location=0,scrollbars=0,menubar=1,toolbar=1, align=center,top=100,left=500'); </script>");
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
             
    }
    private void UpdateLoginUsers()
    {
        string updQuery = "Update Contact Set isLogIn = 0";

        using (SqlConnection cn = new SqlConnection(connValue))
        {
            cn.Open();
            using (SqlCommand cmd = new SqlCommand())
            {
                cmd.Connection = cn;
                cmd.CommandText = updQuery;
                cmd.CommandType = CommandType.Text;
                cmd.ExecuteNonQuery();
            }
        }        
    }
    protected void txtUserSearch_TextChanged(object sender, EventArgs e)
    {
        SearchUser_Details();
    }
    private void SearchUser_Details()
    {
        string sqlQuery = "SELECT Contact.UserName, UserSecurityProfile.profilename, Contact.EmailAddress, Contact.officePhone, " +
                          " (Contact.firstName + ' ' + Contact.lastName)  AS ActualName, Contact.UserShortName,Contact.isLogIn,Contact.contactID  " +
                       " FROM Contact INNER JOIN UserSecurityProfile ON Contact.userProfileID = UserSecurityProfile.userProfileID Where (Contact.firstName + ' ' + Contact.lastName Like  '" + txtUserSearch.Text + "%" + "')  ORDER BY Contact.userName DESC, ActualName ";
                
        SqlConnection objCon = new SqlConnection(connValue);
        SqlCommand objCmd = new SqlCommand(sqlQuery, objCon);
        SqlDataAdapter objDA = new SqlDataAdapter(objCmd);

        objDA.SelectCommand.CommandText = objCmd.CommandText.ToString();
        DataTable dt = new DataTable();
        objDA.Fill(dt);

        gridDocStatus.DataSource = dt.DefaultView;
        gridDocStatus.DataBind();

        // lblCnt.Text = " Jobs Count :  " + gridJobs.Rows.Count.ToString();
    }
    protected void ddlSection_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlSection.SelectedIndex != 0)
        {
            string sqlQuery = "SELECT Contact.UserName, UserSecurityProfile.profilename, Contact.EmailAddress, Contact.officePhone, " +
                             " (Contact.firstName + ' ' + Contact.lastName)  AS ActualName, Contact.UserShortName,Contact.isLogIn,Contact.contactID  " +
                          " FROM Contact INNER JOIN UserSecurityProfile ON Contact.userProfileID = UserSecurityProfile.userProfileID Where contact.sectionID =" + ddlSection.SelectedValue + "  ORDER BY Contact.userName DESC, ActualName ";

            SqlConnection objCon = new SqlConnection(connValue);
            SqlCommand objCmd = new SqlCommand(sqlQuery, objCon);
            SqlDataAdapter objDA = new SqlDataAdapter(objCmd);

            objDA.SelectCommand.CommandText = objCmd.CommandText.ToString();
            DataTable dt = new DataTable();
            objDA.Fill(dt);

            gridDocStatus.DataSource = dt.DefaultView;
            gridDocStatus.DataBind();
        }
    }
    protected void gridDocStatus_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        gridDocStatus.PageIndex = e.NewPageIndex;
        DataTable dt = new DataTable();
        dt = Session["getDCJobs"] as DataTable;

        BindData(dt);
    }
    private void BindData(DataTable dt)
    {     
        gridDocStatus.DataSource = dt;
        gridDocStatus.DataBind();
    }
    protected void gridDocStatus_Sorting(object sender, GridViewSortEventArgs e)
    {
        DataTable dataTable = gridDocStatus.DataSource as DataTable;
        if (dataTable != null)
        {
            DataView dataView = new DataView(dataTable);
            dataView.Sort = e.SortExpression + " " + ConvertSortDirectionToSql(e.SortDirection);

            gridDocStatus.DataSource = dataView;
            gridDocStatus.DataBind();
        }
    }
   
    private string ConvertSortDirectionToSql(SortDirection sortDirection)
    {
        string newSortDirection = String.Empty;

        switch (sortDirection)
        {
            case SortDirection.Ascending:
                newSortDirection = "ASC";
                break;

            case SortDirection.Descending:
                newSortDirection = "DESC";
                break;
        }
        return newSortDirection;
    }

    protected void Button1_Click1(object sender, EventArgs e)
    {
        if (Session["UserID"].ToString() == "1" || Session["UserID"].ToString() == "95") // Admin n sree
        {
            UpdateLoginUsers();
        }  
    }


    private void getUserCnt()
    {       
        SqlConnection sqlConn = new SqlConnection(connValue);
        string sqlQuery = "SELECT count(*) as Cnt From Contact Where UserName is not null ";

        try
        {
            sqlConn.Open();
            SqlCommand sqlCom = new SqlCommand(sqlQuery, sqlConn);
            SqlDataReader sqlReader = sqlCom.ExecuteReader();
            while (sqlReader.Read())
            {
                lblCnt.Text = sqlReader["Cnt"].ToString();
            }
            sqlReader.Close();
        }
        catch (Exception ex)
        {
            Response.Write("Error getting while reading data !" + ex.Message);
        }
        finally
        {
            sqlConn.Close();
        }        
    }
    private void getUserLogCnt()
    {
        SqlConnection sqlConn = new SqlConnection(connValue);
        string sqlQuery = "SELECT count(*) as Cnt From Contact Where isLogIn = 1";

        try
        {
            sqlConn.Open();
            SqlCommand sqlCom = new SqlCommand(sqlQuery, sqlConn);
            SqlDataReader sqlReader = sqlCom.ExecuteReader();
            while (sqlReader.Read())
            {
                lblLogCnt.Text = sqlReader["Cnt"].ToString();
            }
            sqlReader.Close();
        }
        catch (Exception ex)
        {
            Response.Write("Error getting while reading data !" + ex.Message);
        }
        finally
        {
            sqlConn.Close();
        }
    }
    protected void ddlLogIn_SelectedIndexChanged(object sender, EventArgs e)
    {
       
    }
    protected void btnLogIn_Click(object sender, EventArgs e)
    {
        string sqlQuery = "SELECT Contact.UserName, UserSecurityProfile.profilename, Contact.EmailAddress, Contact.officePhone, " +
                            " (Contact.firstName + ' ' + Contact.lastName)  AS ActualName, Contact.UserShortName,Contact.isLogIn,Contact.contactID  " +
                         " FROM Contact INNER JOIN UserSecurityProfile ON Contact.userProfileID = UserSecurityProfile.userProfileID Where Contact.isLogin =1 ORDER BY Contact.isLogIn";

        SqlConnection objCon = new SqlConnection(connValue);
        SqlCommand objCmd = new SqlCommand(sqlQuery, objCon);
        SqlDataAdapter objDA = new SqlDataAdapter(objCmd);

        objDA.SelectCommand.CommandText = objCmd.CommandText.ToString();
        DataTable dt = new DataTable();
        objDA.Fill(dt);

        gridDocStatus.DataSource = dt.DefaultView;
        gridDocStatus.DataBind();
    }

    protected void ddlProfileType_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlProfileType.SelectedIndex != 0)
        {
            string sqlQuery = "SELECT Contact.UserName, UserSecurityProfile.profilename, Contact.EmailAddress, Contact.officePhone, " +
                             " (Contact.firstName + ' ' + Contact.lastName)  AS ActualName, Contact.UserShortName,Contact.isLogIn,Contact.contactID  " +
                          " FROM Contact INNER JOIN UserSecurityProfile ON Contact.userProfileID = UserSecurityProfile.userProfileID Where contact.userProfileID =" + ddlProfileType.SelectedValue + "  ORDER BY Contact.userName DESC, ActualName ";

            SqlConnection objCon = new SqlConnection(connValue);
            SqlCommand objCmd = new SqlCommand(sqlQuery, objCon);
            SqlDataAdapter objDA = new SqlDataAdapter(objCmd);

            objDA.SelectCommand.CommandText = objCmd.CommandText.ToString();
            DataTable dt = new DataTable();
            objDA.Fill(dt);

            gridDocStatus.DataSource = dt.DefaultView;
            gridDocStatus.DataBind();
        }
    }
}