﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using Datalayer;
using System.Drawing;

public partial class Admin_UserSecurityProfiles : System.Web.UI.Page
{
    string connValue = System.Configuration.ConfigurationManager.ConnectionStrings["EBSDEBookConn"].ConnectionString;
    protected void Page_Init(object sender, EventArgs e)
    {
        fillDocumentData();
        if (!IsPostBack)
        {
            ListView1.DataSource = GetEmployee("Select * from UserSecurityProfile");    //UserSecurityProfile           user_profile_id    profile_name
            ListView1.DataBind();
            PopulateDropDownBox(ddlProfileName, "SELECT userProfileID, profileName FROM  UserSecurityProfile Where userProfileID <>1 ORDER BY userProfileID ", "userProfileID", "profileName");
        }
    }
    private void PopulateDropDownBox(DropDownList ddlBox, string sqlQuery, string valueMember, string displayName)
    {
        ddlBox.DataSource = new JobOrderData().FillDropdown(sqlQuery);
        ddlBox.DataTextField = displayName;
        ddlBox.DataValueField = valueMember;
        ddlBox.SelectedIndex = -1;
        ddlBox.DataBind();
        ddlBox.Items.Insert(0, new ListItem("--Select--"));
    }    
    public DataTable GetEmployee(string query)
    {
        SqlConnection con = new SqlConnection(connValue);
        SqlDataAdapter ada = new SqlDataAdapter(query, con);
        DataTable dtEmp = new DataTable();
        ada.Fill(dtEmp);
        return dtEmp;
    }
    private void BindListView()
    {
        // string constr = ConfigurationManager.ConnectionStrings["constr"].ConnectionString;
        using (SqlConnection con = new SqlConnection(connValue))
        {
            using (SqlCommand cmd = new SqlCommand())
            {
                cmd.CommandText = "SELECT AccessID,AccessRights FROM UserAccessRights";
                cmd.Connection = con;
                using (SqlDataAdapter sda = new SqlDataAdapter(cmd))
                {
                    DataTable dt = new DataTable();
                    sda.Fill(dt);
                    //lvEmployee.DataSource = dt;
                    //lvEmployee.DataBind();
                }
            }
        }
    }
    protected void OnPagePropertiesChanging(object sender, PagePropertiesChangingEventArgs e)
    {
        //(lvEmployee.FindControl("DataPager1") as DataPager).SetPageProperties(e.StartRowIndex, e.MaximumRows, false);
        //this.BindListView();
    }   
    protected void DataPager1_PreRender(object sender, EventArgs e)
    {
        ListView1.DataSource = GetEmployee("Select * from UserSecurityProfile");
        ListView1.DataBind();
    }
    protected void btnBack_Click(object sender, EventArgs e)
    {
        Response.Redirect("AccessRights.aspx");
    }
    private void fillDocumentData()
    {
        // if (!Page.IsPostBack)
        {
            string sqlQuery = " SELECT UserAccessRights.accessID, UserAccessRights.accessRights, UserPrivilege.hasPrivilege,UserPrivilege.userPrivilegeID FROM  UserAccessRights INNER JOIN UserPrivilege ON UserAccessRights.accessID = UserPrivilege.accessID " +
                " WHERE (UserPrivilege.UserProfileID = 1) order by UserAccessRights.accessID";

            SqlConnection objCon = new SqlConnection(connValue);
            SqlCommand objCmd = new SqlCommand(sqlQuery, objCon);
            SqlDataAdapter objDA = new SqlDataAdapter(objCmd);

            objDA.SelectCommand.CommandText = objCmd.CommandText.ToString();
            DataTable dt = new DataTable();
            objDA.Fill(dt);

            ViewState["CurrentTable"] = dt;
            BindGrid_TEMP();
        }
    }
    protected void BindGrid_TEMP()
    {
        gvJoborder.DataSource = ViewState["CurrentTable"] as DataTable;
        gvJoborder.DataBind();
    }
    protected void gvJoborder_RowDataBound(object sender, GridViewRowEventArgs e)
    {        
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            //TextBox lm = (TextBox)e.Row.FindControl("jobid");
            //TextBox afr = (TextBox)e.Row.FindControl("TextBox1");
          //  TextBox InchargeID = (TextBox)e.Row.FindControl("AccessID");

            Label privID = (Label)e.Row.FindControl("txtPrivID");
            CheckBox chkstate = (CheckBox)e.Row.FindControl("ad");
            chkstate.ToolTip = privID.Text;
            chkstate.CheckedChanged += new EventHandler(chkstate_CheckedChanged);
        }
    }
    protected void chkstate_CheckedChanged(object sender, EventArgs e)
    {
        if (ddlProfileName.SelectedIndex == 0)
            return;

        CheckBox chk = (CheckBox)sender;
        new JobOrderData().UpdateProfileStatus(Convert.ToInt32(chk.ToolTip), Convert.ToBoolean(chk.Checked), Convert.ToInt32(ddlProfileName.SelectedValue));
        //fillData();
    }   
    protected void ddlProfileName_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlProfileName.SelectedIndex != 0)
        {
            string sqlQuery = " SELECT UserAccessRights.accessID, UserAccessRights.accessRights, UserPrivilege.hasPrivilege,UserPrivilege.userPrivilegeID FROM  UserAccessRights INNER JOIN UserPrivilege ON UserAccessRights.accessID = UserPrivilege.accessID" +
                " Where UserPrivilege.UserProfileID = " + ddlProfileName.SelectedValue + " ";

            SqlConnection objCon = new SqlConnection(connValue);
            SqlCommand objCmd = new SqlCommand(sqlQuery, objCon);
            SqlDataAdapter objDA = new SqlDataAdapter(objCmd);

            objDA.SelectCommand.CommandText = objCmd.CommandText.ToString();
            DataTable dt = new DataTable();
            objDA.Fill(dt);

            ViewState["CurrentTable"] = dt;
            BindGrid_TEMP();
        }
    }
    protected void ListView1_ItemInserting(object sender, ListViewInsertEventArgs e)
    {
        string name = "";
        TextBox txt = (e.Item.FindControl("EmpNameTextBox")) as TextBox;
        if (txt != null)
            name = txt.Text;

        string INSERTQuery = "INSERT INTO [UserSecurityProfile] (profileName) VALUES ('" + name + "')";
        SqlConnection con = new SqlConnection(connValue);
        con.Open();
        SqlCommand com = new SqlCommand(INSERTQuery, con);
        com.ExecuteNonQuery();
        con.Close();
        ListView1.DataSource = GetEmployee("Select * from UserSecurityProfile");
        ListView1.DataBind();
        ListView1.EditIndex = -1;

        // We shoul add values here
        //InsertPreviligeData();
    }
    protected void ListView1_ItemUpdating(object sender, ListViewUpdateEventArgs e)
    {
        string empid = "", name = "";
        Label lbl = (ListView1.Items[e.ItemIndex].FindControl("EmpIDLabel1")) as Label;
        if (lbl != null)
            empid = lbl.Text;
        TextBox txt = (ListView1.Items[e.ItemIndex].FindControl("EmpNameTextBox")) as TextBox;

        string UpdateQuery = "UPDATE [UserSecurityProfile] SET [profileName] = '" + txt.Text + "' WHERE [userProfileID] = '" + empid + "'";
        SqlConnection con = new SqlConnection(connValue);
        con.Open();
        SqlCommand com = new SqlCommand(UpdateQuery, con);
        com.ExecuteNonQuery();
        con.Close();
        ListView1.DataSource = GetEmployee("Select * from UserSecurityProfile");
        ListView1.DataBind();
        ListView1.EditIndex = -1;

    }
    protected void ListView1_ItemEditing(object sender, ListViewEditEventArgs e)
    {
        ListView1.EditIndex = e.NewEditIndex;
    }
    protected void ListView1_ItemDeleting(object sender, ListViewDeleteEventArgs e)
    {
        int proID = 0;
        Label lbl = (ListView1.Items[e.ItemIndex].FindControl("EmpIDLabel")) as Label;
        if (lbl != null)
            proID = Convert.ToInt32(lbl.Text);

        Boolean chkUser = Convert.ToBoolean(getuserProfileID(proID));

        if (getuserProfileID(proID)== false)
        {
            string DeleteQuery = "Delete from UserSecurityProfile WHERE userProfileID = '" + proID + "'";
            SqlConnection con = new SqlConnection(connValue);
            con.Open();
            SqlCommand com = new SqlCommand(DeleteQuery, con);
            com.ExecuteNonQuery();
            con.Close();

            ListView1.DataSource = GetEmployee("Select * from UserSecurityProfile");
            ListView1.DataBind();
            ListView1.EditIndex = -1;
        }
        else
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "Popup", "<script>alert('The security profile was assigned to a user.It canot be deleted.')</script>", false);
            return;
        } 
    }
    protected void ListView1_ItemCanceling(object sender, ListViewCancelEventArgs e)
    {
        ListView1.EditIndex = -1;
    }
    public Boolean getuserProfileID(int profID)
    {
        Boolean chkTrue = false;
        try
        {
            SqlConnection sqlConn = new SqlConnection(connValue);
            sqlConn.Open();
            SqlCommand sqlCom = new SqlCommand("Select userProfileID from Contact where userProfileID = " + profID + " ", sqlConn);       
            SqlDataReader sqlReader = sqlCom.ExecuteReader();
            if (sqlReader.HasRows)
            {
                chkTrue = true;
            }
            sqlReader.Close();
            sqlConn.Close();
        }
        catch (System.Exception ex)
        {
            throw ex;
        }
        return chkTrue;
    }
}