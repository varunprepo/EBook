﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Data;
using System.Data.SqlClient;
using Datalayer;
using System.IO;
using System.Configuration;
using System.Globalization;
using System.Threading;
using System.Net.Mail;
using System.Security.Cryptography.X509Certificates;
using System.Net.Security;
using System.Net;

public partial class DCOnline_Default9 : System.Web.UI.Page
{
    string connValue = System.Configuration.ConfigurationManager.ConnectionStrings["EBSDEBookConn"].ConnectionString;
    string _jobNo = string.Empty;
    int _jobID = 0;
    IList<string> userRightsColl = new List<string>();
    string profile_Name = string.Empty;
    int _tabType = 0;

    protected void Page_Init(object sender, EventArgs e)
    {
        if (Session["UserName"] == null)
        {
            Response.Redirect("~/LoginPage.aspx", false);
            return;
        }

        if (_jobID == 0)
            _jobID = Convert.ToInt32(Request.QueryString["JobID"]);

        if (_jobID == 0)
            _jobID = Convert.ToInt32(Session["GIS_JobID"]);

        //Session["StaffJobID"] = Convert.ToInt32(Request.QueryString["JobID"]);

        _tabType = Convert.ToInt32(Request.QueryString["tabType"]);

        // _jobID = 17621;

        userRightsColl = (IList<string>)Session["UserRightsColl"];



        if (!IsPostBack)
        {
            PopulateDropDownBox(ddlJobCat, "SELECT  jobTypeID, jobTypeName, CategoryID, sectionID FROM   JobType WHERE (sectionID = 11) ", "jobTypeID", "jobTypeName"); // AND (jobTypeID <> CategoryID)

            //   PopulateDropDownBox(ddlJobType, "SELECT  jobTypeID, jobTypeName, CategoryID, sectionID FROM   JobType WHERE (sectionID = 11) AND (jobTypeID <> CategoryID) ", "jobTypeID", "jobTypeName"); // 

            // PopulateDropDownBox(drpSubTaskType, "SELECT  subTypeID, subTypeName, typeID FROM  SubTaskType Where typeID = 67 ", "subTypeID", "subTypeName");  // Where typeID = 67   no need            

            //PopulateDropDownBox(drpActionBy, "SELECT contactID, firstName FROM Contact where sectionID = 22", "contactID", "firstName");

            PopulateDropDownBox(ddlJobStatus, "SELECT JobStatusID, JobStatusName FROM JobStatus Where JobStatusID in(3,5,7) ORDER BY JobStatusName", "JobStatusID", "JobStatusName");   //4, Ongoing and Pending

            //ddlQS.DataSource = null;

            string getStaff = "SELECT  contactID, (firstName + ' ' + lastName) as UserName FROM  Contact WHERE (userShortName IS NOT NULL) AND (contactID <> 1) AND (isActive = 1) and sectionID = 11  ORDER BY UserName";

            PopulateDropDownBox(ddlQS, getStaff, "contactID", "UserName");

            PopulateDropDownBox(ddlStaff, getStaff, "contactID", "UserName");

            PopulateDropDownBox(ddlReqVia, "SELECT ReqID, ReqVia FROM RequestService", "ReqID", "ReqVia");

            PopulateDropDownBox(ddlDept, "SELECT departmentID, deptName FROM  Department where affairID is not null ORDER BY deptName ", "departmentID", "deptName");

            Fill_JobOrder_Information(_jobID);

            if (fileUpload1.PostedFile == null)
            {
                UploadFile(CreateFolder(false));
            }

            //ReadFiles();

            ReadFiles_GS();

            // After job cat fill 

            PopulateDropDownBox(ddlJobType, "SELECT  jobTypeID, jobTypeName, CategoryID, sectionID FROM JobType WHERE (sectionID = 11) AND (jobTypeID <> CategoryID) and CategoryID = " + Session["JobCatID"].ToString() + " ", "jobTypeID", "jobTypeName"); // AND (jobTypeID <> CategoryID)

            //PopulateDropDownBox(ddlTask, "SELECT jobPurposeID, jobPurposeName FROM JobPurpose where jobPurposeID in(1,8,9,10,14) OR sectionID = 11", "jobPurposeID", "jobPurposeName"); //  For Distribution -1  // For Review - 8// For Approval - 9// For Action -10 // 14 - For Coordination

            string sqlQuery = "select x.jobTypeID,a.jobtypeid,d.jobPurposeID,x.jobTypeName as jobCategory,a.jobTypeName,d.jobpurposename from JobType a inner join JobType x ON x.jobTypeID = a.CategoryID inner join JobTypePurpose b on a.jobTypeID = b.jobTypeID " +
         " inner join JobPurpose d on b.jobPurposeID = d.jobPurposeID where a.jobTypeID = " + Session["jobTypeID"].ToString() + " order by x.jobTypeID";

            PopulateDropDownBox(ddlPurpose, sqlQuery, "jobPurposeID", "jobPurposeName"); //  For Distribution -1  // For Review - 8// For Approval - 9// For Action -10 // 14 - For Coordination

            txtStaffRemarks.Enabled = false;

            trStaffRmrks.Visible = false;
        }

        //gvJoborder.DataSource = new JobOrderData().GetMngrJobOwnerDetails(_jobID);
        //gvJoborder.DataBind();
    }
    string filename = string.Empty;
    private void UploadFile(string newfolderNme)
    {
        string _requestID = txtJobNo.Text;
        if (fileUpload1.PostedFile != null)
        {
            filename = Path.GetFileName(fileUpload1.PostedFile.FileName);

            string filePath = string.Empty;
            if (fileUpload1.HasFile)
            {
                try
                {
                    //  string folderName = ConfigurationManager.AppSettings["NonEBDfolderName"].ToString();
                    filePath = Path.Combine(newfolderNme, filename);

                    fileUpload1.SaveAs(filePath);
                }
                catch (Exception ex)
                {
                    Response.Write(ex.Message);

                    string script = "<script type=\"text/javascript\"> displayPopup('" + ex.Message + "'); </script>";
                    ClientScript.RegisterClientScriptBlock(this.GetType(), "myscript", script);

                    return;
                }
            }
            else
            {
                ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Please select file for upload.')</script>", false);
                return;
            }
        }
    }
    private string CreateFolder(bool isUpload)
    {
        string requestID = string.Empty;
        requestID = txtJobNo.Text;
        string newfolderName = null;

        if (!Directory.Exists(ConfigurationManager.AppSettings["GISRequestFolderPath"].ToString()))
            Directory.CreateDirectory(ConfigurationManager.AppSettings["GISRequestFolderPath"].ToString());

        newfolderName = ConfigurationManager.AppSettings["GISRequestFolderPath"].ToString() + "\\" + requestID;
        Directory.CreateDirectory(newfolderName);

        if (newfolderName != null)
        {
            if (!isUpload)
            {
                string fullFilePath = getAllFiles(newfolderName);
                if (fullFilePath != "")
                {
                    fullFilePath.Substring(fullFilePath.LastIndexOf("\\") + 1);
                }
                else
                {


                }
            }
        }
        else
        {


        }
        return newfolderName;
    }
    private string getAllFiles(string newPath)
    {
        String[] allfiles = System.IO.Directory.GetFiles(newPath, "*.*", System.IO.SearchOption.AllDirectories);
        string foldrfileName = string.Empty;
        if (allfiles.Length != 0)
        {
            //foreach (var file in allfiles)
            //{
            FileInfo info = new FileInfo(allfiles[0]);
            foldrfileName = info.FullName;
        }

        return foldrfileName;
    }
    private void PopulateDropDownBox(DropDownList ddlBox, string sqlQuery, string valueMember, string displayName)
    {
        DataTable table = new DataTable();
        try
        {
            using (SqlConnection sqlConn = new SqlConnection(connValue))
            {
                using (SqlDataAdapter da = new SqlDataAdapter(sqlQuery, sqlConn))
                {
                    sqlConn.Open();
                    da.Fill(table);
                }
            }
            //cmbBox.Items.Add("Select");

            ddlBox.DataSource = table;
            ddlBox.DataTextField = displayName;
            ddlBox.DataValueField = valueMember;

            ddlBox.SelectedIndex = -1;
            ddlBox.DataBind();

            ddlBox.Items.Insert(0, new ListItem(""));
        }
        catch (System.Exception ex)
        {
            throw ex;
        }
    }
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnsave_Click(object sender, EventArgs e)
    {
        if (userRightsColl.Contains("7"))
        {
            // UpdateRequest_RemarksOnly(_jobID);
        }
        else
        {
            UpdateJobOrder(_jobID);
        }
    }
    protected void SelectedIndexChanged(object sender, EventArgs e)
    {
        DropDownList ddl = (DropDownList)sender;
        if (ddl.SelectedIndex != -1)
        {
            string ID = ddl.ID;
            string g = ddl.SelectedValue;
            string inchargeID = ddl.ToolTip;

            Session["_InchargeID"] = inchargeID;
            Session["StatusValCurrent"] = ddl.SelectedValue;

            if (ddl.SelectedValue != "3")
            {
                int rowFnd = getandChkData(Convert.ToInt32(inchargeID), Convert.ToInt32(ddl.SelectedValue));
                if (rowFnd != 0)
                {
                    ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Action By Staff not yet completed')</script>", false);
                    ddl.SelectedValue = "3";
                }
                else
                {
                    // updateOngoingStatus(Convert.ToInt32(inchargeID), Convert.ToInt32(ddl.SelectedValue));

                    gvJoborder.DataSource = new JobOrderData().GetJobOwnerDetails(_jobID);
                    gvJoborder.DataBind();
                }
            }
            else
            {
                updateOngoingStatus(Convert.ToInt32(inchargeID), Convert.ToInt32(ddl.SelectedValue));

                //if (ddl.SelectedValue == "3")
                //{
                //    new JobOrderData().UpdateCompletionDate(Convert.ToInt32(inchargeID));
                //}


                //if (ddl.SelectedValue == "3" || ddl.SelectedValue == "7")
                //    new JobOrderData().UpdateJobDoneCheckBox(Convert.ToInt32(inchargeID), Convert.ToInt32(ddl.SelectedValue)); //cmldaten jobdone

                //if (ddl.SelectedValue != "7")
                //{
                //    new JobOrderData().UpdateCompletionDate(Convert.ToInt32(inchargeID));
                //}

                // new JobOrderData().UpdateJobStatus(Convert.ToInt32(inchargeID), Convert.ToInt32(ddl.SelectedValue), Session["UserName"].ToString());

                gvJoborder.DataSource = new JobOrderData().GetJobOwnerDetails(_jobID);
                gvJoborder.DataBind();
            }
        }
    }



    private int getandChkDataTeamLead(int _ownerID, int _statusID)
    {
        int iCnt = 0;
        SqlConnection cnn = new SqlConnection(connValue);
        cnn.Open();
        SqlCommand cmm = new SqlCommand();
        cmm.Connection = cnn;
        cmm.CommandText = "select COUNT(*) AS rCnt from JobOwner where jobID = @jobID and jobownerID <> @ownerID and jobOwnerStatusID = 3";
        cmm.CommandType = CommandType.Text;

        cmm.Parameters.AddWithValue("@jobID", _jobID);
        cmm.Parameters.AddWithValue("@statID", _statusID);
        cmm.Parameters.AddWithValue("@ownerID", _ownerID);

        SqlDataReader dr = cmm.ExecuteReader();

        if (dr.HasRows)
        {
            while (dr.Read())
                iCnt = Convert.ToInt16(dr["rCnt"]);
        }
        cnn.Close();

        return iCnt;
    }


    private int getandChkData(int _ownerID, int _statusID)
    {
        SqlConnection cnn = new SqlConnection(connValue);
        cnn.Open();
        SqlCommand cmm = new SqlCommand();
        cmm.Connection = cnn;
        cmm.CommandText = "gis_chkTeamLeadStatus";
        cmm.CommandType = CommandType.StoredProcedure;

        cmm.Parameters.AddWithValue("@jobID", _jobID);
        cmm.Parameters.AddWithValue("@userID", Convert.ToInt32(Session["UserID"]));
        cmm.Parameters.AddWithValue("@ownerID", _ownerID);
        cmm.Parameters.AddWithValue("@statID", _statusID);
        cmm.Parameters.AddWithValue("@rCnt", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

        cmm.ExecuteNonQuery();
        cnn.Close();

        return (int)cmm.Parameters["@rCnt"].Value;
    }
    private void updateOngoingStatus(int _ownerID, int _statusID)
    {
        SqlConnection cnn = new SqlConnection(connValue);
        cnn.Open();
        SqlCommand cmm = new SqlCommand();
        cmm.Connection = cnn;
        cmm.CommandText = "update JobOwner set jobOwnerStatusID = @statID,completionDate = @completionDate where jobOwnerID =@ownerID";
        cmm.CommandType = CommandType.Text;

        cmm.Parameters.AddWithValue("@ownerID", _ownerID);
        cmm.Parameters.AddWithValue("@statID", _statusID);
        if (_statusID != 3)
            cmm.Parameters.AddWithValue("@completionDate", Convert.ToDateTime(System.DateTime.Now).ToString("dd/MMM/yyyy"));
        else
            cmm.Parameters.AddWithValue("@completionDate", System.DBNull.Value);

        cmm.ExecuteNonQuery();
        cnn.Close();
    }
    public void UpdateJobOrder(int upd_JobID)
    {
        SqlConnection sqlCon = new SqlConnection(connValue);
        SqlCommand cmd = new SqlCommand();
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.CommandText = "GIS_UpdateLog";
        cmd.Connection = sqlCon;

        cmd.Parameters.AddWithValue("@Job_id", upd_JobID);

        if (ddlJobType.SelectedIndex != 0)
            cmd.Parameters.AddWithValue("@Job_Type_id", ddlJobType.SelectedValue);
        else
            cmd.Parameters.AddWithValue("@Job_Type_id", ddlJobType.SelectedValue);

        if (ddlJobStatus.SelectedIndex != 0)
            cmd.Parameters.AddWithValue("@Job_Status_id", ddlJobStatus.SelectedValue);
        else
            cmd.Parameters.AddWithValue("@Job_Status_id", System.DBNull.Value);

        cmd.Parameters.AddWithValue("@Project_Code", "");

        cmd.Parameters.AddWithValue("@jobDesc", txtPrjTitle.Text);

        cmd.Parameters.AddWithValue("@Project_Title", txtPrjTitle.Text);

        cmd.Parameters.AddWithValue("@ContractorID", System.DBNull.Value);

        cmd.Parameters.AddWithValue("@ConsultantID", System.DBNull.Value);

        if (ddlDept.SelectedIndex != 0)
            cmd.Parameters.AddWithValue("@DepartmentID", ddlDept.SelectedValue);  // Not Applicable
        else
            cmd.Parameters.AddWithValue("@DepartmentID", 22);  // EBD

        cmd.Parameters.AddWithValue("@QSID", System.DBNull.Value);

        cmd.Parameters.AddWithValue("@PEID", System.DBNull.Value);

        cmd.Parameters.AddWithValue("@CEID", System.DBNull.Value);

        if (ddlPrjSize.SelectedIndex != 0)
            cmd.Parameters.AddWithValue("@gradeID", ddlPrjSize.SelectedValue);
        else
            cmd.Parameters.AddWithValue("@gradeID", 1);

        cmd.Parameters.AddWithValue("@remarks", txtRemarks.Text);

        cmd.Parameters.AddWithValue("@addendumNO", System.DBNull.Value);

        cmd.Parameters.AddWithValue("@contractTypeID", System.DBNull.Value);

        cmd.Parameters.AddWithValue("@workDays", 1);

        cmd.Parameters.AddWithValue("@dueDate", Convert.ToDateTime(txtDueDate.Text).ToString("dd/MMM/yyyy"));

        cmd.Parameters.AddWithValue("@updateUser", Session["UserName"]);

        cmd.Parameters.AddWithValue("@submissionNo", System.DBNull.Value);

        cmd.Parameters.AddWithValue("@attRecDate", System.DBNull.Value);

        cmd.Parameters.AddWithValue("@dcRejectionID", System.DBNull.Value);

        cmd.Parameters.AddWithValue("@projStstusID", System.DBNull.Value);

        cmd.Parameters.AddWithValue("@receivedSurveyTeamOn", System.DBNull.Value);

        cmd.Parameters.AddWithValue("@sentOnSurveyTeam", System.DBNull.Value);

        cmd.Parameters.AddWithValue("@reviewDate", System.DBNull.Value);

        cmd.Parameters.AddWithValue("@committmentNo", txtCntrNo.Text);

        cmd.Parameters.AddWithValue("@projectCode", txtPrjCode.Text);

        cmd.Parameters.AddWithValue("@projCoordinatorID", 216);

        cmd.Parameters.AddWithValue("@requesterName", txtRequesterName.Text);

        cmd.Parameters.AddWithValue("@DCID", System.DBNull.Value);

        if (ddlReqVia.SelectedIndex != 0)
            cmd.Parameters.AddWithValue("@recVia", ddlReqVia.SelectedValue);
        else
            cmd.Parameters.AddWithValue("@recVia", 1);

        cmd.Parameters.AddWithValue("@subTypeID", System.DBNull.Value);

        cmd.Parameters.AddWithValue("@taskPct", 100);

        cmd.Parameters.AddWithValue("@externalDept", System.DBNull.Value);

        cmd.Parameters.AddWithValue("@BarcodeNo", System.DBNull.Value);

        cmd.Parameters.AddWithValue("@ReqBehalf", txtOnBehalf.Text);

        try
        {
            sqlCon.Open();
            cmd.ExecuteNonQuery();
            sqlCon.Close();
        }
        catch (Exception ex)
        {
            throw ex;
        }
        //lblResult.Text = "Data Updated Successfully";
        // Response.Write();
    }
    private void UpdateRemarks(int jobOwnerID, string remarks)
    {
        if (txtStaffRemarks.Text.Trim() != "" && lblInchargeID.Text.Trim() != "")
        {
            SqlConnection con = new SqlConnection(connValue);
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.Text;
            cmd.Connection = con;

            cmd.CommandText = "Update JobOwner set remarks=@remarks,remarksDate=@remarksDate Where jobOwnerID=@jobOwnerID";
            cmd.Parameters.AddWithValue("@remarks", remarks);
            cmd.Parameters.AddWithValue("@remarksDate", System.DateTime.Now.ToString("dd/MMM/yyyy"));
            cmd.Parameters.AddWithValue("@jobOwnerID", jobOwnerID);

            try
            {
                con.Open();
                cmd.ExecuteNonQuery();
                con.Dispose();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                con.Close();
            }
        }

    }
    private void InsertStaffData()
    {
        int _ownerID = 0;

        _ownerID = AddInchargeDataDC(Session["Username"].ToString(), Convert.ToInt32(Session["UserID"]), Convert.ToInt32(Session["SectionID"]), txtReceivedDate.Text);
    }
    public int AddInchargeDataDC(string userName, int _currentUserID, int _currentSecID, string staffStartDate)
    {
        int _ownerID = 0;
        using (SqlConnection con = new SqlConnection(connValue))
        {
            using (SqlCommand cmd = new SqlCommand())
            {
                try
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Connection = con;

                    cmd.CommandText = "AddJobInchargeDC";

                    cmd.Parameters.AddWithValue("@jobID", _jobID);

                    cmd.Parameters.AddWithValue("@contactID", ddlStaff.SelectedValue);

                    cmd.Parameters.AddWithValue("@distributedBy", _currentUserID);

                    cmd.Parameters.AddWithValue("@actionDueDate", txtStaffDueDate.Text);

                    cmd.Parameters.AddWithValue("@daysToAct", 1);

                    cmd.Parameters.AddWithValue("@createUser", userName);

                    cmd.Parameters.AddWithValue("@StaffRoleID", 1);

                    if (ddlPurpose.SelectedIndex != 0)
                        cmd.Parameters.AddWithValue("@jobPurposeID", ddlPurpose.SelectedValue);
                    else
                        cmd.Parameters.AddWithValue("@jobPurposeID", 1);

                    cmd.Parameters.AddWithValue("@sectionID", 11);

                    cmd.Parameters.AddWithValue("@jobOwnerID", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                    if (staffStartDate != "")
                        cmd.Parameters.AddWithValue("@startDate", Convert.ToDateTime(System.DateTime.Now).ToString("dd/MMM/yyyy"));
                    else
                        cmd.Parameters.AddWithValue("@startDate", System.DBNull.Value);

                    con.Open();
                    cmd.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    throw ex;
                }

                return _ownerID = (int)cmd.Parameters["@jobOwnerID"].Value;
            }
        }
    }
    private void ClearStaffData()
    {
        //  ddlPrjSize.SelectedIndex = -1;
        //  ddlPurpose.SelectedIndex = -1;

        //  //txtStartDate.Text = "";
        //  //txtDueDate.Text = "";


        //  txtStaffRemarks.Text = "";

        ////  lblDistributedBy.Text = "";

        //  lblInchargeID.Text = "";





        // // txtMngrComments.Text = "";
        // // lblDistributedBy.Text = "";




    }
    private void PopulateDropDownBox_Staff(DropDownList ddlBox, string sqlQuery, string valueMember, string displayName)
    {
        DataTable table = new DataTable();
        try
        {
            using (SqlConnection sqlConn = new SqlConnection(connValue))
            {
                using (SqlDataAdapter da = new SqlDataAdapter(sqlQuery, sqlConn))
                {
                    sqlConn.Open();
                    da.Fill(table);
                }
            }
            //cmbBox.Items.Add("Select");

            ddlBox.DataSource = table;
            ddlBox.DataTextField = displayName;
            ddlBox.DataValueField = valueMember;

            ddlBox.SelectedIndex = -1;
            ddlBox.DataBind();

            // ddlBox.Items.Insert(0, new ListItem("--Select--"));
        }
        catch (System.Exception ex)
        {
            throw ex;
        }
    }
    Boolean isDisabled = false;
    protected void gvJoborder_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            //e.Row.Cells[8].Width = new Unit("60px");
            //e.Row.Cells[8].Height = new Unit("60px");
            //e.Row.Cells[8].Wrap = true;


            DropDownList l = (DropDownList)e.Row.FindControl("ddljobtype");

            PopulateDropDownBox_Staff(l, "SELECT JobStatusid,JobStatusName as JobStatus FROM jobStatus where JobStatusid in(2,3,6,7) ", "JobStatusid", "JobStatus");  // where JobStatusid in(5,6,7,8)

            TextBox lm = (TextBox)e.Row.FindControl("jobid");
            TextBox afr = (TextBox)e.Row.FindControl("TextBox1");
            TextBox InchargeID = (TextBox)e.Row.FindControl("txtInchargeID");

            Session["InchargeID"] = InchargeID.Text;

            string lk = lm.Text;

            l.ToolTip = InchargeID.Text;



            l.SelectedValue = afr.Text;

            Session["StatusVal"] = l.SelectedValue;

            l.SelectedIndexChanged += new EventHandler(SelectedIndexChanged);

            TextBox txtdate = (TextBox)e.Row.FindControl("lblJoindate");
            txtdate.ToolTip = InchargeID.Text;
            txtdate.TextChanged += new EventHandler(txtdate_TextChanged);
            Session["JobActionDueDate"] = txtdate.Text;

            Label lblStaff = (Label)e.Row.FindControl("txtStaff");

            Label lblDistributedBy = (Label)e.Row.FindControl("txtDistrubed");

            Label lblConactID = (Label)e.Row.FindControl("txtCnctID");

            TextBox _txtDocID = (TextBox)e.Row.FindControl("txtDocID");
            Session["statusdocID"] = _txtDocID.Text;
            Session["contactID"] = lblConactID.Text;

            Label lblDistribID = (Label)e.Row.FindControl("txtDistributedBy");
            Label lblTeamLeadID = (Label)e.Row.FindControl("lblTeamLead");

            //Label lblRoleID = (Label)e.Row.FindControl("txtRoleID");
            // chkDelete.CheckedChanged += new EventHandler(chkstate_CheckedChanged);                        

            if ((!lblConactID.Text.Equals(Session["userID"])))
            {
                l.Enabled = false;
            }
            if (lblConactID.Text.Equals(Session["userID"]))
            {
                //  btnOutlook.Enabled = true;
                Session["ActionDate"] = txtdate.Text;
            }
            if (!lblDistribID.Text.Equals(Session["userID"]))
            {
                txtdate.Enabled = false;
            }

            if (!isDisabled)
            {
                LinkButton lnkSelect = (LinkButton)e.Row.FindControl("btnSelect");
                lnkSelect.Enabled = false;
                isDisabled = true;
            }


        }
    }
    protected void txtdate_TextChanged(object sender, EventArgs e)
    {
        TextBox tdate = (TextBox)sender;
        //string format = "dd/mm/yyyy";

        string dfs = tdate.Text;


        DateTime dd = new DateTime();
        Thread.CurrentThread.CurrentCulture = new CultureInfo("en-GB");
        CultureInfo ci = System.Threading.Thread.CurrentThread.CurrentCulture;
        DateTime dt;

        //dt = DateTime.Parse(tdate.Text, ci); 
        // DateTime dt = DateTime.Parse(tdate.Text, CultureInfo.GetCultureInfo("en-gb"));
        // new JobOrderData().UpdateJobDate(Convert.ToInt32(tdate.ToolTip), dd.ToString());

        new JobOrderData().UpdateJobDate(Convert.ToInt32(tdate.ToolTip), dfs);

        gvJoborder.DataSource = new JobOrderData().GetJobOwnerDetails(_jobID);
        gvJoborder.DataBind();
    }
    protected void gvJoborder_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName.Equals("SelectStaff"))
        {
            string arguments = e.CommandArgument.ToString();

            if (arguments == "")
                return;

            string[] args = arguments.Split(';');

            int staffID = Convert.ToInt32(args[0]);

            FillstaffData(staffID);

            btnStaffSave.Text = " Update Data";

            txtStaffRemarks.Enabled = true;

            trStaffRmrks.Visible = true;

            ddlStaff.Enabled = false;
        }
    }
    private void FillstaffData(int staffID)
    {
        string qry = "SELECT  jobOwnerID, jobID, contactID, jobNo,REPLACE(CONVERT(NVARCHAR, actionDueDate, 106), ' ', '/') AS actionDueDate,  daysToAct, REPLACE(CONVERT(NVARCHAR, completionDate, 106), ' ', '/') AS completionDate, jobOwnerStatusID, jobPurposeID, JobTypeID, " +
        "REPLACE(CONVERT(NVARCHAR, staffIssueDate, 106), ' ', '/') AS staffIssueDate , distributedBy,   remarks, REPLACE(CONVERT(NVARCHAR, staffStartDate, 106), ' ', '/') AS staffStartDate  FROM  JobOwner WHERE (jobOwnerID = " + staffID + ")";

        using (SqlConnection cn = new SqlConnection(connValue))
        {
            cn.Open();
            using (SqlCommand cmd = new SqlCommand(qry, cn))
            {
                using (SqlDataReader dr = cmd.ExecuteReader())
                {
                    while (dr.Read())
                    {
                        lblInchargeID.Text = dr["JobOwnerID"].ToString();
                        // lblDistributedBy.Text = "95";

                        ddlPurpose.SelectedValue = dr["jobPurposeID"].ToString();
                        //txtStartDate.Text = dr["staffIssueDate"].ToString();

                        //  txtWorkDays.Text = dr["daysToAct"].ToString();
                        txtStaffDueDate.Text = dr["actionDueDate"].ToString();

                        txtStaffRemarks.Text = dr["remarks"].ToString();

                        lblDistributedBy.Text = dr["distributedBy"].ToString();

                        try
                        {
                            ddlStaff.SelectedValue = dr["contactID"].ToString();
                        }
                        catch (Exception ex)
                        {

                        }
                    }
                }
            }
        }
    }
    public void Fill_JobOrder_Information(int _jobID)
    {
        try
        {
            SqlConnection sqlConn = new SqlConnection(connValue);
            sqlConn.Open();

            string strValue = "SELECT Job.jobNo, Job.jobTypeID, Job.jobPriorityID, Job.jobStatusID, Job.remarks AS Instruction, Job.deptID, Job.contractNo, Job.qsID, Job.ceID, Job.peID, Job.dcID, " +
                        " Job.contractTypeID AS Contract_Type_id, Job.projectTitle, Job.remarks, Job.contractorID, Job.consultantID, Job.jobID, Job.addendumNO, Job.jobTypeID AS Expr1, " +
                        " Job.jobDesc, Job.docRefID, Job.workDays, Job.jobDueDate, Job.jobReceivedDate, Job.jobStatusClosedDate, Job.jobClosedDate, Job.docRefID AS Expr2, " +
                         " JobType.CategoryID AS JobCatID, Job.projectCode, Job.committmentNo, Job.attRcvdDateDC, Job.reviewDateDC, Job.sentToSurveyTeamDC, " +
                       "  Job.receivedBySurveyTeamDC, Job.reqStatusID, Job.submissionNoDC, Job.projCoordinatorID, Job.dcRejectionID, Job.closedDocRefID, Job.jobPriorityID, " +
                        " Job.reqServiceID, Job.jobRequester, Job.taskSubTypeID, Contact.jobPosition, Contact_1.firstName + '  ' + Contact_1.lastName AS coordName, " +
                        " Department.deptName,Job.externalDept,Job.taskPct,Job.BarcodeNo, Contact.firstName + '  ' + Contact.lastName AS Requester, Contact.emailAddress,job.reqBehalf,job.reqServiceID FROM Job INNER JOIN JobType ON Job.jobTypeID = JobType.jobTypeID INNER JOIN Contact ON Job.requestedBy = Contact.contactID INNER JOIN Contact AS Contact_1 ON Job.projCoordinatorID = Contact_1.contactID INNER JOIN " +
                        " Department ON Job.deptID = Department.departmentID Where (Job.jobID = " + _jobID + ")";


            SqlCommand sqlCom = new SqlCommand(strValue, sqlConn);


            sqlCom.CommandText = strValue;

            sqlCom.Parameters.AddWithValue("@JobID", _jobID);

            SqlDataReader sqlReader = sqlCom.ExecuteReader();

            while (sqlReader.Read())
            {
                txtJobNo.Text = sqlReader["JobNo"].ToString();

                Session["jobNo"] = txtJobNo.Text;

                ddlJobStatus.SelectedValue = sqlReader["jobStatusID"].ToString();

                ddlJobCat.SelectedValue = sqlReader["JobCatID"].ToString();

                Session["JobCatID"] = sqlReader["JobCatID"].ToString();

                ddlJobType.SelectedValue = sqlReader["jobTypeID"].ToString();

                Session["jobTypeID"] = sqlReader["jobTypeID"].ToString();

                txtPrjTitle.Text = sqlReader["jobDesc"].ToString();    //jobDesc

                txtPrjTitle.Text = sqlReader["projectTitle"].ToString();    //jobDesc

                txtReceivedDate.Text = Convert.ToDateTime(sqlReader["jobReceivedDate"]).ToString("dd/MMM/yyyy");

                txtRequesterEmail.Text = sqlReader["emailAddress"].ToString();

                txtRequesterName.Text = sqlReader["Requester"].ToString();

                //  ddlPrjSize.SelectedValue = sqlReader["DCID"].ToString();

                if (sqlReader["JobDueDate"].ToString() != "")
                    txtDueDate.Text = Convert.ToDateTime(sqlReader["JobDueDate"]).ToString("dd/MMM/yyyy");

                txtRemarks.Text = sqlReader["remarks"].ToString();

                if (sqlReader["jobStatusClosedDate"].ToString() != "")
                    txtStatusClose.Text = Convert.ToDateTime(sqlReader["jobStatusClosedDate"]).ToString("dd/MMM/yyyy");

                txtCntrNo.Text = sqlReader["contractNo"].ToString();

                txtPrjCode.Text = sqlReader["projectCode"].ToString();


                Session["contractNo"] = txtCntrNo.Text;

                if (sqlReader["deptID"].ToString() != "")
                    ddlDept.SelectedValue = sqlReader["deptID"].ToString();

                if (sqlReader["jobPriorityID"].ToString() != "")
                {
                    ddlPrjSize.SelectedValue = sqlReader["jobPriorityID"].ToString();
                    if (sqlReader["jobPriorityID"].ToString().Equals("1"))
                        lblSize.Text = "- 7 Days";
                    else if (sqlReader["jobPriorityID"].ToString().Equals("2"))
                        lblSize.Text = "- 10 Days";
                    else if (sqlReader["jobPriorityID"].ToString().Equals("3"))
                        lblSize.Text = "- 15 Days";

                }
                else
                    ddlPrjSize.SelectedValue = "1";

                txtOnBehalf.Text = sqlReader["reqBehalf"].ToString();

                ddlReqVia.SelectedValue = sqlReader["reqServiceID"].ToString();
            }

            sqlReader.Close();
            sqlConn.Close();
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    protected void btnreset_Click(object sender, EventArgs e)
    {
        ddlStaff.SelectedIndex = 0;
        ddlPurpose.SelectedIndex = 0;
        txtStaffDueDate.Text = "";
        txtStaffRemarks.Text = "";

        ddlStaff.Enabled = true;

        btnStaffSave.Text = "ADD Staff";
    }
    protected void gvFileUpload_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        string requestID = txtJobNo.Text;
        if (!Directory.Exists(ConfigurationManager.AppSettings["GISRequestFolderPath"].ToString()))
            Directory.CreateDirectory(ConfigurationManager.AppSettings["GSRequestFolderPath"].ToString());

        string newfolderName = ConfigurationManager.AppSettings["GISRequestFolderPath"].ToString() + "\\" + requestID;

        if (e.CommandName == "Select")
        {
            int rowIndex = Convert.ToInt32(e.CommandArgument);
            GridViewRow row = gvFileUpload.Rows[rowIndex];
            string country = row.Cells[0].Text;
            string _FilePath = newfolderName + "\\" + country;
            Response.Clear();
            Response.ContentType = "application/octect-stream";
            Response.AddHeader("Content-Disposition", "attachment;filename=\"" + _FilePath + "\"");
            Response.TransmitFile(_FilePath);
            Response.End();


        }
        else if (e.CommandName == "Delete")
        {
            if (userRightsColl.Contains("4"))
            {
                ClientScript.RegisterClientScriptBlock(this.GetType(), "Popup", "<script>alert('You have no privilege to delete this file')</script>", false);
                return;
            }

            int rowIndex = Convert.ToInt32(e.CommandArgument);
            GridViewRow row = gvFileUpload.Rows[rowIndex];
            string fileName = row.Cells[0].Text;
            string _FilePath = newfolderName + "\\" + fileName;


            try
            {
                if (fileName != null || fileName != string.Empty)
                {
                    if ((System.IO.File.Exists(_FilePath)))
                    {
                        System.IO.File.Delete(_FilePath);
                    }
                }
            }
            catch (Exception ex)
            {

            }
            finally
            {
                ReadFiles_GS();
            }
        }


    }
    protected void gvFileUpload_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {

    }
    protected void btnUpload_Click1(object sender, EventArgs e)
    {
        UploadFile(CreateFolder(true));

        ReadFiles_GS();
    }



    private void ReadFiles()
    {
        string[] filePaths = Directory.GetFiles(Server.MapPath("~/Images/"));
        List<ListItem> files = new List<ListItem>();
        foreach (string filePath in filePaths)
        {
            string fileName = Path.GetFileName(filePath);
            files.Add(new ListItem(fileName, "~/Images/" + fileName));
        }
        gvFileUpload.DataSource = files;
        gvFileUpload.DataBind();
    }
    private void ReadFiles_GS()
    {
        string requestID = txtJobNo.Text;
        if (!Directory.Exists(ConfigurationManager.AppSettings["GISRequestFolderPath"].ToString()))
            Directory.CreateDirectory(ConfigurationManager.AppSettings["GISRequestFolderPath"].ToString());

        try
        {
            string newfolderName = ConfigurationManager.AppSettings["GISRequestFolderPath"].ToString() + "\\" + requestID;
            string[] filePaths = Directory.GetFiles(newfolderName);
            List<ListItem> files = new List<ListItem>();
            foreach (string filePath in filePaths)
            {
                string fileName = Path.GetFileName(filePath);
                files.Add(new ListItem(fileName, newfolderName + "\\" + fileName));
            }
            gvFileUpload.DataSource = files;
            gvFileUpload.DataBind();
        }
        catch (Exception ex)
        {

        }
        finally
        {

        }
    }
    protected void lnkDownload_Click(object sender, EventArgs e)
    {
        //if (checkUserExist(Convert.ToInt32(fileID), 1, Convert.ToInt32(Session["UserID"])))
        {
            LinkButton lnkbtn = sender as LinkButton;
            GridViewRow gvrow = lnkbtn.NamingContainer as GridViewRow;

            string filePath = gvFileUpload.DataKeys[gvrow.RowIndex].Value.ToString();

            // Only use in case Application Server File foldes not in C Drive

            filePath = filePath.Replace("C:", "E:");

            Response.AddHeader("Content-Disposition", "attachment;filename=\"" + filePath + "\"");
            //Response.TransmitFile(Server.MapPath(filePath));

            if (!File.Exists((string)filePath))
            {
                Response.Write("File not available at specific path");
                return;
            }

            Response.TransmitFile(filePath);
            Response.End();
        }
    }
    private void reset_StaffData()
    {
        ddlStaff.SelectedIndex = 0;
        ddlPurpose.SelectedIndex = 0;
        txtStaffDueDate.Text = "";
        txtStaffRemarks.Text = "";

        lblInchargeID.Text = "";

        btnStaffSave.Text = "ADD Staff";
    }
    protected void btnStaffSave_Click(object sender, EventArgs e)
    {
        int InchargeID = 0;

        if (lblInchargeID.Text != "")
            InchargeID = Convert.ToInt32(lblInchargeID.Text);

        if (InchargeID == 0)
        {
            if (userRightsColl.Contains("4"))
            {
                ClientScript.RegisterClientScriptBlock(this.GetType(), "Popup", "<script>alert('You have no privilege to Add Staff')</script>", false);
                return;
            }

            InsertStaffData();


            string _eMail = getEmail(ddlStaff.SelectedValue);
            OutLookAlertQuick(_eMail, "");

            reset_StaffData();
        }
        else
        {
            //  UpdateRemarks(InchargeID, txtStaffRemarks.Text.Trim());

            UpdateInchargeData(InchargeID);

            reset_StaffData();
        }

        gvJoborder.DataSource = new JobOrderData().GetJobOwnerDetails(_jobID);
        gvJoborder.DataBind();

        txtStaffRemarks.Enabled = false;
        trStaffRmrks.Visible = true;
        ddlStaff.Enabled = true;

    }
    private string getEmail(string contactID)
    {
        string streMail = string.Empty;
        try
        {
            SqlConnection sqlConn = new SqlConnection(connValue);
            sqlConn.Open();
            SqlCommand sqlCom = new SqlCommand("Select emailAddress from Contact where ContactID = " + Convert.ToInt32(contactID) + "", sqlConn);
            SqlDataReader sqlReader = sqlCom.ExecuteReader();
            while (sqlReader.Read())
            {
                streMail = sqlReader["emailAddress"].ToString();
            }
            sqlReader.Close();
            sqlConn.Close();
        }
        catch (System.Exception ex)
        {
            throw ex;
        }

        return streMail;
    }
    public void UpdateInchargeData(int inchargeID)
    {
        using (SqlConnection con = new SqlConnection(connValue))
        {
            using (SqlCommand cmd = new SqlCommand())
            {
                try
                {
                    cmd.CommandType = CommandType.Text;
                    cmd.Connection = con;

                    if (lblDistributedBy.Text.Equals(Session["UserID"].ToString()))
                    {
                        cmd.CommandText = "Update JobOwner Set remarks =@inchargeRemarks,jobPurposeID = @jobPurposeID, " +
                        " actionDueDate =@actionDueDate where jobOwnerID = " + inchargeID;

                        // ,teamStatusID = @taskStatusID

                        cmd.Parameters.AddWithValue("@actionDueDate", Convert.ToDateTime(txtStaffDueDate.Text).ToString("dd/MMM/yyyy"));
                        cmd.Parameters.AddWithValue("@jobPurposeID", ddlPurpose.SelectedValue);
                    }
                    else if (!userRightsColl.Contains("4"))
                    {
                        cmd.CommandText = "Update JobOwner Set remarks =@inchargeRemarks,jobPurposeID = @jobPurposeID, " +
                        " actionDueDate =@actionDueDate where jobOwnerID = " + inchargeID;

                        // ,teamStatusID = @taskStatusID

                        cmd.Parameters.AddWithValue("@actionDueDate", Convert.ToDateTime(txtStaffDueDate.Text).ToString("dd/MMM/yyyy"));
                        cmd.Parameters.AddWithValue("@jobPurposeID", ddlPurpose.SelectedValue);
                    }
                    else
                    {
                        cmd.CommandText = "Update JobOwner Set remarks =@inchargeRemarks where jobOwnerID = " + inchargeID;
                    }

                    cmd.Parameters.AddWithValue("@inchargeRemarks", txtStaffRemarks.Text);
                    cmd.Parameters.AddWithValue("@jobOwnerID", SqlDbType.SmallInt).Direction = ParameterDirection.Output;


                    con.Open();
                    cmd.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
        }
    }
    protected void ddlPrjSize_SelectedIndexChanged(object sender, EventArgs e)
    {
        string endDate = string.Empty;
        if (ddlPrjSize.SelectedIndex == 0)
        {
            lblSize.Text = "- 7 Days";
            endDate = getEndDateByGivenDays(7, txtReceivedDate.Text);
        }
        else if (ddlPrjSize.SelectedIndex == 1)
        {
            lblSize.Text = "- 10 Days";
            endDate = getEndDateByGivenDays(10, txtReceivedDate.Text);

        }
        else if (ddlPrjSize.SelectedIndex == 2)
        {
            lblSize.Text = "- 15 Days";
            endDate = getEndDateByGivenDays(15, txtReceivedDate.Text);
        }
        else
        {
            endDate = getEndDateByGivenDays(7, txtReceivedDate.Text);
        }

        txtDueDate.Text = Convert.ToDateTime(endDate).ToString("dd/MMM/yyyy");

    }
    private void WorkingDaysCaluclationByGrade(string strDate)
    {
        string endDate = string.Empty;
        switch (ddlPrjSize.SelectedItem.ToString())
        {
            case "1":

                endDate = getEndDateByGivenDays(7, strDate);
                txtDueDate.Text = Convert.ToDateTime(endDate).ToString("dd/MMM/yyyy");

                //txtDueDate.Text = System.DateTime.Now.AddDays(5).ToString("dd/MMM/yyyy");
                break;
            case "2":
                endDate = getEndDateByGivenDays(10, strDate);
                txtDueDate.Text = Convert.ToDateTime(endDate).ToString("dd/MMM/yyyy");
                break;

            case "3":
                endDate = getEndDateByGivenDays(15, strDate);
                txtDueDate.Text = Convert.ToDateTime(endDate).ToString("dd/MMM/yyyy");
                break;

            case "4":
                endDate = getEndDateByGivenDays(20, strDate);
                txtDueDate.Text = Convert.ToDateTime(endDate).ToString("dd/MMM/yyyy");
                break;

            case "":
                txtDueDate.Text = "";
                //txtWorkDays.Text = "";
                break;

            default:
                break;
        }
    }
    private string getEndDateByGivenDays(int _days, string strDate)
    {
        SqlConnection con = new SqlConnection(connValue);
        SqlCommand cmd = new SqlCommand();
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Connection = con;

        cmd.CommandText = "AddWorkdays";
        SqlParameter prm = cmd.Parameters.Add("@ad_startDate", SqlDbType.DateTime);
        prm.Value = strDate;
        prm = cmd.Parameters.Add("@actual_workDays", SqlDbType.Int);
        prm.Value = Convert.ToInt32(_days);
        prm = cmd.Parameters.Add("@endDate", SqlDbType.DateTime);
        prm.Direction = ParameterDirection.Output;
        con.Open();
        SqlDataReader dr = cmd.ExecuteReader();
        while (dr.Read())
            Console.WriteLine(dr.GetString(0));
        con.Dispose();
        con.Close();

        return cmd.Parameters[2].Value.ToString();
    }
    protected void ddlJobStatus_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (userRightsColl.Contains("6")) // Access Right is 6
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Don't have the permission to edit this field ')</script>", false);
        }
        else if (getStaffStatus() == true)
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Action By Staff not yet completed')</script>", false);
            ddlJobStatus.SelectedValue = "3";
        }
        else
        {
            if (ddlJobStatus.SelectedIndex != 0)
            {
                Session["lnkJobID"] = _jobID;

                if ((ddlJobStatus.SelectedValue == "2") || (ddlJobStatus.SelectedValue == "5"))     //Rej or Cancelleted 2 n 5
                {
                    UpdateJobStatuCompletedsDate(_jobID, Convert.ToInt32(ddlJobStatus.SelectedValue));

                    // UpdateJobStatusByUserSelection(_jobID, Convert.ToInt32(ddlJobStatus.SelectedValue));
                }
                else if ((ddlJobStatus.SelectedValue == "3"))  // ongoing
                {
                    // UpdateJobStatusByUserSelection(_jobID, Convert.ToInt32(ddlJobStatus.SelectedValue));

                    UpdateJobStatuCompletedsDate(_jobID, Convert.ToInt32(ddlJobStatus.SelectedValue));
                }
                else if ((ddlJobStatus.SelectedValue == "7"))               // Close n Completed 7
                {
                    UpdateJobStatuCompletedsDate(_jobID, Convert.ToInt32(ddlJobStatus.SelectedValue));
                    // txtWt.Text = "100";
                }
                //else if (ddlJobStatus.SelectedValue == "1")
                //{
                //    CloseJob();

                //    UpdateJobClosedDate(_jobID, Convert.ToInt32(ddlJobStatus.SelectedValue));

                //    txtWt.Text = "100";
                //}
                else
                {
                    UpdateJobStatusByUserSelection(_jobID, Convert.ToInt32(ddlJobStatus.SelectedValue));
                }

                Fill_JobOrder_Information(_jobID);
            }
        }
    }
    public void UpdateJobStatuCompletedsDate(int _jobID, int statusID)
    {
        string upDateQuery = string.Empty;

        upDateQuery = "UPDATE Job SET jobStatusID =@jobStatusID,jobStatusClosedDate=@jobStatusClosedDate WHERE JobID = @JobID";          // jobClosedDate =@jobClosedDate,


        SqlConnection sqlCon = new SqlConnection(connValue);
        SqlCommand cmd = new SqlCommand();
        cmd.CommandText = upDateQuery;
        cmd.Connection = sqlCon;

        cmd.Parameters.AddWithValue("@JobID", _jobID);


        if (statusID == 3) // On going
            cmd.Parameters.AddWithValue("@jobStatusClosedDate", System.DBNull.Value);
        else
            cmd.Parameters.AddWithValue("@jobStatusClosedDate", System.DateTime.Now.ToString("dd/MMM/yyyy"));

        if (statusID == 3)
            cmd.Parameters.AddWithValue("@jobStatusID", 3);
        else
            cmd.Parameters.AddWithValue("@jobStatusID", statusID);

        try
        {
            sqlCon.Open();
            cmd.ExecuteNonQuery();
            sqlCon.Close();
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    public void UpdateJobStatusByUserSelection(int _jobID, int statusID)
    {
        string upDateQuery = string.Empty;

        upDateQuery = "UPDATE Job SET jobStatusID =@jobStatusID WHERE JobID = @JobID";          // jobClosedDate =@jobClosedDate,


        using (SqlConnection sqlCon = new SqlConnection(connValue))
        {
            using (SqlCommand cmd = new SqlCommand())
            {
                cmd.CommandText = upDateQuery;
                cmd.Connection = sqlCon;

                cmd.Parameters.AddWithValue("@JobID", _jobID);
                cmd.Parameters.AddWithValue("@jobStatusID", statusID);

                try
                {
                    sqlCon.Open();
                    cmd.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
        }
    }

    private Boolean getStaffStatus()
    {
        Boolean chkStaffStatus = false;

        try
        {
            SqlConnection sqlConn = new SqlConnection(connValue);
            sqlConn.Open();

            string strValue = "SELECT jobOwnerID FROM  JobOwner WHERE (jobID = @JobID) AND (jobOwnerStatusID = 3)";

            SqlCommand sqlCom = new SqlCommand(strValue, sqlConn);
            sqlCom.CommandText = strValue;

            sqlCom.Parameters.AddWithValue("@JobID", _jobID);
            SqlDataReader sqlReader = sqlCom.ExecuteReader();

            if (sqlReader.HasRows)
                chkStaffStatus = true;
            else
                chkStaffStatus = false;

            sqlReader.Close();
            sqlConn.Close();
        }
        catch (Exception ex)
        {
            throw ex;
        }

        return chkStaffStatus;
    }
    protected void btnSearch_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/GIS/SearchGISData.aspx", false);
    }

    protected void ddlStaff_SelectedIndexChanged(object sender, EventArgs e)
    {
        //string sqlQuery = "SELECT  JobType_1.jobTypeName AS jobCategory, JobType.jobTypeName,JobPurpose.jobPurposeID, JobPurpose.jobPurposeName, JobType.CategoryID, JobType.jobTypeID FROM JobTypePurpose INNER JOIN " + 
        //               "  JobType ON JobTypePurpose.jobTypeID = JobType.jobTypeID INNER JOIN JobPurpose ON JobTypePurpose.jobPurposeID = JobPurpose.jobPurposeID INNER JOIN JobType AS JobType_1 ON JobType_1.jobTypeID = JobType.CategoryID " +
        //   "WHERE        (JobType.jobTypeID  = " + ddlJobType.SelectedItem.Value + ")  or (JobPurpose.jobPurposeID in(8,10))";



        //string sqlQuery = "select x.jobTypeID,a.jobtypeid,d.jobPurposeID,x.jobTypeName as jobCategory,a.jobTypeName,d.jobpurposename from JobType a inner join JobType x ON x.jobTypeID = a.CategoryID inner join JobTypePurpose b on a.jobTypeID = b.jobTypeID " +
        //  " inner join JobPurpose d on b.jobPurposeID = d.jobPurposeID where a.jobTypeID = " + ddlJobType.SelectedItem.Value + " order by x.jobTypeID";

        //PopulateDropDownBox(ddlPurpose, sqlQuery, "jobPurposeID", "jobPurposeName"); //  For Distribution -1  // For Review - 8// For Approval - 9// For Action -10 // 14 - For Coordination
    }
    protected void btnDelete_Click(object sender, EventArgs e)
    {
        if (userRightsColl.Contains("4"))
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "Popup", "<script>alert('You have no privilege to Update this Job')</script>", false);
            return;
        }
        else
        {
            if (lblInchargeID.Text == "")
                return;

            int InchargeID = Convert.ToInt32(lblInchargeID.Text);
            new JobOrderData().DeleteIncharge(InchargeID);

            gvJoborder.DataSource = new JobOrderData().GetMngrJobOwnerDetails(_jobID);
            gvJoborder.DataBind();

            reset_StaffData();

            ddlStaff.Enabled = true;

            // ClearStaffData();
        }
    }
    protected void gvJoborder_SelectedIndexChanged(object sender, EventArgs e)
    {

    }

    #region MyRegion

    private void SendCompletedCallback(SmtpClient smtpclient, System.Net.Mail.MailMessage mail) //private static void SendCompletedCallback(object sender, AsyncCompletedEventArgs e
    {
        try
        {
            smtpclient.Send(mail);
        }
        catch (Exception ex)
        {
            Console.WriteLine(ex);
            if (ex.InnerException != null)
            {
                Console.WriteLine("InnerException is: {0}", ex.InnerException);
            }
        }
        //finally
        //{
        //    mail.Dispose();
        //    mail = null;
        //    // smtpclient = null;
        //}
    }

    private void OutLookAlertQuick(string eMail, string mailBody)
    {
        SmtpClient smtpclient = new SmtpClient("10.250.50.201", 587);
        System.Net.Mail.MailMessage mail = new System.Net.Mail.MailMessage();
        MailAddress fromaddress = new MailAddress("EBSD@ashghal.gov.qa");
        mail.From = fromaddress;
        mail.To.Add(eMail);
        mail.Subject = ("eBook Job No. " + Session["jobNo"].ToString());
        mail.IsBodyHtml = true;

        // mail.Body = "Please be informed that a new Job Order was assigned to you under the above subject. Please log on to eBook Application to see the details of the Job Order.";

        mail.Body = "<html><body><i style='font-family:Calibri; font-size:15'>Dear eBook Team,</i><br/><br/><i style='font-family:Calibri; font-size:15'>This is an automated alert from Document & Task Management System.</i><br/><br/><i style='font-family:Calibri;font-size:15'>" +
                            "Please be noted that</i><i style='color:Maroon;font-family:Calibri; font-size:15'> Job No. " + Session["jobNo"].ToString() + "</i><i style='font-family:Calibri; font-size:15'> a new Job Order was assigned to you and the details are as follows:-</i><br /><br />" +
                            "<table style='width:80%' border='1'><tr><td align='center' colspan='2' style='background-color:Maroon;color:White;font-family:Calibri;font-size:18;font-weight:bold'>JOB NO: " + Session["jobNo"].ToString() + "</td>" +
                            "</tr><tr><td style='background-color:#B58AA5;font-family:Calibri;font-size:15'><i>Contract No / Project Code </i></td><td style='font-family:Calibri;font-size:15'>" + Session["contractNo"].ToString() + "</td></tr>" +
                            "<tr><td style='background-color:#B58AA5;font-family:Calibri;font-size:15'><i>eBook URL</i></td><td style='font-family:Calibri;font-size:15'>   http://mv2ebdbookp01/eBookGIS/LoginPage.aspx   </td></tr>" +
                            "<tr><td style='background-color:#B58AA5;font-family:Calibri;font-size:15'><i>Date of Creation</i></td><td style='font-family:Calibri;font-size:15'>" + System.DateTime.Now + "</td></tr>" +
                            "</table><br/><br/><div style='font-family:Calibri; font-size:15'>Best Regards,<br/>eBook Team</div></body></html>";


        smtpclient.EnableSsl = true;
        smtpclient.UseDefaultCredentials = true;

        try
        {
            smtpclient.Credentials = new System.Net.NetworkCredential(@"Ashghal\EBSD", ConfigurationManager.AppSettings["passWordForReport"].ToString()); //i
            ServicePointManager.ServerCertificateValidationCallback = delegate(object s, X509Certificate certificate, X509Chain chain, SslPolicyErrors sslPolicyErrors) { return true; };

            // Added code for qucik mail

            SendEmail myAction = new SendEmail(SendCompletedCallback);
            myAction.BeginInvoke(smtpclient, mail, null, null);
        }
        catch (System.Exception ex)
        {
            Console.WriteLine(ex);
            if (ex.InnerException != null)
            {
                Console.WriteLine("InnerException is: {0}", ex.InnerException);
            }
        }
        //finally
        //{
        //    //mail.Dispose();
        //    //mail = null;
        //    //// smtpclient = null;
        //}

    }

    private delegate void SendEmail(SmtpClient smtpclient, System.Net.Mail.MailMessage mail);



    #endregion
}