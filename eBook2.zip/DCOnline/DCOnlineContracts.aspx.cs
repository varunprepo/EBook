﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;


using Datalayer;
using System.Web.UI.HtmlControls;

//using System.Data.OracleClient;

using Oracle.ManagedDataAccess.Client;

using System.Globalization;
using System.IO;
using System.Web.Script.Serialization;

public partial class DCOnline_DCOnlineContracts : System.Web.UI.Page
{
    string connValueOracle = System.Configuration.ConfigurationManager.ConnectionStrings["DCConnOracle"].ConnectionString;

    string connValue = System.Configuration.ConfigurationManager.ConnectionStrings["EBSDEBookConn"].ConnectionString;

    Employee jObject = new Employee();

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
          DataTable dt =  getData("");

          //DataTable dtFiles = getDataFiles("");

          //DataTable dtStaff = getDataStaff("");

          gvPerson.DataSource = dt;
          gvPerson.DataBind();

          //gvFiles.DataSource = dtFiles;
          //gvFiles.DataBind();

          //gvStaff.DataSource = dtStaff;
          //gvStaff.DataBind();
            
        }
    }
    protected void lnkJobOrderJobNo_Click(object sender, EventArgs e)     //ForCommitted
    {
        try
        {
            LinkButton lnkJobID = (LinkButton)sender;
            GridViewRow gvr = (GridViewRow)lnkJobID.NamingContainer;

            Session["JobID"] = ((HtmlGenericControl)gvr.FindControl("divJobID")).InnerText;

            string strJobNo = ((HtmlGenericControl)gvr.FindControl("divJobNo")).InnerText;

            lblID.Text = strJobNo;

            DataTable dtFiles = getDataFiles(Session["JobID"].ToString());
            DataTable dtStaff = getDataStaff(Session["JobID"].ToString());

            gvFiles.DataSource = dtFiles;
            gvFiles.DataBind();

            gvStaff.DataSource = dtStaff;
            gvStaff.DataBind();

            gveBook.DataSource = getData_eBook(Session["JobID"].ToString());
            gveBook.DataBind();  

            DataTable dtDCComments = getDataDCComments(Session["JobID"].ToString());
            gvDCComments.DataSource = dtDCComments;
            gvDCComments.DataBind();

            DataTable dtSubmission = getDataSubmissions(Session["JobID"].ToString());
            gvSubmissionData.DataSource = dtSubmission;
            gvSubmissionData.DataBind();
        }
        catch
        {

        }
    }    
   
    private DataTable getData(string sp_Name)
    {
        string sqlQuery = string.Empty;
        if (sp_Name=="")
          sqlQuery = "select contract_id, project_no, project_title, contractor,project_manager from pwa_dc_contracts_master where project_no like 'C18%'";
        else
            sqlQuery = "select contract_id, project_no, project_title, contractor,project_manager from pwa_dc_contracts_master where project_no like '" + sp_Name+ "%'";

        using (OracleConnection objConn = new OracleConnection(connValueOracle))
        {
            OracleDataAdapter objAdapter = new OracleDataAdapter();
            OracleCommand objSelectCmd = new OracleCommand();
            objSelectCmd.Connection = objConn;
            objSelectCmd.CommandText = sqlQuery;
            objSelectCmd.CommandType = CommandType.Text;


            //if (txtReqID.Text == "")
            //    objSelectCmd.Parameters.Add("p_REQUEST_ID", OracleDbType.NVarchar2).Value = DBNull.Value;
            //else
            //    objSelectCmd.Parameters.Add("p_REQUEST_ID", OracleDbType.Int32).Value = txtReqID.Text;  

          //  objSelectCmd.Parameters.Add("o_cRefCursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

            objAdapter.SelectCommand = objSelectCmd;

            DataTable dtEmp = new DataTable();

            objAdapter.Fill(dtEmp);

            return dtEmp;
        }
    }
    private DataTable getDataFiles(string sp_Name)
    {
        string sqlQuery = "select pwa_dc_users.name,pwa_dc_files.ID,pwa_dc_files.name as FileName,pwa_dc_files.filesize, pwa_dc_files.url,pwa_dc_files.added_by,pwa_dc_files.tags,pwa_dc_files.FOLDER_ID from pwa_dc_files INNER JOIN pwa_dc_users ON pwa_dc_files.added_by = pwa_dc_users.user_id where pwa_dc_files.contract_id = " + sp_Name + "";

        
        using (OracleConnection objConn = new OracleConnection(connValueOracle))
        {
            OracleDataAdapter objAdapter = new OracleDataAdapter();
            OracleCommand objSelectCmd = new OracleCommand();
            objSelectCmd.Connection = objConn;
            objSelectCmd.CommandText = sqlQuery;
            objSelectCmd.CommandType = CommandType.Text;


            //if (txtReqID.Text == "")
            //    objSelectCmd.Parameters.Add("p_REQUEST_ID", OracleDbType.NVarchar2).Value = DBNull.Value;
            //else
            //    objSelectCmd.Parameters.Add("p_REQUEST_ID", OracleDbType.Int32).Value = txtReqID.Text;  

            //  objSelectCmd.Parameters.Add("o_cRefCursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

            objAdapter.SelectCommand = objSelectCmd;

            DataTable dtEmp = new DataTable();

            objAdapter.Fill(dtEmp);

            return dtEmp;
        }
    }

    private DataTable getDataStaff(string sp_Name)
    {
     //   string sqlQuery = "select pwa_dc_contracts_team.contract_id,pwa_dc_contracts_team.user_id,pwa_dc_users.name, pwa_dc_contracts_team.added_on, pwa_dc_contracts_team.est_start_date, " +
     //" pwa_dc_contracts_team.completed_on, pwa_dc_contracts_team.status_id, pwa_dc_contracts_team.remarks,pwa_dc_contracts_team.privilage_id,pwa_dc_user_privilage.privilage " +
     //     " from pwa_dc_contracts_team INNER JOIN pwa_dc_users ON pwa_dc_contracts_team.user_id = pwa_dc_users.user_id INNER JOIN pwa_dc_user_privilage ON pwa_dc_contracts_team.privilage_id = pwa_dc_user_privilage.privilage_id where pwa_dc_contracts_team.contract_id = " + sp_Name + "";

        string sqlQuery = "select pwa_dc_contracts_team.contract_id,pwa_dc_contracts_team.user_id,pwa_dc_users.name, pwa_dc_contracts_team.added_on, pwa_dc_contracts_team.est_start_date,  " +
      " pwa_dc_contracts_team.completed_on, pwa_dc_contracts_team.status_id, pwa_dc_contracts_team.remarks,pwa_dc_contracts_team.privilage_id,pwa_dc_user_privilage.privilage,PWA_DC_STATUS_LUT.status " +
          " from pwa_dc_contracts_team INNER JOIN pwa_dc_users ON pwa_dc_contracts_team.user_id = pwa_dc_users.user_id " +
          " INNER JOIN pwa_dc_user_privilage ON pwa_dc_contracts_team.privilage_id = pwa_dc_user_privilage.privilage_id INNER JOIN PWA_DC_STATUS_LUT ON pwa_dc_contracts_team.status_id = PWA_DC_STATUS_LUT.STATUS_ID where pwa_dc_contracts_team.contract_id = " + sp_Name + "";


      //  string sqlQuery = "select pwa_dc_contracts_team.contract_id,pwa_dc_contracts_team.user_id,pwa_dc_users.name, pwa_dc_contracts_team.added_on, pwa_dc_contracts_team.est_start_date, " +
      //" pwa_dc_contracts_team.completed_on, pwa_dc_contracts_team.status_id, pwa_dc_contracts_team.remarks,pwa_dc_contracts_team.privilage_id,pwa_dc_user_privilage.privilage,PWA_DC_STATUS_LUT.status ,pwa_dc_comments.comments " +
      //    " from pwa_dc_contracts_team INNER JOIN pwa_dc_users ON pwa_dc_contracts_team.user_id = pwa_dc_users.user_id INNER JOIN pwa_dc_user_privilage ON pwa_dc_contracts_team.privilage_id = pwa_dc_user_privilage.privilage_id INNER JOIN PWA_DC_STATUS_LUT " +
      //   " ON pwa_dc_contracts_team.status_id = PWA_DC_STATUS_LUT.STATUS_ID INNER JOIN pwa_dc_comments ON pwa_dc_contracts_team.user_id = pwa_dc_comments.user_id  where pwa_dc_contracts_team.contract_id =" + sp_Name + "";
                

        using (OracleConnection objConn = new OracleConnection(connValueOracle))
        {
            OracleDataAdapter objAdapter = new OracleDataAdapter();
            OracleCommand objSelectCmd = new OracleCommand();
            objSelectCmd.Connection = objConn;
            objSelectCmd.CommandText = sqlQuery;
            objSelectCmd.CommandType = CommandType.Text;


            //if (txtReqID.Text == "")
            //    objSelectCmd.Parameters.Add("p_REQUEST_ID", OracleDbType.NVarchar2).Value = DBNull.Value;
            //else
            //    objSelectCmd.Parameters.Add("p_REQUEST_ID", OracleDbType.Int32).Value = txtReqID.Text;  

            //  objSelectCmd.Parameters.Add("o_cRefCursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

            objAdapter.SelectCommand = objSelectCmd;

            DataTable dtEmp = new DataTable();

            objAdapter.Fill(dtEmp);

            return dtEmp;
        }
    }

    private DataTable getData_eBook(string sp_Name)
    {
        string sqlQuery = "SELECT  contract_no, contract_id, submission_no, staff_name, received_on, due_date, end_date,contract_type FROM pwa_dc_ebook_info where pwa_dc_ebook_info.contract_id = " + sp_Name + "";


        using (OracleConnection objConn = new OracleConnection(connValueOracle))
        {
            OracleDataAdapter objAdapter = new OracleDataAdapter();
            OracleCommand objSelectCmd = new OracleCommand();
            objSelectCmd.Connection = objConn;
            objSelectCmd.CommandText = sqlQuery;
            objSelectCmd.CommandType = CommandType.Text;


            //if (txtReqID.Text == "")
            //    objSelectCmd.Parameters.Add("p_REQUEST_ID", OracleDbType.NVarchar2).Value = DBNull.Value;
            //else
            //    objSelectCmd.Parameters.Add("p_REQUEST_ID", OracleDbType.Int32).Value = txtReqID.Text;  

            //  objSelectCmd.Parameters.Add("o_cRefCursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

            objAdapter.SelectCommand = objSelectCmd;

            DataTable dtEmp = new DataTable();

            objAdapter.Fill(dtEmp);

            return dtEmp;
        }
    }
    protected void drpListCat_SelectedIndexChanged(object sender, EventArgs e)
    {
        DataTable dt = getData(drpListCat.SelectedItem.Text);

        //DataTable dtFiles = getDataFiles("");

        //DataTable dtStaff = getDataStaff("");

        gvPerson.DataSource = dt;
        gvPerson.DataBind();
    }
    protected void btneBook_Click(object sender, EventArgs e)
    {
        //Response.Redirect("~/JobOrder/CostControlHomePage.aspx", false);
        //return;

        string jsonFilePath = Server.MapPath("~/JS/CTS.json");  // @"C:\MyFolder\myFile.json";

        string json = File.ReadAllText(jsonFilePath);
        Dictionary<string, object> json_Dictionary = (new JavaScriptSerializer()).Deserialize<Dictionary<string, object>>(json);

        var jObjs = (new JavaScriptSerializer()).Deserialize<IList<JsonCTSCls>>(json);       

        List<JsonCTSCls> results = null;
        results = new List<JsonCTSCls>();  

        //for (int i = 0; i < jObjs.Count; i++)
        //{
        //    // Does the object contain a "media_type" identifier - eg: "media_type":
        //    var token = jObjs[i].FindTokens("media_type");
        //    if (token != null && token.Count > 0)
        //    {
        //        // Only one is expected
        //        switch (token[0].ToString())
        //        {
        //            // "media_type": "tv"
        //            case "tv":
        //                results.Add(Convert<TV>(jObjs[i]));
        //                break;
        //            // "media_type": "movie"
        //            case "movie":
        //                results.Add(Convert<Movie>(jObjs[i]));
        //                break;
        //            // "media_type": "person"
        //            case "person":
        //                results.Add(Convert<Person>(jObjs[i]));
        //                break;
        //        }
        //    }
        //}


        foreach (var item in json_Dictionary)
        {
            // parse here

            string key = item.Key[1].ToString();

          // string key = item.Key.ToString();

           string Val = item.Value.ToString();
        }

        //return; 

        if (!Directory.Exists(Server.MapPath("~/eBook_Contracts/eBook/eBook/JS")))
        {
            Directory.CreateDirectory(Server.MapPath("~/eBook_Contracts/eBook/eBook/JS"));
            System.IO.File.WriteAllText(Server.MapPath("~/eBook_Contracts/eBook/eBook/JS/CTS.json"), null);
        }

        var jsonInstagramdata = new StreamReader(Server.MapPath("~/JS/CTS.json"));

         StreamReader reader = new StreamReader(Server.MapPath("~/JS/CTS.json"));
         while (true)
         {
            string line = reader.ReadLine();
            if (line == null)
            {
                break;
            }
            Console.WriteLine(line); // Use line.
         }

       //  ----------------------------------------------------------

         string jsonFilePath3 = Server.MapPath("~/JS/CTS.json");
         using (StreamReader r = new StreamReader(jsonFilePath3))
         {
             string jsonNew = r.ReadToEnd();
             JavaScriptSerializer jss = new JavaScriptSerializer();
             //var Items = jss.Deserialize<JSONClass>(jsonNew);

             List<JsonCTSCls> items = jss.Deserialize<List<JsonCTSCls>>(jsonNew);

             var json9 = jss.Serialize(Items);

             //Console.WriteLine(Items["url"]);
         }

         //  ----------------------------------------------------------

        var rawJsonData = jsonInstagramdata.ReadToEnd();
        jsonInstagramdata.Close();      

        

        //  ----------------------------------------------------------

        //var dtlData = JsonConvert.DeserializeObject<List<Instagram>>(rawJsonData); //Get List Of all Data Json File    
        //if (dtlData != null)
        //{
        //    ViewData["InstagramData"] = dtlData.ToList();
        //}    

    }
  
    private DataTable getDataSubmissions(string sp_Name)
    {
       // string sqlQuery = "SELECT contract_id, status_id, status_updated_by  FROM pwa_dc_submission_data where CONTRACT_ID in (" + sp_Name +",33402)";

        string sqlQuery = "SELECT contract_id, status_id, status_updated_by  FROM pwa_dc_submission_data where CONTRACT_ID in ((select contract_id from pwa_dc_contracts_master where parent_cid = " + sp_Name + ")," + sp_Name + ")";
        
        using (OracleConnection objConn = new OracleConnection(connValueOracle))
        {
            OracleDataAdapter objAdapter = new OracleDataAdapter();
            OracleCommand objSelectCmd = new OracleCommand();
            objSelectCmd.Connection = objConn;
            objSelectCmd.CommandText = sqlQuery;
            objSelectCmd.CommandType = CommandType.Text;

            objAdapter.SelectCommand = objSelectCmd;

            DataTable dtEmp = new DataTable();

            objAdapter.Fill(dtEmp);

            return dtEmp;
        }
    }
    private DataTable getDataDCComments(string sp_Name)
    {
        // string sqlQuery = "SELECT contract_id, status_id, status_updated_by  FROM pwa_dc_submission_data where CONTRACT_ID in (" + sp_Name +",33402)";


        string sqlQuery = "select * from pwa_dc_comments where contract_id = " + sp_Name + "";

        using (OracleConnection objConn = new OracleConnection(connValueOracle))
        {
            OracleDataAdapter objAdapter = new OracleDataAdapter();
            OracleCommand objSelectCmd = new OracleCommand();
            objSelectCmd.Connection = objConn;
            objSelectCmd.CommandText = sqlQuery;
            objSelectCmd.CommandType = CommandType.Text;

            objAdapter.SelectCommand = objSelectCmd;

            DataTable dtEmp = new DataTable();

            objAdapter.Fill(dtEmp);

            return dtEmp;
        }
    }

    //private DataTable geteBookData(DataTable dteBook)
    //{
    //    //foreach (var item in dteBook.Rows)
    //    //{
            
    //    //}

    //    //string sqlQuery = "SELECT contract_id, status_id, status_updated_by  FROM pwa_dc_submission_data where CONTRACT_ID in ((select contract_id from pwa_dc_contracts_master where parent_cid = " + sp_Name + ")," + sp_Name + ")";

    //    //using (OracleConnection objConn = new OracleConnection(connValueOracle))
    //    //{
    //    //    OracleDataAdapter objAdapter = new OracleDataAdapter();
    //    //    OracleCommand objSelectCmd = new OracleCommand();
    //    //    objSelectCmd.Connection = objConn;
    //    //    objSelectCmd.CommandText = sqlQuery;
    //    //    objSelectCmd.CommandType = CommandType.Text;

    //    //    objAdapter.SelectCommand = objSelectCmd;

    //    //    DataTable dtEmp = new DataTable();

    //    //    objAdapter.Fill(dtEmp);

    //    //    return dtEmp;
    //    //}

    //}

    protected void btn_Click(object sender, EventArgs e)
    {
        var json = Server.MapPath("~/eBook/js/CTS.json");

      //  Server.MapPath("~/eBook/JS/CTS.json");
    }
}