﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Globalization;
using Datalayer;

public partial class UserRigistration : System.Web.UI.Page
{
    string connValue = System.Configuration.ConfigurationManager.ConnectionStrings["EBSDEBookConn"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
           PopulateDropDownBox(ddlCmp, "SELECT companyID, cmpName FROM Company ORDER BY cmpName ", "companyID", "cmpName");    
    }
    // Function used Add and Update user Registration data
    private void AddUser(int contactID,string _computerName, string _computerUserName)
    {
        using (SqlConnection sqlConn = new SqlConnection(connValue))
        {
            using (SqlCommand sqlCmd = new SqlCommand())
            {
                try
                {
                    sqlCmd.Parameters.AddWithValue("@firstName", txtFirstName.Text.Trim());
                    sqlCmd.Parameters.AddWithValue("@lastName", txtLastName.Text.Trim());
                    sqlCmd.Parameters.AddWithValue("@middleName", System.DBNull.Value);

                    if (ddlCmp.SelectedValue !="")
                         sqlCmd.Parameters.AddWithValue("@companyID", ddlCmp.SelectedValue);
                    else
                        sqlCmd.Parameters.AddWithValue("@companyID", "362"); //PWA

                    sqlCmd.Parameters.AddWithValue("@officeAddress", txtOfficeAddress.Text.Trim());
                    sqlCmd.Parameters.AddWithValue("@officePhone", txtOffTelNo.Text.Trim());

                    sqlCmd.Parameters.AddWithValue("@mobPhone", txtMobilePhone.Text.Trim());
                    sqlCmd.Parameters.AddWithValue("@country", txtCountry.Text.Trim());
                    sqlCmd.Parameters.AddWithValue("@emailAddress", txtEmailId.Text.Trim());

                    sqlCmd.Parameters.AddWithValue("@userName", txtUserName.Text.Trim());
                    sqlCmd.Parameters.AddWithValue("@password", txtPassword.Text);

                    sqlCmd.Parameters.AddWithValue("@currentUser", txtUserName.Text.Trim());                 
                    sqlCmd.Parameters.AddWithValue("@jobPosition", txtJobTitle.Text.Trim());

                    if (ViewState["updsectionID"] != null)
                        sqlCmd.Parameters.AddWithValue("@sectionID", ViewState["updsectionID"]);
                    else
                        sqlCmd.Parameters.AddWithValue("@sectionID", 8); //guest user sectionId is not applicable = 8 

                    if (ViewState["updteamLeaderID"] != null)
                        sqlCmd.Parameters.AddWithValue("@teamLeaderID", ViewState["updteamLeaderID"]);
                    else
                        sqlCmd.Parameters.AddWithValue("@teamLeaderID", 6); //guest user teamLeadID is not applicable = 6 

                    if (ViewState["upduserProfileID"] != null)
                        sqlCmd.Parameters.AddWithValue("@userProfileID", ViewState["upduserProfileID"]);
                    else
                        sqlCmd.Parameters.AddWithValue("@userProfileID", 3); ////For New User ProfileID = 3 (guest) 

                    sqlCmd.Parameters.AddWithValue("@computerName", _computerName);
                    sqlCmd.Parameters.AddWithValue("@computerUserName", _computerUserName);
                    sqlCmd.Parameters.AddWithValue("@contactID", contactID);

                    sqlConn.Open();
                    sqlCmd.Connection = sqlConn;
                    sqlCmd.CommandType = CommandType.StoredProcedure;
                    sqlCmd.CommandText = "InsertUserRegistration";
                    sqlCmd.ExecuteNonQuery();
                }
                catch (Exception ex)
                {                        
                    throw ex;
                }                    
            }
        } 
    }
     DataTable _dtuserDataColl = new DataTable();
    
    // Function used to check whether user exist or not and Fill values 
    protected void txtEmailId_TextChanged(object sender, EventArgs e)
    {
        _dtuserDataColl = new JobOrderData().checkUserExist(txtEmailId.Text);
        if (_dtuserDataColl.Rows.Count > 0)
        {
            if (_dtuserDataColl.Rows[0]["userName"].ToString() == "")
            {
                txtFirstName.Text = _dtuserDataColl.Rows[0]["firstName"].ToString();
                txtLastName.Text = _dtuserDataColl.Rows[0]["lastName"].ToString();
                txtOfficeAddress.Text = _dtuserDataColl.Rows[0]["officeAddress"].ToString();
                txtMobilePhone.Text = _dtuserDataColl.Rows[0]["mobPhone"].ToString();
                txtJobTitle.Text = _dtuserDataColl.Rows[0]["jobPosition"].ToString();
                txtOffTelNo.Text = _dtuserDataColl.Rows[0]["officePhone"].ToString();

                ddlCmp.SelectedValue = _dtuserDataColl.Rows[0]["companyID"].ToString();

                //_userContactID = Convert.ToInt32(_dtuserDataColl.Rows[0]["contactID"]);
                //_userSectionID = Convert.ToInt32(_dtuserDataColl.Rows[0]["sectionID"]);
                //_userTeamID = Convert.ToInt32(_dtuserDataColl.Rows[0]["teamLeaderID"]);
                //_userProfileID = Convert.ToInt32(_dtuserDataColl.Rows[0]["userProfileID"]);

                ViewState["updcontactID"] = Convert.ToInt32(_dtuserDataColl.Rows[0]["contactID"]);
                ViewState["updsectionID"] = Convert.ToInt32(_dtuserDataColl.Rows[0]["sectionID"]);
                ViewState["updteamLeaderID"] = Convert.ToInt32(_dtuserDataColl.Rows[0]["teamLeaderID"]);

                ViewState["upduserProfileID"] = Convert.ToInt32(_dtuserDataColl.Rows[0]["userProfileID"]);

                lblContactID.Text = _dtuserDataColl.Rows[0]["contactID"].ToString();

                Response.Write(" User Profile ID " + ViewState["upduserProfileID"].ToString());

                enableControls();

                txtUserName.Focus();
            }
            else
            {
                txtEmailId.Focus();
                ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('This email address was already registered in the system. Please log in using your Username and Password.')</script>", false);
            }

            // txtUserName.Text = _dtuserDataColl.Rows[0]["userName"].ToString();
        }
        else
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Please double check entered Email address')</script>", false);
        }
        
    }   
    protected void lnkSignIN_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/LoginPage.aspx", false);
    }

    // Function enable the controls when emaail Address cross check   
    protected void btnRegister_Click1(object sender, EventArgs e)
    {
        try
        {
            string full_computername = System.Net.Dns.GetHostEntry(Request.ServerVariables["REMOTE_HOST"]).HostName; // FUll computer name
            string compname = System.Net.Dns.GetHostEntry(Request.ServerVariables["REMOTE_HOST"]).HostName.Split('.')[0]; // Computer name only

            string userName = string.Empty;

            userName = compname.Split('.')[0].Replace("-", "_").ToLower();

            //AddUser(_userContactID, compname, userName);

            if (lblContactID.Text != "")
                AddUser(Convert.ToInt32(lblContactID.Text), compname, userName);
            else
            {
                AddUser(0, compname, userName);        // If user not exist in contact table
            }

            if (ViewState["upduserProfileID"] != null)
               Response.Write(" User Profile ID After Save " + ViewState["upduserProfileID"].ToString());            

            Response.Redirect("~/LoginPage.aspx?RegUser =" + userName, false);   // For Registred User Auto dispaly in login userName 

        }
        catch (Exception ex)
        {
            Response.Write(ex.Message); 
            throw ex;
        }

        //Session["updcontactID"] = null;
        //Session["updsectionID"] = null;
        //Session["updteamLeaderID"] = null;
        //Session["upduserProfileID"] = null;
        
        //var ident = (System.Security.Principal.WindowsIdentity)HttpContext.Current.User.Identity;
        //if (!ident.IsAnonymous && ident.IsAuthenticated)
        //{
        //    userName = ident.Name;
        //    AddUser(_userContactID, compname, userName);
        //} 
      
        
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/LoginPage.aspx", false);
    }


    #region GenaralFunctions

    private void enableControls()
    {
        txtConfirmPassword.Disabled = false;
        txtCountry.Enabled = true;
        txtFirstName.Enabled = true;
        txtJobTitle.Enabled = true;
        txtLastName.Enabled = true;
        txtMobilePhone.Enabled = true;
        txtOfficeAddress.Enabled = true;
        txtOffTelNo.Enabled = true;
        txtPassword.Enabled = true;
        txtUserName.Enabled = true;
       // txtMobilePhone.Enabled = true;
    }
    private void PopulateDropDownBox(DropDownList ddlBox, string sqlQuery, string valueMember, string displayName)
    {
        DataTable table = new DataTable();
        try
        {
            using (SqlConnection sqlConn = new SqlConnection(connValue))
            {
                using (SqlDataAdapter da = new SqlDataAdapter(sqlQuery, sqlConn))
                {
                    sqlConn.Open();
                    da.Fill(table);
                }
            }
            ddlBox.DataSource = table;
            ddlBox.DataTextField = displayName;
            ddlBox.DataValueField = valueMember;
            ddlBox.SelectedIndex = -1;
            ddlBox.DataBind();
            ddlBox.Items.Insert(0, new ListItem(""));
        }
        catch (System.Exception ex)
        {
            throw ex;
        }
    }   
    #endregion
    protected void txtUserName_TextChanged(object sender, EventArgs e)
    {
        //if ((txtUserName.Text != "") & (lblContactID.Text!=""))
        //{
        //    if (new JobOrderData().checkUserNameExist(txtUserName.Text, Convert.ToInt32(lblContactID.Text)) != "")
        //    {
        //        ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('User Name already exist ')</script>", false);
        //        txtUserName.Text = "";
        //        txtUserName.Focus();
        //    }
        //    else
        //        txtPassword.Focus();
        //}       
    }
}