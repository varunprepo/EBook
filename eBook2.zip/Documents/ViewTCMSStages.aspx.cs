﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Documents_ViewTCMSStages : System.Web.UI.Page
{
    string tcmConn = System.Configuration.ConfigurationManager.ConnectionStrings["TCMSConn"].ConnectionString;  
    string eBookConn = System.Configuration.ConfigurationManager.ConnectionStrings["EBSDEBookConn"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {

            DAL dalObj = new DAL(tcmConn);
            DataTable dtStages = dalObj.GetDataFromDB("StagePTD", "SELECT REPLACE(CONVERT(nvarchar, ptd_receive_on, 106), ' ', '/') AS ReceivedOn, ptd_purpose As Purpose, " +
            "ptd_assign_qs As AssignedQS, REPLACE(CONVERT(nvarchar,ptd_sent_for_rev, 106), ' ', '/') As Review, ptd_qs_working_status As QSWorkingStatus, ptd_tendec_doc_cur_status As TenderDocumentCurrentStatus, " +
            "REPLACE(CONVERT(nvarchar,ptd_forwarded_to_dep, 106), ' ', '/') As ForwardedToEndUserDepartment, remarks As Remarks FROM TenderDatesInfo WHERE (stage_id = 1) AND (proj_id = " + HttpUtility.HtmlDecode(Request.QueryString["projectID"].ToString()) + ")");

            if (dtStages == null)
            {
                ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Error occurred while retrieving the information for Prepare Tender Document Stage')</script>", false);
            }
            else
            {
                gvPTD.DataSource = dtStages;
                gvPTD.DataBind();
            }

            //dtStages = dalObj.GetDataFromDB("StageTS", "SELECT REPLACE(CONVERT(nvarchar, ts_receive_on, 106), ' ', '/') AS ReceivedOn,ts_issue_handling As TsIssueHandledBy, REPLACE(CONVERT(nvarchar,ts_return_to_dept, 106), ' ', '/') As TsReturnToDept, " +
            //"REPLACE(CONVERT(nvarchar,ts_receive_from_dept, 106), ' ', '/') AS TsReceiveFromDept,REPLACE(CONVERT(nvarchar,ts_pr_advertise, 106), ' ', '/') AS TsPrAdvertise, REPLACE(CONVERT(nvarchar,ts_tender_invitation, 106), ' ', '/') AS TsTenderInvitation, REPLACE(CONVERT(nvarchar,ts_closing_s1, 106), ' ', '/') AS TsClosingS1" +
            //",REPLACE(CONVERT(nvarchar,ts_closing_s2, 106), ' ', '/') AS TsClosingS2,REPLACE(CONVERT(nvarchar,ts_modified_closing, 106), ' ', '/') AS TsModifiedClosingS1,REPLACE(CONVERT(nvarchar,ts_modified_closing_s2, 106), ' ', '/') AS TsModifiedClosingS2, remarks FROM TenderDatesInfo WHERE (proj_id = " + HttpUtility.HtmlDecode(Request.QueryString["projectID"].ToString()) + ") " +
            //"and (ts_tender_issue is null) AND (co_ID is NULL) and (stage_id = 2)");

            //dalObj = new DAL(eBookConn);
            //dtStages = dalObj.GetDataFromDB("EOIStage", "SELECT REPLACE(CONVERT(nvarchar,eoi_receiveon, 106), ' ', '/') AS ReceivedOn,eoi_issue_handledby AS IssueHandledBy,REPLACE(CONVERT(nvarchar,eoi_issue_date, 106), ' ', '/') AS TenderInvitation,REPLACE(CONVERT(nvarchar,eoi_receive_from_dept,106), ' ', '/') AS ReceiveFromDept,REPLACE(CONVERT(nvarchar,eoi_return_to_dept, 106), ' ', '/') AS ReturnToDept," +
            //"REPLACE(CONVERT(nvarchar,eoi_pr_advertise, 106), ' ', '/') AS PrAdvertise,REPLACE(CONVERT(nvarchar,eoi_closing_date, 106), ' ', '/') AS ClosingDate,REPLACE(CONVERT(nvarchar,eoi_closing_date_ext1, 106), ' ', '/') AS ClosingDateExt1,REPLACE(CONVERT(nvarchar,eoi_closing_date_ext2, 106), ' ', '/') AS ClosingDateExt2,REPLACE(CONVERT(nvarchar,eoi_closing_date_ext3, 106), ' ', '/') AS ClosingDateExt3," +
            //"REPLACE(CONVERT(nvarchar,eoi_closing_date_ext4, 106), ' ', '/') AS ClosingDateExt4,REPLACE(CONVERT(nvarchar,eoi_closing_date_ext5, 106), ' ', '/') AS ClosingDateExt5,REPLACE(CONVERT(nvarchar,modified_closing_date, 106), ' ', '/') AS ModifiedClosingDate,REPLACE(CONVERT(nvarchar,modified_closing_date_ext1, 106), ' ', '/') AS ModifiedClosingDateExt1,REPLACE(CONVERT(nvarchar,modified_closing_date_ext2, 106), ' ', '/') AS ModifiedClosingDateExt2," +
            //"REPLACE(CONVERT(nvarchar,modified_closing_date_ext3, 106), ' ', '/') AS ModifiedClosingDateExt3,REPLACE(CONVERT(nvarchar,modified_closing_date_ext4, 106), ' ', '/') AS ModifiedClosingDateExt4,REPLACE(CONVERT(nvarchar,modified_closing_date_ext5, 106), ' ', '/') AS ModifiedClosingDateExt5,Remark from Eoi_Tracking where stage_id=2 and proj_id="+ HttpUtility.HtmlDecode(Request.QueryString["projectID"].ToString()));
            dtStages = LoadEOIStages();
            if (dtStages == null)
            {
                ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Error occurred while retrieving the information for EOI Stage')</script>", false);
            }
            else
            {
                if (dtStages.Rows.Count == 0)
                {
                    btnOp.Text = "Save";
                }
                else
                {
                    btnOp.Text = "Update";
                    txtReceiveOn.Text = dtStages.Rows[0][0].ToString();
                    txtIssueHandler.Text = dtStages.Rows[0][1].ToString();
                    txtEoiReceiveFromDept.Text = dtStages.Rows[0][2].ToString();
                    txtEoiReturnToDept.Text = dtStages.Rows[0][3].ToString();
                    txtEoiPRAdvert.Text = dtStages.Rows[0][4].ToString();
                    txtEoiClosingDate.Text = dtStages.Rows[0][5].ToString();
                    txtEoiClosingDateExt1.Text = dtStages.Rows[0][6].ToString();
                    txtEoiClosingDateExt2.Text = dtStages.Rows[0][7].ToString();
                    txtEoiClosingDateExt3.Text = dtStages.Rows[0][8].ToString();
                    txtEoiClosingDateExt4.Text = dtStages.Rows[0][9].ToString();
                    txtEoiClosingDateExt5.Text = dtStages.Rows[0][10].ToString();
                    txtEoiModifiedClosingDate.Text = dtStages.Rows[0][11].ToString();
                    txtEoiModifiedClosingDateExt1.Text = dtStages.Rows[0][12].ToString();
                    txtEoiModifiedClosingDateExt2.Text = dtStages.Rows[0][13].ToString();
                    txtEoiModifiedClosingDateExt3.Text = dtStages.Rows[0][14].ToString();
                    txtEoiModifiedClosingDateExt4.Text = dtStages.Rows[0][15].ToString();
                    txtEoiModifiedClosingDateExt5.Text = dtStages.Rows[0][16].ToString();
                    txtRemarks.Text = dtStages.Rows[0][17].ToString();
                }
                
                gvEOIStage.DataSource = dtStages;
                gvEOIStage.DataBind();
            }

            //dalObj = new DAL(tcmConn);
            //dtStages = dalObj.GetDataFromDB("StageTEA", "SELECT REPLACE(CONVERT(nvarchar,eval_tender_opening, 106), ' ', '/') AS TenderOpeningEval, REPLACE(CONVERT(nvarchar,eval_tender_doc_receive_from_cd, 106), ' ', '/') AS TenderDocReceiveFromCdEval, REPLACE(CONVERT(nvarchar,eval_tech_sent1, 106), ' ', '/') AS TechSent1Eval, TPWD1,REPLACE(CONVERT(nvarchar,eval_tech_receive1, 106), ' ', '/') AS TechReceive1Eval, " +
            //"REPLACE(CONVERT(nvarchar,eval_com_sent1, 106), ' ', '/') AS FinancialSent1Eval,FPWD1, REPLACE(CONVERT(nvarchar,eval_com_receive1, 106), ' ', '/') AS FinancialReceive1Eval, REPLACE(CONVERT(nvarchar,eval_tech_sent2, 106), ' ', '/') AS TechSent2Eval,TPWD2,REPLACE(CONVERT(nvarchar,eval_tech_receive2, 106), ' ', '/') AS TechReceive2Eval,REPLACE(CONVERT(nvarchar,eval_com_sent2, 106), ' ', '/') AS FinancialSent2Eval,FPWD2,REPLACE(CONVERT(nvarchar,eval_com_receive2, 106), ' ', '/') AS FinancialReceive2Eval," +
            //"REPLACE(CONVERT(nvarchar,eval_tender_award_approval, 106), ' ', '/') As TenderAwardApprovalEval,tender_validity_ext1 as TenderValidityExt1,tender_validity_ext2 as TenderValidityExt2,tenderbond_validity_ext1 As TenderbondValidityExt1,tenderbond_validity_ext2 As TenderbondValidityExt2,eval_no_of_meetings As NoOfMeetingsEval,Remarks " +
            //" FROM TenderDatesInfo WHERE (proj_id = " + HttpUtility.HtmlDecode(Request.QueryString["projectID"].ToString()) + ") AND (stage_id = 3)");

            //if (dtStages == null)
            //{
            //    ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Error occurred while retrieving the information for Technical, Financial Evaluation & Award Stage')</script>", false);
            //}
            //else
            //{                
            //    gvTEA.DataSource = dtStages;
            //    gvTEA.DataBind();
            //}

            //dalObj = new DAL(tcmConn);
            //dtStages = dalObj.GetDataFromDB("StageCP1", "SELECT COMPANY.co_name, CONTRACTORS.ContractAmount, REPLACE(CONVERT(nvarchar,CONTRACTORS.cp_tender_award, 106), ' ', '/') AS TenderAward, CONTRACTORS.StaffInCharge, REPLACE(CONVERT(nvarchar,CONTRACTORS.cp_received_of_doc, 106), ' ', '/') AS ReceivedOfDoc, REPLACE(CONVERT(nvarchar,CONTRACTORS.cp_request_start_date, 106), ' ', '/') AS RequestStartDate, " +
            //"REPLACE(CONVERT(nvarchar,CONTRACTORS.cp_start_date_receive, 106), ' ', '/') AS StartDateReceive, REPLACE(CONVERT(nvarchar,CONTRACTORS.cp_notice_contractor_to_sign, 106), ' ', '/') AS NoticeContractorToSign, REPLACE(CONVERT(nvarchar,CONTRACTORS.cp_due_date_pb, 106), ' ', '/') AS DueDateToPub FROM CONTRACTORS INNER JOIN COMPANY ON CONTRACTORS.co_id = COMPANY.co_id WHERE (CONTRACTORS.proj_id = " + HttpUtility.HtmlDecode(Request.QueryString["projectID"].ToString()) +
            //" and CONTRACTORS.stage_Id = 4 and CONTRACTORS.cp_tender_award is Not Null)");

            //if (dtStages == null)
            //{
            //    ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Error occurred while retrieving the information for Contract Process 1st Table Stage')</script>", false);
            //}
            //else
            //{
            //    gvCP1.DataSource = dtStages;
            //    gvCP1.DataBind();
            //}

            //dalObj = new DAL(tcmConn);
            //dtStages = dalObj.GetDataFromDB("StageCP2", "SELECT COMPANY.co_name, REPLACE(CONVERT(nvarchar,CONTRACTORS.cp_contractor_sign, 106), ' ', '/') AS ContractorSign,REPLACE(CONVERT(nvarchar,CONTRACTORS.cp_sent_dep_sign, 106), ' ', '/') AS SentDepToSign, REPLACE(CONVERT(nvarchar,CONTRACTORS.cp_receive_dep_sent_prsd, 106), ' ', '/') AS ReceiveDepSentToPrsd,REPLACE(CONVERT(nvarchar,CONTRACTORS.cp_sent_fd_commit, 106), ' ', '/') AS SentToCommittee, " +
            //" REPLACE(CONVERT(nvarchar,CONTRACTORS.cp_receive_fd_commit, 106), ' ', '/') AS ReceiveFromCommittee, REPLACE(CONVERT(nvarchar,CONTRACTORS.cp_distribution, 106), ' ', '/') AS DistributionDate, CONTRACTORS.contract_no,CONTRACTORS.Remarks FROM CONTRACTORS INNER JOIN COMPANY ON CONTRACTORS.co_id = COMPANY.co_id WHERE (CONTRACTORS.proj_id = " + HttpUtility.HtmlDecode(Request.QueryString["projectID"].ToString()) +
            //" and CONTRACTORS.stage_Id = 4 and CONTRACTORS.cp_tender_award is Not Null)");

            //if (dtStages == null)
            //{
            //    ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Error occurred while retrieving the information for Contract Process 2nd Table Stage')</script>", false);
            //}
            //else
            //{
            //    gvCP2.DataSource = dtStages;
            //    gvCP2.DataBind();
            //}
        }
    }

    private DataTable LoadEOIStages()
    {
        DAL dalObj = new DAL(eBookConn);
        DataTable dtStages = dalObj.GetDataFromDB("EOIStage", "SELECT REPLACE(CONVERT(nvarchar,eoi_receiveon, 106), ' ', '/') AS ReceivedOn,eoi_issue_handledby AS IssueHandledBy,REPLACE(CONVERT(nvarchar,eoi_issue_date, 106), ' ', '/') AS TenderInvitation,REPLACE(CONVERT(nvarchar,eoi_receive_from_dept,106), ' ', '/') AS ReceiveFromDept,REPLACE(CONVERT(nvarchar,eoi_return_to_dept, 106), ' ', '/') AS ReturnToDept," +
        "REPLACE(CONVERT(nvarchar,eoi_pr_advertise, 106), ' ', '/') AS PrAdvertise,REPLACE(CONVERT(nvarchar,eoi_closing_date, 106), ' ', '/') AS ClosingDate,REPLACE(CONVERT(nvarchar,eoi_closing_date_ext1, 106), ' ', '/') AS ClosingDateExt1,REPLACE(CONVERT(nvarchar,eoi_closing_date_ext2, 106), ' ', '/') AS ClosingDateExt2,REPLACE(CONVERT(nvarchar,eoi_closing_date_ext3, 106), ' ', '/') AS ClosingDateExt3," +
        "REPLACE(CONVERT(nvarchar,eoi_closing_date_ext4, 106), ' ', '/') AS ClosingDateExt4,REPLACE(CONVERT(nvarchar,eoi_closing_date_ext5, 106), ' ', '/') AS ClosingDateExt5,REPLACE(CONVERT(nvarchar,modified_closing_date, 106), ' ', '/') AS ModifiedClosingDate,REPLACE(CONVERT(nvarchar,modified_closing_date_ext1, 106), ' ', '/') AS ModifiedClosingDateExt1,REPLACE(CONVERT(nvarchar,modified_closing_date_ext2, 106), ' ', '/') AS ModifiedClosingDateExt2," +
        "REPLACE(CONVERT(nvarchar,modified_closing_date_ext3, 106), ' ', '/') AS ModifiedClosingDateExt3,REPLACE(CONVERT(nvarchar,modified_closing_date_ext4, 106), ' ', '/') AS ModifiedClosingDateExt4,REPLACE(CONVERT(nvarchar,modified_closing_date_ext5, 106), ' ', '/') AS ModifiedClosingDateExt5,Remark from Eoi_Tracking where stage_id=2 and proj_id=" + HttpUtility.HtmlDecode(Request.QueryString["projectID"].ToString()));
        gvEOIStage.DataSource = dtStages;
        gvEOIStage.DataBind();
        return dtStages;
    }
    protected void btn_click(object sender, EventArgs e)
    {
        SqlConnection sqlConn = null;
        
        try
        {
            using (sqlConn = new SqlConnection(eBookConn))
            {
                sqlConn.Open();
                using (SqlCommand sqlComm = new SqlCommand())
                {
                    sqlComm.Connection = sqlConn;
                    sqlComm.CommandType = CommandType.StoredProcedure;
                    if (btnOp.Text == "Save")
                    {
                        sqlComm.CommandText = "EOIStageDataInsertOrUpdate";
                        sqlComm.Parameters.AddWithValue("@isInsert", 1);
                    }
                    else
                    {
                        sqlComm.CommandText = "EOIStageDataInsertOrUpdate";
                        sqlComm.Parameters.AddWithValue("@isInsert", 0);
                    }
                    sqlComm.Parameters.AddWithValue("@projId", HttpUtility.HtmlDecode(Request.QueryString["projectID"].ToString()));
                    if (txtReceiveOn.Text != "")
                    {                         
                        sqlComm.Parameters.AddWithValue("@eoiReceiveOn", txtReceiveOn.Text); //strDate = Convert.ToDateTime(strDate).ToString("MM/dd/yyyy", CultureInfo.InvariantCulture);                        
                    }
                    else
                    {
                        sqlComm.Parameters.AddWithValue("@eoiReceiveOn", DBNull.Value);
                    }
                    if (txtIssueHandler.Text != "")
                    {
                        sqlComm.Parameters.AddWithValue("@eoiIssueHandler", txtIssueHandler.Text);
                    }
                    else
                    {
                        sqlComm.Parameters.AddWithValue("@eoiIssueHandler", DBNull.Value);
                    }
                    if (txtEoiReceiveFromDept.Text != "")
                    {
                        sqlComm.Parameters.AddWithValue("@eoiReceiveFromDept", txtEoiReceiveFromDept.Text);
                    }
                    else
                    {
                        sqlComm.Parameters.AddWithValue("@eoiReceiveFromDept", DBNull.Value);
                    }
                    if (txtEoiReturnToDept.Text != "")
                    {
                        sqlComm.Parameters.AddWithValue("@eoiReturnToDept", txtEoiReturnToDept.Text);
                    }
                    else
                    {
                        sqlComm.Parameters.AddWithValue("@eoiReturnToDept", DBNull.Value);
                    }
                    if (txtEoiIssueDate.Text != "")
                    {
                        sqlComm.Parameters.AddWithValue("@eoiIssueDate", txtEoiIssueDate.Text);
                    }
                    else
                    {
                        sqlComm.Parameters.AddWithValue("@eoiIssueDate", DBNull.Value);
                    }
                    if (txtEoiClosingDate.Text != "")
                    {
                        sqlComm.Parameters.AddWithValue("@eoiClosingDate", txtEoiClosingDate.Text);
                    }
                    else
                    {
                        sqlComm.Parameters.AddWithValue("@eoiClosingDate", DBNull.Value);
                    }
                    if (txtEoiClosingDateExt1.Text != "")
                    {
                        sqlComm.Parameters.AddWithValue("@eoiClosingDateExt1", txtEoiClosingDateExt1.Text);
                    }
                    else
                    {
                        sqlComm.Parameters.AddWithValue("@eoiClosingDateExt1", DBNull.Value);
                    }
                    if (txtEoiClosingDateExt2.Text != "")
                    {
                        sqlComm.Parameters.AddWithValue("@eoiClosingDateExt2", txtEoiClosingDateExt2.Text);
                    }
                    else
                    {
                        sqlComm.Parameters.AddWithValue("@eoiClosingDateExt2", DBNull.Value);
                    }
                    if (txtEoiClosingDateExt2.Text != "")
                    {
                        sqlComm.Parameters.AddWithValue("@eoiClosingDateExt3", txtEoiClosingDateExt3.Text);
                    }
                    else
                    {
                        sqlComm.Parameters.AddWithValue("@eoiClosingDateExt3", DBNull.Value);
                    }
                    if (txtEoiClosingDateExt4.Text != "")
                    {
                        sqlComm.Parameters.AddWithValue("@eoiClosingDateExt4", txtEoiClosingDateExt4.Text);
                    }
                    else
                    {
                        sqlComm.Parameters.AddWithValue("@eoiClosingDateExt4", DBNull.Value);
                    }
                    if (txtEoiClosingDateExt5.Text != "")
                    {
                        sqlComm.Parameters.AddWithValue("@eoiClosingDateExt5", txtEoiClosingDateExt5.Text);
                    }
                    else
                    {
                        sqlComm.Parameters.AddWithValue("@eoiClosingDateExt5", DBNull.Value);
                    }
                    if (txtEoiModifiedClosingDate.Text != "")
                    {
                        sqlComm.Parameters.AddWithValue("@eoiModifiedClosingDate", txtEoiModifiedClosingDate.Text);
                    }
                    else
                    {
                        sqlComm.Parameters.AddWithValue("@eoiModifiedClosingDate", DBNull.Value);
                    }
                    if (txtEoiModifiedClosingDateExt1.Text != "")
                    {
                        sqlComm.Parameters.AddWithValue("@eoiModifiedClosingDateExt1", txtEoiModifiedClosingDateExt1.Text);
                    }
                    else
                    {
                        sqlComm.Parameters.AddWithValue("@eoiModifiedClosingDateExt1", DBNull.Value);
                    }
                    if (txtEoiModifiedClosingDateExt2.Text != "")
                    {
                        sqlComm.Parameters.AddWithValue("@eoiModifiedClosingDateExt2", txtEoiModifiedClosingDateExt2.Text);
                    }
                    else
                    {
                        sqlComm.Parameters.AddWithValue("@eoiModifiedClosingDateExt2", DBNull.Value);
                    }
                    if (txtEoiModifiedClosingDateExt3.Text != "")
                    {
                        sqlComm.Parameters.AddWithValue("@eoiModifiedClosingDateExt3", txtEoiModifiedClosingDateExt3.Text);
                    }
                    else
                    {
                        sqlComm.Parameters.AddWithValue("@eoiModifiedClosingDateExt3", DBNull.Value);
                    }
                    if (txtEoiModifiedClosingDateExt4.Text != "")
                    {
                        sqlComm.Parameters.AddWithValue("@eoiModifiedClosingDateExt4", txtEoiModifiedClosingDateExt4.Text);
                    }
                    else
                    {
                        sqlComm.Parameters.AddWithValue("@eoiModifiedClosingDateExt4", DBNull.Value);
                    }
                    if (txtEoiModifiedClosingDateExt5.Text != "")
                    {
                        sqlComm.Parameters.AddWithValue("@eoiModifiedClosingDateExt5", txtEoiModifiedClosingDateExt5.Text);
                    }
                    else
                    {
                        sqlComm.Parameters.AddWithValue("@eoiModifiedClosingDateExt5", DBNull.Value);
                    }
                    if (txtEoiPRAdvert.Text != "")
                    {
                        sqlComm.Parameters.AddWithValue("@eoiPrAdvertise", txtEoiPRAdvert.Text);
                    }
                    else
                    {
                        sqlComm.Parameters.AddWithValue("@eoiPrAdvertise", DBNull.Value);
                    }
                    if (txtRemarks.Text != "")
                    {
                        sqlComm.Parameters.AddWithValue("@eoiRemarks", txtRemarks.Text);
                    }
                    else
                    {
                        sqlComm.Parameters.AddWithValue("@eoiRemarks", DBNull.Value);
                    }
                    sqlComm.ExecuteNonQuery();
                    LoadEOIStages();
                }
            }
        }
        catch (Exception ex)
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Error occurred while inserting the information in the database')</script>", false);
        }
        finally
        {
            sqlConn.Close();
        }
    }
}