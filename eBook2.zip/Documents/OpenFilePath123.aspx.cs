﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Documents_OpenFilePath123 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        string queryString = "OpenFilePath123.aspx?path=" + System.Web.HttpUtility.UrlEncode(Session["Path"].ToString());


        string newWin =

            "window.open('" + queryString + "');";

        ClientScript.RegisterStartupScript

            (this.GetType(), "pop", newWin, true);
    }
}