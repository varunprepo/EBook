﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Datalayer;
using System.Data.SqlClient;
using System.Data;
using System.Globalization;
using System.Configuration;
using System.Collections;
using System.IO;
using System.Text;
using System.Web.UI.HtmlControls;
using System.Net;
using System.DirectoryServices;
public partial class Documents_DocumentDetailsWindow : System.Web.UI.Page, ICallbackEventHandler
{
    string eBookConn = System.Configuration.ConfigurationManager.ConnectionStrings["EBSDEBookConn"].ConnectionString;
    string connValueTCMS = System.Configuration.ConfigurationManager.ConnectionStrings["TCMSConn"].ConnectionString;

    // static int _docID = 0;

    // static int _docCatID = 0;

    //static string _flag = string.Empty;
    //static string replyToClose = string.Empty;

    int _docID = 0;
    int _docCatID = 0;

    string _jobID = null;
    string _flag = string.Empty;
    string replyToClose = string.Empty;

    int _currentUserID = 0;
    string _userName = string.Empty;

    IList<string> userRightsColl = null; int _profileID = 0;

    static ArrayList docrowList = new ArrayList();
    static DataTable dtDistrUserExist = new DataTable();

    string opMsg = null;
    public string GetCallbackResult()
    {
        return opMsg;
    }

    static string emailID = null;
    static string deptCoordID = null;
    public void RaiseCallbackEvent(string eventArgument)
    {
        eventArgument  = HttpUtility.HtmlDecode(eventArgument);
        if (eventArgument != "")
        {
            //if (uCls == null)
            //    uCls = new UtilityClass(this.Page);
            //if (eventArgument.Split(',')[1].ToString().Contains("txtDaysToAct"))
            //{
            try
            {
                string empName = GetUserInfoFromActiveDirectory(eventArgument);
                if (empName == null)
                {
                    opMsg = "";
                }
                else
                {
                    SqlConnection sqlConn = null;
                    try
                    {
                        using (sqlConn = new SqlConnection(eBookConn))
                        {
                            sqlConn.Open();
                            string sqlQuery = "SELECT contactID from Contact WHERE (emailAddress = '" + eventArgument + "')";
                            SqlCommand sqlCom = new SqlCommand(sqlQuery, sqlConn);
                            SqlDataReader sqlReader = sqlCom.ExecuteReader();
                            if (!sqlReader.HasRows)
                            {                                
                                opMsg = "No";
                            }                       
                            else
                            {
                                sqlReader.Read();
                                deptCoordID = sqlReader["contactID"].ToString();
                                emailID = eventArgument;
                            }
                            sqlReader.Close();
                        }
                    }
                    catch (Exception)
                    {
                        opMsg = "Error";
                    }

                }
            }
            catch (Exception ex)
            {
                //opMsg = "Error Occurred while checking the emailID";
                opMsg = "Not able to find the emailID. Please again enter the correct emailID.";
            }

        }
        //throw new NotImplementedException();
    }
    protected void WireUpJSFunctions()
    {
        ClientScriptManager csm = Page.ClientScript;
        string callbackRef = csm.GetCallbackEventReference(this, "arg", "getInfo", "context");
        string callbackScript = "function findEmailID(arg, context) {" + callbackRef + "}";
        csm.RegisterClientScriptBlock(this.GetType(), "findEmailID", callbackScript, true);        
    }

    private string GetUserInfoFromActiveDirectory(string emailID)
    {
        string empName = null;
        DirectoryEntry directoryEntry = new DirectoryEntry("LDAP://RootDSE");
        DirectoryEntry searchRoot = new DirectoryEntry("LDAP://" + directoryEntry.Properties["defaultNamingContext"].Value.ToString(), null, null, AuthenticationTypes.Secure);
        string filter = string.Format("(&(ObjectClass={0})(mail={1}))", "top", emailID);
        SearchResult searchResult = new DirectorySearcher(searchRoot)
        {
            Filter = filter
        }.FindOne();
        DirectoryEntry directoryEntry2 = searchResult.GetDirectoryEntry();
        if (directoryEntry2.Properties["cn"] != null)
        {
            if (directoryEntry2.Properties["cn"][0] != null)
            {
                empName = directoryEntry2.Properties["cn"][0].ToString().Trim();
            }
        }
        return empName;
    }
    protected void Page_Load(object sender, EventArgs e)
    {
        pageInitDataLoad();

        if (Session["UserName"] == null)
        {
            Response.Redirect("~/LoginPage.aspx", false);
            return;
        }

        if (Session["SectionID"].ToString() != "13")
        {
            emailIDLblRow.Visible = false;
            emailIDTxtRow.Visible = false;
            radioBtns.Visible = false;
            //reqdeptCoordEmailID.Visible = false;
        }
        else
        {
            if (Session["JobID"] != null)
            {
                //string sqlQuery = "select Document.documentID from Document JOIN Job on Job.jobID=Document.jobID where Document.jobID=" + Session["JobID"] + " and Job.closedDocRefID is not Null and Document.documentID=" + Request.QueryString["docRecID"];
                string sqlQuery = null;
                if (Request.QueryString["docRecID"] != null)
                {
                    sqlQuery = "select documentID from Document where jobID=" + Session["JobID"] + " and isDocForClosing=1 and documentID=" + Request.QueryString["docRecID"];
                }
                else
                {
                    sqlQuery = "select documentID from Document where jobID=" + Session["JobID"] + " and isDocForClosing=1";
                }
                DataTable dtDocumentCloseDate = GetDataFromDB("DocumentCloseDate", sqlQuery);
                if (dtDocumentCloseDate.Rows.Count >= 1)
                {
                    emailIDLblRow.Visible = false;
                    emailIDLblRow.Style.Add("visibility", "hidden");
                    dptCoordEmailIDAst.Style.Add("visibility", "hidden");
                    emailIDTxtRow.Visible = false;
                    emailIDTxtRow.Style.Add("visibility", "hidden");
                    eoiRdb.Visible = false;
                    lblEoi.Visible = false;
                    preQualRdb.Visible = false;
                    lblPreQual.Visible = false;
                    deptCordEmailID.Text = "";
                    ViewState["replyToClose"] = "1";
                }

                DataSet ds = (new JobOrderData().FillDocAttributeDataByJobID(Convert.ToInt32(Session["JobID"].ToString().Trim()), 0));
                if (ds.Tables[0].Rows.Count != 0)
                {
                    FillDocRelatedTasks(Convert.ToInt32(ds.Tables[0].Rows[0][1]), _currentUserID);
                }
                
            }
            else
            {
                if (Session["jobTypeID"] != null)
                {
                    if (Session["jobTypeID"].ToString() == "114") //Pre Qual Document Finalization
                    {
                        emailIDLblRow.Visible = true;
                        emailIDTxtRow.Visible = true;
                        eoiRdb.Visible = false;
                        eoiRdb.Style.Add("visibility", "hidden");
                        lblEoi.Visible = false;
                        preQualRdb.Visible = true;
                        lblPreQual.Visible = true;                         
                    }
                    else
                    {
                        eoiRdb.Visible = true;
                        lblEoi.Visible = true;
                        dateRecAst.Visible = false;
                        preQualRdb.Visible = false;
                        preQualRdb.Style.Add("visibility", "hidden");
                        lblPreQual.Visible = false;
                        emailIDLblRow.Visible = true;
                        emailIDTxtRow.Visible = true;
                    }
                }
            }
            WireUpJSFunctions();
            ddlContractNo.Visible = false;
            ddlTenderNo.Visible = false;
            prjAttributes.InnerText = "Project Attribute";
        }
        Label2.Text = "Rights : - " + userRightsColl.Count.ToString();
        lblCatID.Text = "CatID - : - " + _docCatID.ToString();
        Session["DocCatID"] = _docCatID.ToString();
        setCreateJobBtnVisibility();

        if (Session["personOnLeave"] != null)
            lblLeave.Text = Session["personOnLeave"].ToString();

        //if (hdnprojectID.Value != "")
        //{
        //    DAL dalObj = new DAL(System.Configuration.ConfigurationManager.ConnectionStrings["TCMSConn"].ConnectionString);
        //    DataTable dtStages = dalObj.GetDataFromDB("StagePTD", "SELECT REPLACE(CONVERT(nvarchar, ptd_receive_on, 106), ' ', '/') AS ReceivedOn, ptd_purpose As Purpose, " +
        //    "ptd_assign_qs As AssignedQS, REPLACE(CONVERT(nvarchar,ptd_sent_for_rev, 106), ' ', '/') As Review, ptd_qs_working_status As QSWorkingStatus, ptd_tendec_doc_cur_status As TenderDocumentCurrentStatus, " +
        //    "REPLACE(CONVERT(nvarchar,ptd_forwarded_to_dep, 106), ' ', '/') As ForwardedToEndUserDepartment, remarks As Remarks FROM TenderDatesInfo WHERE (stage_id = 1) AND (proj_id = " + hdnprojectID.Value + ")");

        //    if (dtStages == null)
        //    {
        //        ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Error occurred while retrieving the information for Prepare Tender Document Stage')</script>", false);
        //    }
        //    else
        //    {
        //        gvPTD.DataSource = dtStages;
        //        gvPTD.DataBind();
        //    }

        //    //dtStages = dalObj.GetDataFromDB("StageTS", "SELECT REPLACE(CONVERT(nvarchar, ts_receive_on, 106), ' ', '/') AS ReceivedOn,ts_issue_handling As TsIssueHandledBy, REPLACE(CONVERT(nvarchar,ts_return_to_dept, 106), ' ', '/') As TsReturnToDept, " +
        //    //"REPLACE(CONVERT(nvarchar,ts_receive_from_dept, 106), ' ', '/') AS TsReceiveFromDept,REPLACE(CONVERT(nvarchar,ts_pr_advertise, 106), ' ', '/') AS TsPrAdvertise, REPLACE(CONVERT(nvarchar,ts_tender_invitation, 106), ' ', '/') AS TsTenderInvitation, REPLACE(CONVERT(nvarchar,ts_closing_s1, 106), ' ', '/') AS TsClosingS1" +
        //    //",REPLACE(CONVERT(nvarchar,ts_closing_s2, 106), ' ', '/') AS TsClosingS2,REPLACE(CONVERT(nvarchar,ts_modified_closing, 106), ' ', '/') AS TsModifiedClosingS1,REPLACE(CONVERT(nvarchar,ts_modified_closing_s2, 106), ' ', '/') AS TsModifiedClosingS2, remarks FROM TenderDatesInfo WHERE (proj_id = " + HttpUtility.HtmlDecode(Request.QueryString["projectID"].ToString()) + ") " +
        //    //"and (ts_tender_issue is null) AND (co_ID is NULL) and (stage_id = 2)");

        //    //dalObj = new DAL(eBookConn);
        //    //dtStages = dalObj.GetDataFromDB("EOIStage", "SELECT REPLACE(CONVERT(nvarchar,eoi_receiveon, 106), ' ', '/') AS ReceivedOn,eoi_issue_handledby AS IssueHandledBy,REPLACE(CONVERT(nvarchar,eoi_issue_date, 106), ' ', '/') AS TenderInvitation,REPLACE(CONVERT(nvarchar,eoi_receive_from_dept,106), ' ', '/') AS ReceiveFromDept,REPLACE(CONVERT(nvarchar,eoi_return_to_dept, 106), ' ', '/') AS ReturnToDept," +
        //    //"REPLACE(CONVERT(nvarchar,eoi_pr_advertise, 106), ' ', '/') AS PrAdvertise,REPLACE(CONVERT(nvarchar,eoi_closing_date, 106), ' ', '/') AS ClosingDate,REPLACE(CONVERT(nvarchar,eoi_closing_date_ext1, 106), ' ', '/') AS ClosingDateExt1,REPLACE(CONVERT(nvarchar,eoi_closing_date_ext2, 106), ' ', '/') AS ClosingDateExt2,REPLACE(CONVERT(nvarchar,eoi_closing_date_ext3, 106), ' ', '/') AS ClosingDateExt3," +
        //    //"REPLACE(CONVERT(nvarchar,eoi_closing_date_ext4, 106), ' ', '/') AS ClosingDateExt4,REPLACE(CONVERT(nvarchar,eoi_closing_date_ext5, 106), ' ', '/') AS ClosingDateExt5,REPLACE(CONVERT(nvarchar,modified_closing_date, 106), ' ', '/') AS ModifiedClosingDate,REPLACE(CONVERT(nvarchar,modified_closing_date_ext1, 106), ' ', '/') AS ModifiedClosingDateExt1,REPLACE(CONVERT(nvarchar,modified_closing_date_ext2, 106), ' ', '/') AS ModifiedClosingDateExt2," +
        //    //"REPLACE(CONVERT(nvarchar,modified_closing_date_ext3, 106), ' ', '/') AS ModifiedClosingDateExt3,REPLACE(CONVERT(nvarchar,modified_closing_date_ext4, 106), ' ', '/') AS ModifiedClosingDateExt4,REPLACE(CONVERT(nvarchar,modified_closing_date_ext5, 106), ' ', '/') AS ModifiedClosingDateExt5,Remark from Eoi_Tracking where stage_id=2 and proj_id="+ HttpUtility.HtmlDecode(Request.QueryString["projectID"].ToString()));
        //    dtStages = LoadEOIStages();
        //    if (dtStages == null)
        //    {
        //        ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Error occurred while retrieving the information for EOI Stage')</script>", false);
        //    }
        //    else
        //    {
        //        if (dtStages.Rows.Count == 0)
        //        {
        //            btnOp.Text = "Save";
        //        }
        //        else
        //        {
        //            btnOp.Text = "Update";
        //            txtReceiveOn.Text = dtStages.Rows[0][0].ToString();
        //            txtIssueHandler.Text = dtStages.Rows[0][1].ToString();
        //            txtEoiReceiveFromDept.Text = dtStages.Rows[0][2].ToString();
        //            txtEoiReturnToDept.Text = dtStages.Rows[0][3].ToString();
        //            txtEoiPRAdvert.Text = dtStages.Rows[0][4].ToString();
        //            txtEoiClosingDate.Text = dtStages.Rows[0][5].ToString();
        //            txtEoiClosingDateExt1.Text = dtStages.Rows[0][6].ToString();
        //            txtEoiClosingDateExt2.Text = dtStages.Rows[0][7].ToString();
        //            txtEoiClosingDateExt3.Text = dtStages.Rows[0][8].ToString();
        //            txtEoiClosingDateExt4.Text = dtStages.Rows[0][9].ToString();
        //            txtEoiClosingDateExt5.Text = dtStages.Rows[0][10].ToString();
        //            txtEoiModifiedClosingDate.Text = dtStages.Rows[0][11].ToString();
        //            txtEoiModifiedClosingDateExt1.Text = dtStages.Rows[0][12].ToString();
        //            txtEoiModifiedClosingDateExt2.Text = dtStages.Rows[0][13].ToString();
        //            txtEoiModifiedClosingDateExt3.Text = dtStages.Rows[0][14].ToString();
        //            txtEoiModifiedClosingDateExt4.Text = dtStages.Rows[0][15].ToString();
        //            txtEoiModifiedClosingDateExt5.Text = dtStages.Rows[0][16].ToString();
        //            txtRemarks.Text = dtStages.Rows[0][17].ToString();
        //        }

        //        gvEOIStage.DataSource = dtStages;
        //        gvEOIStage.DataBind();
        //    }
        //}

        if (Session["JobID"] != null)
        {
            lblJobID.Text = Session["JobID"].ToString().Trim();
            //setFileAttachmentLinksVisibility(true);
            //lblSessionJob.Text = "Session Job ID : - " + Session["JobID"].ToString();
        }

        if (!IsPostBack)
        {
            
            lblDocID.Text = _docID.ToString();

            Session["distribDocID"] = null;           // it should kill for button click on rec/Sent new from job or payment details ------ ist comming from disribution document
            FillDropdownData();

            if (_docID == 0)
            {
                //btnSave.Enabled = false;
                btnDelete.Visible = false;
                tdDivSuperseded.Visible = false;
                btnDistribute.Enabled = false;

                ddlProjectID.Enabled = false;
                ddlTenderNo.Enabled = false;
                ddlContractNo.Enabled = false;
                btnAddDbs.Enabled = false;

                txtPopupDatepicker.Text = System.DateTime.Now.ToString("dd/MMM/yyyy");
                txtDateReceived.Text = System.DateTime.Now.ToString("dd/MMM/yyyy");

                if (_docCatID == 2)
                {
                    ddlOriginSender.SelectedValue = _currentUserID.ToString() + "," + Session["CmpID"].ToString();  
                    ddlCompany.SelectedValue = Session["CmpID"].ToString(); 
                }
            }
            else
            {
                btnDelete.Visible = true;
                btnDistribute.Enabled = true;
                lnkAttachments.Enabled = true;
                lnkFile.Enabled = true;
                ImageButton1.Enabled = true;
                ImageButton2.Enabled = true;
                CheckAttachments(_docID);
                setFileAttachmentLinksVisibility(true);
            }

            if (_docCatID == 2)
            {
                txtDateReceived.Visible = false;
                lblRecDate.Visible = false;
                txtPopupDatepicker.Width = 250;
            }
             
            //if (Session["docSender"] != null)
            //    ddlOriginSender.SelectedValue = Session["docSender"].ToString();
            //if (Session["docOrginCmpID"] != null)
            //    ddlCompany.SelectedValue = Session["docOrginCmpID"].ToString(); // +"," + Session["CmpShortName"].ToString();


            // ============================================================================================================



            trDocCreated.Visible = false;

            if (_docID != 0)
            {
                FillAllDocumentData();
                DistributionGridView();
                FillDocRelatedTasks(_docID, _currentUserID);
                if (lnkJobNo.ToolTip != "")
                {
                    DataSet ds = new JobOrderData().FillDocAttributeDataByJobID(Convert.ToInt32(lnkJobNo.ToolTip.Trim()), 0);
                    gvDocProjAttributes.DataSource = ds;
                    gvDocProjAttributes.DataBind();
                }
             
            }

            if (_docID == 0 & Session["distribDocID"] != null)
            {
                _docID = Convert.ToInt32(Session["distribDocID"]);
                Session["distribDocID"] = null;
            }

            // ============================================================================================================

            // check enable for btnDelete last execution

            if (Session["JobID"] != null)
            {
                if (Session["JobID"].ToString() != "")
                {
                    if (CheckOpenClosedDocExistForJob(Convert.ToInt32(Session["JobID"])))
                    {
                        btnDelete.Enabled = false;
                    }

                    btnDelete.BackColor = System.Drawing.Color.WhiteSmoke;
                }
            }

            int _distribID = 0;
            if (_docID != 0)
            {
                if (checkUserExistDateRead(ref _distribID))
                    new JobOrderData().UpdateDistributionDateRead(_distribID, _currentUserID);
            }

            trDocCreated.Visible = false;

            // testCode();

        }

        if (lblDocID.Text != "")
            _docID = Convert.ToInt32(lblDocID.Text);

        if (_docID != 0)
            btnCreateDoc.Text = "Update Document";

        else

            btnCreateDoc.Text = "Create Document";


        // For Non EBD Doc Type Session

        if (Session["docType"] != null)
            ddlTypeOfDocs.SelectedValue = Session["docType"].ToString();

        trlbl.Visible = false;
                
        // ddlMajorDBSValues.Enabled = false;

        // zfile:///C:/Doc_In/C2010-92/151069

        // zfile:///C:/Doc_In/C2010-92/151069
    }
    private void setFileAttachmentLinksVisibility(bool isVisible)
    {
        lnkFile.Visible = isVisible;
        lnkAttachments.Visible = isVisible;
        ImageButton1.Visible = isVisible;
        lblCover.Visible = isVisible;
        ImageButton2.Visible = isVisible;
        lblAttch.Visible = isVisible;
    }
    private void setCreateJobBtnVisibility()
    {
        if (ViewState["replyToClose"] != null)
        {
            //lblRply.Text = " rplyCls " + ViewState["replyToClose"].ToString();
            btnCreateJob.Visible = false;
            emailIDLblRow.Visible = false;
            //tdDeptCoordEmailID.Visible = false;
            emailIDTxtRow.Visible = false;
            radioBtns.Visible = false;
            if (Session["referenceNo"] != null)
                txtRplyDoc.Text = Session["referenceNo"].ToString();
        }
        else
        {
            if (lblJobID.Text.Trim() == "")
            {
                btnCreateJob.Visible = true;
            }
            else
            {
                btnCreateJob.Visible = false;
            }
            //lblRply.Text = " rplyCls = NULL";
            txtRplyDoc.Text = "";
        }
    }
     

    private void CheckAttachments(int chkdocID)
    {
        int fileCnt = 0;
        fileCnt = coverLetterExist(chkdocID);

        if (fileCnt == 0)
            ImageButton1.Visible = false;
        else
        {
            ImageButton1.Visible = true;
            lblCover.Text = "( " + fileCnt + " )";
        }

        int attCnt = 0;

        attCnt = fileAttachmentsExist(chkdocID);
        if (attCnt == 0)
            ImageButton2.Visible = false;
        else
        {
            ImageButton2.Visible = true;
            lblAttch.Text = "( " + attCnt + " )";
        }
    }

    private void pageInitDataLoad()
    {
        if (Session["UserName"] == null)
        {
            Response.Redirect("~/LoginPage.aspx", false);
            return;
        }

        // =============================================================================================================================

        //_docID = 0;
        //_docCatID = 0;

        _currentUserID = Convert.ToInt32(Session["UserID"]);
        userRightsColl = (IList<string>)Session["UserRightsColl"];
        _profileID = Convert.ToInt32(Session["UserProfileID"]);
        _userName = Session["UserName"].ToString();


        // --------------------------------------------------------------------------------------------------------------------------------------

        if (ViewState["replyToClose"] == null)
            ViewState["replyToClose"] = Request.QueryString["Reply"];

        if (_docID == 0)
            _docID = Convert.ToInt32(Request.QueryString["docRecID"]); //docRecID 

        //if (_docID == 0)
        //    _docID = Convert.ToInt32(Request.QueryString["PaydocRecID"]);   

        if (_docCatID == 0)
            _docCatID = Convert.ToInt32(Request.QueryString["RecSentCatID"]); //ReceiveAndSent Document Page of Receive/Upload Grid link    


        //  ======================================================== ==========================================================================                     

        if (_docID == 0)
            _docID = Convert.ToInt32(Session["SearchDocID"]);               //  From Search Document Page

        if (_docCatID == 0)
            _docCatID = Convert.ToInt32(Session["SearchDocCatID"]);         //  From Search Document Page

        if (Request.QueryString["Flag"] == null)
            ViewState["_flag"] = "0";     // not from reply to close
        else
            ViewState["_flag"] = Request.QueryString["Flag"]; //  from reply to close

        //   ===================================================================================================================================    

        if (!IsPostBack)
        {
            if (_docID == 0 & lblDocID.Text != "")
                _docID = Convert.ToInt32(lblDocID.Text);

            if (_docID == 0 & Session["distribDocID"] != null)       // Document Distribution Page 
                _docID = Convert.ToInt32(Session["distribDocID"]);

            if (Session["SectionID"].ToString().Equals("13"))
            {
                btnDistribute.Visible = false;
            }

            //if(_docID!=0)
            //{
            //    if (CheckDocLinkedWithJob(_docID))
            //    {
            //        btnCreateJob.Visible = false;
            //    }                 
            //}
        }

        //  ============================================================================================================================================= 

        if (lblDocID.Text == "")
            lblDocID.Text = _docID.ToString();

    }
    private void DistributionGridView()
    {
        try
        {
            if (Session["docCreatedByID"] != null && Session["originContactID"] != null)
            {
                if (_docID != 0)
                {
                    _docID = Convert.ToInt32(lblDocID.Text);
                    dtDistrUserExist = fillDataDistribution(_docID);
                    if (dtDistrUserExist.Rows.Count > 0)
                    {
                        DataRow[] rows = dtDistrUserExist.Select("contactID = " + _currentUserID);

                        if ((rows.Count() == 0) & (_docID != 0))
                        {
                            if (_profileID.Equals(1) || Session["docCreatedByID"].Equals(_currentUserID.ToString()) || Session["originContactID"].Equals(_currentUserID.ToString()))
                            {
                                EnableControlsStatusForNonDistribution();
                                chkSuperseded.Visible = true;
                                tdSuper.Visible = true;
                                tdDivSuperseded.Visible = true;
                            }
                            else
                            {
                                DisableControlsStatusForNonDistribution();
                                chkSuperseded.Visible = false;
                                tdSuper.Visible = false;
                                tdDivSuperseded.Visible = false;
                            }
                        }
                        else
                            EnableControlsStatusForNonDistribution();
                    }
                }
                else
                    EnableControlsStatusForNonDistribution();
            }
        }
        catch (Exception)
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Error occurred while filling the document distribution data')</script>", false);            
        }
        
    }
    private void FillAllDocumentData()
    {
        fillDocumentData(_docID);
        gridloadForProjectAttributeData(0);
        gridloadForDBSValues();
        checkOpenCloseDocumentInJob(_docID);

    }
    private Boolean checkUserExistDateRead(ref int _disribID)
    {
        string prjTitle = string.Empty;

        using (SqlConnection cnn = new SqlConnection(eBookConn))
        {
            cnn.Open();
            using (SqlCommand cmm = new SqlCommand())
            {
                cmm.Connection = cnn;
                cmm.CommandText = "SELECT contactID,distributeID  FROM DocumentDistribution WHERE dateread is null and documentID = " + _docID + " and  contactID  = '" + _currentUserID + "' ";
                using (SqlDataReader sqlDtReader = cmm.ExecuteReader())
                {
                    if (sqlDtReader.HasRows)
                    {
                        while (sqlDtReader.Read())
                        {
                            _disribID = Convert.ToInt32(sqlDtReader["distributeID"].ToString());
                            return true;
                        }
                    }
                }
            }
        }
        return false;
    }
    protected void lnkJobNo_Click(object sender, EventArgs e)
    {
        try
        {
            LinkButton lnkJobID = (LinkButton)sender;
            GridViewRow gvr = (GridViewRow)lnkJobID.NamingContainer;

            Session["JobID"] = ((HtmlGenericControl)gvr.FindControl("divLnkJobID")).InnerText;
            Session["JobInchargeID"] = lnkJobID.ToolTip;

            Session["JobCatID"] = ((HtmlGenericControl)gvr.FindControl("divJoCatbID")).InnerText;

            if (((HtmlGenericControl)gvr.FindControl("divJoCatbID")).InnerText != "1")
            {
                Session["UrlRef"] = "~/JobOrder/DefaultGrid.aspx";
                Response.Redirect("~/JobOrder/DefaultGrid.aspx?JobID= " + Session["JobID"] + "", false);
            }
            else
            {
                Session["UrlRef"] = "~/JobOrder/PSAJobDetails.aspx";
                Response.Redirect("~/JobOrder/PSAJobDetails.aspx?JobID= " + Session["JobID"] + "", false);
            }
        }
        catch (Exception ex)
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Error occurred while processing the request')</script>", false);
        }
    }
    private void DisableControlsStatusForNonDistribution()
    {

        btnDistribute.Enabled = false;
        // btnSave.Enabled = false;
        btnDelete.Enabled = false;
        btnDelete.BackColor = System.Drawing.Color.WhiteSmoke;
        btnAddProjAttrib.Enabled = false;
        btnAddDbs.Enabled = false;


        ddlContractNo.Enabled = false;
        ddlProjectID.Enabled = false;
        ddlTenderNo.Enabled = false;

        ddlDetailedDBSValues.Enabled = false;
        ddlMajorDBSValues.Enabled = false;

        txtPopupDatepicker.Enabled = false;
        txtDateReceived.Enabled = false;
    }
    private void EnableControlsStatusForNonDistribution()
    {

        btnDistribute.Enabled = true;
        //btnSave.Enabled = true;
        btnDelete.Enabled = true;
        btnAddProjAttrib.Enabled = true;
        btnAddDbs.Enabled = true;


        ddlContractNo.Enabled = true;
        ddlProjectID.Enabled = true;
        ddlTenderNo.Enabled = true;

        ddlDetailedDBSValues.Enabled = true;
        ddlMajorDBSValues.Enabled = true;

        txtPopupDatepicker.Enabled = true;
        txtDateReceived.Enabled = true;
    }


    #region MyRegion


    private int coverLetterExist(int filedocID)
    {
        int fileCnt = 0;
        using (SqlConnection con = new SqlConnection(eBookConn))
        {
            con.Open();
            using (SqlCommand sqlCom = new SqlCommand())
            {
                // sqlCom.CommandType = CommandType.StoredProcedure;
                sqlCom.CommandType = CommandType.Text;
                sqlCom.Connection = con;
                string sqlfileType = "select  count(fileID) from FilesTable where isFileActive = 1 and  fileType ='F' and docID = " + filedocID + "";
                sqlCom.CommandText = sqlfileType;

                using (SqlDataReader sqlReader = sqlCom.ExecuteReader())
                {
                    while (sqlReader.Read())
                    {
                        fileCnt = Convert.ToInt32(sqlReader[0].ToString());
                    }
                }
            }
        }
        return fileCnt;
    }
    private int fileAttachmentsExist(int filedocID)
    {
        int fileCnt = 0;
        using (SqlConnection con = new SqlConnection(eBookConn))
        {
            con.Open();
            using (SqlCommand sqlCom = new SqlCommand())
            {
                // sqlCom.CommandType = CommandType.StoredProcedure;
                sqlCom.CommandType = CommandType.Text;
                sqlCom.Connection = con;
                string sqlfileType = "select  count(fileID)  from FilesTable where isFileActive = 1 and  fileType ='A' and docID = " + filedocID + " ";
                sqlCom.CommandText = sqlfileType;

                using (SqlDataReader sqlReader = sqlCom.ExecuteReader())
                {
                    while (sqlReader.Read())
                    {
                        fileCnt = Convert.ToInt32(sqlReader[0].ToString());
                    }
                }
            }
        }
        return fileCnt;
    }

    static System.Web.UI.WebControls.DropDownList ddlProjectIDCopy = null;
    private void FillDropdownData()
    {
        string selectName = string.Empty;

        //  dropdown index 0 should no as Select string for required feild validatior

        PopulateDropDownBox(ddlTypeOfDocs, "SELECT docTypeID, documentType FROM  DocumentType ORDER BY documentType ", "docTypeID", "documentType", "");
        ddlTypeOfDocs.SelectedValue = "8"; // Internal memo

        //PopulateDropDownBox(ddlOriginSender, "SELECT CAST(companyID AS nvarchar(7))+','+cmpShortName As cmpIDAndShortName,contactID, (firstName + ' ' + lastName) as OriginSender FROM Contact where firstName is not NULL and lastName is not NULL ORDER BY OriginSender", "contactID", "OriginSender", ""); //WHERE (isActive = 1)
        //PopulateDropDownBox(ddlOriginSender, "SELECT CAST(Projects.department_id AS nvarchar(3))+','+CAST(Contact.contactID AS nvarchar(3)) As deptContactID, (Contact.firstName + ' ' + Contact.lastName) as OriginSender FROM Contact join Projects on contact.affairID=Projects.Affair_id where Contact.firstName is not NULL and Contact.lastName is not NULL ORDER BY OriginSender", "deptContactID", "OriginSender", ""); 
        

        //PopulateDropDownBox(ddlCompany, "SELECT CAST(companyID AS nvarchar(7))+','+cmpShortName As cmpIDAndShortName,cmpName FROM  Company ORDER BY cmpName", "cmpIDAndShortName", "cmpName", "");

        // PopulateDropDownBox(ddlDocCrossRefNo1, "SELECT documentID, referenceNo FROM  Document ORDER BY referenceNo ", "documentID", "referenceNo", "");

        FillContactCompProjDDL();
        //  ============================================================================================

        //PopulateDropDownBox_TCMS(ddlProjectID, "SELECT  proj_id, project_code FROM  PROJECTS ORDER BY project_code", "proj_id", "project_code", "Select Project ID to Add");

        //PopulateDropDownBox_TCMS(ddlTenderNo, "SELECT  proj_id, tender_no FROM PROJECTS WHERE (tender_no IS NOT NULL)  ORDER BY tender_no", "proj_id", "tender_no", "Select Tender No. to Add");

        //PopulateDropDownBox_TCMS(ddlContractNo, "SELECT bidder_id,Contract_No FROM CONTRACTORS WHERE (Contract_No IS NOT NULL) and (Contract_No != '')  ORDER BY Contract_No", "bidder_id", "Contract_No", "Select Contract No.to Add");

        //PopulateDropDownBox(ddlProjectID, "SELECT  CAST(proj_id As nvarchar(7))+','+CAST(department_id As nvarchar(7)) As projDeptId, project_code FROM PROJECTS ORDER BY project_code", "projDeptId", "project_code", "Select Project ID to Add");

        //ddlProjectIDCopy = ddlProjectID;

        PopulateDropDownBox(ddlTenderNo, "SELECT  proj_id, tender_no FROM PROJECTS WHERE (tender_no IS NOT NULL)  ORDER BY tender_no", "proj_id", "tender_no", "Select Tender No. to Add");

        PopulateDropDownBox(ddlContractNo, "SELECT bidder_id,Contract_No FROM CONTRACTORS WHERE (Contract_No IS NOT NULL) and (Contract_No != '')  ORDER BY Contract_No", "bidder_id", "Contract_No", "Select Contract No.to Add");

        PopulateDropDownBox(ddlMajorDBSValues, "SELECT dbsID, dbsDescription FROM DBSValues WHERE (dbsID = dbsParentID) ORDER BY dbsDescription", "dbsID", "dbsDescription", "Select Major DBS");

    }

    private void FillContactCompProjDDL()
    {
        if (!Session["SectionID"].ToString().Equals("13"))
        {
            //PopulateDropDownBox(ddlCompany, "SELECT (CAST(cp.companyID AS nvarchar(7))+','+CAST(ct.contactID AS nvarchar(7))) As cmpContactID,cp.cmpName FROM Company cp join Contact ct on ct.companyID=cp.companyID ORDER BY cmpName", "cmpContactID", "cmpName", "");
            PopulateDropDownBox(ddlCompany, "SELECT companyID,cmpName FROM Company ORDER BY cmpName", "companyID", "cmpName", "");
            //PopulateDropDownBox(ddlOriginSender, "SELECT (CAST(companyID As varchar(5))+','+CAST(contactID AS nvarchar(7)))  As cmpContactID, (firstName + ' ' + lastName) as OriginSender FROM  Contact ORDER BY OriginSender", "cmpContactID", "OriginSender", ""); //WHERE (isActive = 1)        
            PopulateDropDownBox(ddlProjectID, "SELECT proj_id, project_code FROM TCMS_PROJECTS ORDER BY project_code", "proj_id", "project_code", "Select Project ID to Add");
            //PopulateDropDownBox(ddlOriginSender, "SELECT (CAST(cp.companyID AS nvarchar(7))+','+CAST(ct.contactID AS nvarchar(7))) As cmpContactID, (ct.firstName + ' ' + ct.lastName) as OriginSender FROM Contact ct join Company cp on ct.companyID=cp.companyID ORDER BY OriginSender ", "cmpContactID", "OriginSender", ""); //WHERE (isActive = 1)
            //PopulateDropDownBox(ddlOriginSender, "SELECT (CAST(c1.contactID AS nvarchar(7))+','+CAST(c1.companyID AS nvarchar(7))) As contactCompID, (c1.firstName + ' ' + c1.lastName) as OriginSender FROM Contact c1 where c1.isActive=1 ORDER BY OriginSender", "contactCompID", "OriginSender", "");
        }
        else
        {
            PopulateDropDownBox(ddlCompany, "SELECT companyID,cmpName FROM  Company where cmpName like '%PWA%' ORDER BY cmpName", "companyID", "cmpName", "");
            //PopulateDropDownBox(ddlOriginSender, "SELECT (CAST(c1.contactID AS nvarchar(7))+','+CAST(d1.newDeptID AS nvarchar(7))+','+CAST(c1.companyID AS nvarchar(7))) As contactDeptCompID, (c1.firstName + ' ' + c1.lastName) as OriginSender FROM Contact c1 left outer join Department d1 on c1.deptID=d1.departmentID join UserSecurityProfile on c1.userProfileID=UserSecurityProfile.userProfileID where c1.isActive=1 and c1.contactID is not Null and d1.newDeptID is not Null and c1.companyID is not Null ORDER BY UserSecurityProfile.userProfileID", "contactDeptCompID", "OriginSender", "");
            //PopulateDropDownBox(ddlOriginSender, "SELECT (CAST(c1.companyID AS nvarchar(7))+','+CAST(c1.contactID AS nvarchar(7))) As cmpContactID, (c1.firstName + ' ' + c1.lastName) as OriginSender FROM Contact c1 join UserSecurityProfile on c1.userProfileID=UserSecurityProfile.userProfileID where c1.isActive=1 and c1.contactID is not Null and c1.companyID is not Null ORDER BY UserSecurityProfile.userProfileID", "cmpContactID", "OriginSender", "");            
            if (ddlCompany.SelectedValue != "")
            {
                PopulateDropDownBox(ddlProjectID, "SELECT proj_id, project_code FROM TCMS_PROJECTS tp join Department on tp.department_id=Department.tcmsDeptID where Department.deptName like '%" + ddlCompany.SelectedItem.Text + "%' ORDER BY project_code", "proj_id", "project_code", "Select Project ID to Add");
            }
            else
            {
                PopulateDropDownBox(ddlProjectID, "SELECT proj_id, project_code FROM TCMS_PROJECTS tp join Department on tp.department_id=Department.tcmsDeptID ORDER BY project_code", "proj_id", "project_code", "Select Project ID to Add");
            }
            //PopulateDropDownBox(ddlCompany, "SELECT CAST(companyID AS nvarchar(7))+','+cmpShortName As cmpIDAndShortName,cmpName FROM  Company where cmpName like '%PWA%' ORDER BY cmpName", "cmpIDAndShortName", "cmpName", "");
        } //c1.isActive=1 and
        PopulateDropDownBox(ddlOriginSender, "SELECT (CAST(c1.contactID AS nvarchar(7))+','+CAST(c1.companyID AS nvarchar(7))) As contactCmpID, (firstName + ' ' + lastName) as OriginSender FROM Contact c1 join UserSecurityProfile on c1.userProfileID=UserSecurityProfile.userProfileID where c1.companyID is not Null ORDER BY UserSecurityProfile.userProfileID,OriginSender", "contactCmpID", "OriginSender", ""); //WHERE (isActive = 1)
    }
    private void FillOriginSenderDDL()
    {
        //if (!Session["SectionID"].ToString().Equals("13"))
        //{
            PopulateDropDownBox(ddlOriginSender, "SELECT (CAST(c1.contactID AS nvarchar(7))+','+CAST(c1.companyID AS nvarchar(7))) As contactCmpID, (firstName + ' ' + lastName) as OriginSender FROM Contact c1 join UserSecurityProfile on c1.userProfileID=UserSecurityProfile.userProfileID where c1.companyID is not Null ORDER BY UserSecurityProfile.userProfileID,OriginSender", "contactCmpID", "OriginSender", ""); //WHERE (isActive = 1) c1.isActive=1 and
        //}
        //else
        //{
        //    PopulateDropDownBox(ddlOriginSender, "SELECT (CAST(c1.contactID AS nvarchar(7))+','+CAST(c1.companyID AS nvarchar(7))) As contactCmpID, (firstName + ' ' + lastName) as OriginSender FROM Contact c1 join UserSecurityProfile on c1.userProfileID=UserSecurityProfile.userProfileID where c1.companyID is not Null ORDER BY UserSecurityProfile.userProfileID,OriginSender", "contactCmpID", "OriginSender", ""); //WHERE (isActive = 1) c1.isActive=1 and 
        //}
    }
    private void PopulateDropDownBox_TCMS(DropDownList ddlBox, string sqlQuery, string valueMember, string displayName, string selectName)
    {

        ddlBox.DataSource = new JobOrderData().FillDropdown_TCMS(sqlQuery);
        ddlBox.DataTextField = displayName;
        ddlBox.DataValueField = valueMember;
        ddlBox.SelectedIndex = -1;

        ddlBox.DataBind();

        ListItem emptyItem = new ListItem(selectName, selectName);
        ddlBox.Items.Insert(0, emptyItem);
    }

    private void PopulateDropDownBox(DropDownList ddlBox, string sqlQuery, string valueMember, string displayName, string selectName)
    {
        try
        {
            ddlBox.DataSource = new JobOrderData().FillDropdown(sqlQuery);
            ddlBox.DataTextField = displayName;
            //if (valueMember == "cmpIDAndShortName")
            //{
            //    ddlBox.DataValueField = valueMember; //.companyID+","+valueMember.cmpShortName;
            //}
            //else
            //{
            ddlBox.DataValueField = valueMember;
            //}
            ddlBox.SelectedIndex = -1;
            ddlBox.DataBind();

            if (ddlBox.Items.Count != 0)
            {
                ListItem emptyItem = new ListItem(selectName, selectName);
                ddlBox.Items.Insert(0, emptyItem);
            }
        }
        catch (Exception)
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Error occurred while filling the Project Attribute-Project ID')</script>", false);
        }
        
    }

    #endregion

    protected void ddlMajorDBSValues_SelectedIndexChanged(object sender, EventArgs e)
    {
        string strMnrValues = " SELECT dbsDescription, dbsID FROM DBSValues WHERE  (dbsParentID = " + ddlMajorDBSValues.SelectedValue + ") AND (dbsID <> 1) ORDER BY dbsDescription";
        PopulateDropDownBox(ddlDetailedDBSValues, strMnrValues, "dbsID", "dbsDescription", " ---- Select Detailed DBS------");
    }

    private void SetCmpOrSenderFillProjectCodes(bool isCmpSelected)
    {
        ddlProjectID.Items.Clear();
        if (Session["SectionID"].ToString().Equals("13"))
        {
            //if (ddlOriginSender.SelectedValue != "")
            //{
            if (!isCmpSelected)
            {
                //ddlCompany.SelectedValue = ddlOriginSender.SelectedValue.Split(',')[2];
                OriginSenderSelected();
            }
            else
            {            
                ddlOriginSender.Items.Clear();
                PopulateDropDownBox(ddlOriginSender, "SELECT (CAST(contactID AS nvarchar(7))+','+CAST(companyID AS nvarchar(7))) As contactCmpID, (firstName + ' ' + lastName) as OriginSender FROM " +
                "Contact where companyID=" + ddlCompany.SelectedValue + " and (firstName<>Null or firstName<>'') and (lastName<>Null or lastName<>'') ORDER BY OriginSender", "contactCmpID", "OriginSender", ""); //WHERE (isActive = 1) and isActive<>0 and isAutoReplyActive=0
                FillOriginSender();
                ddlOriginSender.SelectedIndex = -1;
                //SetOriginSender();
                //ddlOriginSender.SelectedValue.IndexOf(Items.FindByValue("," + ddlCompany.SelectedValue);
                //try
                //{
                //    ddlOriginSender.SelectedIndex = 1;
                //}
                //catch (Exception)
                //{
                //    if (ddlOriginSender.SelectedItem.Text == "")
                //    {
                //        ddlOriginSender.SelectedIndex = 2;
                //    }
                //}
                //CompanySelected();
            }
            FillProjIds();
            //else
            //{
            //ddlOriginSender.Items.FindByValue(","+ddlCompany.SelectedValue);
            //}
            //PopulateDropDownBox(ddlOriginSender, "SELECT (CAST(c1.contactID AS nvarchar(7))+','+CAST(d1.newDeptID AS nvarchar(7))+','+CAST(c1.companyID AS nvarchar(7))) As contactDeptCompID, (c1.firstName + ' ' + c1.lastName) as OriginSender FROM Contact c1 left outer join Department d1 on c1.deptID=d1.departmentID where c1.isActive=1 and c1.companyID="+ddlCompany.SelectedValue+" ORDER BY OriginSender", "contactDeptCompID", "OriginSender", "");

            
            //FillCompanyDeptDDL();
            //isprjCodeChanged = true;
            //}
            //else
            //{
            //    ddlCompany.SelectedIndex = 0;
            //}
            //ddlCompany.Enabled = false;
        }
        else
        {
            //    ddlCompany.Enabled = true;
            //    string cmpIDShortName = null;
            //if (ddlOriginSender.SelectedIndex != 0)
            //{
            //ddlCompany.SelectedValue = ddlOriginSender.SelectedValue.Split(',')[1];
           
            if (isCmpSelected)
            {
                ddlOriginSender.Items.Clear();
                PopulateDropDownBox(ddlOriginSender, "SELECT (CAST(contactID AS nvarchar(7))+','+CAST(companyID AS nvarchar(7))) As contactCmpID, (firstName + ' ' + lastName) as OriginSender FROM Contact where companyID=" + ddlCompany.SelectedValue + "  ORDER BY OriginSender", "contactCmpID", "OriginSender", ""); //WHERE (isActive = 1)
                FillOriginSender();
                //SetOriginSender();
            }
            else
            {
                OriginSenderSelected();
            }
            FillProjIds();
            //PopulateDropDownBox(ddlProjectID, "SELECT proj_id, project_code FROM TCMS_PROJECTS tp join Department on tp.department_id=Department.tcmsDeptID where Department.newDeptID=" + ddlOriginSender.SelectedValue.Split(',')[1] + " ORDER BY project_code", "proj_id", "project_code", "Select Project ID to Add");
            //PopulateDropDownBox(ddlOriginSender, "SELECT contactID, (firstName + ' ' + lastName) as OriginSender FROM Contact where companyID=" + ddlCompany.SelectedValue + "  ORDER BY OriginSender", "contactID", "OriginSender", ""); //WHERE (isActive = 1)
            
            //FillCompanyDeptDDL();
            //isprjCodeChanged = true;
            //}
            //else
            //{
            //    ddlCompany.SelectedValue = ddlOriginSender.SelectedValue;
            //PopulateDropDownBox(ddlProjectID, "SELECT proj_id, project_code FROM TCMS_PROJECTS ORDER BY project_code", "proj_id", "project_code", "Select Project ID to Add");
            //ddlCompany.SelectedIndex = 0;
            //}
            //        cmpIDShortName = getCompanyIDShortName(Convert.ToInt32(ddlOriginSender.SelectedValue));
            //        if (cmpIDShortName != null)
            //        {
            //            ddlCompany.SelectedValue = cmpIDShortName.Split(',')[0]; // cmpIDShortName.ToString();
            //            //string cmpID = cmpIDShortName.Split(',')[0];
            //            //if ((cmpID == "362") || (cmpID == "2783")) // From EBSD
            //            //    lblDocCatID.Text = "2";
            //            //else
            //            //    lblDocCatID.Text = "1";
            //            PopulateDropDownBox(ddlProjectID, "SELECT proj_id, project_code FROM TCMS_PROJECTS tp join Department on tp.department_id=Department.tcmsDeptID where Department.newDeptID=" + ddlOriginSender.SelectedValue.Split(',')[1] + " ORDER BY project_code", "proj_id", "project_code", "Select Project ID to Add");
            //        }
            //        else
            //        {
            //            PopulateDropDownBox(ddlProjectID, "SELECT proj_id, project_code FROM TCMS_PROJECTS ORDER BY project_code", "proj_id", "project_code", "Select Project ID to Add");
            //        }

            //    }


        }
    }

    private void FillProjIds()
    {
        if (ddlCompany.SelectedValue != "")
        {
            FillProjectID();
        }
        else
        {
            PopulateDropDownBox(ddlProjectID, "SELECT proj_id, project_code FROM TCMS_PROJECTS tp join Department on tp.department_id=Department.tcmsDeptID ORDER BY project_code", "proj_id", "project_code", "Select Project ID to Add");
        }
    }

    private void SetOriginSender()
    {
        try
        {
            ddlOriginSender.SelectedValue = getContactID(ddlCompany.SelectedValue) + "," + ddlCompany.SelectedValue;
        }
        catch (Exception)
        {
            ddlOriginSender.SelectedIndex = 0;
        }
    }
    private void FillProjectID()
    {
        string cmpName = ddlCompany.SelectedItem.Text.Replace("-", "");
        string sqlQuery = null;
        if (cmpName.Contains("Assets"))
        {
            sqlQuery = "SELECT proj_id, project_code FROM TCMS_PROJECTS tp join Department on tp.department_id=Department.tcmsDeptID where project_code like '%AA%' and project_code not like '%FAAD%' ORDER BY project_code";
        }
        else if (cmpName == "PWA" || cmpName=="")
        {
            sqlQuery = "SELECT proj_id, project_code FROM TCMS_PROJECTS tp join Department on tp.department_id=Department.tcmsDeptID ORDER BY project_code";
        }
        else
        {           
           sqlQuery = "SELECT proj_id, project_code FROM TCMS_PROJECTS tp join Department on tp.department_id=Department.tcmsDeptID where Department.deptName like '%" + cmpName.Substring(cmpName.IndexOf(cmpName.Split(' ')[1])).Split(' ')[0] + "%' ORDER BY project_code";            
        }
        PopulateDropDownBox(ddlProjectID, sqlQuery, "proj_id", "project_code", "Select Project ID to Add");
    }

    private void CompanySelected()
    {
        ddlOriginSender.Items.Clear();
        PopulateDropDownBox(ddlOriginSender, "SELECT contactID, (firstName + ' ' + lastName) as OriginSender FROM Contact where companyID=" + ddlCompany.SelectedValue + " ORDER BY OriginSender", "contactID", "OriginSender", ""); //WHERE (isActive = 1)
        //PopulateDropDownBox(ddlOriginSender, "SELECT (CAST(cp.companyID AS nvarchar(7))+','+CAST(ct.contactID AS nvarchar(7))) As cmpContactID, (ct.firstName + ' ' + ct.lastName) as OriginSender FROM Contact ct join Company cp on ct.companyID=cp.companyID where cp.companyID=" + ddlCompany.SelectedValue + " ORDER BY OriginSender ", "cmpContactID", "OriginSender", ""); //WHERE (isActive = 1)
        //if (ddlOriginSender.Items.Count > 0)
        //{
        try
        {
            ddlOriginSender.SelectedIndex = 1;
        }
        catch (Exception)
        {
            if (ddlOriginSender.SelectedItem.Text == "")
            {
                ddlOriginSender.SelectedIndex = 2;
            }
        }
    }

    private void FillOriginSender()
    {
        if (ddlOriginSender.Items.Count == 0)
        {
            PopulateDropDownBox(ddlOriginSender, "SELECT (CAST(contactID AS nvarchar(7))+','+CAST(companyID AS nvarchar(7))) As contactCmpID, (firstName + ' ' + lastName) as OriginSender FROM " +
            "Contact where (firstName<>Null or firstName<>'') and (lastName<>Null or lastName<>'') ORDER BY OriginSender", "contactCmpID", "OriginSender", ""); //WHERE (isActive = 1) and isActive<>0 and isAutoReplyActive=0 
        }
    }

    private void OriginSenderSelected()
    {
        string cmpID = null;
        if (ddlOriginSender.SelectedIndex != 0)
        {
            //cmpID = getCompanyID(Convert.ToInt32(ddlOriginSender.SelectedValue));
            cmpID = ddlOriginSender.SelectedValue.Split(',')[1];
            try
            {
                ddlCompany.SelectedValue = cmpID.ToString();
            }
            catch (Exception)
            {
                ddlCompany.SelectedIndex = 0;                
            }            
        }

        if (cmpID == "362") // From EBSD
            lblDocCatID.Text = "2";
        else
            lblDocCatID.Text = "1";
    }

    private string getContactID(string cmpID)
    {
        string contactID = null;

        SqlConnection cnn = new SqlConnection(eBookConn);
        cnn.Open();
        SqlCommand cmm = new SqlCommand();
        cmm.Connection = cnn;         
        cmm.CommandText = "SELECT contactID FROM Contact where companyID=" + cmpID;      

        SqlDataReader sqlDtReader = cmm.ExecuteReader();
        if (sqlDtReader.HasRows)
        {
            if (sqlDtReader.Read())
            {               
                contactID = sqlDtReader["contactID"].ToString();                
            }
        }
        sqlDtReader.Close();
        cnn.Close();
        return contactID;
    }

    
    private int getCompanyID(int _contactID)
    {
        int cmpID = 0;

        SqlConnection cnn = new SqlConnection(eBookConn);
        cnn.Open();
        SqlCommand cmm = new SqlCommand();
        cmm.Connection = cnn;

        cmm.CommandText = "SELECT companyID From contact where contactid = " + _contactID;

        SqlDataReader sqlDtReader = cmm.ExecuteReader();
        if (sqlDtReader.HasRows)
        {
            while (sqlDtReader.Read())
            {
                cmpID = Convert.ToInt32(sqlDtReader["companyID"]);
            }
        }
        sqlDtReader.Close();
        cnn.Close();
        return cmpID;
    }

    //static Boolean isprjCodeChanged = false;
    protected void ddlOriginSender_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (Session["UserName"] != null)
        {
            try
            {
                if (ddlOriginSender.SelectedValue != "")
                {
                    SetCmpOrSenderFillProjectCodes(false);
                }
                else
                {
                    ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Origin/Sender cannot be blank. Please select Origin/Sender');$('#ctl00_ContentPlaceHolder1_ddlOriginSender')[0].focus();</script>", false);
                }
            }
            catch (Exception)
            {
                ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Error occurred while filling the company or project codes')</script>", false);
            }
            txtDocRefNo.Focus();
        }
        else
        {
            Response.Redirect("~/LoginPage.aspx", false);            
        }        

        //else
        //{
        //    ddlOriginSender.SelectedIndex = 0; // ddlOriginSender.SelectedIndex;
        //    ddlCompany.Enabled = true;
        //}
        

    }
    public IList<int> getDistributionDataForOrginSender(int orginID)
    {
        IList<int> strColl = new List<int>();
        try
        {
            string qry = "SELECT distributeID, contactID  From DocumentDistribution WHERE (documentID = " + _docID + ") AND (contactID = " + orginID + ")";

            using (SqlConnection sqlConn = new SqlConnection(eBookConn))
            {
                sqlConn.Open();

                using (SqlCommand sqlCmd = new SqlCommand())
                {
                    sqlCmd.Connection = sqlConn;
                    sqlCmd.CommandText = qry;

                    using (SqlDataReader dr = sqlCmd.ExecuteReader())
                    {
                        while (dr.Read())
                        {
                            strColl.Add(Convert.ToInt32(dr["distributeID"].ToString()));
                        }
                    }
                }
            }
        }
        catch (Exception ex)
        {
        }

        return strColl;
    }

    public void PrjCodeChangeLog(string changeDesc, string windowName, string NewprjCode, string oldPrjCode)
    {
        if (ddlOriginSender.SelectedIndex != 0)
        {
            string upDateQuery = "INSERT INTO CHANGELOG(ChangeData,windowName,oldData,newData,updateUser) VALUES('" + changeDesc + "','" + windowName + "','" + NewprjCode + "','" + oldPrjCode + "', '" + Session["UserName"].ToString() + "')";
            SqlConnection sqlCon = new SqlConnection(eBookConn);
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = upDateQuery;
            cmd.Connection = sqlCon;
            try
            {
                sqlCon.Open();
                cmd.ExecuteNonQuery();
                sqlCon.Close();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
     
    protected void ddlCompany_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (Session["SectionID"] != null)
        {
            //if (!Session["SectionID"].ToString().Equals("13"))
            //{
                if (ddlCompany.SelectedValue == "362") // From EBSD
                    lblDocCatID.Text = "2";
                else
                    lblDocCatID.Text = "1";
            //}

            if (ddlCompany.SelectedValue != "")
            {
                SetCmpOrSenderFillProjectCodes(true);
            }
            else
            {
                ddlOriginSender.Items.Clear();
                //ddlCompany.SelectedIndex = 0;
                FillOriginSenderDDL();
                //ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Company/Department cannot be blank. Please select Company/Department');$('#ctl00_ContentPlaceHolder1_ddlCompany')[0].focus();</script>", false);
            }
        }
        else
        {
            Response.Redirect("~/LoginPage.aspx", false);
        }
        //FillCompanyDeptDDL();
        //}
    }
    private void UpdateDistributionContactID(int distID, int _contactID, string userName)
    {
        // Update contactID and IssedBy and DistributedTo When changing Existed Orgin Sender

        SqlConnection cn = new SqlConnection(eBookConn);
        SqlCommand sqlCmd = new SqlCommand();
        sqlCmd.CommandType = CommandType.Text;
        sqlCmd.CommandText = "Update DocumentDistribution Set ContactID=@ContactID,createUser = @createUser  Where disributeID= @distID";
        sqlCmd.Connection = cn;

        sqlCmd.Parameters.AddWithValue("@ContactID", _contactID);
        sqlCmd.Parameters.AddWithValue("@distID", distID);
        sqlCmd.Parameters.AddWithValue("@createUser", userName);

        try
        {
            cn.Open();
            sqlCmd.ExecuteNonQuery();
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            cn.Close();
        }
    }
    private void UpdateDocumetOrgin()
    {
        // Update OriginSender and IssedBy and DistributedTo When changing Existed Orgin Sender

        SqlConnection cn = new SqlConnection(eBookConn);
        SqlCommand sqlCmd = new SqlCommand();
        sqlCmd.CommandType = CommandType.Text;
        sqlCmd.CommandText = "Update Document Set originContactID = @originContactID Where documentID =@docID";
        sqlCmd.Connection = cn;

        sqlCmd.Parameters.AddWithValue("@docID", _docID);
        sqlCmd.Parameters.AddWithValue("@originContactID", ddlOriginSender.SelectedValue.Split(',')[0]);

        try
        {
            cn.Open();
            sqlCmd.ExecuteNonQuery();
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            cn.Close();
        }
    }
    private void UpdateDistributionOrginForIssuedBy(int _NeworginID, int _oldOrginID)
    {
        // Update OriginSender and IssedBy and DistributedTo When changing Existed Orgin Sender

        SqlConnection cn = new SqlConnection(eBookConn);
        SqlCommand sqlCmd = new SqlCommand();
        sqlCmd.CommandType = CommandType.Text;
        sqlCmd.CommandText = "Update DocumentDistribution Set issuedByContactID= " + _NeworginID + "Where documentID = " + _docID + " and issuedByContactID= " + _oldOrginID + " ";
        sqlCmd.Connection = cn;

        //sqlCmd.Parameters.AddWithValue("@docID", _docID);
        //sqlCmd.Parameters.AddWithValue("@issuedByContactID", _NeworginID);
        try
        {
            cn.Open();
            sqlCmd.ExecuteNonQuery();
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            cn.Close();
        }
    }
    private void UpdateDistributionOrginForDistributedTo(int _NeworginID, int _oldOrginID)
    {
        // Update OriginSender and IssedBy and DistributedTo When changing Existed Orgin Sender

        SqlConnection cn = new SqlConnection(eBookConn);
        SqlCommand sqlCmd = new SqlCommand();
        sqlCmd.CommandType = CommandType.Text;

        sqlCmd.CommandText = "Update DocumentDistribution Set ContactID= " + _NeworginID + "  Where documentID = " + _docID + " and ContactID = " + _oldOrginID + " ";
        sqlCmd.Connection = cn;

        //sqlCmd.Parameters.AddWithValue("@docID", _docID);
        //sqlCmd.Parameters.AddWithValue("@contactID", _orginID);
        try
        {
            cn.Open();
            sqlCmd.ExecuteNonQuery();
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            cn.Close();
        }
    }
    public void gridloadForDocDistributeData()
    {
        DataSet ds = new DataSet();
        ds = (new JobOrderData().FillDocDistributeData(_docID));
        gvDistribution.DataSource = ds;
        gvDistribution.DataBind();
    }
    //public void gridloadForDocRelatedTasks()
    //{
    //    DataSet ds = new DataSet();
    //    ds = (new JobOrderData().FillDocRelatedTasks(_docID,_currentUserID));
    //    gvJobDetails.DataSource = ds;
    //    DataTable dt = ds.Tables[0];
    //    if (dt.Rows.Count != 0)
    //    {
    //        gvJobDetails.DataSource = dt;
    //    }
    //    else
    //    {
    //        gvJobDetails.DataSource = null;
    //        //gridTasks.Visible = true;
    //    }
    //    gvJobDetails.DataBind();       
    //}
    private void gridloadForProjectAttributeData(int jobID)
    {
        DataSet ds = new DataSet();
        if (jobID == 0)
        {
            ds = (new JobOrderData().FillDocAttributeData(_docID, _currentUserID));
        }
        else
        {
            ds = (new JobOrderData().FillDocAttributeDataByJobID(jobID, _currentUserID));
        }
        gvDocProjAttributes.DataSource = ds;
        gvDocProjAttributes.DataBind();
    }
    private void gridloadForDBSValues()
    {
        DataSet ds = new DataSet();
        ds = (new JobOrderData().FillDBSValues(_docID));
        gvDBS.DataSource = ds;
        gvDBS.DataBind();
    }

    protected void lnkBtnJobID_Click(object sender, EventArgs e)
    {
        string strUpdateJob = Request.Url.AbsoluteUri;
        Session["UrlRef"] = strUpdateJob;
        try
        {
            LinkButton lnkJobID = (LinkButton)sender;
            GridViewRow gvr = (GridViewRow)lnkJobID.NamingContainer;

            Session["REQUEST_ID"] = lnkJobID.ToolTip;

            if (Session["SectionID"].ToString().Equals("4"))
            {
                Response.Redirect("~/Survey/SurveyDetails.aspx?REQUEST_ID= " + Session["REQUEST_ID"] + "", false);
            }
        }
        catch (Exception ex)
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Error occurred while processing the request')</script>", false);
        }
    }

    public void FillDocRelatedTasks(int _docID, int currentUserID)
    {
        try
        {

            string qry = "SELECT DISTINCT  JobOwner.jobID,JobOwner.payID, JobOwner.jobNo, JobType_1.jobTypeName, Section.sectionName, JobStatus.jobStatusName, DocumentDistribution.documentID,   JobOwner.jobOwnerID, JobOwner.contactID, JobOwner.JobTypeID, JobType_1.CategoryID, JobOwner.sectionID " +
                       " FROM    JobOwner INNER JOIN   JobStatus ON JobOwner.jobOwnerStatusID = JobStatus.jobStatusID INNER JOIN   Section ON JobOwner.sectionID = Section.sectionID INNER JOIN  JobType ON JobOwner.JobTypeID = JobType.jobTypeID INNER JOIN " +
                   " JobType AS JobType_1 ON JobType.CategoryID = JobType_1.jobTypeID FULL OUTER JOIN  DocumentDistribution ON JobOwner.jobOwnerID = DocumentDistribution.jobOwnerID  WHERE (DocumentDistribution.documentID = " + _docID + ") AND (JobOwner.jobOwnerID IS NOT NULL) AND (JobOwner.contactID = " + currentUserID + ")";

            using (SqlConnection sqlConn = new SqlConnection(eBookConn))
            {
                sqlConn.Open();

                using (SqlCommand sqlCmd = new SqlCommand())
                {
                    sqlCmd.Connection = sqlConn;
                    sqlCmd.CommandText = qry;

                    using (SqlDataReader dr = sqlCmd.ExecuteReader())
                    {
                        if (dr.HasRows)
                        {
                            dr.Read();
                            lnkJobNo.Text = dr["jobNo"].ToString();
                            lnkJobNo.ToolTip = dr["jobID"].ToString();
                            if (lnkJobNo.ToolTip == "")
                                lnkJobNo.ToolTip = dr["payID"].ToString();

                            txtJobType.Value = dr["jobTypeName"].ToString();
                            txtSection.Value = dr["sectionName"].ToString();
                            txtJobStatus.Value = dr["jobStatusName"].ToString();

                            txtCatID.Value = dr["CategoryID"].ToString();

                        }
                    }
                }
            }
        }
        catch (Exception ex)
        {
        }
    }

    #region AllFunctions

    private string getCompanyIDShortName(int _contactID)
    {
        string cmpIDShortName = null;

        SqlConnection cnn = new SqlConnection(eBookConn);
        cnn.Open();
        SqlCommand cmm = new SqlCommand();
        cmm.Connection = cnn;

        cmm.CommandText = "SELECT company.companyID,company.cmpShortName From contact join company on contact.companyID=company.companyID where contact.contactid = " + _contactID;

        SqlDataReader sqlDtReader = cmm.ExecuteReader();
        if (sqlDtReader.HasRows)
        {
            while (sqlDtReader.Read())
            {
                cmpIDShortName = Convert.ToString(sqlDtReader["companyID"]) + "," + sqlDtReader["cmpShortName"];
            }
        }
        sqlDtReader.Close();
        cnn.Close();
        return cmpIDShortName;
    }

    #endregion

    private string CreateDocument(bool isDocForClosing)
    {
        using (SqlConnection cn = new SqlConnection(eBookConn))
        {
            using (SqlCommand sqlCmd = new SqlCommand())
            {
                try
                {
                    string cmpID = null;
                    string originContactID = null;

                    cmpID = ddlCompany.SelectedValue;
                    originContactID = ddlOriginSender.SelectedValue.Split(',')[0];
                    sqlCmd.CommandType = CommandType.StoredProcedure;
                    sqlCmd.CommandText = "sp_InsertDocument_TSS";
                    sqlCmd.Connection = cn;

                    // sqlCmd.Parameters.AddWithValue("@docDate", DateTime.ParseExact(txtPopupDatepicker.Text, "dd/MMM/yyyy", CultureInfo.InvariantCulture));

                    sqlCmd.Parameters.AddWithValue("@docDate", Convert.ToDateTime(txtPopupDatepicker.Text).ToString("dd/MMM/yyyy"));
                    sqlCmd.Parameters.AddWithValue("@docTypeID", ddlTypeOfDocs.SelectedValue);
                    sqlCmd.Parameters.AddWithValue("@originID", originContactID);

                    Session["originContactID"] = originContactID;

                    sqlCmd.Parameters.AddWithValue("@originCoID", cmpID);
                    //sqlCmd.Parameters.AddWithValue("@newDeptID", ddlOriginSender.SelectedValue.Split(',')[1]);
                    sqlCmd.Parameters.AddWithValue("@referenceNo", txtDocRefNo.Text);

                    sqlCmd.Parameters.AddWithValue("@docReceivedDate", Convert.ToDateTime(txtDateReceived.Text).ToString("dd/MMM/yyyy"));

                    // sqlCmd.Parameters.AddWithValue("@docReceivedDate", DateTime.ParseExact(txtDateReceived.Text, "dd/MMM/yyyy", CultureInfo.InvariantCulture));
                    if (txtRplyDoc.Text != "")
                        sqlCmd.Parameters.AddWithValue("@crossReferenceNo", txtRplyDoc.Text);
                    else
                        sqlCmd.Parameters.AddWithValue("@crossReferenceNo", System.DBNull.Value);

                    sqlCmd.Parameters.AddWithValue("@docSubject", txtDocSubject.Text);
                    sqlCmd.Parameters.AddWithValue("@docContent", txtDocDescription.Text);

                    if ((cmpID == "362") || (cmpID == "2783"))
                    {
                        sqlCmd.Parameters.AddWithValue("@docCatID", 2);
                        _docCatID = 2;
                    }
                    else
                    {
                        sqlCmd.Parameters.AddWithValue("@docCatID", 1);
                        _docCatID = 1;
                    }

                    sqlCmd.Parameters.AddWithValue("@docCreatedByID", Session["UserID"].ToString());
                    Session["docCreatedByID"] = Session["UserID"].ToString();
                    sqlCmd.Parameters.AddWithValue("@createUser", Session["UserName"].ToString());

                    //sqlCmd.Parameters.AddWithValue("@createDate ", DateTime.ParseExact(DateTime.Now.ToString("dd/MMM/yyyy HH:mm:ss"), "dd/MMM/yyyy HH:mm:ss", CultureInfo.InvariantCulture));

                    if (_docID == 0)
                        sqlCmd.Parameters.AddWithValue("@docID", SqlDbType.SmallInt).Direction = ParameterDirection.Output;
                    else
                        sqlCmd.Parameters.AddWithValue("@docID", _docID);

                    string actionDueDate = getEndDateByGivenDays(txtDateReceived.Text, 1);

                    sqlCmd.Parameters.AddWithValue("@actionDueDate", Convert.ToDateTime(actionDueDate).ToString("dd/MMM/yyyy"));

                    sqlCmd.Parameters.AddWithValue("@isImportance", (Boolean)chkHighImp.Checked);
                    sqlCmd.Parameters.AddWithValue("@isSuperseded", (Boolean)chkSuperseded.Checked);

                    if (Session["JobID"] == null || Session["JobID"].ToString() == "")    // Reply to close validation for JobID
                        sqlCmd.Parameters.AddWithValue("@jobID", System.DBNull.Value);
                    else
                        sqlCmd.Parameters.AddWithValue("@jobID", Convert.ToInt32(Session["JobID"].ToString().Trim()));

                    if (Session["SectionID"].ToString().Equals("13"))
                    {
                        if (emailID == null || emailID=="")
                        {
                            if (deptCordEmailID.Text.Trim() != "")
                            {
                                emailID = deptCordEmailID.Text.Trim();
                                sqlCmd.Parameters.AddWithValue("@deptCoordEmailID", emailID);
                            }
                            else
                            {
                                sqlCmd.Parameters.AddWithValue("@deptCoordEmailID", System.DBNull.Value);
                            }
                        }
                        else
                        {
                            sqlCmd.Parameters.AddWithValue("@deptCoordEmailID", emailID);
                        }
                        
                        if (eoiRdb.Checked)
                        {                        
                            sqlCmd.Parameters.AddWithValue("@isEOI", 1);
                            eoiRdb.Checked = true;                             
                            eoiRdb.Visible = true;
                            preQualRdb.Visible = true;
                            lblEoi.Visible = true;
                        }
                        else
                        {
                            sqlCmd.Parameters.AddWithValue("@isEOI", System.DBNull.Value);
                        }
                        
                        if (preQualRdb.Checked)
                        {                             
                            sqlCmd.Parameters.AddWithValue("@isPreQual",1);
                            eoiRdb.Checked = false;                             
                            preQualRdb.Checked = true;
                            preQualRdb.Visible = true;
                            lblPreQual.Visible = true;
                        //    emailIDLblRow.Visible = false;
                        //    emailIDTxtRow.Visible = false;
                        }
                        else
                        {
                            sqlCmd.Parameters.AddWithValue("@isPreQual", System.DBNull.Value);
                        }
                    }
                    else
                    {
                        sqlCmd.Parameters.AddWithValue("@deptCoordEmailID", System.DBNull.Value);
                        sqlCmd.Parameters.AddWithValue("@isEOI", System.DBNull.Value);
                        sqlCmd.Parameters.AddWithValue("@isPreQual", System.DBNull.Value);
                    }
                    // Newly added Parameter for Payment Module

                    if (Session["PayID"] == null)
                        sqlCmd.Parameters.AddWithValue("@payID", System.DBNull.Value);
                    else
                        sqlCmd.Parameters.AddWithValue("@payID", Convert.ToInt32(Session["PayID"]));

                    if (isDocForClosing == true)
                        sqlCmd.Parameters.AddWithValue("@isDocForClosing", 1);
                    else
                        sqlCmd.Parameters.AddWithValue("@isDocForClosing", 0);

                    if (deptCoordID != null)
                    {
                        sqlCmd.Parameters.AddWithValue("@deptCoordID", deptCoordID);
                    }
                    else
                    {
                        sqlCmd.Parameters.AddWithValue("@deptCoordID", System.DBNull.Value);
                    }
                    cn.Open();
                    sqlCmd.ExecuteNonQuery();

                }
                catch (Exception ex)
                {
                    ClientScript.RegisterStartupScript(this.GetType(), "Popup", "<script>alert('Error occurred while creating the document:" + ex.Message.Replace("'", "") + "')</script>", false);
                    return "0";
                    //throw ex;
                }

                return sqlCmd.Parameters["@docID"].Value.ToString();
            }
        }
    }

    protected void btnCreateDoc_Click1(object sender, EventArgs e)
    {
        saveDocument();
    }

    private void saveDocument()
    {
        try
        {
            if (ViewState["replyToClose"] != null)                             // (replyToClose != null)       // Clicked On Rec/Send Button for new Doc Creation
            {
                _docID = Convert.ToInt32(CreateDocument(true));
            }
            else
            {
                _docID = Convert.ToInt32(CreateDocument(false));
            }
            if (_docID != 0)
            {
                eoiRdb.Disabled = true;
                preQualRdb.Disabled = true;                
                Session["docSender"] = null;

                Session["File_docID"] = _docID;

                if ((Session["JobID"] != null))        // Coming from Job Order /PSA 
                {
                    if (ViewState["replyToClose"] != null)                             // (replyToClose != null)       // Clicked On Rec/Send Button for new Doc Creation
                    {
                        int jobID = Convert.ToInt32(lblJobID.Text);
                        CheckandDeleteDistributionData(_docID);
                        AddDistributionData(jobID);
                        

                        // if (replyToClose.Equals("1")) // Clicked On Reply To Close Button

                        if (ViewState["replyToClose"].Equals("1")) // Clicked On Reply To Close Button
                        {
                            updateJobClosedDate_ReplyToClose(jobID, txtPopupDatepicker.Text);
                            JobOrderData jod = new JobOrderData();
                            if (Session["SectionID"].ToString() == "13") //13==TSS Section
                            {
                                jod.setPageObj(this.Page);
                                //if (Session["JobCatID"].ToString() == "113") //EOI Expression of Interest
                                //{
                                //string sqlQuery = "SELECT documentID, docCatID, distributeID, contactID FROM  DocumentDistribution WHERE   (documentID IN (SELECT documentID FROM  DocumentDistribution AS Tmp  GROUP BY documentID, contactID HAVING   (COUNT(*) > 1) AND (contactID = DocumentDistribution.contactID) AND (documentID = " + DocID + ")))  ORDER BY documentID, docCatID, distributeID";
                                string sqlQuery = "select deptCoordEmailID from Document where jobID=" + jobID + " and deptCoordEmailID is not NULL";
                                DataTable dtDocumentCoordEmailID = GetDataFromDB("DocumentCoordEmailID", sqlQuery);
                                string emailID = dtDocumentCoordEmailID.Rows[0].ItemArray[0].ToString();
                                if (emailID != "")
                                {
                                    jod.SendEmailAlert(emailID, jobID.ToString(), Session["CntrNo"].ToString(), "memo attached and job status is closed.");  //105 is Nazar ContactID  the job and send email Notification to department representative
                                }
                                //}
                                //else
                                //{
                                if (Session["teamLeaderID"].ToString() != "")
                                {
                                    string tlContactID = jod.getTeamLeadContactID(Session["teamLeaderID"].ToString());
                                    using (SqlConnection sqlConn = new SqlConnection(eBookConn))
                                    {
                                        sqlConn.Open();
                                        UpdateDateReadOfTeamLead(tlContactID, sqlConn);
                                        sqlConn.Close();
                                    }
                                    jod.SendEmailAlert(jod.getEmail(tlContactID), jobID.ToString(), "", "Job Request has been Closed successfully");  //105 is Nazar ContactID                             
                                }
                                //}

                            }
                        }

                        //lblJobID.Text = Session["JobID"].ToString();
                    }
                    else
                    {
                        // Clicked on Link button of Rec/Sent Grid
                    }
                }

                //Session["JobID"] = null;   // Make Session Null becos of its carring from Job page for new document creation
                //Session["PayID"] = null;

                lblDocID.Text = _docID.ToString();
                
                ddlProjectID.Enabled = true;
                ddlTenderNo.Enabled = true;
                ddlContractNo.Enabled = true;
                btnAddDbs.Enabled = true;

                gridloadForDocDistributeData();
            }
        }
        catch (Exception)
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "Popup", "<script>alert('Error Occurred while saving the document.')</script>", false);
        }        
        
    }
    private void UpdateDateReadOfTeamLead(string contactID, SqlConnection sqlConn)
    {
        string strValue = "select jobOwnerID from JobOwner where contactID=@contactID and jobID=@jobID"; //and distributedBy=@distributedBy and staffStartDate is not Null
        SqlCommand sqlCom = new SqlCommand(strValue, sqlConn);
        sqlCom.Parameters.AddWithValue("@contactID", contactID);
        //sqlCom.Parameters.AddWithValue("@distributedBy", Session["UserID"].ToString());
        sqlCom.Parameters.AddWithValue("@jobID", lblJobID.Text);
        SqlDataReader sqlReader = sqlCom.ExecuteReader();
        if (sqlReader.HasRows)
        {
            sqlReader.Read();
            string jobOwnerID = sqlReader["jobOwnerID"].ToString();
            sqlReader.Close();
            strValue = "update JobOwner set dateRead=@dateRead where jobOwnerID=@jobOwnerID"; // select jobOwnerID from JobOwner where contactID=" + eventArgument.Split(',')[4].ToString() + " and jobID=" + _jobID + " and staffStartDate is not Null";
            sqlCom = new SqlCommand(strValue, sqlConn);
            sqlCom.Parameters.AddWithValue("@jobOwnerID", jobOwnerID);
            sqlCom.Parameters.AddWithValue("@dateRead", DBNull.Value);
            sqlCom.ExecuteNonQuery();
        }
        sqlReader.Close();
        sqlCom.Dispose();
    }
    private void AddDistributionData(int jobID)
    {
        //Session["DocID"] = 203;

        string sqlQuery = "SELECT contactID, daysToAct, convert(nvarchar,actionDueDate,103) as ActionDueDate,jobOwnerStatusID,JobOwnerID,distributedBy,docID FROM JobOwner WHERE jobID =" + jobID;
        DataTable dtJobOwner = GetDataFromDB("JobOwner", sqlQuery);

        short jobOwnerCounter = 0;
        while (jobOwnerCounter < dtJobOwner.Rows.Count)
        {
            string InchargeStat = dtJobOwner.Rows[jobOwnerCounter]["jobOwnerStatusID"].ToString();

            SqlConnection sqlConn = new SqlConnection(eBookConn);
            SqlCommand sqlCmd = new SqlCommand();
            sqlCmd.Connection = sqlConn;

            sqlCmd.CommandType = CommandType.StoredProcedure;
            sqlCmd.CommandText = "InsertDocDistributionFromJob";

            sqlCmd.Parameters.AddWithValue("@contactID", dtJobOwner.Rows[jobOwnerCounter]["contactID"].ToString());

            if (InchargeStat != "7")       //
            {
                sqlCmd.Parameters.AddWithValue("@docPurposeID", 1); //// For Action
                sqlCmd.Parameters.AddWithValue("@docStatusID", 1);

                string actionDate = Convert.ToDateTime(dtJobOwner.Rows[jobOwnerCounter][2]).ToString("dd/MMM/yyyy");

                sqlCmd.Parameters.AddWithValue("@actionDueDate", actionDate);   //DateTime.ParseExact(dtJobOwner.Rows[jobOwnerCounter][2].ToString().Split(' ')[0].Split(' ')[0], "dd/MM/yyyy", CultureInfo.InvariantCulture));
                sqlCmd.Parameters.AddWithValue("@daysToReply", dtJobOwner.Rows[jobOwnerCounter]["daysToAct"].ToString());
                sqlCmd.Parameters.AddWithValue("@dateRead", System.DBNull.Value);
            }
            else
            {
                sqlCmd.Parameters.AddWithValue("@docPurposeID", 2);       // For Info
                sqlCmd.Parameters.AddWithValue("@docStatusID", 4);
                sqlCmd.Parameters.AddWithValue("@actionDueDate", System.DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@daysToReply", System.DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@dateRead", System.DateTime.Now.ToString("dd/MMM/yyyy"));
            }

            // sqlCmd.Parameters.AddWithValue("@issuedByContactID", Session["UserID"].ToString());

            sqlCmd.Parameters.AddWithValue("@issuedByContactID", dtJobOwner.Rows[jobOwnerCounter]["distributedBy"].ToString());

            sqlCmd.Parameters.AddWithValue("@createUser", Session["UserName"].ToString());

            sqlCmd.Parameters.AddWithValue("@documentID", _docID);
            sqlCmd.Parameters.AddWithValue("@inchargeID", dtJobOwner.Rows[jobOwnerCounter]["JobOwnerID"].ToString());

            // sqlCmd.Parameters.AddWithValue("@docIssuedDate", System.DateTime.Now.ToString("dd/MMM/yyyy"));
            sqlCmd.Parameters.AddWithValue("@docCatID", 1);


            sqlConn.Open();
            sqlCmd.ExecuteNonQuery();
            sqlConn.Close();

            jobOwnerCounter++;
        }
    }
    private void CheckandDeleteDistributionData(int DocID)
    {
        string sqlQuery = "SELECT documentID, docCatID, distributeID, contactID FROM  DocumentDistribution WHERE   (documentID IN (SELECT documentID FROM  DocumentDistribution AS Tmp  GROUP BY documentID, contactID HAVING   (COUNT(*) > 1) AND (contactID = DocumentDistribution.contactID) AND (documentID = " + DocID + ")))  ORDER BY documentID, docCatID, distributeID";
        DataTable dtDocumentDistribution = GetDataFromDB("DocumentDistribution", sqlQuery);

        if (dtDocumentDistribution.Rows.Count != 0)
            DeleteDistributionData(Convert.ToInt32(dtDocumentDistribution.Rows[0]["documentID"]));//Modified below line
            //DeleteDistributionData(Convert.ToInt32(dtDocumentDistribution.Rows[0]["distributeID"]));
    }


    private void DeleteDistributionData(int documentID)
    {
        string updateSql = "Delete From DocumentDistribution Where documentID = " + documentID + " ";
        //string updateSql = "Delete From DocumentDistribution Where distributeID = " + documentID + " ";
        using (SqlConnection sqlConn = new SqlConnection(eBookConn))
        {
            using (SqlCommand cmd = new SqlCommand())
            {
                cmd.CommandText = updateSql;
                cmd.Connection = sqlConn;

                try
                {
                    sqlConn.Open();
                    cmd.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    Response.Write(ex.Message);
                }
            }
        }
    }

    public DataTable GetDataFromDB(string dataTabName, string sqlQuery)
    {
        DataTable table = null;
        SqlConnection sqlConn = new SqlConnection(eBookConn);
        sqlConn.Open();
        SqlDataAdapter sqlDtAdptr = null;
        table = new DataTable(dataTabName);
        sqlDtAdptr = new SqlDataAdapter(@sqlQuery, sqlConn);
        sqlDtAdptr.Fill(table);
        sqlConn.Close();
        return table;
    }

    public void updateJobClosedDate_ReplyToClose(int jobID, string closedDate)
    {
        try
        {
            using (SqlConnection sqlConn = new SqlConnection(eBookConn))
            {
                string strUpdate = "Update Job Set jobClosedDate = @jobClosedDate,JobStatusID =@JobStatusID,closedDocRefID = @closedDocRefID where jobID = " + jobID + "";

                using (SqlCommand sqlCom = new SqlCommand())
                {
                    // sqlCom.CommandType = CommandType.StoredProcedure;
                    sqlCom.CommandType = CommandType.Text;

                    sqlCom.Connection = sqlConn;
                    sqlCom.CommandText = strUpdate;          //ReplyToCloseJob

                    sqlCom.Parameters.AddWithValue("@jobClosedDate", Convert.ToDateTime(closedDate).ToString("dd/MMM/yyyy"));
                    sqlCom.Parameters.AddWithValue("@JobStatusID", 1);   // Closed
                    sqlCom.Parameters.AddWithValue("@closedDocRefID", _docID);
                    sqlCom.Parameters.AddWithValue("@jobID", jobID);
                    sqlConn.Open();
                    sqlCom.ExecuteNonQuery();

                }
            }
        }
        catch (System.Exception ex)
        {
            throw ex;
        }
    }
    protected void btnDistribute_Click(object sender, EventArgs e)
    {
        if (lblDocID.Text != "")
            _docID = Convert.ToInt32(lblDocID.Text);

        //string url = "~/Documents/DistributionWindow.aspx";
        if (userRightsColl.Contains("27")) // Access Right is 4 
        {
            Session["lblText"] = "You are not allowed to Distribute Document.Please contact system Administrator for further inquiry.";
            Session["lblSub"] = "Restricted Access to Distribute Document.";
            Session["lblBody"] = "This is in reference to Restricted Access to Distribute Document. I would like to inquire about the restriction.";

            string url = "RestrictedMsgWindow.aspx";
            string s = "window.open('" + url + "', 'popup_window', 'width=470,height=250,left=100,top=100,resizable=yes,scrollbars=yes');";
            ClientScript.RegisterStartupScript(this.GetType(), "script", s, true);

            //ClientScript.RegisterClientScriptBlock(this.GetType(), "Popup", "<script>alert('You have no privilege to add this Staff')</script>", false);
            //return;
        }
        else
        {
            Session["Dist_docID"] = _docID;
            string url = "DistributionWindow.aspx";
            string s = "window.open('" + url + "', 'popup_window', 'width=800,height=520,left=100,top=100,resizable=yes,scrollbars=yes');";
            ClientScript.RegisterStartupScript(this.GetType(), "script", s, true);
        }
    }
    private string getEndDateByGivenDays(string strDate, int workDays)
    {
        SqlConnection con = new SqlConnection(eBookConn);
        SqlCommand cmd = new SqlCommand();
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Connection = con;

        cmd.CommandText = "AddWorkdays";
        SqlParameter prm = cmd.Parameters.Add("@ad_startDate", SqlDbType.DateTime);
        prm.Value = strDate;
        prm = cmd.Parameters.Add("@actual_workDays", SqlDbType.Int);
        prm.Value = workDays;
        prm = cmd.Parameters.Add("@endDate", SqlDbType.DateTime);
        prm.Direction = ParameterDirection.Output;
        con.Open();
        SqlDataReader dr = cmd.ExecuteReader();
        while (dr.Read())
            Console.WriteLine(dr.GetString(0));
        con.Dispose();
        con.Close();

        return cmd.Parameters[2].Value.ToString();
    }
    protected void btnAddProjAttrib_Click(object sender, EventArgs e)
    {
        //if (lblDocID.Text != "")
        //    _docID = Convert.ToInt32(lblDocID.Text);

        if (Session["SectionID"].ToString() != "13")
        {
            if (ddlContractNo.SelectedIndex != -1)
            {
                IList<string> projectInfoColl = new List<string>();
                projectInfoColl = new JobOrderData().FillDropDownSelectedContractValues(Convert.ToInt32(ddlContractNo.SelectedValue));
                InsertProjectAttributes(projectInfoColl, Convert.ToInt32(ddlContractNo.SelectedValue));
                gridloadForProjectAttributeData(0);
                ddlContractNo.SelectedIndex = 0;
            }
            else if (ddlTenderNo.SelectedIndex != -1)
            {
                IList<string> projectInfoColl = new List<string>();
                projectInfoColl = new JobOrderData().FillDropDownSelectedValues(Convert.ToInt32(ddlTenderNo.SelectedValue));
                InsertProjectAttributes(projectInfoColl, Convert.ToInt32(ddlTenderNo.SelectedValue));
                gridloadForProjectAttributeData(0);
                ddlTenderNo.SelectedIndex = 0;
            }
        }
        if (ddlProjectID.SelectedIndex != -1)
        {
            IList<string> projectInfoColl = new List<string>();
            projectInfoColl = new JobOrderData().FillDropDownSelectedValues(Convert.ToInt32(ddlProjectID.SelectedValue));
            InsertProjectAttributes(projectInfoColl, Convert.ToInt32(ddlProjectID.SelectedValue));
            gridloadForProjectAttributeData(0);
            ddlProjectID.SelectedIndex = 0;
        }

    }
    private void InsertProjectAttributes(IList<string> prjDataColl, int prjID)
    {
        try
        {
            using (SqlConnection cn = new SqlConnection(eBookConn))
            {
                using (SqlCommand sqlCmd = new SqlCommand())
                {
                    sqlCmd.Connection = cn;
                    sqlCmd.CommandType = CommandType.StoredProcedure;
                    sqlCmd.CommandText = "InsertProjectAttributes";

                    sqlCmd.Parameters.AddWithValue("@docID", _docID);
                    sqlCmd.Parameters.AddWithValue("@prjID", prjID);
                    sqlCmd.Parameters.AddWithValue("@contractNo", prjDataColl[3].ToString());
                    sqlCmd.Parameters.AddWithValue("@projectCode", prjDataColl[1].ToString());
                    sqlCmd.Parameters.AddWithValue("@projectTitle", prjDataColl[4].ToString());
                    sqlCmd.Parameters.AddWithValue("@tenderNo", prjDataColl[2].ToString());

                    cn.Open();
                    sqlCmd.ExecuteNonQuery();
                }
            }
        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
    }

    private void InsertDBSValues()
    {
        string insertQuery = string.Empty;
        try
        {
            if (ddlDetailedDBSValues.SelectedIndex != 0)
                insertQuery = "INSERT INTO DBSValuePerDocument(documentID,dbsID) VALUES(" + _docID + "," + ddlDetailedDBSValues.SelectedValue + ")";
            else if (ddlMajorDBSValues.SelectedIndex != 0)
                insertQuery = "INSERT INTO DBSValuePerDocument(documentID,dbsID) VALUES(" + _docID + "," + ddlMajorDBSValues.SelectedValue + ")";
            else
                return;

            using (SqlConnection cn = new SqlConnection(eBookConn))
            {
                using (SqlCommand sqlCmd = new SqlCommand())
                {
                    sqlCmd.Connection = cn;
                    sqlCmd.CommandType = CommandType.Text;
                    sqlCmd.CommandText = insertQuery;
                    cn.Open();
                    sqlCmd.ExecuteNonQuery();
                }
            }
        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
    }

    protected void gvDocProjAttributes_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            //e.Row.Cells[8].Width = new Unit("60px");
            //e.Row.Cells[8].Height = new Unit("60px");
            //e.Row.Cells[8].Wrap = true;

            //LinkButton lnkProjCode = (LinkButton)e.Row.FindControl("projectCode");
            //lnkProjCode.Attributes.Add("onclick", "return viewProjectStages(" + ((HtmlGenericControl)e.Row.FindControl("projId")).InnerText + ")");
            //lnkProjCode.Attributes.Add("onclick", "return viewProjectStages(" + ((HtmlGenericControl)e.Row.FindControl("projId")).InnerText + ")");
        }
    }

    protected void gvDocProjAttributes_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandArgument != "")
        {
            int attributeID = Convert.ToInt32(e.CommandArgument);
            switch (e.CommandName)
            {
                case "DeleteDocid":
                    new JobOrderData().DeleteAttributeData(attributeID);
                    gridloadForProjectAttributeData(0);
                    break;
                //case "projectCode":
                //    new JobOrderData().DeleteAttributeData(attributeID);
                //    gridloadForProjectAttributeData();
                //    break;

            }
        }
    }

    Boolean chkDistributeID = false;
    protected void gvDistribution_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            DropDownList ddlStatus = (DropDownList)e.Row.FindControl("ddljobtype0");

            TextBox txtBoxRemarks = (TextBox)e.Row.FindControl("txtRemarks");

            PopulateDropDownBox(ddlStatus, "SELECT docStatusID,docStatusName as docStatusName FROM DocumentStatus", "docStatusID", "docStatusName", "");  // where JobStatusid in(5,6,7,8)

            //TextBox lm = (TextBox)e.Row.FindControl("jobid0");
            TextBox txtdocStatus = (TextBox)e.Row.FindControl("TextBox1");
            TextBox InchargeID = (TextBox)e.Row.FindControl("jobid0");

            Session["InchargeID"] = InchargeID.Text;


            ddlStatus.ToolTip = InchargeID.Text;

            ddlStatus.SelectedValue = txtdocStatus.Text;

            Session["StatusVal"] = ddlStatus.SelectedValue;

            ddlStatus.SelectedIndexChanged += new EventHandler(SelectedIndexChanged);

            txtBoxRemarks.TextChanged += new EventHandler(TextChanged);

            txtBoxRemarks.ToolTip = InchargeID.Text;

            TextBox txtdate = (TextBox)e.Row.FindControl("lblJoindate");            // ActionDueDate 
            txtdate.ToolTip = InchargeID.Text;
            txtdate.TextChanged += new EventHandler(txtdate_TextChanged);
            Session["JobActionDueDate"] = txtdate.Text;

            Label lblDistribID = (Label)e.Row.FindControl("txtDistributeID");
            TextBox _txtContactID = (TextBox)e.Row.FindControl("txtContactID");
            LinkButton btnDelete = (LinkButton)e.Row.FindControl("btnDelete0");
            Label _lblDateofAction = (Label)e.Row.FindControl("lblDateofAction");

            if (!lblDistribID.Text.Equals(Session["userID"]))
                txtdate.Enabled = false;

            if (!_txtContactID.Text.Equals(Session["userID"]))
                ddlStatus.Enabled = false;
            if (txtdate.Text != "")
            {
                if ((Convert.ToDateTime(txtdate.Text) > System.DateTime.Now) & (_lblDateofAction.Text == "") & (ddlStatus.SelectedValue == "2"))
                {
                    // Update distributio docSttsu as open - 1
                    new JobOrderData().UpdateDocStatus(Convert.ToInt32(InchargeID.Text), Convert.ToInt32(ddlStatus.SelectedValue), _userName);
                }
                if ((Convert.ToDateTime(txtdate.Text) < System.DateTime.Today) & (_lblDateofAction.Text == "") & (ddlStatus.SelectedValue == "2"))
                {
                    e.Row.Cells[4].BackColor = System.Drawing.Color.Red;
                    e.Row.Cells[4].ForeColor = System.Drawing.Color.White;

                    txtdate.ForeColor = System.Drawing.Color.White;
                    txtdate.BackColor = System.Drawing.Color.Red;
                }
            }


            try
            {
                if (_txtContactID.Text.Equals(Session["docCreatedByID"].ToString()))
                    btnDelete.ForeColor = System.Drawing.Color.White;
            }
            catch (Exception ex)
            {

                throw ex;
            }



            if (!userRightsColl.Contains("30"))
            {
                LinkButton l = (LinkButton)e.Row.FindControl("btnDelete0");
                l.Attributes.Add("onclick", "javascript:return " + "confirm('Are you sure you want to delete this Distribution ?')");
                l.CssClass = "btnDelete0";
            }
        }


    }

    protected void SelectedIndexChanged(object sender, EventArgs e)
    {
        DropDownList ddl = (DropDownList)sender;
        if (ddl.SelectedIndex != 0)
        {
            string ID = ddl.ID;
            string g = ddl.SelectedValue;
            int _distrID = Convert.ToInt32(ddl.ToolTip);

            new JobOrderData().UpdateDocStatus(_distrID, Convert.ToInt32(ddl.SelectedValue), _userName);
            //new JobOrderData().UpdateDistributionDateOfAction(_distrID, Convert.ToInt32(ddl.SelectedValue)); 
            fillDataDistribution(_docID);
        }
    }

    protected void TextChanged(object sender, EventArgs e)
    {
        TextBox txtBox = (TextBox)sender;
        if (txtBox.Text != "")
        {
            string gRemarks = txtBox.Text;
            int _distrID = Convert.ToInt32(txtBox.ToolTip);

            new JobOrderData().UpdateDocRemarks(_distrID, gRemarks, _userName);
            //new JobOrderData().UpdateDistributionDateOfAction(_distrID, Convert.ToInt32(ddl.SelectedValue)); 
            fillDataDistribution(_docID);
        }
    }

    int flag = 0;
    protected void gvDistribution_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandArgument != "")
        {
            int distributeID = Convert.ToInt32(e.CommandArgument);
            switch (e.CommandName)
            {
                case "DeleteDocid":
                    if (checkUserExist(distributeID, Convert.ToInt32(Session["docCreatedByID"]), Convert.ToInt32(Session["UserID"])))
                        AccessRightsForDelete(distributeID);

                    if (flag > 0)
                    {
                        //Response.Write("Link Deactivated with Job");
                    }
                    break;
            }
        }
    }
    private void AccessRightsForDelete(int distributeID)
    {
        if (userRightsColl.Contains("30"))   //Add New Project
        {
            Session["lblText"] = "You are not allowed to delete Distribution.Please contact system Administrator for further inquiry.";
            Session["lblSub"] = "Restricted Access to delete Distribution.";
            Session["lblBody"] = "This is in reference to Restricted Access to delete Distribution. I would like to inquire about the restriction.";


            string url = "RestrictedMsgWindow.aspx";
            string s = "window.open('" + url + "', 'popup_window', 'width=500,height=250,left=100,top=100,resizable=yes,scrollbars=yes');";
            ClientScript.RegisterStartupScript(this.GetType(), "script", s, true);
        }
        else
        {
            new JobOrderData().DeleteDistributionInfo(distributeID);
            fillDataDistribution(_docID);
        }
    }
    private Boolean checkUserExist(int distributeID, int createdBy, int currentUserID)
    {
        using (SqlConnection sqlConn = new SqlConnection(eBookConn))
        {
            sqlConn.Open();
            using (SqlCommand sqlCom = new SqlCommand())
            {
                // sqlCom.CommandType = CommandType.StoredProcedure;
                sqlCom.CommandType = CommandType.Text;
                sqlCom.Connection = sqlConn;
                sqlCom.CommandText = "Select contactID,issuedByContactID From DocumentDistribution where distributeID = " + distributeID;

                sqlCom.Parameters.AddWithValue("@docID", _docID);

                using (SqlDataReader sqlReader = sqlCom.ExecuteReader())
                {
                    while (sqlReader.Read())
                    {
                        if ((!sqlReader["contactID"].Equals(createdBy)) & (sqlReader["issuedByContactID"].Equals(currentUserID)))
                            return true;
                    }
                }
            }
        }
        return false;
    }

    protected void txtdate_TextChanged(object sender, EventArgs e)
    {
        TextBox tdate = (TextBox)sender;
        string actionDate = tdate.Text;
        int distID = Convert.ToInt32(tdate.ToolTip);
        // new JobOrderData().UpdateDistributionActionDueDate(Convert.ToInt32(distID), actionDate, getWorkDays(actionDate));

        UpdateDistributionActionDueDate(Convert.ToInt32(distID), actionDate, getWorkDays(actionDate));
        fillDataDistribution(_docID);
    }
    public void UpdateDistributionActionDueDate(int distID, string _actionDate, int workDays)
    {
        using (SqlConnection sqlConn = new SqlConnection(eBookConn))
        {
            sqlConn.Open();
            using (SqlCommand sqlCom = new SqlCommand())
            {
                sqlCom.CommandType = CommandType.Text;
                sqlCom.Connection = sqlConn;
                sqlCom.CommandText = "Update DocumentDistribution Set actionDueDate= @actionDueDate,daysToReply = @daysToReply Where distributeID= " + distID + "";

                sqlCom.Parameters.AddWithValue("@actionDueDate", Convert.ToDateTime(_actionDate).ToString("dd/MMM/yyyy"));
                sqlCom.Parameters.AddWithValue("@daysToReply", workDays);
                sqlCom.Parameters.AddWithValue("@distributeID", distID);

                sqlCom.ExecuteNonQuery();

            }
        }
    }
    public DataTable fillDataDistribution(int _docID)
    {
        DataTable dt = new DataTable();
        try
        {
            DataSet dsMain = new DataSet();
            dsMain = (new JobOrderData().FillDocDistributeData(_docID));
            dt = dsMain.Tables[0];
            gvDistribution.DataSource = dt;
            gvDistribution.DataBind();
        }
        catch (Exception ex)
        {

        }

        return dt;
    }
    private int getWorkDays(string actionDate)
    {
        int _workDays = 0;
        DateTime dateEnd = System.DateTime.Now;
        dateEnd = ConvertToDateTime(actionDate);
        return _workDays = Convert.ToInt32(getDaysByGivenEndDate(System.DateTime.Now.ToString(), dateEnd));
    }
    private string getDaysByGivenEndDate(string strDate, DateTime endDate)
    {
        strDate = Convert.ToDateTime(strDate).ToString("MM/dd/yyyy", CultureInfo.InvariantCulture);
        //endDate = Convert.ToDateTime(endDate).ToString("MM/dd/yyyy", CultureInfo.InvariantCulture);

        //DateTime dt = DateTime.ParseExact(endDate, "d/M/yyyy", null);
        //endDate = dt.ToString("dd/MM/yyyy");

        DateTime strDt = DateTime.ParseExact(strDate, "MM/dd/yyyy", CultureInfo.InvariantCulture);
        //DateTime endDt = DateTime.ParseExact(endDate, "MM/dd/yyyy", CultureInfo.InvariantCulture);

        SqlConnection con = new SqlConnection(eBookConn);
        SqlCommand cmd = new SqlCommand();

        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Connection = con;

        cmd.CommandText = "testSP";

        SqlParameter prm = cmd.Parameters.Add("@ad_startDate", SqlDbType.DateTime);
        prm.Value = strDt;

        prm = cmd.Parameters.Add("@ad_endDate", SqlDbType.DateTime);
        prm.Value = endDate;

        prm = cmd.Parameters.Add("@ai_workDays", SqlDbType.Int);
        prm.Direction = ParameterDirection.Output;

        //prm = cmd.Parameters.Add("@as_errMsg", SqlDbType.VarChar);
        //prm.Direction = ParameterDirection.Output;

        con.Open();
        SqlDataReader dr = cmd.ExecuteReader();
        while (dr.Read())
            Console.WriteLine(dr.GetString(0));
        con.Dispose();
        con.Close();

        return cmd.Parameters[2].Value.ToString();
    }
    private DateTime ConvertToDateTime(string strDateTime)
    {
        DateTime dtFinaldate; string sDateTime;
        try
        {
            //dtFinaldate = Convert.ToDateTime(strDateTime); 

            string[] sDate = strDateTime.Split('/');
            sDateTime = sDate[1] + '/' + sDate[0] + '/' + sDate[2];
            dtFinaldate = Convert.ToDateTime(sDateTime);
        }
        catch (Exception e)
        {
            string[] sDate = strDateTime.Split('/');
            sDateTime = sDate[0] + '/' + sDate[1] + '/' + sDate[2];
            dtFinaldate = Convert.ToDateTime(sDateTime);
        }
        return dtFinaldate;
    }
    protected void gvDBS_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandArgument != "")
        {
            int attributeID = Convert.ToInt32(e.CommandArgument);
            switch (e.CommandName)
            {
                case "DeleteDocid":
                    new JobOrderData().DeleteDBSData(attributeID);
                    gridloadForDBSValues();
                    break;
            }
        }
    }
    private Boolean checkOpenCloseDocumentInJob(int _docID)
    {
        SqlConnection sqlConn = new SqlConnection(eBookConn);
        SqlCommand sqlCom = new SqlCommand();

        try
        {
            sqlConn.Open();
            string strValue = "SELECT  docRefID, closedDocRefID,jobTypeID FROM Job WHERE (docRefID =" + _docID + " ) OR  (closedDocRefID = " + _docID + ")";
            sqlCom = new SqlCommand(strValue, sqlConn);
            SqlDataReader sqlReader = sqlCom.ExecuteReader();
            if (sqlReader.HasRows)
            {
                sqlReader.Read();
                Session["JobTypeID"] = sqlReader["jobTypeID"].ToString();
                return true;
            }

            sqlReader.Close();
            sqlConn.Close();


        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            sqlConn.Close();
        }
        return false;
    }
    private void fillDocumentData(int _docID)
    {
        try
        {
            SqlConnection sqlConn = new SqlConnection(eBookConn);
            sqlConn.Open();


            string strValue = "SELECT distinct [Document].documentID, [Document].docCatID, [Document].docTypeID, [Document].docStatusID, [Document].referenceNo, [Document].crossReferenceNo, " +
                        " CAST(REPLACE(CAST([Document].docSubject AS nvarchar(MAX)), CHAR(13) + CHAR(10), '') AS nvarchar(MAX)) AS docSubject, replace(convert(NVARCHAR, [Document].docDate, 106), ' ', '/') AS docDate, cast([Document].docContent As VARCHAR(350)) As docContent, [Document].importance, " +
                        " [Document].superseded, [Document].originContactID, [Document].originCompanyID, REPLACE(CONVERT(NVARCHAR, [Document].docReceivedDate, 106), ' ', '/') " +
            " AS docReceivedDate, [Document].docCreatedByID, [Document].jobID, [Document].paymentID,Contact.firstName + '  ' + Contact.lastName AS DocCreatedBy, Contact.contactID , [Document].deptCoordEmailID," +
            " Company.cmpShortName,[Document].isEOI,[Document].isPreQual FROM [Document] INNER JOIN Contact ON [Document].docCreatedByID = Contact.contactID join Company on Document.originCompanyID = Company.companyID " +
            " WHERE ([Document].documentID = " + _docID + ")"; //left outer join Department on Contact.deptID=Department.newDeptID left outer join Projects on Department.tcmsDeptID=Projects.department_id

            SqlCommand sqlCom = new SqlCommand(strValue, sqlConn);
            SqlDataReader sqlReader = sqlCom.ExecuteReader();

            if (sqlReader.Read())
            {
                txtDocRefNo.Text = sqlReader["referenceNo"].ToString();
                txtDocDescription.Text = sqlReader["docContent"].ToString();
                txtDocSubject.Text = sqlReader["docSubject"].ToString();
                txtPopupDatepicker.Text = sqlReader["docDate"].ToString();

                //  importance,superseded,originContactID,originCompanyID,docReceivedDate

                ddlCompany.SelectedValue = sqlReader["originCompanyID"].ToString(); // +"," + sqlReader["cmpShortName"].ToString();
                txtRplyDoc.Text = sqlReader["crossReferenceNo"].ToString();

                ddlOriginSender.SelectedValue = sqlReader["originContactID"].ToString() + "," + sqlReader["originCompanyID"].ToString();

                if (Session["SectionID"].ToString() == "13") //13=="TSS Section"
                {
                    FillProjectID();
                }
                else
                {
                    PopulateDropDownBox(ddlProjectID, "SELECT proj_id, project_code FROM TCMS_PROJECTS tp join Department on tp.department_id=Department.tcmsDeptID ORDER BY project_code", "proj_id", "project_code", "Select Project ID to Add");
                }
                Session["originContactID"] = sqlReader["originContactID"].ToString();
                 
                emailID = deptCordEmailID.Text = sqlReader["deptCoordEmailID"].ToString();
                emailIDLblRow.Visible = true;
                emailIDTxtRow.Visible = true;
                emailIDTxtRow.Style.Add("visibility", "visibile");
                dptCoordEmailIDAst.Style.Add("visibility", "visibile");
                emailIDLblRow.Style.Add("visibility", "visibile");
                radioBtns.Visible = true;

                if (sqlReader["isEOI"].ToString()!="" && sqlReader["isEOI"].ToString() == "True")
                {                    
                    eoiRdb.Checked = true;
                    eoiRdb.Disabled = true;
                    eoiRdb.Visible = true;
                    preQualRdb.Checked = false;
                    preQualRdb.Disabled = true;                    
                    Session["JobTypeID"] = "113";
                }
                else if (sqlReader["isPreQual"].ToString() != "" && sqlReader["isPreQual"].ToString() == "True")
                {                    
                    eoiRdb.Checked = false;
                    eoiRdb.Disabled = true;
                    preQualRdb.Checked = true;
                    preQualRdb.Visible = true;
                    preQualRdb.Disabled = true;
                    Session["JobTypeID"] = "114";
                }
                else
                {
                    radioBtns.Visible = false;
                    emailIDLblRow.Visible = false;
                    emailIDTxtRow.Visible = false;
                }          

                txtDateReceived.Text = sqlReader["docReceivedDate"].ToString();
                ddlTypeOfDocs.SelectedValue = sqlReader["docTypeID"].ToString();
                chkSuperseded.Checked = Convert.ToBoolean(sqlReader["superseded"].ToString());
                chkHighImp.Checked = Convert.ToBoolean(sqlReader["importance"].ToString());
                //lblDocID.Text = sqlReader["documentID"].ToString();

                lblDocCatID.Text = sqlReader["docCatID"].ToString();

                lblJobID.Text = sqlReader["jobID"].ToString();
                if (lblJobID.Text.Trim() == "")
                {
                    btnCreateJob.Visible = true;
                }
                else
                {
                    btnCreateJob.Visible = false;
                }

                lblPayID.Text = sqlReader["paymentID"].ToString();

                lblDocCreatedBy.Text = sqlReader["docCreatedByID"].ToString();

                Session["docCreatedByID"] = sqlReader["docCreatedByID"].ToString();

                //if (sqlReader["consultantID"].ToString() != "")
                //    ddlConsultantNo.SelectedValue = sqlReader["consultantID"].ToString();

                if (sqlReader["originContactID"].Equals(sqlReader["docCreatedByID"]))
                    ddlOriginSender.Enabled = false;
                if (sqlReader["docCatID"].Equals("2"))
                    txtDateReceived.Enabled = false;

                if (!_currentUserID.Equals(sqlReader["docCreatedByID"]))
                {
                    if (!Session["UserProfileID"].Equals("1"))
                    {
                        if (userRightsColl.Contains("28"))
                        {
                            btnCreateDoc.Enabled = false;
                        }
                        if (userRightsColl.Contains("29"))
                        {
                            btnDelete.Enabled = false;
                            btnDelete.BackColor = System.Drawing.Color.WhiteSmoke;
                        }
                    }
                }
                if (_profileID.Equals(1) || sqlReader["originContactID"].Equals(_currentUserID) || sqlReader["docCreatedByID"].Equals(_currentUserID))
                {
                    tdSuper.Visible = true;
                    EnableControlsStatusForNonDistribution();
                    btnDelete.Enabled = true;
                    chkSuperseded.Enabled = true;
                }
                else
                {
                    tdSuper.Visible = false;
                    DisableControlsStatusForNonDistribution();
                    btnDelete.Enabled = false;
                    btnDelete.BackColor = System.Drawing.Color.WhiteSmoke;
                    chkSuperseded.Enabled = false;
                }

                lblCreatedByName.Text = "Document Created By : - " + sqlReader["DocCreatedBy"].ToString();
                lblCreatedByName.Visible = true;
            }
            sqlReader.Close();
            sqlConn.Close();
        }
        catch (Exception ex)
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "Error", "<script>alert('Error Occurred while filling the Document Details Web Form')</script>", false);
            //throw ex;
        }

        Session["orginName"] = ddlOriginSender.SelectedItem.Text;
        Session["DocRefNo"] = txtDocRefNo.Text;
    }
    private ArrayList getCurrentDocumentData(int _docID)
    {
        ArrayList docCollLList = new ArrayList();
        using (SqlConnection sqlConn = new SqlConnection(eBookConn))
        {
            sqlConn.Open();
            using (SqlCommand sqlCom = new SqlCommand())
            {
                sqlCom.CommandType = CommandType.StoredProcedure;
                sqlCom.Connection = sqlConn;
                sqlCom.CommandText = "GetDocumentData";

                sqlCom.Parameters.AddWithValue("@docID", _docID);

                using (SqlDataReader sqlReader = sqlCom.ExecuteReader())
                {
                    while (sqlReader.Read())
                    {
                        object[] values = new object[sqlReader.FieldCount];
                        sqlReader.GetValues(values);
                        docCollLList.Add(values);
                    }
                }
            }
        }
        return docCollLList;
    }
    protected void btnDelete_Click(object sender, EventArgs e)
    {
        if ((_profileID.Equals(1)) || (Session["UserID"].ToString().Equals("150")))
        {
            new JobOrderData().DeleteMainDocument(_docID); // DeActivate document 
        }
        else if (userRightsColl.Contains("29") & (!Session["originContactID"].Equals(_currentUserID.ToString())))
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "Popup", "<script>alert('You have no privilege to Delete this document')</script>", false);
            return;
        }
        else if (Session["docCreatedByID"].Equals(_currentUserID.ToString()) || Session["originContactID"].Equals(_currentUserID.ToString()))
            new JobOrderData().DeleteMainDocument(_docID);

        lblDocID.Text = "";

        if (Session["UrlRef"] != null)
            Response.Redirect(Session["UrlRef"].ToString(), false);
        else
            Response.Redirect("~/Documents/ReceiveSentDocuments.aspx", false);
    }
    public Boolean CheckDocLinkedWithJob(int docID)
    {
        using (SqlConnection sqlConn = new SqlConnection(eBookConn))
        {
            sqlConn.Open();
            string strValue = "SELECT  jobID FROM Job  WHERE (docRefID =@docRefID)";

            using (SqlCommand sqlCom = new SqlCommand(strValue, sqlConn))
            {
                sqlCom.Parameters.Add("@docRefID", docID);
                using (SqlDataReader sqlReader = sqlCom.ExecuteReader())
                {
                    while (sqlReader.Read())
                    {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    public Boolean CheckOpenClosedDocExistForJob(int jobID)
    {
        using (SqlConnection sqlConn = new SqlConnection(eBookConn))
        {
            sqlConn.Open();
            string strValue = "SELECT  jobID, docRefID, closedDocRefID FROM Job  WHERE (jobID =@jobID) AND (docRefID =@docRefID) OR   (jobID = @jobID) AND (closedDocRefID =@closedDocRefID)";

            using (SqlCommand sqlCom = new SqlCommand(strValue, sqlConn))
            {
                sqlCom.Parameters.Add("@jobID", jobID);
                sqlCom.Parameters.Add("@docRefID", _docID);
                sqlCom.Parameters.Add("@closedDocRefID", _docID);
                using (SqlDataReader sqlReader = sqlCom.ExecuteReader())
                {
                    while (sqlReader.Read())
                    {
                        return true;
                    }
                }
            }
        }
        return false;
    }
    protected void btnSave_Click(object sender, EventArgs e)
    {


    }
    protected void chkHighImp_CheckedChanged(object sender, EventArgs e)
    {
        if (_docID != 0)
            updateDocumentSuperseeded(_docID);
    }
    protected void chkSuperseded_CheckedChanged(object sender, EventArgs e)
    {
        if (chkSuperseded.Checked == false)
            lblSuperseeded.Visible = false;
        else
            lblSuperseeded.Visible = true;


        if (_docID != 0)
            updateDocumentSuperseeded(_docID);
    }
    private void updateDocumentHighImportance(int _docid)
    {
        using (SqlConnection cn = new SqlConnection(eBookConn))
        {
            using (SqlCommand sqlCmd = new SqlCommand())
            {
                try
                {
                    sqlCmd.CommandType = CommandType.Text;
                    sqlCmd.CommandText = "Update Document set importance =@isImportance where documentid = @docID";
                    sqlCmd.Connection = cn;
                    sqlCmd.Parameters.AddWithValue("@docID", _docid);
                    sqlCmd.Parameters.AddWithValue("@isImportance", (Boolean)chkHighImp.Checked);

                    cn.Open();
                    sqlCmd.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    Response.Write(ex.Message);
                }
            }
        }
    }
    private void updateDocumentSuperseeded(int _docid)
    {
        using (SqlConnection cn = new SqlConnection(eBookConn))
        {
            using (SqlCommand sqlCmd = new SqlCommand())
            {
                try
                {
                    sqlCmd.CommandType = CommandType.Text;
                    sqlCmd.CommandText = "Update Document set superseded =@isSuperseeded where documentid = @docID";
                    sqlCmd.Connection = cn;
                    sqlCmd.Parameters.AddWithValue("@docID", _docid);
                    sqlCmd.Parameters.AddWithValue("@isSuperseeded", (Boolean)chkSuperseded.Checked);
                    cn.Open();
                    sqlCmd.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
        }
    }

    private int getOrginContactID(int _docID)
    {
        int orginID = 0;
        SqlConnection sqlConn = new SqlConnection(eBookConn);
        sqlConn.Open();

        string strValue = "SELECT originContactID From Document WHERE (documentID = " + _docID + ")";

        SqlCommand sqlCom = new SqlCommand(strValue, sqlConn);
        SqlDataReader sqlReader = sqlCom.ExecuteReader();

        while (sqlReader.Read())
        {
            orginID = Convert.ToInt32(sqlReader["originContactID"]);
        }
        sqlReader.Close();
        sqlConn.Close();

        return orginID;
    }
    private void OpenPageByUsingJS(string url, string width, string height)
    {
        string s = "window.open('" + url + "', 'popup_window', 'width=" + width + ",height=" + height + "left=100,top=100,resizable=yes');";
        Page.ClientScript.RegisterStartupScript(this.GetType(), "script", s, true);
    }
    static Boolean isdocRefChanged = false;
    protected void txtDocRefNo_TextChanged(object sender, EventArgs e)
    {
        //// isdocRefChanged = true;

        if (checkDocExist())
        {
            //this.Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('This document reference No was already loaded in the system')</script>", false);

            lblRefNo.Text = "Reference No Exist";

            txtDocRefNo.BackColor = System.Drawing.Color.Pink;
            lblRefNo.ForeColor = System.Drawing.Color.Red;

            // txtDocRefNo.Text = "";

            txtDocRefNo.Text = txtDocRefNo.Text + " - Copy";
            txtDocRefNo.Focus();

            // return;

        }
        else
        {
            lblRefNo.Text = "Document Reference No.";
            txtDocRefNo.BackColor = System.Drawing.Color.White;
            lblRefNo.ForeColor = System.Drawing.Color.Black;
            txtDocSubject.Focus();
        }
    }
    private Boolean checkDocExist()
    {
        string prjTitle = string.Empty;

        using (SqlConnection cnn = new SqlConnection(eBookConn))
        {
            cnn.Open();
            using (SqlCommand cmm = new SqlCommand())
            {
                cmm.Connection = cnn;
                cmm.CommandText = "SELECT referenceNo FROM Document WHERE referenceNo = '" + txtDocRefNo.Text.Trim() + "' ";
                using (SqlDataReader sqlDtReader = cmm.ExecuteReader())
                {
                    if (sqlDtReader.HasRows)
                    {
                        return true;
                    }
                }
            }
        }

        return false;
    }

    protected void btnAddDbs_Click(object sender, EventArgs e)
    {
        if (lblDocID.Text != "")
            _docID = Convert.ToInt32(lblDocID.Text);

        InsertDBSValues();
        gridloadForDBSValues();
    }

    protected void lnkJobNo_Click2(object sender, EventArgs e)
    {
        string strUpdateJob = Request.Url.AbsoluteUri;
        try
        {
            LinkButton lnkJobID = (LinkButton)sender;

            Session["JobID"] = lnkJobID.ToolTip;
            Session["JobCatID"] = txtCatID.Value;

            if (txtCatID.Value.Equals("1"))
            {

                Session["UrlRef"] = "~/JobOrder/PSAJobDetails.aspx";
                Response.Redirect("~/JobOrder/PSAJobDetails.aspx?JobID= " + Session["JobID"] + "", false);
            }
            else if (txtCatID.Value.Equals("2"))
            {
                // Session["UrlRef"] = "~/Payments/PaymentDetails.aspx";
                //Response.Redirect("~/Payments/PaymentDetails.aspx?PayID= " + Session["PayID"] + "", false);

                Session["UrlRef"] = strUpdateJob;
                Response.Redirect("~/Payments/PaymentDetails.aspx?PayID= " + Session["JobID"] + "", false);
            }
            else if (txtCatID.Value.Equals("8"))
            {
                Session["UrlRef"] = "~/DCLog/DCDetails.aspx";
                Response.Redirect("~/DCLog/DCDetails.aspx?JobID= " + Session["JobID"] + "", false);
            }
            else if (Session["SectionID"].ToString().Equals("13"))
            {
                Session["UrlRef"] = "~/TSS/TSSJobDetails.aspx";
                Response.Redirect("~/TSS/TSSJobDetails.aspx?JobID= " + Session["JobID"] + "", false);
            }
            else
            {
                Session["UrlRef"] = "~/JobOrder/DefaultGrid.aspx";
                Response.Redirect("~/JobOrder/DefaultGrid.aspx?JobID= " + Session["JobID"] + "", false);
            }
        }
        catch (Exception ex)
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Error occurred while processing the request')</script>", false);
        }
    }

    #region FileAttchment Functions


    protected void lnkFile_Click(object sender, EventArgs e)
    {
        if (lblDocID.Text != "")
            _docID = Convert.ToInt32(lblDocID.Text);

        if ((Session["File_docID"] == null) || (Session["File_docID"].ToString() == "0") || _docID != 0)
            Session["File_docID"] = _docID;

        //else
        //    return;

        Session["fileType"] = "";
        Session["fileType"] = "F";
        Session["lblCatID"] = lblDocCatID.Text;

        if (Session["SectionID"].ToString().Equals("12") || Session["SectionID"].ToString().Equals("13"))
        {
            Response.Redirect("~/FileUpload.aspx", false);
        }
        else
        {
            //string url = "/eBook/FileUpload.aspx";
            string url = "/eBookTSS/FileUpload.aspx";
            string s = "window.open('" + url + "', 'popup_window', 'width=640,height=520,left=100,top=100,resizable=yes,scrollbars=yes');";
            ClientScript.RegisterStartupScript(this.GetType(), "script", s, true);
        }
    }
    protected void lnkAttachments_Click(object sender, EventArgs e)
    {
        if (lblDocID.Text != "")
            _docID = Convert.ToInt32(lblDocID.Text);

        if ((Session["File_docID"] == null) || (Session["File_docID"] == "0") || _docID != 0)
            Session["File_docID"] = _docID;

        Session["fileType"] = "";
        Session["fileType"] = "A";

        //string url = "/eBook/FileUpload.aspx";
        //string s = "window.open('" + url + "', 'popup_window', 'width=810,height=520,left=100,top=100,resizable=yes,scrollbars=yes');";
        //ClientScript.RegisterStartupScript(this.GetType(), "script", s, true);

        Session["lblCatID"] = lblDocCatID.Text;

        string strUpdateJob = Request.Url.AbsoluteUri;
        Session["UrlRef"] = strUpdateJob;
        Response.Redirect("~/Documents/UploadFiles.aspx", false);

    }
    protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
    {
        if (lblDocID.Text != "")
            _docID = Convert.ToInt32(lblDocID.Text);

        if ((Session["File_docID"] == null) || (Session["File_docID"] == "0") || _docID != 0)
            Session["File_docID"] = _docID;

        Session["fileType"] = "";
        Session["fileType"] = "F";

        string url = "/eBook/FileUpload.aspx";

        string s = "window.open('" + url + "', 'popup_window', 'width=810,height=520,left=100,top=100,resizable=yes,scrollbars=yes');";
        ClientScript.RegisterStartupScript(this.GetType(), "script", s, true);

        // Response.Redirect("~/DocumetAttachments.aspx", false);
    }
    protected void ImageButton2_Click(object sender, ImageClickEventArgs e)
    {
        if (lblDocID.Text != "")
            _docID = Convert.ToInt32(lblDocID.Text);

        if ((Session["File_docID"] == null) || (Session["File_docID"] == "0") || _docID != 0)
            Session["File_docID"] = _docID;

        Session["fileType"] = "";
        Session["fileType"] = "A";


        string url = "/eBook/FileUpload.aspx";
        string s = "window.open('" + url + "', 'popup_window', 'width=810,height=520,left=100,top=100,resizable=yes,scrollbars=yes');";
        ClientScript.RegisterStartupScript(this.GetType(), "script", s, true);

        //string strUpdateJob = Request.Url.AbsoluteUri;
        //Session["UrlRef"] = strUpdateJob;
        //Response.Redirect("~/Documents/UploadFiles.aspx", false);
    }

    #endregion


    #region Not Using Functions


    // ----------------------------------------------------- Not Using -- ------------------------------------------------------------------------------------------------------------------------------------------------------

    public void docReferenceChangeLog(string changeDesc, string windowName, string NewprjCode, string oldPrjCode)
    {
        if (ddlOriginSender.SelectedIndex != 0)
        {
            string upDateQuery = "INSERT INTO CHANGELOG(ChangeData,windowName,oldData,newData,updateUser) VALUES('" + changeDesc + "','" + windowName + "','" + NewprjCode + "','" + oldPrjCode + "', '" + Session["UserDisplayName"].ToString() + "')";
            using (SqlConnection sqlCon = new SqlConnection(eBookConn))
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.CommandText = upDateQuery;
                    cmd.Connection = sqlCon;
                    try
                    {
                        sqlCon.Open();
                        cmd.ExecuteNonQuery();
                    }
                    catch (Exception ex)
                    {
                        Response.Write(ex.Message);
                    }
                }
            }
        }
    }
    private void getData()
    {
        if (!IsPostBack)
        {
            using (SqlConnection scon = new SqlConnection(eBookConn))
            {
                using (SqlCommand scmd = new SqlCommand())
                {
                    string strQuery = "SELECT JobOwner.jobNo, JobStatus.jobStatusName, Section.sectionName, JobType.jobTypeName " +
                    " FROM   JobOwner INNER JOIN  JobStatus ON JobOwner.jobOwnerStatusID = JobStatus.jobStatusID INNER JOIN " +
                    " Section ON JobOwner.sectionID = Section.sectionID INNER JOIN JobType ON JobOwner.jobOwnerCatID = JobType.jobTypeID FULL OUTER JOIN " +
                    " DocumentDistribution ON JobOwner.jobOwnerID = DocumentDistribution.jobOwnerID";

                    scmd.Connection = scon;
                    scmd.CommandType = CommandType.Text;
                    scmd.CommandText = strQuery;
                    scon.Open();
                    SqlDataReader articleReader = scmd.ExecuteReader();

                    StringBuilder htmlTable = new StringBuilder();

                    htmlTable.Append("<table border='1'>");
                    htmlTable.Append("<tr><th>jobNo.</th><th>jobStatusName</th><th>sectionName</th><th>jobTypeName</th></tr>");

                    if (articleReader.HasRows)
                    {
                        while (articleReader.Read())
                        {
                            htmlTable.Append("<tr>");
                            htmlTable.Append("<td>" + articleReader["jobNo"] + "</td>");
                            htmlTable.Append("<td>" + articleReader["jobStatusName"] + "</td>");
                            htmlTable.Append("<td>" + articleReader["sectionName"] + "</td>");
                            htmlTable.Append("<td>" + articleReader["jobTypeName"] + "</td>");
                            htmlTable.Append("</tr>");
                        }
                        htmlTable.Append("</table>");

                        // PlaceHolder1.Controls.Add(new Literal { Text = htmlTable.ToString() });

                        articleReader.Close();
                        articleReader.Dispose();
                    }
                }
            }
        }
    }
    //private void updateDocument(int _docid)
    //{
    //    SqlConnection cn = new SqlConnection(eBookConn);
    //    SqlCommand sqlCmd = new SqlCommand();
    //    sqlCmd.CommandType = CommandType.StoredProcedure;
    //    sqlCmd.CommandText = "UpdateDocument";
    //    sqlCmd.Connection = cn;

    //    sqlCmd.Parameters.AddWithValue("@docDate", Convert.ToDateTime(txtPopupDatepicker.Text).ToString("dd/MMM/yyyy"));
    //    sqlCmd.Parameters.AddWithValue("@docTypeID", ddlTypeOfDocs.SelectedValue);
    //    sqlCmd.Parameters.AddWithValue("@originID", ddlOriginSender.SelectedValue);
    //    sqlCmd.Parameters.AddWithValue("@originCoID", cmpID);
    //    sqlCmd.Parameters.AddWithValue("@referenceNo", txtDocRefNo.Text);
    //    sqlCmd.Parameters.AddWithValue("@docReceivedDate", Convert.ToDateTime(txtDateReceived.Text).ToString("dd/MMM/yyyy"));

    //    if (txtRplyDoc.Text != "")
    //        sqlCmd.Parameters.AddWithValue("@crossReferenceNo", txtRplyDoc.Text);
    //    else
    //        sqlCmd.Parameters.AddWithValue("@crossReferenceNo", System.DBNull.Value);        

    //    sqlCmd.Parameters.AddWithValue("@docSubject", txtDocSubject.Text);
    //    sqlCmd.Parameters.AddWithValue("@docContent", txtDocDescription.Text);

    //    sqlCmd.Parameters.AddWithValue("@docCatID", lblDocCatID.Text);
    //    sqlCmd.Parameters.AddWithValue("@docCreatedByID", Session["UserID"].ToString());

    //    sqlCmd.Parameters.AddWithValue("@updateUser", Session["UserName"].ToString());
    //    sqlCmd.Parameters.AddWithValue("@updateDate ", System.DBNull.Value);    // DateTime.ParseExact(DateTime.Now.ToString("dd/MMM/yyyy HH:mm:ss"), "dd/MMM/yyyy HH:mm:ss", CultureInfo.InvariantCulture)

    //    sqlCmd.Parameters.AddWithValue("@docID", _docID);
    //    sqlCmd.Parameters.AddWithValue("@isImportance", (Boolean)chkHighImp.Checked);
    //    sqlCmd.Parameters.AddWithValue("@isSuperseded", (Boolean)chkSuperseded.Checked);


    //    try
    //    {
    //        cn.Open();
    //        sqlCmd.ExecuteNonQuery();
    //    }
    //    catch (Exception ex)
    //    {
    //        throw ex;
    //    }
    //    finally
    //    {
    //        cn.Close();
    //    }
    //}

    // ----------------------------------------------------- Not Using -- ------------------------------------------------------------------------------------------------------------------------------------------------------

    #endregion
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        lblDocID.Text = "";

        //if (Session["UrlRef"] != null)
        //  Response.Redirect(Session["UrlRef"].ToString(), false);
        //else 
        //  Response.Redirect("~/Documents/ReceiveSentDocuments.aspx", false);

        if (Session["UrlRef"] != null)
            Response.Redirect(Session["UrlRef"].ToString(), false);
        else if ((Session["CmpID"].ToString() != "362"))
            Response.Redirect("~/JobOrder/DefaultWindow.aspx", false);
        else if (Session["SectionID"].Equals("4"))
            Response.Redirect("~/JobOrder/SurveyDefaultWindow.aspx", false);
        else
            Response.Redirect("~/Documents/ReceiveSentDocuments.aspx", false);

        Session["docSender"] = null;
    }
    protected void btnCreateDoc_Click(object sender, EventArgs e)
    {
        // string strUpdateJob = Request.Url.AbsoluteUri;
        // Session["UrlRef"] = strUpdateJob;

        if (Session["UserName"] == null)
        {
            Response.Redirect("~/LoginPage.aspx", false);
            return;
        }

        string keyValue = null;
        if (Request.Cookies["key"] != null)
        {
            keyValue = Request.Cookies["key"].Value;
        }
        //HtmlGenericControl subClick1 = (HtmlGenericControl)this.Form.FindControl("btnAddClickDiv");
        //ClientScript.RegisterClientScriptBlock(this.GetType(), "Popup", "<script>var hdnAddClicked = document.getElementById('hdnAddClick') ;alert(hdnAddClicked)</script>", false);
        if (keyValue == "1")
        {
            if (lblDocID.Text != "")
            {
                _docID = Convert.ToInt32(lblDocID.Text);
            }
            //if(!Session["SectionID"].ToString().Equals("13"))
            //{
            //    emailIDLblRow.Visible = false;
            //    emailIDTxtRow.Visible = false;
            //}       
            if (_docID != 0)
            {

                string newOriginID = ddlOriginSender.SelectedValue.Split(',')[0];
                if (getOrginContactID(_docID) != Convert.ToInt32(newOriginID))
                {
                    UpdateDistributionOrginForIssuedBy(Convert.ToInt32(newOriginID), Convert.ToInt32(Session["originContactID"].ToString()));
                    UpdateDistributionOrginForDistributedTo(Convert.ToInt32(newOriginID), Convert.ToInt32(Session["originContactID"].ToString()));
                }

                if (_profileID.Equals(1) || Session["docCreatedByID"].Equals(_currentUserID.ToString()) || Session["originContactID"].Equals(_currentUserID.ToString()))
                    saveDocument();
                else if (!userRightsColl.Contains("28") & dtDistrUserExist.Rows.Count > 0)  //Check Current user partofDistribution Data
                    saveDocument();

                setFileAttachmentLinksVisibility(true);
                lblCreatedByName.Visible = true;

                //if (Session["UrlRef"] != null)
                //    Response.Redirect(Session["UrlRef"].ToString(), false);
                //else
                //    Response.Redirect("~/Documents/ReceiveSentDocuments.aspx", false);

            }
            else
            {
                if (eoiRdb.Visible == true || preQualRdb.Visible == true)
                {
                    if (!(eoiRdb.Checked == false && preQualRdb.Checked == false))
                    {
                        saveDocFunctions();                        
                    }
                    else
                    {
                        ClientScript.RegisterClientScriptBlock(this.GetType(), "Popup", "<script>alert('Select at least one option among the type of documents.')</script>", false);
                    }
                }
                else
                {
                    saveDocFunctions();
                }
                setFileAttachmentLinksVisibility(true);
                lblCreatedByName.Visible = true;
            }

            btnAddProjAttrib.Enabled = true;
        }
    }

    private void saveDocFunctions()
    {
        saveDocument();

        Session["DocID"] = lblDocID.Text;
        setCreateJobBtnVisibility();
        //btnCreateJob.Visible = true;
        // btnSave.Enabled = true;
        btnDistribute.Enabled = true;
        trDocCreated.Visible = true;

        lnkAttachments.Enabled = true;
        lnkFile.Enabled = true;

        ImageButton1.Enabled = true;
        ImageButton2.Enabled = true;
        fillDocumentData(Int32.Parse(lblDocID.Text));

        btnCreateDoc.Text = "Update Document";
    }

    protected void txtDocSubject_TextChanged(object sender, EventArgs e)
    {

    }

    protected void LinkButton3_Click(object sender, EventArgs e)
    {
        //  \\mv2fileprint

        // D:\Doc_IN\C 2010-87\13384


        // string url = @"C:\Doc_IN\C2010-110";

        // string url = "\\ebsd-sreedhar\\Doc_IN";

        // string url = "file://ebsd-vpuchnanda/Doc_In/C 2010-87/13384";

        string url = "file://ebsd-vpuchnanda/Doc_In/C2010-87/13384";

        // string url = "file://ebsd-sreedhar/Doc_In/C2010-111/160002";

        string s = "window.open('" + url + "', 'popup_window', 'width=640,height=520,left=100,top=100,resizable=yes,scrollbars=yes');";
        ClientScript.RegisterStartupScript(this.GetType(), "script", s, true);

        return;

        Session["Path"] = LinkButton3.Text;


        Response.Redirect("~/Documents/OpenFilePath123.aspx", false);



    }
    private IList<string> getJobNO(int docID)
    {
        //return;


        //string queryString = "~/eBook/Documents/OpenFilePath.aspx?path=" + System.Web.HttpUtility.UrlEncode(LinkButton3.Text);


        //string newWin =

        //    "window.open('" + queryString + "');";

        //ClientScript.RegisterStartupScript

        //    (this.GetType(), "pop", newWin, true);

        IList<string> strColl = new List<string>();
        using (SqlConnection cnn = new SqlConnection(eBookConn))
        {
            cnn.Open();
            using (SqlCommand cmm = new SqlCommand())
            {
                cmm.Connection = cnn;
                cmm.CommandText = "SELECT contractNo,JobNo  FROM Job WHERE docRefID = " + docID + " ";
                using (SqlDataReader sqlDtReader = cmm.ExecuteReader())
                {
                    if (sqlDtReader.HasRows)
                    {
                        while (sqlDtReader.Read())
                        {
                            strColl.Add(sqlDtReader["contractNo"].ToString());
                            strColl.Add(sqlDtReader["JobNo"].ToString());
                        }
                    }
                }
            }
        }

        return strColl;
    }


    private void testCode()
    {
        IList<string> jobDatColl = getJobNO(_docID);

        if (jobDatColl.Count > 0)
        {
            string strDrive = "X:\\";        // string strDrive = "C:\\"; 

            string strIn = "Doc_In";

            //  string strDrive = "file:///X:/Doc_In/C2010-92/151069
            ///
            string cntrNo = jobDatColl[0]; string jobNo = jobDatColl[1];



            string result = cntrNo.Replace(@"/", "-");

            string strPath_ = strDrive + strIn + "\\" + result + "\\" + jobNo;
            NetworkCredential theNetworkCredential = new NetworkCredential(@"Ashghal\ebsd_svadakapuram", "Spandana@008");
            CredentialCache theNetCache = new CredentialCache();
            theNetCache.Add(new Uri(@"\\ebsd-sreedhar"), "Basic", theNetworkCredential);
            //string[] theFolders = Directory.GetDirectories(strPath_);
            //LinkButton3.Text = theFolders[0].ToString();

            LinkButton3.Text = strPath_;
        }
        else
        {
            LinkButton3.Text = "Link_Not_Found";
        }
    }

    private void testCode_New()
    {
        IList<string> jobDatColl = getJobNO(_docID);

        if (jobDatColl.Count > 0)
        {
            string strDrive = "C:\\"; string strIn = "Doc_In";
            string cntrNo = jobDatColl[0]; string jobNo = jobDatColl[1];

            string result = cntrNo.Replace(@"/", "-");

            string strPath_ = strDrive + strIn + "\\" + result + "\\" + jobNo;
            NetworkCredential theNetworkCredential = new NetworkCredential(@"Ashghal\ebsd_svadakapuram", "Spandana@008");
            CredentialCache theNetCache = new CredentialCache();
            theNetCache.Add(new Uri(@"\\ebsd-sreedhar"), "Basic", theNetworkCredential);
            //string[] theFolders = Directory.GetDirectories(strPath_);
            //LinkButton3.Text = theFolders[0].ToString();

            LinkButton3.Text = strPath_;
        }
        else
        {
            LinkButton3.Text = "Link_Not_Found";
        }
    }
    //protected void txtDocRefNo_Unload(object sender, EventArgs e)
    //{
    //    LinkButton3.Text = "Link_Not_Found Now";
    //}
    protected void btnCreateJob_Click(object sender, EventArgs e)
    {
        //if (gvDocProjAttributes.Rows.Count > 0)
        //{
        //    getContractData();
        //}

        string strUpdateJob = Request.Url.AbsoluteUri;
        Session["UrlRef"] = strUpdateJob;
        //Session["UrlRef"] = "~/Documents/DocumentDetailsWindow.aspx"; ;

        Session["CreateJobID"] = "";
        Session["CreateJobID"] = lblDocID.Text;

        if (userRightsColl.Contains("2"))   //Add New Project
        {
            Session["lblText"] = "You are not allowed to Add New Job Order.Please contact system Administrator for further inquiry.";
            Session["lblSub"] = "Restricted Access to Add New Job Order.";
            Session["lblBody"] = "This is in reference to Restricted Access to Add New Job Order. I would like to inquire about the restriction.";

            string url = "/ebookTSS/JobOrder/RestrictedMsgWindow.aspx";
            string s = "window.open('" + url + "', 'popup_window', 'width=500,height=250,left=100,top=100,resizable=yes,scrollbars=yes');";
            ClientScript.RegisterStartupScript(this.GetType(), "script", s, true);
        }
        else if (Session["SectionID"].ToString().Equals("2"))
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "Popup", "<script>alert('This is not applicable to all employees from EBSD Payment Section.')</script>", false);
            return;
        }
        else
        {
            if (Session["SectionID"].Equals("12"))
            {
                Response.Redirect("~/Contracts/CreateClaim.aspx");
            }
            else if (Session["SectionID"].Equals("13"))
            {
                //ddlCompany.SelectedValue
                Session["DocID"] = _docID;
                Response.Redirect("~/TSS/CreateTSSJob.aspx");
            }
            else
            {
                string url = "NewJob.aspx";
                string s = "window.open('" + url + "', 'popup_window', 'width=990,height=700,left=100,top=100,resizable=yes,scrollbars=yes');";
                ClientScript.RegisterStartupScript(this.GetType(), "script", s, true);
            }
        }
    }
    private void getContractData()
    {
        string sqlQuery = "SELECT documentID, contractNo, projectCode, tenderNo, projectTitle, docAtttributeID, projectID FROM  DocumentProjectAttributes WHERE (documentID = " + lblDocID.Text + ") AND (contractNo <> N'')";

        using (SqlConnection cnn = new SqlConnection(eBookConn))
        {
            cnn.Open();
            using (SqlCommand cmm = new SqlCommand())
            {
                cmm.Connection = cnn;
                cmm.CommandText = sqlQuery;
                using (SqlDataReader sqlDtReader = cmm.ExecuteReader())
                {
                    if (sqlDtReader.HasRows)
                    {
                        while (sqlDtReader.Read())
                        {
                            Session["ContractNo"] = sqlDtReader["contractNo"].ToString();
                        }
                    }
                }
            }
        }
    }

    protected void btnBack_Click(object sender, EventArgs e)
    {
        try
        {
            if (Session["UserName"] == null)
            {
                Response.Redirect("~/LoginPage.aspx", false);
                return;
            }
            Response.Redirect(Session["UrlRef"].ToString());
        }
        catch (Exception)
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Error occurred while navigating to previously visited page')</script>", false);
        }        
    }
    protected void imgOriginSenderRefresh_Click(object sender, ImageClickEventArgs e)
    {
        ddlOriginSender.Items.Clear();
        ddlCompany.SelectedIndex = -1;
        FillOriginSenderDDL();
    }
    //protected void imgCompanyRefresh_Click(object sender, ImageClickEventArgs e)
    //{

    //}
}