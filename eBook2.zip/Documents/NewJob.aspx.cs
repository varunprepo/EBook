﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
using PropertyLayer;
using Datalayer;
using System.Globalization;
using System.Text;
using System.IO;


public partial class Documents_NewJob : System.Web.UI.Page
{
    string connValue = System.Configuration.ConfigurationManager.ConnectionStrings["EBSDEBookConn"].ConnectionString;
    private SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["EBSDEBookConn"].ConnectionString);
    string _userProfile = string.Empty;
    string _userDisplayName = string.Empty;
   
    int _jobID = 0;
    //static int jobdocID = 0;

     int jobdocID = 0;
     int teamleadID = 0;
    JobOrderProperty x = new JobOrderProperty();
    protected void Page_Load(object sender, EventArgs e)    
    {
        if (Session["UserName"] == null)
        {
            Response.Redirect("~/LoginPage.aspx", false);
            return;
        }

        _jobID = Convert.ToInt32(Request.QueryString["JobID"]);
        teamleadID = Convert.ToInt32(Session["teamLeaderID"]);
        
        if (!IsPostBack)
        {
            FillDropBox();
            txtRecDate.Text = System.DateTime.Now.ToString();

            //_userProfile = Session["ProfileName"].ToString();
            //_userDisplayName = Session["UserDisplayName"].ToString();
            //_userID = Convert.ToInt32(Session["userID"]);

            ddlGrade.SelectedIndex = 2;
            txtWorkDays.Text = "7";
            WorkingDaysCaluclationByGrade(txtRecDate.Text);

            trtxtCmtee.Visible = false;
            trtxtPrjID.Visible = false;
            trtxtTndrNo.Visible = false;

            FillDropBoxForDocument();
            Panel1.Visible = false;
            disableJobControls();

            if (teamleadID == 6)
            {
                ddlInchargeType.SelectedValue = "4";
                ddlJobPurpose.SelectedValue = "1";
            }

            // Newly Added Job 2017

            //if (Session["CreateJobID"] != null)
            //{
            //    ddlDocRef.SelectedValue = Session["CreateJobID"].ToString();

            //    //if (Session["ContractNo"] != null)
            //    //{
            //    //    txtJobNo0.Text = Session["ContractNo"].ToString();                   
            //    //    string payFor = ddlCommitNo.Items.FindByText(txtJobNo0.Text).Value;
            //    //    ddlCommitNo.SelectedValue = payFor;
            //    //    contractColl = new JobOrderData().getVendorData(Convert.ToInt32(ddlCommitNo.SelectedItem.Value));
            //    //    Session["sessprjColl"] = contractColl;
            //    //    txtPrjTitle.Text = contractColl[0];
            //    //    ddlVendor.SelectedValue = contractColl[4];
            //    //    ddlPrjCode.SelectedIndex = 0;
            //    //    ddlTndrNo.SelectedIndex = 0;
            //    //    trtxtCmtee.Visible = false;
            //    //    Session["TCMS_CntrTypeID"] = contractColl[11];
            //    //}
            //}
        }       
    }    
    private void enableJobControls()
    {
        txtAddendum.Enabled = true;
        txtCmtNo.Enabled = true;
        txtDateReceived.Enabled = true;

        txtDocRefNo.Enabled = true;
        txtDocSubject.Enabled = true;
        txtDueDate123.Enabled = true;

        txtJobNo.Enabled = true;
        txtJobTitle.Enabled = true;

        txtPrjNo.Enabled = true;
        txtPrjTitle.Enabled = true;

        txtRecDate.Enabled = true;

        txtTndrNo.Enabled = true;
        txtWorkDays.Enabled = true;

        ddlCommitNo.Enabled = true;
        ddlDept.Enabled = true;

        ddlDocRef.Enabled = true;
        ddlGrade.Enabled = true;

        ddlInchargeType.Enabled = true;      

        ddlJobPurpose.Enabled = true;
        ddlJobType.Enabled = true;

        ddlPrjCode.Enabled = true;
        ddlTndrNo.Enabled = true;
        ddlVendor.Enabled = true; 
    }
    private void disableJobControls()
    {
        txtAddendum.Enabled = false;
        txtCmtNo.Enabled = false;


        //txtDateReceived.Enabled = false;

       // txtDocRefNo.Enabled = false;
        //txtDocSubject.Enabled = false;

        txtDueDate123.Enabled = false;

        txtJobNo.Enabled = false;
        txtJobTitle.Enabled = false;

        txtPrjNo.Enabled = false;
        txtPrjTitle.Enabled = false;

        txtRecDate.Enabled = false;

        txtTndrNo.Enabled = false;
        txtWorkDays.Enabled = false;

        ddlCommitNo.Enabled = false;
        ddlDept.Enabled = false;

        ddlDocRef.Enabled = false;
        ddlGrade.Enabled = false;

        ddlInchargeType.Enabled = false;      

        ddlJobPurpose.Enabled = false;
        ddlJobType.Enabled = false;

        ddlPrjCode.Enabled = false;
        ddlTndrNo.Enabled = false;
        ddlVendor.Enabled = false; 
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        Panel1.Visible = true;
        Panel2.Visible = false;

        trUpload.Visible = false;
        trgrid.Visible = false;

        txtPopupDatepicker.Text = System.DateTime.Now.ToString("dd/MMM/yyyy");
        txtDateReceived.Text = System.DateTime.Now.ToString("dd/MMM/yyyy");

       // Response.Redirect("~/Documents/DocumentDetailsWindow.aspx", false);
    }
    static DataTable dtDocument = new DataTable();
    protected void Button2_Click(object sender, EventArgs e)
    {
        if (lblJobDocID.Text == "")
          addDocument();

        btnSaveJobDoc.Enabled = false;
    }
    private void addDocument()
    {
        jobdocID = 0;

        jobdocID = InsertJobDocumentData();

        lblJobDocID.Text = jobdocID.ToString(); 

        Session["Dist_docID"] = lblJobDocID.Text;
        PopulateDropDownBox(ddlDocRef, "SELECT [Document].documentID, [Document].referenceNo, Job.jobID FROM Job RIGHT OUTER JOIN  [Document] ON Job.docRefID = [Document].documentID  WHERE ([Document].paymentID IS NULL) and (Document.jobID IS NULL) ORDER BY [Document].createDate", "documentID", "referenceNo");

       // ddlDocRef.SelectedValue = jobdocID.ToString();

        if ((ddlDocRef.SelectedValue != ""))
        {
            Session["DocRecDate"] = getDocReceivedDate(Convert.ToInt32(ddlDocRef.SelectedValue));
            txtRecDate.Text = getDocReceivedDate(Convert.ToInt32(ddlDocRef.SelectedValue));

            WorkingDaysCaluclationByGrade(txtRecDate.Text);
        }
        else if  (ddlDocRef.SelectedItem.Text != "")
        {
            Session["DocRecDate"] = getDocReceivedDate(Convert.ToInt32(ddlDocRef.SelectedItem.Value));
            txtRecDate.Text = getDocReceivedDate(Convert.ToInt32(ddlDocRef.SelectedItem.Value));

            WorkingDaysCaluclationByGrade(txtRecDate.Text);
        }
        else
        {
            txtRecDate.Text = System.DateTime.Now.ToString();
        } 
    }
    private void fillTable()
    {
        dtDocument.Clear();
        dtDocument.Columns.Add("docDate");
        dtDocument.Columns.Add("originID");
        dtDocument.Columns.Add("referenceNo");
        dtDocument.Columns.Add("docReceivedDate");
        dtDocument.Columns.Add("docSubject");

        DataRow drValue = dtDocument.NewRow();
        drValue["docDate"] = DateTime.ParseExact(txtPopupDatepicker.Text, "dd/MMM/yyyy", CultureInfo.InvariantCulture);
        drValue["originID"] = ddlOriginSender.SelectedValue;
        drValue["referenceNo"] = txtDocRefNo.Text;
        drValue["docReceivedDate"] = DateTime.ParseExact(txtDateReceived.Text, "dd/MMM/yyyy", CultureInfo.InvariantCulture);
        drValue["docSubject"] = txtDocSubject.Text;
        dtDocument.Rows.Add(drValue); 
    }
    private int InsertJobDocumentData()
    {
        int _cmpID =  getCompanyID(Convert.ToInt32(ddlOriginSender.SelectedValue));
        

        SqlConnection cn = new SqlConnection(connValue);
        SqlCommand sqlCmd = new SqlCommand();
        sqlCmd.CommandType = CommandType.StoredProcedure;
        sqlCmd.CommandText = "sp_InsertDocument";
        sqlCmd.Connection = cn;

        sqlCmd.Parameters.AddWithValue("@docDate", Convert.ToDateTime(txtPopupDatepicker.Text).ToString("dd/MMM/yyyy"));

        //sqlCmd.Parameters.AddWithValue("@docDate", DateTime.ParseExact(txtPopupDatepicker.Text, "dd/MMM/yyyy", CultureInfo.InvariantCulture));
        sqlCmd.Parameters.AddWithValue("@docTypeID", 1); // Job Order
        sqlCmd.Parameters.AddWithValue("@originID", ddlOriginSender.SelectedValue);
        sqlCmd.Parameters.AddWithValue("@originCoID", _cmpID);
        sqlCmd.Parameters.AddWithValue("@referenceNo", txtDocRefNo.Text);
        sqlCmd.Parameters.AddWithValue("@docReceivedDate", Convert.ToDateTime(txtDateReceived.Text).ToString("dd/MMM/yyyy"));


       // sqlCmd.Parameters.AddWithValue("@docReceivedDate", DateTime.ParseExact(txtDateReceived.Text, "dd/MMM/yyyy", CultureInfo.InvariantCulture));
        sqlCmd.Parameters.AddWithValue("@crossReferenceNo", System.DBNull.Value);

        sqlCmd.Parameters.AddWithValue("@docSubject", txtDocSubject.Text);
        sqlCmd.Parameters.AddWithValue("@docContent", System.DBNull.Value);

        sqlCmd.Parameters.AddWithValue("@docCatID", 1); // Receive 
        sqlCmd.Parameters.AddWithValue("@docCreatedByID", Session["UserID"].ToString());

        sqlCmd.Parameters.AddWithValue("@createUser", Session["UserName"].ToString());
        

        sqlCmd.Parameters.AddWithValue("@docID", SqlDbType.SmallInt).Direction = ParameterDirection.Output;
        //string actionDueDate = getEndDateByGivenDays(txtDateReceived.Text, 1);
        sqlCmd.Parameters.AddWithValue("@actionDueDate", System.DBNull.Value);
        sqlCmd.Parameters.AddWithValue("@isImportance", 0);
        sqlCmd.Parameters.AddWithValue("@isSuperseded", 0);

        sqlCmd.Parameters.AddWithValue("@jobID", System.DBNull.Value);

        //Session["originContactID"] = ddlOriginSender.SelectedValue;
        //Session["docCreatedByID"] = Session["UserID"].ToString();

        if (Session["PayID"] == null)
            sqlCmd.Parameters.AddWithValue("@payID", System.DBNull.Value);
        else
            sqlCmd.Parameters.AddWithValue("@payID", Convert.ToInt32(Session["PayID"]));
        

        try
        {
            cn.Open();
            sqlCmd.ExecuteNonQuery();

            Response.Write("Document Added SuccessFully!");

            Label1.Text = "Document Added";
        }
        catch (Exception ex)
        {
           // throw ex;

            Response.Write(ex.Message);
        }
        finally
        {
            cn.Close();
        }

        return (int)sqlCmd.Parameters["@docID"].Value;
    }
    private string getEndDateByGivenDays(string strDate,int workDays)
    {
        SqlConnection con = new SqlConnection(connValue);
        SqlCommand cmd = new SqlCommand();
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Connection = con;

        cmd.CommandText = "AddWorkdays";
        SqlParameter prm = cmd.Parameters.Add("@ad_startDate", SqlDbType.DateTime);
        prm.Value = strDate;
        prm = cmd.Parameters.Add("@actual_workDays", SqlDbType.Int);
        prm.Value = workDays;
        prm = cmd.Parameters.Add("@endDate", SqlDbType.DateTime);
        prm.Direction = ParameterDirection.Output;
        con.Open();
        SqlDataReader dr = cmd.ExecuteReader();
        while (dr.Read())
            Console.WriteLine(dr.GetString(0));
        con.Dispose();
        con.Close();

        return cmd.Parameters[2].Value.ToString();
    }
    private int getCompanyID(int contactID)
    {
        int CmpID = 0;
        SqlConnection sqlConn = new SqlConnection(connValue);
        string sqlQuery = "SELECT companyID From Contact where contactID = " + contactID + "";

        try
        {
            sqlConn.Open();
            SqlCommand sqlCom = new SqlCommand(sqlQuery, sqlConn);
            SqlDataReader sqlReader = sqlCom.ExecuteReader();
            while (sqlReader.Read())
            {
                CmpID =  Convert.ToInt32(sqlReader["companyID"]);
            }
            sqlReader.Close();
        }
        catch (Exception ex)
        {
            // Response.Write("Error getting while reading data !" + ex.Message);
        }
        finally
        {
            sqlConn.Close();
        }
        return CmpID;
    }
    protected void btnCancelDoc_Click(object sender, EventArgs e)
    {

    }
    protected void Button3_Click(object sender, EventArgs e)
    {
        if (CheckFileExist())
        {
            Panel2.Visible = true;
            Panel1.Visible = false;
        }
        else
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "Popup", "<script>alert('Please attach the file.')</script>", false);
        }
    }
    protected void txtPrjID_TextChanged(object sender, EventArgs e)
    {

    }
    protected void txtTndrNo_TextChanged(object sender, EventArgs e)
    {

    }

    # region


    private void CheckDropdown()
    {
        if (ddlDept.SelectedIndex == -1)
        {
            Response.Write("Please Select Department ");
            return;
        }
        if (ddlPrjCode.SelectedIndex == -1)
        {
            Response.Write("Please Select Project Code");
            return;
        }
        if (ddlInchargeType.SelectedIndex == -1)
        {
            Response.Write("Please Select Contract Type");
            return;
        }
        if (ddlVendor.SelectedIndex == -1)
        {
            Response.Write("Please Select Vendor ");
            return;
        }
        if (ddlVendor.SelectedIndex == -1)
        {
            Response.Write("Please Select Consultant ");
            return;
        }
    }
    private void FillDropBox()
    {
        PopulateDropDownBox(ddlInchargeType, "SELECT jobOwnerCatID, jobOwnerCategory FROM  JobOwnerCategory ORDER BY jobOwnerCatID", "jobOwnerCatID", "jobOwnerCategory");
        
        int sectionID = Convert.ToInt32(Session["SectionID"]);

        if (sectionID == 1)   // All Section 
        {
            FillCombo(ddlJobCat, "jobTypeID", "JobTypeName", ExecuteQuery("SELECT jobTypeID,JobTypeName FROM JobType Where jobTypeID In(1,3,4,5,6,7,60,61) order by JobTypeName"), false);
            // ddlJobCat.Items.Insert(0, new ListItem("--Select--"));
        }
        else if (sectionID == 2)   // Payment
        {
            FillCombo(ddlJobCat, "jobTypeID", "JobTypeName", ExecuteQuery("SELECT jobTypeID,JobTypeName FROM JobType Where jobTypeID In(1,3,4,5,6,7) order by JobTypeName"), false);
            // ddlJobCat.Items.Insert(0, new ListItem("--Select--"));
        }       
        else
        {
            FillCombo(ddlJobCat, "jobTypeID", "JobTypeName", ExecuteQuery("SELECT jobTypeID,JobTypeName FROM JobType  Where jobTypeID In(1,3,4,5,6,7)  order by JobTypeName"), false);

            // FillCombo(ddlJobCat, "jobTypeID", "JobTypeName", ExecuteQuery("SELECT jobTypeID,JobTypeName FROM JobType where sectionID =" + sectionID + " order by JobTypeName"), false);
            if (sectionID == 3) // documentController
            {
                // ddlJobCat.SelectedValue = "8";
                //  ddlJobCat.SelectedIndex = 1;
                ddlInchargeType.SelectedValue = "4";              
            }
        }
        PopulateDropDownBox(ddlDept, "SELECT departmentID, deptName FROM  Department where affairID is not null ORDER BY deptName ", "departmentID", "deptName");

       //  string strQuery = "SELECT  [Document].documentID, [Document].referenceNo, Job.jobID, [Document].paymentID, [Document].createDate FROM  Job RIGHT OUTER JOIN    [Document] ON Job.docRefID = [Document].documentID WHERE  ([Document].jobID IS NULL) AND ([Document].paymentID IS NULL) ORDER BY [Document].createDate";

        string strQuery = "SELECT [Document].documentID, [Document].referenceNo, Job.jobID, [Document].paymentID, [Document].createDate, [Document].docCreatedByID, Contact.firstName, " +
                        " Contact.sectionID FROM   [Document] INNER JOIN  Contact ON [Document].docCreatedByID = Contact.contactID LEFT OUTER JOIN   Job ON [Document].documentID = Job.docRefID " +
                          " WHERE ([Document].jobID IS NULL) AND ([Document].paymentID IS NULL) AND (Contact.sectionID Not in(2,3)) ORDER BY [Document].createDate";

        PopulateDropDownBox(ddlDocRef, strQuery, "documentID", "referenceNo");

        //PopulateDropDownBox(ddlJobType, "SELECT jobTypeID, jobTypeName FROM JobType where jobTypeID not in(18,19,20,21,22,23,24,25) ORDER BY jobTypeID", "jobTypeID", "jobTypeName");
        PopulateDropDownBox(ddlJobPurpose, "SELECT jobPurposeID, jobPurposeName FROM  JobPurpose ORDER BY jobPurposeName", "jobPurposeID", "jobPurposeName");


        PopulateDropDownBox_TCMS(ddlPrjCode, "SELECT  proj_id, project_code FROM  PROJECTS ORDER BY project_code", "proj_id", "project_code");
        PopulateDropDownBox_TCMS(ddlTndrNo, "SELECT  proj_id, tender_no FROM PROJECTS WHERE (tender_no IS NOT NULL)  ORDER BY tender_no", "proj_id", "tender_no");
        PopulateDropDownBox_TCMS(ddlCommitNo, "SELECT bidder_ID,Contract_No FROM CONTRACTORS WHERE (Contract_No IS NOT NULL) and (Contract_No != '')  ORDER BY Contract_No", "bidder_ID", "Contract_No");

        PopulateDropDownBox_TCMS(ddlVendor, "SELECT co_id, co_name FROM Company ORDER BY co_name", "co_id", "co_name");
    }
    public static void FillCombo(DropDownList dropDownList, string dataValueField, string dataTextField, DataTable dataTbl, bool bHasBlank)
    {
        dropDownList.DataTextField = dataTextField;
        dropDownList.DataValueField = dataValueField;
        dropDownList.DataSource = dataTbl;
        dropDownList.DataBind();

        ListItem emptyItem = new ListItem("", "");
        dropDownList.Items.Insert(0, emptyItem);

        //if (bHasBlank)
        //    dropDownList.Items.Insert(0, new ListItem());
    }

    public static DataTable ExecuteQuery(string SQLstring)
    {
        string sConstr = ConfigurationManager.ConnectionStrings["EBSDEBookConn"].ConnectionString;
        SqlConnection Conn = new SqlConnection(sConstr);
        DataTable dt = new DataTable("tbl");

        using (Conn)
        {
            Conn.Open();
            SqlCommand comm = new SqlCommand(SQLstring, Conn);
            comm.CommandTimeout = 0;
            SqlDataAdapter da = new SqlDataAdapter(comm);
            da.Fill(dt);
        }
        return dt;
    }
    private void PopulateDropDownBox(DropDownList ddlBox, string sqlQuery, string valueMember, string displayName)
    {
        ddlBox.DataBound += new EventHandler(this.ddlBox_DataBound);
        ddlBox.DataSource = new JobOrderData().FillDropdown(sqlQuery);
        ddlBox.DataTextField = displayName;
        ddlBox.DataValueField = valueMember;
        ddlBox.SelectedIndex = -1;
        ddlBox.DataBind();
    }
    protected void ddlBox_DataBound(object sender, EventArgs e)
    {
        DropDownList ddl = (DropDownList)sender;
        ListItem emptyItem = new ListItem("", "");
        ddl.Items.Insert(0, emptyItem);
    }
    private void PopulateDropDownBox_TCMS(DropDownList ddlBox, string sqlQuery, string valueMember, string displayName)
    {
        ddlBox.DataBound += new EventHandler(this.ddlBox_DataBound);
        ddlBox.DataSource = new JobOrderData().FillDropdown_TCMS(sqlQuery);
        ddlBox.DataTextField = displayName;
        ddlBox.DataValueField = valueMember;
        ddlBox.SelectedIndex = -1;
        ddlBox.DataBind();
    }
    protected void btnSave_Click(object sender, EventArgs e)
    {
        //FillDropdown(); 
        InsertNewJobOrder();

        string script = "this.window.opener.location=this.window.opener.location;this.window.close();";
        if (!ClientScript.IsClientScriptBlockRegistered("REFRESH_PARENT"))
            ClientScript.RegisterClientScriptBlock(typeof(string), "REFRESH_PARENT", script, true);

    }
    JobOrderProperty _addJob = new JobOrderProperty();
    private Boolean ValidateControls()
    {
        Boolean chkCntrl = true;
        if (txtJobNo.Text == "")
        {
            // Response.Write("<script language='javascript'>alert('Please Enter JobNo');</script>");
            chkCntrl = false;
        }
        if (ddlJobCat.SelectedIndex == -1)
        {
            // Response.Write("<script language='javascript'>alert('Please Select Category');</script>");
            chkCntrl = false;
        }
        if (ddlDocRef.SelectedIndex == -1)
        {
            //Response.Write("<script language='javascript'>alert('Please Select DocRef');</script>");
            chkCntrl = false;
        }
        if (ddlInchargeType.SelectedIndex == -1)
        {
            // Response.Write("<script language='javascript'>alert('Please Select Job Assignment');</script>");
            chkCntrl = false;
        }
        if (ddlJobPurpose.SelectedIndex == -1)
        {
            // Response.Write("<script language='javascript'>alert('Please Select Job Purpose');</script>");
            chkCntrl = false;
        }
        if (txtPrjTitle.Text == "")
        {
            // Response.Write("<script language='javascript'>alert('Please Select Project Title');</script>");
            chkCntrl = false;
            txtPrjTitle.Focus();
        }
        if (txtDueDate123.Text == "")
        {
            // Response.Write("<script language='javascript'>alert('Please Select Project Title');</script>");
            chkCntrl = false;
            txtDueDate123.Focus();
        }
        return chkCntrl;
    }
    private void InsertNewJobOrder()
    {
        if (!ValidateControls())
            return;

        string docRecDate = string.Empty; IList<string> userInfoColl = new List<string>();

      //  int maxJobID = new JobOrderData().getMaxJobID() + 1;

        int docID = Convert.ToInt32(ddlDocRef.SelectedValue);

       _jobID =  PassJobOrderData(docID);

        //new JobOrderData().DeleteDuplicateDataFromDistribution(_jobID);
       // int docID = 0;
        IList<int> docIDColl = getDocIDCollection(_jobID);
        foreach (var vardocID in docIDColl)
        {
            CheckandDeleteDistributionData(vardocID);
        }

        AddProject_Attributes(docID); // Add project Attribute jobs 

         // AddProjectAttributes(docID, _addJob.commitmentNo, _addJob.prjCode, _addJob.prjTitle, _addJob.tenderNo);
         // AddBudgetCodes(_jobID, _addJob.commitmentNo);
    }
    private void AddBudgetCodes(int _jobid, string cntrNo)
    {
        List<string> projData = Session["sessprjColl"] as List<string>;

        SqlConnection con = new SqlConnection(connValue);
        SqlCommand sqlCmd = new SqlCommand();
        sqlCmd.CommandType = CommandType.StoredProcedure;
        sqlCmd.Connection = con;
        sqlCmd.CommandText = "InsertBudgetCodes";

        sqlCmd.Parameters.AddWithValue("@jobID", _jobid);

        if ((cntrNo != "") & (cntrNo != null))
            sqlCmd.Parameters.AddWithValue("@contractNo", cntrNo);
        else
            sqlCmd.Parameters.AddWithValue("@contractNo", System.DBNull.Value);

        if (projData != null)
            sqlCmd.Parameters.AddWithValue("@ministryCode", projData[1].ToString());
        else
            sqlCmd.Parameters.AddWithValue("@ministryCode", System.DBNull.Value);

        if (projData != null)
            sqlCmd.Parameters.AddWithValue("@budgetRefNo", projData[2].ToString());
        else
            sqlCmd.Parameters.AddWithValue("@budgetRefNo", System.DBNull.Value);

        if (projData != null)
            sqlCmd.Parameters.AddWithValue("@provisionNo", projData[3].ToString());
        else
            sqlCmd.Parameters.AddWithValue("@provisionNo", System.DBNull.Value);

        if (projData != null)
            sqlCmd.Parameters.AddWithValue("@budgetAmnt", projData[4].ToString());
        else
            sqlCmd.Parameters.AddWithValue("@budgetAmnt", System.DBNull.Value);

        sqlCmd.Parameters.AddWithValue("@createUser", Session["UserName"].ToString());
        sqlCmd.Parameters.AddWithValue("@createDate", System.DateTime.Now.ToString("dd/MMM/yyyy"));

        con.Open();
        sqlCmd.ExecuteNonQuery();
        con.Close();
    }

    private IList<int> getDocIDCollection(int _jobID)
    {
        IList<int> docIDColl = new List<int>();
        try
        {
            SqlConnection sqlConn = new SqlConnection(connValue);
            sqlConn.Open();
            SqlCommand sqlCom = new SqlCommand("Select DocumentID from Document where jobID = " + _jobID + "", sqlConn);
            SqlDataReader sqlReader = sqlCom.ExecuteReader();
            while (sqlReader.Read())
            {
                docIDColl.Add(Convert.ToInt32(sqlReader["DocumentID"]));
            }
            sqlReader.Close();
            sqlConn.Close();
        }
        catch (System.Exception ex)
        {
            throw ex;
        }

        return docIDColl;
    }  


    //private void InsertNewJob()
    //{
    //    if (!ValidateControls())
    //        return;

    //    string docRecDate = string.Empty; IList<string> userInfoColl = new List<string>();

    //    int maxJobID = new JobOrderData().getMaxJobID() + 1;

    //    int docID = Convert.ToInt32(ddlDocRef.SelectedValue);

    //    docCreatedID = new JobOrderData().getDocumentDistributedBy(docID);

    //    docRecDate = getdocReceivedDate(docID);

    //    PassJobOrderData(maxJobID, docRecDate);

    //    userInfoColl = getdocCreatedByInfo(docCreatedID);

    //    int _ownerID = 0;

    //    PassJobInchargeData(maxJobID, docCreatedID, ref _ownerID, docRecDate);

    //    InsertDocDistributionData(_ownerID, maxJobID, docID, docCreatedID, userInfoColl, docRecDate);

    //    //   int distributeID = 0;
    //    //   distributeID = getDistributeData(docID, Convert.ToInt32(Session["UserID"].ToString()));

    //    //if (distributeID==0)
    //    //  InsertDocDistributionData(_ownerID, maxJobID, docID, docCreatedID, userInfoColl, docRecDate);
    //    //else
    //    //    UpdateDocDistributionData(_ownerID, distributeID);

    //    new JobOrderData().UpdateJobForDocument(maxJobID, docID);

    //    AddProjectAttributes(docID, _addJob.commitmentNo, _addJob.prjCode, _addJob.prjTitle, _addJob.tenderNo);
    //}
    private void AddProjectAttributes(int _docID, string cntrNo, string prjNo, string prjTitle, string tndrNo)
    {
        SqlConnection con = new SqlConnection(connValue);
        SqlCommand sqlCmd = new SqlCommand();
        sqlCmd.CommandType = CommandType.StoredProcedure;
        sqlCmd.Connection = con;
        sqlCmd.CommandText = "InsertDocProjectAttributes";

        sqlCmd.Parameters.AddWithValue("@docID", _docID);
        if ((cntrNo != "") & (cntrNo != null))
            sqlCmd.Parameters.AddWithValue("@contractNo", cntrNo);
        else
            sqlCmd.Parameters.AddWithValue("@contractNo", System.DBNull.Value);

        if ((prjNo != "") & (prjNo != null))
            sqlCmd.Parameters.AddWithValue("@projectCode", prjNo);
        else
            sqlCmd.Parameters.AddWithValue("@projectCode", System.DBNull.Value);

        if ((tndrNo != "") & (tndrNo != null))
            sqlCmd.Parameters.AddWithValue("@tenderNo", tndrNo);
        else
            sqlCmd.Parameters.AddWithValue("@tenderNo", System.DBNull.Value);

        sqlCmd.Parameters.AddWithValue("@projectTitle", prjTitle);

        con.Open();
        sqlCmd.ExecuteNonQuery();
        con.Close();
    }

    private string getdocReceivedDate(int docID)
    {
        string strDate = string.Empty;

        SqlConnection sqlConn = new SqlConnection(connValue);
        string sqlQuery = "SELECT docReceivedDate,originContactID From Document where documentID = " + docID + "";

        try
        {
            sqlConn.Open();
            SqlCommand sqlCom = new SqlCommand(sqlQuery, sqlConn);
            SqlDataReader sqlReader = sqlCom.ExecuteReader();
            while (sqlReader.Read())
            {
                strDate = sqlReader[0].ToString();
            }
            sqlReader.Close();
        }
        catch (Exception ex)
        {
            // Response.Write("Error getting while reading data !" + ex.Message);
        }
        finally
        {
            sqlConn.Close();
        }
        return strDate;
    }
    private IList<string> getdocCreatedByInfo(int docCreatedID)
    {
        IList<string> userInfo = new List<string>();

        SqlConnection sqlConn = new SqlConnection(connValue);
        string sqlQuery = "SELECT (firstName + ' ' + lastName) as DisplayName,companyID,emailAddress from Contact where ContactID =" + docCreatedID + "";

        try
        {
            sqlConn.Open();
            SqlCommand sqlCom = new SqlCommand(sqlQuery, sqlConn);
            SqlDataReader sqlReader = sqlCom.ExecuteReader();
            while (sqlReader.Read())
            {
                userInfo.Add(sqlReader[0].ToString());
                userInfo.Add(sqlReader[1].ToString());
                userInfo.Add(sqlReader[2].ToString());
            }
            sqlReader.Close();
        }
        catch (Exception ex)
        {
            // Response.Write("Error getting while reading data !" + ex.Message);
        }
        finally
        {
            sqlConn.Close();
        }
        return userInfo;
    }
    private int getDistributeData(int docID, int CntctID)
    {
        int distDocID = 0;
        SqlConnection sqlConn = new SqlConnection(connValue);
        string sqlQuery = "SELECT contactID, documentID, issuedByContactID, distributeID FROM  DocumentDistribution WHERE (documentID = " + docID + ") AND (contactID = " + CntctID + ")"; //  AND (distributeID = 27)

        try
        {
            sqlConn.Open();
            SqlCommand sqlCom = new SqlCommand(sqlQuery, sqlConn);
            SqlDataReader sqlReader = sqlCom.ExecuteReader();
            while (sqlReader.Read())
            {
                distDocID = Convert.ToInt32(sqlReader["distributeID"]);
            }
            sqlReader.Close();
        }
        catch (Exception ex)
        {
            // Response.Write("Error getting while reading data !" + ex.Message);
        }
        finally
        {
            sqlConn.Close();
        }
        return distDocID;
    }
    
    private void CheckandDeleteDistributionData(int DocID)
    {
        //string sqlQuery = "SELECT  distributeID, docCatID, documentID, contactID FROM  DocumentDistribution WHERE (documentID = " + DocID + ")";

        string sqlQuery = "SELECT documentID, docCatID, distributeID, contactID FROM  DocumentDistribution WHERE   (documentID IN (SELECT documentID FROM  DocumentDistribution AS Tmp  GROUP BY documentID, contactID HAVING   (COUNT(*) > 1) AND (contactID = DocumentDistribution.contactID) AND (documentID = " + DocID + ")))  ORDER BY documentID, docCatID, distributeID";

        DataTable dtDocumentDistribution = GetDataFromDB("DocumentDistribution", sqlQuery);

        if (dtDocumentDistribution.Rows.Count != 0)
            DeleteDistributionData(Convert.ToInt32(dtDocumentDistribution.Rows[0]["distributeID"]));


    }
    public DataTable GetDataFromDB(string dataTabName, string sqlQuery)
    {
        DataTable table = null;
        SqlConnection sqlConn = new SqlConnection(connValue);
        sqlConn.Open();
        SqlDataAdapter sqlDtAdptr = null;
        table = new DataTable(dataTabName);
        sqlDtAdptr = new SqlDataAdapter(@sqlQuery, sqlConn);
        sqlDtAdptr.Fill(table);
        sqlConn.Close();
        return table;
    }
    private void DeleteDistributionData(int documentID)
    {
        string updateSql = "Delete From DocumentDistribution Where distributeID = " + documentID + " ";
        SqlConnection sqlConn = new SqlConnection(connValue);
        SqlCommand cmd = new SqlCommand();
        cmd.CommandText = updateSql;
        cmd.Connection = sqlConn;

        try
        {
            //cmd.Parameters.AddWithValue("@contactID", documentID);   
            sqlConn.Open();
            cmd.ExecuteNonQuery();
            sqlConn.Close();
        }
        catch (Exception ex)
        {

        }
    }
    private void UpdateDocDistributionData(int inchargeID, int docDistribID)
    {
        SqlConnection con = new SqlConnection(connValue);
        SqlCommand sqlCmd = new SqlCommand();
        // sqlCmd.CommandType = CommandType.StoredProcedure;
        sqlCmd.Connection = con;
        sqlCmd.CommandText = "UPDATE DocumentDistribution SET daysToReply= @daysToReply, actionDueDate = @actionDueDate Where distributeID  = @distributeID";

        sqlCmd.Parameters.AddWithValue("@daysToReply", txtWorkDays.Text);
        sqlCmd.Parameters.AddWithValue("@actionDueDate", txtDueDate123.Text);
        sqlCmd.Parameters.AddWithValue("@distributeID", docDistribID);

        try
        {
            con.Open();
            sqlCmd.ExecuteNonQuery();
        }
        catch (System.Exception ex)
        {
            throw ex;
        }
        finally
        {
            con.Close();
        }
    }
    private void UpdateJobIDforDocument(string contactID, DateTime actionDueDate, DateTime docIssuedDate, string docID, string jobOwnerStatusID, string jobOwnerID)
    {
        string updateSql = "UPDATE DocumentDistribution SET actionDueDate = @actionDueDate,docStatusID=@docStatusID,docPurposeID=@docPurposeID,jobOwnerID=@jobOwnerID Where DocumentID = @docRefID and contactID=@contactID";
        SqlConnection con = new SqlConnection(connValue);
        SqlCommand cmd = new SqlCommand();
        cmd.CommandText = updateSql;
        cmd.Connection = con;
        try
        {
            con.Open();

            if (jobOwnerStatusID == "7")
                cmd.Parameters.AddWithValue("@docPurposeID", 2);
            else
                cmd.Parameters.AddWithValue("@docPurposeID", 1);

            if (jobOwnerStatusID == "7")
            {
                cmd.Parameters.AddWithValue("@docStatusID", 4);
                cmd.Parameters.AddWithValue("@actionDueDate", DBNull.Value);
                cmd.Parameters.AddWithValue("@docIssuedDate", DBNull.Value);
            }
            else
            {
                if (actionDueDate.CompareTo(DateTime.ParseExact(System.DateTime.Now.ToString("dd/MM/yyyy"), "dd/MM/yyyy", CultureInfo.InvariantCulture)) <= -1)
                    cmd.Parameters.AddWithValue("@docStatusID", 2);
                else
                    cmd.Parameters.AddWithValue("@docStatusID", 1);

                cmd.Parameters.AddWithValue("@actionDueDate", actionDueDate);
                cmd.Parameters.AddWithValue("@docIssuedDate", docIssuedDate);
            }
            cmd.Parameters.AddWithValue("@contactID", contactID);
            cmd.Parameters.AddWithValue("@docRefID", docID);
            cmd.Parameters.AddWithValue("@jobOwnerID", jobOwnerID);

            cmd.ExecuteNonQuery();
            cmd = null;
        }
        catch (Exception ex)
        {
            Response.Write("While action date calucalation UpdateJobIDforDocument Function " + ex.Message);
        }
        finally
        {
            con.Close();
        }
    }
    private void UpdateJobQSID(int jobqsID, int _jobID)
    {
        SqlConnection con = new SqlConnection(connValue);
        SqlCommand cmd = new SqlCommand();
        cmd.CommandType = CommandType.Text;
        cmd.Connection = con;
        cmd.CommandText = "Update Job Set QSID = @qsID Where jobID = @jobID";
        cmd.Parameters.AddWithValue("@jobID", _jobID);
        cmd.Parameters.AddWithValue("@qsID", jobqsID);
        try
        {
            con.Open();
            cmd.ExecuteNonQuery();
            con.Dispose();
        }
        catch (System.Exception ex)
        {
            throw ex;
        }
        finally
        {
            con.Close();
        }
    }
    private void UpdateJobCEID(int jobceID, int _jobID)
    {
        SqlConnection con = new SqlConnection(connValue);
        SqlCommand cmd = new SqlCommand();
        cmd.CommandType = CommandType.Text;
        cmd.Connection = con;
        cmd.CommandText = "Update Job Set CEID = @ceID Where jobID = @jobID";
        cmd.Parameters.AddWithValue("@jobID", _jobID);
        cmd.Parameters.AddWithValue("@ceID", jobceID);
        try
        {
            con.Open();
            cmd.ExecuteNonQuery();
            con.Dispose();
        }
        catch (System.Exception ex)
        {
            throw ex;
        }
        finally
        {
            con.Close();
        }
    }
    private void UpdateJobPEID(int jobpeID, int _jobID)
    {
        SqlConnection con = new SqlConnection(connValue);
        SqlCommand cmd = new SqlCommand();
        cmd.CommandType = CommandType.Text;
        cmd.Connection = con;
        cmd.CommandText = "Update Job Set peID = @peID Where jobID = @jobID";
        cmd.Parameters.AddWithValue("@jobID", _jobID);
        cmd.Parameters.AddWithValue("@peID", jobpeID);
        try
        {
            con.Open();
            cmd.ExecuteNonQuery();
            con.Dispose();
        }
        catch (System.Exception ex)
        {
            throw ex;
        }
        finally
        {
            con.Close();
        }
    }
    public int PassJobOrderData(int _docID)
    {
      //  _addJob.jobID = maxJobID;
        _addJob.jobNo = txtJobNo.Text;

        if (ddlJobType.SelectedIndex != 0)
        {
            _addJob.jobTypeID = Convert.ToInt32(ddlJobType.SelectedValue);
            _addJob.jobCatID = Convert.ToInt32(ddlJobCat.SelectedValue);
        }
        else
        {
            _addJob.jobCatID = Convert.ToInt32(ddlJobCat.SelectedValue);
            _addJob.jobTypeID = Convert.ToInt32(ddlJobCat.SelectedValue);
        }

        if (ddlJobCat.SelectedValue != "1")
            _addJob.jobStatusID = 3;  //jobOrder
        else
            _addJob.jobStatusID = 8;  //PSA

        if (ddlDept.SelectedIndex != 0)
        {
            _addJob.deptID = Convert.ToInt32(ddlDept.SelectedValue);
            _addJob.affID = Convert.ToInt32(Session["AffairID"]);
        }
        else
        {
            _addJob.deptID = 1;
        }

        if (ddlVendor.SelectedIndex != 0)
            _addJob.contractorID = Convert.ToInt32(ddlVendor.SelectedItem.Value);
     

        _addJob.prjCode = "";

        if (ddlPrjCode.SelectedIndex != 0)
            _addJob.prjCode = ddlPrjCode.SelectedItem.Text;
        else if (txtPrjNo.Text != "")
            _addJob.prjCode = txtPrjNo.Text;
        else if (ddlCommitNo.SelectedIndex != 0)
            _addJob.commitmentNo = ddlCommitNo.SelectedItem.Text;
        else if (txtCmtNo.Text != "")
            _addJob.commitmentNo = txtCmtNo.Text;
        else if (ddlTndrNo.SelectedIndex != 0)
            _addJob.tenderNo = ddlTndrNo.SelectedItem.Text;
        else if (txtTndrNo.Text != "")
            _addJob.tenderNo = txtTndrNo.Text;

        _addJob.prjTitle = txtPrjTitle.Text;
        _addJob.jobDesc = txtJobTitle.Text;

        _addJob.qsID = 0; _addJob.ceID = 0; _addJob.peID = 0;
        if (txtAddendum.Text != "")
            _addJob.addendumNO = Convert.ToInt32(txtAddendum.Text);

        _addJob.contractTypeID = Convert.ToInt32(Session["TCMS_CntrTypeID"]); // Supervision 

        if (ddlDocRef.SelectedIndex != 0)
            _addJob.docRefID = Convert.ToInt32(ddlDocRef.SelectedValue);      

        if (ddlGrade.SelectedIndex != 0)
            _addJob.gradeID = Convert.ToInt32(ddlGrade.SelectedValue);

        if (ddlInchargeType.SelectedIndex == 1)
            _addJob.qsID = Convert.ToInt32(Session["UserID"]);
        else if (ddlInchargeType.SelectedIndex == 2)
            _addJob.peID = Convert.ToInt32(Session["UserID"]);
        else if (ddlInchargeType.SelectedIndex == 3)
            _addJob.ceID = Convert.ToInt32(Session["UserID"]);
        else if (ddlInchargeType.SelectedIndex == 4)            
            _addJob.dcID = Convert.ToInt32(Session["UserID"]);

       
        _addJob.actionDueDate = Convert.ToDateTime(txtDueDate123.Text).ToString("dd/MMM/yyyy");
        _addJob.daysToAct = Convert.ToInt32(txtWorkDays.Text);

        _addJob.jobCreatedByID = Convert.ToInt32(Session["UserID"]);
        _addJob.SectionID = Convert.ToInt32(Session["SectionID"].ToString());

        _addJob.JobReceivedDate = Convert.ToDateTime(txtRecDate.Text).ToString("dd/MMM/yyyy");

        _addJob.staffRoleID = Convert.ToInt32(ddlInchargeType.SelectedValue);

        _addJob.jobPurposeID = Convert.ToInt32(ddlJobPurpose.SelectedValue);

        
        if (ddlJobPurpose.SelectedValue == "1")
        {
            _addJob.inchargeActionDueDate = Convert.ToDateTime(getEndDateByGivenDays(1, txtRecDate.Text)).ToString();
            _addJob.inchargeWorkDays = 1;
        }
        else
        {
            _addJob.inchargeActionDueDate = Convert.ToDateTime(txtDueDate123.Text).ToString();
            _addJob.inchargeWorkDays = Convert.ToInt32(txtWorkDays.Text);
        }

       // _addJob.inchargeActionDueDate = Convert.ToDateTime(d).ToString("dd/MMM/yyyy"); 

        _jobID = InsertJobOrder(_addJob, Session["UserName"].ToString(), _docID);

        return _jobID;

    }
    public int InsertJobOrder(JobOrderProperty _insrttData, string userName, int _outDocID)
    {
        List<string> projData = Session["sessprjColl"] as List<string>;

         SqlConnection con = new SqlConnection(connValue);
        SqlCommand cmd = new SqlCommand();
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Connection = con;
        cmd.CommandText = "CreateJobOrder";

        //cmd.Parameters.AddWithValue("@jobID", _insrttData.jobID);

        // cmd.Parameters.AddWithValue("@jobID", SqlDbType.SmallInt).Direction = ParameterDirection.Output;           

        cmd.Parameters.AddWithValue("@jobNo", _insrttData.jobNo);

        // we have to Change below code
        if (_insrttData.jobTypeID != 0)
        {
            cmd.Parameters.AddWithValue("@jobTypeID", _insrttData.jobTypeID);
            cmd.Parameters.AddWithValue("@jobCatID", _insrttData.jobCatID);
        }
        else
        {
            cmd.Parameters.AddWithValue("@jobCatID", _insrttData.jobCatID);
            cmd.Parameters.AddWithValue("@jobTypeID", _insrttData.jobCatID);
        }

        if (_insrttData.affID != 0)
            cmd.Parameters.AddWithValue("@affairID", _insrttData.affID);
        else
            cmd.Parameters.AddWithValue("@affairID", System.DBNull.Value);

        if (_insrttData.deptID != 0)
            cmd.Parameters.AddWithValue("@deptID", _insrttData.deptID);
        else
            cmd.Parameters.AddWithValue("@deptID", System.DBNull.Value);

        if (_insrttData.commitmentNo != "" & _insrttData.commitmentNo != null)
            cmd.Parameters.AddWithValue("@contractNo", _insrttData.commitmentNo);
        else if (_insrttData.prjCode != "" & _insrttData.prjCode != null)
            cmd.Parameters.AddWithValue("@contractNo", _insrttData.prjCode);
        else if (_insrttData.tenderNo != "" & _insrttData.tenderNo != null)
            cmd.Parameters.AddWithValue("@contractNo", _insrttData.tenderNo);
        else
            cmd.Parameters.AddWithValue("@contractNo", System.DBNull.Value);

        cmd.Parameters.AddWithValue("@projectTitle", _insrttData.prjTitle);
        cmd.Parameters.AddWithValue("@jobDesc", _insrttData.jobDesc);


        if (_insrttData.contractorID != 0)
            cmd.Parameters.AddWithValue("@contractorID", _insrttData.contractorID);
        else
            cmd.Parameters.AddWithValue("@contractorID", System.DBNull.Value);

        if (_insrttData.jobCatID != 1)
            cmd.Parameters.AddWithValue("@jobStatusID", 3); // on-going
        else
            cmd.Parameters.AddWithValue("@jobStatusID", 8);       // Under EBSD for PSA          


        cmd.Parameters.AddWithValue("@docRefID", _insrttData.docRefID);

        if (_insrttData.addendumNO != 0)
            cmd.Parameters.AddWithValue("@addendumNO", _insrttData.addendumNO);
        else
            cmd.Parameters.AddWithValue("@addendumNO", System.DBNull.Value);

        //if (_insrttData.jobCatID == 1)        // PSA
        //    cmd.Parameters.AddWithValue("@contractTypeID", 1); // Supervision
        //else
        //    cmd.Parameters.AddWithValue("@contractTypeID", System.DBNull.Value);    //any

        cmd.Parameters.AddWithValue("@contractTypeID", _insrttData.contractTypeID);

        if (_insrttData.gradeID != 0)
            cmd.Parameters.AddWithValue("@gradeID", _insrttData.gradeID);
        else
            cmd.Parameters.AddWithValue("@gradeID", System.DBNull.Value);

        if (_insrttData.qsID != 0)
            cmd.Parameters.AddWithValue("@qsID", _insrttData.qsID);
        else
            cmd.Parameters.AddWithValue("@qsID", System.DBNull.Value);

        if (_insrttData.peID != 0)
            cmd.Parameters.AddWithValue("@peID", _insrttData.peID);
        else
            cmd.Parameters.AddWithValue("@peID", System.DBNull.Value);

        if (_insrttData.ceID != 0)
            cmd.Parameters.AddWithValue("@ceID", _insrttData.ceID);
        else
            cmd.Parameters.AddWithValue("@ceID", System.DBNull.Value);

        if (_insrttData.dcID != 0)
            cmd.Parameters.AddWithValue("@dcID", _insrttData.dcID);
        else
            cmd.Parameters.AddWithValue("@dcID", System.DBNull.Value);

        cmd.Parameters.AddWithValue("@actionDueDate", Convert.ToDateTime(_insrttData.actionDueDate).ToString("dd/MMM/yyyy"));
        cmd.Parameters.AddWithValue("@workDays", _insrttData.daysToAct);

        cmd.Parameters.AddWithValue("@JobDueDate", Convert.ToDateTime(_insrttData.actionDueDate).ToString("dd/MMM/yyyy"));
        cmd.Parameters.AddWithValue("@jobCreatedByID", _insrttData.jobCreatedByID);
        cmd.Parameters.AddWithValue("@SectionID", _insrttData.SectionID);

        cmd.Parameters.AddWithValue("@JobReceivedDate", Convert.ToDateTime(_insrttData.JobReceivedDate).ToString("dd/MMM/yyyy"));

        cmd.Parameters.AddWithValue("@createDate", System.DateTime.Now.ToString("dd/MMM/yyyy"));
        cmd.Parameters.AddWithValue("@createUser", userName);

        cmd.Parameters.AddWithValue("@StaffRoleID", _insrttData.staffRoleID); // pass value need

        //  cmd.Parameters.AddWithValue("@docID", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

        cmd.Parameters.AddWithValue("@docID", _outDocID);
        cmd.Parameters.AddWithValue("@jobPurposeID", _insrttData.jobPurposeID);


        cmd.Parameters.AddWithValue("@inchargeDueDate", Convert.ToDateTime(_insrttData.inchargeActionDueDate).ToString("dd/MMM/yyyy"));
        cmd.Parameters.AddWithValue("@daysToAct", _insrttData.inchargeWorkDays);


        cmd.Parameters.AddWithValue("@jobOwnerStatusID", 3);
        cmd.Parameters.AddWithValue("@docCreatedByID", System.DBNull.Value);

        cmd.Parameters.AddWithValue("@originID", System.DBNull.Value);
        cmd.Parameters.AddWithValue("@jobOwnerID", System.DBNull.Value);
        cmd.Parameters.AddWithValue("@docReceivedDate", System.DBNull.Value);

        cmd.Parameters.AddWithValue("@docDate", System.DBNull.Value);

        if (projData != null)
            cmd.Parameters.AddWithValue("@ministryCode", projData[1].ToString());
        else
            cmd.Parameters.AddWithValue("@ministryCode", System.DBNull.Value);

        if (projData != null)
            cmd.Parameters.AddWithValue("@budgetRefNo", projData[2].ToString());
        else
            cmd.Parameters.AddWithValue("@budgetRefNo", System.DBNull.Value);

        if (projData != null)
           cmd.Parameters.AddWithValue("@provisionNo", projData[3].ToString());
        else
           cmd.Parameters.AddWithValue("@provisionNo", System.DBNull.Value);



        if (_insrttData.commitmentNo != null)
            cmd.Parameters.AddWithValue("@committmentNo", _insrttData.commitmentNo);
        else
            cmd.Parameters.AddWithValue("@committmentNo", System.DBNull.Value);

        if (_insrttData.prjCode != null)
            cmd.Parameters.AddWithValue("@projectCode", _insrttData.prjCode);
        else
            cmd.Parameters.AddWithValue("@projectCode", System.DBNull.Value);



        cmd.Parameters.AddWithValue("@JobID", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

        try
        {
            con.Open();
            cmd.ExecuteNonQuery();
            con.Dispose();
        }
        catch (Exception ex)
        {

            throw ex;
        }
        finally
        {
            con.Close();
        }


        return (int)cmd.Parameters["@JobID"].Value;

       // return _insrttData.jobID;
    }
    public void PassJobInchargeData(int maxJobID, int docCreatedID, ref int _InchargeID, string docRecDate)
    {
        _addJob.contactID = Convert.ToInt32(Session["userID"]);
        _addJob.docCreatedByID = docCreatedID;

        _addJob.daysToAct = Convert.ToInt32(txtWorkDays.Text);
        _addJob.completionDate = "";


        _addJob.actionDueDate = Convert.ToDateTime(txtDueDate123.Text).ToString("dd/MMM/yyyy");

        _addJob.staffIssueDate = Convert.ToDateTime(docRecDate).ToString("dd/MMM/yyyy");

        _addJob.userDisplayName = _userDisplayName;

        _addJob.jobID = maxJobID;
        _addJob.jobNo = txtJobNo.Text;
        _addJob.jobTypeID = Convert.ToInt32(ddlJobCat.SelectedValue);
        _addJob.jobCatID = Convert.ToInt32(ddlJobCat.SelectedValue);

        _addJob.jobStatusID = 3;

        if (ddlDept.SelectedIndex != 0)
            _addJob.deptID = Convert.ToInt32(ddlDept.SelectedValue);

        _addJob.affID = Convert.ToInt32(Session["AffairID"]);

        if (ddlVendor.SelectedIndex != 0)
            _addJob.consultID = Convert.ToInt32(ddlVendor.SelectedValue);

        if (ddlVendor.SelectedIndex != 0)
            _addJob.contractorID = Convert.ToInt32(ddlVendor.SelectedValue);

        _addJob.prjCode = ddlPrjCode.Text;
        _addJob.prjTitle = txtPrjTitle.Text;

        _addJob.qsID = 0; _addJob.ceID = 0; _addJob.peID = 0;
        _addJob.letterDate = ""; _addJob.createDate = ""; _addJob.ebsdDateReceived = "";
        _addJob.letterRefNo = "";

        if (txtAddendum.Text != "")
            _addJob.addendumNO = Convert.ToInt32(txtAddendum.Text);

        //if (ddlJobCat.SelectedValue != "1")
        //    _addJob.contractTypeID = 1;    // Supervison
        //else
        //    _addJob.contractTypeID = 2;

        if (ddlDocRef.SelectedIndex != 0)
            _addJob.docRefID = Convert.ToInt32(ddlDocRef.SelectedValue);

        _addJob.jobSubject = "";

        _addJob.staffRoleID = Convert.ToInt32(ddlInchargeType.SelectedValue);

        _addJob.jobPurposeID = Convert.ToInt32(ddlJobPurpose.SelectedValue);

        _addJob.SectionID = Convert.ToInt32(Session["SectionID"]);        

       // new JobOrderData().Insert_JobOwner(_addJob, ref _InchargeID);

        Insert_JobOwner(_addJob, ref _InchargeID);
    }
    public void Insert_JobOwner(JobOrderProperty _insertIncharge, ref int _ownerID)
    {
        SqlConnection con = new SqlConnection(connValue);
        SqlCommand cmd = new SqlCommand();
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Connection = con;
        cmd.CommandText = "[Insert_JobOwner]";
        cmd.Parameters.AddWithValue("@jobID", _insertIncharge.jobID);

        cmd.Parameters.AddWithValue("@contactID", _insertIncharge.contactID);

        cmd.Parameters.AddWithValue("@payID", System.DBNull.Value);

        cmd.Parameters.AddWithValue("@changeID", System.DBNull.Value);

        cmd.Parameters.AddWithValue("@momID", System.DBNull.Value);

        cmd.Parameters.AddWithValue("@docID", _insertIncharge.docRefID);

        cmd.Parameters.AddWithValue("@projectCode", _insertIncharge.prjCode);

        cmd.Parameters.AddWithValue("@projectTitle", _insertIncharge.prjTitle);

        cmd.Parameters.AddWithValue("@jobNo", _insertIncharge.jobNo);

        cmd.Parameters.AddWithValue("@jobOwnerCatID", _insertIncharge.jobCatID);

        cmd.Parameters.AddWithValue("@distributedBy", _insertIncharge.docCreatedByID);

        cmd.Parameters.AddWithValue("@actionDueDate", _insertIncharge.actionDueDate);
        cmd.Parameters.AddWithValue("@daysToAct", _insertIncharge.daysToAct);
        cmd.Parameters.AddWithValue("@completionDate", System.DBNull.Value);          //_insertIncharge.completionDate

        cmd.Parameters.AddWithValue("@jobDone", 0);
        cmd.Parameters.AddWithValue("@docRead", 0);

        cmd.Parameters.AddWithValue("@dateRead", System.DBNull.Value);
        cmd.Parameters.AddWithValue("@createUser", _insertIncharge.userDisplayName);
        cmd.Parameters.AddWithValue("@createDate", System.DateTime.Now.ToString("dd/MMM/yyyy"));
        cmd.Parameters.AddWithValue("@updateUser", System.DBNull.Value);
        cmd.Parameters.AddWithValue("@updateDate", System.DBNull.Value);
        cmd.Parameters.AddWithValue("@jobOwnerStatusID", 3);
        cmd.Parameters.AddWithValue("@StaffRoleID", _insertIncharge.staffRoleID); // pass value need
        cmd.Parameters.AddWithValue("@jobPurposeID", _insertIncharge.jobPurposeID);
        cmd.Parameters.AddWithValue("@sectionID", _insertIncharge.SectionID);
        cmd.Parameters.AddWithValue("@staffIssueDate", _insertIncharge.staffIssueDate);
        cmd.Parameters.AddWithValue("@jobOwnerID", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

        try
        {
            con.Open();
            cmd.ExecuteNonQuery();
            con.Dispose();
            _ownerID = (int)cmd.Parameters["@jobOwnerID"].Value;
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            con.Close();
        }
    }
    private void visibleFalsePrj()
    {
        trlblPrjCode.Visible = false;
        trPrjID.Visible = false;
        trtxtPrjID.Visible = false;
    }
    private void visibleFalseTndr()
    {
        trlblTndrNo.Visible = false;
        trTndrNo.Visible = false;
        trtxtTndrNo.Visible = false;
    }
    private void visibleFalseContracts()
    {
        trlblCntrNo.Visible = false;
        trCmtee.Visible = false;
        trtxtCmtee.Visible = false;
    }
    private void visibleTruePrj()
    {
        trlblPrjCode.Visible = true;
        trPrjID.Visible = true;
        //trtxtPrjID.Visible = true;
    }
    private void visibleTrueTndr()
    {
        trlblTndrNo.Visible = true;
        trTndrNo.Visible = true;
        //trtxtTndrNo.Visible = true;
    }
    private void visibleTrueContracts()
    {
        trlblCntrNo.Visible = true;
        trCmtee.Visible = true;
        //trtxtCmtee.Visible = true;
    }
    static string holdVisibleStstus = string.Empty; 
    private void checkCategoryStausForControls()
    {
        if ((ddlJobCat.SelectedValue == "1") || (ddlJobCat.SelectedValue == "3"))     // PSA and Commtted
        {
            visibleFalsePrj();
            visibleFalseTndr();

            visibleTrueContracts();
        }
        else if (ddlJobCat.SelectedValue == "7" || ddlJobCat.SelectedValue == "4")        // Non-Committed n Cost Estimate
        {
            visibleFalseContracts();

            visibleTrueTndr();
            visibleTruePrj();
        }
        else if (ddlJobCat.SelectedValue == "5" || ddlJobCat.SelectedValue == "6" || ddlJobCat.SelectedValue == "2")       
        {
            visibleTrueContracts();
            visibleTruePrj();
            visibleTrueTndr();
        }        
    }        
    protected void ddlJobCat_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlJobCat.SelectedIndex == -1)
            disableJobControls();

        ddlCommitNo.SelectedIndex = 0; ddlPrjCode.SelectedIndex = 0; ddlTndrNo.SelectedIndex = 0;
        txtCmtNo.Text = ""; txtPrjNo.Text = ""; txtTndrNo.Text = "";

        enableJobControls();

        checkCategoryStausForControls();   
        // CreateJobNO();

        int sectionID = 1;    int seriesID = 1; 
        
        int catID = Convert.ToInt16(ddlJobCat.SelectedValue);

        if (catID == 7)
            seriesID = 3;
        else if (catID == 60)   // CCC
            seriesID = 12;
        else if (catID == 61)  // Genaral
            seriesID = 13;
        else
            seriesID = catID;

        genarateJobNo(sectionID, seriesID, catID);          // 1- for Cost Section

        if (ddlJobCat.SelectedIndex > 0)
        {
            FillCombo(ddlJobType, "JobTypeID", "JobTypeName", ExecuteQuery("SELECT JobTypeID,JobTypeName FROM JobType WHERE CategoryID= " + ddlJobCat.SelectedValue + " and JobTypeID <> CategoryID"), false);
            // ddlJobType.Items.Insert(0, new ListItem("--Select--"));
        }
        else
            ddlJobType.Items.Clear();

        // getJobTypes(Convert.ToInt32(ddlJobCat.SelectedValue));
    }
    private void UpdateDataForUnusedJobNo()
    {
        string strQuery = "Update TempJobNo Set confirmed = 0,sessionUser = NULL  WHERE (confirmed = 1) AND (sessionUser IS NOT NULL) AND (DateCreated < GETDATE() - 1)";

        using (SqlConnection cn = new SqlConnection(connValue))
        {
            using (SqlCommand sqlCmd = new SqlCommand())
            {
                sqlCmd.CommandType = CommandType.Text;
                sqlCmd.CommandText = strQuery;
                sqlCmd.Connection = cn;

                try
                {
                    cn.Open();
                    sqlCmd.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    Response.Write(ex.Message);
                }
                finally
                {
                    cn.Close();
                }
            }
        }
    }
    private void genarateJobNo(int sectionID,int seriesID,int CategID)
    {
        // lblmsg.Text = "";       

        string userSessionJobNo = string.Empty;

        // Function used to update columns because of unused jobno continiously for last two day
        // Making use of same jobno for other users

        UpdateDataForUnusedJobNo();  //  Function Should be run as Job Shedule every day


        // SELECT  tempID, CategoryID, sectionID, JobNo, sessionUser, confirmed FROM  TempJobNo WHERE (CategoryID =2) and  (sectionID = 2) AND (sessionUser = @userName) AND (confirmed = 1)
        userSessionJobNo = new JobOrderData().CheckCurrentUserSessioExist(Session["UserName"].ToString(), seriesID);

        if (userSessionJobNo == "")
        {
            userSessionJobNo = CheckSessionUserNull(seriesID);
            if (userSessionJobNo != "")
                updateSessionUser(seriesID, userSessionJobNo); // he hold jobno before now using - make confirm =1 and sessionUser update
        }

        //update sessionuserName  as current user and confirmed is true

        string strYear = System.DateTime.Now.Year.ToString().Substring(2, 2);

        string jobShortName = getJobTypeShortName(seriesID);      // for payment seriesID = 2     // getJobTypeShortName(CategID);  Changed as seriesID on May29th

        if (userSessionJobNo != "")
        {
            // Same user come back So Same Job No.
            txtJobNo.Text = jobShortName + userSessionJobNo;
        }
        else
        {
            if (new JobOrderData().checkJobNoconfimed(seriesID) == "")
            {

                string tempAutojobNo = GenarateAutomate_JobNo(seriesID);

                txtJobNo.Text = jobShortName + strYear + tempAutojobNo;

                string strTempJobNo = strYear + tempAutojobNo;

                new JobOrderData().InsertTemJobNo(strTempJobNo, Session["UserName"].ToString(), sectionID, seriesID, CategID);
            }
            else
            {
                txtJobNo.Text = jobShortName + new JobOrderData().checkJobNoconfimed(seriesID);
                new JobOrderData().UpdateSessionUser(Session["UserName"].ToString(), seriesID);
            }
        }
    }   
    private void CreateJobNO()
    {
        string strYear = System.DateTime.Now.Year.ToString().Substring(2, 2);
        if (ddlJobCat.SelectedValue.ToString() != "")
        {
            string jobTypeSHname = string.Empty;
            jobTypeSHname = new JobOrderData().getJobCategory_ShortName(Convert.ToInt32(ddlJobCat.SelectedValue.ToString()));
            string autoJobNO = string.Empty;
            autoJobNO = GenarateAutomate_JobNo(jobTypeSHname);
            autoJobNO = jobTypeSHname + strYear + autoJobNO;
            txtJobNo.Text = autoJobNO;
        }
    }
    private string GenarateAutomate_JobNo(string jobType)
    {
        string _jobNo = string.Empty;
        int _maxjobNo = 0;
        string tempJobNo = string.Empty;

        _jobNo = new JobOrderData().getMaxJobNoSeries(jobType);

        if (_jobNo != "")
        {
            tempJobNo = _jobNo.Substring(_jobNo.Length - 4, 4);
            _maxjobNo = Convert.ToInt32(tempJobNo) + 1;

           // _maxjobNo = Convert.ToInt32(_jobNo) + 1;

            if (_maxjobNo.ToString().Length == 1)
                tempJobNo = "000" + _maxjobNo;

            if (_maxjobNo.ToString().Length == 2)
                tempJobNo = "00" + _maxjobNo;

            if (_maxjobNo.ToString().Length == 3)
                tempJobNo = "0" + _maxjobNo;

            if (_maxjobNo.ToString().Length == 4)
                tempJobNo = _maxjobNo.ToString();

            _jobNo = tempJobNo;
        }
        else
        {
            _jobNo = "0001";
        }

        return _jobNo;
    }
    protected void ddlGrade_SelectedIndexChanged(object sender, EventArgs e)
    {

        // WorkingDaysCaluclationByGrade(getDocReceivedDate(Convert.ToInt32(ddlDocRef.SelectedValue)));

        WorkingDaysCaluclationByGrade(txtRecDate.Text);
    }
    private void WorkingDaysCaluclationByGrade(string strDate)
    {
        string endDate = string.Empty;
        switch (ddlGrade.SelectedItem.ToString())
        {
            case "1":
                txtWorkDays.Text = "5"; // Working Days
                endDate = getEndDateByGivenDays(5, strDate);
                txtDueDate123.Text = Convert.ToDateTime(endDate).ToString("dd/MMM/yyyy");

                //txtDueDate.Text = System.DateTime.Now.AddDays(5).ToString("dd/MMM/yyyy");
                break;
            case "2":
                endDate = getEndDateByGivenDays(8, strDate);
                txtDueDate123.Text = Convert.ToDateTime(endDate).ToString("dd/MMM/yyyy");
                txtWorkDays.Text = "7";
                break;

            case "3":
                endDate = getEndDateByGivenDays(10, strDate);
                txtDueDate123.Text = Convert.ToDateTime(endDate).ToString("dd/MMM/yyyy");
                txtWorkDays.Text = "10";
                break;

            case "4":
                endDate = getEndDateByGivenDays(15, strDate);
                txtDueDate123.Text = Convert.ToDateTime(endDate).ToString("dd/MMM/yyyy");
                txtWorkDays.Text = "15";
                break;

            case "":
                endDate = getEndDateByGivenDays(8, strDate);
                txtDueDate123.Text = Convert.ToDateTime(endDate).ToString("dd/MMM/yyyy");
                txtWorkDays.Text = "7";
                break;

            default:
                break;
        }
    }
    private string getEndDateByGivenDays(int _days, string strDate)
    {
        SqlConnection con = new SqlConnection(connValue);
        SqlCommand cmd = new SqlCommand();
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Connection = con;

        cmd.CommandText = "AddWorkdays";
        SqlParameter prm = cmd.Parameters.Add("@ad_startDate", SqlDbType.DateTime);
        prm.Value = strDate;
        prm = cmd.Parameters.Add("@actual_workDays", SqlDbType.Int);
        prm.Value = Convert.ToInt32(_days);
        prm = cmd.Parameters.Add("@endDate", SqlDbType.DateTime);
        prm.Direction = ParameterDirection.Output;
        con.Open();
        SqlDataReader dr = cmd.ExecuteReader();
        while (dr.Read())
            Console.WriteLine(dr.GetString(0));
        con.Dispose();
        con.Close();

        return cmd.Parameters[2].Value.ToString();
    }
   
    
    
    protected void ddlDept_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlDept.SelectedValue != "")
            Session["AffairID"] = new JobOrderData().getAffairID(Convert.ToInt32(ddlDept.SelectedValue));
    }
    List<string> prjColl = new List<string>();
    protected void ddlPrjCode_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlPrjCode.SelectedIndex != 0)
        {
            txtTndrNo.Text = "";
            trlblTndrNo.Visible = false;
            trTndrNo.Visible = false;
            txtTndrNo.Visible = false;

            txtCmtNo.Text = "";
            trlblCntrNo.Visible = false;
            trCmtee.Visible = false;
            txtCmtNo.Visible = false;
        }
        else
        {
            checkCategoryStausForControls();
        }


        if (ddlPrjCode.SelectedValue != "")
        {
          //  txtPrjTitle.Text = new JobOrderData().getProjectTitle(Convert.ToInt32(ddlPrjCode.SelectedValue));
           prjColl =  new JobOrderData().getProjectData(Convert.ToInt32(ddlPrjCode.SelectedValue));

           if (prjColl.Count > 0)
           {
               Session["sessprjColl"] = prjColl;
               txtPrjTitle.Text = prjColl[0];

               Session["TCMS_CntrTypeID"] = prjColl[5]; 
           }
            ddlTndrNo.SelectedIndex = 0;
            ddlCommitNo.SelectedIndex = 0;
        }
    }
    List<string> contractColl = new List<string>();
    protected void ddlCommitNo_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlCommitNo.SelectedIndex != 0)
        {
            txtPrjNo.Text = "";
            trlblPrjCode.Visible = false;
            trPrjID.Visible = false;
            trtxtPrjID.Visible = false;

            txtTndrNo.Text = "";
            trlblTndrNo.Visible = false;
            trtxtTndrNo.Visible = false;
            trTndrNo.Visible = false;
        }
        else
        {
            checkCategoryStausForControls();
        }

        string companyNameID = string.Empty;
        if (ddlCommitNo.SelectedValue != "")
        {
            //txtPrjTitle.Text = new JobOrderData().getVendorName(Convert.ToInt32(ddlCommitNo.SelectedValue), ref companyNameID);


            contractColl = new JobOrderData().getVendorData(Convert.ToInt32(ddlCommitNo.SelectedValue));

            Session["sessprjColl"] = contractColl;
            txtPrjTitle.Text = contractColl[0];

            ddlVendor.SelectedValue = contractColl[4];

            // ddlVendor.SelectedItem.Value = companyNameID;
            ddlPrjCode.SelectedIndex = 0;
            ddlTndrNo.SelectedIndex = 0;
            trtxtCmtee.Visible = false;

            Session["TCMS_CntrTypeID"] = contractColl[11];
        }
    }
    protected void ddlTndrNo_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlTndrNo.SelectedIndex != 0)
        {
            txtPrjNo.Text = "";
            trlblTndrNo.Visible = false;
            trPrjID.Visible = false;
            trtxtPrjID.Visible = false;

            txtCmtNo.Text = "";
            trlblCntrNo.Visible = false;
            trtxtCmtee.Visible = false;
            txtCmtNo.Visible = false;
        }
        else
        {
            checkCategoryStausForControls();
        }

        if (ddlTndrNo.SelectedValue != "")
        {
           // txtPrjTitle.Text = new JobOrderData().getProjectTitle(Convert.ToInt32(ddlTndrNo.SelectedValue));

            prjColl = new JobOrderData().getProjectData(Convert.ToInt32(ddlTndrNo.SelectedValue));
            Session["sessprjColl"] = prjColl;
            txtPrjTitle.Text = prjColl[0];

            ddlPrjCode.SelectedIndex = 0;
            ddlCommitNo.SelectedIndex = 0;

            Session["TCMS_CntrTypeID"] = prjColl[5]; 
        }
    }
    private string getEndDateByGivenDays(string strDate)
    {
        SqlConnection con = new SqlConnection(connValue);
        SqlCommand cmd = new SqlCommand();
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Connection = con;

        cmd.CommandText = "AddWorkdays";
        SqlParameter prm = cmd.Parameters.Add("@ad_startDate", SqlDbType.DateTime);
        prm.Value = strDate;
        prm = cmd.Parameters.Add("@actual_workDays", SqlDbType.Int);
        prm.Value = Convert.ToInt32(txtWorkDays.Text);
        prm = cmd.Parameters.Add("@endDate", SqlDbType.DateTime);
        prm.Direction = ParameterDirection.Output;
        con.Open();
        SqlDataReader dr = cmd.ExecuteReader();
        while (dr.Read())
            Console.WriteLine(dr.GetString(0));
        con.Dispose();
        con.Close();

        return cmd.Parameters[2].Value.ToString();
    }
    protected void txtWorkDays_TextChanged(object sender, EventArgs e)
    {
        if (txtWorkDays.Text != "0")
        {
            if (ddlDocRef.SelectedValue == "")
            {
                return;
            }
            string docDate = getDocReceivedDate(Convert.ToInt32(ddlDocRef.SelectedValue));
            string endDate = getEndDateByGivenDays(docDate);
            txtDueDate123.Text = Convert.ToDateTime(endDate).ToString("dd/MMM/yyyy");
        }
        else
        {
            txtWorkDays.Text = "1";
        }

        if (txtWorkDays.Text.Equals("5"))
            ddlGrade.SelectedIndex = 1;
        else if (txtWorkDays.Text.Equals("7"))
            ddlGrade.SelectedIndex = 2;
        else if (txtWorkDays.Text.Equals("10"))
            ddlGrade.SelectedIndex = 3;
        else if (txtWorkDays.Text.Equals("15"))
            ddlGrade.SelectedIndex = 4;
        else
            ddlGrade.SelectedIndex = 0;

    }
    protected void ddlDocRef_SelectedIndexChanged(object sender, EventArgs e)
    {
        documentChangeEvent();
    }
    private void documentChangeEvent()
    {
        if (ddlDocRef.SelectedIndex != 0)
        {
            Session["DocRecDate"] = getDocReceivedDate(Convert.ToInt32(ddlDocRef.SelectedValue));
            txtRecDate.Text = getDocReceivedDate(Convert.ToInt32(ddlDocRef.SelectedValue));

            WorkingDaysCaluclationByGrade(txtRecDate.Text);
        }
        else
        {
            txtRecDate.Text = System.DateTime.Now.ToString();
        }
    }
    private string getDocReceivedDate(int docID)
    {
        string docRecDate = string.Empty;
        SqlConnection sqlConn = new SqlConnection(connValue);
        string sqlQuery = "SELECT docReceivedDate from Document where documentID =" + docID + "";

        try
        {
            sqlConn.Open();
            SqlCommand sqlCom = new SqlCommand(sqlQuery, sqlConn);
            SqlDataReader sqlReader = sqlCom.ExecuteReader();
            while (sqlReader.Read())
            {
                docRecDate = sqlReader[0].ToString();
            }
            sqlReader.Close();
        }
        catch (Exception ex)
        {
            // Response.Write("Error getting while reading data !" + ex.Message);
        }
        finally
        {
            sqlConn.Close();
        }
        return docRecDate;
    }
    protected void lnkDocuments_Click(object sender, EventArgs e)
    {
        string str = Request.Url.AbsoluteUri;
        Session["UrlRef"] = str;
        Session["JobID"] = null;
        Session["DocID"] = null;
        Session["DocCategoryID"] = "1";

        Response.Redirect("~/Documents/DocumentDetailsWindow.aspx", false);
    }
    protected void btnSave_Click1(object sender, EventArgs e)
    {
        InsertNewJobOrder();

        jobdocID = 0;

        int catID = Convert.ToInt16(ddlJobCat.SelectedValue);
        int seriesID = 0;
       
        //if (catID == 7)
        //    seriesID = 3;
        //else
        //    seriesID = catID;


        if (catID == 7)
            seriesID = 3;
        else if (catID == 60)   // CCC
            seriesID = 12;
        else if (catID == 61)  // Genaral
            seriesID = 13;
        else
            seriesID = catID;


        new JobOrderData().deleteTempJobNO(seriesID);
        new JobOrderData().UpdateSessionUserNull(Session["UserName"].ToString(), seriesID,_jobID);
               

        string script = "this.window.opener.location=this.window.opener.location;this.window.close();";
        if (!ClientScript.IsClientScriptBlockRegistered("REFRESH_PARENT"))
            ClientScript.RegisterClientScriptBlock(typeof(string), "REFRESH_PARENT", script, true);
    
    }

    private void AddProject_Attributes(int _AttrbdocID)
    {
        if (ddlCommitNo.SelectedIndex != 0)
        {
            IList<string> projectInfoColl = new List<string>();
            projectInfoColl = new JobOrderData().FillDropDownSelectedContractValues(Convert.ToInt32(ddlCommitNo.SelectedValue));
            InsertProjectAttributes(projectInfoColl, Convert.ToInt32(ddlCommitNo.SelectedValue));            
        }
        else if (ddlTndrNo.SelectedIndex != 0)
        {
            IList<string> projectInfoColl = new List<string>();
            projectInfoColl = new JobOrderData().FillDropDownSelectedValues(Convert.ToInt32(ddlTndrNo.SelectedValue));
            InsertProjectAttributes(projectInfoColl, Convert.ToInt32(ddlTndrNo.SelectedValue));  
        }
        else if (ddlPrjCode.SelectedIndex != 0)
        {
            IList<string> projectInfoColl = new List<string>();
            projectInfoColl = new JobOrderData().FillDropDownSelectedValues(Convert.ToInt32(ddlPrjCode.SelectedValue));
            InsertProjectAttributes(projectInfoColl, Convert.ToInt32(ddlPrjCode.SelectedValue));
        }
        else
        {
            AddProjectAttributes(_AttrbdocID, _addJob.commitmentNo, _addJob.prjCode, _addJob.prjTitle, _addJob.tenderNo);
        }
    }
    private void InsertProjectAttributes(IList<string> prjDataColl, int prjID)
    {
        try
        {
            using (SqlConnection cn = new SqlConnection(connValue))
            {
                using (SqlCommand sqlCmd = new SqlCommand())
                {
                    sqlCmd.Connection = cn;
                    sqlCmd.CommandType = CommandType.StoredProcedure;
                    sqlCmd.CommandText = "InsertProjectAttributes";

                    sqlCmd.Parameters.AddWithValue("@docID", ddlDocRef.SelectedValue);
                    sqlCmd.Parameters.AddWithValue("@prjID", prjID);
                    sqlCmd.Parameters.AddWithValue("@contractNo", prjDataColl[3].ToString());
                    sqlCmd.Parameters.AddWithValue("@projectCode", prjDataColl[1].ToString());
                    sqlCmd.Parameters.AddWithValue("@projectTitle", prjDataColl[4].ToString());
                    sqlCmd.Parameters.AddWithValue("@tenderNo", prjDataColl[2].ToString());

                    cn.Open();
                    sqlCmd.ExecuteNonQuery();
                }
            }
        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
    }   
    private string getDaysByGivenEndDate(string strDate, string endDate)
    {
        strDate = Convert.ToDateTime(strDate).ToString("MM/dd/yyyy", CultureInfo.InvariantCulture);
        endDate = Convert.ToDateTime(endDate).ToString("MM/dd/yyyy", CultureInfo.InvariantCulture);

        DateTime strDt = DateTime.ParseExact(strDate, "MM/dd/yyyy", CultureInfo.InvariantCulture);
        DateTime endDt = DateTime.ParseExact(endDate, "MM/dd/yyyy", CultureInfo.InvariantCulture);

        SqlConnection con = new SqlConnection(connValue);
        SqlCommand cmd = new SqlCommand();

        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Connection = con;

        cmd.CommandText = "testSP";

        SqlParameter prm = cmd.Parameters.Add("@ad_startDate", SqlDbType.DateTime);
        prm.Value = strDt;

        prm = cmd.Parameters.Add("@ad_endDate", SqlDbType.DateTime);
        prm.Value = endDt;

        prm = cmd.Parameters.Add("@ai_workDays", SqlDbType.Int);
        prm.Direction = ParameterDirection.Output;

        //prm = cmd.Parameters.Add("@as_errMsg", SqlDbType.VarChar);
        //prm.Direction = ParameterDirection.Output;

        con.Open();
        SqlDataReader dr = cmd.ExecuteReader();
        while (dr.Read())
            Console.WriteLine(dr.GetString(0));
        con.Dispose();
        con.Close();

        return cmd.Parameters[2].Value.ToString();
    }
    protected void btnCmtFind_Click(object sender, EventArgs e)
    {
        txtCmtNo.Text = "";

        txtPrjTitle.Text = "";
        ddlCommitNo.SelectedIndex = 0;
        ddlVendor.SelectedIndex = 0;

        trCmtee.Visible = false;
        trtxtCmtee.Visible = true;

        txtPrjNo.Text = "";
        trlblPrjCode.Visible = false;
        trPrjID.Visible = false;
        trtxtPrjID.Visible = false;

        txtTndrNo.Text = "";
        trlblTndrNo.Visible = false;
        trtxtTndrNo.Visible = false;
        trTndrNo.Visible = false;

    }
    protected void btnPrjFind_Click(object sender, EventArgs e)
    {
        txtPrjNo.Text = "";

        txtPrjTitle.Text = "";
        ddlPrjCode.SelectedIndex = 0;
        ddlVendor.SelectedIndex = 0;

        trPrjID.Visible = false;   // DropDown
        trtxtPrjID.Visible = true;       // textbox       

        //-------------------------------------------------------
               

        txtCmtNo.Text = "";
        trlblCntrNo.Visible = false;
        trCmtee.Visible = false;
        trtxtCmtee.Visible = false;

        txtTndrNo.Text = "";
        trlblTndrNo.Visible = false;
        trtxtTndrNo.Visible = false;
        trTndrNo.Visible = false;

    }
    protected void btnTndrFind_Click(object sender, EventArgs e)
    {
        txtTndrNo.Text = "";
        txtPrjTitle.Text = "";

        ddlTndrNo.SelectedIndex = 0;
        ddlVendor.SelectedIndex = 0;       

        trTndrNo.Visible = false;
        trtxtTndrNo.Visible = true;

       // -----------------------------------------------------
             txtPrjNo.Text = "";
        trlblPrjCode.Visible = false;
        trPrjID.Visible = false;
        trtxtPrjID.Visible = false;

        txtCmtNo.Text = "";
        trlblCntrNo.Visible = false;
        trCmtee.Visible = false;
        trtxtCmtee.Visible = false;



    }
    protected void txtDueDate123_TextChanged(object sender, EventArgs e)
    {
        DateTime dateEnd = System.DateTime.Now;
        dateEnd = ConvertToDateTime(txtDueDate123.Text);

        //txtWorkDays.Text = getDaysByGivenEndDate(System.DateTime.Now.ToString(), dateEnd);
        if (ddlDocRef.SelectedIndex == 0)
            txtWorkDays.Text = getDaysByGivenEndDate(System.DateTime.Now.ToString(), dateEnd);
        else
            txtWorkDays.Text = getDaysByGivenEndDate(txtRecDate.Text, dateEnd);

        txtDueDate123.Text = dateEnd.ToString("dd/MMM/yyyy");

        if (txtWorkDays.Text.Equals("5"))
            ddlGrade.SelectedIndex = 1;
        else if (txtWorkDays.Text.Equals("7"))
            ddlGrade.SelectedIndex = 2;
        else if (txtWorkDays.Text.Equals("10"))
            ddlGrade.SelectedIndex = 3;
        else if (txtWorkDays.Text.Equals("15"))
            ddlGrade.SelectedIndex = 4;
        else
            ddlGrade.SelectedIndex = 0;
    }
    private DateTime ConvertToDateTime(string strDateTime)
    {
        DateTime dtFinaldate; string sDateTime;
        try
        {
            //dtFinaldate = Convert.ToDateTime(strDateTime); 

            string[] sDate = strDateTime.Split('/');
            sDateTime = sDate[1] + '/' + sDate[0] + '/' + sDate[2];
            dtFinaldate = Convert.ToDateTime(sDateTime);
        }
        catch (Exception e)
        {
            string[] sDate = strDateTime.Split('/');
            sDateTime = sDate[0] + '/' + sDate[1] + '/' + sDate[2];
            dtFinaldate = Convert.ToDateTime(sDateTime);
        }
        return dtFinaldate;
    }
    private string getDaysByGivenEndDate(string strDate, DateTime endDate)
    {
        strDate = Convert.ToDateTime(strDate).ToString("MM/dd/yyyy", CultureInfo.InvariantCulture);
        //endDate = Convert.ToDateTime(endDate).ToString("MM/dd/yyyy", CultureInfo.InvariantCulture);

        //DateTime dt = DateTime.ParseExact(endDate, "d/M/yyyy", null);
        //endDate = dt.ToString("dd/MM/yyyy");

        DateTime strDt = DateTime.ParseExact(strDate, "MM/dd/yyyy", CultureInfo.InvariantCulture);
        //DateTime endDt = DateTime.ParseExact(endDate, "MM/dd/yyyy", CultureInfo.InvariantCulture);

        SqlConnection con = new SqlConnection(connValue);
        SqlCommand cmd = new SqlCommand();

        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Connection = con;

        cmd.CommandText = "testSP";

        SqlParameter prm = cmd.Parameters.Add("@ad_startDate", SqlDbType.DateTime);
        prm.Value = strDt;

        prm = cmd.Parameters.Add("@ad_endDate", SqlDbType.DateTime);
        prm.Value = endDate;

        prm = cmd.Parameters.Add("@ai_workDays", SqlDbType.Int);
        prm.Direction = ParameterDirection.Output;

        //prm = cmd.Parameters.Add("@as_errMsg", SqlDbType.VarChar);
        //prm.Direction = ParameterDirection.Output;

        con.Open();
        SqlDataReader dr = cmd.ExecuteReader();
        while (dr.Read())
            Console.WriteLine(dr.GetString(0));
        con.Dispose();
        con.Close();

        return cmd.Parameters[2].Value.ToString();
    }
    protected void txtRecDate_TextChanged(object sender, EventArgs e)
    {

    }
    protected void txtCmtNo_TextChanged(object sender, EventArgs e)
    {
        if (txtCmtNo.Text != "")
        {
            txtPrjNo.Text = "";
            trPrjID.Visible = false;
            trtxtPrjID.Visible = false;

            txtTndrNo.Text = "";
            trtxtTndrNo.Visible = false;
            txtTndrNo.Visible = false;
        }
        else
        {
            txtPrjNo.Text = "";
            trPrjID.Visible = true;
            trtxtPrjID.Visible = true;

            txtTndrNo.Text = "";
            trtxtTndrNo.Visible = true;
            txtTndrNo.Visible = true;
        } 

    }
    static DateTime _inchareDueDate = System.DateTime.Now;
    protected void ddlJobPurpose_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlJobPurpose.SelectedValue == "1")   // For Distribution
        {
            
            string docDate = Convert.ToDateTime(txtRecDate.Text).ToString("dd/MM/yyyy", CultureInfo.InvariantCulture);

            // strDate = Convert.ToDateTime(strDate).ToString("MM/dd/yyyy", CultureInfo.InvariantCulture);

            _inchareDueDate = ConvertToDateTime(docDate);

            _inchareDueDate = _inchareDueDate.AddDays(1);


            // txtWorkDays.Text = getDaysByGivenEndDate(System.DateTime.Now.ToString(), dateEnd);
            //txtDueDate123.Text = dateEnd.ToString("dd/MMM/yyyy");

            //if (txtWorkDays.Text.Equals("5"))
            //    ddlGrade.SelectedIndex = 1;
            //else if (txtWorkDays.Text.Equals("8"))
            //    ddlGrade.SelectedIndex = 2;
            //else if (txtWorkDays.Text.Equals("10"))
            //    ddlGrade.SelectedIndex = 3;
            //else if (txtWorkDays.Text.Equals("15"))
            //    ddlGrade.SelectedIndex = 4;
            //else
            //    ddlGrade.SelectedIndex = 0;
        }
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        string strUpdate = "Update TempJobNo Set sessionUser =null , confirmed =0 WHERE  (sessionUser = '" + Session["UserName"].ToString() + "') ";

        SqlConnection cn = new SqlConnection(connValue);
        SqlCommand sqlCmd = new SqlCommand();
        sqlCmd.CommandType = CommandType.Text;
        sqlCmd.CommandText = strUpdate;
        sqlCmd.Connection = cn;

        // sqlCmd.Parameters.AddWithValue("@docDate", Convert.ToDateTime(txtPopupDatepicker.Text).ToString("dd/MMM/yyyy"));

        try
        {
            cn.Open();
            sqlCmd.ExecuteNonQuery();
        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
        finally
        {
            cn.Close();
        }


        this.ClientScript.RegisterClientScriptBlock(this.GetType(), "Close", "window.close()", true);

        //ClientScript.RegisterStartupScript(Page.GetType(), "SaveClose", "<script>alert('hey');</script>");

        // Response.Write("<script language='javascript'> { self.close() }</script>");
    }



    # endregion




    #region 

    private void FillDropBoxForDocument()
    {
         //string strQuery = "SELECT contactID, (firstName + ' ' + lastName) as OriginSender FROM  Contact WHERE (isActive = 1) ORDER BY OriginSender ";
         PopulateDropDownBox(ddlOriginSender, "SELECT contactID, (firstName + ' ' + lastName) as OriginSender FROM  Contact WHERE (isActive = 1) ORDER BY OriginSender ", "contactID", "OriginSender");
    }

    #endregion


    protected void ddlOriginSender_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void btnAddSender_Click(object sender, EventArgs e)
    {

    }
    protected void lnkFile_Click(object sender, EventArgs e)
    {
         addDocument();

        // Response.Redirect("~/DocumetAttachments.aspx", false);
    }

    #region MyRegion


    private void BindGridviewData()
    {
        con.Open();
        string sqlfileType = string.Empty;
        if (Session["fileType"].Equals("F"))
            sqlfileType = "select  fileID, FileName, FilePath, docID from FilesTable where isFileActive = 1 and  fileType ='F' and docID = " + Convert.ToInt32(Session["Dist_docID"]);
        else
            sqlfileType = "select  fileID, FileName, FilePath, docID from FilesTable where isFileActive = 1 and fileType ='A' and docID = " + Convert.ToInt32(Session["Dist_docID"]);

        SqlCommand cmd = new SqlCommand(sqlfileType, con);
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        DataSet ds = new DataSet();
         da.Fill(ds);
        con.Close();
         gvDetails.DataSource = ds;
        gvDetails.DataBind();
    }
    private Boolean CheckFileExist()
    {
        con.Open();
        string sqlfileType = string.Empty;
       
            sqlfileType = "select  fileID, FileName, FilePath, docID from FilesTable where docID = " + Convert.ToInt32(Session["Dist_docID"]);        

        SqlCommand cmd = new SqlCommand(sqlfileType, con);
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        DataSet ds = new DataSet();
        da.Fill(ds);
        con.Close();

        if (ds.Tables[0].Rows.Count>0)
             return true;
        else
            return false;
    }
    protected void btnUpload_Click(object sender, EventArgs e)
    {
        string prefixfileName = string.Empty;
        string filename = Path.GetFileName(fileUpload1.PostedFile.FileName);
        prefixfileName = Session["Dist_docID"] + "_" + filename;

        string filePath = string.Empty;
        if (fileUpload1.HasFile)
        {
            string folderName = ConfigurationManager.AppSettings["CCfolderName"].ToString();
            filePath = Path.Combine(folderName, prefixfileName);

            // filePath = Path.Combine(@"C:\eBookFiles", fileUpload1.FileName);

            fileUpload1.SaveAs(filePath);
            con.Open();
            SqlCommand cmd = new SqlCommand("Insert into FilesTable(fileName,docfileName,filePath,docID,fileType,sectionID,uploadByID,createUser,createDate) values(@Name,@docfileName,@Path,@docID,@fileType,@sectionID,@uploadByID,@createUser,@createDate)", con);
            cmd.Parameters.AddWithValue("@Name", filename);
            cmd.Parameters.AddWithValue("@docfileName", prefixfileName);
            cmd.Parameters.AddWithValue("@Path", filePath);
            cmd.Parameters.AddWithValue("@docID", Convert.ToInt32(Session["Dist_docID"]));
            cmd.Parameters.AddWithValue("@fileType", Session["fileType"].ToString());
            cmd.Parameters.AddWithValue("@sectionID", Session["SectionID"]);
            cmd.Parameters.AddWithValue("@uploadByID", Session["UserID"]);
            cmd.Parameters.AddWithValue("@createUser", Session["Username"].ToString()); 
            cmd.Parameters.AddWithValue("@createDate", System.DateTime.Now);
            cmd.ExecuteNonQuery();
            con.Close();

            BindGridviewData();
        }
        else
        {
            Response.Write("Please browse to upload the file ");
        } 
    }
    protected void lnkDownload_Click(object sender, EventArgs e)
    {
        LinkButton lnkbtn = sender as LinkButton;
        GridViewRow gvrow = lnkbtn.NamingContainer as GridViewRow;
        string filePath = gvDetails.DataKeys[gvrow.RowIndex].Value.ToString();

        filePath = filePath.Replace("C:", "E:");

        Response.ContentType = "image/jpg";
        Response.AddHeader("Content-Disposition", "attachment;filename=\"" + filePath + "\"");
        //Response.TransmitFile(Server.MapPath(filePath));

        Response.TransmitFile(filePath);
        Response.End();
    }
    protected void lnkDelete_Click(object sender, EventArgs e)
    {
        try
        {

            LinkButton lnkbtn = sender as LinkButton;
            GridViewRow gvrow = lnkbtn.NamingContainer as GridViewRow;
            string fileID = gvDetails.DataKeys[gvrow.RowIndex].Values[1].ToString();

            try
            {
                using (SqlConnection con = new SqlConnection(connValue))
                {
                    con.Open();
                    using (SqlCommand cmd = new SqlCommand("Update FilesTable Set isFileActive = 0,updateUser = @updateUser,updateDate = @updateDate where fileID = " + fileID, con))
                    {
                        cmd.Parameters.AddWithValue("@updateUser", Session["Username"].ToString());
                        cmd.Parameters.AddWithValue("@updateDate", System.DateTime.Now);
                        cmd.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception ex)
            {

            }           

            BindGridviewData();

        }
        catch (Exception ex)
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Error occurred while processing the request')</script>", false);
        }
    }
    protected void btnBack_Click(object sender, EventArgs e)
    {
        // this.ClientScript.RegisterClientScriptBlock(this.GetType(), "Close", "window.close()", true);

        // Response.Redirect("~/Documents/DocumetAttachments.aspx", false);
    }  
    public void DeleteAttributeData(int attrID)
    {
        try
        {
            using (SqlConnection con = new SqlConnection(connValue))
            {
                con.Open();
                using (SqlCommand cmd = new SqlCommand("Update FilesTable Set isFileActive = 0,updateUser = @updateUser,updateDate = @updateDate where fileID = " + attrID, con))
                {
                    cmd.Parameters.AddWithValue("@updateUser", Session["Username"].ToString());
                    cmd.Parameters.AddWithValue("@updateDate", System.DateTime.Now);
                    cmd.ExecuteNonQuery();
                }
            }
        }
        catch (Exception ex)
        {

        }
        finally
        {

        }
    }
   
    protected void gvDetails_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandArgument != "")
        {
            int attributeID = Convert.ToInt32(e.CommandArgument);
            DeleteAttributeData(attributeID);
        }
    }
    protected void gvDetails_RowDataBound(object sender, GridViewRowEventArgs e)
    {

    }
    #endregion



    protected void btnCmtBack_Click(object sender, EventArgs e)
    {
        txtCmtNo.Text = "";

        trCmtee.Visible = true;
        trtxtCmtee.Visible = false;

        checkCategoryStausForControls();
    }
    protected void btnPrjBack_Click(object sender, EventArgs e)
    {
        txtPrjNo.Text = "";

        trPrjID.Visible = true;
        trtxtPrjID.Visible = false;

        checkCategoryStausForControls();
    }
    protected void btnTndrBack_Click(object sender, EventArgs e)
    {
        txtTndrNo.Text = "";

        trTndrNo.Visible = true;
        trtxtTndrNo.Visible = false;

        checkCategoryStausForControls();
    }

    protected void lnkUploadFile_Click(object sender, EventArgs e)
    {
        if (lblJobDocID.Text == "")
            addDocument();

        Session["fileType"] = "";
        if (lblJobDocID.Text == "")
        {
           // addDocument();
            
            trUpload.Visible = true;
            trgrid.Visible = true;

         
        }
        else
        {
           
            trUpload.Visible = true;
            trgrid.Visible = true;
            
        }

        Session["fileType"] = "F"; // File

        BindGridviewData();
    }
    protected void imgBtnFile_Click(object sender, ImageClickEventArgs e)
    {
        //Session["fileType"] = "";
        //if (jobdocID == 0)
        //{
        //    addDocument();
        //    trUpload.Visible = true;
        //    trgrid.Visible = true;
        //    BindGridviewData();
        //}
        //else
        //{
        //    BindGridviewData();
        //    trUpload.Visible = true;
        //    trgrid.Visible = true;
        //}
        //Session["fileType"] = "F"; // File
    }
    protected void ImgBtnAttach_Click(object sender, ImageClickEventArgs e)
    {
        //Session["fileType"] = "";
        //if (jobdocID == 0)
        //{
        //    addDocument();
        //    trUpload.Visible = true;
        //    trgrid.Visible = true;
        //    BindGridviewData();
        //}
        //else
        //{
        //    BindGridviewData();
        //    trUpload.Visible = true;
        //    trgrid.Visible = true;
        //}
        //Session["fileType"] = "A"; // File
    }
    protected void lnkAttach_Click(object sender, EventArgs e)
    {
        Session["fileType"] = "";
        if (lblJobDocID.Text == "")
        {
            addDocument();
            trUpload.Visible = true;
            trgrid.Visible = true;           
        }
        else
        {          
            trUpload.Visible = true;
            trgrid.Visible = true;
        }

        Session["fileType"] = "A";    // Attachments
        BindGridviewData();
    }
    protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
    {
        Session["fileType"] = "";
        if (lblJobDocID.Text == "")
        {
            addDocument();
            trUpload.Visible = true;
            trgrid.Visible = true;
           
        }
        else
        {
           
            trUpload.Visible = true;
            trgrid.Visible = true;
        }
        Session["fileType"] = "F"; // File

        BindGridviewData();
    }
    protected void ImageButton2_Click(object sender, ImageClickEventArgs e)
    {
        Session["fileType"] = "";
        if (lblJobDocID.Text == "")
        {
            addDocument();
            trUpload.Visible = true;
            trgrid.Visible = true;
           
        }
        else
        {
           
            trUpload.Visible = true;
            trgrid.Visible = true;
        }
        Session["fileType"] = "A"; // File

        BindGridviewData();
    }
    protected void btnCancelDoc_Click1(object sender, EventArgs e)
    {
        Panel2.Visible = true;
        Panel1.Visible = false;

        ddlDocRef.SelectedIndex = 0;
    }
    protected void ddlInchargeType_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlInchargeType.SelectedValue == "1")
            ddlJobPurpose.SelectedValue = "4";
        else if (ddlInchargeType.SelectedValue == "2")
            ddlJobPurpose.SelectedValue = "6";
        else if (ddlInchargeType.SelectedValue == "3")
            ddlJobPurpose.SelectedValue = "12";
        else if (ddlInchargeType.SelectedValue == "4")
            ddlJobPurpose.SelectedValue = "1";
    }
    protected void txtDocRefNo_TextChanged(object sender, EventArgs e)
    {
        if (checkDocExist())
        {
            //this.Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('This document reference No was already loaded in the system')</script>", false);

            lblRefNo.Text = "Reference No Exist";
            txtDocRefNo.BackColor = System.Drawing.Color.Red;
            txtDocRefNo.Text = "";
            txtDocRefNo.Focus();
            return;
        }
        else
        {
            lblRefNo.Text = "Document Reference No.";
            txtDocRefNo.BackColor = System.Drawing.Color.White;

        }
    }
    private Boolean checkDocExist()
    {

        string prjTitle = string.Empty;
        using (SqlConnection cnn = new SqlConnection(connValue))
        {
            cnn.Open();
            using (SqlCommand cmm = new SqlCommand())
            {
                cmm.Connection = cnn;
                cmm.CommandText = "SELECT referenceNo  FROM Document WHERE referenceNo = '" + txtDocRefNo.Text.Trim() + "' ";
                using (SqlDataReader sqlDtReader = cmm.ExecuteReader())
                {
                    if (sqlDtReader.HasRows)
                    {
                        return true;
                    }
                }
            }
        }

        return false;
    }


    #region GenarateJobNO
    string strYear = string.Empty;
    private string GenarateAutomate_JobNo(int seriesID)
    {
        strYear = System.DateTime.Now.Year.ToString().Substring(2, 2);
        string _jobNo = string.Empty;
        int _maxjobNo = 0;
        string tempJobNo = string.Empty;

        //   _jobNo = new JobOrderData().getMaxJobNoSeriesOfPayment();

        // _jobNo =  new JobOrderData().getMaxPayJobNo("PR" + strYear + "%");

        _jobNo = new JobOrderData().getMaxJobOrderJobNo(strYear + "%", seriesID);

        if (_jobNo != "")
        {
            tempJobNo = _jobNo.Substring(_jobNo.Length - 4, 4);
            _maxjobNo = Convert.ToInt32(tempJobNo) + 1;

            // _maxjobNo = Convert.ToInt32(_jobNo) + 1;

            if (_maxjobNo.ToString().Length == 1)
                tempJobNo = "000" + _maxjobNo;

            if (_maxjobNo.ToString().Length == 2)
                tempJobNo = "00" + _maxjobNo;

            if (_maxjobNo.ToString().Length == 3)
                tempJobNo = "0" + _maxjobNo;

            if (_maxjobNo.ToString().Length == 4)
                tempJobNo = _maxjobNo.ToString();

            _jobNo = tempJobNo;
        }
        else
        {
            _jobNo = "0001";
        }

        return _jobNo;
    }
    public string GetJobNoByCurrentYear(int seriesID)
    {
        string jobNo = string.Empty;

        try
        {
            using (SqlConnection con = new SqlConnection(connValue))
            {
                con.Open();
                using (SqlCommand sqlCom = new SqlCommand())
                {
                    sqlCom.CommandType = CommandType.Text;
                    sqlCom.Connection = con;

                    string strJobNo = "SELECT  MAX(JobNo) + 1 AS maxJobNo  FROM TempJobNo WHERE (seriesTypeID = " + seriesID + ") AND (jobYear = YEAR(GETDATE())) ";

                    //  string strJobNo = "SELECT Max(JobNo) as JobNo  FROM   TempJobNo WHERE (confirmed = 1) AND (seriesTypeID = 2) and (JobNo like '" + strjobLike + "')";

                    sqlCom.CommandText = strJobNo;

                    using (SqlDataReader sqlReader = sqlCom.ExecuteReader())
                    {
                        while (sqlReader.Read())
                        {
                            jobNo = sqlReader["maxJobNo"].ToString();
                        }
                    }
                }
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {

        }
        return jobNo;
    }
    private string CheckSessionUserNull(int seriesID)
    {
        string jobNo = string.Empty;

        try
        {
            using (SqlConnection con = new SqlConnection(connValue))
            {
                con.Open();
                using (SqlCommand sqlCom = new SqlCommand())
                {
                    sqlCom.CommandType = CommandType.Text;
                    sqlCom.Connection = con;
                    // sqlCom.CommandText = "sp_CheckCurrentUserSessioExist";

                    sqlCom.CommandText = "SELECT JobNo FROM TempJobNo WHERE (seriesTypeID = " + seriesID + ") AND (confirmed = 0) and SessionUser is null ORDER BY JobNo DESC";
                    using (SqlDataReader sqlReader = sqlCom.ExecuteReader())
                    {
                        while (sqlReader.Read())
                        {
                            jobNo = sqlReader["JobNo"].ToString();
                        }
                    }
                }
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {

        }
        return jobNo;
    }
    private void updateSessionUser(int seriesID,string _jobNo)
    {
        // string strUpdate = "Delete from TempJobNo WHERE  (sessionUser = '" + Session["UserName"].ToString() +"') ";

        string strUpdate = "Update TempJobNo Set sessionUser = '" + Session["UserName"].ToString() + "' , confirmed =1 WHERE JobNo ='" + _jobNo + "' and (sessionUser is null) and (seriesTypeID = " + seriesID + ") and confirmed =0 ";

        SqlConnection cn = new SqlConnection(connValue);
        SqlCommand sqlCmd = new SqlCommand();
        sqlCmd.CommandType = CommandType.Text;
        sqlCmd.CommandText = strUpdate;
        sqlCmd.Connection = cn;

        // sqlCmd.Parameters.AddWithValue("@docDate", Convert.ToDateTime(txtPopupDatepicker.Text).ToString("dd/MMM/yyyy"));

        try
        {
            cn.Open();
            sqlCmd.ExecuteNonQuery();
        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
        finally
        {
            cn.Close();
        }
    }
    private string getJobTypeShortName(int seriesID)
    {
        string jobType = string.Empty;
        using (SqlConnection con = new SqlConnection(connValue))
        {
            con.Open();
            using (SqlCommand sqlCom = new SqlCommand())
            {
                // sqlCom.CommandType = CommandType.StoredProcedure;
                sqlCom.CommandType = CommandType.Text;
                sqlCom.Connection = con;
                sqlCom.CommandText = "SELECT DISTINCT jobTypeShortName FROM JobType WHERE seriesTypeID = " + seriesID;

                using (SqlDataReader sqlReader = sqlCom.ExecuteReader())
                {
                    while (sqlReader.Read())
                    {
                        jobType = sqlReader["jobTypeShortName"].ToString();
                    }
                }
            }
        }
        return jobType;
    }
    

    #endregion

    protected void ddlJobType_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
}
