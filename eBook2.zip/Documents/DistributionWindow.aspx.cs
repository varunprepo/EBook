﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using Datalayer;
using System.Globalization;


public partial class Documents_DistributionWindow : System.Web.UI.Page
{
    string connValue = System.Configuration.ConfigurationManager.ConnectionStrings["EBSDEBookConn"].ConnectionString;
    static int distID = 0; 
    static int _docID = 0; 
    static int _currentUserID = 0;


    protected void OnTextChanged(object sender, EventArgs e)
    {
        int workDays = 0;
        TextBox txtBox = (sender as TextBox);
        if (txtBox.Text != "")
        {
            workDays = Convert.ToInt32(txtBox.Text);

            int distribID = Convert.ToInt32(txtBox.ToolTip);

            if (workDays < 1)
            {
                txtBox.Text = "1";
                workDays = 1;
            }      

            string actionDueDate = getEndDateByGivenDays(System.DateTime.UtcNow.ToString("dd/MMM/yyyy"), workDays);
            new JobOrderData().UpdateDistributionDataForActionDueDate(distribID, ConvertToDateTime(actionDueDate).ToString(), workDays);
            gridload();
        }
    }
    protected void Page_Load(object sender, EventArgs e)
    {
      //  distID = Convert.ToInt32(Session["distributeID"]);
        
            
    }   
    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (new JobOrderData().checkDistributionExist(Convert.ToInt32(DropDownList1.SelectedValue), _currentUserID))
        {
            string strMsg = ""+ DropDownList1.SelectedItem.Text + " " +  " is already in your distribution list.";
            ClientScript.RegisterClientScriptBlock(this.GetType(), "Popup", "<script>alert('" + strMsg + "')</script>", false);
            DropDownList1.SelectedIndex = 0;
            return;
        }

        if (DropDownList1.SelectedIndex != 0)
        {
            string actionDueDate = getEndDateByGivenDays(System.DateTime.Now.ToString(), 2);

            new JobOrderData().AddDistributionData(Convert.ToInt32(DropDownList1.SelectedValue), 1, 2, Convert.ToDateTime(actionDueDate).ToString("dd/MMM/yyyy"), _currentUserID); // for Acion - 1-day 
            gridload();
            DropDownList1.SelectedIndex = 0;
        }
    }
  
    
    protected void Page_Init(object sender, EventArgs e)
    {
        if (Session["UserName"] == null)
        {
            Response.Redirect("~/LoginPage.aspx", false);
            return;
        }

        _docID = Convert.ToInt32(Session["Dist_docID"]);
        _currentUserID = Convert.ToInt32(Session["UserID"]);        
        if (!IsPostBack)
        {
            PopulateDropDownBox(DropDownList1, "SELECT contactID,Contact.firstName + ' ' + Contact.lastName AS DisplayName FROM Contact Where (Contact.isActive = 1) and (ContactID <> " + _currentUserID + ") Order by DisplayName; ", "contactID", "DisplayName");
            PopulateDropDownBox(dddlForCC, "SELECT contactID,Contact.firstName + ' ' + Contact.lastName AS DisplayName FROM Contact Where (Contact.isActive = 1) and (ContactID <> " + _currentUserID + ") Order by DisplayName; ", "contactID", "DisplayName");
            updateActionDueDateForPageLoad();
        }
        gridload();
        gridloadForCC();
    }

    private void PopulateDropDownBox(DropDownList ddlBox, string sqlQuery, string valueMember, string displayName)
    {
        DataTable table = new DataTable();
        try
        {
            using (SqlConnection sqlConn = new SqlConnection(connValue))
            {
                using (SqlDataAdapter da = new SqlDataAdapter(sqlQuery, sqlConn))
                {
                    sqlConn.Open();
                    da.Fill(table);
                }
            }
            //cmbBox.Items.Add("Select");
            ddlBox.DataSource = table;

            ddlBox.DataTextField = displayName;
            ddlBox.DataValueField = valueMember;
            //ddlBox.SelectedIndex = -1;

            ddlBox.DataBind();
            ddlBox.Items.Insert(0, new ListItem("--Select--"));
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    public void gridload()
    {
        DataSet ds = new DataSet();
        ds = (new JobOrderData().GetDistributionData(1, _currentUserID));
        GridView1.DataSource = ds;
        GridView1.DataBind();
    }

    public void gridloadForCC()
    {
        DataSet ds = new DataSet();
        ds = (new JobOrderData().GetDistributionDataForCC(1, _currentUserID));
        gridForCC.DataSource = ds;
        gridForCC.DataBind();
    }

    private string getEndDateByGivenDays(string strDate, int workDays)
    {
        SqlConnection con = new SqlConnection(connValue);
        SqlCommand cmd = new SqlCommand();
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Connection = con;

        cmd.CommandText = "AddWorkdays";
        SqlParameter prm = cmd.Parameters.Add("@ad_startDate", SqlDbType.DateTime);
        prm.Value = strDate;
        prm = cmd.Parameters.Add("@actual_workDays", SqlDbType.Int);
        prm.Value = workDays;
        prm = cmd.Parameters.Add("@endDate", SqlDbType.DateTime);
        prm.Direction = ParameterDirection.Output;
        con.Open();
        SqlDataReader dr = cmd.ExecuteReader();
        while (dr.Read())
            Console.WriteLine(dr.GetString(0));
        con.Dispose();
        con.Close();

        return cmd.Parameters[2].Value.ToString();
    }
    protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "delete")
        {
            string arguments = e.CommandArgument.ToString();
            string[] args = arguments.Split(';');
            new JobOrderData().DeleteDistributionData(Convert.ToInt32(args[0]));
        }
    }
    protected void GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        gridload();
    }
    protected void gridForCC_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "delete")
        {
            string arguments = e.CommandArgument.ToString();
            string[] args = arguments.Split(';');
            new JobOrderData().DeleteDistributionData(Convert.ToInt32(args[0]));
        }
    }
    protected void gridForCC_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        gridloadForCC();
    }
    protected void dddlForCC_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (new JobOrderData().checkDistributionExist(Convert.ToInt32(dddlForCC.SelectedValue), _currentUserID))
        {
            string strMsg = "" + dddlForCC.SelectedItem.Text + " " + " is already in your distribution list.";
            ClientScript.RegisterClientScriptBlock(this.GetType(), "Popup", "<script>alert('" + strMsg + "')</script>", false);
            dddlForCC.SelectedIndex = 0;
            return;
        } 

        if (dddlForCC.SelectedIndex != 0)
        {
            string actionDueDate = getEndDateByGivenDays(System.DateTime.Now.ToString(), 2);

            new JobOrderData().AddDistributionDataForCC(Convert.ToInt32(dddlForCC.SelectedValue), 1, _currentUserID); 
            gridloadForCC();
            dddlForCC.SelectedIndex = 0;
        }
    }
    protected void GridView1_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            DropDownList l = (DropDownList)e.Row.FindControl("ddljobtype");
            PopulateDropDownBox(l, "SELECT  docPurposeID, purpose FROM DocumentPurpose", "docPurposeID", "purpose");
            Label lblCntctID = (Label)e.Row.FindControl("lblContactID");
            Label lblDistID = (Label)e.Row.FindControl("lblDistID");
            TextBox afr = (TextBox)e.Row.FindControl("TextBox1");
            TextBox txtworkDays = (TextBox)e.Row.FindControl("txtWorkDays");
            txtworkDays.ToolTip = lblDistID.Text;
            l.ToolTip = lblDistID.Text;
            l.SelectedValue = afr.Text;
            l.SelectedIndexChanged += new EventHandler(SelectedIndexChanged);
            TextBox txtdate = (TextBox)e.Row.FindControl("lblJoindate");            // ActionDueDate 
            txtdate.ToolTip = lblDistID.Text; 
           // txtdate.ToolTip = txtworkDays.Text;
            txtdate.TextChanged += new EventHandler(txtdate_TextChanged);             
        }
    }
    protected void SelectedIndexChanged(object sender, EventArgs e)
    {       
        DropDownList ddl = (DropDownList)sender;
        if (ddl.SelectedIndex != 0)
        {             
            string distID = ddl.ToolTip;

            if (ddl.SelectedValue == "3") // Distibution
            {
                new JobOrderData().UpdateDistributionDataForPurpose(Convert.ToInt32(distID), Convert.ToInt32(ddl.SelectedValue), getEndDateByGivenDays(1));
            }
            else
                new JobOrderData().UpdateDistributionDataForPurpose(Convert.ToInt32(distID), Convert.ToInt32(ddl.SelectedValue), "");

            gridload();
        }
    }
    protected void txtdate_TextChanged(object sender, EventArgs e)
    {
        TextBox tdate = (TextBox)sender; 
        string actionDate = tdate.Text;
        //int workDays = Convert.ToInt32(tdate.ToolTip);        

        distID = Convert.ToInt32(tdate.ToolTip);
        new JobOrderData().UpdateDistributionDataForActionDueDate(Convert.ToInt32(distID), actionDate, getWorkDays(actionDate));
        gridload();
    }
    private void updateActionDueDateForPageLoad()
    {
        Dictionary<int, int> dictionaryWorkdays = new Dictionary<int, int>();
        dictionaryWorkdays = new JobOrderData().GetWorkDaysForPageLoad(_currentUserID);

       foreach (KeyValuePair<int, int> pair in dictionaryWorkdays)
       {
           int _distID = pair.Key;
           int workDays = pair.Value;

           string actionDate = getEndDateByGivenDays(System.DateTime.Now.ToString(), workDays);
           new JobOrderData().UpdateDistributionActionDueDateForPageLoad(_distID, actionDate);
       } 
    } 
   
    private int getWorkDays(string actionDate)
    {
        int _workDays =0;
        DateTime dateEnd = System.DateTime.Now;
        dateEnd = ConvertToDateTime(actionDate);
        return  _workDays = Convert.ToInt32(getDaysByGivenEndDate(System.DateTime.Now.ToString(), dateEnd));
    }
    private DateTime ConvertToDateTime(string strDateTime)
    {
        DateTime dtFinaldate; string sDateTime;
        try
        {
            //dtFinaldate = Convert.ToDateTime(strDateTime); 

            string[] sDate = strDateTime.Split('/');
            sDateTime = sDate[1] + '/' + sDate[0] + '/' + sDate[2];
            dtFinaldate = Convert.ToDateTime(sDateTime);
        }
        catch (Exception e)
        {
            string[] sDate = strDateTime.Split('/');
            sDateTime = sDate[0] + '/' + sDate[1] + '/' + sDate[2];
            dtFinaldate = Convert.ToDateTime(sDateTime);
        }
        return dtFinaldate;
    }
    private string getDaysByGivenEndDate(string strDate, DateTime endDate)
    {
        strDate = Convert.ToDateTime(strDate).ToString("MM/dd/yyyy", CultureInfo.InvariantCulture);
        //endDate = Convert.ToDateTime(endDate).ToString("MM/dd/yyyy", CultureInfo.InvariantCulture);

        //DateTime dt = DateTime.ParseExact(endDate, "d/M/yyyy", null);
        //endDate = dt.ToString("dd/MM/yyyy");

        DateTime strDt = DateTime.ParseExact(strDate, "MM/dd/yyyy", CultureInfo.InvariantCulture);
        //DateTime endDt = DateTime.ParseExact(endDate, "MM/dd/yyyy", CultureInfo.InvariantCulture);

        SqlConnection con = new SqlConnection(connValue);
        SqlCommand cmd = new SqlCommand();

        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Connection = con;

        cmd.CommandText = "testSP";

        SqlParameter prm = cmd.Parameters.Add("@ad_startDate", SqlDbType.DateTime);
        prm.Value = strDt;

        prm = cmd.Parameters.Add("@ad_endDate", SqlDbType.DateTime);
        prm.Value = endDate;

        prm = cmd.Parameters.Add("@ai_workDays", SqlDbType.Int);
        prm.Direction = ParameterDirection.Output;

        //prm = cmd.Parameters.Add("@as_errMsg", SqlDbType.VarChar);
        //prm.Direction = ParameterDirection.Output;

        con.Open();
        SqlDataReader dr = cmd.ExecuteReader();
        while (dr.Read())
            Console.WriteLine(dr.GetString(0));
        con.Dispose();
        con.Close();

        return cmd.Parameters[2].Value.ToString();
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        string alreadyDistibuted = string.Empty;
        string personOnLeave = new JobOrderData().AddDocumentDistributionDataForTo(_docID, ref alreadyDistibuted, _currentUserID, Session["UserName"].ToString());
        if (personOnLeave != "")
        {
            
            ClientScript.RegisterClientScriptBlock(this.GetType(), "Popup", "<script>alert('" + personOnLeave + "')</script>", false);
        }

      if (alreadyDistibuted != "")
          ClientScript.RegisterClientScriptBlock(this.GetType(), "Popup", "<script>alert('" + alreadyDistibuted + "')</script>", false);


      Session["personOnLeave"] = personOnLeave;

      Session["alreadyDistibuted"] = alreadyDistibuted;

      Session["distribDocID"] = _docID;

      string script = "this.window.opener.location=this.window.opener.location;this.window.close();";
      if (!ClientScript.IsClientScriptBlockRegistered("REFRESH_PARENT"))
          ClientScript.RegisterClientScriptBlock(typeof(string), "REFRESH_PARENT", script, true);

    }
    public DataTable GetDataFromDB(string dataTabName, string sqlQuery)
    {
        DataTable table = null;
        SqlConnection sqlConn = new SqlConnection(connValue);
        sqlConn.Open();
        SqlDataAdapter sqlDtAdptr = null;
        table = new DataTable(dataTabName);
        sqlDtAdptr = new SqlDataAdapter(@sqlQuery, sqlConn);
        sqlDtAdptr.Fill(table);
        sqlConn.Close();
        return table;
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        string script = "this.window.opener.location=this.window.opener.location;this.window.close();";
        if (!ClientScript.IsClientScriptBlockRegistered("REFRESH_PARENT"))
            ClientScript.RegisterClientScriptBlock(typeof(string), "REFRESH_PARENT", script, true);
    }

    private string getEndDateByGivenDays(int Days)
    {
        SqlConnection con = new SqlConnection(connValue);
        SqlCommand cmd = new SqlCommand();
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Connection = con;
       
        
            cmd.CommandText = "AddWorkdays";
            SqlParameter prm = cmd.Parameters.Add("@ad_startDate", SqlDbType.DateTime);
            prm.Value = System.DateTime.Now;
            prm = cmd.Parameters.Add("@actual_workDays", SqlDbType.Int);
            prm.Value = Days;
            prm = cmd.Parameters.Add("@endDate", SqlDbType.DateTime);
            prm.Direction = ParameterDirection.Output;
            con.Open();
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
                Console.WriteLine(dr.GetString(0));
            con.Dispose();
            con.Close();
 
        return cmd.Parameters[2].Value.ToString();
    }

}