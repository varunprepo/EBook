﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Documents_CheckDocRefNo : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnYes_Click(object sender, EventArgs e)
    {
        Session["DocID"] = Session["ExistingDocID"];
        Session["DocCategoryID"] = "2";
        //Session["UrlRef"] = "~/Documents/ReceiveUploadDocuments.aspx";
        Response.Redirect("~/Documents/DocumentDetails.aspx", false);
    }
    //protected void btnNo_Click(object sender, EventArgs e)
    //{
    //    string script = "this.window.close();";
    //    ClientScript.RegisterClientScriptBlock(this.GetType(), "PageClose", script, true);         
    //    //Session["DocCategoryID"] = Session["ExistingDocCategoryID"];
    //    //Session["DocID"] = null;
    //    //Session["JobID"] = null;
    //    //Response.Redirect("~/Documents/DocumentDetails.aspx", false);
    //}
}