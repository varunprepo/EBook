﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;
using Datalayer;
using System.Web.UI.HtmlControls;
public partial class Documents_ReceiveSentDocuments : System.Web.UI.Page
{
    string connValue = ConfigurationManager.ConnectionStrings["EBSDEBookConn"].ToString();
     int _currentUserID = 0;   
  
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["UserName"] == null)
        {
            Response.Redirect("~/LoginPage.aspx", false);
            return;
        }

        _currentUserID = Convert.ToInt32(Session["UserID"]);      

        if (!IsPostBack)
        {
            gridloadForDocReceivedData();
            gridloadForDocUploadData();
        }
    }
    protected void ddl_SelectedIndexChanged(object sender, EventArgs e)
    {
        DropDownList ddl = (DropDownList)sender;
        if (ddl.SelectedIndex != 0)
        {
            string distID = ddl.ToolTip;
            new JobOrderData().UpdateUploadDistributionStatus(Convert.ToInt32(distID), Convert.ToInt32(ddl.SelectedValue));
            gridloadForDocUploadData();
        }
    }
    public void gridloadForDocReceivedData()
    {
        DataSet ds = new DataSet();
        ds = (new JobOrderData().FillDocReceivedData(_currentUserID));
        gridDocReceive.DataSource = ds;
        DataTable dt = ds.Tables[0];
        if (dt.Rows.Count != 0)
        {
            gridDocReceive.DataSource = dt;
        }
        else
        {
            gridDocReceive.DataSource = null;
        }
        Session["recDocument"] = dt;
        lblRecCnt.Text = " Record Count :  " + dt.Rows.Count.ToString();
        gridDocReceive.DataBind();
    }
    public void gridloadForDocUploadData()
    {
        DataSet ds = new DataSet();
        ds = (new JobOrderData().FillDocUploadData(_currentUserID));
        gridDocReceive.DataSource = ds;
        DataTable dt = ds.Tables[0];
        if (dt.Rows.Count != 0)
        {
            gridSent.DataSource = dt;
        }
        else
        {
            gridSent.DataSource = null;         
        }
        lblSentCnt.Text = " Record Count :  " + dt.Rows.Count.ToString();
        Session["sentDocument"] = dt;
        gridSent.DataBind();
    }
    protected void btnDocReceive_Click(object sender, EventArgs e)
    {
        Session["docID"] = null;
        Session["JobID"] = null;
        Session["PayID"] = null;

        Response.Redirect("~/Documents/DocumentDetailsWindow.aspx?btnDocNew=1&RecSentCatID=1", false);  // 1- for rec
    }

    protected void btnDocUpload_Click(object sender, EventArgs e)
    {
        Session["docID"] = null;
        Session["JobID"] = null;
        Session["PayID"] = null;
       
        // Response.Redirect("~/Documents/DocumentDetailsWindow.aspx?RecSentCatID=2", false);

        Response.Redirect("~/Documents/DocumentDetailsWindow.aspx?btnDocNew=2&RecSentCatID=2", false);
    }
    protected void gridSent_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            DropDownList l = (DropDownList)e.Row.FindControl("ddljobtype");
            PopulateDropDownBox(l, "SELECT  docStatusID, docStatusName FROM DocumentStatus", "docStatusID", "docStatusName");

            Label lblDistiD = (Label)e.Row.FindControl("lblDistID");
            Label afr = (Label)e.Row.FindControl("lblDocStatusID");

            l.ToolTip = lblDistiD.Text;
            l.SelectedValue = afr.Text;
           // l.SelectedIndexChanged += new EventHandler(SelectedIndexChanged);

            LinkButton lnkRef = (LinkButton)e.Row.FindControl("lnkBtnDocSentRead");         
            Control ctrlSuperseded = e.Row.FindControl("divUploadSuperseded");
            HtmlGenericControl htmlCtrlSuperseded = ctrlSuperseded as HtmlGenericControl;          

            if (htmlCtrlSuperseded.InnerText.Equals("True"))
            {
                e.Row.Cells[1].BackColor = System.Drawing.Color.WhiteSmoke;
                e.Row.Cells[1].ForeColor = System.Drawing.Color.Gray;

                e.Row.Cells[2].BackColor = System.Drawing.Color.WhiteSmoke;
                e.Row.Cells[2].ForeColor = System.Drawing.Color.Gray;     
            }
        }
    }
    protected void lnkBtnDocReadDate_Click(object sender, EventArgs e)
    {

        try
        {
            Session["UrlRef"] = Request.Url.AbsoluteUri;

            LinkButton lnkDistributrID = (LinkButton)sender;
            GridViewRow gvr = (GridViewRow)lnkDistributrID.NamingContainer;
            Session["distributeID"] = ((HtmlGenericControl)gvr.FindControl("divDistributeID")).InnerText;
            new JobOrderData().UpdateDistributionDateRead(Convert.ToInt32(((HtmlGenericControl)gvr.FindControl("divDistributeID")).InnerText), _currentUserID);
            int docid = Convert.ToInt32(((HtmlGenericControl)gvr.FindControl("divDocID")).InnerText);
            Response.Redirect("~/Documents/DocumentDetailsWindow.aspx?docRecID=" + docid + "&RecSentCatID=1", false);
        }
        catch (Exception ex)
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Error occurred while processing the request')</script>", false);
        } 
     
    }
    protected void lnkBtnDocSentReadDate_Click(object sender, EventArgs e)
    {
        try
        {
            Session["UrlRef"] = Request.Url.AbsoluteUri;

            LinkButton lnkDistributrID = (LinkButton)sender;
            GridViewRow gvr = (GridViewRow)lnkDistributrID.NamingContainer;
            Session["distributeID"] = ((HtmlGenericControl)gvr.FindControl("divDistributeID")).InnerText;
            new JobOrderData().UpdateDistributionDateRead(Convert.ToInt32(((HtmlGenericControl)gvr.FindControl("divDistributeID")).InnerText), _currentUserID);
            int docid = Convert.ToInt32(((HtmlGenericControl)gvr.FindControl("divDocID")).InnerText);

            if ((Session["CmpID"].ToString() == "362"))
                Response.Redirect("~/Documents/DocumentDetailsWindow.aspx?docRecID=" + docid + "&RecSentCatID=2", false);
            else
                Response.Redirect("~/Documents/NonEBDDocumentInfo.aspx?docRecID=" + docid + "&RecSentCatID=2", false);
               

            
        }
        catch (Exception ex)
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Error occurred while processing the request')</script>", false);
        }

        // lnkBtnDocSentReadDate_Click
    }   
   
    private void PopulateDropDownBox(DropDownList ddlBox, string sqlQuery, string valueMember, string displayName)
    {
        DataTable table = new DataTable();
        try
        {
            using (SqlConnection sqlConn = new SqlConnection(connValue))
            {
                using (SqlDataAdapter da = new SqlDataAdapter(sqlQuery, sqlConn))
                {
                    sqlConn.Open();
                    da.Fill(table);
                }
            }
            //cmbBox.Items.Add("Select");
            ddlBox.DataSource = table;

            ddlBox.DataTextField = displayName;
            ddlBox.DataValueField = valueMember;
            //ddlBox.SelectedIndex = -1;

            ddlBox.DataBind();
            ddlBox.Items.Insert(0, new ListItem("--Select--"));
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    protected void gridDocReceive_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            LinkButton lnkRef = (LinkButton)e.Row.FindControl("lnkBtnDocRec");
            Label txtDocType = (Label)e.Row.FindControl("txtDocType");
            Label txtDate = (Label)e.Row.FindControl("txtDate");
            TextBox txtDocID = (TextBox)e.Row.FindControl("txtDocID");    
            Control ctrlReceiveCreateUser = e.Row.FindControl("divReceiveCreateUserID");
            Control ctrlReceiveOriginContactID = e.Row.FindControl("divReceiveOriginContactID");
            Control ctrlSuperseded = e.Row.FindControl("divUploadSuperseded");
            HtmlGenericControl htmlCtrlSuperseded = ctrlSuperseded as HtmlGenericControl;
            HtmlGenericControl htmlCtrlctrlReceiveOriginContactID = ctrlReceiveOriginContactID as HtmlGenericControl;
            HtmlGenericControl htmlCtrlReceiveCreateUser = ctrlReceiveCreateUser as HtmlGenericControl;


            Control ctrlDocRead = e.Row.FindControl("divDateRead");
            HtmlGenericControl htmlCtrlDateRead = ctrlDocRead as HtmlGenericControl;

            if (htmlCtrlDateRead.InnerText.Equals(""))  //htmlCtrlDateRead.InnerText.Equals("")
            {
                e.Row.Cells[1].ForeColor = System.Drawing.Color.Blue;
                e.Row.Cells[1].Font.Bold = true;
                e.Row.Cells[2].ForeColor = System.Drawing.Color.Blue;
                e.Row.Cells[2].Font.Bold = true;
               
            }

            if (htmlCtrlSuperseded.InnerText.Equals("True"))
            {
                e.Row.Cells[1].BackColor = System.Drawing.Color.WhiteSmoke;
                e.Row.Cells[1].ForeColor = System.Drawing.Color.Gray;

                e.Row.Cells[2].BackColor = System.Drawing.Color.WhiteSmoke;
                e.Row.Cells[2].ForeColor = System.Drawing.Color.Gray;


                if (htmlCtrlReceiveCreateUser.InnerText.Equals(Session["UserID"].ToString()) || htmlCtrlctrlReceiveOriginContactID.InnerText.Equals(Session["UserID"].ToString()) || Session["UserProfileID"].ToString().Equals("1"))
                {
                    if (lnkRef != null)
                    {
                        lnkRef.Enabled = true;
                        lnkRef.Font.Underline = true;
                    }                  
                }
                else
                {
                    if (lnkRef != null)
                    {
                        lnkRef.Enabled = false;
                        lnkRef.Font.Underline = false;
                        lnkRef.ForeColor = System.Drawing.Color.Gray;

                        e.Row.Cells[0].BackColor = System.Drawing.Color.WhiteSmoke;
                        e.Row.Cells[0].ForeColor = System.Drawing.Color.Black;
                    }
                }
            }
        }
    }
   
    protected void gridSent_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        gridSent.PageIndex = e.NewPageIndex;
        gridSent.DataSource = Session["sentDocument"];
        gridSent.DataBind();
        gridloadForDocUploadData();
    }
    protected void gridDocReceive_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        gridDocReceive.PageIndex = e.NewPageIndex;
        gridDocReceive.DataSource = Session["recDocument"];
        gridDocReceive.DataBind();
        gridloadForDocReceivedData();
    }
}