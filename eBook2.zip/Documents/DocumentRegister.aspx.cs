﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
using Datalayer;

public partial class Documents_DocumentRegister : System.Web.UI.Page
{
    string connValue = ConfigurationManager.ConnectionStrings["EBSDEBookConn"].ToString();
   int docStatID = 0;
   static IList<string> userRightsColl = null;
   static int _currentUserID = 0;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["UserName"] == null)
        {
            Response.Redirect("~/LoginPage.aspx", false);
            return;
        }
        userRightsColl = (IList<string>)Session["UserRightsColl"];
        docStatID = Convert.ToInt32(Request.QueryString["docStatID"]);

        _currentUserID = Convert.ToInt32(Session["UserID"]);
        if (!IsPostBack)
        {
            FillDropdownData();

            if (Session["userProfileID"].ToString().Equals("1"))
            {
                lblTitle.Text = "EBSD Document Register";
                if (docStatID == 0)
                    FillTab2(0);
                else
                    FillTab2(docStatID);
               
            }
            else if ((!userRightsColl.Contains("1")) & (Session["SectionID"].ToString().Equals("7"))) // All Sections
            {
                lblTitle.Text = "EBSD Document Register";
                if (docStatID == 0)
                    FillTab2(0);
                else
                    FillTab2(docStatID);
            }
            else
            {
                lblTitle.Text = "Document Register In " + Session["SectionName"];

                if (docStatID == 0)
                    FillDataSectionWise(0, Convert.ToInt32(Session["SectionID"]));
                else
                    FillDataSectionWise(docStatID, Convert.ToInt32(Session["SectionID"]));
               
            }           
        }

        
    }

    private void hideRow()
    {
        trRow1.Visible = false;
        trRow2.Visible = false;
        trRow3.Visible = false;

        trRow4.Visible = false;
        trRow5.Visible = false;
        trRow6.Visible = false;

        trRow7.Visible = false;
        trRow8.Visible = false;
    }
    protected void btnClearAllSort_Click(object sender, EventArgs e)
    {
        docStatID = 0;

        ddlDocRefNo.SelectedIndex = 0;
        ddlTypeOfDoc.SelectedIndex = 0;
        ddlStatus.SelectedIndex = 0;
        // ddlDocStatus.SelectedValue = "0";



        ddlOriginSender.SelectedIndex = 0;
        ddlCompany.SelectedIndex = 0;

        ddlDBSMajorSubject.SelectedIndex = 0;
        txtProjectTitle.Text = "";
        txtCommitmentNo.Text = "";
        txtProjectID.Text = "";
        txtTenderNo.Text = "";
        txtSubject.Text = "";
        txtDescription.Text = "";
        // txtDistribution.Text = "";
        ddlIssuedBy.SelectedIndex = 0;

        ddlDBSDetailedSubject.Items.Clear();

        TextBox1.Text = "";

        if (ddlDBSDetailedSubject.SelectedIndex != -1)
            ddlDBSDetailedSubject.SelectedIndex = 0;

        if (Session["userProfileID"].ToString().Equals("1"))
        {
            lblTitle.Text = "EBSD Document Register";
            if (docStatID == 0)
                FillTab2(0);
            else
                FillTab2(docStatID);

        }
        else if (!userRightsColl.Contains("1") & (Session["SectionID"].ToString().Equals("7"))) // All Sections
        {
            lblTitle.Text = "EBSD Document Register";
            if (docStatID == 0)
                FillTab2(0);
            else
                FillTab2(docStatID);
        }
        else
        {
            lblTitle.Text = "Document Register In " + Session["SectionName"];

            if (docStatID == 0)
                FillDataSectionWise(0, Convert.ToInt32(Session["SectionID"]));
            else
                FillDataSectionWise(docStatID, Convert.ToInt32(Session["SectionID"]));

        }   

    }
    protected void OpenDocumentDetails_Click(object sender, EventArgs e)
    {
        try
        {
            LinkButton lnkDistributrID = (LinkButton)sender;
            GridViewRow gvr = (GridViewRow)lnkDistributrID.NamingContainer;
            Session["distributeID"] = ((HtmlGenericControl)gvr.FindControl("divDistributeID")).InnerText;
            new JobOrderData().UpdateDistributionDateRead(Convert.ToInt32(((HtmlGenericControl)gvr.FindControl("divDistributeID")).InnerText), _currentUserID);
            int docid = Convert.ToInt32(((HtmlGenericControl)gvr.FindControl("divDocID")).InnerText);
            int docCatid = Convert.ToInt32(((HtmlGenericControl)gvr.FindControl("divDocCatID")).InnerText);        

            Response.Redirect("~/Documents/DocumentDetailsWindow.aspx?docRecID=" + docid + "&RecSentCatID= " + docCatid + "", false);
        }
        catch (Exception ex)
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Error occurred while processing the request')</script>", false);
        }
    }   
    protected void btnSearch_Click(object sender, EventArgs e)
    {
        if (TextBox1.Text != "")
            return;

        if ((txtProjectTitle.Text == "") & (txtCommitmentNo.Text == "") & (txtProjectID.Text == "") & (txtTenderNo.Text == "") & (ddlDBSMajorSubject.SelectedIndex == 0))
        {
            if ((ddlDBSDetailedSubject.SelectedIndex == 0) || (ddlDBSDetailedSubject.SelectedIndex == -1))
            {
                if (Session["userProfileID"].ToString().Equals("1"))
                    FillTab2(0);  // SearchDocSectionWise
                else if (!userRightsColl.Contains("1") & (Session["SectionID"].ToString().Equals("7"))) // All Sections
                    FillTab2(0); 
                else
                    FillDataSectionWise(docStatID, Convert.ToInt32(Session["SectionID"]));
            }
            else
            {
                if (Session["userProfileID"].ToString().Equals("1"))             // All Section
                    FillDataForProjectSectionWise(0);
               else if (!userRightsColl.Contains("1") & (Session["SectionID"].ToString().Equals("7"))) // All Sections
                    FillDataForProjectSectionWise(0);
                else
                    FillDataForProjectSectionWise(Convert.ToInt32(Session["SectionID"]));
            }
        }
        else
        {
            if (Session["userProfileID"].ToString().Equals("1"))
                FillDataForProjectSectionWise(0);
             else if (!userRightsColl.Contains("1") & (Session["SectionID"].ToString().Equals("7"))) // All Sections
                FillDataForProjectSectionWise(0);
            else
                FillDataForProjectSectionWise(Convert.ToInt32(Session["SectionID"]));
        }
    }
    protected void ddlDBSDetailedSubject_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    private const string ASCENDING = " ASC";
    private const string DESCENDING = " DESC";
    public SortDirection GridViewSortDirection
    {
        get
        {
            if (ViewState["sortDirection"] == null)
                ViewState["sortDirection"] = SortDirection.Ascending;

            return (SortDirection)ViewState["sortDirection"];
        }
        set { ViewState["sortDirection"] = value; }
    }
    protected void GVMyDocs_Sorting(object sender, GridViewSortEventArgs e)
    {
        string sortExpression = e.SortExpression;


        if (GridViewSortDirection == SortDirection.Ascending)
        {
            GridViewSortDirection = SortDirection.Descending;
            SortGridView(sortExpression, DESCENDING);

        }
        else
        {
            GridViewSortDirection = SortDirection.Ascending;
            SortGridView(sortExpression, ASCENDING);
        }   
    }
    private void SortGridView(string sortExpression, string direction)
    {
        if (ddlStatus.SelectedIndex == 0)
            docStatID = 0;
        else
            docStatID = Convert.ToInt32(ddlStatus.SelectedItem.Value);

        DataTable dt = new DataTable();
        if (docStatID == 0)
            dt = FillTab2(0);
        else
            dt = FillTab2(docStatID);


        //if (Session["userProfileID"].ToString().Equals("1"))
        //    FillTab2(0);  // SearchDocSectionWise
        //else if (!userRightsColl.Contains("1") & (Session["SectionID"].ToString().Equals("7"))) // All Sections
        //    FillTab2(0);
        //else
        //    FillDataSectionWise(docStatID, Convert.ToInt32(Session["SectionID"]));

        DataView dv = new DataView(dt);
        dv.Sort = sortExpression + direction;

        gvMyDocument0.DataSource = dv;
        gvMyDocument0.DataBind();
    }
    //===================================================================================================================================================

    private void FillDropdownData()
    {
        //uCls.FillDropDownList(ddlDocRefNo, "SelectDocRefNoForMyDocs", null, null, null, null, dtMyDocuments, null);
        //uCls.FillDropDownList(ddlTypeOfDoc, "SelectDocTypesForMyDocs", null, null, null, null, dtMyDocuments, null);
        //uCls.FillDropDownList(ddlStatus, "SelectDocStatusForMyDocs", null, null, null, null, dtMyDocuments, null);
        //uCls.FillDropDownList(ddlOriginSender, "SelectOriginSenderForMyDocs", null, null, null, null, dtMyDocuments, null);
        //uCls.FillDropDownList(ddlCompany, "SelectCompanyForMyDocs", null, null, null, null, dtMyDocuments, null);

        int currentUserID = Convert.ToInt32(Session["UserID"]);

        string strQuery = "SELECT  documentID, referenceNo FROM DOCUMENT ORDER BY referenceNo";
        PopulateDropDownBox(ddlDocRefNo, strQuery, "documentID", "referenceNo");

        PopulateDropDownBox(ddlTypeOfDoc, "select docTypeID,documentType from DocumentType ", "docTypeID", "documentType");       
       
        PopulateDropDownBox(ddlStatus, "select docStatusID,docStatusName from DocumentStatus ", "docStatusID", "docStatusName");
        if (docStatID != 0)
            ddlStatus.SelectedValue = docStatID.ToString();
        
        string strOrgin = "SELECT DISTINCT DocumentDistribution.contactID, Contact.firstName + ' ' + Contact.lastName AS DisributeName " + 
                " FROM DocumentDistribution INNER JOIN   Contact ON DocumentDistribution.contactID = Contact.contactID AND DocumentDistribution.contactID = Contact.contactID ORDER BY DisributeName";


        PopulateDropDownBox(ddlOriginSender, strOrgin, "contactID", "DisributeName"); // 00000

        string strCompany = "SELECT DISTINCT [Document].originCompanyID, Company.cmpName FROM   [Document] INNER JOIN  Company ON [Document].originCompanyID = Company.companyID ORDER BY Company.cmpName";
        PopulateDropDownBox(ddlCompany, strCompany, "originCompanyID", "cmpName");

        //PopulateDropDownBox(ddlDBSMajorSubject, "select dbsDescription,dbsID from DBSValues where dbsID=dbsParentID order by dbsDescription", "dbsID", "dbsDescription");


        string strIssed = "SELECT DISTINCT DocumentDistribution.issuedByContactID, Contact.firstName + ' ' + Contact.lastName AS Sender " + 
                         " FROM    DocumentDistribution INNER JOIN  Contact ON DocumentDistribution.issuedByContactID = Contact.contactID ORDER BY Sender";

        PopulateDropDownBox(ddlIssuedBy, strIssed, "issuedByContactID", "Sender");      // 00000

        PopulateDropDownBox(ddlDBSMajorSubject, "SELECT dbsID, dbsDescription FROM DBSValues WHERE (dbsID = dbsParentID) ORDER BY dbsDescription", "dbsID", "dbsDescription");

        // PopulateDropDownBox(ddlDBSDetailedSubject, "SELECT dbsID, dbsDescription FROM DBSValues WHERE (dbsID = dbsParentID) ORDER BY dbsDescription", "issuedByContactID", "IssuedByName"); 

        // PopulateDropDownBox(ddlIssuedBy, "select dbsDescription,dbsID from DBSValues", "dbsID", "dbsDescription");   // 00000
        //ddlDBSDetailedSubject     //select dbsDescription,dbsID from DBSValues where dbsID<>dbsParentID and dbsParentID=" + dbsID


    }
    private void PopulateDropDownBox(DropDownList ddlBox, string sqlQuery, string valueMember, string displayName)
    {
        ddlBox.DataBound += new EventHandler(this.ddlBox_DataBound);
        ddlBox.DataSource = ExecuteSql(sqlQuery);
        ddlBox.DataTextField = displayName;
        ddlBox.DataValueField = valueMember;
        ddlBox.SelectedIndex = -1;
        ddlBox.DataBind();
    }
    protected void ddlBox_DataBound(object sender, EventArgs e)
    {
        DropDownList ddl = (DropDownList)sender;
        ListItem emptyItem = new ListItem("", "");
        ddl.Items.Insert(0, emptyItem);
    }
    public DataSet ExecuteSql(string sql)
    {
        SqlDataAdapter da;
        DataSet ds;
        ds = new DataSet();
        SqlConnection con = new SqlConnection(connValue);
        try
        {
            if (con.State == ConnectionState.Open)
            {
                con.Close();
            }
            con.Open();
            da = new SqlDataAdapter(sql, con);
            da.Fill(ds);
            con.Dispose();
            con.Close();
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            con.Close();
        }
        return ds;
    }
    private DataTable SearchDocumetReference()
    {
        DataSet ds = new DataSet();
        try
        {
            string strSubject = string.Empty;
            if (TextBox1.Text != "")
                strSubject = "%" + TextBox1.Text + "%";


            ds = new JobOrderData().GetDocumentDetailsByRefenceNo(strSubject);           

            DataView dvCommitted = new DataView(ds.Tables[0]);
           

            Session["SearchDocByREfence"] = ds.Tables[0];

            lblDocCnt.Text = " Record Count =  " + ds.Tables[0].Rows.Count.ToString();

            gvMyDocument0.DataSource = dvCommitted;
            gvMyDocument0.DataBind();

        }
        catch (Exception ex)
        {

        }

        return ds.Tables[0];
    }
    private DataTable FillTab2(int docStatID)
    {
        DataSet ds = new DataSet();
        try
        {
            

            Int32 docContactID;
            Int32.TryParse("0", out docContactID);

            Int32 docID;
            Int32.TryParse(ddlDocRefNo.SelectedValue, out docID);

            Int32 docTypeID;
            Int32.TryParse(ddlTypeOfDoc.SelectedValue, out docTypeID);

            Int32 docStatusID;
            if (docStatID==0)
             Int32.TryParse(ddlStatus.SelectedValue, out docStatusID);
            else
                Int32.TryParse(docStatID.ToString(), out docStatusID);


            Int32 orginID;
            Int32.TryParse(ddlOriginSender.SelectedValue, out orginID);

            Int32 cmpID;
            Int32.TryParse(ddlCompany.SelectedValue, out cmpID);

            string strSubject = string.Empty;
            if (txtSubject.Text != "")
                strSubject = "%" + txtSubject.Text + "%";

            string strDescription = string.Empty;
            if (txtDescription.Text != "")
                strDescription = "%" + txtDescription.Text + "%";

            Int32 docIssuedByID;
            Int32.TryParse(ddlIssuedBy.SelectedValue, out docIssuedByID);

            //string strDBSMajorSubject = string.Empty;
            //if (ddlDBSMajorSubject.Text != "")
            //    strDBSMajorSubject = "%" + ddlDBSMajorSubject.Text + "%";

            //Int32 docDetailSub;
            //Int32.TryParse(ddlDBSDetailedSubject.SelectedValue, out docDetailSub);

            //string strprjTitle = string.Empty;
            //if (txtProjectTitle.Text != "")
            //    strprjTitle = "%" + txtProjectTitle.Text + "%";

            //string strCommitmentNo = string.Empty;
            //if (txtCommitmentNo.Text != "")
            //    strCommitmentNo = "%" + txtCommitmentNo.Text + "%";

            //string strProjectID = string.Empty;
            //if (txtProjectID.Text != "")
            //    strProjectID = "%" + txtProjectID.Text + "%";

            //string strTenderNo = string.Empty;
            //if (txtTenderNo.Text != "")
            //    strTenderNo = "%" + txtTenderNo.Text + "%"; 

            // docContactID = Convert.ToInt32(Session["UserID"]);


            ds = new JobOrderData().GetDocumentDetailsForAdmin(docContactID, docID, docTypeID, docStatusID, orginID, cmpID, strSubject, strDescription, docIssuedByID);

           // SearchDocAdmin
            // ds = new JobOrderData().GetDocumentDetails(docContactID, docID, docTypeID, docStatusID, orginID, cmpID, strDBSMajorSubject, docDetailSub, strprjTitle, strCommitmentNo, strProjectID, strTenderNo, strSubject, strDescription, docIssuedByID, strDescription);

            //GetJobOrderDetails(docID,docTypeID,docStatusID,strdocDistribution,orginID,cmpID,deptID,strDBSMajorSubject,

            DataView dvCommitted = new DataView(ds.Tables[0]);
            // dvCommitted.RowFilter = "CategoryID in(3,4,5,6,7)";

            Session["SearchDoc"] = ds.Tables[0];

            lblDocCnt.Text = " Record Count =  " + ds.Tables[0].Rows.Count.ToString();

            gvMyDocument0.DataSource = dvCommitted;
            gvMyDocument0.DataBind();

        }
        catch (Exception ex)
        {

        }

        return ds.Tables[0];
    }
    private DataTable FillDataForProjectSectionWise(int sectionID)
    {
        DataSet ds = new DataSet();
        try
        {  
            Int32 docContactID;
            Int32.TryParse("0", out docContactID);

            Int32 docID;
            Int32.TryParse(ddlDocRefNo.SelectedValue, out docID);

            Int32 docTypeID;
            Int32.TryParse(ddlTypeOfDoc.SelectedValue, out docTypeID);

            Int32 docStatusID;
            Int32.TryParse(ddlStatus.SelectedValue, out docStatusID);


            Int32 orginID;
            Int32.TryParse(ddlOriginSender.SelectedValue, out orginID);

            Int32 cmpID;
            Int32.TryParse(ddlCompany.SelectedValue, out cmpID);

            string strSubject = string.Empty;
            if (txtSubject.Text != "")
                strSubject = "%" + txtSubject.Text + "%";

            string strDescription = string.Empty;
            if (txtDescription.Text != "")
                strDescription = "%" + txtDescription.Text + "%";

            Int32 docIssuedByID;
            Int32.TryParse(ddlIssuedBy.SelectedValue, out docIssuedByID);

            Int32 docMjrID;
            Int32.TryParse(ddlDBSMajorSubject.SelectedValue, out docMjrID);

            Int32 docMnrID;
            Int32.TryParse(ddlDBSDetailedSubject.SelectedValue, out docMnrID);

            string strprjTitle = string.Empty;
            if (txtProjectTitle.Text != "")
                strprjTitle = "%" + txtProjectTitle.Text + "%";

            string strCommitmentNo = string.Empty;
            if (txtCommitmentNo.Text != "")
                strCommitmentNo = "%" + txtCommitmentNo.Text + "%";

            string strProjectID = string.Empty;
            if (txtProjectID.Text != "")
                strProjectID = "%" + txtProjectID.Text + "%";

            string strTenderNo = string.Empty;
            if (txtTenderNo.Text != "")
                strTenderNo = "%" + txtTenderNo.Text + "%";

            // docContactID = Convert.ToInt32(Session["UserID"]);

            Int32 docSectionID;
            Int32.TryParse(sectionID.ToString(), out docSectionID);


            ds = new JobOrderData().GetDocumentDetailsForProjectForSectionWise(docContactID, docID, docTypeID, docStatusID, orginID, cmpID, strSubject, strDescription, docIssuedByID, docMjrID, docMnrID, strprjTitle, strCommitmentNo, strProjectID, strTenderNo, sectionID);


            // ds = new JobOrderData().GetDocumentDetails(docContactID, docID, docTypeID, docStatusID, orginID, cmpID, strDBSMajorSubject, docDetailSub, strprjTitle, strCommitmentNo, strProjectID, strTenderNo, strSubject, strDescription, docIssuedByID, strDescription);

            //GetJobOrderDetails(docID,docTypeID,docStatusID,strdocDistribution,orginID,cmpID,deptID,strDBSMajorSubject,

            DataTable dt = new DataTable();
            dt = ds.Tables[0];

            //foreach(string col in dt.Columns)
            //{
            //   dt.Columns.Remove("MjrID");
            //}

            //for (int i = 0; i < dt.Columns.Count; i++)
            //{
            //    if (i>9)
            //      dt.Columns.Remove(dt.Columns[i]);
            //}

            for (int i = 0; i < dt.Columns.Count; i++)
            {
                if (dt.Columns[i].ToString().Equals("contractNo"))
                    dt.Columns.Remove(dt.Columns["contractNo"]);

                if (dt.Columns[i].ToString().Equals("projectID"))
                    dt.Columns.Remove(dt.Columns["projectID"]);

                if (dt.Columns[i].ToString().Equals("tenderNo"))
                    dt.Columns.Remove(dt.Columns["tenderNo"]);

                if (dt.Columns[i].ToString().Equals("MjrID"))
                    dt.Columns.Remove(dt.Columns["MjrID"]);

                if (dt.Columns[i].ToString().Equals("MnrID"))
                    dt.Columns.Remove(dt.Columns["MnrID"]);

                //if (dt.Columns[i].ToString().Equals("documentID"))
                //    dt.Columns.Remove(dt.Columns["documentID"]);
                //if (dt.Columns[i].ToString().Equals("superseded"))
                //    dt.Columns.Remove(dt.Columns["superseded"]);
                //if (dt.Columns[i].ToString().Equals("docCreatedByID"))
                //    dt.Columns.Remove(dt.Columns["docCreatedByID"]);
                //if (dt.Columns[i].ToString().Equals("originContactID"))
                //    dt.Columns.Remove(dt.Columns["originContactID"]);
                if (dt.Columns[i].ToString().Equals("contactID"))
                    dt.Columns.Remove(dt.Columns["contactID"]);
            }

            String[] szColumns = new String[dt.Columns.Count];
            for (int index = 0; index < dt.Columns.Count; index++)
                szColumns[index] = dt.Columns[index].ColumnName;

            // Get the distinct records
            dt = dt.DefaultView.ToTable(true, szColumns);

            // dt.AsEnumerable().Distinct(System.Data.DataRowComparer.Default).ToList();

            DataView dvCommitted = new DataView(dt);
            // dvCommitted.RowFilter = "CategoryID in(3,4,5,6,7)";

            lblDocCnt.Text = " Record Count =  " + ds.Tables[0].Rows.Count.ToString();

            gvMyDocument0.DataSource = dvCommitted;
            gvMyDocument0.DataBind();

        }
        catch (Exception ex)
        {

        }

        return ds.Tables[0];
    }

    //==========================================================================================================================================================

    private void FillDataSectionWise(int docStatID, int sectionID)
    {
        try
        {
            DataSet ds = new DataSet();

            Int32 docContactID;
            Int32.TryParse("0", out docContactID);

            Int32 docID;
            Int32.TryParse(ddlDocRefNo.SelectedValue, out docID);

            Int32 docTypeID;
            Int32.TryParse(ddlTypeOfDoc.SelectedValue, out docTypeID);

            Int32 docStatusID;
            if (docStatID==0)
                Int32.TryParse(ddlStatus.SelectedValue, out docStatusID);
            else
                Int32.TryParse(docStatID.ToString(), out docStatusID);


            Int32 orginID;
            Int32.TryParse(ddlOriginSender.SelectedValue, out orginID);

            Int32 cmpID;
            Int32.TryParse(ddlCompany.SelectedValue, out cmpID);

            string strSubject = string.Empty;
            if (txtSubject.Text != "")
                strSubject = "%" + txtSubject.Text + "%";

            string strDescription = string.Empty;
            if (txtDescription.Text != "")
                strDescription = "%" + txtDescription.Text + "%";

            Int32 docIssuedByID;
            Int32.TryParse(ddlIssuedBy.SelectedValue, out docIssuedByID);

            Int32 docSectionID;
            Int32.TryParse(sectionID.ToString(), out docSectionID);


            ds = new JobOrderData().GetDocumentDetailsForSection(docContactID, docID, docTypeID, docStatusID, orginID, cmpID, strSubject, strDescription, docIssuedByID, docSectionID);

            // SearchDocAdmin
            // ds = new JobOrderData().GetDocumentDetails(docContactID, docID, docTypeID, docStatusID, orginID, cmpID, strDBSMajorSubject, docDetailSub, strprjTitle, strCommitmentNo, strProjectID, strTenderNo, strSubject, strDescription, docIssuedByID, strDescription);

            //GetJobOrderDetails(docID,docTypeID,docStatusID,strdocDistribution,orginID,cmpID,deptID,strDBSMajorSubject,

            DataView dvCommitted = new DataView(ds.Tables[0]);
            // dvCommitted.RowFilter = "CategoryID in(3,4,5,6,7)";

            Session["SearchDoc"] = ds.Tables[0];

            lblDocCnt.Text = " Record Count =  " + ds.Tables[0].Rows.Count.ToString();

            gvMyDocument0.DataSource = dvCommitted;
            gvMyDocument0.DataBind();

        }
        catch (Exception ex)
        {

        }
    }
    protected void ddlDBSMajorSubject_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlDBSMajorSubject.SelectedIndex != 0)
        {
            string strMnrValues = " SELECT dbsDescription, dbsID FROM DBSValues WHERE  (dbsParentID = " + ddlDBSMajorSubject.SelectedValue + ") AND (dbsID <> dbsParentID) ORDER BY dbsDescription";

            PopulateDropDownBox(ddlDBSDetailedSubject, strMnrValues, "dbsID", "dbsDescription");
        }
    }
    protected void gvMyDocument0_PageIndexChanged(object sender, EventArgs e)
    {

    }
    protected void gvMyDocument0_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        gvMyDocument0.PageIndex = e.NewPageIndex; 
        gvMyDocument0.DataSource = Session["SearchDoc"];
        gvMyDocument0.DataBind();
       // FillTab2(0);
    }
    protected void gvMyDocument0_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
           // Control ctrlImportance = e.Row.FindControl("divDocImportance");
            Control ctrlSuperseded = e.Row.FindControl("divDocSuperseded");
            HtmlGenericControl htmlCtrlSuperseded = ctrlSuperseded as HtmlGenericControl;
            //HtmlGenericControl htmlCtrlImportance = ctrlImportance as HtmlGenericControl;

            Label lblImportance = e.Row.FindControl("divDocImportance") as Label; 
            Control ctrlReceiveCreateUser = e.Row.FindControl("divReceiveCreateUserID");
            Control ctrlReceiveOriginContactID = e.Row.FindControl("divReceiveOriginContactID");
            HtmlGenericControl htmlCtrlctrlReceiveOriginContactID = ctrlReceiveOriginContactID as HtmlGenericControl;
            HtmlGenericControl htmlCtrlReceiveCreateUser = ctrlReceiveCreateUser as HtmlGenericControl;

            Control ctrlDocRead = e.Row.FindControl("divDateRead");
            HtmlGenericControl htmlCtrlDateRead = ctrlDocRead as HtmlGenericControl;

            Label lblReadDoc = e.Row.FindControl("lblDateRead") as Label;

            LinkButton lnkView = (LinkButton)e.Row.FindControl("lnkBtnDocRefNo");

            if (lblReadDoc.Text.Equals(""))  //htmlCtrlDateRead.InnerText.Equals("")
            {
                e.Row.Cells[1].ForeColor = System.Drawing.Color.Blue;
                e.Row.Cells[1].Font.Bold = true;
                e.Row.Cells[2].ForeColor = System.Drawing.Color.Blue;
                e.Row.Cells[2].Font.Bold = true;
                e.Row.Cells[3].ForeColor = System.Drawing.Color.Blue;
                e.Row.Cells[3].Font.Bold = true;
                e.Row.Cells[4].ForeColor = System.Drawing.Color.Blue;
                e.Row.Cells[4].Font.Bold = true;
                e.Row.Cells[5].ForeColor = System.Drawing.Color.Blue;
                e.Row.Cells[5].Font.Bold = true;
                e.Row.Cells[6].ForeColor = System.Drawing.Color.Blue;
                e.Row.Cells[6].Font.Bold = true;

                e.Row.Cells[7].ForeColor = System.Drawing.Color.Blue;
                e.Row.Cells[7].Font.Bold = true;
            }
            if (htmlCtrlSuperseded.InnerText.Equals("True"))
            {
                e.Row.Cells[1].BackColor = System.Drawing.Color.WhiteSmoke;   // 
                e.Row.Cells[1].ForeColor = System.Drawing.Color.Gray;

                e.Row.Cells[2].BackColor = System.Drawing.Color.WhiteSmoke;
                e.Row.Cells[2].ForeColor = System.Drawing.Color.Gray;

                e.Row.Cells[3].BackColor = System.Drawing.Color.WhiteSmoke;
                e.Row.Cells[3].ForeColor = System.Drawing.Color.Gray;

                e.Row.Cells[4].BackColor = System.Drawing.Color.WhiteSmoke;
                e.Row.Cells[4].ForeColor = System.Drawing.Color.Gray;

                e.Row.Cells[5].BackColor = System.Drawing.Color.WhiteSmoke;
                e.Row.Cells[5].ForeColor = System.Drawing.Color.Gray;

                e.Row.Cells[6].BackColor = System.Drawing.Color.WhiteSmoke;
                e.Row.Cells[6].ForeColor = System.Drawing.Color.Gray;

                e.Row.Cells[7].BackColor = System.Drawing.Color.WhiteSmoke;
                e.Row.Cells[7].ForeColor = System.Drawing.Color.Gray;

                if (htmlCtrlReceiveCreateUser.InnerText.Equals(Session["UserID"].ToString()) || htmlCtrlctrlReceiveOriginContactID.InnerText.Equals(Session["UserID"].ToString()) || Session["UserProfileID"].ToString().Equals("1"))
                {

                }
                else
                {
                    lnkView.Enabled = false;
                    lnkView.Font.Underline = false;

                    e.Row.Cells[0].BackColor = System.Drawing.Color.WhiteSmoke;   // DocRef
                    e.Row.Cells[0].ForeColor = System.Drawing.Color.Black;
                }
            }
            if (lblImportance.Text.Equals("True"))
            {
                e.Row.Cells[4].ForeColor = System.Drawing.Color.Red;
                lblImportance.Text = "!";
            }
            else
            {
                lblImportance.Text = "";
            }      
        }

    }
    protected void ddlTypeOfDoc_SelectedIndexChanged(object sender, EventArgs e)
    {

    }  

    protected void TextBox1_TextChanged1(object sender, EventArgs e)
    {
        SearchDocumetReference();
    }
}