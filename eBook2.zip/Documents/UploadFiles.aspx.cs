﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Data.SqlClient;
using System.Data;
using System.IO;
using System.Web.UI.HtmlControls;
using System.Configuration;

public partial class Documents_UploadFiles : System.Web.UI.Page
{
    private string connValue = System.Configuration.ConfigurationManager.ConnectionStrings["EBSDEBookConn"].ConnectionString;
    int fileDocID = 0;
    IList<string> userRightsColl = null;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["UserName"] == null)
        {
            Response.Redirect("~/LoginPage.aspx", false);
            return;
        }

        userRightsColl = (IList<string>)Session["UserRightsColl"];
        fileDocID = Convert.ToInt32(Session["File_docID"]);
       
        if (!IsPostBack)
        {           
            BindGridviewData();
        }
    }
    protected void btnUpload_Click(object sender, EventArgs e)
    {
        string prefixfileName = string.Empty;
        if (!getDistributionRights(fileDocID))
        {
            lblTitle.Text = "You are not allowed to Upload files for this document.";
            return;
        }

        string filename = Path.GetFileName(fileUpload1.PostedFile.FileName);
        string filePath = string.Empty;
        
        if (fileUpload1.HasFile)
        {
            try
            {
                prefixfileName = fileDocID + " _ " + fileUpload1.FileName;
                string folderName = string.Empty;
                if (Session["SectionID"].ToString().Equals("3"))
                {
                    folderName = ConfigurationManager.AppSettings["DCUfolderName"].ToString();
                    filePath = Path.Combine(folderName, prefixfileName);

                   // filePath = Path.Combine(@"C:\eBookDCLogFiles", prefixfileName);
                }
                else if (Session["SectionID"].ToString().Equals("2"))
                {
                    folderName = ConfigurationManager.AppSettings["PayfolderName"].ToString();
                    filePath = Path.Combine(folderName, prefixfileName);

                   // filePath = Path.Combine(@"C:\eBookPaymentFiles", prefixfileName);
                }
                else
                {
                    folderName = ConfigurationManager.AppSettings["CCfolderName"].ToString();
                    filePath = Path.Combine(folderName, prefixfileName);

                    //filePath = Path.Combine(@"C:\eBookFiles", prefixfileName);
                }

                fileUpload1.SaveAs(filePath);
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);

                string script = "<script type=\"text/javascript\"> displayPopup('" + ex.Message + "'); </script>";
                ClientScript.RegisterClientScriptBlock(this.GetType(), "myscript", script);
                return;  
            }
        }
        else
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Please select file for upload.')</script>", false);
            return;
        }
       
        try
        {
            using (SqlConnection con = new SqlConnection(connValue))
            {
                con.Open();
                using (SqlCommand cmd = new SqlCommand("Insert into FilesTable(fileName,docFileName,filePath,docID,fileType,sectionID,uploadByID,createUser,createDate) values(@Name,@docFileName,@Path,@docID,@fileType,@sectionID,@uploadByID,@createUser,@createDate)", con))
                {
                    cmd.Parameters.AddWithValue("@Name", filename);
                    cmd.Parameters.AddWithValue("@docFileName", prefixfileName);
                    cmd.Parameters.AddWithValue("@Path", filePath);
                    cmd.Parameters.AddWithValue("@docID", fileDocID);
                    cmd.Parameters.AddWithValue("@fileType", Session["fileType"].ToString());
                    cmd.Parameters.AddWithValue("@sectionID", Session["SectionID"]);
                    cmd.Parameters.AddWithValue("@uploadByID", Session["UserID"]);
                    cmd.Parameters.AddWithValue("@createUser", Session["Username"].ToString());  
                    cmd.Parameters.AddWithValue("@createDate", System.DateTime.Now);
                    cmd.ExecuteNonQuery();
                }
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {

        }
        BindGridviewData();
    }

    DataSet ds = new DataSet();
    private void BindGridviewData()
    {
        string sqlfileType = string.Empty;

        if (Session["fileType"].Equals("F"))
            sqlfileType = "select  fileID, FileName,docFileName, FilePath, docID,createUser,REPLACE(CONVERT(NVARCHAR, createDate, 106), ' ', '-') AS createDate from FilesTable where isFileActive = 1 and fileType ='F' and docID = " + fileDocID;
        else
            sqlfileType = "select  fileID, FileName,docFileName, FilePath, docID,createUser,REPLACE(CONVERT(NVARCHAR, createDate, 106), ' ', '-') AS createDate from FilesTable where isFileActive = 1 and fileType ='A' and docID = " + fileDocID;


        using (SqlConnection con = new SqlConnection(connValue))
        {
            //  con.Open();
            using (SqlCommand cmd = new SqlCommand(sqlfileType, con))
            {
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(ds);
            }

            // con.Close();
        }
        
        gvFileUpload.DataSource = ds;
        gvFileUpload.DataBind();
    }
    private Boolean checkUserExist(int fileID, int createdBy, int currentUserID)
    {
        using (SqlConnection con = new SqlConnection(connValue))
        {
            con.Open();
            using (SqlCommand sqlCom = new SqlCommand())
            {               
                sqlCom.CommandType = CommandType.Text;
                sqlCom.Connection = con;
                sqlCom.CommandText = "Select uploadByID From FilesTable where fileID = " + fileID;

                using (SqlDataReader sqlReader = sqlCom.ExecuteReader())
                {
                    while (sqlReader.Read())
                    {
                        if ((sqlReader["uploadByID"].Equals(currentUserID)) || (Session["userProfileID"].Equals("1")))
                            return true;
                    }
                }
            }
        }
        return false;
    }
    private Boolean getDistributionRights(int docID)
    {
        int currentUserID = Convert.ToInt32(Session["UserID"]);
        using (SqlConnection con = new SqlConnection(connValue))
        {
            con.Open();
            using (SqlCommand sqlCom = new SqlCommand())
            {               
                sqlCom.CommandType = CommandType.Text;
                sqlCom.Connection = con;
                sqlCom.CommandText = "Select contactID From DocumentDistribution where documentID = " + docID;

                using (SqlDataReader sqlReader = sqlCom.ExecuteReader())
                {
                    while (sqlReader.Read())
                    {
                        if (sqlReader["contactID"].Equals(currentUserID))
                            return true;
                    }
                }
            }
        }
        return false;
    }
    public void DeleteAttributeData(int attrID)
    {        
        try
        {
            using (SqlConnection con = new SqlConnection(connValue))
            {
                con.Open();
                using (SqlCommand cmd = new SqlCommand("Update FilesTable Set isFileActive = 0,updateUser = @updateUser,updateDate = @updateDate where fileID = " + attrID, con))
                {
                    cmd.Parameters.AddWithValue("@updateUser", Session["Username"].ToString());
                    cmd.Parameters.AddWithValue("@updateDate", System.DateTime.Now);
                    cmd.ExecuteNonQuery();
                }
            }
        }
        catch (Exception ex)
        {
          
        }
        finally
        {
            
        }
    }
    protected void btnBack_Click(object sender, EventArgs e)
    {
        if (Session["lblCatID"].ToString().Equals("1"))
               Response.Redirect("~/Documents/DocumentDetailsWindow.aspx?docRecID=" + fileDocID + "&RecSentCatID=1", false);
        else
            Response.Redirect("~/Documents/DocumentDetailsWindow.aspx?docRecID=" + fileDocID + "&RecSentCatID=2", false);
    }
    protected void lnkDownload_Click(object sender, EventArgs e)
    {     
        LinkButton lnkbtn = sender as LinkButton;
        GridViewRow gvrow = lnkbtn.NamingContainer as GridViewRow;
        string filePath = gvFileUpload.DataKeys[gvrow.RowIndex].Value.ToString();
        
        
        filePath = filePath.Replace("C:", "E:");

        Response.AddHeader("Content-Disposition", "attachment;filename=\"" + filePath + "\"");
        Response.TransmitFile(filePath);
        Response.End();        
    }
    protected void lnkDelete_Click(object sender, EventArgs e)
    {
        try
        {
            LinkButton lnkbtn = sender as LinkButton;
            GridViewRow gvrow = lnkbtn.NamingContainer as GridViewRow;

            string fileID = gvFileUpload.DataKeys[gvrow.RowIndex].Values[1].ToString();



            if (!userRightsColl.Contains("26"))
            {
                if (checkUserExist(Convert.ToInt32(fileID), 1, Convert.ToInt32(Session["UserID"])))
                {
                    using (SqlConnection con = new SqlConnection(connValue))
                    {
                        con.Open();
                        using (SqlCommand cmd = new SqlCommand("Update FilesTable Set isFileActive = 0,updateUser = @updateUser,updateDate = @updateDate where fileID = " + fileID, con))
                        {
                            cmd.Parameters.AddWithValue("@updateUser", Session["Username"].ToString());
                            cmd.Parameters.AddWithValue("@updateDate", System.DateTime.Now);
                            cmd.ExecuteNonQuery();
                        }
                    }

                    BindGridviewData();
                }
                else
                {
                    lblTitle.Text = "You don't have rights to delete this file..";
                }
            }
            else
            {
                lblTitle.Text = "Please contact Administrator,You don't have rights to delete this file..'";
            }
        }
        catch (Exception ex)
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Error occurred while processing the request')</script>", false);
        }
    }
    protected void gvFileUpload_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        
    }
    protected void gvFileUpload_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandArgument != "")
        {
            int attributeID = Convert.ToInt32(e.CommandArgument);
            if (checkUserExist(attributeID, 1, Convert.ToInt32(Session["UserID"])))
                DeleteAttributeData(attributeID);
            else
                ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('You don't have rights to delete this file..')</script>", false);
        }
    }
}