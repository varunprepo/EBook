﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.IO;
using System.Data.SqlClient;
using System.Drawing;
using System.Data;
using Datalayer;


using System.Configuration;
using System.Collections;
using Excel = Microsoft.Office.Interop.Excel;
using System.Runtime.InteropServices;   

public partial class UserChart : System.Web.UI.Page
{
    string connValue = System.Configuration.ConfigurationManager.ConnectionStrings["EBSDEBookConn"].ConnectionString;

    DynamicData dynmicCls = new DynamicData();

    int _userID = 1;

   

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {



            if ((Session["UserProfileID"].Equals("20")) || (Session["UserProfileID"].Equals("1")))
                PopulateDropDownBox(ddlStaffName, "SELECT ContactID, firstName FROM  Contact Where sectionID in(1,2,3,6,9,10,11,12) ORDER BY firstName ", "ContactID", "firstName");   

            //if (ddlStaffName.SelectedIndex == -1)
            //    _userID = Convert.ToInt32(Session["UserID"]);
            //else
            //    _userID = Convert.ToInt32(ddlStaffName.SelectedValue);

            _userID = Convert.ToInt32(Session["UserID"]);

            IList<string> tblColle = new List<string>();
            getYearAndmonthWiseJobCount();

            workLoadRatioChart(_userID);

            DynamicTable(_userID);           

            gridJobEOT.DataSource = chartEOT(_userID);
            gridJobEOT.DataBind();

            gridJobOverdue.DataSource = OverdueJobs(Convert.ToInt32(Session["UserID"]));
            gridJobOverdue.DataBind();

            gridJobOngoing.DataSource = OngoingJobs(Convert.ToInt32(Session["UserID"]));
            gridJobOngoing.DataBind();

            DynamicTableForMonthWiseProcess(_userID);    

            
   
            lblName.Text = Session["UserDisplayName"].ToString();
        }
    }
     

    //public static void getExcelFile()
    //{

    //        //Create COM Objects. Create a COM object for everything that is referenced
    //        Excel.Application xlApp = new Excel.Application();
    //        Excel.Workbook xlWorkbook = xlApp.Workbooks.Open(@"C:\Users\E56626\Desktop\Teddy\VS2012\Sandbox\sandbox_test - Copy - Copy.xlsx");
    //        Excel._Worksheet xlWorksheet = xlWorkbook.Sheets[1];      // xlWorkbook.Sheets[1];
    //        Excel.Range xlRange = xlWorksheet.UsedRange;

    //        int rowCount = xlRange.Rows.Count;
    //        int colCount = xlRange.Columns.Count;

    //        //iterate over the rows and columns and print to the console as it appears in the file
    //        //excel is not zero based!!
    //        for (int i = 1; i <= rowCount; i++)
    //        {
    //            for (int j = 1; j <= colCount; j++)
    //            {
    //                //new line
    //                if (j == 1)
    //                    Console.Write("\r\n");

    //                //write the value to the console
    //                if (xlRange.Cells[i, j] != null && xlRange.Cells[i, j].ToString() != null)
    //                    Console.Write(xlRange.Cells[i, j].ToString() + "\t");
    //            }
    //        }

    //        //cleanup
    //        GC.Collect();
    //        GC.WaitForPendingFinalizers();

    //        //rule of thumb for releasing com objects:
    //        //  never use two dots, all COM objects must be referenced and released individually
    //        //  ex: [somthing].[something].[something] is bad

    //        //release com objects to fully kill excel process from running in the background
    //        Marshal.ReleaseComObject(xlRange);
    //        Marshal.ReleaseComObject(xlWorksheet);

    //        //close and release
    //        xlWorkbook.Close();
    //        Marshal.ReleaseComObject(xlWorkbook);

    //        //quit and release
    //        xlApp.Quit();
    //        Marshal.ReleaseComObject(xlApp);
    //}
    
  
    private void DynamicTable(int _userID)
    {
        DataTable dtMerge = new DataTable();

        DataTable table1 = new DataTable("Items");
        DataColumn _userName = new DataColumn("_userName", typeof(System.String));
        DataColumn _Year = new DataColumn("_Year", typeof(System.String));
        DataColumn _Received = new DataColumn("_Received", typeof(System.Int32));
        DataColumn _onTime = new DataColumn("_onTimeCompleted", typeof(System.Int32));
        DataColumn _delay = new DataColumn("_delay", typeof(System.Int32));

        table1.Columns.Add(_userName);
        table1.Columns.Add(_Year);
        table1.Columns.Add(_Received);
        table1.Columns.Add(_onTime);
        table1.Columns.Add(_delay);

        // DataRow row = table1.NewRow();            

        for (int i = 1; i <= 3; i++)
        {
            DataTable dtMain = userKPI(i, _userID);
            int _rCnt = 0;
            for (int k = 0; k <= dtMain.Rows.Count - 1; k++)
            {
                if (i == 1)
                {
                    DataRow row = table1.NewRow();

                    row["_userName"] = dtMain.Rows[k][0];

                    row["_Year"] = dtMain.Rows[k][1];

                    row["_Received"] = dtMain.Rows[k][2];

                    row["_onTimeCompleted"] = 0;

                    row["_delay"] = 0;

                    table1.Rows.Add(row);
                }
                else if (i == 2)
                {
                    table1.Rows[_rCnt][3] = dtMain.Rows[k][2];
                }
                else if (i == 3)
                {
                    table1.Rows[_rCnt][4] = dtMain.Rows[k][2];
                }

                _rCnt = _rCnt + 1;
            }

            table1.AcceptChanges();

            // dtMerge = table1;               
        }

        gridJobCnt.DataSource = table1;
        gridJobCnt.DataBind();
    }
    private void workLoadRatioChart(int _userID)
    {
        DataSet dsDoc = new DataSet();

        string sqlQuery = null;

        if (_userID == 1)
        {
            sqlQuery = "SELECT  COUNT(jobID) AS jCnt, { fn MONTHNAME(createDate) } AS Month FROM Job WHERE (sectionID = 22) AND (YEAR(createDate) = 2019) GROUP BY { fn MONTHNAME(createDate) } ";

        }
        else
        {
            if (Session["SectionID"].ToString().Equals("1"))
               sqlQuery = "SELECT        COUNT(*) AS jCnt, YEAR(Job.createDate) AS Year, MONTH(JobOwner.createDate) AS MonthID, { fn MONTHNAME(JobOwner.createDate) } AS Month " +
                   "FROM JobOwner INNER JOIN   Job ON JobOwner.jobID = Job.jobID WHERE (JobOwner.contactID = " + _userID + ") AND (YEAR(JobOwner.createDate) IN (2018, 2019)) " +
                  " GROUP BY JobOwner.contactID, YEAR(Job.createDate), MONTH(JobOwner.createDate), { fn MONTHNAME(JobOwner.createDate) } ORDER BY year, MonthID";
            else if (Session["SectionID"].ToString().Equals("2"))
               sqlQuery = "SELECT   COUNT(*) AS jCnt, YEAR(Payment.createDate) AS Year, MONTH(JobOwner.createDate) AS MonthID, { fn MONTHNAME(JobOwner.createDate) } AS Month " +
                  "FROM JobOwner INNER JOIN   Payment ON JobOwner.PayID = Payment.payID WHERE (JobOwner.contactID = " + _userID + ") AND (YEAR(JobOwner.createDate) IN (2018, 2019)) " +
                 " GROUP BY JobOwner.contactID, YEAR(Payment.createDate), MONTH(JobOwner.createDate), { fn MONTHNAME(JobOwner.createDate) } ORDER BY year, MonthID";
            else if (Session["SectionID"].ToString().Equals("9"))
                sqlQuery = "SELECT        COUNT(*) AS jCnt, YEAR(EBDServiceRequests.createDate) AS Year, MONTH(JobOwner.createDate) AS MonthID, { fn MONTHNAME(JobOwner.createDate) } AS Month " +
                   "FROM JobOwner INNER JOIN   Job ON JobOwner.SRID = EBDServiceRequests.serviceReqID WHERE (JobOwner.contactID = " + _userID + ") AND (YEAR(JobOwner.createDate) IN (2018, 2019)) " +
                  " GROUP BY JobOwner.contactID, YEAR(Job.createDate), MONTH(JobOwner.createDate), { fn MONTHNAME(JobOwner.createDate) } ORDER BY year, MonthID";
            else               
               sqlQuery = "SELECT        COUNT(*) AS jCnt, YEAR(Job.createDate) AS Year, MONTH(JobOwner.createDate) AS MonthID, { fn MONTHNAME(JobOwner.createDate) } AS Month " +
                  "FROM JobOwner INNER JOIN   Job ON JobOwner.jobID = Job.jobID WHERE (JobOwner.contactID = " + _userID + ") AND (YEAR(JobOwner.createDate) IN (2018, 2019)) " +
                 " GROUP BY JobOwner.contactID, YEAR(Job.createDate), MONTH(JobOwner.createDate), { fn MONTHNAME(JobOwner.createDate) } ORDER BY year, MonthID";

        }

        SqlDataAdapter daDoc = new SqlDataAdapter(sqlQuery, connValue);
        daDoc.Fill(dsDoc);
        if (dsDoc.Tables[0].Rows.Count != 0)
        {
            workLoadChart.DataSource = dsDoc.Tables[0].DefaultView;
            workLoadChart.Series["Series1"].XValueMember = "Month";
            workLoadChart.Series["Series1"].YValueMembers = "jCnt";

            dsDoc.Tables.Clear();

            workLoadChart.ChartAreas[0].AxisX.MajorGrid.Enabled = false;
            workLoadChart.ChartAreas[0].AxisX.MinorGrid.Enabled = false;
            workLoadChart.ChartAreas[0].AxisY.MajorGrid.Enabled = false;
            workLoadChart.ChartAreas[0].AxisY.MinorGrid.Enabled = false;

            workLoadChart.ChartAreas[0].AxisX.LabelStyle.Angle = 30;
            workLoadChart.ChartAreas[0].AxisX.LabelStyle.ForeColor = Color.Maroon;

            workLoadChart.ChartAreas[0].AxisX.Interval = 1;
        }
    }
    private void getYearAndmonthWiseJobCount()
    {
        string _section = string.Empty;        
            _section = "1";

        DynamicData dynmicCls = new DynamicData();

        GridView3.DataSource = getYearAndmonthWiseJobCount(_section, _userID);
        GridView3.DataBind();

    
    }
    public DataTable getYearAndmonthWiseJobCount(string _section, int _userID)
    {
        string sqlQuery = string.Empty;

        sqlQuery = " SELECT * FROM (SELECT YEAR(JobOwner.staffIssueDate) [Year], DATENAME(MONTH, JobOwner.staffIssueDate) [Month], COUNT(1) [Sales Count] FROM JobOwner where  JobOwner.contactID = " + _userID + "  " +
       " GROUP BY YEAR(JobOwner.staffIssueDate), DATENAME(MONTH, JobOwner.staffIssueDate)) AS MontlySalesData PIVOT( SUM([Sales Count]) FOR Month IN ([January],[February],[March],[April],[May], " +
      " [June],[July],[August],[September],[October],[November], [December])) AS MNamePivot order by year desc";

        SqlConnection objCon = new SqlConnection(connValue);
        SqlCommand objCmd = new SqlCommand(sqlQuery, objCon);

        DataSet dsTndrStaff = new DataSet();
        objCmd.CommandText = sqlQuery;
        objCmd.Connection = objCon;

        SqlDataAdapter daTndrStaff = new SqlDataAdapter(objCmd);
        daTndrStaff.Fill(dsTndrStaff);

        return dsTndrStaff.Tables[0];
    }

   
    protected void btnPivotYearly_Click(object sender, EventArgs e)
    {
        getYearAndmonthWiseJobCount();
    }
    
   

    public static DataTable GetInversedDataTable(DataTable table, string columnX, string columnY, string columnZ, string nullValue, bool sumValues)
    {
        //Create a DataTable to Return
        DataTable returnTable = new DataTable();

        if (columnX == "")
            columnX = table.Columns[0].ColumnName;

        //Add a Column at the beginning of the table
        returnTable.Columns.Add(columnY);


        //Read all DISTINCT values from columnX Column in the provided DataTale
        List<string> columnXValues = new List<string>();

        foreach (DataRow dr in table.Rows)
        {

            string columnXTemp = dr[columnX].ToString();
            if (!columnXValues.Contains(columnXTemp))
            {
                //Read each row value, if it's different from others provided, add to 
                //the list of values and creates a new Column with its value.
                columnXValues.Add(columnXTemp);
                returnTable.Columns.Add(columnXTemp);
            }
        }

        //Verify if Y and Z Axis columns re provided
        if (columnY != "" && columnZ != "")
        {
            //Read DISTINCT Values for Y Axis Column
            List<string> columnYValues = new List<string>();

            foreach (DataRow dr in table.Rows)
            {
                if (!columnYValues.Contains(dr[columnY].ToString()))
                    columnYValues.Add(dr[columnY].ToString());
            }

            //Loop all Column Y Distinct Value
            foreach (string columnYValue in columnYValues)
            {
                //Creates a new Row
                DataRow drReturn = returnTable.NewRow();
                drReturn[0] = columnYValue;
                //foreach column Y value, The rows are selected distincted
                DataRow[] rows = table.Select(columnY + "='" + columnYValue + "'");

                //Read each row to fill the DataTable
                foreach (DataRow dr in rows)
                {
                    string rowColumnTitle = dr[columnX].ToString();

                    //Read each column to fill the DataTable
                    foreach (DataColumn dc in returnTable.Columns)
                    {
                        if (dc.ColumnName == rowColumnTitle)
                        {
                            //If Sum of Values is True it try to perform a Sum
                            //If sum is not possible due to value types, the value 
                            // displayed is the last one read
                            if (sumValues)
                            {
                                try
                                {
                                    drReturn[rowColumnTitle] =
                                         Convert.ToDecimal(drReturn[rowColumnTitle]) +
                                         Convert.ToDecimal(dr[columnZ]);
                                }
                                catch
                                {
                                    drReturn[rowColumnTitle] = dr[columnZ];
                                }
                            }
                            else
                            {
                                drReturn[rowColumnTitle] = dr[columnZ];
                            }
                        }
                    }
                }
                returnTable.Rows.Add(drReturn);
            }
        }
        else
        {
            throw new Exception("The columns to perform inversion are not provided");
        }

        //if a nullValue is provided, fill the datable with it
        if (nullValue != "")
        {
            foreach (DataRow dr in returnTable.Rows)
            {
                foreach (DataColumn dc in returnTable.Columns)
                {
                    if (dr[dc.ColumnName].ToString() == "")
                        dr[dc.ColumnName] = nullValue;
                }
            }
        }

        return returnTable;
    }
    private void getQuaterlyData()
    {
        string _section = string.Empty;
       
            _section = "1";

        DynamicData dynmicCls = new DynamicData();

        GridView3.DataSource = dynmicCls.getQuaterlyData("", "", _section);
        GridView3.DataBind();

    }
 

    protected void ddlStaffName_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlStaffName.SelectedIndex != 0)
        {
            GridView3.DataSource = getYearAndmonthWiseJobCount("1", Convert.ToInt32(ddlStaffName.SelectedValue));

            workLoadRatioChart(Convert.ToInt32(ddlStaffName.SelectedValue));

            gridJobEOT.DataSource = chartEOT(Convert.ToInt32(ddlStaffName.SelectedValue));
            gridJobEOT.DataBind();

            DynamicTable(Convert.ToInt32(ddlStaffName.SelectedValue));

            gridJobOverdue.DataSource = OverdueJobs(Convert.ToInt32(ddlStaffName.SelectedValue));
            gridJobOverdue.DataBind();

            gridJobOngoing.DataSource = OngoingJobs(Convert.ToInt32(ddlStaffName.SelectedValue));
            gridJobOngoing.DataBind();

            DynamicTableForMonthWiseProcess(Convert.ToInt32(ddlStaffName.SelectedValue));
        }
        else
        {
            GridView3.DataSource = getYearAndmonthWiseJobCount("1", _userID);

            workLoadRatioChart(Convert.ToInt32(Session["UserID"]));

            gridJobEOT.DataSource = chartEOT(Convert.ToInt32(Session["UserID"]));
            gridJobEOT.DataBind();

            DynamicTable(Convert.ToInt32(Session["UserID"]));

            gridJobOverdue.DataSource = OverdueJobs(Convert.ToInt32(Session["UserID"]));
            gridJobOverdue.DataBind();

            gridJobOngoing.DataSource = OngoingJobs(Convert.ToInt32(Session["UserID"]));
            gridJobOngoing.DataBind();

            DynamicTableForMonthWiseProcess(Convert.ToInt32(Session["UserID"]));
        }

        GridView3.DataBind();

        lblName.Text = ddlStaffName.SelectedItem.Text.ToString();
    }
    private void PopulateDropDownBox(DropDownList ddlBox, string sqlQuery, string valueMember, string displayName)
    {
        ddlBox.DataSource = new JobOrderData().FillDropdown(sqlQuery);
        ddlBox.DataTextField = displayName;
        ddlBox.DataValueField = valueMember;
        ddlBox.SelectedIndex = -1;
        ddlBox.DataBind();
        ddlBox.Items.Insert(0, new ListItem("--Select--"));
    }
    private void dynamicClaims(Excel.Range range)
    {
        string str;
        int rCnt;
        int cCnt;
        int rw = 0;
        int cl = 0;

        DataTable table1 = new DataTable("Items");

        DataColumn _userName = new DataColumn("_contractNo", typeof(System.String));
        DataColumn _Year = new DataColumn("_CntrName", typeof(System.String));
        DataColumn _Received = new DataColumn("_CnsultName", typeof(System.String));
        DataColumn _onTime = new DataColumn("_EOT", typeof(System.String));
        DataColumn _delay = new DataColumn("_Amnt", typeof(System.String));

        table1.Columns.Add(_userName);
        table1.Columns.Add(_Year);
        table1.Columns.Add(_Received);
        table1.Columns.Add(_onTime);
        table1.Columns.Add(_delay);

        DataRow row = table1.NewRow();

        // =====================================================================================

        for (rCnt = 1; rCnt <= rw; rCnt++)
        {
            for (cCnt = 1; cCnt <= cl; cCnt++)
            {
                // str = (string)(range.Cells[rCnt, cCnt] as Excel.Range).Value2;

                var val = (range.Cells[rCnt, cCnt] as Excel.Range).Value2;

                if (val != null)
                {
                    if ((rCnt == 8) & (cCnt == 2))      //// Cno
                    {
                        row["_contractNo"] = val;
                    }
                    else if ((rCnt == 8) & (cCnt == 17))      // Cntr Name
                    {
                        row["_CntrName"] = val;
                    }
                    else if ((rCnt == 9) & (cCnt == 17))         // KEO
                    {
                        row["_CnsultName"] = val;
                    }
                    else if ((rCnt == 17) & (cCnt == 1))       /// 2 days
                    {
                        row["_EOT"] = val;
                    }
                    else if ((rCnt == 17) & (cCnt == 2))       // Amount
                    {
                        row["_Amnt"] = val;
                    }
                }
            }
        }

        table1.Rows.Add(row);
        table1.AcceptChanges();
    }
    protected void btnBack_Click(object sender, EventArgs e)
    {

        Excel.Application xlApp ;
            Excel.Workbook xlWorkBook ;
            Excel.Worksheet xlWorkSheet ;
            Excel.Range range ;

            string str;
            int rCnt ;
            int cCnt ;
            int rw = 0;
            int cl = 0;

            xlApp = new Excel.Application();
            xlWorkBook = xlApp.Workbooks.Open(@"d:\Claim.xlsx", 0, true, 5, "", "", true, Microsoft.Office.Interop.Excel.XlPlatform.xlWindows, "\t", false, false, 0, true, 1, 0);
            xlWorkSheet = (Excel.Worksheet)xlWorkBook.Worksheets.get_Item(1);

            range = xlWorkSheet.UsedRange;
            rw = range.Rows.Count;
            cl = range.Columns.Count;

           // dynamicClaims(range);
            

            // ====================================================================================

            DataTable tableClaim = new DataTable("Claims");

            DataColumn _contractNo = new DataColumn("_contractNo", typeof(System.String));

            DataColumn _SINo = new DataColumn("_SiNo", typeof(System.String));
            DataColumn _SIReceivedOn = new DataColumn("_SiRec", typeof(System.String));
            DataColumn _claimNo = new DataColumn("_claimNo", typeof(System.String));

            DataColumn _costDt = new DataColumn("_costDt", typeof(System.String));
            DataColumn _cntrAmnt = new DataColumn("_cntrAmnt", typeof(System.String));
            DataColumn _EotDt = new DataColumn("_EotDt", typeof(System.String));
            DataColumn _EotTime = new DataColumn("_EotTime", typeof(System.String));

            DataColumn _CnsltcostDt = new DataColumn("_CnsltcostDt", typeof(System.String));
            DataColumn _CnsltAmnt = new DataColumn("_CnsltAmnt", typeof(System.String));
            DataColumn _CnsltEotDt = new DataColumn("_CnsltEotDt", typeof(System.String));
            DataColumn _CnsltTime = new DataColumn("_CnsltTime", typeof(System.String));

            DataColumn _PmccostDt = new DataColumn("_PmccostDt", typeof(System.String));
            DataColumn _PmcAmnt = new DataColumn("_PmcAmnt", typeof(System.String));
            DataColumn _PmcEotDt = new DataColumn("_PmcEotDt", typeof(System.String));
            DataColumn _PmcTime = new DataColumn("_PmcTime", typeof(System.String));            

            DataColumn _EBDcostDt = new DataColumn("_EBDcostDt", typeof(System.String));
            DataColumn _EBDAmnt = new DataColumn("_EBDAmnt", typeof(System.String));
            DataColumn _EBDEotDt = new DataColumn("_EBDEotDt", typeof(System.String));
            DataColumn _EBDTime = new DataColumn("_EBDTime", typeof(System.String));
            

            DataColumn _voNo = new DataColumn("_voNo", typeof(System.String));
            DataColumn _voIssued = new DataColumn("_voIssued", typeof(System.String));
            DataColumn _voAmnt = new DataColumn("_voAmnt", typeof(System.String));
            DataColumn _voEot = new DataColumn("_voEot", typeof(System.String));

            DataColumn _paidCntrAmnt = new DataColumn("_paidCntrAmnt", typeof(System.String));

            tableClaim.Columns.Add(_contractNo);

            tableClaim.Columns.Add(_SINo);
            tableClaim.Columns.Add(_SIReceivedOn);
            tableClaim.Columns.Add(_claimNo);

            tableClaim.Columns.Add(_costDt);
            tableClaim.Columns.Add(_cntrAmnt);
            tableClaim.Columns.Add(_EotDt);
            tableClaim.Columns.Add(_EotTime);

            tableClaim.Columns.Add(_CnsltcostDt);
            tableClaim.Columns.Add(_CnsltAmnt);
            tableClaim.Columns.Add(_CnsltEotDt);
            tableClaim.Columns.Add(_CnsltTime);

            tableClaim.Columns.Add(_PmccostDt);
            tableClaim.Columns.Add(_PmcAmnt);
            tableClaim.Columns.Add(_PmcEotDt);
            tableClaim.Columns.Add(_PmcTime);

            tableClaim.Columns.Add(_EBDcostDt);
            tableClaim.Columns.Add(_EBDAmnt);
            tableClaim.Columns.Add(_EBDEotDt);
            tableClaim.Columns.Add(_EBDTime);

            tableClaim.Columns.Add(_voNo);
            tableClaim.Columns.Add(_voIssued);
            tableClaim.Columns.Add(_voAmnt);
            tableClaim.Columns.Add(_voEot);
            tableClaim.Columns.Add(_paidCntrAmnt);

            string _contrctNo = string.Empty;

            for (rCnt = 1; rCnt <= rw; rCnt++)
            {
                if (rCnt > 30)
                {
                    gridCliamData.DataSource = tableClaim;
                    gridCliamData.DataBind();

                    return;
                }
                else if (rCnt == 8)
                {
                    DataRow rowClaim = tableClaim.NewRow();

                    for (cCnt = 1; cCnt <= cl; cCnt++)
                    {
                        var val = (range.Cells[rCnt, cCnt] as Excel.Range).Text;

                        string strVal = val.ToString();

                        if ((rCnt == 8) & (cCnt == 2))      //// Cno
                        {
                            //RowValus(rCnt, cCnt, strVal, rowClaim);                          
                            _contrctNo = strVal;
                        }                        
                    }

                    tableClaim.Rows.Add(rowClaim);
                    tableClaim.AcceptChanges();
                }
                else if (rCnt >= 17)
                {
                    DataRow rowClaim = tableClaim.NewRow();

                    for (cCnt = 1; cCnt <= cl; cCnt++)
                    {
                        // str = (string)(range.Cells[rCnt, cCnt] as Excel.Range).Value2;
                        var val = (range.Cells[rCnt, cCnt] as Excel.Range).Text;

                        string strVal = val.ToString();

                        
                        if (val != null)
                        {
                            RowValus(rCnt, cCnt, strVal, rowClaim, _contrctNo);
                        }
                    }

                    tableClaim.Rows.Add(rowClaim);
                    tableClaim.AcceptChanges();
                }
            }

            tableClaim.Rows[1][1] = _contrctNo;

            gridCliamData.DataSource = tableClaim;
            gridCliamData.DataBind();

            xlWorkBook.Close(true, null, null);
            xlApp.Quit();

            Marshal.ReleaseComObject(xlWorkSheet);
            Marshal.ReleaseComObject(xlWorkBook);
            Marshal.ReleaseComObject(xlApp);

        //Response.Redirect("~/JobOrder/CostControlHomePage.aspx", false);
    }
    private void RowValus(int rCnt, int cCnt, string val, DataRow rowClaim, string _contrctNo)
    {
        if ((rCnt == 8) & (cCnt == 2))      //// Cno
        {
            rowClaim["_contractNo"] = _contrctNo;
        }
        else if ((rCnt >= 17) & (cCnt == 1))      //// SiNo
        {
            rowClaim["_SiNo"] = val;

            rowClaim["_contractNo"] = _contrctNo;
        }
        else if ((rCnt >= 17) & (cCnt == 2))      // SI Rec Dt
        {
            rowClaim["_SiRec"] = val;
        }
        else if ((rCnt >= 17) & (cCnt == 3))         // Claim no
        {
            rowClaim["_claimNo"] = val;
        }
        else if ((rCnt >= 17) & (cCnt == 4))       /// Cntr Rec Dt
        {
            rowClaim["_costDt"] = val;
        }
        else if ((rCnt >= 17) & (cCnt == 5))       // Contractor Amount
        {
            rowClaim["_cntrAmnt"] = val;
        }
        else if ((rCnt >= 17) & (cCnt == 6))       // Cntr Eot Dt
        {
            rowClaim["_EotDt"] = val;
        }
        else if ((rCnt >= 17) & (cCnt == 7))       // Cntr Eot Time
        {
            rowClaim["_EotTime"] = val;
        }

        else if ((rCnt >= 17) & (cCnt == 8))       /// Cntr Rec Dt
        {
            rowClaim["_CnsltcostDt"] = val;
        }
        else if ((rCnt >= 17) & (cCnt == 9))       // Contractor Amount
        {
            rowClaim["_CnsltAmnt"] = val;
        }
        else if ((rCnt >= 17) & (cCnt == 10))       // Cntr Eot Dt
        {
            rowClaim["_CnsltEotDt"] = val;
        }
        else if ((rCnt >= 17) & (cCnt == 11))       // Cntr Eot Time
        {
            rowClaim["_CnsltTime"] = val;
        }


        else if ((rCnt >= 17) & (cCnt == 12))       /// Cntr Rec Dt
        {
            rowClaim["_PmccostDt"] = val;
        }
        else if ((rCnt >= 17) & (cCnt == 13))       // Contractor Amount
        {
            rowClaim["_PmcAmnt"] = val;
        }
        else if ((rCnt >= 17) & (cCnt == 14))       // Cntr Eot Dt
        {
            rowClaim["_PmcEotDt"] = val;
        }
        else if ((rCnt >= 17) & (cCnt == 15))       // Cntr Eot Time
        {
            rowClaim["_PmcTime"] = val;
        }


        else if ((rCnt >= 17) & (cCnt == 16))       /// Cntr Rec Dt
        {
            rowClaim["_EBDcostDt"] = val;
        }
        else if ((rCnt >= 17) & (cCnt == 17))       // Contractor Amount
        {
            rowClaim["_EBDAmnt"] = val;
        }
        else if ((rCnt >= 17) & (cCnt == 18))       // Cntr Eot Dt
        {
            rowClaim["_EBDEotDt"] = val;
        }
        else if ((rCnt >= 17) & (cCnt == 19))       // Cntr Eot Time
        {
            rowClaim["_EBDTime"] = val;
        }

        else if ((rCnt >= 17) & (cCnt == 20))       /// Cntr Rec Dt
        {
            rowClaim["_voNo"] = val;
        }
        else if ((rCnt >= 17) & (cCnt == 21))       // Contractor Amount
        {
            rowClaim["_voIssued"] = val;
        }
        else if ((rCnt >= 17) & (cCnt == 22))       // Cntr Eot Dt
        {
            rowClaim["_voAmnt"] = val;
        }
        else if ((rCnt >= 17) & (cCnt == 23))       // Cntr Eot Time
        {
            rowClaim["_voEot"] = val;
        }
        else if ((rCnt >= 17) & (cCnt == 24))       // Cntr Eot Time
        {
            rowClaim["_paidCntrAmnt"] = val;
        }
        else
        {
            rowClaim["_contractNo"] = _contrctNo;
        }
    }
    private DataTable userKPI(int iCnt,int _userID)
    {        
        string SqlQuery_Received = string.Empty;
        string SqlQuery_OnTime = string.Empty;
        string SqlQuery_Delay = string.Empty;

         SqlConnection objCon = new SqlConnection(connValue);
         SqlCommand objCmd = new SqlCommand();
         if (iCnt == 1)
         {
             SqlQuery_Received = "SELECT Contact.firstName, YEAR(JobOwner.staffIssueDate) AS Year, COUNT(JobOwner.jobOwnerID) AS Received_JobCnt " +
              " FROM JobOwner INNER JOIN Contact ON JobOwner.contactID = Contact.contactID WHERE (JobOwner.contactID = " + _userID  + ")  " +
             " GROUP BY Contact.firstName, JobOwner.contactID, YEAR(JobOwner.staffIssueDate) order by YEAR(JobOwner.staffIssueDate) ";
              objCmd = new SqlCommand(SqlQuery_Received, objCon);
             
         }
         else if (iCnt == 2)
         {
             SqlQuery_OnTime = "SELECT Contact.firstName, YEAR(JobOwner.completionDate) AS Year, COUNT(JobOwner.jobOwnerID) AS Received_JobCnt " +
               " FROM JobOwner INNER JOIN Contact ON JobOwner.contactID = Contact.contactID WHERE (JobOwner.contactID = " + _userID + ") AND convert(date, JobOwner.actionDueDate, 104)  >= convert(date, JobOwner.completionDate, 104) " +
               " GROUP BY Contact.firstName, JobOwner.contactID, YEAR(JobOwner.completionDate) order by YEAR(JobOwner.completionDate)";
              objCmd = new SqlCommand(SqlQuery_OnTime, objCon);
         }
         else
         {
             SqlQuery_Delay = "SELECT Contact.firstName, YEAR(JobOwner.completionDate) AS Year, COUNT(JobOwner.jobOwnerID) AS Received_JobCnt " +
               " FROM JobOwner INNER JOIN Contact ON JobOwner.contactID = Contact.contactID WHERE (JobOwner.contactID = " + _userID + ") AND convert(date, JobOwner.actionDueDate, 104)  < convert(date, JobOwner.completionDate, 104) " +
               " GROUP BY Contact.firstName, JobOwner.contactID, YEAR(JobOwner.completionDate) order by YEAR(JobOwner.completionDate)";
              objCmd = new SqlCommand(SqlQuery_Delay, objCon);
         }

        DataSet dsTndrStaff = new DataSet();  
        SqlDataAdapter daTndrStaff = new SqlDataAdapter(objCmd);
        daTndrStaff.Fill(dsTndrStaff);      

        return dsTndrStaff.Tables[0];
    }

    private DataTable chartEOT(int _userID)
    {
        DataSet dsDoc = new DataSet();
        string sqlQuery = null;

        if (_userID == 1)
        {
            sqlQuery = "SELECT  COUNT(Job.jobID) AS jCnt, Contact.firstName,job.JobNo FROM  Job INNER JOIN   JobOwner ON Job.jobID = JobOwner.jobID INNER JOIN " +
                       "  Contact ON JobOwner.contactID = Contact.contactID LEFT OUTER JOIN   JobVOSI ON Job.jobID = JobVOSI.jobID " +
                " WHERE (YEAR(Job.createDate) = 2019) AND (JobOwner.jobPurposeID NOT IN (1, 8)) AND (Job.sectionID = 1) and (JobOwner.contactID = " + _userID + ") GROUP BY JobOwner.contactID, Contact.firstName,job.JobNo";

        }
        else if (_userID == 1)
        {
            sqlQuery = "SELECT  COUNT(Job.jobID) AS jCnt, Contact.firstName,job.JobNo FROM  Job INNER JOIN   JobOwner ON Job.jobID = JobOwner.jobID INNER JOIN " +
                       "  Contact ON JobOwner.contactID = Contact.contactID LEFT OUTER JOIN   JobVOSI ON Job.jobID = JobVOSI.jobID " +
                " WHERE (YEAR(Job.createDate) = 2019) AND (JobOwner.jobPurposeID NOT IN (1, 8)) AND (Job.sectionID = 1) and (JobOwner.contactID = " + _userID + ") GROUP BY JobOwner.contactID, Contact.firstName,job.JobNo";

            //AND (Job.jobCatID = 1)        

        }
        else
        {
             sqlQuery = "SELECT  COUNT(Job.jobID) AS jCnt, Contact.firstName, EBSDTeamLeaders.teamLeaderName, { fn MONTHNAME(Job.createDate) } AS Month FROM    Job INNER JOIN   JobOwner ON Job.jobID = JobOwner.jobID INNER JOIN " + 
                                " Contact ON JobOwner.contactID = Contact.contactID INNER JOIN   EBSDTeamLeaders ON Contact.teamLeaderID = EBSDTeamLeaders.teamLeaderID LEFT OUTER JOIN " + 
                                " JobVOSI ON Job.jobID = JobVOSI.jobID WHERE        (YEAR(Job.createDate) = 2019) AND (JobOwner.jobPurposeID NOT IN (11, 18)) AND (Job.sectionID = 1) " +
                        " GROUP BY JobOwner.contactID, Contact.firstName, EBSDTeamLeaders.teamLeaderName, EBSDTeamLeaders.contactID, { fn MONTHNAME(Job.createDate) } HAVING (JobOwner.contactID = " + _userID + ")";
       }

        SqlConnection objCon = new SqlConnection(connValue);
        SqlCommand objCmd = new SqlCommand();
        objCmd = new SqlCommand(sqlQuery, objCon);
        DataSet dsTndrStaff = new DataSet();
        SqlDataAdapter daTndrStaff = new SqlDataAdapter(objCmd);
        daTndrStaff.Fill(dsTndrStaff);

        return dsTndrStaff.Tables[0];
    }

    private DataTable OverdueJobs(int _userID)
    {
        string sqlQuery = "SELECT  jobNo, projectTitle, actionDueDate FROM  JobOwner WHERE  (contactID = " + _userID + ") AND (actionDueDate < GETDATE()) AND (jobOwnerStatusID = 3)";
        SqlConnection objCon = new SqlConnection(connValue);
        SqlCommand objCmd = new SqlCommand();
        objCmd = new SqlCommand(sqlQuery, objCon);
        DataSet dsTndrStaff = new DataSet();
        SqlDataAdapter daTndrStaff = new SqlDataAdapter(objCmd);
        daTndrStaff.Fill(dsTndrStaff);

        return dsTndrStaff.Tables[0];
    }

    private DataTable OngoingJobs(int _userID)
    {
        string sqlQuery = "SELECT  jobNo, projectTitle, actionDueDate FROM  JobOwner WHERE  (contactID = " + _userID + ") AND (jobOwnerStatusID = 3)";
        SqlConnection objCon = new SqlConnection(connValue);
        SqlCommand objCmd = new SqlCommand();
        objCmd = new SqlCommand(sqlQuery, objCon);
        DataSet dsTndrStaff = new DataSet();
        SqlDataAdapter daTndrStaff = new SqlDataAdapter(objCmd);
        daTndrStaff.Fill(dsTndrStaff);

        return dsTndrStaff.Tables[0];
    }

    private void DynamicTableForMonthWiseProcess(int _userID)
    {
        DataTable dtMerge = new DataTable();

        DataTable table1 = new DataTable("Items");
        DataColumn _userName = new DataColumn("_userName", typeof(System.String));
        DataColumn _Year = new DataColumn("_Month", typeof(System.String));
        DataColumn _Received = new DataColumn("_Received", typeof(System.Int32));
        DataColumn _onTime = new DataColumn("_onTimeCompleted", typeof(System.Int32));
        DataColumn _delay = new DataColumn("_delay", typeof(System.Int32));

        table1.Columns.Add(_userName);
        table1.Columns.Add(_Year);
        table1.Columns.Add(_Received);
        table1.Columns.Add(_onTime);
        table1.Columns.Add(_delay);

        // DataRow row = table1.NewRow();            

        for (int i = 1; i <= 3; i++)
        {
            DataTable dtMain = userKPI_Monthly(i, _userID);
            int _rCnt = 0; int _monthsCnt = dtMain.Rows.Count;
            for (int k = 0; k <= _monthsCnt; k++) // for (int k = 0; k <= dtMain.Rows.Count - 1; k++)
            {
                if (i == 1)
                {
                    _monthsCnt = dtMain.Rows.Count;

                    DataRow row = table1.NewRow();

                    row["_userName"] = dtMain.Rows[k][0];

                    row["_Month"] = dtMain.Rows[k][1];

                    row["_Received"] = dtMain.Rows[k][2];

                    row["_onTimeCompleted"] = 0;

                    row["_delay"] = 0;

                    table1.Rows.Add(row);
                }
                else if (i == 2)
                {
                    table1.Rows[_rCnt][3] = dtMain.Rows[k][2];
                }
                else if (i == 3)
                {
                    for (int x = 0; x < table1.Rows.Count - 1; x++)
                    {
                        if (dtMain.Rows[x][1].ToString().Equals(table1.Rows[_rCnt][1].ToString())) // dtMain.Rows[k][1].ToString()     // if (table1.Rows[_rCnt][1].ToString().Equals(dtMain.Rows[x][1].ToString())) // dtMain.Rows[k][1].ToString()
                            table1.Rows[_rCnt][4] = dtMain.Rows[x][2];
                        else
                            table1.Rows[_rCnt][4] = "0";
                    }                    
                }

                _rCnt = _rCnt + 1;
            }

            table1.AcceptChanges();

            // dtMerge = table1;               
        }

        gridJobCntMonthly.DataSource = table1;
        gridJobCntMonthly.DataBind();
    }
    private DataTable userKPI_Monthly(int iCnt, int _userID)
    {
        string SqlQuery_Received = string.Empty;
        string SqlQuery_OnTime = string.Empty;
        string SqlQuery_Delay = string.Empty;

        SqlConnection objCon = new SqlConnection(connValue);
        SqlCommand objCmd = new SqlCommand();
        if (iCnt == 1)
        {
            SqlQuery_Received = "SELECT        Contact.firstName, { fn MONTHNAME(JobOwner.staffIssueDate) } AS Month, COUNT(JobOwner.jobOwnerID) AS Received_JobCnt FROM   JobOwner INNER JOIN   Contact ON JobOwner.contactID = Contact.contactID WHERE  " +
          " (JobOwner.contactID = " + _userID + ") AND (YEAR(JobOwner.staffIssueDate) = 2019) GROUP BY Contact.firstName, JobOwner.contactID, { fn MONTHNAME(JobOwner.staffIssueDate) }, MONTH(JobOwner.staffIssueDate) ORDER BY MONTH(JobOwner.staffIssueDate) ";
            objCmd = new SqlCommand(SqlQuery_Received, objCon);

        }
        else if (iCnt == 2)
        {
            SqlQuery_OnTime = "SELECT Contact.firstName, { fn MONTHNAME(JobOwner.completionDate) } AS Month, COUNT(JobOwner.jobOwnerID) AS Received_JobCnt FROM     JobOwner INNER JOIN   Contact ON JobOwner.contactID = Contact.contactID   WHERE   (JobOwner.contactID = " + _userID + ") AND " +
           " (YEAR(JobOwner.completionDate) = 2019) AND datediff(day,JobOwner.completionDate,JobOwner.actionDueDate) >=0 GROUP BY Contact.firstName, JobOwner.contactID, { fn MONTHNAME(JobOwner.completionDate) }, MONTH(JobOwner.completionDate) ORDER BY MONTH(JobOwner.completionDate)";



            objCmd = new SqlCommand(SqlQuery_OnTime, objCon);
        }
        else
        {
            SqlQuery_Delay = "SELECT Contact.firstName, { fn MONTHNAME(JobOwner.completionDate) } AS Month, COUNT(JobOwner.jobOwnerID) AS Received_JobCnt FROM JobOwner INNER JOIN   Contact ON JobOwner.contactID = Contact.contactID   WHERE   (JobOwner.contactID = " + _userID + ") AND " +
           " (YEAR(JobOwner.completionDate) = 2019) AND datediff(day,JobOwner.completionDate,JobOwner.actionDueDate) <0 GROUP BY Contact.firstName, JobOwner.contactID, { fn MONTHNAME(JobOwner.completionDate) }, MONTH(JobOwner.completionDate) ORDER BY MONTH(JobOwner.completionDate)";

            objCmd = new SqlCommand(SqlQuery_Delay, objCon);
        }

        DataSet dsTndrStaff = new DataSet();
        SqlDataAdapter daTndrStaff = new SqlDataAdapter(objCmd);
        daTndrStaff.Fill(dsTndrStaff);

        return dsTndrStaff.Tables[0];
    }

    #region MyRegion

    string strPreviousRowID = string.Empty;
    int intGroupStartRowIndex = 0;

    // To keep track the Index of Group Total
    int intSubTotalIndex = 1;

    // To temporarily store Sub Total
    double dblSubTotalDirectRevenue = 0;
    double dblSubTotalReferralRevenue = 0;
    double dblSubTotalTotalRevenue = 0;

    IList<Table> TotalList = new List<Table>();

   // IList<Total> TotalList = new List<Total>();

    private void PageLoad()
    {
       // TotalList = new List<Total>();

       TableCell cell = grdViewProducts.HeaderRow.Cells[0]; // First Cell in the Header - Grand Total

        System.Web.UI.HtmlControls.HtmlGenericControl title = new System.Web.UI.HtmlControls.HtmlGenericControl();
        title.InnerText = "Year  ";
        cell.Controls.Add(title);

        System.Web.UI.HtmlControls.HtmlImage img = new System.Web.UI.HtmlControls.HtmlImage();
        img.Src = "images/button_minus_red.png";
        img.Attributes.Add("class", "ExpandCollapseHeaderStyle");
        img.Attributes.Add("alt", "0");
        cell.Controls.Add(img);

    }
    protected void grdViewProducts_RowCreated(object sender, GridViewRowEventArgs e)
    {
        bool IsSubTotalRowNeedToAdd = false;

        if ((strPreviousRowID == string.Empty) && (e.Row.RowType == DataControlRowType.DataRow))
        {
            IsSubTotalRowNeedToAdd = true;
            intSubTotalIndex = 1;
        }

        if ((strPreviousRowID != string.Empty) &&
            (e.Row.RowType == DataControlRowType.DataRow) &&
            (strPreviousRowID != DataBinder.Eval(e.Row.DataItem, "Year").ToString())
            )
            IsSubTotalRowNeedToAdd = true;

        if (e.Row.RowType == DataControlRowType.Footer)
            IsSubTotalRowNeedToAdd = false;

        // To add the runing total into List
        if ((e.Row.RowType == DataControlRowType.Footer) || ((e.Row.RowType == DataControlRowType.DataRow) && (IsSubTotalRowNeedToAdd == true) && (strPreviousRowID != string.Empty))            )
        {
           // Total total = new Total();

            //Table total = new Table();

           


            //total.RowIndex = intGroupStartRowIndex;
            //total.DirectRevenue = dblSubTotalDirectRevenue;
            //total.ReferralRevenue = dblSubTotalReferralRevenue;
            //total.TotalRevenue = dblSubTotalTotalRevenue;
            //TotalList.Add(total);
        }

        if (IsSubTotalRowNeedToAdd)
        {
            GridView grdViewProducts = (GridView)sender;

            GridViewRow SubTotalRow = new GridViewRow(0, 0, DataControlRowType.DataRow, DataControlRowState.Insert);

            TableCell cell = new TableCell();

            System.Web.UI.HtmlControls.HtmlImage img = new System.Web.UI.HtmlControls.HtmlImage();
            img.Src = "images/minus.gif";
            img.Attributes.Add("alt", DataBinder.Eval(e.Row.DataItem, "Year").ToString() + ",Expanded");
            img.Attributes.Add("class", "ExpandCollapseStyle");
            cell.Controls.Add(img);

            System.Web.UI.HtmlControls.HtmlGenericControl title = new System.Web.UI.HtmlControls.HtmlGenericControl();
            title.InnerText = DataBinder.Eval(e.Row.DataItem, "Year").ToString();
            cell.Controls.Add(title);
            cell.HorizontalAlign = HorizontalAlign.Left;
            cell.ColumnSpan = 3;
            cell.CssClass = "FirstCellSubTotalRowStyle";
            SubTotalRow.Cells.Add(cell);

            cell = new TableCell();
            cell.Text = string.Format("{0:0.00}", dblSubTotalDirectRevenue);
            cell.HorizontalAlign = HorizontalAlign.Right;
            cell.CssClass = "SubTotalRowStyle";
            SubTotalRow.Cells.Add(cell);

            cell = new TableCell();
            cell.Text = string.Format("{0:0.00}", dblSubTotalReferralRevenue);
            cell.HorizontalAlign = HorizontalAlign.Right;
            cell.CssClass = "SubTotalRowStyle";
            SubTotalRow.Cells.Add(cell);

            cell = new TableCell();
            cell.Text = string.Format("{0:0.00}", dblSubTotalTotalRevenue);
            cell.HorizontalAlign = HorizontalAlign.Right;
            cell.CssClass = "SubTotalRowStyle";
            SubTotalRow.Cells.Add(cell);

            //Adding the Row at the RowIndex position in the Grid

            grdViewProducts.Controls[0].Controls.AddAt(e.Row.RowIndex + intSubTotalIndex, SubTotalRow);
            intGroupStartRowIndex = e.Row.RowIndex + intSubTotalIndex;
            intSubTotalIndex++;

            dblSubTotalDirectRevenue = 0;
            dblSubTotalReferralRevenue = 0;
            dblSubTotalTotalRevenue = 0;
        }
    }
    protected void grdViewProducts_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        // This is for calculation of column (Total = Direct + Referral)
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            strPreviousRowID = DataBinder.Eval(e.Row.DataItem, "Year").ToString();

            double dblDirectRevenue = Convert.ToDouble(DataBinder.Eval(e.Row.DataItem, "DirectRevenue").ToString());
            double dblReferralRevenue = Convert.ToDouble(DataBinder.Eval(e.Row.DataItem, "ReferralRevenue").ToString());

            Label lblTotalRevenue = ((Label)e.Row.FindControl("lblTotalRevenue"));
            //lblTotalRevenue.Text = string.Format("{0:0.00}", (dblDirectRevenue + dblReferralRevenue));

            //dblSubTotalDirectRevenue += dblDirectRevenue;
            //dblSubTotalReferralRevenue += dblReferralRevenue;
            //dblSubTotalTotalRevenue += (dblDirectRevenue + dblReferralRevenue);
            //e.Row.CssClass = "Row" + strPreviousRowID;
        }
    }
    protected void grdViewProducts_DataBound(object sender, EventArgs e)
    {
        //foreach (Total total in TotalList)
        //{
        //    GridViewRow row = (GridViewRow)grdViewProducts.Controls[0].Controls[total.RowIndex];
        //    row.Cells[1].Text = string.Format("{0:0.00}", total.DirectRevenue);
        //    row.Cells[2].Text = string.Format("{0:0.00}", total.ReferralRevenue);
        //    row.Cells[3].Text = string.Format("{0:0.00}", total.TotalRevenue);
        //}
    }

    #endregion


    //#region MyRegion

    //string strPreviousSectorRowID = string.Empty;
    //string strPreviousNameRowID = string.Empty;
    //string strPreviousAccountSectionRowID = string.Empty;

    //int intSectorGroupStartRowIndex = 0;
    //int intNameGroupStartRowIndex = 0;
    //int intAccountSectionGroupStartRowIndex = 0;

    //// To keep track the Index of Group Total
    //int intSubTotalIndex = 1;

    //// To temporarily store Sub Total
    //ProfitLossTotal pfSectorGroupTotal;
    //ProfitLossTotal pfNameGroupTotal;
    //ProfitLossTotal pfAccountSectionGroupTotal;

    //IList<ProfitLossTotal> TotalList;

    //protected void Page_Load(object sender, EventArgs e)
    //{
    //    TotalList = new List<ProfitLossTotal>();
    //    pfSectorGroupTotal = new ProfitLossTotal();
    //    pfNameGroupTotal = new ProfitLossTotal();
    //    pfAccountSectionGroupTotal = new ProfitLossTotal();

    //    TableCell cell = grdViewProducts.HeaderRow.Cells[0];

    //    System.Web.UI.HtmlControls.HtmlGenericControl title = new System.Web.UI.HtmlControls.HtmlGenericControl();
    //    title.InnerText = "Sector  ";
    //    cell.Controls.Add(title);
    //    System.Web.UI.HtmlControls.HtmlImage img = new System.Web.UI.HtmlControls.HtmlImage();
    //    img.Src = "images/minus.gif";
    //    img.Attributes.Add("class", "ExpandCollapseHeaderStyle");
    //    img.Attributes.Add("alt", "1");
    //    cell.Controls.Add(img);
    //    cell.Attributes.Add("alt", "HeaderCell" + ",1");

    //    cell = grdViewProducts.HeaderRow.Cells[1];
    //    title = new System.Web.UI.HtmlControls.HtmlGenericControl();
    //    title.InnerText = "Name  ";
    //    cell.Controls.Add(title);
    //    img = new System.Web.UI.HtmlControls.HtmlImage();
    //    img.Src = "images/minus.gif";
    //    img.Attributes.Add("class", "ExpandCollapseHeaderStyle");
    //    img.Attributes.Add("alt", "2");
    //    cell.Controls.Add(img);
    //    cell.Attributes.Add("alt", "HeaderCell" + ",2");

    //    cell = grdViewProducts.HeaderRow.Cells[2];
    //    title = new System.Web.UI.HtmlControls.HtmlGenericControl();
    //    title.InnerText = "Income / Expense  ";
    //    cell.Controls.Add(title);
    //    img = new System.Web.UI.HtmlControls.HtmlImage();
    //    img.Src = "images/minus.gif";
    //    img.Attributes.Add("class", "ExpandCollapseHeaderStyle");
    //    img.Attributes.Add("alt", "3");
    //    cell.Controls.Add(img);
    //    cell.Attributes.Add("alt", "HeaderCell" + ",3");
    //}

    ///// <summary>
    ///// Event fires for every row creation
    ///// Used for creating SubTotal row when next group starts by adding Group Total at previous row manually
    ///// </summary>
    ///// <param name="sender"></param>
    ///// <param name="e"></param>
    //protected void grdViewProducts_RowCreated(object sender, GridViewRowEventArgs e)
    //{
    //    bool IsSectorSubTotalRowNeedToAdd = false;
    //    bool IsNameSubTotalRowNeedToAdd = false;
    //    bool IsAccountSectionSubTotalRowNeedToAdd = false;

    //    // This is the first row
    //    if ((strPreviousSectorRowID == string.Empty) && (e.Row.RowType == DataControlRowType.DataRow))
    //    {
    //        IsSectorSubTotalRowNeedToAdd = true;
    //        IsNameSubTotalRowNeedToAdd = true;
    //        IsAccountSectionSubTotalRowNeedToAdd = true;
    //        intSubTotalIndex = 1;
    //    }

    //    // When a group completed fully, next group started
    //    if ((strPreviousSectorRowID != string.Empty) &&
    //        (e.Row.RowType == DataControlRowType.DataRow) &&
    //        (strPreviousSectorRowID != DataBinder.Eval(e.Row.DataItem, "Sector").ToString())
    //        )
    //    {
    //        IsSectorSubTotalRowNeedToAdd = true;
    //        IsNameSubTotalRowNeedToAdd = true;
    //        IsAccountSectionSubTotalRowNeedToAdd = true;
    //    }

    //    if ((strPreviousNameRowID != string.Empty) &&
    //        (e.Row.RowType == DataControlRowType.DataRow) &&
    //        (strPreviousNameRowID != DataBinder.Eval(e.Row.DataItem, "Name").ToString())
    //        )
    //        IsNameSubTotalRowNeedToAdd = true;

    //    if ((strPreviousAccountSectionRowID != string.Empty) &&
    //        (e.Row.RowType == DataControlRowType.DataRow) &&
    //        (strPreviousAccountSectionRowID != DataBinder.Eval(e.Row.DataItem, "AccountSection").ToString())
    //        )
    //        IsAccountSectionSubTotalRowNeedToAdd = true;

    //    if (e.Row.RowType == DataControlRowType.Footer)
    //    {
    //        IsSectorSubTotalRowNeedToAdd = false;
    //        IsNameSubTotalRowNeedToAdd = false;
    //        IsAccountSectionSubTotalRowNeedToAdd = false;
    //    }

    //    // To add the runing total into List
    //    if ((e.Row.RowType == DataControlRowType.Footer) ||
    //        ((e.Row.RowType == DataControlRowType.DataRow) && (IsSectorSubTotalRowNeedToAdd == true) && (strPreviousSectorRowID != string.Empty)
    //        )
    //        )
    //    {
    //        pfSectorGroupTotal.RowIndex = intSectorGroupStartRowIndex;
    //        TotalList.Add(pfSectorGroupTotal);
    //    }

    //    if ((e.Row.RowType == DataControlRowType.Footer) ||
    //        ((e.Row.RowType == DataControlRowType.DataRow) && (IsNameSubTotalRowNeedToAdd == true) && (strPreviousNameRowID != string.Empty)
    //        )
    //        )
    //    {
    //        pfNameGroupTotal.RowIndex = intNameGroupStartRowIndex;
    //        TotalList.Add(pfNameGroupTotal);
    //    }
    //    if ((e.Row.RowType == DataControlRowType.Footer) ||
    //        ((e.Row.RowType == DataControlRowType.DataRow) && (IsAccountSectionSubTotalRowNeedToAdd == true) && (strPreviousAccountSectionRowID != string.Empty)
    //        )
    //        )
    //    {
    //        pfAccountSectionGroupTotal.RowIndex = intAccountSectionGroupStartRowIndex;
    //        TotalList.Add(pfAccountSectionGroupTotal);
    //    }


    //    if (IsSectorSubTotalRowNeedToAdd)
    //    {
    //        #region Sector Sub Total
    //        GridView grdViewProducts = (GridView)sender;

    //        GridViewRow SubTotalRow = new GridViewRow(0, 0, DataControlRowType.DataRow, DataControlRowState.Insert);
    //        SubTotalRow.CssClass = "ExpandCollapse" + DataBinder.Eval(e.Row.DataItem, "Sector").ToString().Replace(" ", "");

    //        TableCell cell = new TableCell();

    //        System.Web.UI.HtmlControls.HtmlImage img = new System.Web.UI.HtmlControls.HtmlImage();
    //        img.Src = "images/minus.gif";
    //        img.Attributes.Add("alt", DataBinder.Eval(e.Row.DataItem, "Sector").ToString().Replace(" ", "") + ",1,Expanded");
    //        img.Attributes.Add("class", "ExpandCollapseStyle");
    //        cell.Controls.Add(img);

    //        System.Web.UI.HtmlControls.HtmlGenericControl title = new System.Web.UI.HtmlControls.HtmlGenericControl();
    //        title.InnerText = DataBinder.Eval(e.Row.DataItem, "Sector").ToString();
    //        cell.Controls.Add(title);
    //        cell.HorizontalAlign = HorizontalAlign.Left;
    //        cell.ColumnSpan = 3;
    //        cell.CssClass = "SectionTotalRowStyle";
    //        SubTotalRow.Cells.Add(cell);

    //        cell = new TableCell();
    //        cell.Text = string.Format("{0:0.00}", pfSectorGroupTotal.Sep12);
    //        cell.HorizontalAlign = HorizontalAlign.Right;
    //        cell.CssClass = "SectionTotalRowStyle";
    //        SubTotalRow.Cells.Add(cell);

    //        cell = new TableCell();
    //        cell.Text = string.Format("{0:0.00}", pfSectorGroupTotal.Sep11);
    //        cell.HorizontalAlign = HorizontalAlign.Right;
    //        cell.CssClass = "SectionTotalRowStyle";
    //        SubTotalRow.Cells.Add(cell);

    //        cell = new TableCell();
    //        cell.Text = string.Format("{0:0.00}", pfSectorGroupTotal.Sep10);
    //        cell.HorizontalAlign = HorizontalAlign.Right;
    //        cell.CssClass = "SectionTotalRowStyle";
    //        SubTotalRow.Cells.Add(cell);

    //        cell = new TableCell();
    //        cell.Text = string.Format("{0:0.00}", pfSectorGroupTotal.Sep09);
    //        cell.HorizontalAlign = HorizontalAlign.Right;
    //        cell.CssClass = "SectionTotalRowStyle";
    //        SubTotalRow.Cells.Add(cell);

    //        cell = new TableCell();
    //        cell.Text = string.Format("{0:0.00}", pfSectorGroupTotal.Sep08);
    //        cell.HorizontalAlign = HorizontalAlign.Right;
    //        cell.CssClass = "SectionTotalRowStyle";
    //        SubTotalRow.Cells.Add(cell);

    //        //Adding the Row at the RowIndex position in the Grid
    //        grdViewProducts.Controls[0].Controls.AddAt(e.Row.RowIndex + intSubTotalIndex, SubTotalRow);
    //        intSectorGroupStartRowIndex = e.Row.RowIndex + intSubTotalIndex;
    //        intSubTotalIndex++;

    //        pfSectorGroupTotal = new ProfitLossTotal();
    //        pfNameGroupTotal = new ProfitLossTotal();
    //        pfAccountSectionGroupTotal = new ProfitLossTotal();
    //        #endregion
    //    }

    //    if (IsNameSubTotalRowNeedToAdd)
    //    {
    //        #region Name Sub Total
    //        GridView grdViewProducts = (GridView)sender;

    //        GridViewRow SubTotalRow = new GridViewRow(0, 0, DataControlRowType.DataRow, DataControlRowState.Insert);
    //        SubTotalRow.CssClass = "ExpandCollapse" + DataBinder.Eval(e.Row.DataItem, "Sector").ToString().Replace(" ", "") + "_" + DataBinder.Eval(e.Row.DataItem, "Name").ToString().Replace(" ", "");
    //        TableCell cell = new TableCell();

    //        cell = new TableCell();
    //        cell.Text = string.Empty;
    //        cell.CssClass = "DataCell";
    //        SubTotalRow.Cells.Add(cell);

    //        cell = new TableCell();

    //        System.Web.UI.HtmlControls.HtmlImage img = new System.Web.UI.HtmlControls.HtmlImage();
    //        img.Src = "images/minus.gif";
    //        img.Attributes.Add("alt", DataBinder.Eval(e.Row.DataItem, "Sector").ToString().Replace(" ", "") + "_" + DataBinder.Eval(e.Row.DataItem, "Name").ToString().Replace(" ", "") + ",2,Expanded");
    //        img.Attributes.Add("class", "ExpandCollapseStyle");
    //        cell.Controls.Add(img);

    //        System.Web.UI.HtmlControls.HtmlGenericControl title = new System.Web.UI.HtmlControls.HtmlGenericControl();
    //        title.InnerText = DataBinder.Eval(e.Row.DataItem, "Name").ToString();
    //        cell.Controls.Add(title);
    //        cell.HorizontalAlign = HorizontalAlign.Left;
    //        cell.ColumnSpan = 2;
    //        cell.CssClass = "NameTotalRowStyle";
    //        SubTotalRow.Cells.Add(cell);

    //        cell = new TableCell();
    //        cell.Text = string.Format("{0:0.00}", pfNameGroupTotal.Sep12);
    //        cell.HorizontalAlign = HorizontalAlign.Right;
    //        cell.CssClass = "NameTotalRowStyle";
    //        SubTotalRow.Cells.Add(cell);

    //        cell = new TableCell();
    //        cell.Text = string.Format("{0:0.00}", pfNameGroupTotal.Sep11);
    //        cell.HorizontalAlign = HorizontalAlign.Right;
    //        cell.CssClass = "NameTotalRowStyle";
    //        SubTotalRow.Cells.Add(cell);

    //        cell = new TableCell();
    //        cell.Text = string.Format("{0:0.00}", pfNameGroupTotal.Sep10);
    //        cell.HorizontalAlign = HorizontalAlign.Right;
    //        cell.CssClass = "NameTotalRowStyle";
    //        SubTotalRow.Cells.Add(cell);

    //        cell = new TableCell();
    //        cell.Text = string.Format("{0:0.00}", pfNameGroupTotal.Sep09);
    //        cell.HorizontalAlign = HorizontalAlign.Right;
    //        cell.CssClass = "NameTotalRowStyle";
    //        SubTotalRow.Cells.Add(cell);

    //        cell = new TableCell();
    //        cell.Text = string.Format("{0:0.00}", pfNameGroupTotal.Sep08);
    //        cell.HorizontalAlign = HorizontalAlign.Right;
    //        cell.CssClass = "NameTotalRowStyle";
    //        SubTotalRow.Cells.Add(cell);

    //        //Adding the Row at the RowIndex position in the Grid
    //        grdViewProducts.Controls[0].Controls.AddAt(e.Row.RowIndex + intSubTotalIndex, SubTotalRow);
    //        intNameGroupStartRowIndex = e.Row.RowIndex + intSubTotalIndex;
    //        intSubTotalIndex++;

    //        pfNameGroupTotal = new ProfitLossTotal();
    //        pfAccountSectionGroupTotal = new ProfitLossTotal();
    //        #endregion
    //    }

    //    if (IsAccountSectionSubTotalRowNeedToAdd)
    //    {
    //        #region Account Section Sub Total
    //        GridView grdViewProducts = (GridView)sender;

    //        GridViewRow SubTotalRow = new GridViewRow(0, 0, DataControlRowType.DataRow, DataControlRowState.Insert);
    //        SubTotalRow.CssClass = "ExpandCollapse" + DataBinder.Eval(e.Row.DataItem, "Sector").ToString().Replace(" ", "") + "_" + DataBinder.Eval(e.Row.DataItem, "Name").ToString().Replace(" ", "") + "_" + DataBinder.Eval(e.Row.DataItem, "AccountSection").ToString().Replace(" ", "");
    //        TableCell cell = new TableCell();

    //        cell = new TableCell();
    //        cell.Text = string.Empty;
    //        cell.CssClass = "DataCell";
    //        SubTotalRow.Cells.Add(cell);

    //        cell = new TableCell();
    //        cell.Text = string.Empty;
    //        cell.CssClass = "DataCell";
    //        SubTotalRow.Cells.Add(cell);

    //        cell = new TableCell();

    //        System.Web.UI.HtmlControls.HtmlImage img = new System.Web.UI.HtmlControls.HtmlImage();
    //        img.Src = "images/minus.gif";
    //        img.Attributes.Add("alt", DataBinder.Eval(e.Row.DataItem, "Sector").ToString().Replace(" ", "") + "_" + DataBinder.Eval(e.Row.DataItem, "Name").ToString().Replace(" ", "") + "_" + DataBinder.Eval(e.Row.DataItem, "AccountSection").ToString().Replace(" ", "") + ",3,Expanded");
    //        img.Attributes.Add("class", "ExpandCollapseStyle");
    //        cell.Controls.Add(img);

    //        System.Web.UI.HtmlControls.HtmlGenericControl title = new System.Web.UI.HtmlControls.HtmlGenericControl();
    //        title.InnerText = DataBinder.Eval(e.Row.DataItem, "AccountSection").ToString();
    //        cell.Controls.Add(title);
    //        cell.HorizontalAlign = HorizontalAlign.Left;
    //        cell.CssClass = "AccountSectionTotalRowStyle";
    //        SubTotalRow.Cells.Add(cell);

    //        cell = new TableCell();
    //        cell.Text = string.Format("{0:0.00}", pfAccountSectionGroupTotal.Sep12);
    //        cell.HorizontalAlign = HorizontalAlign.Right;
    //        cell.CssClass = "AccountSectionTotalRowStyle";
    //        SubTotalRow.Cells.Add(cell);

    //        cell = new TableCell();
    //        cell.Text = string.Format("{0:0.00}", pfAccountSectionGroupTotal.Sep11);
    //        cell.HorizontalAlign = HorizontalAlign.Right;
    //        cell.CssClass = "AccountSectionTotalRowStyle";
    //        SubTotalRow.Cells.Add(cell);

    //        cell = new TableCell();
    //        cell.Text = string.Format("{0:0.00}", pfAccountSectionGroupTotal.Sep10);
    //        cell.HorizontalAlign = HorizontalAlign.Right;
    //        cell.CssClass = "AccountSectionTotalRowStyle";
    //        SubTotalRow.Cells.Add(cell);

    //        cell = new TableCell();
    //        cell.Text = string.Format("{0:0.00}", pfAccountSectionGroupTotal.Sep09);
    //        cell.HorizontalAlign = HorizontalAlign.Right;
    //        cell.CssClass = "AccountSectionTotalRowStyle";
    //        SubTotalRow.Cells.Add(cell);

    //        cell = new TableCell();
    //        cell.Text = string.Format("{0:0.00}", pfAccountSectionGroupTotal.Sep08);
    //        cell.HorizontalAlign = HorizontalAlign.Right;
    //        cell.CssClass = "AccountSectionTotalRowStyle";
    //        SubTotalRow.Cells.Add(cell);

    //        //Adding the Row at the RowIndex position in the Grid
    //        grdViewProducts.Controls[0].Controls.AddAt(e.Row.RowIndex + intSubTotalIndex, SubTotalRow);
    //        intAccountSectionGroupStartRowIndex = e.Row.RowIndex + intSubTotalIndex;
    //        intSubTotalIndex++;

    //        pfAccountSectionGroupTotal = new ProfitLossTotal();
    //        #endregion
    //    }
    //}

    ///// <summary>
    ///// Event fires when data binds to each row
    ///// Used for calculating Group Total 
    ///// </summary>
    ///// <param name="sender"></param>
    ///// <param name="e"></param>
    //protected void grdViewProducts_RowDataBound(object sender, GridViewRowEventArgs e)
    //{
    //    // This is for calculation of column (Total = Direct + Referral)
    //    if (e.Row.RowType == DataControlRowType.DataRow)
    //    {
    //        strPreviousSectorRowID = DataBinder.Eval(e.Row.DataItem, "Sector").ToString();
    //        strPreviousNameRowID = DataBinder.Eval(e.Row.DataItem, "Name").ToString();
    //        strPreviousAccountSectionRowID = DataBinder.Eval(e.Row.DataItem, "AccountSection").ToString();

    //        pfSectorGroupTotal.Sep12 += Convert.ToDouble(DataBinder.Eval(e.Row.DataItem, "Sep12").ToString());
    //        pfSectorGroupTotal.Sep11 += Convert.ToDouble(DataBinder.Eval(e.Row.DataItem, "Sep11").ToString());
    //        pfSectorGroupTotal.Sep10 += Convert.ToDouble(DataBinder.Eval(e.Row.DataItem, "Sep10").ToString());
    //        pfSectorGroupTotal.Sep09 += Convert.ToDouble(DataBinder.Eval(e.Row.DataItem, "Sep09").ToString());
    //        pfSectorGroupTotal.Sep08 += Convert.ToDouble(DataBinder.Eval(e.Row.DataItem, "Sep08").ToString());

    //        pfNameGroupTotal.Sep12 += Convert.ToDouble(DataBinder.Eval(e.Row.DataItem, "Sep12").ToString());
    //        pfNameGroupTotal.Sep11 += Convert.ToDouble(DataBinder.Eval(e.Row.DataItem, "Sep11").ToString());
    //        pfNameGroupTotal.Sep10 += Convert.ToDouble(DataBinder.Eval(e.Row.DataItem, "Sep10").ToString());
    //        pfNameGroupTotal.Sep09 += Convert.ToDouble(DataBinder.Eval(e.Row.DataItem, "Sep09").ToString());
    //        pfNameGroupTotal.Sep08 += Convert.ToDouble(DataBinder.Eval(e.Row.DataItem, "Sep08").ToString());

    //        pfAccountSectionGroupTotal.Sep12 += Convert.ToDouble(DataBinder.Eval(e.Row.DataItem, "Sep12").ToString());
    //        pfAccountSectionGroupTotal.Sep11 += Convert.ToDouble(DataBinder.Eval(e.Row.DataItem, "Sep11").ToString());
    //        pfAccountSectionGroupTotal.Sep10 += Convert.ToDouble(DataBinder.Eval(e.Row.DataItem, "Sep10").ToString());
    //        pfAccountSectionGroupTotal.Sep09 += Convert.ToDouble(DataBinder.Eval(e.Row.DataItem, "Sep09").ToString());
    //        pfAccountSectionGroupTotal.Sep08 += Convert.ToDouble(DataBinder.Eval(e.Row.DataItem, "Sep08").ToString());

    //        //e.Row.Style.Add("display", "block");
    //        e.Row.Cells[0].CssClass = "DataRowStyle";
    //        e.Row.Cells[0].Attributes.Add("alt", ",4");
    //        //e.Row.CssClass = "Row" + strPreviousSectorRowID.Replace(" ", "") + "_" + strPreviousNameRowID.Replace(" ", "") + "_" + strPreviousAccountSectionRowID.Replace(" ", "");

    //    }
    //}

    //protected void grdViewProducts_DataBound(object sender, EventArgs e)
    //{
    //    foreach (ProfitLossTotal total in TotalList)
    //    {
    //        GridViewRow row = (GridViewRow)grdViewProducts.Controls[0].Controls[total.RowIndex];

    //        row.Cells[row.Cells.Count - 5].Text = string.Format("{0:0.00}", total.Sep12);
    //        row.Cells[row.Cells.Count - 4].Text = string.Format("{0:0.00}", total.Sep11);
    //        row.Cells[row.Cells.Count - 3].Text = string.Format("{0:0.00}", total.Sep10);
    //        row.Cells[row.Cells.Count - 2].Text = string.Format("{0:0.00}", total.Sep09);
    //        row.Cells[row.Cells.Count - 1].Text = string.Format("{0:0.00}", total.Sep08);
    //    }
    //}
    //#endregion

}