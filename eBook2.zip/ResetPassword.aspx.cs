﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data.SqlClient;

public partial class ResetPassword : System.Web.UI.Page
{
    string connValue = ConfigurationManager.ConnectionStrings["EBSDEBookConn"].ToString();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Request.QueryString["code"] != null)
            {                 
                UtilityClass uCls = null;
                DAL dal = null;
                try
                {

                    uCls = new UtilityClass(this.Page);
                    dal = new DAL(connValue);
                    if (dal.ConnectDB(this.Page) == 'E')
                        return;
                    SqlCommand sqlCommand = new SqlCommand("select emailAddress from contact where code=@code", dal.SqlConnection);
                    sqlCommand.Parameters.AddWithValue("@code", Request.QueryString["code"].ToString());
                    SqlDataReader sqlDtReader = sqlCommand.ExecuteReader();
                    if (!sqlDtReader.Read())
                    {
                        ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('You are not an authenticated user')</script>", false);
                        txtNewPwd.Enabled = false;
                        txtConfirmPassword.Enabled = false;
                        btnChangePwd.Enabled = false;
                    }
                    sqlDtReader.Close();
                }
                catch (Exception ex)
                {
                    ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Error occurred while performing database operation')</script>", false);
                }
                finally
                {
                    if (dal != null)
                        dal.DisconnectDB();
                }
            }
        }           
        
    }
    protected void btnChangePwd_Click(object sender, EventArgs e)
    {
        if (Request.QueryString["code"] != null)
        {
            DAL dal = null;
            UtilityClass uCls = null;
            try
            {
                dal = new DAL(connValue);
                uCls = new UtilityClass(this.Page);
                if (dal.ConnectDB(this.Page) == 'E')
                    return;
                SqlCommand sqlCommand = new SqlCommand("update Users set password=HashBytes('SHA1', @password) where code=@code", dal.SqlConnection);
                sqlCommand.Parameters.AddWithValue("@code", Request.QueryString["code"].ToString());
                sqlCommand.Parameters.AddWithValue("@password", txtConfirmPassword.Text.Trim());
                if (sqlCommand.ExecuteNonQuery() == 1)
                {
                    //ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Password has been reset successfully')</script>", false);
                    Response.Redirect("~/LoginPage.aspx", false);
                    sqlCommand = null;
                }

            }
            catch (Exception ex)
            {
                ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Error occurred while performing database operation')</script>", false);
            }
            finally
            {
                if (dal != null)
                    dal.DisconnectDB();
            }
        }
    }
}