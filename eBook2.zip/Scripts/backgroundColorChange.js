﻿function changeBackgroundColor(id) {
    //alert('Hi') find("option:selected")
    if ($(id + ':selected').text().split('-')[1] == "Providing a safe & healthy environment for everyone") {
        //$('#ctl00_straTheme1').removeClass('column');
        $('#ctl00_straTheme1').attr('style', 'background-color:');
        $('#ctl00_straTheme1').attr('style', 'background-color:#92c854;');
        $('#straTheme2').attr('style', 'background-color:');
        $('#straTheme2').attr('style', 'background-color:#F0F0F0;');
        $('#straTheme3').attr('style', 'background-color:');
        $('#straTheme3').attr('style', 'background-color:#CCFFFF;');
        $('#straTheme4').attr('style', 'background-color:');
        $('#straTheme4').attr('style', 'background-color:#ccffe6;');
        //$('#ctl00_straTheme1').addClass('column');
    }
    else if ($(id + ':selected').text().split('-')[1] == "Delivering Excellence") {
        //$('#straTheme2').removeClass('column');
        $('#ctl00_straTheme1').attr('style', 'background-color:');
        $('#ctl00_straTheme1').attr('style', 'background-color:#FFFFCC;');
        $('#straTheme2').attr('style', 'background-color:');
        $('#straTheme2').attr('style', 'background-color:#92c854;');
        $('#straTheme3').attr('style', 'background-color:');
        $('#straTheme3').attr('style', 'background-color:#CCFFFF;');
        $('#straTheme4').attr('style', 'background-color:');
        $('#straTheme4').attr('style', 'background-color:#ccffe6;');
        //$('#straTheme2').addClass('column');
    }
    else if ($(id + ':selected').text().split('-')[1] == "Developing capabilities to support future service delivery") {
        //$('#ctl00_straTheme3').removeClass('column');
        $('#ctl00_straTheme1').attr('style', 'background-color:');
        $('#ctl00_straTheme1').attr('style', 'background-color:#FFFFCC;');
        $('#straTheme2').attr('style', 'background-color:');
        $('#straTheme2').attr('style', 'background-color:#F0F0F0;');
        $('#straTheme3').attr('style', 'background-color:');
        $('#straTheme3').attr('style', 'background-color:#92c854;');
        $('#straTheme4').attr('style', 'background-color:');
        $('#straTheme4').attr('style', 'background-color:#ccffe6;');
        //$('#ctl00_straTheme3').addClass('column');
    }
    else if ($(id + ':selected').text().split('-')[1] == "Building trust through excellent customer experiences") {
        //$('#ctl00_straTheme4').removeClass('column');
        $('#ctl00_straTheme1').attr('style', 'background-color:');
        $('#ctl00_straTheme1').attr('style', 'background-color:#FFFFCC;');
        $('#straTheme2').attr('style', 'background-color:');
        $('#straTheme2').attr('style', 'background-color:#F0F0F0;');
        $('#straTheme3').attr('style', 'background-color:');
        $('#straTheme3').attr('style', 'background-color:#CCFFFF;');
        $('#straTheme4').attr('style', 'background-color:');
        $('#straTheme4').attr('style', 'background-color:#92c854;');
        //$('#ctl00_straTheme4').addClass('column');
    }
}