﻿$(function () {
    $('#ctl00_strBanner').attr('style', 'display-inline:block');     
    $('#ctl00_strThemes').attr('style', 'display-inline:block');
});