﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Web.UI.HtmlControls;
using System.Web.Security;
using System.Globalization;



using System.IO;

using Oracle.ManagedDataAccess.Client;
using System.Net;


public partial class LoginPage : System.Web.UI.Page
{
    DAL dal = null;
    UtilityClass utilCls = null;
    private string connValue = ConfigurationManager.ConnectionStrings["EBSDEBookConn"].ToString();

    
    static string compname = string.Empty;

    static string userName = string.Empty;
    static int _contactID = 0; 
    protected void Page_Load(object sender, EventArgs e)
    {
       try
        {
            if (!IsPostBack)
            {
                if (Request.QueryString["RegUser"] != null)
                    txtUsername.Text = Request.QueryString["RegUser"].ToString();

                dal = new DAL(connValue);
                utilCls = new UtilityClass(this.Page);

                lblDate.Text = DateTime.Now.ToString();
                Label2.Text = "After Convert as CurrentCulture " + Convert.ToDateTime(DateTime.Now, CultureInfo.CurrentCulture).ToString("dd/MMM/yyyy HH:mm:ss") + " Published " + Application["xyz"].ToString();
            }
        }
       catch (Exception ex)
       {
           string strError = ex.Message;
          // ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Error occurred while reading computerName')</script>", false);
       }
       finally
       {

       }        
    }
    protected void btnLogin_Click(object sender, EventArgs e)
    {
      loginUser();       
    }
    private void loginUser()
    {
        dal = new DAL(connValue);
        utilCls = new UtilityClass(this.Page);

        if (dal.ConnectDB(this.Page) == 'E')
            return;

       // string connResult = string.Empty;

      
        string connResult = utilCls.AuthenticateUserCredentials(txtUsername.Text, txtPassword.Text, dal);

        if (connResult == "0")
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('You are not an Authenticated User')</script>", false);
            txtUsername.Text = "";
            txtPassword.Text = "";
            txtUsername.Focus();
        }
        else if (connResult == "Ex")
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Error occurred while performing database operation')</script>", false);
        }
        else
        {
            loginUpdate();
            
            //if (Session["UserProfileID"].Equals("1"))
            //    Response.Redirect("~/JobOrder/AdminHomePage.aspx", false);
            //else                

            // Response.Redirect("~/JobOrder/CostControlHomePage.aspx", false);
            if (Session["UserProfileID"].Equals("1"))
                Response.Redirect("~/JobOrder/DCLogHomePage.aspx", false);
            else if (Session["SectionID"].Equals("3"))
                Response.Redirect("~/JobOrder/DCLogHomePage.aspx", false);
            else if (Session["SectionID"].Equals("12")) // else if (Session["UserID"].Equals("358"))
            {
                // Response.Redirect("~/Guest/Default9.aspx", false);

                Response.Redirect("~/Contracts/ClaimsHomePage.aspx", false);
            }
            else if (Session["SectionID"].Equals("13")) // else if (Session["UserID"].Equals("358"))
            {
                // Response.Redirect("~/Guest/Default9.aspx", false);

                Response.Redirect("~/TSS/TSSHomePage.aspx", false);
            }
            else if (Session["UserProfileID"].Equals("20")) //  Response.Redirect("~/JobOrder/CostControlHomePage.aspx", false);
                Response.Redirect("~/DCOnline/DCOnlineContracts.aspx", false);
            //Response.Redirect("~/Strategy/StrategyHome.aspx", false);
            else if (Session["SectionID"].Equals("11"))  // GIS
                Response.Redirect("~/JobOrder/DCLogHomePage.aspx", false); // Response.Redirect("~/GIS/GISData.aspx", false);
            else if (Session["UserProfileID"].Equals("23"))
                Response.Redirect("~/ESDStrategy/index.aspx", false);
            else if ((Session["CmpID"].ToString() == "2783") && !Session["SectionID"].Equals("4"))
                Response.Redirect("~/JobOrder/DCLogHomePage.aspx", false);
            else if ((Session["CmpID"].ToString() == "362") && !Session["SectionID"].Equals("4"))
                Response.Redirect("~/JobOrder/DCLogHomePage.aspx", false);
            else if (Session["SectionID"].Equals("4"))
                Response.Redirect("~/JobOrder/SurveyDefaultWindow.aspx", false);


            else
                Response.Redirect("~/JobOrder/NonEBDHomePage.aspx", false);

            //if (Session["UserProfileID"].Equals("1"))
            //    Response.Redirect("~/JobOrder/DefaultWindow.aspx", false);
            //else if (Session["UserID"].Equals("95"))
            //    Response.Redirect("~/JobOrder/CostControlHomePage.aspx", false);
            //else if ((Session["CmpID"].ToString() == "362") && !Session["SectionID"].Equals("4"))
            //    Response.Redirect("~/JobOrder/DefaultWindow.aspx", false);
            //else if (Session["SectionID"].Equals("4"))
            //    Response.Redirect("~/JobOrder/SurveyDefaultWindow.aspx", false);
            //else if (Session["UserProfileID"].Equals("14"))
            //    Response.Redirect("~/Strategy/StrategyHome.aspx", false);
            //else
            //    Response.Redirect("~/JobOrder/NonEBDHomePage.aspx", false);

            //Response.Redirect("~/JobOrder/HomePage.aspx", false);
        }
    }
    protected void lnkRegister_Click(object sender, EventArgs e)
    {       
        string _username = string.Empty;
        _username = checkUserExist(compname, userName);

        if (_username != "")
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('You are already Registered user,Click on Login Here')</script>", false);
            return;
        }
        Session["OutsideClick"] = "1";       

        Response.Redirect("UserRigistration.aspx", false);
    }   
    private void loginUpdate()
    {
        SqlConnection _con = new SqlConnection(connValue);
        SqlCommand _cmdInsert = new SqlCommand("Update Contact Set isLogIn =@isLogin where contactID = " + Convert.ToInt32(Session["userID"]) + "", _con);
       _cmdInsert.Parameters.AddWithValue("@userID", Convert.ToInt32(Session["userID"]));
       _cmdInsert.Parameters.AddWithValue("@isLogin", 1);
        try
        {
            _con.Open();
            _cmdInsert.ExecuteNonQuery();
        }
        finally
        {
            _con.Close();
        }
    }
    private void InsertloginInfo()
    {
        SqlConnection _con = new SqlConnection(connValue);
        SqlCommand _cmdInsert = new SqlCommand();
        _cmdInsert.CommandType = CommandType.StoredProcedure;
        _cmdInsert.CommandText = "UserLoginActivity";
        _cmdInsert.Connection = _con;

        _cmdInsert.Parameters.AddWithValue("@contactID", _contactID);
        _cmdInsert.Parameters.AddWithValue("@loginTime", System.DateTime.Now);
        _cmdInsert.Parameters.AddWithValue("@logoutTime", System.DBNull.Value);
        _cmdInsert.Parameters.AddWithValue("@computerName", compname);
        _cmdInsert.Parameters.AddWithValue("@systemUserName", userName);

        try
        {
            _con.Open();
            _cmdInsert.ExecuteNonQuery();
        }
        finally
        {
            _con.Close();
        }
    }   
    public  string checkUserExist(string userComputerName, string systemUserName)
    {
        string userName = string.Empty;
        string str = User.Identity.Name;
        try
        {
            SqlConnection sqlConn = new SqlConnection(connValue);
            sqlConn.Open();

           // string sqlQuery = "Select UserName,contactID from Contact  where computerName = '" + userComputerName + "' and  systemUserName = '" + systemUserName + "'";

            string sqlQuery = "Select UserName,contactID from Contact where computerName = '" + userComputerName + "'";
            SqlCommand sqlCom = new SqlCommand(sqlQuery, sqlConn);       
            SqlDataReader sqlReader = sqlCom.ExecuteReader();
            if (sqlReader.HasRows)
            {
                while (sqlReader.Read())
                {
                    userName = sqlReader["UserName"].ToString();
                    _contactID = Convert.ToInt32(sqlReader["contactID"]);
                }
            }
            sqlReader.Close();
            sqlConn.Close();
        }
        catch (System.Exception ex)
        {
            throw ex;
        }
        return userName;
    }
    protected void lnkPasswordChange_Click(object sender, EventArgs e)
    {
       Response.Redirect("~/ForgotPassword.aspx", false);

        // Response.Redirect("~/JobOrder/CostControlHomePage.aspx", false);

        
    }

    protected void LinkButton1_Click1(object sender, EventArgs e)
    {
        dal = new DAL(connValue);
        utilCls = new UtilityClass(this.Page);

        try
        {
            try
            {
               


                string full_computername = System.Net.Dns.GetHostEntry(Request.ServerVariables["REMOTE_HOST"]).HostName; // FUll computer name
                compname = System.Net.Dns.GetHostEntry(Request.ServerVariables["REMOTE_HOST"]).HostName.Split('.')[0]; // Computer name only
                userName = compname.Split('.')[0].Replace("-", "_").ToLower();

               
            }
            catch (Exception ex)
            {
                Response.Write("Cname" + compname);
                throw ex;               
            }

        

            string _username = string.Empty;
            _username = checkUserExist(compname, userName);
            if (_username != "")
            {
                Session["Opened"] = "False";
                InsertloginInfo();

                if (utilCls.AuthenticateUserCredentialsDirect(compname, userName))
                {
                    loginUpdate();
                    Session["Opened"] = "False";   // For Alert pop Adm, over due job             
                    
                    if ((Session["CmpID"].ToString() == "362") && !Session["SectionID"].Equals("4"))
                        Response.Redirect("~/JobOrder/DefaultWindow.aspx", false);
                    else if (Session["SectionID"].Equals("4"))
                        Response.Redirect("~/JobOrder/SurveyDefaultWindow.aspx", false);
                    else
                        Response.Redirect("~/JobOrder/NonEBDHomePage.aspx", false); 
                }
            }
            else
            {
                ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('You are not a registered user, please click Register Here.')</script>", false);
            }
        }
        catch (Exception ex)
        {
            
        }
        finally
        {
           // Response.Redirect("~/JobOrder/DefaultWindow.aspx", false);
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
       
    }
    protected void Button1_Click1(object sender, EventArgs e)
    {    
    
    }
    //protected void Button1_Click2(object sender, EventArgs e)
    //{

    //    IList<string> strColl = new List<string>();

    //    string text = System.IO.File.ReadAllText(@"C:\WriteText.txt");

    //    // Display the file contents to the console. Variable text is a string.
    //    System.Console.WriteLine("Contents of WriteText.txt = {0}", text);

    //    // Example #2
    //    // Read each line of the file into a string array. Each element
    //    // of the array is one line of the file.
    //    string[] lines = System.IO.File.ReadAllLines(@"C:\WriteText.txt");

    //    // Display the file contents by using a foreach loop.
    //    System.Console.WriteLine("Contents of WriteLines2.txt = ");
    //    foreach (string line in lines)
    //    {
    //        // Use a tab to indent each line of the file.
    //        Console.WriteLine("\t" + line);

    //        if (line.Contains("X="))
    //        {
    //            strColl
    //        }
            
    //    }

    //    // Keep the console window open in debug mode.
    //    Console.WriteLine("Press any key to exit.");
    //    System.Console.ReadKey();
    //}
    protected void LinkButton2_Click(object sender, EventArgs e)
    {
        string aaa = System.Environment.MachineName;
        string bbb = HttpContext.Current.Server.MachineName;
        string ccc = System.Net.Dns.GetHostName();
        string ddd = System.Net.Dns.GetHostEntry(Environment.MachineName).HostName;
        string eee = System.Net.Dns.GetHostByName("LocalHost").HostName;

        string s = aaa + " -- " + bbb + " -- " + ccc + " -- " + ddd + " -- " + eee;

        Response.Write(s);


        string[] computer_name = System.Net.Dns.GetHostEntry(Request.ServerVariables["remote_addr"]).HostName.Split(new Char[] { '.' });
        String ecn = System.Environment.MachineName;
        Response.Write(" ----" + computer_name[0].ToString());


        string clientMachineName;
        clientMachineName = (Dns.GetHostEntry(Request.ServerVariables["remote_addr"]).HostName);
        Response.Write("--- > " +  clientMachineName);





    }
}