﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class TSS_Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void btnStaffSave_Click(object sender, EventArgs e)
    {
        //_httpContext.Items[""].ToString()

        //btnStaffSave.UseSubmitBehavior == false
        string keyValue = null;
        if (Request.Cookies["key"] != null) {
            keyValue = Request.Cookies["key"].Value; 
        }
        //HtmlGenericControl subClick1 = (HtmlGenericControl)this.Form.FindControl("btnAddClickDiv");
        //ClientScript.RegisterClientScriptBlock(this.GetType(), "Popup", "<script>var hdnAddClicked = document.getElementById('hdnAddClick') ;alert(hdnAddClicked)</script>", false);
        if (keyValue == "1")
        {

            //btnStaffSave.Click -= new EventHandler(btnStaffSave_Click);

             
               
                //updateOngoingStatus(Convert.ToInt32(Session["loggedInJobOwnerID"]), 7,""); //7=="Completed"
                //hdnAddClick.Value = "";
                //btnStaffSave.Attributes.Remove("onclick");
                //ClientScript.RegisterClientScriptBlock(this.GetType(), "Popup", "<script>onButtonClick('0')</script>", false);
                //btnStaffSave.Attributes.Add("onclick","onButtonClick('1')");
            Request.Cookies["key"].Value = "0";
            //hdnAddClick.Value = "0";
                //btnAddClickDiv.Text = "0";
                //Control ctrl = new Control();
                //ctrl.ID = "subClick";
                //Page.Controls.Remove(subClick1);
                //ClientScript.RegisterClientScriptBlock(this.GetType(), "Popup", "<script>$('#__EVENTTARGET').val('');alert($('#__EVENTTARGET').val())</script>", false);
                //ClientScript.RegisterClientScriptBlock(this.GetType(), "Popup", "<script>document.getElementById('sub').value='';alert(document.getElementById('sub').value)</script>", false);
                //sub.Value = "";
                

        }

    }
}