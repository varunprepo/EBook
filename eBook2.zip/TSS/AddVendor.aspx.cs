﻿using Datalayer;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class TSS_AddVendor : System.Web.UI.Page
{
    string eBookConn = System.Configuration.ConfigurationManager.ConnectionStrings["EBSDEBookConn"].ConnectionString;
    string tcmsConn = System.Configuration.ConfigurationManager.ConnectionStrings["TCMSConn"].ConnectionString;
    IList<string> userRightsColl = new List<string>();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["UserName"] == null)
        {
            Response.Redirect("~/LoginPage.aspx", false);
            return;
        }

        if (!IsPostBack)
        {
            userRightsColl = (IList<string>)Session["UserRightsColl"];
            lblUser.Text = Session["UserDisplayName"].ToString();
            lblUserProfile.Text = Session["ProfileName"].ToString();
            txtProjTitle.Text = Session["PrjTitle"].ToString();
            addVendor.InnerText =  "ADD VENDOR DETAILS | EOI Number:-" + Session["EOINumber"] + " | Job No.:-" + Session["JobNo"];
            try
            {
                PopulateDropDownBox(ddlCompany, "SELECT co_id,co_name FROM Company where co_name not like '%PWA%' ORDER BY co_name", "co_id", "co_name", "");
                //PopulateDropDownBox(ddlCompany, "SELECT co_id,co_Name FROM Company_TCMS where co_Name not like '%PWA%' ORDER BY co_Name", "co_id", "co_Name", "");            
                //BindGridviewData();
            }
            catch (Exception ex)
            {
                ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Error occurred while retrieving the information of uploaded files')</script>", false);
            }
        }
    }
    private void PopulateDropDownBox(DropDownList ddlBox, string sqlQuery, string valueMember, string displayName, string selectName)
    {
        ddlBox.DataSource = new JobOrderData().FillDropdown_TCMS(sqlQuery);
        ddlBox.DataTextField = displayName;
        //if (valueMember == "cmpIDAndShortName")
        //{
        //    ddlBox.DataValueField = valueMember; //.companyID+","+valueMember.cmpShortName;
        //}
        //else
        //{
        ddlBox.DataValueField = valueMember;
        //}
        ddlBox.SelectedIndex = -1;
        ddlBox.DataBind();

        ListItem emptyItem = new ListItem(selectName, selectName);
        ddlBox.Items.Insert(0, emptyItem);
    }
    protected void lnkCRDownload_Click(object sender, EventArgs e)
    {
        //if (checkUserExist(Convert.ToInt32(fileID), 1, Convert.ToInt32(Session["UserID"])))

        LinkButton lnkbtn = sender as LinkButton;
        GridViewRow gvrow = lnkbtn.NamingContainer as GridViewRow;

        string filePath = gvCrFilesUpload.DataKeys[gvrow.RowIndex].Value.ToString();

        // Only use in case Application Server File foldes not in C Drive

        //if (Session["SectionID"].ToString().Equals("12") || Session["SectionID"].ToString().Equals("13"))
        //filePath = filePath.Replace("C:", "C:");
        //else
        //    filePath = filePath.Replace("C:", "E:");           

        //Response.TransmitFile(Server.MapPath(filePath));

        if (!File.Exists((string)filePath))
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('File not available at specific path')</script>", false);
            return;
        }
        FileInfo file = new FileInfo(filePath);
        string fileName = file.FullName;
        Response.AddHeader("Content-Disposition", "attachment;filename=\"" + fileName + "\"");
        Response.TransmitFile(fileName);
        Response.End();
    }
    protected void lnkSDDownload_Click(object sender, EventArgs e)
    {
        //if (checkUserExist(Convert.ToInt32(fileID), 1, Convert.ToInt32(Session["UserID"])))

        LinkButton lnkbtn = sender as LinkButton;
        GridViewRow gvrow = lnkbtn.NamingContainer as GridViewRow;

        string filePath = gvSdFilesUpload.DataKeys[gvrow.RowIndex].Value.ToString();

        // Only use in case Application Server File foldes not in C Drive

        //if (Session["SectionID"].ToString().Equals("12") || Session["SectionID"].ToString().Equals("13"))
        //filePath = filePath.Replace("C:", "C:");
        //else
        //    filePath = filePath.Replace("C:", "E:");           

        //Response.TransmitFile(Server.MapPath(filePath));

        if (!File.Exists((string)filePath))
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('File not available at specific path')</script>", false);
            return;
        }
        FileInfo file = new FileInfo(filePath);
        string fileName = file.FullName;
        Response.AddHeader("Content-Disposition", "attachment;filename=\"" + fileName + "\"");
        Response.TransmitFile(fileName);
        Response.End();
    }
    protected void lnkSDDelete_Click(object sender, EventArgs e)
    {

        try
        {
            LinkButton lnkbtn = sender as LinkButton;
            GridViewRow gvrow = lnkbtn.NamingContainer as GridViewRow;
            string fileID = gvCrFilesUpload.DataKeys[gvrow.RowIndex].Values[1].ToString();

            if (!userRightsColl.Contains("26"))
            {
                if (checkUserExist(Convert.ToInt32(fileID), 1, Convert.ToInt32(Session["UserID"])))
                {
                    try
                    {
                        using (SqlConnection con = new SqlConnection(eBookConn))
                        {
                            con.Open();
                            using (SqlCommand cmd = new SqlCommand("Update FilesTable Set isFileActive = 0,updateUser = @updateUser,updateDate = @updateDate where fileID = " + fileID, con))
                            {
                                cmd.Parameters.AddWithValue("@updateUser", Session["Username"].ToString());
                                cmd.Parameters.AddWithValue("@updateDate", System.DateTime.Now);
                                cmd.ExecuteNonQuery();
                            }
                        }
                    }
                    catch (Exception ex)
                    {

                    }

                    BindGridviewData("SD");
                }

                else
                {
                    ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('You do not have rights to delete this file')</script>", false);
                }
            }
            else
            {
                ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Please contact Administrator,You do not have rights to delete this file')</script>", false);
            }
        }
        catch (Exception ex)
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Error occurred while processing the request')</script>", false);
        }

    }
    protected void lnkCRDelete_Click(object sender, EventArgs e)
    {

        try
        {
            LinkButton lnkbtn = sender as LinkButton;
            GridViewRow gvrow = lnkbtn.NamingContainer as GridViewRow;
            string fileID = gvCrFilesUpload.DataKeys[gvrow.RowIndex].Values[1].ToString();

            if (!userRightsColl.Contains("26"))
            {
                if (checkUserExist(Convert.ToInt32(fileID), 1, Convert.ToInt32(Session["UserID"])))
                {
                    try
                    {
                        using (SqlConnection con = new SqlConnection(eBookConn))
                        {
                            con.Open();
                            using (SqlCommand cmd = new SqlCommand("Update FilesTable Set isFileActive = 0,updateUser = @updateUser,updateDate = @updateDate where fileID = " + fileID, con))
                            {
                                cmd.Parameters.AddWithValue("@updateUser", Session["Username"].ToString());
                                cmd.Parameters.AddWithValue("@updateDate", System.DateTime.Now);
                                cmd.ExecuteNonQuery();
                            }
                        }
                    }
                    catch (Exception ex)
                    {

                    }

                    BindGridviewData("CR");
                }

                else
                {
                    ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('You do not have rights to delete this file')</script>", false);
                }
            }
            else
            {
                ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Please contact Administrator,You do not have rights to delete this file')</script>", false);
            }
        }
        catch (Exception ex)
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Error occurred while processing the request')</script>", false);
        }

    }
    protected void gvFileUpload_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandArgument != "")
        {
            int attributeID = Convert.ToInt32(e.CommandArgument);
            if (checkUserExist(attributeID, 1, Convert.ToInt32(Session["UserID"])))
                DeleteAttributeData(attributeID);
            else
                ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('You do not have rights to delete this file.')</script>", false);
        }
    }
    private Boolean checkUserExist(int fileID, int createdBy, int currentUserID)
    {
        using (SqlConnection con = new SqlConnection(eBookConn))
        {
            con.Open();
            using (SqlCommand sqlCom = new SqlCommand())
            {
                sqlCom.CommandType = CommandType.Text;
                sqlCom.Connection = con;
                sqlCom.CommandText = "Select uploadByID From FilesTable where fileID = " + fileID;

                using (SqlDataReader sqlReader = sqlCom.ExecuteReader())
                {
                    while (sqlReader.Read())
                    {
                        if ((sqlReader["uploadByID"].Equals(currentUserID)) || (Session["userProfileID"].Equals("1")))
                            return true;
                    }
                }
            }
        }
        return false;
    }
    public void DeleteAttributeData(int attrID)
    {
        SqlConnection con = null;
        try
        {
            using (con = new SqlConnection(eBookConn))
            {
                con.Open();
                using (SqlCommand cmd = new SqlCommand("Update FilesTable Set isFileActive = 0,updateUser = @updateUser,updateDate = @updateDate where fileID = " + attrID, con))
                {
                    cmd.Parameters.AddWithValue("@updateUser", Session["Username"].ToString());
                    cmd.Parameters.AddWithValue("@updateDate", System.DateTime.Now);
                    cmd.ExecuteNonQuery();
                }
            }
        }
        catch (Exception ex)
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Error occurred while deleting the file records')</script>", false);
        }
        finally
        {
            con.Close();
        }
    }
    protected void txtEOICollectionDate_TextChanged(object sender, EventArgs e)
    {
        if (txtEOICollectionDate.Text.Trim() != "")
        {
            txtEOICollectionDate.Text = Convert.ToDateTime(getWorkingDate(txtEOICollectionDate.Text)).ToString("dd/MMM/yyyy");
        }
    }
    
    protected void lnkLogOutBtn_Click(object sender, EventArgs e)
    {
        // Added by Varun on 01/Dec/2019
        Session["UserName"] = null;
        Response.Redirect("~/LoginPage.aspx", false);
    }
    protected void imgHome_Click(object sender, ImageClickEventArgs e)
    {
        Response.Redirect("~/GIS/SearchGISData.aspx", false);
    }
    protected void btnEOISearch_click(object sender, EventArgs e)
    {
        Session["UrlRef"] = Request.Url.AbsoluteUri;
        Response.Redirect("~/TSS/SearchEOIInfo.aspx", false);
    }
    private string getWorkingDate(string strDate)
    {
        SqlConnection con = new SqlConnection(eBookConn);
        SqlCommand cmd = new SqlCommand();
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Connection = con;

        cmd.CommandText = "GetFirstWorkingday";
        SqlParameter prm = cmd.Parameters.Add("@ad_startDate", SqlDbType.DateTime);
        prm.Value = strDate;
        //prm = cmd.Parameters.Add("@actual_work  Days", SqlDbType.Int);
        //prm.Value = Convert.ToInt32(_days);
        prm = cmd.Parameters.Add("@workingDate", SqlDbType.DateTime);
        prm.Direction = ParameterDirection.Output;
        con.Open();
        SqlDataReader dr = cmd.ExecuteReader();
        while (dr.Read())
            Console.WriteLine(dr.GetString(0));
        con.Dispose();
        con.Close();

        return cmd.Parameters[1].Value.ToString();
    }
    protected void btnSave_Click(object sender, EventArgs e)
    {
        SqlConnection sqlConn = null;

        try
        {
            using (sqlConn = new SqlConnection(eBookConn))
            {
                sqlConn.Open();
                SqlCommand sqlComm = null;
                using (sqlComm = new SqlCommand())
                {
                    
                        //sqlDtReader.Close();
                        sqlComm = new SqlCommand();
                        sqlComm.Connection = sqlConn;
                        sqlComm.CommandType = CommandType.StoredProcedure;
                        sqlComm.CommandText = "EOIAddVendor";
                        if (btnSave.Text == "Save")
                        {                            
                            sqlComm.Parameters.AddWithValue("@isInsert", 1);
                            sqlComm.Parameters.AddWithValue("@projectTitle", txtProjTitle.Text);
                            if (ddlCompany.SelectedValue != "")
                            {
                                sqlComm.Parameters.AddWithValue("@companyID", ddlCompany.SelectedValue);
                            }
                        }
                        else
                        {
                            sqlComm.Parameters.AddWithValue("@isInsert", 0);
                            sqlComm.Parameters.AddWithValue("@projectTitle", DBNull.Value);
                            sqlComm.Parameters.AddWithValue("@companyID", ddlCompany.SelectedValue);
                        }
                        //sqlComm.Parameters.AddWithValue("@projId", HttpUtility.HtmlDecode(Request.QueryString["projectID"].ToString()));
                        //sqlComm.Parameters.AddWithValue("@projId", DBNull.Value);
                        sqlComm.Parameters.AddWithValue("@jobID", Session["JobID"].ToString());

                        if (txtEOICollectionDate.Text != "")
                        {
                            sqlComm.Parameters.AddWithValue("@eoiCollectionDate", Convert.ToDateTime(txtEOICollectionDate.Text + " " + DateTime.Now.TimeOfDay)); //strDate = Convert.ToDateTime(strDate).ToString("MM/dd/yyyy", CultureInfo.InvariantCulture);                        
                        }
                        else
                        {
                            sqlComm.Parameters.AddWithValue("@eoiCollectionDate", DBNull.Value);
                        }                        
                         
                        if (txtCompanyAddress.Text.Trim() != "")
                        {
                            sqlComm.Parameters.AddWithValue("@cmpAddress", txtCompanyAddress.Text.Trim());
                        }
                        else
                        {
                            sqlComm.Parameters.AddWithValue("@cmpAddress", DBNull.Value);
                        }
                        if (txtCompanyTelephoneNo.Text.Trim() != "")
                        {
                            sqlComm.Parameters.AddWithValue("@cmpTelNo", txtCompanyTelephoneNo.Text.Trim());
                        }
                        else
                        {
                            sqlComm.Parameters.AddWithValue("@cmpTelNo", DBNull.Value);
                        }
                        if (txtFaxNo.Text.Trim() != "")
                        {
                            sqlComm.Parameters.AddWithValue("@cmpFaxNo", txtFaxNo.Text.Trim());
                        }
                        else
                        {
                            sqlComm.Parameters.AddWithValue("@cmpFaxNo", DBNull.Value);
                        }
                        if (txtNationality.Text.Trim() != "")
                        {
                            sqlComm.Parameters.AddWithValue("@cmpNationality", txtNationality.Text.Trim());
                        }
                        else
                        {
                            sqlComm.Parameters.AddWithValue("@cmpNationality", DBNull.Value);
                        }
                        if (txtCmpEmailID.Text.Trim() != "")
                        {
                            sqlComm.Parameters.AddWithValue("@cmpEmailID", txtCmpEmailID.Text.Trim());
                        }
                        else
                        {
                            sqlComm.Parameters.AddWithValue("@cmpEmailID", DBNull.Value);
                        }
                        if (txtCRNo.Text.Trim() != "")
                        {
                            sqlComm.Parameters.AddWithValue("@cmpCRNo", txtCRNo.Text.Trim());
                        }
                        else
                        {
                            sqlComm.Parameters.AddWithValue("@cmpCRNo", DBNull.Value);
                        }
                        if (txtQatariShare.Text.Trim() != "")
                        {
                            sqlComm.Parameters.AddWithValue("@cmpQatariShare", txtQatariShare.Text.Trim());
                        }
                        else
                        {
                            sqlComm.Parameters.AddWithValue("@cmpQatariShare", DBNull.Value);
                        }
                        if (txtCRExpDate.Text.Trim() != "")
                        {
                            sqlComm.Parameters.AddWithValue("@cmpCRExpDate", Convert.ToDateTime(txtCRExpDate.Text.Trim() + " " + DateTime.Now.TimeOfDay));
                        }
                        else
                        {
                            sqlComm.Parameters.AddWithValue("@cmpCRExpDate", DBNull.Value);
                        }
                        if (txtRemarks.Text != "")
                        {
                            sqlComm.Parameters.AddWithValue("@remarks", Server.HtmlDecode(txtRemarks.Text));
                        }
                        else
                        {
                            sqlComm.Parameters.AddWithValue("@remarks", DBNull.Value);
                        }                         
                        sqlComm.ExecuteNonQuery();
                    //}
                    //if (btnSave.Text == "Save")
                    //{
                        btnSave.Text = "Update";
                    //}
                    //LoadEOIStages();
                }
            }
        }
        catch (Exception ex)
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Error occurred while inserting or updating the vendor information in the database')</script>", false);
        }
        finally
        {
            sqlConn.Close();
        }
    }
    protected void btnSearchTSS_click(object sender, EventArgs e)
    {
        Session["UrlRef"] = Request.Url.AbsoluteUri;
        Response.Redirect("~/TSS/SearchTSSJobs.aspx", false);
    }
    protected void btnCRUpload_Click(object sender, EventArgs e)
    {
        UploadFiles("CR");
    }

    private void UploadFiles(string docFileName)
    {
        if (ddlCompany.SelectedValue != "")
        {
            FileUpload fileUploadObj = null;
            if (docFileName == "CR")
            {
                fileUploadObj = crFileUploads;
                UploadDiffTypeFiles(fileUploadObj, docFileName, null, null);
            }
            else if (docFileName == "SD")
            {
                fileUploadObj = sdFileUploads;
                UploadDiffTypeFiles(fileUploadObj, docFileName, null, null);
            }

            BindGridviewData(docFileName);
        }
        else
        {
            string script = "<script type=\"text/javascript\">alert('Company cannot be left blank');</script>";
            ClientScript.RegisterClientScriptBlock(this.GetType(), "myscript", script);
        }
    }

    private void UploadDiffTypeFiles(FileUpload fileUploadObj, string docFileName, DataTable dtCRFiles, string filename)
    {
        try
        {        
            string prefixfileName = null;
            // Path.GetFileName(fileUploads.PostedFile.FileName);
            SqlConnection sqlCon = null;
            //fileUploads.SaveAs(Server.MapPath("Files/" + filename));
            string filePath = null;
            if (fileUploadObj != null)
            {

                if (fileUploadObj.HasFile)
                {
                    try
                    {
                        //HttpPostedFileBase[] filebase = null;
                        //filePath = Path.Combine(filePath, Session["ReqID"] + "_" + filename);
                        //if (System.Web.HttpContext.Current.Request.Files.AllKeys.Any())
                        //{
                        //filePath = Server.MapPath(ConfigurationManager.AppSettings["TSSFolderPath"].ToString() + Session["JobNo"]);
                        filePath = ConfigurationManager.AppSettings["TSSFolderPath"].ToString() + "\\" + Session["JobNo"];
                        if (!Directory.Exists(filePath))
                        {
                            Directory.CreateDirectory(filePath);
                        }

                        //filebase = new HttpPostedFileBase[fileUploads.PostedFiles.Count];
                        foreach (HttpPostedFile uploadedFile in fileUploadObj.PostedFiles)
                        {
                            filename = Path.GetFileName(uploadedFile.FileName);
                        
                            using (sqlCon = new SqlConnection(eBookConn))
                            {
                                sqlCon.Open();
                                SqlCommand cmd1 = new SqlCommand("select * from FilesTable where jobID=@jobID and filename=@filename and sectionID=@sectionID and companyID=@companyID and docFileName like '" + docFileName + "_%'");
                                cmd1.Connection = sqlCon;
                                cmd1.Parameters.AddWithValue("@filename", filename);
                                //cmd2.Parameters.AddWithValue("@docFileName", prefixfileName);
                                cmd1.Parameters.AddWithValue("@jobID", Session["JobID"].ToString());
                                //cmd2.Parameters.AddWithValue("@isFileActive", 1);
                                //cmd2.Parameters.AddWithValue("@Path", filePath);
                                cmd1.Parameters.AddWithValue("@sectionID", Session["SectionID"]);
                                cmd1.Parameters.AddWithValue("@companyID", ddlCompany.SelectedValue);
                                SqlDataReader sqlDtReader = cmd1.ExecuteReader();
                                if (!sqlDtReader.HasRows)
                                {
                                    sqlDtReader.Close();
                                    string newFilePath = filePath + "\\" + filename;
                                    //filebase[idxCounter] = new HttpPostedFileWrapper(uploadedFile);
                                    uploadedFile.SaveAs(newFilePath);
                                    prefixfileName = docFileName + "_" + filename;
                                    using (SqlCommand cmd2 = new SqlCommand("Insert into FilesTable(fileName,docFileName,jobID,isFileActive,filePath,sectionID,companyID,uploadByID,createUser,createDate,fileType) values(@Name,@docFileName,@jobID,@isFileActive,@Path,@sectionID,@companyID,@uploadByID,@createUser,@createDate,@fileType)", sqlCon))
                                    {
                                        cmd2.Parameters.AddWithValue("@Name", filename);
                                        cmd2.Parameters.AddWithValue("@fileType", 'A');
                                        cmd2.Parameters.AddWithValue("@docFileName", prefixfileName);
                                        cmd2.Parameters.AddWithValue("@jobID", Session["JobID"].ToString());
                                        cmd2.Parameters.AddWithValue("@isFileActive", 1);
                                        cmd2.Parameters.AddWithValue("@Path", newFilePath);
                                        cmd2.Parameters.AddWithValue("@sectionID", Session["SectionID"]);
                                        cmd2.Parameters.AddWithValue("@companyID", ddlCompany.SelectedValue);
                                        cmd2.Parameters.AddWithValue("@uploadByID", Session["UserID"]); //541==EOIAdmin
                                        cmd2.Parameters.AddWithValue("@createUser", Session["UserName"]);
                                        cmd2.Parameters.AddWithValue("@createDate", System.DateTime.Now);
                                        cmd2.ExecuteNonQuery();
                                    }
                                }
                                //else
                                //{
                                //    sqlDtReader.Close();
                                //    using (SqlCommand cmd2 = new SqlCommand("Update FilesTable set isFileActive=1,uploadByID=@uploadByID,updateDate=@updateDate,updateUser=@updateUser where jobID=@jobID and sectionID=@sectionID", sqlCon))
                                //    {
                                //        cmd2.Parameters.AddWithValue("@jobID", Session["JobID"].ToString());
                                //        cmd2.Parameters.AddWithValue("@sectionID", Session["SectionID"]);
                                //        cmd2.Parameters.AddWithValue("@uploadByID", Session["UserID"]);
                                //        cmd2.Parameters.AddWithValue("@updateDate", System.DateTime.Now);
                                //        cmd2.Parameters.AddWithValue("@updateUser", Session["UserName"]);
                                //        cmd2.ExecuteNonQuery();
                                //    }
                                //}

                            }
                        }

                    }
                    catch (Exception ex)
                    {
                        //Response.Write(ex.Message);
                        string script = "<script type=\"text/javascript\">alert('" + ex.Message.Replace("'", "") + "'); </script>";
                        ClientScript.RegisterClientScriptBlock(this.GetType(), "myscript", script);
                        return;
                    }
                    finally
                    {
                        sqlCon.Close();
                    }
                }
                else
                {
                    ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Please select file to upload.')</script>", false);
                    return;
                }
            }
            else
            {
                filePath = ConfigurationManager.AppSettings["TSSFolderPath"].ToString() + "\\" + Session["JobNo"];
                if (!Directory.Exists(filePath))
                {
                    Directory.CreateDirectory(filePath);
                }

                Int16 rowCounter = 0;
                while (rowCounter<dtCRFiles.Rows.Count)
                {
                    using (sqlCon = new SqlConnection(eBookConn))
                    {
                        sqlCon.Open();
                        SqlCommand cmd1 = new SqlCommand("select * from FilesTable where jobID=@jobID and filename=@filename and sectionID=@sectionID and companyID=@companyID and docFileName like '" + docFileName + "_%'");
                        cmd1.Connection = sqlCon;
                        cmd1.Parameters.AddWithValue("@filename", filename);
                        //cmd2.Parameters.AddWithValue("@docFileName", prefixfileName);
                        cmd1.Parameters.AddWithValue("@jobID", Session["JobID"].ToString());
                        //cmd2.Parameters.AddWithValue("@isFileActive", 1);
                        //cmd2.Parameters.AddWithValue("@Path", filePath);
                        cmd1.Parameters.AddWithValue("@sectionID", Session["SectionID"]);
                        cmd1.Parameters.AddWithValue("@companyID", ddlCompany.SelectedValue);
                        SqlDataReader sqlDtReader = cmd1.ExecuteReader();
                        if (!sqlDtReader.HasRows)
                        {
                            sqlDtReader.Close();
                            string newFilePath = filePath + "\\" + filename;
                            //filebase[idxCounter] = new HttpPostedFileWrapper(uploadedFile);
                            //FileInfo fInfo = new FileInfo(filename);
                            //DirectoryInfo di = new DirectoryInfo(newFilePath);
                            var fs = new FileStream(newFilePath, FileMode.Create, FileAccess.Write);
                            byte[] img = (byte[])dtCRFiles.Rows[rowCounter][2];
                            //MemoryStream ms = new MemoryStream(img);
                            fs.Write(img, 0, img.Length);
                            //ms.WriteTo(fs);
                            fs.Close();
                            //ms.Close();
                            //ms = new MemoryStream(photo);
                            //fs.Write(img, 0, img.Length);
                            //FileInfo.Save(newFilePath);
                            prefixfileName = docFileName + "_" + filename;
                            using (SqlCommand cmd2 = new SqlCommand("Insert into FilesTable(fileName,docFileName,jobID,isFileActive,filePath,sectionID,companyID,uploadByID,createUser,createDate,fileType) values(@Name,@docFileName,@jobID,@isFileActive,@Path,@sectionID,@companyID,@uploadByID,@createUser,@createDate,@fileType)", sqlCon))
                            {
                                cmd2.Parameters.AddWithValue("@Name", filename);
                                cmd2.Parameters.AddWithValue("@fileType", 'A');
                                cmd2.Parameters.AddWithValue("@docFileName", prefixfileName);
                                cmd2.Parameters.AddWithValue("@jobID", Session["JobID"].ToString());
                                cmd2.Parameters.AddWithValue("@isFileActive", 1);
                                cmd2.Parameters.AddWithValue("@Path", newFilePath);
                                cmd2.Parameters.AddWithValue("@sectionID", Session["SectionID"]);
                                cmd2.Parameters.AddWithValue("@companyID", ddlCompany.SelectedValue);
                                cmd2.Parameters.AddWithValue("@uploadByID", Session["UserID"]); //541==EOIAdmin
                                cmd2.Parameters.AddWithValue("@createUser", Session["UserName"]);
                                cmd2.Parameters.AddWithValue("@createDate", System.DateTime.Now);
                                cmd2.ExecuteNonQuery();
                            }
                        }
                        //else
                        //{
                        //    sqlDtReader.Close();
                        //    using (SqlCommand cmd2 = new SqlCommand("Update FilesTable set isFileActive=1,uploadByID=@uploadByID,updateDate=@updateDate,updateUser=@updateUser where jobID=@jobID and sectionID=@sectionID", sqlCon))
                        //    {
                        //        cmd2.Parameters.AddWithValue("@jobID", Session["JobID"].ToString());
                        //        cmd2.Parameters.AddWithValue("@sectionID", Session["SectionID"]);
                        //        cmd2.Parameters.AddWithValue("@uploadByID", Session["UserID"]);
                        //        cmd2.Parameters.AddWithValue("@updateDate", System.DateTime.Now);
                        //        cmd2.Parameters.AddWithValue("@updateUser", Session["UserName"]);
                        //        cmd2.ExecuteNonQuery();
                        //    }
                        //}

                    }
                    rowCounter++;
                }            

            }
        }
        catch (Exception)
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Error occurred while uploading the files.')</script>", false);            
        }
    }

    //DataTable dt = 
    private void BindGridviewData(string docFileName)
    {
        DataSet ds = new DataSet();
        gvCrFilesUpload.DataSource = null;
        gvCrFilesUpload.DataBind();
        string sqlQuery = null;

        if (docFileName == "All")
        {
            sqlQuery = "select fileID, FileName,docFileName, FilePath,createUser,REPLACE(CONVERT(NVARCHAR, createDate, 106), ' ', '-') AS createDate from FilesTable where isFileActive = 1 and jobID=" + Session["JobID"].ToString() + " and companyID=" + ddlCompany.SelectedValue + " and docFileName like 'CR_%'";
            //sqlQuery2 = "select fileID, FileName,docFileName, FilePath,createUser,REPLACE(CONVERT(NVARCHAR, createDate, 106), ' ', '-') AS createDate from FilesTable where isFileActive = 1 and jobID=" + Session["JobID"].ToString() + " and companyID=" + ddlCompany.SelectedValue + " and docFileName like '" + docFileName + "_%'"; //541=="EOIAdmin"
        }
        else
        {                           
            sqlQuery = "select fileID, FileName,docFileName, FilePath,createUser,REPLACE(CONVERT(NVARCHAR, createDate, 106), ' ', '-') AS createDate from FilesTable where isFileActive = 1 and jobID=" + Session["JobID"].ToString() + " and companyID=" + ddlCompany.SelectedValue + " and docFileName like '" + docFileName + "_%'"; //541=="EOIAdmin"          
        }
        try
        {
            SqlConnection con = new SqlConnection(eBookConn);
            con.Open();
            SqlCommand cmd = null;
            cmd = new SqlCommand(sqlQuery, con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(ds);
            DataTable dt = ds.Tables[0];
            if (docFileName != "All")
            {
                if (docFileName == "CR")
                {
                    Session["crDs"] = dt;
                    gvCrFilesUpload.DataSource = dt;
                    gvCrFilesUpload.DataBind();
                    gvSdFilesUpload.DataSource = (DataTable)Session["sdDs"];
                    gvSdFilesUpload.DataBind();
                }
                else
                {
                    Session["sdDs"] = dt;
                    gvSdFilesUpload.DataSource = dt;
                    gvSdFilesUpload.DataBind();
                    gvCrFilesUpload.DataSource = (DataTable)Session["crDs"];
                    gvCrFilesUpload.DataBind();
                }
            }
            else
            {
                Session["crDs"] = null;
                dt = ds.Tables[0];
                gvCrFilesUpload.DataSource = dt;
                gvCrFilesUpload.DataBind();
                Session["crDs"] = dt; // gvCrFilesUpload.DataSource;
                sqlQuery = "select fileID, FileName,docFileName, FilePath,createUser,REPLACE(CONVERT(NVARCHAR, createDate, 106), ' ', '-') AS createDate from FilesTable where isFileActive = 1 and jobID=" + Session["JobID"].ToString() + " and companyID=" + ddlCompany.SelectedValue + " and docFileName like 'SD_%'";
                cmd = new SqlCommand(sqlQuery, con);
                da = new SqlDataAdapter(cmd);
                ds = new DataSet();
                //if (ds.Tables.Count != 0)
                //{
                //    ds.Tables[0].Rows.Clear();
                //}
                da.Fill(ds);
                Session["sdDs"] = null;
                dt = ds.Tables[0];
                gvSdFilesUpload.DataSource = dt;
                gvSdFilesUpload.DataBind();
                Session["sdDs"] = dt;

            }
            con.Close();
            if (!Session["UserID"].Equals("541"))
            {
                if (gvCrFilesUpload.Columns.Count != 0)
                {
                    gvCrFilesUpload.Columns[5].Visible = false;
                }

                if (gvSdFilesUpload.Columns.Count != 0)
                {
                    gvSdFilesUpload.Columns[5].Visible = false;
                }
            }
        }
        catch (Exception)
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Error occurred while filling the CR or Submission Documents of the company')</script>", false);
        }        
    }
    protected void ddlCompany_SelectedIndexChanged(object sender, EventArgs e)
    {
        //txtCompanyAddress
        //txtCompanyTelephoneNo
        SqlConnection sqlCon = null;
        try
        {
            using (sqlCon = new SqlConnection(eBookConn))
            {
                sqlCon.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = sqlCon;
                cmd.CommandText = "select cmpAddress,cmpTelNo,cmpFaxNo,cmpEmailID,cmpNationality,cmpQatariShare,cmpCRExpDate,cmpCRNo,remarks from EOIVendors where companyID=@companyID and jobID=@jobID";
                cmd.Parameters.AddWithValue("@companyID", ddlCompany.SelectedValue);
                cmd.Parameters.AddWithValue("@jobID", Session["JobID"]);
                SqlDataReader sqlDtReader = cmd.ExecuteReader();
                if (sqlDtReader.HasRows)
                {
                    ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('For the Job No. " + Session["JobNo"].ToString() + ". Already the Company exists.')</script>", false);
                    btnSave.Text = "Update";
                    sqlDtReader.Read();
                    txtCompanyAddress.Text = sqlDtReader[0].ToString();
                    txtCompanyTelephoneNo.Text = sqlDtReader[1].ToString();
                    txtFaxNo.Text = sqlDtReader[2].ToString();
                    txtCmpEmailID.Text = sqlDtReader[3].ToString();
                    txtNationality.Text = sqlDtReader[4].ToString();
                    txtQatariShare.Text = sqlDtReader[5].ToString();
                    string crExpDate = sqlDtReader[6].ToString().Trim();
                    if (crExpDate != "")
                    {
                        txtCRExpDate.Text = Convert.ToDateTime(crExpDate).ToString("dd/MMM/yyyy");
                    }
                    txtCRNo.Text = sqlDtReader[7].ToString();
                    txtRemarks.Text = sqlDtReader[8].ToString();
                    //txtCompanyAddress.Text = sqlDtReader[0].ToString();
                    //txtCompanyTelephoneNo.Text = sqlDtReader[1].ToString();
                    //txtFaxNo.Text = sqlDtReader[2].ToString();
                    //txtCmpEmailID.Text = sqlDtReader[3].ToString();
                    //txtNationality.Text = sqlDtReader[4].ToString();
                    //txtQatariShare.Text = sqlDtReader[5].ToString();
                    //txtCRExpDate.Text = Convert.ToDateTime(sqlDtReader[6].ToString()).ToString("dd/MMM/yyyy");
                    //txtCRNo.Text = sqlDtReader[7].ToString();                                 
                }
                else
                {
                    btnSave.Text = "Save";
                }

                sqlDtReader.Close();
            }
        }
        catch (Exception)
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Error occurred while retrieving the information of the company')</script>", false);             
        }
        
        
        if (btnSave.Text == "Save")
        {
            //cmd = new SqlCommand("select address1,address2,address3,telephone,fax,emailAddress,nationality,qatariShare,crNo,crExpiryDate from Company where companyID=@companyID"); // and uploadByID=@uploadByID and filename=@filename and sectionID=@sectionID");
            using (sqlCon = new SqlConnection(tcmsConn))
            {
                //sqlCon.Open();
                //SqlCommand cmd = new SqlCommand("select cmp.co_address,cmp.co_tel,cmp.co_fax,cmp.co_email_address,cmp.nationality,cmp.qatari_share,cmp.cr_expiry_date,cmp.CRNo,crAtt.crAttFile,crAtt.crAttFileName from Company cmp join CRAttachment crAtt on Company.co_id=CRAttachment.co_id where co_id=@companyID");
                //cmd.Connection = sqlCon;
                //cmd.Parameters.AddWithValue("@companyID", ddlCompany.SelectedValue);
                //SqlDataReader sqlDtReader = cmd.ExecuteReader();
                DAL dal = new DAL(System.Configuration.ConfigurationManager.ConnectionStrings["TCMSConn"].ConnectionString);
                DataTable dtCmp = null;
                
                dtCmp = dal.GetDataFromDB("CompanyInfo", "select cmp.co_address,cmp.co_tel,cmp.co_fax,cmp.co_email_address,cmp.nationality,cmp.qatari_share,cmp.cr_expiry_date,cmp.CRNo,crAtt.crAttFile,crAtt.crAttFileName from Company cmp join CRAttachment crAtt on cmp.co_id=crAtt.co_id where cmp.co_id=" + ddlCompany.SelectedValue);
                if(dtCmp==null)
                {
                    ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Error occurred while retrieving the information of the company')</script>", false);
                }
                else if(dtCmp.Rows.Count!=0)
                {
                    txtCompanyAddress.Text = dtCmp.Rows[0][0].ToString(); //+ " " + sqlDtReader[1].ToString() + " " + sqlDtReader[2].ToString()).Trim()
                    txtCompanyTelephoneNo.Text = dtCmp.Rows[0][1].ToString();
                    txtFaxNo.Text = dtCmp.Rows[0][2].ToString();
                    txtCmpEmailID.Text = dtCmp.Rows[0][3].ToString();
                    txtNationality.Text = dtCmp.Rows[0][4].ToString();
                    txtQatariShare.Text = dtCmp.Rows[0][5].ToString();
                    string crExpDate = dtCmp.Rows[0][6].ToString().Trim();
                    if (crExpDate != "")
                    {
                        txtCRExpDate.Text = Convert.ToDateTime(crExpDate).ToString("dd/MMM/yyyy");
                    }
                    txtCRNo.Text = dtCmp.Rows[0][7].ToString();
                    DataTable dtCRFiles = new DataTable();
                    dtCRFiles.Columns.Add("fileId");
                    dtCRFiles.Columns.Add("FileName");
                    DataColumn dc = new DataColumn("FileBytes", System.Type.GetType("System.Byte[]"));
                    dtCRFiles.Columns.Add(dc);
                    dtCRFiles.Columns.Add("docFileName");
                    dtCRFiles.Columns.Add("FilePath");
                    dtCRFiles.Columns.Add("createUser");
                    dtCRFiles.Columns.Add("createDate");
                    dtCRFiles.AcceptChanges();
                    Int16 rowCounter = 0;
                    Int16 sNo = 1;
                    while (rowCounter < dtCmp.Rows.Count)
                    {
                        DataRow dr = dtCRFiles.NewRow();
                        dr[0] = sNo++;
                        dr[1] = dtCmp.Rows[rowCounter][9];
                        dr[2] = dtCmp.Rows[rowCounter][8];
                        dr[3] = "CR_" + dtCmp.Rows[rowCounter][9];
                        dr[4] = ConfigurationManager.AppSettings["TSSFolderPath"].ToString() + "\\" + Session["JobNo"] + "\\" + dtCmp.Rows[rowCounter][9];
                        dr[5] = Session["UserName"];
                        dr[6] = DateTime.Now.ToString();
                        dtCRFiles.Rows.Add(dr);
                        rowCounter++;
                    }
                    //dt = ds.Tables[0];
                    gvCrFilesUpload.DataSource = dtCRFiles;
                    gvCrFilesUpload.DataBind();
                    Session["crDs"] = dtCRFiles;
                    rowCounter = 0;
                    while (rowCounter < dtCmp.Rows.Count)
                    {
                        UploadDiffTypeFiles(null, "CR", dtCRFiles, dtCmp.Rows[rowCounter][9].ToString());
                        rowCounter++;
                    }
                }

                //if (sqlDtReader.HasRows)
                //{
                //    sqlDtReader.Read();
                
                    //txtCompanyAddress.Text = (sqlDtReader[0].ToString(); //+ " " + sqlDtReader[1].ToString() + " " + sqlDtReader[2].ToString()).Trim()
                    //txtCompanyTelephoneNo.Text = sqlDtReader[3].ToString();
                    //txtFaxNo.Text = sqlDtReader[4].ToString();
                    //txtCmpEmailID.Text = sqlDtReader[5].ToString();
                    //txtNationality.Text = sqlDtReader[6].ToString();
                    //txtQatariShare.Text = sqlDtReader[7].ToString();
                    //string crExpDate = sqlDtReader[9].ToString().Trim();
                    //if (crExpDate != "")
                    //{
                    //    txtCRExpDate.Text = Convert.ToDateTime(sqlDtReader[9].ToString()).ToString("dd/MMM/yyyy");
                    //}
                    //txtCRNo.Text = sqlDtReader[8].ToString();
                    //txtCompanyAddress.Text = sqlDtReader[0].ToString();
                    //txtCompanyTelephoneNo.Text = sqlDtReader[1].ToString();
                    //txtFaxNo.Text = sqlDtReader[2].ToString();
                    //txtCmpEmailID.Text = sqlDtReader[3].ToString();
                    //txtNationality.Text = sqlDtReader[4].ToString();
                    //txtQatariShare.Text = sqlDtReader[5].ToString();
                    //txtCRExpDate.Text = Convert.ToDateTime(sqlDtReader[6].ToString()).ToString("dd/MMM/yyyy");
                    //txtCRNo.Text = sqlDtReader[7].ToString();
                    //sqlDtReader.Close();
                    //using (SqlCommand cmd2 = new SqlCommand("select into FilesTable(fileName,docFileName,jobID,isFileActive,filePath,sectionID,companyID,uploadByID,createUser,createDate,fileType) values(@Name,@docFileName,@jobID,@isFileActive,@Path,@sectionID,@companyID,@uploadByID,@createUser,@createDate,@fileType)", sqlCon))
                    //{
                    //    cmd2.Parameters.AddWithValue("@Name", filename);
                    //    cmd2.Parameters.AddWithValue("@fileType", 'A');
                    //    cmd2.Parameters.AddWithValue("@docFileName", prefixfileName);
                    //    cmd2.Parameters.AddWithValue("@jobID", Session["JobID"].ToString());
                    //    cmd2.Parameters.AddWithValue("@isFileActive", 1);
                    //    cmd2.Parameters.AddWithValue("@Path", newFilePath);
                    //    cmd2.Parameters.AddWithValue("@sectionID", Session["SectionID"]);
                    //    cmd2.Parameters.AddWithValue("@companyID", ddlCompany.SelectedValue);
                    //    cmd2.Parameters.AddWithValue("@uploadByID", Session["UserID"]); //541==EOIAdmin
                    //    cmd2.Parameters.AddWithValue("@createUser", Session["UserName"]);
                    //    cmd2.Parameters.AddWithValue("@createDate", System.DateTime.Now);
                    //    cmd2.ExecuteNonQuery();
                    //}
                //}
                //sqlDtReader.Close();
            }
        }
        BindGridviewData("All");
        
    }
    protected void btnBack_Click(object sender, EventArgs e)
    {
        if (Session["UserName"] == null)
        {
            Response.Redirect("~/LoginPage.aspx", false);
            return;
        }
        Response.Redirect(Session["UrlRef"].ToString());
    }
    protected void btnSDUpload_Click(object sender, EventArgs e)
    {
        UploadFiles("SD");
    }

    protected void btnViewVendors_click(object sender, EventArgs e)
    {
        Session["UrlRef"] = Request.Url.AbsoluteUri;
        Response.Redirect("~/TSS/ViewAndUpdateVendors.aspx", false);
    }
}