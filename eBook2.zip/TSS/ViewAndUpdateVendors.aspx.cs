﻿using Datalayer;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class TSS_ViewAndUpdateVendors : System.Web.UI.Page
{    
    string eBookConn = System.Configuration.ConfigurationManager.ConnectionStrings["EBSDEBookConn"].ConnectionString;
    IList<string> userRightsColl = new List<string>();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["UserName"] == null)
        {
            Response.Redirect("~/LoginPage.aspx", false);
            return;
        }

        if (!IsPostBack)
        {
            userRightsColl = (IList<string>)Session["UserRightsColl"];
            lblUser.Text = Session["UserDisplayName"].ToString();
            lblUserProfile.Text = Session["ProfileName"].ToString();       
            viewVendors.InnerText =  "VIEW Or UPDATE VENDORS DETAILS | EOI Number:-" + Session["EOINumber"] + " | Job No.:-" + Session["JobNo"];             

            try
            {
                PopulateDropDownBox(ddlCompany, "SELECT co_ID,co_Name FROM TCMS_Company where co_Name not like '%PWA%' ORDER BY co_Name", "co_ID", "co_Name", "");
                //BindGridviewData();
                //gvViewVendors
                FillVendors();
                ShowOrHideUploadedFiles(false);
                //FillUploadedCmpCRFiles();
            }
            catch (Exception)
            {
                ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Error occurred while retrieving the information of uploaded files')</script>", false);
            }
        }
        //"select eoiCollectionDate,companyID,cmpAddress,cmpTelNo,cmpFaxNo,cmpNationality,cmpEmailID,cmpCRNo,cmpQatariShare,cmpCRExpDate,remarks from EOIVendors join Company on EOIVendors.companyID=Company.companyID" 
    }

    private void ShowOrHideUploadedFiles(bool isVisible)
    {        
        uploadedCommRegCrDoc.Visible = isVisible;
        gvEoiDocsFileUpload.Visible = isVisible;
    }
    private void FillVendors()
    {
        DataSet ds = new DataSet();
        gvViewVendors.DataSource = null;
        gvViewVendors.DataBind();
        string sqlfileType = null;
        sqlfileType = "select Replace(Convert(nvarchar,eoiVen.eoiCollectionDate,106),' ','/') As eoiCollectionDate,cmp.co_ID,cmp.co_Name,eoiVen.cmpAddress,eoiVen.cmpTelNo,eoiVen.cmpFaxNo,eoiVen.cmpNationality,eoiVen.cmpEmailID," +
        "eoiVen.cmpCRNo,eoiVen.cmpQatariShare,Replace(Convert(nvarchar,eoiVen.cmpCRExpDate,106),' ','/') As cmpCRExpDate,eoiVen.remarks,eoiVen.cmpResponded,eoiVen.vendorID from EOIVendors eoiVen join TCMS_Company cmp on eoiVen.companyID=cmp.co_ID where eoiVen.jobID=" + Session["JobID"].ToString();
        SqlConnection con = new SqlConnection(eBookConn);
        con.Open();
        SqlCommand cmd = new SqlCommand(sqlfileType, con);
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        da.Fill(ds);
        con.Close();
        gvViewVendors.DataSource = ds;
        gvViewVendors.DataBind();         
    }   
    private void PopulateDropDownBox(DropDownList ddlBox, string sqlQuery, string valueMember, string displayName, string selectName)
    {
        ddlBox.DataSource = new JobOrderData().FillDropdown(sqlQuery);
        ddlBox.DataTextField = displayName;
        //if (valueMember == "cmpIDAndShortName")
        //{
        //    ddlBox.DataValueField = valueMember; //.companyID+","+valueMember.cmpShortName;
        //}
        //else
        //{
        ddlBox.DataValueField = valueMember;
        //}
        ddlBox.SelectedIndex = -1;
        ddlBox.DataBind();

        ListItem emptyItem = new ListItem(selectName, selectName);
        ddlBox.Items.Insert(0, emptyItem);
    }
    protected void txtEOICollectionDate_TextChanged(object sender, EventArgs e)
    {
        if (txtEOICollectionDate.Text.Trim() != "")
        {
            txtEOICollectionDate.Text = Convert.ToDateTime(getWorkingDate(txtEOICollectionDate.Text)).ToString("dd/MMM/yyyy");
        }
        string cmpID = Session["CmpID"].ToString();
        if (cmpID != null)
        {
            ddlCompany.SelectedValue = cmpID;
        }
    }
    protected void lnkSDDownload_Click(object sender, EventArgs e)
    {
        //if (checkUserExist(Convert.ToInt32(fileID), 1, Convert.ToInt32(Session["UserID"])))

        LinkButton lnkbtn = sender as LinkButton;
        GridViewRow gvrow = lnkbtn.NamingContainer as GridViewRow;

        string filePath = gvSdFilesUpload.DataKeys[gvrow.RowIndex].Value.ToString();

        // Only use in case Application Server File foldes not in C Drive

        //if (Session["SectionID"].ToString().Equals("12") || Session["SectionID"].ToString().Equals("13"))
        //filePath = filePath.Replace("C:", "C:");
        //else
        //    filePath = filePath.Replace("C:", "E:");           

        //Response.TransmitFile(Server.MapPath(filePath));

        if (!File.Exists((string)filePath))
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('File not available at specific path')</script>", false);
            return;
        }
        FileInfo file = new FileInfo(filePath);
        string fileName = file.FullName;
        Response.AddHeader("Content-Disposition", "attachment;filename=\"" + fileName + "\"");
        Response.TransmitFile(fileName);
        Response.End();
    }
    protected void lnkSDDelete_Click(object sender, EventArgs e)
    {

        try
        {
            LinkButton lnkbtn = sender as LinkButton;
            GridViewRow gvrow = lnkbtn.NamingContainer as GridViewRow;
            string fileID = gvSdFilesUpload.DataKeys[gvrow.RowIndex].Values[1].ToString();

            if (!userRightsColl.Contains("26"))
            {
                if (checkUserExist(Convert.ToInt32(fileID), 1, Convert.ToInt32(Session["UserID"])))
                {
                    try
                    {
                        using (SqlConnection con = new SqlConnection(eBookConn))
                        {
                            con.Open();
                            using (SqlCommand cmd = new SqlCommand("Update FilesTable Set isFileActive = 0,updateUser = @updateUser,updateDate = @updateDate where fileID = " + fileID, con))
                            {
                                cmd.Parameters.AddWithValue("@updateUser", Session["Username"].ToString());
                                cmd.Parameters.AddWithValue("@updateDate", System.DateTime.Now);
                                cmd.ExecuteNonQuery();
                            }
                        }
                    }
                    catch (Exception ex)
                    {

                    }

                    FillGridView("SD");                     
                }

                else
                {
                    ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('You do not have rights to delete this file')</script>", false);
                }
            }
            else
            {
                ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Please contact Administrator,You do not have rights to delete this file')</script>", false);
            }
        }
        catch (Exception ex)
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Error occurred while processing the request')</script>", false);
        }

    }
    private string getWorkingDate(string strDate)
    {
        SqlConnection con = new SqlConnection(eBookConn);
        SqlCommand cmd = new SqlCommand();
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Connection = con;

        cmd.CommandText = "GetFirstWorkingday";
        SqlParameter prm = cmd.Parameters.Add("@ad_startDate", SqlDbType.DateTime);
        prm.Value = strDate;
        //prm = cmd.Parameters.Add("@actual_work  Days", SqlDbType.Int);
        //prm.Value = Convert.ToInt32(_days);
        prm = cmd.Parameters.Add("@workingDate", SqlDbType.DateTime);
        prm.Direction = ParameterDirection.Output;
        con.Open();
        SqlDataReader dr = cmd.ExecuteReader();
        while (dr.Read())
            Console.WriteLine(dr.GetString(0));
        con.Dispose();
        con.Close();

        return cmd.Parameters[1].Value.ToString();
    }
    protected void lnkLogOutBtn_Click(object sender, EventArgs e)
    {
        // Added by Varun on 01/Dec/2019
        Session["UserName"] = null;
        Response.Redirect("~/LoginPage.aspx", false);
    }
    protected void lnkDownload_Click(object sender, EventArgs e)
    {
        //if (checkUserExist(Convert.ToInt32(fileID), 1, Convert.ToInt32(Session["UserID"])))

        LinkButton lnkbtn = sender as LinkButton;
        GridViewRow gvrow = lnkbtn.NamingContainer as GridViewRow;

        string filePath = gvCrFilesUpload.DataKeys[gvrow.RowIndex].Value.ToString();

        // Only use in case Application Server File foldes not in C Drive

        //if (Session["SectionID"].ToString().Equals("12") || Session["SectionID"].ToString().Equals("13"))
        //filePath = filePath.Replace("C:", "C:");
        //else
        //    filePath = filePath.Replace("C:", "E:");           

        //Response.TransmitFile(Server.MapPath(filePath));

        if (!File.Exists((string)filePath))
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('File not available at specific path')</script>", false);
            return;
        }
        FileInfo file = new FileInfo(filePath);
        string fileName = file.FullName;
        Response.AddHeader("Content-Disposition", "attachment;filename=\"" + fileName + "\"");
        Response.TransmitFile(fileName);
        Response.End();
    }
    protected void lnkDelete_Click(object sender, EventArgs e)
    {
        try
        {
            LinkButton lnkbtn = sender as LinkButton;
            GridViewRow gvrow = lnkbtn.NamingContainer as GridViewRow;
            string fileID = gvCrFilesUpload.DataKeys[gvrow.RowIndex].Values[1].ToString();

            if (!userRightsColl.Contains("26"))
            {
                if (checkUserExist(Convert.ToInt32(fileID), 1, Convert.ToInt32(Session["UserID"])))
                {                     
                    using (SqlConnection con = new SqlConnection(eBookConn))
                    {
                        con.Open();
                        using (SqlCommand cmd = new SqlCommand("Update FilesTable Set isFileActive = 0,updateUser = @updateUser,updateDate = @updateDate where fileID = " + fileID, con))
                        {
                            cmd.Parameters.AddWithValue("@updateUser", Session["Username"].ToString());
                            cmd.Parameters.AddWithValue("@updateDate", System.DateTime.Now);
                            cmd.ExecuteNonQuery();
                        }
                    }
                    FillGridView("CR");
                }

                else
                {
                    ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('You do not have rights to delete this file')</script>", false);
                }
            }
            else
            {
                ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Please contact Administrator,You do not have rights to delete this file')</script>", false);
            }
        }
        catch (Exception ex)
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Error occurred while processing the request')</script>", false);
        }

    }
    private Boolean checkUserExist(int fileID, int createdBy, int currentUserID)
    {
        using (SqlConnection con = new SqlConnection(eBookConn))
        {
            con.Open();
            using (SqlCommand sqlCom = new SqlCommand())
            {
                sqlCom.CommandType = CommandType.Text;
                sqlCom.Connection = con;
                sqlCom.CommandText = "Select uploadByID From FilesTable where fileID = " + fileID;

                using (SqlDataReader sqlReader = sqlCom.ExecuteReader())
                {
                    while (sqlReader.Read())
                    {
                        if ((sqlReader["uploadByID"].Equals(currentUserID)) || (Session["userProfileID"].Equals("1")))
                            return true;
                    }
                }
            }
        }
        return false;
    }
    protected void imgHome_Click(object sender, ImageClickEventArgs e)
    {
        Response.Redirect("~/TSS/TSSHomePage2.aspx", false);
    }
    protected void gvFileUpload_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandArgument != "")
        {
            int attributeID = Convert.ToInt32(e.CommandArgument);
            if (checkUserExist(attributeID, 1, Convert.ToInt32(Session["UserID"])))
                DeleteAttributeData(attributeID);
            else
                ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('You do not have rights to delete this file.')</script>", false);
        }
    }
    //protected void btnUpload_Click(object sender, EventArgs e)
    //{
    //    string cmpID = Session["CmpID"].ToString();
    //    if (cmpID != null)
    //    {
    //        ddlCompany.SelectedValue = cmpID;
    //    }
    //    string prefixfileName = null;
    //    string filename = null; // Path.GetFileName(fileUploads.PostedFile.FileName);
    //    SqlConnection sqlCon = null;
    //    //fileUploads.SaveAs(Server.MapPath("Files/" + filename));
    //    string filePath = null;
    //    if (fileUploads.HasFile)
    //    {
    //        try
    //        {
    //            //HttpPostedFileBase[] filebase = null;
    //            //filePath = Path.Combine(filePath, Session["ReqID"] + "_" + filename);
    //            //if (System.Web.HttpContext.Current.Request.Files.AllKeys.Any())
    //            //{
    //            //filePath = Server.MapPath(ConfigurationManager.AppSettings["TSSFolderPath"].ToString() + Session["JobNo"]);
    //            filePath = ConfigurationManager.AppSettings["TSSFolderPath"].ToString() + "\\" + Session["JobNo"];
    //            if (!Directory.Exists(filePath))
    //            {
    //                Directory.CreateDirectory(filePath);
    //            }

    //            if (fileUploads.HasFile)
    //            {
    //                //filebase = new HttpPostedFileBase[fileUploads.PostedFiles.Count];
    //                foreach (HttpPostedFile uploadedFile in fileUploads.PostedFiles)
    //                {
    //                    filename = Path.GetFileName(uploadedFile.FileName);
    //                    string newFilePath = filePath + "\\" + filename;
    //                    //filebase[idxCounter] = new HttpPostedFileWrapper(uploadedFile);
    //                    uploadedFile.SaveAs(newFilePath);
    //                    prefixfileName = "CR" + "_" + filename;
    //                    using (sqlCon = new SqlConnection(eBookConn))
    //                    {
    //                        sqlCon.Open();
    //                        SqlCommand cmd1 = new SqlCommand("select * from FilesTable where jobID=@jobID and companyID=@companyID and uploadByID=@uploadByID and filename=@filename and sectionID=@sectionID");
    //                        cmd1.Connection = sqlCon;
    //                        cmd1.Parameters.AddWithValue("@filename", filename);
    //                        //cmd2.Parameters.AddWithValue("@docFileName", prefixfileName);
    //                        cmd1.Parameters.AddWithValue("@jobID", Session["JobID"].ToString());
    //                        cmd1.Parameters.AddWithValue("@companyID", cmpID);
    //                        //cmd2.Parameters.AddWithValue("@isFileActive", 1);
    //                        //cmd2.Parameters.AddWithValue("@Path", filePath);
    //                        cmd1.Parameters.AddWithValue("@sectionID", Session["SectionID"]);
    //                        cmd1.Parameters.AddWithValue("@uploadByID", Session["UserID"]);
    //                        SqlDataReader sqlDtReader = cmd1.ExecuteReader();
    //                        if (!sqlDtReader.HasRows)
    //                        {
    //                            sqlDtReader.Close();
    //                            using (SqlCommand cmd2 = new SqlCommand("Insert into FilesTable(fileName,docFileName,jobID,isFileActive,filePath,sectionID,companyID,uploadByID,createUser,createDate,fileType) values(@Name,@docFileName,@jobID,@isFileActive,@Path,@sectionID,@companyID,@uploadByID,@createUser,@createDate,@fileType)", sqlCon))
    //                            {
    //                                cmd2.Parameters.AddWithValue("@Name", filename);
    //                                cmd2.Parameters.AddWithValue("@fileType", 'A');
    //                                cmd2.Parameters.AddWithValue("@docFileName", prefixfileName);
    //                                cmd2.Parameters.AddWithValue("@jobID", Session["JobID"].ToString());
    //                                cmd2.Parameters.AddWithValue("@isFileActive", 1);
    //                                cmd2.Parameters.AddWithValue("@Path", newFilePath);
    //                                cmd2.Parameters.AddWithValue("@sectionID", Session["SectionID"]);
    //                                cmd2.Parameters.AddWithValue("@companyID", cmpID);
    //                                cmd2.Parameters.AddWithValue("@uploadByID", Session["UserID"]); //541==EOIAdmin
    //                                cmd2.Parameters.AddWithValue("@createUser", Session["UserName"]);
    //                                cmd2.Parameters.AddWithValue("@createDate", System.DateTime.Now);
    //                                cmd2.ExecuteNonQuery();
    //                            }
    //                        }                             
    //                        sqlDtReader.Close();
    //                    }
    //                }
    //            }

    //        }
    //        catch (Exception ex)
    //        {
    //            //Response.Write(ex.Message);

    //            string script = "<script type=\"text/javascript\">alert('" + ex.Message.Replace("'", "") + "'); </script>";
    //            ClientScript.RegisterClientScriptBlock(this.GetType(), "myscript", script);

    //            return;
    //        }
    //        finally
    //        {
    //            sqlCon.Close();
    //        }
    //    }
    //    else
    //    {
    //        ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Please select file to upload.')</script>", false);
    //        return;
    //    }

    //    FillUploadedCmpCRFiles();
    //}
    public void DeleteAttributeData(int attrID)
    {
        SqlConnection con = null;
        try
        {
            using (con = new SqlConnection(eBookConn))
            {
                con.Open();
                using (SqlCommand cmd = new SqlCommand("Update FilesTable Set isFileActive = 0,updateUser = @updateUser,updateDate = @updateDate where fileID = " + attrID, con))
                {
                    cmd.Parameters.AddWithValue("@updateUser", Session["Username"].ToString());
                    cmd.Parameters.AddWithValue("@updateDate", System.DateTime.Now);
                    cmd.ExecuteNonQuery();
                }
            }
        }
        catch (Exception ex)
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Error occurred while deleting the file records')</script>", false);
        }
        finally
        {
            con.Close();
        }
    }
    protected void btnSearchTSS_click(object sender, EventArgs e)
    {
        Session["UrlRef"] = Request.Url.AbsoluteUri;
        Response.Redirect("~/TSS/SearchTSSJobs.aspx", false);
    }
    protected void btnEOISearch_click(object sender, EventArgs e)
    {
        Session["UrlRef"] = Request.Url.AbsoluteUri;
        Response.Redirect("~/TSS/SearchEOIInfo.aspx", false);
    }

    protected void chkCmpResponded_CheckedChanged(object sender, EventArgs e)
    {        
        CheckBox chkCmpRes = sender as CheckBox;
        GridViewRow gvrow = chkCmpRes.NamingContainer as GridViewRow;         
        string vendorID = ((Label)gvrow.FindControl("lblVendorID")).Text;
        SqlConnection sqlConn = null;
        try
        {
            using (sqlConn = new SqlConnection(eBookConn))
            {
                sqlConn.Open();
                SqlCommand sqlComm = null;
                using (sqlComm = new SqlCommand())
                {
                    sqlComm.Connection = sqlConn;
                    if (chkCmpRes.Checked)
                    {
                        sqlComm.CommandText = "Update EOIVendors set cmpResponded=1 where vendorID=" + vendorID;
                    }
                    else
                    {
                        sqlComm.CommandText = "Update EOIVendors set cmpResponded=0 where vendorID=" + vendorID;
                    }
                    sqlComm.ExecuteNonQuery();
                    sqlComm.Dispose();
                    ShowOrHideUploadedFiles(false);
                    FillVendors();
                    ddlCompany.SelectedValue = Session["CmpID"].ToString();
                }
            }
        }
        catch (Exception ex)
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Error occurred while updating the vendor information in the database')</script>", false);
        }
        finally
        {
            sqlConn.Close();
        }
        //'<%#Eval("
    }
     
    protected void rdbSelectCmp_OnCheckedChanged(object sender, EventArgs e)
    {
        try
        {
            RadioButton rdoBtn = sender as RadioButton;
            Session["RdoBtn"] = rdoBtn;
            GridViewRow gvrow = rdoBtn.NamingContainer as GridViewRow;
            //GridView gv = rdoBtn.Parent.Parent as GridView;
            //Int16 rdoSelectIdx = 2;
            foreach (GridViewRow row in gvViewVendors.Rows)
            {
                if (row.RowIndex != gvrow.RowIndex)
                {
                    ((System.Web.UI.WebControls.RadioButton)row.FindControl("rdbSelectCmp")).Checked = false;
                }
            }
            //for (int itemRow = 0; itemRow < gvViewVendors.Rows.Count; itemRow++)
            //{
            //    if (gvViewVendors.Rows[itemRow].RowIndex != gvrow.RowIndex)
            //    {
            //        ((RadioButton)gvViewVendors.FindControl("gvViewVendors_ctl0" + rdoSelectIdx++ + "_rdbSelectCmp")).Checked = false;
            //    }
            //}

            Session["CmpID"] = ((Label)gvrow.FindControl("lblCmpID")).Text;
            string cmpID = Session["CmpID"].ToString();
            SqlConnection sqlCon = null;
            using (sqlCon = new SqlConnection(eBookConn))
            {
                sqlCon.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = sqlCon;
                cmd.CommandText = "select eoiCollectionDate,cmpAddress,cmpTelNo,cmpFaxNo,cmpNationality,cmpEmailID,cmpCRNo,cmpQatariShare,cmpCRExpDate,remarks " +
                "from EOIVendors where companyID=@companyID and jobID=@jobID";
                cmd.Parameters.AddWithValue("@companyID", cmpID);
                cmd.Parameters.AddWithValue("@jobID", Session["JobID"].ToString());
                SqlDataReader sqlDtReader = cmd.ExecuteReader();
                sqlDtReader.Read();
                txtEOICollectionDate.Text = Convert.ToDateTime(sqlDtReader[0].ToString()).ToString("dd/MMM/yyyy");
                ddlCompany.SelectedValue = cmpID;
                txtCompanyAddress.Text = sqlDtReader[1].ToString();
                txtCompanyTelephoneNo.Text = sqlDtReader[2].ToString();
                txtFaxNo.Text = sqlDtReader[3].ToString();
                txtNationality.Text = sqlDtReader[4].ToString();
                txtCmpEmailID.Text = sqlDtReader[5].ToString();
                txtCRNo.Text = sqlDtReader[6].ToString();
                txtQatariShare.Text = sqlDtReader[7].ToString();
                txtCRExpDate.Text = Convert.ToDateTime(sqlDtReader[8].ToString()).ToString("dd/MMM/yyyy");
                txtRemarks.Text = sqlDtReader[9].ToString();
                sqlDtReader.Close();
                ShowOrHideUploadedFiles(true);
                FillGridView("CR");
                FillGridView("SD");
            }
        }
        catch(Exception ex)
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Error occurred while retrieving the information of the vendor from the database')</script>", false);
        }
        //gvViewVendors.DataSource 
    }
    private void FillGridView(string docFileName)
    {
        DataSet ds = new DataSet();        
        string sqlQuery = null;
        sqlQuery = "select fileID, FileName,docFileName, FilePath,createUser,REPLACE(CONVERT(NVARCHAR, createDate, 106), ' ', '-') AS createDate from FilesTable where isFileActive = 1 and jobID=" + Session["JobID"].ToString() + " and companyID=" + Session["CmpID"].ToString() + " and docFileName like '" + docFileName + "_%'"; //541=="EOIAdmin"
        SqlConnection con = new SqlConnection(eBookConn);
        con.Open();
        SqlCommand cmd = new SqlCommand(sqlQuery, con);
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        da.Fill(ds);
        con.Close();
        if (docFileName == "CR")
        {
            gvCrFilesUpload.DataSource = ds;
            gvCrFilesUpload.DataBind();
        }
        else
        {
            gvSdFilesUpload.DataSource = ds;
            gvSdFilesUpload.DataBind();
        }
        if (!Session["UserID"].Equals("541"))
        {
            gvCrFilesUpload.Columns[5].Visible = false;
            gvSdFilesUpload.Columns[5].Visible = false;
        }
    }

    protected void btnUpdate_click(object sender, EventArgs e)
    {
        SqlConnection sqlConn = null;

        try
        {
            using (sqlConn = new SqlConnection(eBookConn))
            {
                sqlConn.Open();
                SqlCommand sqlComm = null;
                using (sqlComm = new SqlCommand())
                {

                    //sqlDtReader.Close();
                    sqlComm = new SqlCommand();
                    sqlComm.CommandType = CommandType.StoredProcedure;
                    sqlComm.CommandText = "EOIAddVendor";
                    sqlComm.Connection = sqlConn;
                    sqlComm.Parameters.AddWithValue("@isInsert", 0);
                     
                    //sqlComm.Parameters.AddWithValue("@projId", HttpUtility.HtmlDecode(Request.QueryString["projectID"].ToString()));
                    //sqlComm.Parameters.AddWithValue("@projId", DBNull.Value);
                    sqlComm.Parameters.AddWithValue("@jobID", Session["JobID"].ToString());
                    //strDate = Convert.ToDateTime(strDate).ToString("MM/dd/yyyy", CultureInfo.InvariantCulture);                                            
                    sqlComm.Parameters.AddWithValue("@projectTitle", DBNull.Value);
                    sqlComm.Parameters.AddWithValue("@companyID", Session["CmpID"].ToString());
                    if (txtEOICollectionDate.Text != "")
                    {
                        sqlComm.Parameters.AddWithValue("@eoiCollectionDate", Convert.ToDateTime(txtEOICollectionDate.Text + " " + DateTime.Now.TimeOfDay)); //strDate = Convert.ToDateTime(strDate).ToString("MM/dd/yyyy", CultureInfo.InvariantCulture);                        
                    }
                    else
                    {
                        sqlComm.Parameters.AddWithValue("@eoiCollectionDate", DBNull.Value);
                    }
                     
                    if (txtCompanyAddress.Text.Trim() != "")
                    {
                        sqlComm.Parameters.AddWithValue("@cmpAddress", txtCompanyAddress.Text.Trim());
                    }
                    else
                    {
                        sqlComm.Parameters.AddWithValue("@cmpAddress", DBNull.Value);
                    }
                    if (txtCompanyTelephoneNo.Text.Trim() != "")
                    {
                        sqlComm.Parameters.AddWithValue("@cmpTelNo", txtCompanyTelephoneNo.Text.Trim());
                    }
                    else
                    {
                        sqlComm.Parameters.AddWithValue("@cmpTelNo", DBNull.Value);
                    }
                    if (txtFaxNo.Text.Trim() != "")
                    {
                        sqlComm.Parameters.AddWithValue("@cmpFaxNo", txtFaxNo.Text.Trim());
                    }
                    else
                    {
                        sqlComm.Parameters.AddWithValue("@cmpFaxNo", DBNull.Value);
                    }
                    if (txtNationality.Text.Trim() != "")
                    {
                        sqlComm.Parameters.AddWithValue("@cmpNationality", txtNationality.Text.Trim());
                    }
                    else
                    {
                        sqlComm.Parameters.AddWithValue("@cmpNationality", DBNull.Value);
                    }
                    if (txtCmpEmailID.Text.Trim() != "")
                    {
                        sqlComm.Parameters.AddWithValue("@cmpEmailID", txtCmpEmailID.Text.Trim());
                    }
                    else
                    {
                        sqlComm.Parameters.AddWithValue("@cmpEmailID", DBNull.Value);
                    }
                    if (txtCRNo.Text.Trim() != "")
                    {
                        sqlComm.Parameters.AddWithValue("@cmpCRNo", txtCRNo.Text.Trim());
                    }
                    else
                    {
                        sqlComm.Parameters.AddWithValue("@cmpCRNo", DBNull.Value);
                    }
                    if (txtQatariShare.Text.Trim() != "")
                    {
                        sqlComm.Parameters.AddWithValue("@cmpQatariShare", txtQatariShare.Text.Trim());
                    }
                    else
                    {
                        sqlComm.Parameters.AddWithValue("@cmpQatariShare", DBNull.Value);
                    }
                    if (txtCRExpDate.Text.Trim() != "")
                    {
                        sqlComm.Parameters.AddWithValue("@cmpCRExpDate", Convert.ToDateTime(txtCRExpDate.Text.Trim() + " " + DateTime.Now.TimeOfDay));
                    }
                    else
                    {
                        sqlComm.Parameters.AddWithValue("@cmpCRExpDate", DBNull.Value);
                    }
                    if (txtRemarks.Text != "")
                    {
                        sqlComm.Parameters.AddWithValue("@remarks", Server.HtmlDecode(txtRemarks.Text));
                    }
                    else
                    {
                        sqlComm.Parameters.AddWithValue("@remarks", DBNull.Value);
                    }
                    sqlComm.ExecuteNonQuery();
                    ((RadioButton)Session["RdoBtn"]).Checked = false;                     
                    ShowOrHideUploadedFiles(false);
                    FillVendors();                    
                    ResetControlValues();                     
                    //}
                    //if (btnOp.Text == "Save")
                    //{
                    //    btnOp.Text = "Update";
                    //}
                    //LoadEOIStages();
                }
            }
        }
        catch (Exception ex)
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Error occurred while updating the vendor information in the database')</script>", false);
        }
        finally
        {
            sqlConn.Close();
        }
    }
    private void ResetControlValues()
    {
        txtEOICollectionDate.Text = "";
        txtCompanyAddress.Text = "";
        txtCompanyTelephoneNo.Text = "";
        txtNationality.Text = "";
        txtCmpEmailID.Text = "";
        txtCRNo.Text = "";
        txtQatariShare.Text = "";
        txtCRExpDate.Text = "";
        txtFaxNo.Text = "";
        txtRemarks.Text = "";
    }
    protected void btnBack_Click(object sender, EventArgs e)
    {
        if (Session["UserName"] == null)
        {
            Response.Redirect("~/LoginPage.aspx", false);
            return;
        }
        Response.Redirect(Session["UrlRef"].ToString());
    }
    protected void btnAddVendor_click(object sender, EventArgs e)
    {
        Session["UrlRef"] = Request.Url.AbsoluteUri;
        Response.Redirect("~/TSS/AddVendor.aspx", false);
    }
}