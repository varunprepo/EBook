﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Net.Security;
using System.Security.Cryptography.X509Certificates;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class TSS_ReviewAndApprovalForPublishing : System.Web.UI.Page
{
    string connValue = System.Configuration.ConfigurationManager.ConnectionStrings["EBSDEBookConn"].ConnectionString;
    //string actionDueDate = null;
    protected void Page_Load(object sender, EventArgs e)
    {
        //actionDueDate = Request.QueryString["actionDueDate"];
        if (!IsPostBack)
        {
            PopulateDropDownBox(ddlPurpose, "SELECT jobPurposeID, jobPurposeName FROM JobPurpose where jobPurposeID in(1,8,9,10,14) OR sectionID = 13", "jobPurposeID", "jobPurposeName"); //  For Distribution -1  // For Review - 8// For Approval - 9// For Action -10 // 14 - For Coordination
            string getStaff = "SELECT  contactID, (firstName + ' ' + lastName) as UserName FROM  Contact WHERE (userShortName IS NOT NULL) AND (contactID <> 1) AND (isActive = 1) and sectionID = 13 or isHeadOfSection=1  ORDER BY UserName";
            PopulateDropDownBox(ddlStaff, getStaff, "contactID", "UserName");
        }
    }
   
    protected void returnToTL_click(object sender, EventArgs e)
    {
        CreateTask(false);
    }
    private void PopulateDropDownBox(DropDownList ddlBox, string sqlQuery, string valueMember, string displayName)
    {
        DataTable table = new DataTable();
        try
        {
            using (SqlConnection sqlConn = new SqlConnection(connValue))
            {
                using (SqlDataAdapter da = new SqlDataAdapter(sqlQuery, sqlConn))
                {
                    sqlConn.Open();
                    da.Fill(table);
                }
            }
            //cmbBox.Items.Add("Select");

            ddlBox.DataSource = table;
            ddlBox.DataTextField = displayName;
            ddlBox.DataValueField = valueMember;

            ddlBox.SelectedIndex = -1;
            ddlBox.DataBind();

            ddlBox.Items.Insert(0, new ListItem(""));
        }
        catch (System.Exception ex)
        {
            throw ex;
        }
    }

    private int getTeamLeadContactID(SqlConnection cnn)
    {
        int iCnt = 0;        
        SqlCommand cmm = new SqlCommand();
        cmm.Connection = cnn;
        cmm.CommandText = "select contactID from Contact where sectionID = @sectionID and isTeamLeader=@isTeamLeader and isActive = 1";
        cmm.CommandType = CommandType.Text;

        cmm.Parameters.AddWithValue("@sectionID", Session["SectionID"].ToString());
        cmm.Parameters.AddWithValue("@isTeamLeader", "1"); 

        SqlDataReader dr = cmm.ExecuteReader();

        if (dr.HasRows)
        {
            if (dr.Read())
                iCnt = Convert.ToInt16(dr["contactID"]);
        }
        dr.Close();

        return iCnt;
    }

    private int getEOIAdminContactID(SqlConnection cnn)
    {
        int iCnt = 0;
        SqlCommand cmm = new SqlCommand();
        cmm.Connection = cnn;
        cmm.CommandText = "select contactID from Contact where sectionID = @sectionID and firstName=@firstName and isActive = 1";
        cmm.CommandType = CommandType.Text;

        cmm.Parameters.AddWithValue("@sectionID", Session["SectionID"].ToString());
        cmm.Parameters.AddWithValue("@firstName", "EOI");

        SqlDataReader dr = cmm.ExecuteReader();

        if (dr.HasRows)
        {
            if (dr.Read())
                iCnt = Convert.ToInt16(dr["contactID"]);
        }
        dr.Close();

        return iCnt;
    }

    private void CreateTask(bool isEOIAdmin)
    {         
        if (Session["Username"] != null)
        {
            AddJobInchargeForTSS(Session["Username"].ToString(), Convert.ToInt32(Session["UserID"]), Convert.ToInt32(Session["SectionID"]), isEOIAdmin);
        }
        else
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "Popup", "<script>window.close();</script>", false);
            Response.Redirect("~/LoginPage.aspx", false);
        }
    }
    public void AddJobInchargeForTSS(string userName, int _currentUserID, int _currentSecID, bool isEOIAdmin)
    {
        int _ownerID = 0;
        using (SqlConnection con = new SqlConnection(connValue))
        {
            con.Open();
            using (SqlCommand cmd = new SqlCommand())
            {
                try
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Connection = con;

                    cmd.CommandText = "AddJobInchargeForTSS";

                    cmd.Parameters.AddWithValue("@jobID", Session["JobID"].ToString());

                    int contactID = 0;
                    if (!isEOIAdmin)
                    {
                        contactID = getTeamLeadContactID(con);
                    }
                    else
                    {
                        contactID = getEOIAdminContactID(con);
                    }
                    cmd.Parameters.AddWithValue("@contactID", contactID);

                    cmd.Parameters.AddWithValue("@distributedBy", _currentUserID);

                    cmd.Parameters.AddWithValue("@actionDueDate", actionDueDate.Text); //Convert.ToDateTime(actionDueDate.Text).ToString()

                    cmd.Parameters.AddWithValue("@daysToAct", 1);

                    cmd.Parameters.AddWithValue("@createUser", userName);

                    cmd.Parameters.AddWithValue("@StaffRoleID", 1);
                     
                    cmd.Parameters.AddWithValue("@jobPurposeID", ddlPurpose.SelectedValue);

                    cmd.Parameters.AddWithValue("@sectionID", Session["SectionID"].ToString());

                    cmd.Parameters.AddWithValue("@jobOwnerID", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                    //if (staffStartDate != "")
                    //    cmd.Parameters.AddWithValue("@startDate", Convert.ToDateTime(System.DateTime.Now).ToString("dd/MMM/yyyy"));
                    //else
                    //    cmd.Parameters.AddWithValue("@startDate", System.DBNull.Value);

                    cmd.Parameters.AddWithValue("@startDate", startDate.Text); //Convert.ToDateTime(startDate.Text).ToString()
                    cmd.Parameters.AddWithValue("@remarks", Server.HtmlDecode(comments.InnerText.Replace("\r\n", " ")));
                    cmd.ExecuteNonQuery();
                    _ownerID = (int)cmd.Parameters["@jobOwnerID"].Value;
                    //string _eMail = getEmail(contactID.ToString());
                    //if (_eMail != null)
                    //{
                    //    OutLookAlertQuick(_eMail, "");
                    //}
                    //else
                    //{
                    //    ClientScript.RegisterClientScriptBlock(this.GetType(), "Popup", "<script>alert('Cannot send email. No EmailID found. Please inform Staff personally')</script>", false);
                    //}
                    if (!isEOIAdmin)
                    {
                        UpdateJobStatus(Convert.ToInt32(Session["loggedInJobOwnerID"]), 2);
                    }
                    else
                    {
                        UpdateJobStatus(Convert.ToInt32(Session["loggedInJobOwnerID"]), 7);
                    }
                    this.ClientScript.RegisterClientScriptBlock(this.GetType(), "Close", "window.close()", true);
                    ScriptManager.RegisterStartupScript(this, typeof(string), "script",
                    "<script type=text/javascript> parent.location.href = parent.location.href;</script>", false);
                }
                catch (Exception ex)
                {
                    ClientScript.RegisterClientScriptBlock(this.GetType(), "Popup", "<script>alert('Error Occurred while connecting to the database')</script>", false);
                }                
            }
        }
    }

    private void UpdateJobStatus(int _ownerID, int _statusID)
    {
        SqlConnection cnn = new SqlConnection(connValue);
        cnn.Open();
        SqlCommand cmm = new SqlCommand();
        cmm.Connection = cnn;         
        cmm.CommandText = "update JobOwner set jobOwnerStatusID = @statID,completionDate = @completionDate where jobOwnerID =@ownerID";
        cmm.CommandType = CommandType.Text;
        cmm.Parameters.AddWithValue("@ownerID", _ownerID);
        cmm.Parameters.AddWithValue("@statID", _statusID);        
        cmm.Parameters.AddWithValue("@completionDate", Convert.ToDateTime(System.DateTime.Now).ToString("dd/MMM/yyyy"));
        cmm.ExecuteNonQuery();
        cnn.Close();
    }

    private void OutLookAlertQuick(string eMail, string mailBody)
    {
        SmtpClient smtpclient = new SmtpClient("10.250.50.201", 587);
        System.Net.Mail.MailMessage mail = new System.Net.Mail.MailMessage();
        MailAddress fromaddress = new MailAddress("EBSD@ashghal.gov.qa");
        mail.From = fromaddress;
        mail.To.Add(eMail);
        string jobNo = Session["JobID"].ToString();
        mail.Subject = ("eBook Job No. " + jobNo);
        mail.IsBodyHtml = true;

        // mail.Body = "Please be informed that a new Job Order was assigned to you under the above subject. Please log on to eBook Application to see the details of the Job Order.";

        mail.Body = "<html><body><i style='font-family:Calibri; font-size:15'>Dear eBook Team,</i><br/><br/><i style='font-family:Calibri; font-size:15'>This is an automated alert from Document & Task Management System.</i><br/><br/><i style='font-family:Calibri;font-size:15'>" +
                            "Please be noted that</i><i style='color:Maroon;font-family:Calibri; font-size:15'> Job No. " + jobNo + "</i><i style='font-family:Calibri; font-size:15'> a new Job Order was assigned to you and the details are as follows:-</i><br /><br />" +
                            "<table style='width:80%' border='1'><tr><td align='center' colspan='2' style='background-color:Maroon;color:White;font-family:Calibri;font-size:18;font-weight:bold'>JOB NO: " + jobNo + "</td>" +
                             "</tr><tr><td style='background-color:#B58AA5;font-family:Calibri;font-size:15'><i>Contract No / Job Subject </i></td><td style='font-family:Calibri;font-size:15'>" + Session["PrjTitle"].ToString() + "</td>" +
                            "</tr><tr><td style='background-color:#B58AA5;font-family:Calibri;font-size:15'><i>Contract No / Project Code </i></td><td style='font-family:Calibri;font-size:15'>" + Session["CntrNo"].ToString() + "</td></tr>" +
                            "<tr><td style='background-color:#B58AA5;font-family:Calibri;font-size:15'><i>eBook URL</i></td><td style='font-family:Calibri;font-size:15'><a href='http://mv2ebdbookp01/eBook/LoginPage.aspx'>http://mv2ebdbookp01/eBook/LoginPage.aspx</a></td></tr>" +
                            "<tr><td style='background-color:#B58AA5;font-family:Calibri;font-size:15'><i>Date of Creation</i></td><td style='font-family:Calibri;font-size:15'>" + System.DateTime.Now + "</td></tr>" +
                            "</table><br/><br/><div style='font-family:Calibri; font-size:15'>Best Regards,<br/>eBook Team</div></body></html>";


        smtpclient.EnableSsl = true;
        smtpclient.UseDefaultCredentials = true;

        try
        {
            smtpclient.Credentials = new System.Net.NetworkCredential(@"Ashghal\EBSD", ConfigurationManager.AppSettings["passWordForReport"].ToString()); //i
            ServicePointManager.ServerCertificateValidationCallback = delegate(object s, X509Certificate certificate, X509Chain chain, SslPolicyErrors sslPolicyErrors) { return true; };

            // Added code for qucik mail

            SendEmail myAction = new SendEmail(SendCompletedCallback);
            myAction.BeginInvoke(smtpclient, mail, null, null);
        }
        catch (System.Exception ex)
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "Popup", "<script>alert('Error occurred while sending the email')</script>", false);
        }
        //finally
        //{
        //    //mail.Dispose();
        //    //mail = null;
        //    //// smtpclient = null;
        //}

    }

    private delegate void SendEmail(SmtpClient smtpclient, System.Net.Mail.MailMessage mail);

    private void SendCompletedCallback(SmtpClient smtpclient, System.Net.Mail.MailMessage mail) //private static void SendCompletedCallback(object sender, AsyncCompletedEventArgs e
    {
        try
        {
            smtpclient.Send(mail);
        }
        catch (Exception ex)
        {
            //Console.WriteLine(ex.Message);             
        }
        //finally
        //{
        //    mail.Dispose();
        //    mail = null;
        //    // smtpclient = null;
        //}
    }
    private string getEmail(string contactID)
    {
        string streMail = null;
        try
        {
            SqlConnection sqlConn = new SqlConnection(connValue);
            sqlConn.Open();
            SqlCommand sqlCom = new SqlCommand("Select emailAddress from Contact where ContactID = " + Convert.ToInt32(contactID) + "", sqlConn);
            SqlDataReader sqlReader = sqlCom.ExecuteReader();
            while (sqlReader.Read())
            {
                streMail = sqlReader["emailAddress"].ToString();
            }
            sqlReader.Close();
            sqlConn.Close();
        }
        catch (System.Exception ex)
        {
            throw ex;
        }

        return streMail;
    }

    protected void approvalForPublish_Click(object sender, EventArgs e)
    {
        CreateTask(true);
    }
}