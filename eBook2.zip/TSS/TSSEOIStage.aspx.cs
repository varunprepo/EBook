﻿using Datalayer;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class TSS_TSSEOIStage : System.Web.UI.Page
{
    string tcmConn = System.Configuration.ConfigurationManager.ConnectionStrings["TCMSConn"].ConnectionString;
    string eBookConn = System.Configuration.ConfigurationManager.ConnectionStrings["EBSDEBookConn"].ConnectionString;
    IList<string> userRightsColl = new List<string>();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["UserName"] == null)
        {
            Response.Redirect("~/LoginPage.aspx", false);
            return;
        }
        
        if (!IsPostBack)
        {

            //DAL dalObj = new DAL(tcmConn);
            //DataTable dtStages = dalObj.GetDataFromDB("StagePTD", "SELECT REPLACE(CONVERT(nvarchar, ptd_receive_on, 106), ' ', '/') AS ReceivedOn, ptd_purpose As Purpose, " +
            //"ptd_assign_qs As AssignedQS, REPLACE(CONVERT(nvarchar,ptd_sent_for_rev, 106), ' ', '/') As Review, ptd_qs_working_status As QSWorkingStatus, ptd_tendec_doc_cur_status As TenderDocumentCurrentStatus, " +
            //"REPLACE(CONVERT(nvarchar,ptd_forwarded_to_dep, 106), ' ', '/') As ForwardedToEndUserDepartment, remarks As Remarks FROM TenderDatesInfo WHERE (stage_id = 1) AND (proj_id = " + HttpUtility.HtmlDecode(Request.QueryString["projectID"].ToString()) + ")");

            //if (dtStages == null)
            //{
            //    ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Error occurred while retrieving the information for Prepare Tender Document Stage')</script>", false);
            //}
            //else
            //{
            //    gvPTD.DataSource = dtStages;
            //    gvPTD.DataBind();
            //}

            //dtStages = dalObj.GetDataFromDB("StageTS", "SELECT REPLACE(CONVERT(nvarchar, ts_receive_on, 106), ' ', '/') AS ReceivedOn,ts_issue_handling As TsIssueHandledBy, REPLACE(CONVERT(nvarchar,ts_return_to_dept, 106), ' ', '/') As TsReturnToDept, " +
            //"REPLACE(CONVERT(nvarchar,ts_receive_from_dept, 106), ' ', '/') AS TsReceiveFromDept,REPLACE(CONVERT(nvarchar,ts_pr_advertise, 106), ' ', '/') AS TsPrAdvertise, REPLACE(CONVERT(nvarchar,ts_tender_invitation, 106), ' ', '/') AS TsTenderInvitation, REPLACE(CONVERT(nvarchar,ts_closing_s1, 106), ' ', '/') AS TsClosingS1" +
            //",REPLACE(CONVERT(nvarchar,ts_closing_s2, 106), ' ', '/') AS TsClosingS2,REPLACE(CONVERT(nvarchar,ts_modified_closing, 106), ' ', '/') AS TsModifiedClosingS1,REPLACE(CONVERT(nvarchar,ts_modified_closing_s2, 106), ' ', '/') AS TsModifiedClosingS2, remarks FROM TenderDatesInfo WHERE (proj_id = " + HttpUtility.HtmlDecode(Request.QueryString["projectID"].ToString()) + ") " +
            //"and (ts_tender_issue is null) AND (co_ID is NULL) and (stage_id = 2)");

            //dalObj = new DAL(eBookConn);
            //dtStages = dalObj.GetDataFromDB("EOIStage", "SELECT REPLACE(CONVERT(nvarchar,eoi_receiveon, 106), ' ', '/') AS ReceivedOn,eoi_issue_handledby AS IssueHandledBy,REPLACE(CONVERT(nvarchar,eoi_issue_date, 106), ' ', '/') AS TenderInvitation,REPLACE(CONVERT(nvarchar,eoi_receive_from_dept,106), ' ', '/') AS ReceiveFromDept,REPLACE(CONVERT(nvarchar,eoi_return_to_dept, 106), ' ', '/') AS ReturnToDept," +
            //"REPLACE(CONVERT(nvarchar,eoi_pr_advertise, 106), ' ', '/') AS PrAdvertise,REPLACE(CONVERT(nvarchar,eoi_closing_date, 106), ' ', '/') AS ClosingDate,REPLACE(CONVERT(nvarchar,eoi_closing_date_ext1, 106), ' ', '/') AS ClosingDateExt1,REPLACE(CONVERT(nvarchar,eoi_closing_date_ext2, 106), ' ', '/') AS ClosingDateExt2,REPLACE(CONVERT(nvarchar,eoi_closing_date_ext3, 106), ' ', '/') AS ClosingDateExt3," +
            //"REPLACE(CONVERT(nvarchar,eoi_closing_date_ext4, 106), ' ', '/') AS ClosingDateExt4,REPLACE(CONVERT(nvarchar,eoi_closing_date_ext5, 106), ' ', '/') AS ClosingDateExt5,REPLACE(CONVERT(nvarchar,modified_closing_date, 106), ' ', '/') AS ModifiedClosingDate,REPLACE(CONVERT(nvarchar,modified_closing_date_ext1, 106), ' ', '/') AS ModifiedClosingDateExt1,REPLACE(CONVERT(nvarchar,modified_closing_date_ext2, 106), ' ', '/') AS ModifiedClosingDateExt2," +
            //"REPLACE(CONVERT(nvarchar,modified_closing_date_ext3, 106), ' ', '/') AS ModifiedClosingDateExt3,REPLACE(CONVERT(nvarchar,modified_closing_date_ext4, 106), ' ', '/') AS ModifiedClosingDateExt4,REPLACE(CONVERT(nvarchar,modified_closing_date_ext5, 106), ' ', '/') AS ModifiedClosingDateExt5,Remark from Eoi_Tracking where stage_id=2 and proj_id="+ HttpUtility.HtmlDecode(Request.QueryString["projectID"].ToString()));
            try
            {
                txtEOIHandler.Text = Session["UserName"].ToString();
                lblUser.Text = Session["UserDisplayName"].ToString();
                lblUserProfile.Text = Session["ProfileName"].ToString();
                eoiNoHeading.InnerText = "EOI Number:-" + Session["EOINumber"] +" Job No.:-" +Session["JobNo"];
                userRightsColl = (IList<string>)Session["UserRightsColl"];
                if (Session["EOIPubDate"]!=null & Session["EOIPubDate"] != "")
                {
                    txtEoiPRAdvert.Text = Convert.ToDateTime(Session["EOIPubDate"]).ToString("dd/MMM/yyyy");
                }
                DataTable dtStages = LoadEOIStages();
                if (dtStages == null)
                {
                    ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Error occurred while retrieving the information for EOI Stage')</script>", false);
                }
                else
                {
                    //if (dtStages.Rows.Count == 0)
                    //{
                    //    btnUpdate.Text = "Save";
                    //}
                    //else
                    //{
                        btnUpdate.Text = "Update";
                        txtReceiveOn.Text = dtStages.Rows[0][0].ToString();
                        txtEOIHandler.Text = dtStages.Rows[0][1].ToString();
                        txtEOIIssueDate.Text = dtStages.Rows[0][2].ToString();
                        txtEoiReceiveFromDept.Text = dtStages.Rows[0][3].ToString();
                        txtEoiReturnToDept.Text = dtStages.Rows[0][4].ToString();
                        txtEoiPRAdvert.Text = dtStages.Rows[0][5].ToString();
                        txtEoiClosingDate.Text = dtStages.Rows[0][6].ToString();
                        txtEoiClosingDateExt1.Text = dtStages.Rows[0][7].ToString();
                        txtEoiClosingDateExt2.Text = dtStages.Rows[0][8].ToString();
                        txtEoiClosingDateExt3.Text = dtStages.Rows[0][9].ToString();
                        txtEoiClosingDateExt4.Text = dtStages.Rows[0][10].ToString();
                        txtEoiClosingDateExt5.Text = dtStages.Rows[0][11].ToString();
                        txtEoiModifiedClosingDate.Text = dtStages.Rows[0][12].ToString();
                        txtEoiModifiedClosingDateExt1.Text = dtStages.Rows[0][13].ToString();
                        txtEoiModifiedClosingDateExt2.Text = dtStages.Rows[0][14].ToString();
                        txtEoiModifiedClosingDateExt3.Text = dtStages.Rows[0][15].ToString();
                        txtEoiModifiedClosingDateExt4.Text = dtStages.Rows[0][16].ToString();
                        txtEoiModifiedClosingDateExt5.Text = dtStages.Rows[0][17].ToString();
                        txtRemarks.Text = dtStages.Rows[0][18].ToString();
                    //}

                    gvEOIStage.DataSource = dtStages;
                    gvEOIStage.DataBind();
                }
            }
            catch (Exception)
            {
                ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Error occurred while retrieving the information of EOI Stage')</script>", false);
            }
            try
            {
                BindGridviewData();
            }
            catch (Exception)
            {
                ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Error occurred while retrieving the information of uploaded files')</script>", false);
            }
            
            
            //dalObj = new DAL(tcmConn);
            //dtStages = dalObj.GetDataFromDB("StageTEA", "SELECT REPLACE(CONVERT(nvarchar,eval_tender_opening, 106), ' ', '/') AS TenderOpeningEval, REPLACE(CONVERT(nvarchar,eval_tender_doc_receive_from_cd, 106), ' ', '/') AS TenderDocReceiveFromCdEval, REPLACE(CONVERT(nvarchar,eval_tech_sent1, 106), ' ', '/') AS TechSent1Eval, TPWD1,REPLACE(CONVERT(nvarchar,eval_tech_receive1, 106), ' ', '/') AS TechReceive1Eval, " +
            //"REPLACE(CONVERT(nvarchar,eval_com_sent1, 106), ' ', '/') AS FinancialSent1Eval,FPWD1, REPLACE(CONVERT(nvarchar,eval_com_receive1, 106), ' ', '/') AS FinancialReceive1Eval, REPLACE(CONVERT(nvarchar,eval_tech_sent2, 106), ' ', '/') AS TechSent2Eval,TPWD2,REPLACE(CONVERT(nvarchar,eval_tech_receive2, 106), ' ', '/') AS TechReceive2Eval,REPLACE(CONVERT(nvarchar,eval_com_sent2, 106), ' ', '/') AS FinancialSent2Eval,FPWD2,REPLACE(CONVERT(nvarchar,eval_com_receive2, 106), ' ', '/') AS FinancialReceive2Eval," +
            //"REPLACE(CONVERT(nvarchar,eval_tender_award_approval, 106), ' ', '/') As TenderAwardApprovalEval,tender_validity_ext1 as TenderValidityExt1,tender_validity_ext2 as TenderValidityExt2,tenderbond_validity_ext1 As TenderbondValidityExt1,tenderbond_validity_ext2 As TenderbondValidityExt2,eval_no_of_meetings As NoOfMeetingsEval,Remarks " +
            //" FROM TenderDatesInfo WHERE (proj_id = " + HttpUtility.HtmlDecode(Request.QueryString["projectID"].ToString()) + ") AND (stage_id = 3)");

            //if (dtStages == null)
            //{
            //    ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Error occurred while retrieving the information for Technical, Financial Evaluation & Award Stage')</script>", false);
            //}
            //else
            //{                
            //    gvTEA.DataSource = dtStages;
            //    gvTEA.DataBind();
            //}

            //dalObj = new DAL(tcmConn);
            //dtStages = dalObj.GetDataFromDB("StageCP1", "SELECT COMPANY.co_name, CONTRACTORS.ContractAmount, REPLACE(CONVERT(nvarchar,CONTRACTORS.cp_tender_award, 106), ' ', '/') AS TenderAward, CONTRACTORS.StaffInCharge, REPLACE(CONVERT(nvarchar,CONTRACTORS.cp_received_of_doc, 106), ' ', '/') AS ReceivedOfDoc, REPLACE(CONVERT(nvarchar,CONTRACTORS.cp_request_start_date, 106), ' ', '/') AS RequestStartDate, " +
            //"REPLACE(CONVERT(nvarchar,CONTRACTORS.cp_start_date_receive, 106), ' ', '/') AS StartDateReceive, REPLACE(CONVERT(nvarchar,CONTRACTORS.cp_notice_contractor_to_sign, 106), ' ', '/') AS NoticeContractorToSign, REPLACE(CONVERT(nvarchar,CONTRACTORS.cp_due_date_pb, 106), ' ', '/') AS DueDateToPub FROM CONTRACTORS INNER JOIN COMPANY ON CONTRACTORS.co_id = COMPANY.co_id WHERE (CONTRACTORS.proj_id = " + HttpUtility.HtmlDecode(Request.QueryString["projectID"].ToString()) +
            //" and CONTRACTORS.stage_Id = 4 and CONTRACTORS.cp_tender_award is Not Null)");

            //if (dtStages == null)
            //{
            //    ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Error occurred while retrieving the information for Contract Process 1st Table Stage')</script>", false);
            //}
            //else
            //{
            //    gvCP1.DataSource = dtStages;
            //    gvCP1.DataBind();
            //}

            //dalObj = new DAL(tcmConn);
            //dtStages = dalObj.GetDataFromDB("StageCP2", "SELECT COMPANY.co_name, REPLACE(CONVERT(nvarchar,CONTRACTORS.cp_contractor_sign, 106), ' ', '/') AS ContractorSign,REPLACE(CONVERT(nvarchar,CONTRACTORS.cp_sent_dep_sign, 106), ' ', '/') AS SentDepToSign, REPLACE(CONVERT(nvarchar,CONTRACTORS.cp_receive_dep_sent_prsd, 106), ' ', '/') AS ReceiveDepSentToPrsd,REPLACE(CONVERT(nvarchar,CONTRACTORS.cp_sent_fd_commit, 106), ' ', '/') AS SentToCommittee, " +
            //" REPLACE(CONVERT(nvarchar,CONTRACTORS.cp_receive_fd_commit, 106), ' ', '/') AS ReceiveFromCommittee, REPLACE(CONVERT(nvarchar,CONTRACTORS.cp_distribution, 106), ' ', '/') AS DistributionDate, CONTRACTORS.contract_no,CONTRACTORS.Remarks FROM CONTRACTORS INNER JOIN COMPANY ON CONTRACTORS.co_id = COMPANY.co_id WHERE (CONTRACTORS.proj_id = " + HttpUtility.HtmlDecode(Request.QueryString["projectID"].ToString()) +
            //" and CONTRACTORS.stage_Id = 4 and CONTRACTORS.cp_tender_award is Not Null)");

            //if (dtStages == null)
            //{
            //    ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Error occurred while retrieving the information for Contract Process 2nd Table Stage')</script>", false);
            //}
            //else
            //{
            //    gvCP2.DataSource = dtStages;
            //    gvCP2.DataBind();
            //}
        }
    }
    
    private DataTable LoadEOIStages()
    {
        DAL dalObj = new DAL(eBookConn);
        DataTable dtStages = dalObj.GetDataFromDB("EOIStage", "SELECT REPLACE(CONVERT(nvarchar,eoiTrack.eoi_receiveon, 106), ' ', '/') AS ReceivedOn,eoiTrack.eoi_issue_handledby AS IssueHandledBy,REPLACE(CONVERT(nvarchar,eoiTrack.eoi_issue_date, 106), ' ', '/') AS TenderInvitation,REPLACE(CONVERT(nvarchar,eoiTrack.eoi_receive_from_dept,106), ' ', '/') AS ReceiveFromDept,REPLACE(CONVERT(nvarchar,eoiTrack.eoi_return_to_dept, 106), ' ', '/') AS ReturnToDept," +
        "REPLACE(CONVERT(nvarchar,eoiTrack.eoiPubDate, 106), ' ', '/') AS eoiPubDate,REPLACE(CONVERT(nvarchar,eoiTrack.eoi_closing_date, 106), ' ', '/') AS ClosingDate,REPLACE(CONVERT(nvarchar,eoiTrack.eoi_closing_date_ext1, 106), ' ', '/') AS ClosingDateExt1,REPLACE(CONVERT(nvarchar,eoiTrack.eoi_closing_date_ext2, 106), ' ', '/') AS ClosingDateExt2,REPLACE(CONVERT(nvarchar,eoiTrack.eoi_closing_date_ext3, 106), ' ', '/') AS ClosingDateExt3," +
        "REPLACE(CONVERT(nvarchar,eoiTrack.eoi_closing_date_ext4, 106), ' ', '/') AS ClosingDateExt4,REPLACE(CONVERT(nvarchar,eoiTrack.eoi_closing_date_ext5, 106), ' ', '/') AS ClosingDateExt5,REPLACE(CONVERT(nvarchar,eoiTrack.modified_closing_date, 106), ' ', '/') AS ModifiedClosingDate,REPLACE(CONVERT(nvarchar,eoiTrack.modified_closing_date_ext1, 106), ' ', '/') AS ModifiedClosingDateExt1,REPLACE(CONVERT(nvarchar,eoiTrack.modified_closing_date_ext2, 106), ' ', '/') AS ModifiedClosingDateExt2," +
        "REPLACE(CONVERT(nvarchar,eoiTrack.modified_closing_date_ext3, 106), ' ', '/') AS ModifiedClosingDateExt3,REPLACE(CONVERT(nvarchar,eoiTrack.modified_closing_date_ext4, 106), ' ', '/') AS ModifiedClosingDateExt4,REPLACE(CONVERT(nvarchar,eoiTrack.modified_closing_date_ext5, 106), ' ', '/') AS ModifiedClosingDateExt5,eoiTrack.Remark from EoiTracking as eoiTrack left outer join Job as job on eoiTrack.jobID=job.jobID where eoiTrack.jobId=" + Session["JobID"].ToString()); //HttpUtility.HtmlDecode(Request.QueryString["projectID"].ToString())
        gvEOIStage.DataSource = dtStages;
        gvEOIStage.DataBind();
        return dtStages;
    }
    protected void lnkLogOutBtn_Click(object sender, EventArgs e)
    {
        // Added by Varun on 01/Dec/2019
        Session["UserName"] = null;
        Response.Redirect("~/LoginPage.aspx", false);
    }
    protected void btnUpload_Click(object sender, EventArgs e)
    {
        //if (IsPostBack == false)
        //{
            string prefixfileName = null;
            string filename = null; // Path.GetFileName(fileUploads.PostedFile.FileName);
            SqlConnection sqlCon = null;
            //fileUploads.SaveAs(Server.MapPath("Files/" + filename));
            string filePath = null;
            if (fileUploads.HasFile)
            {
                try
                {
                    //HttpPostedFileBase[] filebase = null;
                    //filePath = Path.Combine(filePath, Session["ReqID"] + "_" + filename);
                    //if (System.Web.HttpContext.Current.Request.Files.AllKeys.Any())
                    //{
                    //filePath = Server.MapPath(ConfigurationManager.AppSettings["TSSFolderPath"].ToString() + Session["JobNo"]);
                    filePath = ConfigurationManager.AppSettings["TSSFolderPath"].ToString() +"\\"+ Session["JobNo"]; 
                    if (!Directory.Exists(filePath))
                    {
                        Directory.CreateDirectory(filePath);
                    }                  
                     
                    if (fileUploads.HasFile)
                    {                        
                        //filebase = new HttpPostedFileBase[fileUploads.PostedFiles.Count];
                        foreach (HttpPostedFile uploadedFile in fileUploads.PostedFiles)
                        {
                            filename = Path.GetFileName(uploadedFile.FileName);
                            string newFilePath = filePath + "\\" + filename;
                            //filebase[idxCounter] = new HttpPostedFileWrapper(uploadedFile);
                            uploadedFile.SaveAs(newFilePath);                            
                            prefixfileName = "EOI" + "_" + filename;
                            using (sqlCon = new SqlConnection(eBookConn))
                            {
                                sqlCon.Open();
                                SqlCommand cmd1 = new SqlCommand("select * from FilesTable where jobID=@jobID and uploadByID=@uploadByID and filename=@filename and sectionID=@sectionID");
                                cmd1.Connection = sqlCon;
                                cmd1.Parameters.AddWithValue("@filename", filename);
                                //cmd2.Parameters.AddWithValue("@docFileName", prefixfileName);
                                cmd1.Parameters.AddWithValue("@jobID", Session["JobID"].ToString());
                                //cmd2.Parameters.AddWithValue("@isFileActive", 1);
                                //cmd2.Parameters.AddWithValue("@Path", filePath);
                                cmd1.Parameters.AddWithValue("@sectionID", Session["SectionID"]);
                                cmd1.Parameters.AddWithValue("@uploadByID", Session["UserID"]);
                                SqlDataReader sqlDtReader = cmd1.ExecuteReader();
                                if (!sqlDtReader.HasRows)
                                {
                                    sqlDtReader.Close();
                                    using (SqlCommand cmd2 = new SqlCommand("Insert into FilesTable(fileName,docFileName,jobID,isFileActive,filePath,sectionID,uploadByID,createUser,createDate,fileType) values(@Name,@docFileName,@jobID,@isFileActive,@Path,@sectionID,@uploadByID,@createUser,@createDate,@fileType)", sqlCon))
                                    {
                                        cmd2.Parameters.AddWithValue("@Name", filename);
                                        cmd2.Parameters.AddWithValue("@fileType", 'A');
                                        cmd2.Parameters.AddWithValue("@docFileName", prefixfileName);
                                        cmd2.Parameters.AddWithValue("@jobID", Session["JobID"].ToString());
                                        cmd2.Parameters.AddWithValue("@isFileActive", 1);
                                        cmd2.Parameters.AddWithValue("@Path", newFilePath);
                                        cmd2.Parameters.AddWithValue("@sectionID", Session["SectionID"]);
                                        cmd2.Parameters.AddWithValue("@uploadByID", Session["UserID"]); //541==EOIAdmin
                                        cmd2.Parameters.AddWithValue("@createUser", Session["UserName"]);
                                        cmd2.Parameters.AddWithValue("@createDate", System.DateTime.Now);
                                        cmd2.ExecuteNonQuery();
                                    }
                                }
                                //else
                                //{
                                //    using (SqlCommand cmd2 = new SqlCommand("Update FilesTable set isFileActive=1,uploadByID=@uploadByID,updateDate=@updateDate,updateUser=@updateUser where jobID=@jobID and sectionID=@sectionID", sqlCon))
                                //    {                                     
                                //        cmd2.Parameters.AddWithValue("@jobID", Session["JobID"].ToString());                                     
                                //        cmd2.Parameters.AddWithValue("@sectionID", Session["SectionID"]);
                                //        cmd2.Parameters.AddWithValue("@uploadByID", Session["UserID"]);
                                //        cmd2.Parameters.AddWithValue("@updateDate", System.DateTime.Now);
                                //        cmd2.Parameters.AddWithValue("@updateUser", Session["UserName"]);                                        
                                //        cmd2.ExecuteNonQuery();
                                //    }
                                //}
                                sqlDtReader.Close();
                            }                            
                        }
                    }

                }
                catch (Exception ex)
                {
                    //Response.Write(ex.Message);

                    string script = "<script type=\"text/javascript\">alert('" + ex.Message.Replace("'", "") + "'); </script>";
                    ClientScript.RegisterClientScriptBlock(this.GetType(), "myscript", script);

                    return;
                }
                finally
                {
                    sqlCon.Close();
                }
            }
            else
            {
                ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Please select file to upload.')</script>", false);
                return;
            }
             
            BindGridviewData();
        //}

    }
    protected void lnkDownload_Click(object sender, EventArgs e)
    {
        //if (checkUserExist(Convert.ToInt32(fileID), 1, Convert.ToInt32(Session["UserID"])))

        LinkButton lnkbtn = sender as LinkButton;
        GridViewRow gvrow = lnkbtn.NamingContainer as GridViewRow;

        string filePath = gvFileUpload.DataKeys[gvrow.RowIndex].Value.ToString();

        // Only use in case Application Server File foldes not in C Drive

        //if (Session["SectionID"].ToString().Equals("12") || Session["SectionID"].ToString().Equals("13"))
        //filePath = filePath.Replace("C:", "C:");
        //else
        //    filePath = filePath.Replace("C:", "E:");           

        //Response.TransmitFile(Server.MapPath(filePath));

        if (!File.Exists((string)filePath))
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('File not available at specific path')</script>", false);             
            return;
        }
        FileInfo file = new FileInfo(filePath);
        string fileName = file.FullName;
        Response.AddHeader("Content-Disposition", "attachment;filename=\"" + fileName + "\"");
        Response.TransmitFile(fileName);
        Response.End();
    }
    private Boolean checkUserExist(int fileID, int createdBy, int currentUserID)
    {
        using (SqlConnection con = new SqlConnection(eBookConn))
        {
            con.Open();
            using (SqlCommand sqlCom = new SqlCommand())
            {
                sqlCom.CommandType = CommandType.Text;
                sqlCom.Connection = con;
                sqlCom.CommandText = "Select uploadByID From FilesTable where fileID = " + fileID;

                using (SqlDataReader sqlReader = sqlCom.ExecuteReader())
                {
                    while (sqlReader.Read())
                    {
                        if ((sqlReader["uploadByID"].Equals(currentUserID)) || (Session["userProfileID"].Equals("1")))
                            return true;
                    }
                }
            }
        }
        return false;
    }
    protected void gvFileUpload_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandArgument != "")
        {
            int attributeID = Convert.ToInt32(e.CommandArgument);
            if (checkUserExist(attributeID, 1, Convert.ToInt32(Session["UserID"])))
                DeleteAttributeData(attributeID);
            else
                ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('You do not have rights to delete this file.')</script>", false);
        }
    }
    public void DeleteAttributeData(int attrID)
    {
        SqlConnection con = null;
        try
        {            
            using (con = new SqlConnection(eBookConn))
            {
                con.Open();
                using (SqlCommand cmd = new SqlCommand("Update FilesTable Set isFileActive = 0,updateUser = @updateUser,updateDate = @updateDate where fileID = " + attrID, con))
                {
                    cmd.Parameters.AddWithValue("@updateUser", Session["Username"].ToString());
                    cmd.Parameters.AddWithValue("@updateDate", System.DateTime.Now);
                    cmd.ExecuteNonQuery();
                }
            }
        }
        catch (Exception ex)
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Error occurred while deleting the file records')</script>", false);
        }
        finally
        {
            con.Close();
        }
    }
    protected void lnkDelete_Click(object sender, EventArgs e)
    {

        try
        {
            LinkButton lnkbtn = sender as LinkButton;
            GridViewRow gvrow = lnkbtn.NamingContainer as GridViewRow;
            string fileID = gvFileUpload.DataKeys[gvrow.RowIndex].Values[1].ToString();

            if (!userRightsColl.Contains("26"))
            {
                if (checkUserExist(Convert.ToInt32(fileID), 1, Convert.ToInt32(Session["UserID"])))
                {
                    try
                    {
                        using (SqlConnection con = new SqlConnection(eBookConn))
                        {
                            con.Open();
                            using (SqlCommand cmd = new SqlCommand("Update FilesTable Set isFileActive = 0,updateUser = @updateUser,updateDate = @updateDate where fileID = " + fileID, con))
                            {
                                cmd.Parameters.AddWithValue("@updateUser", Session["Username"].ToString());
                                cmd.Parameters.AddWithValue("@updateDate", System.DateTime.Now);
                                cmd.ExecuteNonQuery();
                            }
                        }
                    }
                    catch (Exception ex)
                    {

                    }

                    BindGridviewData();
                }

                else
                {
                    ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('You do not have rights to delete this file')</script>", false);
                }
            }
            else
            {
                ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Please contact Administrator,You do not have rights to delete this file')</script>", false);
            }
        }
        catch (Exception ex)
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Error occurred while processing the request')</script>", false);
        }

    }   

    private void BindGridviewData()
    {
        DataSet ds = new DataSet();
        gvFileUpload.DataSource = null;
        gvFileUpload.DataBind();
        string sqlfileType = null;
        sqlfileType = "select fileID, FileName,docFileName, FilePath,createUser,REPLACE(CONVERT(NVARCHAR, createDate, 106), ' ', '-') AS createDate from FilesTable where isFileActive = 1 and uploadByID =541 and jobID=" + Session["JobID"].ToString() + " and docFileName not like 'CR_%' and docFileName not like 'SD_%'"; //541=="EOIAdmin"
        SqlConnection con = new SqlConnection(eBookConn);
        con.Open();
        SqlCommand cmd = new SqlCommand(sqlfileType, con);
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        da.Fill(ds);
        con.Close(); 
        gvFileUpload.DataSource = ds;
        gvFileUpload.DataBind();
        if (!Session["UserID"].Equals("541"))
        {
            gvFileUpload.Columns[5].Visible = false;
        }
    }

    protected void btnUpdate_Click(object sender, EventArgs e)
    {
        SqlConnection sqlConn = null;

        try
        {
            using (sqlConn = new SqlConnection(eBookConn))
            {
                sqlConn.Open();
                using (SqlCommand sqlComm = new SqlCommand())
                {
                    sqlComm.Connection = sqlConn;
                    sqlComm.CommandType = CommandType.StoredProcedure;
                    //if (btnSave.Text == "Save")
                    //{
                    //    sqlComm.CommandText = "EOIStageDataInsertOrUpdate";
                    //    sqlComm.Parameters.AddWithValue("@isInsert", 1);
                    //}
                    //else
                    //{
                        sqlComm.CommandText = "EOIStageDataUpdate";
                        //sqlComm.Parameters.AddWithValue("@isInsert", 0);
                    //}
                    //sqlComm.Parameters.AddWithValue("@projId", HttpUtility.HtmlDecode(Request.QueryString["projectID"].ToString()));
                    //sqlComm.Parameters.AddWithValue("@projId", DBNull.Value);
                    sqlComm.Parameters.AddWithValue("@jobId", Session["JobID"].ToString());
                    if (txtReceiveOn.Text != "")
                    {
                        sqlComm.Parameters.AddWithValue("@eoiReceiveOn", txtReceiveOn.Text); //strDate = Convert.ToDateTime(strDate).ToString("MM/dd/yyyy", CultureInfo.InvariantCulture);                        
                    }
                    else
                    {
                        sqlComm.Parameters.AddWithValue("@eoiReceiveOn", DBNull.Value);
                    }
                    if (txtEOIHandler.Text != "")
                    {
                        sqlComm.Parameters.AddWithValue("@eoiIssueHandler", txtEOIHandler.Text);
                    }
                    else
                    {
                        sqlComm.Parameters.AddWithValue("@eoiIssueHandler", DBNull.Value);
                    }
                    if (txtEoiReceiveFromDept.Text != "")
                    {
                        sqlComm.Parameters.AddWithValue("@eoiReceiveFromDept", txtEoiReceiveFromDept.Text);
                    }
                    else
                    {
                        sqlComm.Parameters.AddWithValue("@eoiReceiveFromDept", DBNull.Value);
                    }
                    if (txtEoiReturnToDept.Text != "")
                    {
                        sqlComm.Parameters.AddWithValue("@eoiReturnToDept", txtEoiReturnToDept.Text);
                    }
                    else
                    {
                        sqlComm.Parameters.AddWithValue("@eoiReturnToDept", DBNull.Value);
                    }
                    if (txtEOIIssueDate.Text != "")
                    {
                        sqlComm.Parameters.AddWithValue("@eoiIssueDate", txtEOIIssueDate.Text);
                    }
                    else
                    {
                        sqlComm.Parameters.AddWithValue("@eoiIssueDate", DBNull.Value);
                    }
                    if (txtEoiClosingDate.Text != "")
                    {
                        sqlComm.Parameters.AddWithValue("@eoiClosingDate", txtEoiClosingDate.Text);
                    }
                    else
                    {
                        sqlComm.Parameters.AddWithValue("@eoiClosingDate", DBNull.Value);
                    }
                    if (txtEoiClosingDateExt1.Text != "")
                    {
                        sqlComm.Parameters.AddWithValue("@eoiClosingDateExt1", txtEoiClosingDateExt1.Text);
                    }
                    else
                    {
                        sqlComm.Parameters.AddWithValue("@eoiClosingDateExt1", DBNull.Value);
                    }
                    if (txtEoiClosingDateExt2.Text != "")
                    {
                        sqlComm.Parameters.AddWithValue("@eoiClosingDateExt2", txtEoiClosingDateExt2.Text);
                    }
                    else
                    {
                        sqlComm.Parameters.AddWithValue("@eoiClosingDateExt2", DBNull.Value);
                    }
                    if (txtEoiClosingDateExt2.Text != "")
                    {
                        sqlComm.Parameters.AddWithValue("@eoiClosingDateExt3", txtEoiClosingDateExt3.Text);
                    }
                    else
                    {
                        sqlComm.Parameters.AddWithValue("@eoiClosingDateExt3", DBNull.Value);
                    }
                    if (txtEoiClosingDateExt4.Text != "")
                    {
                        sqlComm.Parameters.AddWithValue("@eoiClosingDateExt4", txtEoiClosingDateExt4.Text);
                    }
                    else
                    {
                        sqlComm.Parameters.AddWithValue("@eoiClosingDateExt4", DBNull.Value);
                    }
                    if (txtEoiClosingDateExt5.Text != "")
                    {
                        sqlComm.Parameters.AddWithValue("@eoiClosingDateExt5", txtEoiClosingDateExt5.Text);
                    }
                    else
                    {
                        sqlComm.Parameters.AddWithValue("@eoiClosingDateExt5", DBNull.Value);
                    }
                    if (txtEoiModifiedClosingDate.Text != "")
                    {
                        sqlComm.Parameters.AddWithValue("@eoiModifiedClosingDate", txtEoiModifiedClosingDate.Text);
                    }
                    else
                    {
                        sqlComm.Parameters.AddWithValue("@eoiModifiedClosingDate", DBNull.Value);
                    }
                    if (txtEoiModifiedClosingDateExt1.Text != "")
                    {
                        sqlComm.Parameters.AddWithValue("@eoiModifiedClosingDateExt1", txtEoiModifiedClosingDateExt1.Text);
                    }
                    else
                    {
                        sqlComm.Parameters.AddWithValue("@eoiModifiedClosingDateExt1", DBNull.Value);
                    }
                    if (txtEoiModifiedClosingDateExt2.Text != "")
                    {
                        sqlComm.Parameters.AddWithValue("@eoiModifiedClosingDateExt2", txtEoiModifiedClosingDateExt2.Text);
                    }
                    else
                    {
                        sqlComm.Parameters.AddWithValue("@eoiModifiedClosingDateExt2", DBNull.Value);
                    }
                    if (txtEoiModifiedClosingDateExt3.Text != "")
                    {
                        sqlComm.Parameters.AddWithValue("@eoiModifiedClosingDateExt3", txtEoiModifiedClosingDateExt3.Text);
                    }
                    else
                    {
                        sqlComm.Parameters.AddWithValue("@eoiModifiedClosingDateExt3", DBNull.Value);
                    }
                    if (txtEoiModifiedClosingDateExt4.Text != "")
                    {
                        sqlComm.Parameters.AddWithValue("@eoiModifiedClosingDateExt4", txtEoiModifiedClosingDateExt4.Text);
                    }
                    else
                    {
                        sqlComm.Parameters.AddWithValue("@eoiModifiedClosingDateExt4", DBNull.Value);
                    }
                    if (txtEoiModifiedClosingDateExt5.Text != "")
                    {
                        sqlComm.Parameters.AddWithValue("@eoiModifiedClosingDateExt5", txtEoiModifiedClosingDateExt5.Text);
                    }
                    else
                    {
                        sqlComm.Parameters.AddWithValue("@eoiModifiedClosingDateExt5", DBNull.Value);
                    }
                    if (txtEoiPRAdvert.Text != "")
                    {
                        sqlComm.Parameters.AddWithValue("@eoiPrAdvertise", txtEoiPRAdvert.Text);
                    }
                    else
                    {
                        sqlComm.Parameters.AddWithValue("@eoiPrAdvertise", DBNull.Value);
                    }
                    if (txtRemarks.Text != "")
                    {
                        sqlComm.Parameters.AddWithValue("@eoiRemarks", txtRemarks.Text);
                    }
                    else
                    {
                        sqlComm.Parameters.AddWithValue("@eoiRemarks", DBNull.Value);
                    }
                    sqlComm.ExecuteNonQuery();
                                      
                    LoadEOIStages();
                }
            }
        }
        catch (Exception ex)
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Error occurred while inserting the information in the database')</script>", false);
        }
        finally
        {
            sqlConn.Close();
        }
    }
    protected void btnSearchTSS_click(object sender, EventArgs e)
    {
        Session["UrlRef"] = Request.Url.AbsoluteUri;
        Response.Redirect("~/TSS/SearchTSSJobs.aspx", false);
    }
    protected void btnEOISearch_click(object sender, EventArgs e)
    {
        Session["UrlRef"] = Request.Url.AbsoluteUri;
        Response.Redirect("~/TSS/SearchEOIInfo.aspx", false);
    }
    protected void btnAddVendor_click(object sender, EventArgs e)
    {
        Session["UrlRef"] = Request.Url.AbsoluteUri;
        Response.Redirect("~/TSS/AddVendor.aspx", false);
    }
    protected void btnViewVendors_click(object sender, EventArgs e)
    {
        Session["UrlRef"] = Request.Url.AbsoluteUri;
        Response.Redirect("~/TSS/ViewAndUpdateVendors.aspx", false);
    }
    protected void imgHome_Click(object sender, ImageClickEventArgs e)
    {
        Response.Redirect("~/TSS/TSSHomePage.aspx", false);
    }
    protected void txtReceiveOn_TextChanged(object sender, EventArgs e)
    {
        if (txtReceiveOn.Text.Trim() != "")
        {
            txtReceiveOn.Text = Convert.ToDateTime(getWorkingDate(txtReceiveOn.Text)).ToString("dd/MMM/yyyy");
        }
    }
    private string getWorkingDate(string strDate)
    {
        SqlConnection con = new SqlConnection(eBookConn);
        SqlCommand cmd = new SqlCommand();
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Connection = con;

        cmd.CommandText = "GetFirstWorkingday";
        SqlParameter prm = cmd.Parameters.Add("@ad_startDate", SqlDbType.DateTime);
        prm.Value = strDate;
        //prm = cmd.Parameters.Add("@actual_work  Days", SqlDbType.Int);
        //prm.Value = Convert.ToInt32(_days);
        prm = cmd.Parameters.Add("@workingDate", SqlDbType.DateTime);
        prm.Direction = ParameterDirection.Output;
        con.Open();
        SqlDataReader dr = cmd.ExecuteReader();
        while (dr.Read())
            Console.WriteLine(dr.GetString(0));
        con.Dispose();
        con.Close();

        return cmd.Parameters[1].Value.ToString();
    }

    protected void txtEoiReceiveFromDept_TextChanged(object sender, EventArgs e)
    {
        if (txtEoiReceiveFromDept.Text.Trim() != "")
        {
            txtEoiReceiveFromDept.Text = Convert.ToDateTime(getWorkingDate(txtEoiReceiveFromDept.Text)).ToString("dd/MMM/yyyy");
        }
    }
    protected void txtEoiReturnToDept_TextChanged(object sender, EventArgs e)
    {
        if (txtEoiReturnToDept.Text.Trim() != "")
        {
            txtEoiReturnToDept.Text = Convert.ToDateTime(getWorkingDate(txtEoiReturnToDept.Text)).ToString("dd/MMM/yyyy");
        }
    }
    protected void txtEoiPRAdvert_TextChanged(object sender, EventArgs e)
    {
        if (txtEoiPRAdvert.Text.Trim() != "")
        {
            txtEoiPRAdvert.Text = Convert.ToDateTime(getWorkingDate(txtEoiPRAdvert.Text)).ToString("dd/MMM/yyyy");
        }
    }
    protected void txtEOIIssueDate_TextChanged(object sender, EventArgs e)
    {
        if (txtEOIIssueDate.Text.Trim() != "")
        {
            txtEOIIssueDate.Text = Convert.ToDateTime(getWorkingDate(txtEOIIssueDate.Text)).ToString("dd/MMM/yyyy");
        }
    }
    protected void txtEoiClosingDate_TextChanged(object sender, EventArgs e)
    {
        if (txtEoiClosingDate.Text.Trim() != "")
        {
            txtEoiClosingDate.Text = Convert.ToDateTime(getWorkingDate(txtEoiClosingDate.Text)).ToString("dd/MMM/yyyy");
        }
    }
    protected void txtEoiClosingDateExt1_TextChanged(object sender, EventArgs e)
    {
        if (txtEoiClosingDateExt1.Text.Trim() != "")
        {
            txtEoiClosingDateExt1.Text = Convert.ToDateTime(getWorkingDate(txtEoiClosingDateExt1.Text)).ToString("dd/MMM/yyyy");
        }
    }
    protected void txtEoiClosingDateExt2_TextChanged(object sender, EventArgs e)
    {
        if (txtEoiClosingDateExt2.Text.Trim() != "")
        {
            txtEoiClosingDateExt2.Text = Convert.ToDateTime(getWorkingDate(txtEoiClosingDateExt2.Text)).ToString("dd/MMM/yyyy");
        }
    }
    protected void txtEoiClosingDateExt3_TextChanged(object sender, EventArgs e)
    {
        if (txtEoiClosingDateExt3.Text.Trim() != "")
        {
            txtEoiClosingDateExt3.Text = Convert.ToDateTime(getWorkingDate(txtEoiClosingDateExt3.Text)).ToString("dd/MMM/yyyy");
        }
    }
    protected void txtEoiClosingDateExt4_TextChanged(object sender, EventArgs e)
    {
        if (txtEoiClosingDateExt4.Text.Trim() != "")
        {
            txtEoiClosingDateExt4.Text = Convert.ToDateTime(getWorkingDate(txtEoiClosingDateExt4.Text)).ToString("dd/MMM/yyyy");
        }
    }
    protected void txtEoiClosingDateExt5_TextChanged(object sender, EventArgs e)
    {
        if (txtEoiClosingDateExt5.Text.Trim() != "")
        {
            txtEoiClosingDateExt5.Text = Convert.ToDateTime(getWorkingDate(txtEoiClosingDateExt5.Text)).ToString("dd/MMM/yyyy");
        }
    }
    protected void txtEoiModifiedClosingDate_TextChanged(object sender, EventArgs e)
    {
        if (txtEoiModifiedClosingDate.Text.Trim() != "")
        {
            txtEoiModifiedClosingDate.Text = Convert.ToDateTime(getWorkingDate(txtEoiModifiedClosingDate.Text)).ToString("dd/MMM/yyyy");
        }
    }
    protected void txtEoiModifiedClosingDateExt1_TextChanged(object sender, EventArgs e)
    {
        if (txtEoiModifiedClosingDateExt1.Text.Trim() != "")
        {
            txtEoiModifiedClosingDateExt1.Text = Convert.ToDateTime(getWorkingDate(txtEoiModifiedClosingDateExt1.Text)).ToString("dd/MMM/yyyy");
        }
    }
    protected void txtEoiModifiedClosingDateExt2_TextChanged(object sender, EventArgs e)
    {
        if (txtEoiModifiedClosingDateExt2.Text.Trim() != "")
        {
            txtEoiModifiedClosingDateExt2.Text = Convert.ToDateTime(getWorkingDate(txtEoiModifiedClosingDateExt2.Text)).ToString("dd/MMM/yyyy");
        }
    }
    protected void txtEoiModifiedClosingDateExt3_TextChanged(object sender, EventArgs e)
    {
        if (txtEoiModifiedClosingDateExt3.Text.Trim() != "")
        {
            txtEoiModifiedClosingDateExt3.Text = Convert.ToDateTime(getWorkingDate(txtEoiModifiedClosingDateExt3.Text)).ToString("dd/MMM/yyyy");
        }
    }
    protected void txtEoiModifiedClosingDateExt4_TextChanged(object sender, EventArgs e)
    {
        if (txtEoiModifiedClosingDateExt4.Text.Trim() != "")
        {
            txtEoiModifiedClosingDateExt4.Text = Convert.ToDateTime(getWorkingDate(txtEoiModifiedClosingDateExt4.Text)).ToString("dd/MMM/yyyy");
        }
    }
    protected void txtEoiModifiedClosingDateExt5_TextChanged(object sender, EventArgs e)
    {
        if (txtEoiModifiedClosingDateExt5.Text.Trim() != "")
        {
            txtEoiModifiedClosingDateExt5.Text = Convert.ToDateTime(getWorkingDate(txtEoiModifiedClosingDateExt5.Text)).ToString("dd/MMM/yyyy");
        }
    }
    protected void btnBack_Click(object sender, EventArgs e)
    {
        if (Session["UserName"] == null)
        {
            Response.Redirect("~/LoginPage.aspx", false);
            return;
        }
        Response.Redirect(Session["UrlRef"].ToString());
    }
    
}