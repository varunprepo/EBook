﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class TSS_EnterEOINumber : System.Web.UI.Page
{
    string eBookConn = System.Configuration.ConfigurationManager.ConnectionStrings["EBSDEBookConn"].ConnectionString;
    static string inchargeID = null;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            //inchargeID = Request.QueryString["inchargeID"].ToString();
            SqlConnection sqlConn = null;
            try
            {
                using (sqlConn = new SqlConnection(eBookConn))
                {
                    sqlConn.Open();
                    using (SqlCommand sqlComm = new SqlCommand())
                    {
                        sqlComm.Connection = sqlConn;
                        sqlComm.CommandText = "select eoiNumber from Job where Jobid=@jobid";
                        sqlComm.Parameters.AddWithValue("@jobid", Session["JobID"]);
                        SqlDataReader sqlDtRead = sqlComm.ExecuteReader();
                        sqlDtRead.Read();
                        txtEOINumber.Text = sqlDtRead["eoiNumber"].ToString();
                        sqlDtRead.Close();            
                    }
                }
            }
            catch (Exception ex)
            {
                ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Error occurred while updating the EOI Number in the database')</script>", false);
            }
            finally
            {
                sqlConn.Close();
            }
        }
    }

    protected void btn_click(object sender, EventArgs e)
    {
        SqlConnection sqlConn = null;
        try
        {
            using (sqlConn = new SqlConnection(eBookConn))
            {
                sqlConn.Open();
                using (SqlCommand sqlComm = new SqlCommand())
                {
                    sqlComm.Connection = sqlConn;
                    sqlComm.CommandText = "update Job set eoiNumber=@eoiNumber where Jobid=@jobid";
                    sqlComm.Parameters.AddWithValue("@jobid", Session["JobID"]);
                    sqlComm.Parameters.AddWithValue("@eoiNumber", HttpUtility.HtmlDecode(txtEOINumber.Text));
                    sqlComm.ExecuteNonQuery();
                    //updateOngoingStatus(Convert.ToInt32(inchargeID), 7);
                    //if (ddl.SelectedValue == "7") //7 == Completed
                    //{
                        //new JobOrderData().SendEmailAlert(new JobOrderData().getEmail("269"), txtJobNo.Text, "", "all the tasks are completed and the details are as follows");  //105 is Nazar ContactID                             
                        //new JobOrderData().SendEmailAlert(new JobOrderData().getEmail(Session["teamLeaderID"].ToString()), txtJobNo.Text, "", "all the tasks are completed and the details are as follows");  //105 is Nazar ContactID                             
                    //}
                    this.ClientScript.RegisterClientScriptBlock(this.GetType(), "Close", "window.close()", true);
                    ScriptManager.RegisterStartupScript(this, typeof(string), "script",
                    "<script type=text/javascript> parent.location.href = parent.location.href;</script>", false);
                }
            }
        }
        catch (Exception ex)
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Error occurred while updating the EOI Number in the database')</script>", false);
        }
        finally
        {
            sqlConn.Close();
        }
    }

    private void updateOngoingStatus(int _ownerID, int _statusID)
    {
        SqlConnection cnn = new SqlConnection(eBookConn);
        cnn.Open();
        SqlCommand cmm = new SqlCommand();
        cmm.Connection = cnn;

        //if (_statusID == 18)
        //{
        //    cmm.CommandText = "update JobOwner set jobOwnerStatusID = @statID,completionDate = @completionDate,draftCompleted = @draftCompleted where jobOwnerID =@ownerID";
        //}
        //else if (_statusID != 3)
        //{
        //    cmm.CommandText = "update JobOwner set jobOwnerStatusID = @statID,completionDate = @completionDate where jobOwnerID =@ownerID";
        //}
        //else
        //{
            cmm.CommandText = "update JobOwner set jobOwnerStatusID = @statID,completionDate = @completionDate,draftCompleted  = @draftCompleted where jobOwnerID =@ownerID";
        //}

        cmm.CommandType = CommandType.Text;

        cmm.Parameters.AddWithValue("@ownerID", _ownerID);
        cmm.Parameters.AddWithValue("@statID", _statusID);

        //if (_statusID == 18)
        //{
        //    cmm.Parameters.AddWithValue("@draftCompleted", Convert.ToDateTime(System.DateTime.Now).ToString("dd/MMM/yyyy"));
        //    cmm.Parameters.AddWithValue("@completionDate", System.DBNull.Value);
        //}
        //else if (_statusID != 3)
        //{
        //    cmm.Parameters.AddWithValue("@completionDate", Convert.ToDateTime(System.DateTime.Now).ToString("dd/MMM/yyyy"));
        //}
        //else
        //{
            cmm.Parameters.AddWithValue("@completionDate", System.DBNull.Value);
            cmm.Parameters.AddWithValue("@draftCompleted", System.DBNull.Value);

        //}

        cmm.ExecuteNonQuery();
        cnn.Close();
    }
}