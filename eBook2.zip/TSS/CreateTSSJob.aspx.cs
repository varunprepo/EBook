﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Datalayer;
using System.Data.SqlClient;
using System.Data;
using PropertyLayer;
using System.Web.UI.HtmlControls;

public partial class TSS_CreateTSSJob : System.Web.UI.Page, ICallbackEventHandler
{
    string connValue = System.Configuration.ConfigurationManager.ConnectionStrings["EBSDEBookConn"].ConnectionString;

   // private SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["EBSDEBookConn"].ConnectionString);
    string _userProfile = string.Empty;
    string _userDisplayName = string.Empty;
    string _jobIDNo = null; 
   
    JobOrderProperty x = new JobOrderProperty();

    protected void WireUpJSFunctions()
    {
        ClientScriptManager csm = Page.ClientScript;
        string callbackProjTitleRef = csm.GetCallbackEventReference(this, "arg", "setProjTitleFromTender", "context");
        string callbackProjCodeRef = csm.GetCallbackEventReference(this, "arg", "setProjTitleFromProjCode", "context");
        
        //string callbackScript = "function getProjTitleFromContract(arg, context) {" + callbackRef + "}";
        //csm.RegisterClientScriptBlock(this.GetType(), "getProjTitleFromContract", callbackScript, true);

        string callbackProjTitleScript = "function getProjTitleFromTender(arg, context) {" + callbackProjTitleRef + "}";
        csm.RegisterClientScriptBlock(this.GetType(), "getProjTitleFromTender", callbackProjTitleScript, true);

        string callbackProjCodeScript = "function getProjTitleFromProjCode(arg, context) {" + callbackProjCodeRef + "}";
        csm.RegisterClientScriptBlock(this.GetType(), "getProjTitleFromProjCode", callbackProjCodeScript, true);

        //callbackRef = csm.GetCallbackEventReference(this, "arg", "setDaysToAct", "context");
        //callbackScript = "function countWorkDays(arg, context) {" + callbackRef + "}";
        //csm.RegisterClientScriptBlock(this.GetType(), "countWorkDays", callbackScript, true);
    }

    string opMsg = null;
    public string GetCallbackResult()
    {
        if (opMsg==null)
        {
            opMsg = "No records found";
        }
        return opMsg;
    }

    public void RaiseCallbackEvent(string eventArgument)
    {
        if (eventArgument != "")
        {
            //if (uCls == null)
            //    uCls = new UtilityClass(this.Page);
            //if (eventArgument.Split(',')[1].ToString().Contains("txtDaysToAct"))
            //{
            try
            {
                if (eventArgument.Contains("p"))
                {
                    if (eventArgument.Split(',')[0] != "")
                    {
                        prjColl = new JobOrderData().getProjectDataByProjCode(eventArgument);
                        //ddlTndrNo.SelectedValue = "";
                    }
                }
                else
                {
                    if (eventArgument.Split(',')[0] != "")
                    {
                        prjColl = new JobOrderData().getProjectDataByID(eventArgument);
                        txtPrjCode.Text = "";
                    }
                }
                    if (prjColl.Count > 0)
                    {
                        Session["sessprjColl"] = prjColl;
                        opMsg = txtPrjTitle.Text = prjColl[0];
                        ddlDept.SelectedValue = geteBookDept(Convert.ToInt16(prjColl[4])).ToString();
                        Session["TCMS_CntrTypeID"] = prjColl[5];
                    }
                

                    //ddlCommitNo.SelectedIndex = 0;
                    

                
                //Session["ClickedTab"] = eventArgument;
                //ReadFilesInsideDirectory(eventArgument);                 
            }
            catch (Exception ex)
            {
                opMsg = "Error Occurred while retrieving the Project Title";
            }

        }
        //throw new NotImplementedException();
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["UserName"] == null)
        {
            Response.RedirectLocation = System.Web.VirtualPathUtility.ToAbsolute("~/LoginPage.aspx");
            return;
        }
        WireUpJSFunctions();
        lblUser.Text = Session["UserDisplayName"].ToString();
        lblUserDesignation.Text = Session["UserDesignation"].ToString();
        lblUserProfile.Text = Session["ProfileName"].ToString();
        if (!IsPostBack)
        {
            FillDropBox();
            txtRecDate.Text = System.DateTime.Now.ToString();            
            //ddlJobPurpose.SelectedIndex = 13;
            ddlJobCat.SelectedIndex = 1;
        }
    }

    protected void lnkLogOutBtn_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/LoginPage.aspx", false);
    }

    private void FillDropBox()
    {
        PopulateDropDownBox(ddlInchargeType, "SELECT jobOwnerCatID, jobOwnerCategory FROM  JobOwnerCategory ORDER BY jobOwnerCatID", "jobOwnerCatID", "jobOwnerCategory");
        int sectionID = Convert.ToInt32(Session["SectionID"]);

        FillCombo(ddlJobCat, "jobTypeID", "JobTypeName", ExecuteQuery("SELECT jobTypeID,JobTypeName FROM JobType  Where jobTypeID In(112)  order by JobTypeName"), false);
        
        FillCombo(ddlJobType, "jobTypeID", "JobTypeName", ExecuteQuery("SELECT jobTypeID,JobTypeName FROM JobType  Where jobTypeID In(113,114)  order by JobTypeName"), false);
        if (Session["JobTypeID"] != null)
        {
            ddlJobType.SelectedValue = Session["JobTypeID"].ToString();
        }
        if (sectionID == 12 || sectionID == 13) 
        {               
            ddlInchargeType.SelectedValue = "4";
        }        

        PopulateDropDownBox(ddlDept, "SELECT departmentID, deptName FROM  Department where affairID is not null and isActive = 1 ORDER BY deptName ", "departmentID", "deptName");
        
        string docRef = "SELECT [Document].referenceNo, [Document].documentID " +
                        " FROM [Document] INNER JOIN  Contact ON [Document].docCreatedByID = Contact.contactID LEFT OUTER JOIN Job ON [Document].documentID = Job.docRefID " +
                        " WHERE ([Document].jobID IS NULL) AND ([Document].paymentID IS NULL) AND ([Document].isDocActive = 1) ORDER BY [Document].createDate"; //AND (Contact.sectionID Not in(2,1,3))

        PopulateDropDownBox(ddlDocRef, docRef, "documentID", "referenceNo");
        if (Session["DocID"] != null)
        {
            if (Session["DocID"].ToString() != "0")
            {
                ddlDocRef.SelectedValue = Session["DocID"].ToString();
                FillDeptProjDetails();
            }
        }
        //PopulateDropDownBox(ddlJobPurpose, "SELECT jobPurposeID, jobPurposeName FROM JobPurpose where jobPurposeID IN (10, 9, 1, 14, 21, 8) ORDER BY jobPurposeName", "jobPurposeID", "jobPurposeName"); 
     
        //PopulateDropDownBox_TCMS(ddlVendor, "SELECT co_id, co_name FROM Company ORDER BY co_name", "co_id", "co_name");

        //PopulateDropDownBox_TCMS(ddlCommitNo, "SELECT bidder_ID,Contract_No FROM CONTRACTORS WHERE (Contract_No IS NOT NULL) and (Contract_No != '')  ORDER BY Contract_No", "bidder_ID", "Contract_No");

        //PopulateDropDownBox_TCMS1(ddlPrjCode, "SELECT proj_id,project_code FROM PROJECTS ORDER BY project_code", "proj_id", "project_code");

        //PopulateDropDownBox_TCMS(ddlTndrNo, "SELECT proj_id,tender_no FROM PROJECTS WHERE (tender_no IS NOT NULL) and (tender_no != '') ORDER BY tender_no", "proj_id", "tender_no");
    }
    public static void FillCombo(DropDownList dropDownList, string dataValueField, string dataTextField, DataTable dataTbl, bool bHasBlank)
    {
        dropDownList.DataTextField = dataTextField;
        dropDownList.DataValueField = dataValueField;
        dropDownList.DataSource = dataTbl;
        dropDownList.DataBind();

        ListItem emptyItem = new ListItem("", "");
        dropDownList.Items.Insert(0, emptyItem);

        //if (bHasBlank)
        //    dropDownList.Items.Insert(0, new ListItem());
    }
    public static DataTable ExecuteQuery(string SQLstring)
    {

        SqlConnection Conn = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["EBSDEBookConn"].ConnectionString);
        DataTable dt = new DataTable("tbl");

        using (Conn)
        {
            Conn.Open();
            SqlCommand comm = new SqlCommand(SQLstring, Conn);
            comm.CommandTimeout = 0;
            SqlDataAdapter da = new SqlDataAdapter(comm);
            da.Fill(dt);
        }
        return dt;
    }
    private void PopulateDropDownBox(DropDownList ddlBox, string sqlQuery, string valueMember, string displayName)
    {
        ddlBox.DataBound += new EventHandler(this.ddlBox_DataBound);
        ddlBox.DataSource = new JobOrderData().FillDropdown(sqlQuery);
        ddlBox.DataTextField = displayName;
        ddlBox.DataValueField = valueMember;
        ddlBox.SelectedIndex = -1;
        ddlBox.DataBind();
    }
    protected void ddlBox_DataBound(object sender, EventArgs e)
    {
        DropDownList ddl = (DropDownList)sender;
        ListItem emptyItem = new ListItem("", "");
        ddl.Items.Insert(0, emptyItem);
        //ddl.Items.Insert(1, "N/A");
    }
    
    //private void PopulateDropDownBox_TCMS1(HtmlGenericControl ddlBox, string sqlQuery, string valueMember, string displayName)
    //{
    //    HtmlGenericControl hgc = new HtmlGenericControl();
        
    //    ddlBox.DataBound += new EventHandler(this.ddlBox_DataBound);
    //    ddlBox.DataSource = new JobOrderData().FillDropdown_TCMS(sqlQuery);
    //    ddlBox.DataTextField = displayName;
    //    ddlBox.DataValueField = valueMember;
    //    ddlBox.SelectedIndex = -1;
    //    ddlBox.DataBind();
    //}
    private void PopulateDropDownBox_TCMS(DropDownList ddlBox, string sqlQuery, string valueMember, string displayName)
    {
        ddlBox.DataBound += new EventHandler(this.ddlBox_DataBound);
        ddlBox.DataSource = new JobOrderData().FillDropdown_TCMS(sqlQuery);
        ddlBox.DataTextField = displayName;
        ddlBox.DataValueField = valueMember;
        ddlBox.SelectedIndex = -1;
        ddlBox.DataBind();
    }
    protected void btnsave_Click(object sender, EventArgs e)
    {
        //if ((txtPrjTitle.Text == ""))
        //{
        //    ClientScript.RegisterClientScriptBlock(this.GetType(), "Popup", "<script>alert('Please enter ContractNo/Project Code')</script>", false);
        //    return;
        //}

        InsertNewJobOrder();       //dcu_CreateJobOrder   
        if (_jobIDNo != null & _jobIDNo != "")
        {
            Response.Redirect("~/TSS/TSSHomePage.aspx", false);
        }
        else if (_jobIDNo =="")
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "Popup", "<script>alert('Failed to send email notification to the origin document creator. Please inform personally')</script>", false);
        }
    }
    protected void btnHome_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/TSS/TSSHomePage.aspx", false);
    }
   
    private void InsertNewJobOrder()
    {       
        string docRecDate = string.Empty; IList<string> userInfoColl = new List<string>();

        int docID = Convert.ToInt32(ddlDocRef.SelectedValue);

        _jobIDNo = PassJobOrderData(docID);
        if (_jobIDNo != null & _jobIDNo != "")
        {
            string projNo = null;
            if (txtPrjCode.Text != "")
            {
                projNo = txtPrjCode.Text;
            }
            //else
            //{
            //    tdrOrProjNo = ddlTndrNo.SelectedItem.Text;
            //}
            string tssJobNo = _jobIDNo.Split(',')[0];
            if (deptCoordEmailID != "")
            {
                new JobOrderData().SendEmailAlertForTSSJob(deptCoordEmailID, tssJobNo, ddlDocRef.SelectedItem.Text + "," + projNo, "TSS Job No." + tssJobNo + " has been created successfully and the details are as follows");
            }
            //else
            //{
            //    new JobOrderData().SendEmailAlertForTSSJob(Session["IssuedByEmailAddress"].ToString(), tssJobNo, ddlDocRef.SelectedItem.Text + "," + projNo, "TSS Job No." + tssJobNo + " has been created successfully and the details are as follows");
            //}
            IList<int> docIDColl = getDocIDCollection(_jobIDNo.Split(',')[1]);

            foreach (var vardocID in docIDColl)
            {
                CheckandDeleteDistributionData(vardocID);
            }
        }

      //  AddProjectAttributes(docID, _addJob.commitmentNo, _addJob.prjCode, _addJob.prjTitle, _addJob.tenderNo);

    }
    private void CheckandDeleteDistributionData(int DocID)
    {
        string sqlQuery = "SELECT documentID, docCatID, distributeID, contactID FROM  DocumentDistribution WHERE (documentID IN (SELECT documentID FROM  DocumentDistribution AS Tmp  GROUP BY documentID, contactID HAVING   (COUNT(*) > 1) AND (contactID = DocumentDistribution.contactID) AND (documentID = " + DocID + ")))  ORDER BY documentID, docCatID, distributeID";

        DataTable dtDocumentDistribution = GetDataFromDB("DocumentDistribution", sqlQuery);
        if (dtDocumentDistribution.Rows.Count != 0)
            DeleteDistributionData(Convert.ToInt32(dtDocumentDistribution.Rows[0]["distributeID"]));
    }
    private void DeleteDistributionData(int documentID)
    {
        string updateSql = "Delete From DocumentDistribution Where distributeID = " + documentID + " ";
        SqlConnection sqlConn = new SqlConnection(connValue);
        SqlCommand cmd = new SqlCommand();
        cmd.CommandText = updateSql;
        cmd.Connection = sqlConn;

        try
        {
            //cmd.Parameters.AddWithValue("@contactID", documentID);   
            sqlConn.Open();
            cmd.ExecuteNonQuery();
            sqlConn.Close();
        }
        catch (Exception ex)
        {

        }
    }
    public DataTable GetDataFromDB(string dataTabName, string sqlQuery)
    {
        DataTable table = null;
        SqlConnection sqlConn = new SqlConnection(connValue);
        sqlConn.Open();
        SqlDataAdapter sqlDtAdptr = null;
        table = new DataTable(dataTabName);
        sqlDtAdptr = new SqlDataAdapter(@sqlQuery, sqlConn);
        sqlDtAdptr.Fill(table);
        sqlConn.Close();
        return table;
    }
    private IList<int> getDocIDCollection(string _jobID)
    {
        IList<int> docIDColl = new List<int>();
        try
        {
            SqlConnection sqlConn = new SqlConnection(connValue);
            sqlConn.Open();
            SqlCommand sqlCom = new SqlCommand("Select DocumentID from Document where jobID = " + _jobID + "", sqlConn);
            SqlDataReader sqlReader = sqlCom.ExecuteReader();
            while (sqlReader.Read())
            {
                docIDColl.Add(Convert.ToInt32(sqlReader["DocumentID"]));
            }
            sqlReader.Close();
            sqlConn.Close();
        }
        catch (System.Exception ex)
        {
            throw ex;
        }

        return docIDColl;
    }
    private void AddProjectAttributes(int _docID, string cntrNo, string prjNo, string prjTitle, string tndrNo)
    {
        SqlConnection con = new SqlConnection(connValue);
        SqlCommand sqlCmd = new SqlCommand();
        sqlCmd.CommandType = CommandType.StoredProcedure;
        sqlCmd.Connection = con;
        sqlCmd.CommandText = "InsertDocProjectAttributes";

        sqlCmd.Parameters.AddWithValue("@docID", _docID);
        if ((cntrNo != "") & (cntrNo != null))
            sqlCmd.Parameters.AddWithValue("@contractNo", cntrNo);
        else
            sqlCmd.Parameters.AddWithValue("@contractNo", System.DBNull.Value);

        if ((prjNo != "") & (prjNo != null))
            sqlCmd.Parameters.AddWithValue("@projectCode", prjNo);
        else
            sqlCmd.Parameters.AddWithValue("@projectCode", System.DBNull.Value);

        if ((tndrNo != "") & (tndrNo != null))
            sqlCmd.Parameters.AddWithValue("@tenderNo", tndrNo);
        else
            sqlCmd.Parameters.AddWithValue("@tenderNo", System.DBNull.Value);

        sqlCmd.Parameters.AddWithValue("@projectTitle", prjTitle);

        con.Open();
        sqlCmd.ExecuteNonQuery();
        con.Close();
    }
    JobOrderProperty _addJob = new JobOrderProperty();
    public string PassJobOrderData(int _docID)
    {
        if (ddlDept.SelectedIndex != 0)
            Session["AffairID"] = new JobOrderData().getAffairID(Convert.ToInt32(ddlDept.SelectedValue));

        //  _addJob.jobID = maxJobID;
        _addJob.jobNo = txtJobNo.Text;

        if (ddlJobType.SelectedIndex != 0)
        {
            _addJob.jobTypeID = Convert.ToInt32(ddlJobType.SelectedValue);
            _addJob.jobCatID = Convert.ToInt32(ddlJobCat.SelectedValue);
        }
        else
        {
            _addJob.jobCatID = Convert.ToInt32(ddlJobCat.SelectedValue);
            _addJob.jobTypeID = Convert.ToInt32(ddlJobCat.SelectedValue);
        }

        if (ddlJobCat.SelectedValue != "1")
            _addJob.jobStatusID = 3;  //jobOrder
        else
            _addJob.jobStatusID = 8;  //PSA

        if (ddlDept.SelectedIndex != 0)
        {
            _addJob.deptID = Convert.ToInt32(ddlDept.SelectedValue);
            _addJob.affID = Convert.ToInt32(Session["AffairID"]);
        }
        else
        {
            _addJob.deptID = 1;
        }

        //if (ddlVendor.SelectedIndex != 0)
        //    _addJob.contractorID = Convert.ToInt32(ddlVendor.SelectedItem.Value);

        if (txtPrjCode.Text != null)
        {
            _addJob.prjCode = txtPrjCode.Text; // SelectedItem.Text;
        }
        else
            _addJob.prjCode = "";
        //else if (ddlPrjCode.Value== null) // else if (ddlPrjCode.SelectedItem == null)
        //{
        //    _addJob.prjCode = ddlPrjCode ddlPrjCode.SelectedIndex;
        //}
        //else if (ddlTndrNo.SelectedIndex != 0)
        //    _addJob.prjCode = ddlTndrNo.SelectedItem.Text;
        //else if (ddlCommitNo.SelectedIndex != 0)
        //    _addJob.prjCode = ddlCommitNo.SelectedItem.Text;
        

        //_addJob.commitmentNo = txtCmtNo.Text;        
      
        _addJob.tenderNo =  "";

        _addJob.prjTitle = txtPrjTitle.Text;
        _addJob.jobDesc = txtJobTitle.Text;

        _addJob.qsID = 0; _addJob.ceID = 0; _addJob.peID = 0;
        
        _addJob.addendumNO = 0;

        //_addJob.contractTypeID = 1; // Supervision 

        _addJob.contractTypeID = Convert.ToInt32(Session["TCMS_CntrTypeID"]); // Supervision 

        if (ddlDocRef.SelectedIndex != 0)
            _addJob.docRefID = Convert.ToInt32(ddlDocRef.SelectedValue);
        
        _addJob.gradeID = 0;

        if (ddlInchargeType.SelectedIndex == 1)
            _addJob.qsID = Convert.ToInt32(Session["UserID"]);
        else if (ddlInchargeType.SelectedIndex == 2)
            _addJob.peID = Convert.ToInt32(Session["UserID"]);
        else if (ddlInchargeType.SelectedIndex == 3)
            _addJob.ceID = Convert.ToInt32(Session["UserID"]);
        else if (ddlInchargeType.SelectedIndex == 4)
            _addJob.dcID = Convert.ToInt32(Session["UserID"]);
        else
            _addJob.dcID = Convert.ToInt32(Session["UserID"]);

        _addJob.actionDueDate = Convert.ToDateTime(txtDueDate.Text).ToString("dd/MMM/yyyy");

        _addJob.daysToAct = 0;

        _addJob.jobCreatedByID = Convert.ToInt32(Session["UserID"]);
        _addJob.SectionID = Convert.ToInt32(Session["SectionID"].ToString());

        _addJob.JobReceivedDate = Convert.ToDateTime(txtRecDate.Text).ToString("dd/MMM/yyyy");

        _addJob.staffRoleID = Convert.ToInt32(ddlInchargeType.SelectedValue);

        //_addJob.jobPurposeID = Convert.ToInt32(ddlJobPurpose.SelectedValue);

        //if (ddlJobPurpose.SelectedValue == "1")
        //{
        //    _addJob.inchargeActionDueDate = Convert.ToDateTime(getEndDateByGivenDays(1, txtRecDate.Text)).ToString();
        //    _addJob.inchargeWorkDays = 1;
        //}
        //else
        //{
            _addJob.inchargeActionDueDate = Convert.ToDateTime(txtDueDate.Text).ToString();
            _addJob.inchargeWorkDays = Convert.ToInt32(7);
        //}


        //_addJob.commitmentNo = ddlCommitNo.SelectedItem.Text;             //txtCmtNo.Text;

      

      //  _addJob.projectCode = ddlPrjCode.SelectedItem.Text;

        //_addJob.projectCode = ddlTndrNo.SelectedItem.Text;

        //if (_addJob.commitmentNo != "")
        //    _addJob.projectCode = _addJob.commitmentNo;

      //  _addJob.tssRemarks = txtRemarks.Text;

        string jobNoID = InsertJobOrder(_addJob, Session["UserName"].ToString(), _docID);

        return jobNoID;

    }
    public string InsertJobOrder(JobOrderProperty _insrttData, string userName, int _outDocID)
    {
        List<string> projData = Session["sessprjColl"] as List<string>;

        SqlConnection con = new SqlConnection(connValue);
        SqlCommand cmd = new SqlCommand();
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Connection = con;
        cmd.CommandText = "CreateTSSJob";   // SP

        //cmd.Parameters.AddWithValue("@jobID", _insrttData.jobID);

        //cmd.Parameters.AddWithValue("@jobNo", SqlDbType.NVarChar).Direction = ParameterDirection.Output;
        //cmd.Parameters.AddWithValue("@jobID", SqlDbType.Int).Direction = ParameterDirection.Output;

        cmd.Parameters.AddWithValue("@jobNo", "");
        cmd.Parameters.AddWithValue("@jobID", "");
        //cmd.Parameters.AddWithValue("@jobNo", _insrttData.jobNo);

        // we have to Change below code
        //if (_insrttData.jobTypeID != 0)
        //{
        //    cmd.Parameters.AddWithValue("@jobTypeID", _insrttData.jobTypeID);
        //    cmd.Parameters.AddWithValue("@jobCatID", _insrttData.jobCatID);
        //}
        //else
        //{
            cmd.Parameters.AddWithValue("@jobCatID", _insrttData.jobCatID);
            cmd.Parameters.AddWithValue("@jobTypeID", _insrttData.jobTypeID);
        //}

        if (_insrttData.affID != 0)
            cmd.Parameters.AddWithValue("@affairID", _insrttData.affID);
        else
            cmd.Parameters.AddWithValue("@affairID", System.DBNull.Value);

        if (_insrttData.deptID != 0)
            cmd.Parameters.AddWithValue("@deptID", _insrttData.deptID);
        else
            cmd.Parameters.AddWithValue("@deptID", System.DBNull.Value);

        //if (_insrttData.commitmentNo != "" & _insrttData.commitmentNo != null)
        //    cmd.Parameters.AddWithValue("@contractNo", System.DBNull.Value); else
       
        cmd.Parameters.AddWithValue("@projectTitle", _insrttData.prjTitle);
        cmd.Parameters.AddWithValue("@jobDesc", _insrttData.jobDesc);
        
        if (_insrttData.contractorID != 0)
            cmd.Parameters.AddWithValue("@contractorID", _insrttData.contractorID);
        else
            cmd.Parameters.AddWithValue("@contractorID", System.DBNull.Value);

        if (_insrttData.jobCatID != 1)
            cmd.Parameters.AddWithValue("@jobStatusID", 3); // 3==On-going
        else
            cmd.Parameters.AddWithValue("@jobStatusID", 8);       // Under EBSD for PSA          
        
        cmd.Parameters.AddWithValue("@docRefID", _insrttData.docRefID);

        if (_insrttData.addendumNO != 0)
            cmd.Parameters.AddWithValue("@addendumNO", _insrttData.addendumNO);
        else
            cmd.Parameters.AddWithValue("@addendumNO", System.DBNull.Value);

        if (_insrttData.jobCatID == 1)        // PSA
            cmd.Parameters.AddWithValue("@contractTypeID", 1); // Supervision
        else
            cmd.Parameters.AddWithValue("@contractTypeID", System.DBNull.Value);    //any
        
        if (_insrttData.gradeID != 0)
            cmd.Parameters.AddWithValue("@gradeID", _insrttData.gradeID);
        else
            cmd.Parameters.AddWithValue("@gradeID", System.DBNull.Value);

        if (_insrttData.qsID != 0)
            cmd.Parameters.AddWithValue("@qsID", _insrttData.qsID);
        else
            cmd.Parameters.AddWithValue("@qsID", System.DBNull.Value);

        if (_insrttData.peID != 0)
            cmd.Parameters.AddWithValue("@peID", _insrttData.peID);
        else
            cmd.Parameters.AddWithValue("@peID", System.DBNull.Value);

        if (_insrttData.ceID != 0)
            cmd.Parameters.AddWithValue("@ceID", _insrttData.ceID);
        else
            cmd.Parameters.AddWithValue("@ceID", System.DBNull.Value);

        if (_insrttData.dcID != 0)
            cmd.Parameters.AddWithValue("@dcID", _insrttData.dcID);
        else
            cmd.Parameters.AddWithValue("@dcID", System.DBNull.Value);

        cmd.Parameters.AddWithValue("@actionDueDate", Convert.ToDateTime(_insrttData.actionDueDate).ToString("dd/MMM/yyyy"));
        cmd.Parameters.AddWithValue("@workDays", _insrttData.daysToAct);

        cmd.Parameters.AddWithValue("@JobDueDate", Convert.ToDateTime(_insrttData.actionDueDate).ToString("dd/MMM/yyyy"));
        cmd.Parameters.AddWithValue("@jobCreatedByID", _insrttData.jobCreatedByID);

        cmd.Parameters.AddWithValue("@SectionID", _insrttData.SectionID);

        cmd.Parameters.AddWithValue("@JobReceivedDate", Convert.ToDateTime(_insrttData.JobReceivedDate).ToString("dd/MMM/yyyy"));

        cmd.Parameters.AddWithValue("@createDate", System.DateTime.Now.ToString("dd/MMM/yyyy"));
        cmd.Parameters.AddWithValue("@createUser", userName);

        cmd.Parameters.AddWithValue("@StaffRoleID", _insrttData.staffRoleID); // pass value need

        //  cmd.Parameters.AddWithValue("@docID", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

        cmd.Parameters.AddWithValue("@docID", _outDocID);
        //cmd.Parameters.AddWithValue("@jobPurposeID", _insrttData.jobPurposeID);


        cmd.Parameters.AddWithValue("@inchargeDueDate", Convert.ToDateTime(_insrttData.inchargeActionDueDate).ToString("dd/MMM/yyyy"));
        cmd.Parameters.AddWithValue("@daysToAct", _insrttData.inchargeWorkDays);


        cmd.Parameters.AddWithValue("@jobOwnerStatusID", 7);//7==Completed
        cmd.Parameters.AddWithValue("@docCreatedByID", System.DBNull.Value);

        cmd.Parameters.AddWithValue("@originID", System.DBNull.Value);
        cmd.Parameters.AddWithValue("@jobOwnerID", System.DBNull.Value);
        cmd.Parameters.AddWithValue("@docReceivedDate", System.DBNull.Value);

        cmd.Parameters.AddWithValue("@docDate", System.DBNull.Value);

        if (projData != null)
            cmd.Parameters.AddWithValue("@ministryCode", projData[1].ToString());
        else
            cmd.Parameters.AddWithValue("@ministryCode", System.DBNull.Value);

        if (projData != null)
            cmd.Parameters.AddWithValue("@budgetRefNo", projData[2].ToString());
        else
            cmd.Parameters.AddWithValue("@budgetRefNo", System.DBNull.Value);

        if (projData != null)
            cmd.Parameters.AddWithValue("@provisionNo", projData[3].ToString());
        else
            cmd.Parameters.AddWithValue("@provisionNo", System.DBNull.Value);


        //cmd.Parameters.AddWithValue("@JobID", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

        // For DCLog

        if (Session["SectionID"].Equals("3"))
            cmd.Parameters.AddWithValue("@projStstusID", 3);
        else
            cmd.Parameters.AddWithValue("@projStstusID", System.DBNull.Value); // projStstusID

        //if (_insrttData.commitmentNo != null)
        //    cmd.Parameters.AddWithValue("@committmentNo", _insrttData.commitmentNo);
        //else
        //cmd.Parameters.AddWithValue("@committmentNo", System.DBNull.Value);

        if (txtPrjCode.Text != null)
        {
            cmd.Parameters.AddWithValue("@projectCode", txtPrjCode.Text);
        }
        else
        {
            cmd.Parameters.AddWithValue("@projectCode", System.DBNull.Value);
        }
        //else if (ddlPrjCode.SelectedItem == null)
        //{
        //    cmd.Parameters.AddWithValue("@projectCode", ddlPrjCode.Text);
        //}        
        //if (ddlTndrNo.SelectedIndex !=0)
        //    cmd.Parameters.AddWithValue("@tenderNo", ddlTndrNo.SelectedItem.Text);
        //else
        //    cmd.Parameters.AddWithValue("@tenderNo", System.DBNull.Value);
       
        cmd.Parameters.AddWithValue("@contractNo", System.DBNull.Value);         

        if (txtRemarks.Text != "")
        {
            cmd.Parameters.AddWithValue("@remarks", txtRemarks.Text);
        }
        else
            cmd.Parameters.AddWithValue("@remarks", System.DBNull.Value);
        string jobNo = null, jobID = null;
        try
        {
            con.Open();
            SqlDataReader sqlDtReader = cmd.ExecuteReader();
            if (sqlDtReader.Read())
            {
                jobNo = sqlDtReader["jobNo"].ToString();
                jobID = sqlDtReader["jobID"].ToString();                 
            }
            else
            {
                jobNo = null;
                jobID = null;
            }
            
            con.Dispose();
        }
        catch (Exception ex)
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "Popup", "<script>alert('Error Occurred while inserting or retrieving the TSS Job data from the database')</script>", false);
        }
        finally
        {
            con.Close();
        }

        if (jobNo != null)
        {
            jobNo = jobNo + "," + jobID;
        }
        return jobNo;

        // return _insrttData.jobID;
    }
    private string getEndDateByGivenDays(int _days, string strDate)
    {
        SqlConnection con = new SqlConnection(connValue);
        SqlCommand cmd = new SqlCommand();
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Connection = con;

        cmd.CommandText = "AddWorkdays";
        SqlParameter prm = cmd.Parameters.Add("@ad_startDate", SqlDbType.DateTime);
        prm.Value = strDate;
        prm = cmd.Parameters.Add("@actual_workDays", SqlDbType.Int);
        prm.Value = Convert.ToInt32(_days);
        prm = cmd.Parameters.Add("@endDate", SqlDbType.DateTime);
        prm.Direction = ParameterDirection.Output;
        con.Open();
        SqlDataReader dr = cmd.ExecuteReader();
        while (dr.Read())
            Console.WriteLine(dr.GetString(0));
        con.Dispose();
        con.Close();

        return cmd.Parameters[2].Value.ToString();
    }
    //protected void txtCmtNo_TextChanged(object sender, EventArgs e)
    //{
    //    List<string> contractColl = new List<string>();

    //    contractColl = new JobOrderData().getVendorData(Convert.ToInt32(ddlCommitNo.SelectedValue));       
    //    txtPrjTitle.Text = contractColl[0];
    //    ddlVendor.SelectedValue = contractColl[4];     

    //    ddlDept.SelectedValue = geteBookDept(Convert.ToInt16(contractColl[10])).ToString();
    //}
    private int geteBookDept(int tcmsDept)
    {
        int eBookDept = 0;
      //  string sqlQuery = "SELECT departmentID From Department where tcmsDeptID = " + tcmsDept + "";

        string sqlQuery =  "SELECT d2.departmentID,d2.deptName,d1.deptName From " +
        " Department d1 INNER JOIN Department d2 On d2.departmentID = d1.newDeptID where d1.tcmsDeptID = " + tcmsDept + "";


        try
        {
            using (SqlConnection con = new SqlConnection(connValue))
            {
                con.Open();
                SqlCommand sqlCom = new SqlCommand(sqlQuery, con);
                SqlDataReader sqlReader = sqlCom.ExecuteReader();
                while (sqlReader.Read())
                {
                    eBookDept = Convert.ToInt32(sqlReader["departmentID"]);
                }
                sqlReader.Close();
            }
        }
        catch (Exception ex)
        {
            // Response.Write("Error getting while reading data !" + ex.Message);
        }
        finally
        {

        }
        return eBookDept;
    }

    List<string> contractColl = new List<string>();
    //protected void ddlCommitNo_SelectedIndexChanged(object sender, EventArgs e)
    //{
    //    //if (ddlCommitNo.SelectedIndex != 0)
    //    //{
    //    //    txtPrjNo.Text = "";
    //    //    trlblPrjCode.Visible = false;
    //    //    trPrjID.Visible = false;
    //    //    trtxtPrjID.Visible = false;

    //    //    txtTndrNo.Text = "";
    //    //    trlblTndrNo.Visible = false;
    //    //    trtxtTndrNo.Visible = false;
    //    //    trTndrNo.Visible = false;
    //    //}
    //    //else
    //    //{
    //    //    checkCategoryStausForControls();
    //    //}

    //    string companyNameID = string.Empty;
    //    if (ddlCommitNo.SelectedValue != "")
    //    {
    //        //txtPrjTitle.Text = new JobOrderData().getVendorName(Convert.ToInt32(ddlCommitNo.SelectedValue), ref companyNameID);

    //        if (!ddlCommitNo.SelectedValue.Equals("N/A"))
    //        {
    //            contractColl = new JobOrderData().getVendorData(Convert.ToInt32(ddlCommitNo.SelectedValue));

    //            Session["sessprjColl"] = contractColl;
    //            txtPrjTitle.Text = contractColl[0];

    //            ddlVendor.SelectedValue = contractColl[4];

    //            // ddlPrjCode.SelectedIndex = 0;        

    //            ddlDept.SelectedValue = geteBookDept(Convert.ToInt16(contractColl[10])).ToString();

    //            Session["TCMS_CntrTypeID"] = contractColl[11];

    //            txtCmtNo.Text = contractColl[1];
    //        }

    //        ddlPrjCode.SelectedIndex = -1;
    //        ddlTndrNo.SelectedIndex = -1;
    //    }
    //    ddlPrjCode.Text = ddlPrjCode.Text;
    //}
    static string deptCoordEmailID = null;
    protected void ddlDocRef_SelectedIndexChanged(object sender, EventArgs e)
    {
        //  documentChangeEvent();        
        FillDeptProjDetails();
    }

    private void FillDeptProjDetails()
    {
        if (txtRecDate.Text != "")
        {
            string endDate = getEndDateByGivenDays(7, txtRecDate.Text);
            txtDueDate.Text = Convert.ToDateTime(endDate).ToString("dd/MMM/yyyy");
        }
        else
        {
            string endDate = getEndDateByGivenDays(7, System.DateTime.Now.ToString());
            txtDueDate.Text = Convert.ToDateTime(endDate).ToString("dd/MMM/yyyy");            
        }
        if (ddlDocRef.SelectedItem.Text != "")
        {
            SqlConnection conn = null;
            try
            {
                using (conn = new SqlConnection(connValue))
                {
                    conn.Open();
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        cmd.Connection = conn;
                        //cmd.CommandText = "SELECT Contact.emailAddress,[Document].originCompanyID,Company.cmpName,[Document].docContent FROM [Document] full outer JOIN Contact ON [Document].deptCoordContactID = Contact.contactID full outer join Company ON [Document].originCompanyID = Company.companyID WHERE  ([Document].isDocActive = 1) and" +
                        //" [Document].referenceNo=@docRefNo ORDER BY [Document].createDate";
                        cmd.CommandText = "SELECT Document.deptCoordEmailID,[Document].originCompanyID,Company.cmpName,[Document].docContent,[Document].isEOI,[Document].isPreQual FROM [Document] INNER JOIN Contact ON [Document].originContactID = Contact.contactID " +
                        "join Company ON [Document].originCompanyID = Company.companyID WHERE ([Document].isDocActive = 1) and [Document].referenceNo=@docRefNo ORDER BY [Document].createDate"; //AND (Contact.sectionID Not in(2,1,3))
                        cmd.Parameters.AddWithValue("@docRefNo", ddlDocRef.SelectedItem.Text);
                        using (SqlDataReader sqlDtReader = cmd.ExecuteReader())
                        {
                            if (sqlDtReader.Read())
                            {
                                txtJobTitle.Text = sqlDtReader["docContent"].ToString();
                                string cmpName = sqlDtReader["cmpName"].ToString();
                                string val = null;
                                if (cmpName.Contains("PWA"))
                                {
                                    try
                                    {
                                        string deptName = null;
                                        if (cmpName.Contains("-"))
                                        {
                                            deptName = cmpName.Split('-')[1];
                                        }
                                        else
                                        {
                                            deptName = cmpName.Split(' ')[1];
                                        }
                                        if (deptName.Contains("Assets"))
                                        {
                                            val = ddlDept.Items.FindByText("Asset Affairs").Value;
                                            if (val != null)
                                            {
                                                ddlDept.SelectedValue = val;
                                            }
                                        }
                                        else if (deptName.Contains("Quality"))
                                        {
                                            val = ddlDept.Items.FindByText("Quality and Safety Department").Value;
                                            if (val != null)
                                            {
                                                ddlDept.SelectedValue = val;
                                            }
                                        }
                                        else if (deptName.Contains("Public"))
                                        {
                                            val = ddlDept.Items.FindByText("Public Relation & Communication Department").Value;
                                            if (val != null)
                                            {
                                                ddlDept.SelectedValue = val;
                                            }
                                        }
                                        else if (deptName.Contains("President's"))
                                        {
                                            val = ddlDept.Items.FindByText("Presidents Office").Value;
                                            if (val != null)
                                            {
                                                ddlDept.SelectedValue = val;
                                            }
                                        }
                                        else if (deptName.Contains("Engineering"))
                                        {                                             
                                            val = ddlDept.Items.FindByText("Engineering Services Department").Value;
                                            if (val != null)
                                            {
                                                ddlDept.SelectedValue = val;
                                            }                                             
                                        }
                                        else if (deptName.Contains("Drainage"))
                                        {
                                            val = ddlDept.Items.FindByText("Drainage Network Projects Department").Value;
                                            if (val != null)
                                            {
                                                ddlDept.SelectedValue = val;
                                            }
                                        }
                                        else if (deptName.Contains("Roads"))
                                        {
                                            val = ddlDept.Items.FindByText("Roads Projects Department").Value;
                                            if (val != null)
                                            {
                                                ddlDept.SelectedValue = val;
                                            }
                                        }
                                        else if (deptName.Contains("Highway"))
                                        {
                                            val = ddlDept.Items.FindByText("Highway Projects Department").Value;
                                            if (val != null)
                                            {
                                                ddlDept.SelectedValue = val;
                                            }
                                        }
                                        else if (deptName.Contains("Design"))
                                        {
                                            val = ddlDept.Items.FindByText("Designs Department").Value;
                                            if (val != null)
                                            {
                                                ddlDept.SelectedValue = val;
                                            }
                                        }
                                        else if (deptName.Contains("Buildings"))
                                        {
                                            val = ddlDept.Items.FindByText("Building Projects Department").Value;
                                            if (val != null)
                                            {
                                                ddlDept.SelectedValue = val;
                                            }
                                        }
                                        else if (deptName.Contains("Expressway"))
                                        {
                                            val = ddlDept.Items.FindByText("Projects Affairs").Value;
                                            if (val != null)
                                            {
                                                ddlDept.SelectedValue = val;
                                            }
                                        }
                                    }
                                    catch (Exception)
                                    {

                                    }
                                }
                                else
                                {
                                    try
                                    {
                                        val = ddlDept.Items.FindByText(cmpName).Value;
                                        if (val != null)
                                        {
                                            ddlDept.SelectedValue = val;
                                        }
                                        //ddlDept.SelectedValue = sqlDtReader["originCompanyID"].ToString();
                                    }
                                    catch (Exception)
                                    {

                                    }
                                }
                                deptCoordEmailID = sqlDtReader["deptCoordEmailID"].ToString();
                                string isEoi = sqlDtReader["isEOI"].ToString();
                                string isPreQual = sqlDtReader["isPreQual"].ToString();
                                if (isEoi == "True")
                                {
                                    ddlJobType.SelectedValue = "113";
                                }
                                else if (isPreQual == "True")
                                {
                                    ddlJobType.SelectedValue = "114";
                                }
                                else
                                {
                                    ddlJobType.SelectedValue = "114";
                                }
                                ddlJobType.Enabled = false;
                                sqlDtReader.Close();
                                cmd.CommandText = "SELECT projectCode,projectTitle FROM [DocumentProjectAttributes] WHERE ([documentID] = @docID)";
                                cmd.Parameters.AddWithValue("@docID", ddlDocRef.SelectedValue);
                                using (SqlDataReader sqlDtReader1 = cmd.ExecuteReader())
                                {
                                    if (sqlDtReader1.Read())
                                    {
                                        txtPrjTitle.Text = sqlDtReader1["projectTitle"].ToString();
                                        txtPrjCode.Text = sqlDtReader1["projectCode"].ToString();
                                    }
                                    sqlDtReader1.Close();
                                }

                            }
                        }
                    }
                }
            }
            catch (Exception)
            {
                ClientScript.RegisterClientScriptBlock(this.GetType(), "Popup", "<script>alert('Error Occurred while retrieving the data from the database')</script>", false);
            }
            finally
            {
                conn.Close();
            }
        }
    }
    private void documentChangeEvent()
    {
        if (ddlDocRef.SelectedIndex != 0)
        {
            //Session["DocRecDate"] = getDocReceivedDate(Convert.ToInt32(ddlDocRef.SelectedValue));
            //txtRecDate.Text = getDocReceivedDate(Convert.ToInt32(ddlDocRef.SelectedValue));

            //WorkingDaysCaluclationByGrade(txtRecDate.Text);


        }
        else
            txtRecDate.Text = System.DateTime.Now.ToString();

    }
    List<string> prjColl = new List<string>();
    protected void ddlPrjCode_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (txtPrjCode.Text != "")
        {
            prjColl = new JobOrderData().getProjectData(Convert.ToInt32(txtPrjCode.Text));
            if (prjColl.Count > 0)
            {
                Session["sessprjColl"] = prjColl;
                txtPrjTitle.Text = prjColl[0];
            }
           
            //ddlCommitNo.SelectedIndex = 0;
            ddlDept.SelectedValue = geteBookDept(Convert.ToInt16(prjColl[6])).ToString();       
            Session["TCMS_CntrTypeID"] = prjColl[5];

            //ddlCommitNo.SelectedIndex = -1;
            //ddlTndrNo.SelectedIndex = -1;   
        }
         
    }
    //protected void ddlTndrNo_SelectedIndexChanged(object sender, EventArgs e)
    //{
    //    if (ddlTndrNo.SelectedValue != "")
    //    {
    //        prjColl = new JobOrderData().getProjectData(Convert.ToInt32(ddlTndrNo.SelectedValue));
    //        if (prjColl.Count > 0)
    //        {
    //            Session["sessprjColl"] = prjColl;
    //            txtPrjTitle.Text = prjColl[0];
    //        }

    //        //ddlCommitNo.SelectedIndex = 0;
    //        ddlDept.SelectedValue = geteBookDept(Convert.ToInt16(prjColl[6])).ToString();
    //        Session["TCMS_CntrTypeID"] = prjColl[5];

    //        txtPrjCode.Text = "";
    //        //ddlCommitNo.SelectedIndex = -1;

    //    }
    //    //ddlPrjCode.Text = ddlPrjCode.Text;
    //}


    protected void btnBack_Click(object sender, EventArgs e)
    {
        if (Session["UserName"] == null)
        {
            Response.Redirect("~/LoginPage.aspx", false);
            return;
        }
        Session["UrlRef"].ToString().Replace("~", "/ebookTSS");
        Response.Redirect(Session["UrlRef"].ToString());
    }
}