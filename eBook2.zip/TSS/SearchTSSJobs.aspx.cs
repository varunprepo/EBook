﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using Datalayer;
using System.Web.UI.HtmlControls;
using System.IO;
using System.Drawing;
using System.Data.SqlClient;

public partial class TSS_SearchTSSJobs : System.Web.UI.Page
{
    string connValue = System.Configuration.ConfigurationManager.ConnectionStrings["EBSDEBookConn"].ConnectionString;
    string _prjCode = string.Empty; string flag = string.Empty;
    
    string _userName = string.Empty; int cntID = 0;
    static IList<string> userRightsColl = null;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["UserName"] == null)
        {
            Response.Redirect("~/LoginPage.aspx", false);
            return;
        }        

        if (!IsPostBack)
        {
            DataTable dt = new DataTable();
            userRightsColl = (IList<string>)Session["UserRightsColl"];
            lblUser.Text = Session["UserDisplayName"].ToString();
            lblUserDesignation.Text = Session["UserDesignation"].ToString();
            lblUserProfile.Text = Session["ProfileName"].ToString();
            if (Session["ProjectCode"] != null)
                _prjCode = Session["ProjectCode"].ToString(); // Request.QueryString["ProjCode"];      

            if (Session["Flag"] != null)
                flag = Session["Flag"].ToString();

            cntID = new JobOrderData().getUserID(_userName);
            int sectionID = Convert.ToInt16(Session["SectionID"]);
            FillDropBox(sectionID);
            DataView dvCommitted = new DataView();
            if (_prjCode == null)
            {
                dt = FillTab2(0, "");     //  SearchJob
                dt = AddTotalVendorsColumn(dt);
                Session["TSSJobs"] = dt;
                gvJoborder.DataSource = dt;
                gvJoborder.DataBind();

                FillTabByJobNo(0, "","");

                lblCnt.Text = dt.Rows.Count.ToString();
            }
            else
            {
                dt = FillTab2(0, _prjCode);
                dt = AddTotalVendorsColumn(dt);
                Session["TSSJobs"] = dt;
                gvJoborder.DataSource = dt;
                gvJoborder.DataBind();

                lblCnt.Text = dt.Rows.Count.ToString();
            }
        }
    }

    protected void lnkLogOutBtn_Click(object sender, EventArgs e)
    {
        Session["UserName"] = null;
        Response.Redirect("~/LoginPage.aspx", false);
    }
    public void FillDropBox(int _sectionID)
    {
        PopulateDropDownBox(ddlJobType, "SELECT DISTINCT JobType.jobTypeID, JobType.jobTypeName FROM JobType INNER JOIN Job ON JobType.jobTypeID = Job.jobTypeID WHERE (JobType.CategoryID IN (112)) and Job.sectionID=" + _sectionID + " ORDER BY JobType.jobTypeName", "jobTypeID", "jobTypeName");

        PopulateDropDownBox(ddlJobStatus, "SELECT jobStatusID, jobStatusName FROM JobStatus where jobStatusID in(1,2,3,4,5,6,7) ORDER BY jobStatusName", "jobStatusID", "jobStatusName");

        PopulateDropDownBox(ddlAffair, "SELECT  affairID, affairName FROM Affair WHERE (isActive=1) ORDER BY affairName", "affairID", "affairName");

        PopulateDropDownBox(ddlDept, "SELECT departmentID, deptName FROM Department WHERE (isActive=1) ORDER BY deptName", "departmentID", "deptName");

        PopulateDropDownBox(ddlVendor, "SELECT DISTINCT Company.companyID, Company.cmpName FROM Job INNER JOIN Company ON Job.consultantID = Company.companyID INNER JOIN JobType ON Job.jobTypeID = JobType.jobTypeID WHERE  (JobType.CategoryID IN (112)) ORDER BY Company.cmpName", "companyID", "cmpName");

        string strCntr = "SELECT DISTINCT Company.companyID, Company.cmpName FROM   Job INNER JOIN Company ON Job.contractorID = Company.companyID INNER JOIN JobType ON Job.jobTypeID = JobType.jobTypeID WHERE  (JobType.CategoryID IN (112)) ORDER BY Company.cmpName";
        PopulateDropDownBox(ddlContractor, strCntr, "companyID", "cmpName");

        PopulateDropDownBoxQS(ddlQS, "SELECT DISTINCT Contact.contactID, Contact.userShortName FROM JobOwner INNER JOIN  Contact ON JobOwner.contactID = Contact.contactID WHERE (JobOwner.sectionID ="+ _sectionID+")", "ContactID", "userShortName");

        //PopulateDropDownBox(ddlPrjCode, "SELECT DISTINCT Job.contractNo, Job.contractNo  FROM job INNER JOIN JobType ON Job.jobTypeID = JobType.jobTypeID WHERE    (JobType.CategoryID IN (8)) ORDER BY Job.contractNo", "contractNo", "contractNo");

        PopulateDropDownBox(ddlPrjCode, "SELECT ISNULL(contractNo, committmentNo) AS projectCode FROM Job WHERE  (sectionID = " + _sectionID + ") ORDER BY projectCode", "projectCode", "projectCode");

        //PopulateDropDownBox(ddlReqType, "SELECT reqStatusID, reqStatusName FROM DCRequestStatus  ORDER BY reqStatusName", "reqStatusID", "reqStatusName");
    }

    private void PopulateDropDownBoxQS(DropDownList ddlBox, string sqlQuery, string valueMember, string displayName)
    {

        ddlBox.DataSource = new JobOrderData().FillDropdown(sqlQuery);
        ddlBox.DataTextField = displayName;
        ddlBox.DataValueField = valueMember;
        ddlBox.SelectedIndex = -1;
        ddlBox.DataBind();


        ListItem emptyItem123 = new ListItem("ALL", "ALL");
        ddlBox.Items.Insert(0, emptyItem123);

        ListItem emptyItem = new ListItem("", "");
        ddlBox.Items.Insert(0, emptyItem);

    }

    protected void ddlBox_DataBound(object sender, EventArgs e)
    {
        DropDownList ddl = (DropDownList)sender;
        ListItem emptyItem = new ListItem("", "");
        ddl.Items.Insert(0, emptyItem);
    }

    private void PopulateDropDownBox(DropDownList ddlBox, string sqlQuery, string valueMember, string displayName)
    {
        ddlBox.DataBound += new EventHandler(this.ddlBox_DataBound);
        ddlBox.DataSource = new JobOrderData().FillDropdown(sqlQuery);
        ddlBox.DataTextField = displayName;
        ddlBox.DataValueField = valueMember;
        ddlBox.SelectedIndex = -1;
        ddlBox.DataBind();
    }
    //protected void lnkProjectCodeCmted_Click(object sender, EventArgs e)     //ForCommitted
    //{
    //    try
    //    {
    //        LinkButton lnkJobID = (LinkButton)sender;
    //        GridViewRow gvr = (GridViewRow)lnkJobID.NamingContainer;
    //        Session["ProjectCode"] = ((HtmlGenericControl)gvr.FindControl("divProjectCodeCmted")).InnerText;

    //        Session["UrlRef"] = Request.Url.AbsoluteUri;
    //        Response.Redirect("~/JobOrder/SearchJobMstr.aspx?Project_Code = " + Session["ProjectCode"] + "", false);
    //    }
    //    catch
    //    {

    //    }
    //}
    protected void lnkJobOrderJobNo_Click(object sender, EventArgs e)     //ForCommitted
    {
        try
        {
            LinkButton lnkJobID = (LinkButton)sender;
            GridViewRow gvr = (GridViewRow)lnkJobID.NamingContainer;

            Session["JobID"] = ((HtmlGenericControl)gvr.FindControl("divJobID")).InnerText.Trim();
            Session["DocID"] = ((HtmlGenericControl)gvr.FindControl("divDocID")).InnerText.Trim();
            Session["JobNo"] = ((HtmlGenericControl)gvr.FindControl("divJobNo")).InnerText.Trim();
            Session["JobTypeID"] = ((HtmlGenericControl)gvr.FindControl("divJobTypeID")).InnerText.Trim();
            if (Session["UserProfileID"].Equals("26")) //26=="EOIAdmin"
            {
                try
                {
                    Session["IsViewVendors"] = ((Label)gvr.FindControl("lblTotalVendors")).Text.Trim();
                }
                catch (Exception)
                {
                  
                }
            }
            //lblTotalVendors
            Session["UrlRef"] = Request.Url.AbsoluteUri;
            Response.Redirect("~/TSS/TSSJobDetails.aspx?JobID= " + Session["JobID"] + "", false);

        }
        catch
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Error Occurred while opening the TSS Job details')</script>", false);
        }
    }
    protected void lnkEOINumber_Click(object sender, EventArgs e)     //ForCommitted
    {
        try
        {
            LinkButton lnkEOINumber = (LinkButton)sender;
            GridViewRow gvr = (GridViewRow)lnkEOINumber.NamingContainer;
            Session["JobID"] = ((HtmlGenericControl)gvr.FindControl("divJobID")).InnerText.Trim();            
            Session["JobNo"] = ((HtmlGenericControl)gvr.FindControl("divJobNo")).InnerText.Trim();
            Session["EOINumber"] = ((HtmlGenericControl)gvr.FindControl("divEOINumber")).InnerText.Trim();
            Session["EOIPubDate"] = ((HtmlGenericControl)gvr.FindControl("divEoiPubDate")).InnerText.Trim();
            Session["PrjTitle"] = ((Label)gvr.FindControl("lblTitle")).Text;
            Session["UrlRef"] = Request.Url.AbsoluteUri;
            Response.Redirect("~/TSS/TSSEOIStage.aspx", false);
            //Response.Redirect("~/TSS/TSSEOIStages.aspx?JobID= " + Session["JobID"] + "", false);

        }
        catch(Exception ex)
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Error Occurred while opening the TSS EOI Stages')</script>", false);
        }
    }
    protected void btnBack_Click(object sender, EventArgs e)
    {
        if (Session["UserName"] == null)
        {
            Response.Redirect("~/LoginPage.aspx", false);
            return;
        }
        Response.Redirect(Session["UrlRef"].ToString());
    }
    private DataTable FillTab2(int searchType, string _prjCode)
    {
        DataTable dt = new DataTable();
        DataSet ds = new DataSet();
        try
        {
            Int16 jobid;
            Int16.TryParse("0", out jobid);
            
            Int16 docClsRefID;
            Int16.TryParse("0", out docClsRefID);            

            Int16 ceID;
            Int16.TryParse("0", out ceID);

            Int16 peID;
            Int16.TryParse("0", out peID);            
            
            //string docSubject = string.Empty;
            
            Int16 VOID;
            Int16.TryParse("0", out VOID);

            Int16 EOTID;
            Int16.TryParse("0", out EOTID);

            Int16 afrID;
            if (ddlAffair.SelectedValue != null)
            {
                Int16.TryParse(ddlAffair.SelectedValue, out afrID);
            }
            else
            {
                Int16.TryParse("0", out afrID);
            }

            Int16 dptID;
            if (ddlDept.SelectedValue != null)
            {
                Int16.TryParse(ddlDept.SelectedValue, out dptID);
            }
            else
            {
                Int16.TryParse("0", out dptID);
            }             

            //Int16 consID;
            //Int16.TryParse(ddlVendor.SelectedValue, out consID);

            Int16 jobType;
            if (ddlJobType.SelectedValue != null)
            {
                Int16.TryParse(ddlJobType.SelectedValue, out jobType);
            }
            else
            {
                Int16.TryParse("0", out jobType);
            }

            Int16 jobStatus =0;
            string jobStatuses = null;
            if (Session["ClickOnGoingJobs"] == null)
            {                
                if (ddlJobStatus.SelectedValue != null)
                {
                    Int16.TryParse(ddlJobStatus.SelectedValue, out jobStatus);                    
                }
                else
                {
                    Int16.TryParse("0", out jobStatus);
                }
                jobStatuses = jobStatus.ToString();
            }
            else
            {
                jobStatuses = "3,8";
            }

            Int16 docRefID;
            if (txtDocRefNo.Text!= "")
            {
                Int16.TryParse(txtDocRefNo.Text, out docRefID);
            }
            else
            {
                Int16.TryParse("0", out docRefID);
            }
             
            Int16 qsID;
            Int16.TryParse("0", out qsID);

            Int16 contactID;
            if (ddlQS.SelectedValue == "")
                Int16.TryParse(Session["UserID"].ToString(), out contactID);
            else if (ddlQS.SelectedValue == "ALL")
                Int16.TryParse("0", out contactID);
            else
            {
                qsID = 0;
                Int16.TryParse(ddlQS.SelectedValue, out contactID);
            }            

            string prjTitle = string.Empty;
            if (txtTitle.Text != "")
                prjTitle = "%" + txtTitle.Text + "%";

            Int16 cntrID;
            if (ddlContractor.SelectedValue != null)
            {
                Int16.TryParse(ddlContractor.SelectedValue, out cntrID);
            }
            else
            {
                Int16.TryParse("0", out cntrID);
            }

            Int16 consultID;
            if (ddlVendor.SelectedValue != null)
            {
                Int16.TryParse(ddlVendor.SelectedValue, out consultID);
            }
            else
            {
                Int16.TryParse("0", out consultID);
            }

            string prjCode = string.Empty;
            if (_prjCode != "")
            {
                ddlPrjCode.SelectedItem.Text = _prjCode;
                prjCode = _prjCode;
            }
            else
                prjCode = ddlPrjCode.SelectedItem.Text;

            //if (ddlPrjCode.SelectedItem.Text != "")
            //    prjCode = ddlPrjCode.SelectedItem.Text;

            string txtfrom = string.Empty;
            if (txtdept.Text != "")
                txtfrom = txtdept.Text;


            string txtTo = string.Empty;
            if (txtToDate.Text != "")
                txtTo = txtToDate.Text;

            string jobSub = string.Empty;
            if (txtSubject.Text != "")
                jobSub = txtSubject.Text;
            
            string _refNo = string.Empty;

            string _ClsrefNo = string.Empty;

            string _contractNo = string.Empty;                                     
            
            string _jobNo = string.Empty;
            if (txtJobNo.Text != "")
                _jobNo = "%" + txtJobNo.Text + "%";
                        
            if (txtDocRefNo.Text != "")
                _refNo = "%" + txtDocRefNo.Text + "%";
                         
            if (txtPrjNo.Text != "")
                _contractNo = "%" + txtPrjNo.Text + "%";

            string _clsrefNo = string.Empty;
            if (txtClsDocRefNo.Text != "") 
                _clsrefNo = "%" + txtClsDocRefNo.Text + "%";
            //string str = searchType + "," + jobid + "," + jobType + "," + jobStatus + "," + afrID + "," + dptID + "," + docRefID + "," + qsID + "," + ceID + "," + peID + "," + prjTitle + "," + cntrID + "," + consultID + "," + prjCode + "," + txtfrom + "," + VOID + "," + EOTID + "," + docSubject + "," + docClsRefID + "," + txtTo + "," + 0 + "," + 0;             
            //if(Session["IsTSSSearchedClicked"].ToString() == "1")
            //{
                //if ((!userRightsColl.Contains("17")))       // View All On-Going List of Job Orders
                //{
                //    ds = (new JobOrderData().GetJobOrderDetails_Claim(searchType, jobid, jobType, jobStatus, afrID, dptID, docRefID, qsID, ceID, peID, prjTitle, cntrID, consultID, prjCode, txtfrom, VOID, EOTID, jobSub, docClsRefID, txtTo, 0, 0, Convert.ToInt32(Session["SectionID"])));
                //}
                //else
                //{
                //    ds = (new JobOrderData().GetJobOrderDetails_Claim(searchType, jobid, jobType, jobStatus, afrID, dptID, docRefID, qsID, ceID, peID, prjTitle, cntrID, consultID, prjCode, txtfrom, VOID, EOTID, jobSub, docClsRefID, txtTo, 0, Convert.ToInt32(Session["UserID"]), Convert.ToInt32(Session["SectionID"])));
                //}

                //if ((!userRightsColl.Contains("17")))       // View All On-Going List of Job Orders
                //{
            if (Session["ClickOnGoingJobs"]!=null)
            {
                ds = (new JobOrderData().GetJobOrderDetails_TSS("OverDue", jobid, jobType, jobStatuses, afrID, dptID, docRefID, qsID, ceID, peID, prjTitle, cntrID, consultID, prjCode, txtfrom, VOID, EOTID, jobSub, docClsRefID, txtTo, 0, 0));
            }
            else if (contactID == 0)
            {
                if (Session["UserProfileID"].ToString().Contains("26")) //26=="EOIAdmin"
                {
                    //113==Expression of Interest
                    ds = (new JobOrderData().GetJobOrderDetails_TSS("Search", jobid, 113, jobStatuses, afrID, dptID, docRefID, qsID, ceID, peID, prjTitle, cntrID, consultID, prjCode, txtfrom, VOID, EOTID, jobSub, docClsRefID, txtTo, 0, 0));
                }
                else    
                {
                    ds = (new JobOrderData().GetJobOrderDetails_TSS("Search", jobid, jobType, jobStatuses, afrID, dptID, docRefID, qsID, ceID, peID, prjTitle, cntrID, consultID, prjCode, txtfrom, VOID, EOTID, jobSub, docClsRefID, txtTo, 0, 0));
                }
            }
            else
            {
                ds = (new JobOrderData().GetJobOrderDetails_TSS("Search", jobid, jobType, jobStatuses, afrID, dptID, docRefID, qsID, ceID, peID, prjTitle, cntrID, consultID, prjCode, txtfrom, VOID, EOTID, jobSub, docClsRefID, txtTo, 0, contactID));
            }
                //}
                //else
                //{
                //    ds = (new JobOrderData().GetJobOrderDetails_TSS(searchType, jobid, jobType, jobStatus, afrID, dptID, docRefID, qsID, ceID, peID, prjTitle, cntrID, consultID, prjCode, txtfrom, VOID, EOTID, jobSub, docClsRefID, txtTo, 0, Convert.ToInt32(Session["UserID"])));
                //}
                //ds = (new JobOrderData().GetJobOrderDetailsByJobNo(searchType, jobid, jobType, jobStatus, afrID, dptID, docRefID, qsID, ceID, peID, prjTitle, cntrID, consultID, prjCode, txtfrom, jobSub, docClsRefID, _jobNo, _refNo, _contractNo, _ClsrefNo));
                //if ((!userRightsColl.Contains("17")))       // View All On-Going List of Job Orders
                //{
                //    ds = (new JobOrderData().GetTendersServicesDetails(searchType, jobid, jobType, jobStatus, 0, afrID, dptID, docRefID, qsID, ceID, peID, prjTitle, cntrID, consultID, prjCode, txtfrom, VOID, EOTID, jobSub, docClsRefID, txtTo, 0, contactID));
                //}
                //else
                //{
                //    ds = (new JobOrderData().GetTendersServicesDetails(searchType, jobid, jobType, jobStatus, 0, afrID, dptID, docRefID, qsID, ceID, peID, prjTitle, cntrID, consultID, prjCode, txtfrom, VOID, EOTID, jobSub, docClsRefID, txtTo, 0, Convert.ToInt16(Session["UserID"])));
                //}
            //}
            //else if (Session["ShortName"] != null)
            //{
            //    ds = (new JobOrderData().GetTendersServicesDetails(searchType, jobid, jobType, jobStatus, 3,afrID, dptID, docRefID, qsID, ceID, peID, prjTitle, cntrID, consultID, prjCode, txtfrom, VOID, EOTID, jobSub, docClsRefID, txtTo, 0, new JobOrderData().getContactID(Session["ShortName"].ToString())));
            //}
            //else
            //{
            //    ds = (new JobOrderData().GetJobOrderDetails_Claim(searchType, jobid, jobType, jobStatus, afrID, dptID, docRefID, qsID, ceID, peID, prjTitle, cntrID, consultID, prjCode, txtfrom, VOID, EOTID, jobSub, docClsRefID, txtTo, 0, 0, Convert.ToInt32(Session["SectionID"])));
                //ds = (new JobOrderData().GetJobOrderDetailsByJobNo(searchType, jobid, jobType, jobStatus, afrID, dptID, docRefID, qsID, ceID, peID, prjTitle, cntrID, consultID, prjCode, txtfrom, jobSub, docClsRefID, _jobNo, _refNo, _contractNo, _ClsrefNo));
                //ds = (new JobOrderData().GetTendersServicesDetails(searchType, jobid, jobType, jobStatus, 0,afrID, dptID, docRefID, qsID, ceID, peID, prjTitle, cntrID, consultID, prjCode, txtfrom, VOID, EOTID, jobSub, docClsRefID, txtTo, 0, contactID));
            //}

        }
        catch (Exception ex)
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Error occurred while fetching the records for TSS records')</script>", false);
        }

        if(ds.Tables.Count!=0)
        {
            dt = ds.Tables[0];
        }
        return dt;
    }   
    protected void gvJoborder_RowDataBound(object sender, GridViewRowEventArgs e)
    {

    }
    protected void gvJoborder_RowCommand(object sender, GridViewCommandEventArgs e)
    {

    }
    protected void gvJoborder_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        if (Session["UserName"] != null)
        {
            gvJoborder.PageIndex = e.NewPageIndex;
            DataTable dt = new DataTable();
            dt = Session["TSSJobs"] as DataTable;
            gvJoborder.DataSource = dt;
            gvJoborder.DataBind();
            lblCnt.Text = dt.Rows.Count.ToString();
        }
    }
    protected void btnCreateTSSJob_Click(object sender, EventArgs e)
    {
        Session["UrlRef"] = Request.Url.AbsoluteUri;
        Response.Redirect("~/TSS/CreateTSSJob.aspx", false);
    }
    protected void btnDcLog_Click(object sender, EventArgs e)
    {

    }
    protected void txtJobNo_TextChanged(object sender, EventArgs e)
    {
        DataTable dt = new DataTable();
        dt = FindTSSJobDetails();
        if (dt.Rows.Count != 0)
        {
            dt = AddTotalVendorsColumn(dt);
            Session["TSSJobs"] = dt;
            gvJoborder.DataSource = dt;
            gvJoborder.DataBind();
        }
        else
        {
            gvJoborder.DataSource = null;
            gvJoborder.DataBind();
            ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('No TSS Jobs found')</script>", false);
        }        
        lblCnt.Text = dt.Rows.Count.ToString();
    }

    private DataTable FindTSSJobDetails()
    {
        DataTable dt = new DataTable();
        DataSet ds = new DataSet();
        try
        {
            string _jobNo = string.Empty;
            if (txtJobNo.Text != "")
                _jobNo = "%" + txtJobNo.Text + "%";

            string _projTitle = string.Empty;
            if (txtJobTitle.Text != "")
                _projTitle = "%" + txtJobTitle.Text + "%";

            string _refNo = string.Empty;
            if (txtDocRefNo.Text != "")
                _refNo = "%" + txtDocRefNo.Text + "%";

            string _contractNo = string.Empty;
            if (txtPrjNo.Text != "")
                _contractNo = "%" + txtPrjNo.Text + "%";

            string _clsrefNo = string.Empty;
            if (txtClsDocRefNo.Text != "")
                _clsrefNo = "%" + txtClsDocRefNo.Text + "%";

            string _clsEoiNo = string.Empty;
            if (txtEOINo.Text != "")
                _clsEoiNo = "%" + txtEOINo.Text + "%";

            ds = (new JobOrderData().GetTendersServicesDetails_Partial(_jobNo, _projTitle, _refNo, _contractNo, _clsrefNo,_clsEoiNo));   //sp_SearchJobByJobNO
            if (ds.Tables.Count != 0)
            {
                dt = ds.Tables[0];
            }
           
        }
        catch (Exception ex)
        {

        }
        return dt;
    }

    private DataTable FillTabByJobNo(int searchType, string _prjCode,string prjTitle)
    {
        DataSet ds = new DataSet();
        try
        {
            Int16 jobid;
            Int16.TryParse("0", out jobid);

            Int16 afrID;
            Int16.TryParse("0", out afrID);

            Int16 dptID;
            Int16.TryParse("0", out dptID);

            Int16 consID;
            Int16.TryParse("0", out consID);
            
            Int16 jobType;
            Int16.TryParse("0", out jobType);

            Int16 jobStatus;
            Int16.TryParse("0", out jobStatus);

            Int16 docRefID;
            Int16.TryParse("0", out docRefID);

            Int16 docClsRefID;
            Int16.TryParse("0", out docClsRefID);

            Int16 qsID;
            Int16.TryParse("0", out qsID);

            Int16 ceID;
            Int16.TryParse("0", out ceID);

            Int16 peID;
            Int16.TryParse("0", out peID);

            string _prjTitle = string.Empty;
            

            string docSubject = string.Empty;
           

            Int16 cntrID;
            Int16.TryParse("0", out cntrID);

            Int16 consultID;
            Int16.TryParse("0", out consultID);

            string prjCode = string.Empty;

            string txtfrom = string.Empty;
         

            Int16 VOID;
            Int16.TryParse("0", out VOID);

            Int16 EOTID;
            Int16.TryParse("0", out EOTID);


            string _jobNo = string.Empty;
            if (txtJobNo.Text != "")
                _jobNo = "%" + txtJobNo.Text + "%";

            
            if (txtJobTitle.Text != "")
                _prjTitle = "%" + txtJobTitle.Text + "%";

            string _refNo = string.Empty;
            if (txtDocRefNo.Text != "")
            {
                _refNo = txtDocRefNo.Text; 
            }
            string _ClsrefNo = string.Empty;            
            if(txtClsDocRefNo.Text != "")
            {
                _ClsrefNo = txtClsDocRefNo.Text;
            }
            string _contractNo = string.Empty;
            if (txtPrjNo.Text != "")
            {
                _contractNo = txtPrjNo.Text;
            }
            // Cntr_SearchJobByJobNO
            ds = (new JobOrderData().Cntr_GetJobOrderDetailsByJobNo(searchType, jobid, 110, jobStatus, afrID, dptID, docRefID, qsID, ceID, peID, _prjTitle, cntrID, consultID, prjCode, txtfrom, docSubject, docClsRefID, _jobNo, _refNo, _contractNo, _ClsrefNo));   //sp_SearchJobByJobNO

        }
        catch (Exception ex)
        {

        }
        return ds.Tables[0];
    }
    protected void btnHome_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/TSS/TSSHomePage.aspx", false);
    }
    protected void btnExcel_Click(object sender, EventArgs e)
    {
        ExportToExcel_Sree();
    }
    #region MyRegion

    private void ExportToExcel_Sree()
    {
        if (Session["UserName"] == null)
        {
            Response.Redirect("~/LoginPage.aspx", false);
            return;
        }
        if (gvJoborder.Rows.Count != 0)
        {
            Response.Clear();
            Response.Buffer = true;
            Response.AddHeader("content-disposition", "attachment;filename=GridViewExport.xls");
            Response.Charset = "";
            Response.ContentType = "application/vnd.ms-excel";
            using (StringWriter sw = new StringWriter())
            {
                HtmlTextWriter hw = new HtmlTextWriter(sw);

                //To Export all pages
                gvJoborder.AllowPaging = false;

                gvJoborder.DataSource = Session["TSSJobs"];
                gvJoborder.DataBind();

                gvJoborder.HeaderRow.BackColor = Color.White;
                foreach (TableCell cell in gvJoborder.HeaderRow.Cells)
                {
                    cell.BackColor = gvJoborder.HeaderStyle.BackColor;
                }
                foreach (GridViewRow row in gvJoborder.Rows)
                {
                    row.BackColor = Color.White;
                    foreach (TableCell cell in row.Cells)
                    {
                        if (row.RowIndex % 2 == 0)
                        {
                            cell.BackColor = gvJoborder.AlternatingRowStyle.BackColor;
                        }
                        else
                        {
                            cell.BackColor = gvJoborder.RowStyle.BackColor;
                        }
                        cell.CssClass = "textmode";
                    }
                }

                gvJoborder.RenderControl(hw);

                //style to format numbers to string
                string style = @"<style> .textmode { } </style>";
                Response.Write(style);
                Response.Output.Write(sw.ToString());
                Response.Flush();
                Response.End();
            }
        }
        else
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('No rows to export into excel file')</script>", false);
        }
    }
    public override void VerifyRenderingInServerForm(Control control)
    {
        /* Verifies that the control is rendered */
    }

    #endregion
    protected void txtJobTitle_TextChanged(object sender, EventArgs e)
    {
       //  Cntr_SearchJobByJobNO

        //Session["OnGoingJobStatus"] = null;
        try
        {
            DataTable dt = new DataTable();
            dt = FillTabByJobNo(0, "", "");

            //Session["OnGoingJobStatus"] = dt;

            gvJoborder.DataSource = dt;
            gvJoborder.DataBind();

            lblCnt.Text = dt.Rows.Count.ToString();
        }
        catch (Exception)
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Error Occurred while fetching the TSS Jobs')</script>", false);
        }
        
    }

    protected void imgbtn3_Click(object sender, ImageClickEventArgs e)
    {
        Response.Redirect("~/TSS/TSSHomePage.aspx", false);
    }

    protected void Button1_Click(object sender, EventArgs e)
    {

    }
    protected void btnSearch_Click(object sender, EventArgs e)
    {
        try
        {
            Session["TSSJobs"] = null;
            DataTable dt = new DataTable();
            dt = FillTab2(0, "");
            if (dt.Rows.Count != 0)
            {
                dt = AddTotalVendorsColumn(dt);
                Session["TSSJobs"] = dt;
                gvJoborder.DataSource = dt;
                gvJoborder.DataBind();
            }
            else
            {
                ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('No TSS Jobs found')</script>", false);
            }
            lblCnt.Text = dt.Rows.Count.ToString();
        }
        catch (Exception)
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Error Occurred while fetching the TSS Jobs')</script>", false);
        }       
    }

    private DataTable AddTotalVendorsColumn(DataTable dt)
    {
        dt.Columns.Add("TotalVendors");
        dt.AcceptChanges();

        if (Session["UserProfileID"].ToString().Contains("26")) //26=="EOIAdmin" 
        {
            foreach (DataRow row in dt.Rows)
            {
                row[dt.Columns.Count-1] = TotalVendors(row[0].ToString());
                //dt.Rows[0][32] = TotalVendors(row[0].ToString());
                //dt.AcceptChanges();
            }
        }
        else
        {
            gvJoborder.Columns[18].Visible = false; //TotalVendors Column
        }
        return dt;
    }
    private string TotalVendors(string jobID)
    {
        string vendorCount = null;
        using (SqlConnection con = new SqlConnection(connValue))
        {
            con.Open();
            using (SqlCommand sqlCom = new SqlCommand())
            {
                // sqlCom.CommandType = CommandType.StoredProcedure;
                sqlCom.CommandType = CommandType.Text;
                sqlCom.Connection = con;
                string sqlfileType = "select count(vendorID) from EOIVendors where jobID = " + jobID;
                sqlCom.CommandText = sqlfileType;

                using (SqlDataReader sqlReader = sqlCom.ExecuteReader())
                {
                    if (sqlReader.HasRows)
                    {
                        sqlReader.Read();
                        vendorCount = sqlReader[0].ToString();
                    }
                    sqlReader.Close();
                    if (vendorCount=="0")
                    {
                        vendorCount = "";
                    }
                }
            }
        }
        
        return vendorCount;
    }
    protected void btnClear_Click(object sender, EventArgs e)
    {
        Session["ProjectCode"] = null;
        ClearData();
        DataTable dt = new DataTable();
        dt = FillTab2(0, "");     //  SearchJob
        if (dt.Rows.Count != 0)
        {
            dt = AddTotalVendorsColumn(dt);
            Session["TSSJobs"] = dt;
            gvJoborder.DataSource = dt;
            gvJoborder.DataBind();
        }
        else
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('No TSS Jobs found')</script>", false);
        }
        lblCnt.Text = dt.Rows.Count.ToString();
    }

    private void ClearData()
    {

        ddlJobType.SelectedIndex = 0;
        ddlJobStatus.SelectedIndex = 0;

        ddlAffair.SelectedIndex = 0;
        ddlDept.SelectedIndex = 0;
        ddlPrjCode.SelectedIndex = 0;
        ddlPrjCode.SelectedIndex = 0;
        ddlVendor.SelectedIndex = 0; 
        ddlContractor.SelectedIndex = 0; 
        ddlQS.SelectedIndex = 0;
         

        ddlPrjCode.SelectedItem.Text = "";         

        txtTitle.Text = "";
        txtdept.Text = "";

        txtJobNo.Text = "";
        txtJobTitle.Text = "";
        txtDocRefNo.Text = "";
        txtPrjNo.Text = "";
        txtToDate.Text = "";
        txtClsDocRefNo.Text = "";

    }

    protected void ddlJobType_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlJobType.SelectedValue == "114")
        {
            gvJoborder.Columns[1].Visible = false;
        }
        else
        {
            gvJoborder.Columns[1].Visible = true;
        }
    }
    protected void imgHome_Click(object sender, ImageClickEventArgs e)
    {
        Response.Redirect("~/TSS/TSSHomePage.aspx", false);
    }
}