﻿using Datalayer;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;

public partial class TSS_SearchEOIInfo : System.Web.UI.Page
{
    string eBookConn = System.Configuration.ConfigurationManager.ConnectionStrings["EBSDEBookConn"].ConnectionString;
    private void LoadEOIStages()
    {
        DAL dalObj = new DAL(eBookConn);
        DataTable dtStages = dalObj.GetDataFromDB("EOIStage", "SELECT job.jobNo,job.eoiNumber,REPLACE(CONVERT(nvarchar,eoiTrack.eoi_receiveon, 106), ' ', '/') AS ReceivedOn,eoiTrack.eoi_issue_handledby AS IssueHandledBy,REPLACE(CONVERT(nvarchar,eoiTrack.eoi_issue_date, 106), ' ', '/') AS TenderInvitation,REPLACE(CONVERT(nvarchar,eoiTrack.eoi_receive_from_dept,106), ' ', '/') AS ReceiveFromDept,REPLACE(CONVERT(nvarchar,eoiTrack.eoi_return_to_dept, 106), ' ', '/') AS ReturnToDept," +
        "REPLACE(CONVERT(nvarchar,job.eoiPubDate, 106), ' ', '/') AS eoiPubDate,REPLACE(CONVERT(nvarchar,eoiTrack.eoi_closing_date, 106), ' ', '/') AS ClosingDate,REPLACE(CONVERT(nvarchar,eoiTrack.eoi_closing_date_ext1, 106), ' ', '/') AS ClosingDateExt1,REPLACE(CONVERT(nvarchar,eoiTrack.eoi_closing_date_ext2, 106), ' ', '/') AS ClosingDateExt2,REPLACE(CONVERT(nvarchar,eoiTrack.eoi_closing_date_ext3, 106), ' ', '/') AS ClosingDateExt3," +
        "REPLACE(CONVERT(nvarchar,eoiTrack.eoi_closing_date_ext4, 106), ' ', '/') AS ClosingDateExt4,REPLACE(CONVERT(nvarchar,eoiTrack.eoi_closing_date_ext5, 106), ' ', '/') AS ClosingDateExt5,REPLACE(CONVERT(nvarchar,eoiTrack.modified_closing_date, 106), ' ', '/') AS ModifiedClosingDate,REPLACE(CONVERT(nvarchar,eoiTrack.modified_closing_date_ext1, 106), ' ', '/') AS ModifiedClosingDateExt1,REPLACE(CONVERT(nvarchar,eoiTrack.modified_closing_date_ext2, 106), ' ', '/') AS ModifiedClosingDateExt2," +
        "REPLACE(CONVERT(nvarchar,eoiTrack.modified_closing_date_ext3, 106), ' ', '/') AS ModifiedClosingDateExt3,REPLACE(CONVERT(nvarchar,eoiTrack.modified_closing_date_ext4, 106), ' ', '/') AS ModifiedClosingDateExt4,REPLACE(CONVERT(nvarchar,eoiTrack.modified_closing_date_ext5, 106), ' ', '/') AS ModifiedClosingDateExt5,eoiTrack.Remark,job.jobID from Eoi_Tracking as eoiTrack join Job as job on eoiTrack.jobID=job.jobID where eoiTrack.stage_id=2"); //HttpUtility.HtmlDecode(Request.QueryString["projectID"].ToString())
        dtStages.Columns.Add("NoOfFilesAttached");
        dtStages.AcceptChanges();
        foreach (DataRow row in dtStages.Rows)
        {
            row[22] = CountFilesAttachmented(row[21].ToString());             
        }
        gvEOIInfo.DataSource = dtStages;
        gvEOIInfo.DataBind();
        lblCnt.Text = dtStages.Rows.Count.ToString();
        //return dtStages;
    }
    private DataTable SearchEOIRecords(string _prjCode)
    {
        DataSet ds = new DataSet();
        try
        {
            Int16 jobid;
            Int16.TryParse("0", out jobid);

            Int16 docClsRefID;
            Int16.TryParse("0", out docClsRefID);

            Int16 ceID;
            Int16.TryParse("0", out ceID);

            Int16 peID;
            Int16.TryParse("0", out peID);

            //string docSubject = string.Empty;

            Int16 VOID;
            Int16.TryParse("0", out VOID);

            Int16 EOTID;
            Int16.TryParse("0", out EOTID);

            Int16 afrID;
            if (ddlAffair.SelectedValue != null)
            {
                Int16.TryParse(ddlAffair.SelectedValue, out afrID);
            }
            else
            {
                Int16.TryParse("0", out afrID);
            }

            Int16 dptID;
            if (ddlDept.SelectedValue != null)
            {
                Int16.TryParse(ddlDept.SelectedValue, out dptID);
            }
            else
            {
                Int16.TryParse("0", out dptID);
            }

            //Int16 consID;
            //Int16.TryParse(ddlVendor.SelectedValue, out consID);

            Int16 jobType;
            if (ddlJobType.SelectedValue != null)
            {
                Int16.TryParse(ddlJobType.SelectedValue, out jobType);
            }
            else
            {
                Int16.TryParse("0", out jobType);
            }

            Int16 jobStatus;
            if (ddlJobStatus.SelectedValue != null)
            {
                Int16.TryParse(ddlJobStatus.SelectedValue, out jobStatus);
            }
            else
            {
                Int16.TryParse("0", out jobStatus);
            }

            Int16 docRefID;
            if (txtDocRefNo.Text != "")
            {
                Int16.TryParse(txtDocRefNo.Text, out docRefID);
            }
            else
            {
                Int16.TryParse("0", out docRefID);
            }

            Int16 qsID;
            Int16.TryParse("0", out qsID);

            Int16 contactID;
            if (ddlQS.SelectedValue == "")
                Int16.TryParse(Session["UserID"].ToString(), out contactID);
            else if (ddlQS.SelectedValue == "ALL")
                Int16.TryParse("0", out contactID);
            else
            {
                qsID = 0;
                Int16.TryParse(ddlQS.SelectedValue, out contactID);
            }         

            string prjTitle = string.Empty;
            if (txtTitle.Text != "")
                prjTitle = "%" + txtTitle.Text + "%";

            Int16 cntrID;
            if (ddlContractor.SelectedValue != null)
            {
                Int16.TryParse(ddlContractor.SelectedValue, out cntrID);
            }
            else
            {
                Int16.TryParse("0", out cntrID);
            }

            Int16 consultID;
            if (ddlVendor.SelectedValue != null)
            {
                Int16.TryParse(ddlVendor.SelectedValue, out consultID);
            }
            else
            {
                Int16.TryParse("0", out consultID);
            }

            string prjCode = string.Empty;
            if (_prjCode != "")
            {
                ddlPrjCode.SelectedItem.Text = _prjCode;
                prjCode = _prjCode;
            }
            else
                prjCode = ddlPrjCode.SelectedItem.Text;

            //if (ddlPrjCode.SelectedItem.Text != "")
            //    prjCode = ddlPrjCode.SelectedItem.Text;

            string txtfrom = string.Empty;
            if (txtdept.Text != "")
                txtfrom = txtdept.Text;


            string txtTo = string.Empty;
            if (txtToDate.Text != "")
                txtTo = txtToDate.Text;

            string jobSub = string.Empty;
            if (txtSubject.Text != "")
                jobSub = txtSubject.Text;

            string _refNo = string.Empty;

            string _ClsrefNo = string.Empty;

            string _contractNo = string.Empty;


            string _jobNo = string.Empty;
            if (txtJobNo.Text != "")
                _jobNo = "%" + txtJobNo.Text + "%";

            if (txtDocRefNo.Text != "")
                _refNo = "%" + txtDocRefNo.Text + "%";

            if (txtPrjNo.Text != "")
                _contractNo = "%" + txtPrjNo.Text + "%";

            string _clsrefNo = string.Empty;
            if (txtClsDocRefNo.Text != "")
                _clsrefNo = "%" + txtClsDocRefNo.Text + "%";
            //string str = searchType + "," + jobid + "," + jobType + "," + jobStatus + "," + afrID + "," + dptID + "," + docRefID + "," + qsID + "," + ceID + "," + peID + "," + prjTitle + "," + cntrID + "," + consultID + "," + prjCode + "," + txtfrom + "," + VOID + "," + EOTID + "," + docSubject + "," + docClsRefID + "," + txtTo + "," + 0 + "," + 0;             
            //if(Session["IsTSSSearchedClicked"].ToString() == "1")
            //{
            //if ((!userRightsColl.Contains("17")))       // View All On-Going List of Job Orders
            //{
            //    ds = (new JobOrderData().GetJobOrderDetails_Claim(searchType, jobid, jobType, jobStatus, afrID, dptID, docRefID, qsID, ceID, peID, prjTitle, cntrID, consultID, prjCode, txtfrom, VOID, EOTID, jobSub, docClsRefID, txtTo, 0, 0, Convert.ToInt32(Session["SectionID"])));
            //}
            //else
            //{
            //    ds = (new JobOrderData().GetJobOrderDetails_Claim(searchType, jobid, jobType, jobStatus, afrID, dptID, docRefID, qsID, ceID, peID, prjTitle, cntrID, consultID, prjCode, txtfrom, VOID, EOTID, jobSub, docClsRefID, txtTo, 0, Convert.ToInt32(Session["UserID"]), Convert.ToInt32(Session["SectionID"])));
            //}

            //if ((!userRightsColl.Contains("17")))       // View All On-Going List of Job Orders
            //{
            if (contactID == 0)
            {                 
               ds = (new JobOrderData().GetTSSEOIRecords(jobid, jobType, jobStatus, afrID, dptID, docRefID, qsID, ceID, peID, prjTitle, cntrID, consultID, prjCode, txtfrom, VOID, EOTID, jobSub, docClsRefID, txtTo, 0, 0));
            }
            else
            {
                ds = (new JobOrderData().GetTSSEOIRecords(jobid, jobType, jobStatus, afrID, dptID, docRefID, qsID, ceID, peID, prjTitle, cntrID, consultID, prjCode, txtfrom, VOID, EOTID, jobSub, docClsRefID, txtTo, 0, contactID));
            }
             
            //}
            //else
            //{
            //    ds = (new JobOrderData().GetJobOrderDetails_TSS(searchType, jobid, jobType, jobStatus, afrID, dptID, docRefID, qsID, ceID, peID, prjTitle, cntrID, consultID, prjCode, txtfrom, VOID, EOTID, jobSub, docClsRefID, txtTo, 0, Convert.ToInt32(Session["UserID"])));
            //}
            //ds = (new JobOrderData().GetJobOrderDetailsByJobNo(searchType, jobid, jobType, jobStatus, afrID, dptID, docRefID, qsID, ceID, peID, prjTitle, cntrID, consultID, prjCode, txtfrom, jobSub, docClsRefID, _jobNo, _refNo, _contractNo, _ClsrefNo));
            //if ((!userRightsColl.Contains("17")))       // View All On-Going List of Job Orders
            //{
            //    ds = (new JobOrderData().GetTendersServicesDetails(searchType, jobid, jobType, jobStatus, 0, afrID, dptID, docRefID, qsID, ceID, peID, prjTitle, cntrID, consultID, prjCode, txtfrom, VOID, EOTID, jobSub, docClsRefID, txtTo, 0, contactID));
            //}
            //else
            //{
            //    ds = (new JobOrderData().GetTendersServicesDetails(searchType, jobid, jobType, jobStatus, 0, afrID, dptID, docRefID, qsID, ceID, peID, prjTitle, cntrID, consultID, prjCode, txtfrom, VOID, EOTID, jobSub, docClsRefID, txtTo, 0, Convert.ToInt16(Session["UserID"])));
            //}
            //}
            //else if (Session["ShortName"] != null)
            //{
            //    ds = (new JobOrderData().GetTendersServicesDetails(searchType, jobid, jobType, jobStatus, 3,afrID, dptID, docRefID, qsID, ceID, peID, prjTitle, cntrID, consultID, prjCode, txtfrom, VOID, EOTID, jobSub, docClsRefID, txtTo, 0, new JobOrderData().getContactID(Session["ShortName"].ToString())));
            //}
            //else
            //{
            //    ds = (new JobOrderData().GetJobOrderDetails_Claim(searchType, jobid, jobType, jobStatus, afrID, dptID, docRefID, qsID, ceID, peID, prjTitle, cntrID, consultID, prjCode, txtfrom, VOID, EOTID, jobSub, docClsRefID, txtTo, 0, 0, Convert.ToInt32(Session["SectionID"])));
            //ds = (new JobOrderData().GetJobOrderDetailsByJobNo(searchType, jobid, jobType, jobStatus, afrID, dptID, docRefID, qsID, ceID, peID, prjTitle, cntrID, consultID, prjCode, txtfrom, jobSub, docClsRefID, _jobNo, _refNo, _contractNo, _ClsrefNo));
            //ds = (new JobOrderData().GetTendersServicesDetails(searchType, jobid, jobType, jobStatus, 0,afrID, dptID, docRefID, qsID, ceID, peID, prjTitle, cntrID, consultID, prjCode, txtfrom, VOID, EOTID, jobSub, docClsRefID, txtTo, 0, contactID));
            //}

        }
        catch (Exception ex)
        {

        }
        return ds.Tables[0];
    }   
    private int CountFilesAttachmented(string jobID)
    {
        int fileCnt = 0;
        using (SqlConnection con = new SqlConnection(eBookConn))
        {
            con.Open();
            using (SqlCommand sqlCom = new SqlCommand())
            {
                // sqlCom.CommandType = CommandType.StoredProcedure;
                sqlCom.CommandType = CommandType.Text;
                sqlCom.Connection = con;
                string sqlfileType = "select  count(fileID) from FilesTable where isFileActive = 1 and fileType ='A' and jobID = " + jobID;
                sqlCom.CommandText = sqlfileType;

                using (SqlDataReader sqlReader = sqlCom.ExecuteReader())
                {
                    if (sqlReader.HasRows)
                    {
                        sqlReader.Read();
                        fileCnt = Convert.ToInt32(sqlReader[0].ToString());                        
                    }
                    sqlReader.Close();
                }
            }
        }
        return fileCnt;
    }
    public override void VerifyRenderingInServerForm(Control control)
    {
        /* Verifies that the control is rendered */
    }
    private DataTable PartialTSSEOISearch()
    {
        DataTable dt = new DataTable();
        DataSet ds = new DataSet();
        try
        {
            string _jobNo = string.Empty;
            if (txtJobNo.Text != "")
                _jobNo = "%" + txtJobNo.Text + "%";

            string _projTitle = string.Empty;
            if (txtJobTitle.Text != "")
                _projTitle = "%" + txtJobTitle.Text + "%";

            string _refNo = string.Empty;
            if (txtDocRefNo.Text != "")
                _refNo = "%" + txtDocRefNo.Text + "%";

            string _contractNo = string.Empty;
            if (txtPrjNo.Text != "")
                _contractNo = "%" + txtPrjNo.Text + "%";

            string _clsrefNo = string.Empty;
            if (txtClsDocRefNo.Text != "")
                _clsrefNo = "%" + txtClsDocRefNo.Text + "%";

            string _clsEoiNo = string.Empty;
            if (txtEOINo.Text != "")
                _clsEoiNo = "%" + txtEOINo.Text + "%";

            ds = (new JobOrderData().GetTSSEOIRecords_Partial(_jobNo, _projTitle, _refNo, _contractNo, _clsrefNo, _clsEoiNo));   //sp_SearchJobByJobNO
        }
        catch (Exception ex)
        {

        }
        if (ds.Tables.Count != 0)
        {
            dt = ds.Tables[0];
        }
        return dt;
    }

    private DataTable FillAndSetEOISearch()
    {
        DataTable dtEOIStage = null;
        dtEOIStage = SearchEOIRecords(_prjCode);
        dtEOIStage.Columns.Add("NoOfFilesAttached");
        dtEOIStage.AcceptChanges();
        short rowCounter = 0;
        foreach (DataRow row in dtEOIStage.Rows)
        {
            dtEOIStage.Rows[rowCounter][24] = CountFilesAttachmented(row[22].ToString());
            dtEOIStage.AcceptChanges();
            rowCounter++;
        }
        gvEOIInfo.DataSource = dtEOIStage;
        gvEOIInfo.DataBind();
        return dtEOIStage;
    }
    string _prjCode = string.Empty;
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (Session["UserName"] == null)
            {
                Response.Redirect("~/LoginPage.aspx", false);
                return;
            }
            if (!IsPostBack)
            {
                lblUser.Text = Session["UserDisplayName"].ToString();
                lblUserDesignation.Text = Session["UserDesignation"].ToString();
                lblUserProfile.Text = Session["ProfileName"].ToString();
                FillDropBox(Session["SectionID"].ToString());
                if (Session["ProjectCode"] != null)
                    _prjCode = Session["ProjectCode"].ToString(); // Request.QueryString["ProjCode"];                       
                DataTable dt = FillAndSetEOISearch();
                lblCnt.Text = dt.Rows.Count.ToString();
                //LoadEOIStages();
            }
        }
        catch (Exception ex)
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Error occurred while retrieving the information of EOI of Jobs')</script>", false);             
        }        
    }
    protected void txtJobNo_TextChanged(object sender, EventArgs e)
    {
        //Session["OnGoingJobStatus"] = null;
        DataTable dt = null;
        dt = PartialTSSEOISearch();                  
        if (dt.Rows.Count != 0)
        {
            dt.Columns.Add("NoOfFilesAttached");
            dt.AcceptChanges();
            short rowCounter = 0;
            foreach (DataRow row in dt.Rows)
            {
                dt.Rows[rowCounter][24] = CountFilesAttachmented(row[22].ToString());
                dt.AcceptChanges();
                rowCounter++;
            }
            //dt = FillTabByJobNo(0, "","");
            //Session["OnGoingJobStatus"] = dt;  
            gvEOIInfo.DataSource = dt;
            gvEOIInfo.DataBind();
            Session["TSSEOI"] = dt;
        }
        else
        {
            gvEOIInfo.DataSource = null;
            gvEOIInfo.DataBind();
        }
        lblCnt.Text = dt.Rows.Count.ToString();
    }
    protected void lnkLogOutBtn_Click(object sender, EventArgs e)
    {
        // Added by Varun on 01/Dec/2019
        Session["UserName"] = null;
        Response.Redirect("~/LoginPage.aspx", false);
    }
    protected void lnkJobOrderJobNo_Click(object sender, EventArgs e)     //ForCommitted
    {
        try
        {
            LinkButton lnkJobID = (LinkButton)sender;
            GridViewRow gvr = (GridViewRow)lnkJobID.NamingContainer;

            Session["JobID"] = ((HtmlGenericControl)gvr.FindControl("divJobID")).InnerText;
            Session["JobTypeID"] = ((HtmlGenericControl)gvr.FindControl("divJobTypeID")).InnerText;
            Session["JobNo"] = ((HtmlGenericControl)gvr.FindControl("divJobNo")).InnerText.Trim();
            Session["UrlRef"] = Request.Url.AbsoluteUri;
            Response.Redirect("~/TSS/TSSJobDetails.aspx?JobID= " + Session["JobID"] + "", false);

        }
        catch
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Error Occurred while opening the TSS Job details')</script>", false);
        }
    }
    protected void lnkEOINumber_Click(object sender, EventArgs e)     //ForCommitted
    {
        try
        {
            LinkButton lnkJobID = (LinkButton)sender;
            GridViewRow gvr = (GridViewRow)lnkJobID.NamingContainer;

            Session["JobID"] = ((HtmlGenericControl)gvr.FindControl("divJobID")).InnerText;
            LinkButton lnkEOINumber = (LinkButton)sender;
            //gvr = (GridViewRow)lnkJobID.NamingContainer;
            Session["JobNo"] = ((HtmlGenericControl)gvr.FindControl("divJobNo")).InnerText.Trim();
            Session["EOINumber"] = ((HtmlGenericControl)gvr.FindControl("divEOINumber")).InnerText.Trim();
            Session["PrjTitle"] = ((Label)gvr.FindControl("lblProjTitle")).Text;

            Session["UrlRef"] = Request.Url.AbsoluteUri;
            Response.Redirect("~/TSS/TSSEOIStage.aspx", false);
            //Response.Redirect("~/TSS/TSSEOIStages.aspx?JobID= " + Session["JobID"] + "", false);

        }
        catch
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Error Occurred while opening the TSS EOI Stages')</script>", false);
        }
    }
    protected void gvJoborder_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        gvEOIInfo.PageIndex = e.NewPageIndex;
        DataTable dt = new DataTable();
        dt = Session["TSSEOI"] as DataTable;
        gvEOIInfo.DataSource = dt;
        gvEOIInfo.DataBind();
        lblCnt.Text = dt.Rows.Count.ToString();
    }
    protected void btnSearch_Click(object sender, EventArgs e)
    {
        Session["TSSEOI"] = null;
        DataTable dt = null;
        dt = FillAndSetEOISearch();
        Session["TSSEOI"] = dt;       

        lblCnt.Text = dt.Rows.Count.ToString();
    }
    protected void btnClear_Click(object sender, EventArgs e)
    {
        Session["ProjectCode"] = null;
        ClearData();
        DataTable dt = null;
        dt = FillAndSetEOISearch();
        Session["TSSEOI"] = dt;
        lblCnt.Text = dt.Rows.Count.ToString();
    }
    private void ClearData()
    {
        ddlJobType.SelectedIndex = 0;
        ddlJobStatus.SelectedIndex = 0;

        ddlAffair.SelectedIndex = 0;
        ddlDept.SelectedIndex = 0;
        ddlPrjCode.SelectedIndex = 0;        
        ddlVendor.SelectedIndex = 0;
        ddlContractor.SelectedIndex = 0;
        ddlQS.SelectedIndex = 0;


        ddlPrjCode.SelectedItem.Text = "";

        txtTitle.Text = "";
        txtdept.Text = "";

        txtJobNo.Text = "";
        txtJobTitle.Text = "";
        txtDocRefNo.Text = "";
        txtPrjNo.Text = "";
        txtToDate.Text = "";
        txtClsDocRefNo.Text = "";

    }
    protected void ddlBox_DataBound(object sender, EventArgs e)
    {
        DropDownList ddl = (DropDownList)sender;
        ListItem emptyItem = new ListItem("", "");
        ddl.Items.Insert(0, emptyItem);
    }
    private void PopulateDropDownBox(DropDownList ddlBox, string sqlQuery, string valueMember, string displayName)
    {
        ddlBox.DataBound += new EventHandler(this.ddlBox_DataBound);
        ddlBox.DataSource = new JobOrderData().FillDropdown(sqlQuery);
        ddlBox.DataTextField = displayName;
        ddlBox.DataValueField = valueMember;
        ddlBox.SelectedIndex = -1;
        ddlBox.DataBind();
    }
    public void FillDropBox(string _sectionID)
    {
        PopulateDropDownBox(ddlJobType, "SELECT DISTINCT JobType.jobTypeID, JobType.jobTypeName FROM JobType INNER JOIN Job ON JobType.jobTypeID = Job.jobTypeID WHERE (JobType.CategoryID IN (112)) and Job.sectionID=" + _sectionID + " ORDER BY JobType.jobTypeName", "jobTypeID", "jobTypeName");

        PopulateDropDownBox(ddlJobStatus, "SELECT jobStatusID, jobStatusName FROM JobStatus where jobStatusID in(1,2,3,4,5,6,7) ORDER BY jobStatusName", "jobStatusID", "jobStatusName");

        PopulateDropDownBox(ddlAffair, "SELECT  affairID, affairName FROM Affair WHERE (isActive=1) ORDER BY affairName", "affairID", "affairName");

        PopulateDropDownBox(ddlDept, "SELECT departmentID, deptName FROM Department WHERE (isActive=1) ORDER BY deptName", "departmentID", "deptName");

        PopulateDropDownBox(ddlVendor, "SELECT DISTINCT Company.companyID, Company.cmpName FROM Job INNER JOIN Company ON Job.consultantID = Company.companyID INNER JOIN JobType ON Job.jobTypeID = JobType.jobTypeID WHERE  (JobType.CategoryID IN (112)) ORDER BY Company.cmpName", "companyID", "cmpName");

        string strCntr = "SELECT DISTINCT Company.companyID, Company.cmpName FROM   Job INNER JOIN Company ON Job.contractorID = Company.companyID INNER JOIN JobType ON Job.jobTypeID = JobType.jobTypeID WHERE  (JobType.CategoryID IN (112)) ORDER BY Company.cmpName";
        PopulateDropDownBox(ddlContractor, strCntr, "companyID", "cmpName");

        PopulateDropDownBoxQS(ddlQS, "SELECT DISTINCT Contact.contactID, Contact.userShortName FROM JobOwner INNER JOIN  Contact ON JobOwner.contactID = Contact.contactID WHERE (JobOwner.sectionID =" + _sectionID + ")", "ContactID", "userShortName");

        //PopulateDropDownBox(ddlPrjCode, "SELECT DISTINCT Job.contractNo, Job.contractNo  FROM job INNER JOIN JobType ON Job.jobTypeID = JobType.jobTypeID WHERE    (JobType.CategoryID IN (8)) ORDER BY Job.contractNo", "contractNo", "contractNo");

        PopulateDropDownBox(ddlPrjCode, "SELECT ISNULL(contractNo, committmentNo) AS projectCode FROM Job WHERE  (sectionID = " + _sectionID + ") ORDER BY projectCode", "projectCode", "projectCode");

        //PopulateDropDownBox(ddlReqType, "SELECT reqStatusID, reqStatusName FROM DCRequestStatus  ORDER BY reqStatusName", "reqStatusID", "reqStatusName");
    }
    private void PopulateDropDownBoxQS(DropDownList ddlBox, string sqlQuery, string valueMember, string displayName)
    {

        ddlBox.DataSource = new JobOrderData().FillDropdown(sqlQuery);
        ddlBox.DataTextField = displayName;
        ddlBox.DataValueField = valueMember;
        ddlBox.SelectedIndex = -1;
        ddlBox.DataBind();


        ListItem emptyItem123 = new ListItem("ALL", "ALL");
        ddlBox.Items.Insert(0, emptyItem123);

        ListItem emptyItem = new ListItem("", "");
        ddlBox.Items.Insert(0, emptyItem);

    }
    protected void ddlJobType_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlJobType.SelectedValue == "114")
        {
            gvEOIInfo.Columns[1].Visible = false;
        }
        else
        {
            gvEOIInfo.Columns[1].Visible = true;
        }
    }
    protected void btnHome_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/TSS/TSSHomePage.aspx", false);
    }
    protected void btnExcel_Click(object sender, EventArgs e)
    {
        ExportToExcel_Sree();
    }     

    private void ExportToExcel_Sree()
    {
        if (Session["UserName"] == null)
        {
            Response.Redirect("~/LoginPage.aspx", false);
            return;
        }
        Response.Clear();
        Response.Buffer = true;
        Response.AddHeader("content-disposition", "attachment;filename=GridViewExport.xls");
        Response.Charset = "";
        Response.ContentType = "application/vnd.ms-excel";
        using (StringWriter sw = new StringWriter())
        {
            HtmlTextWriter hw = new HtmlTextWriter(sw);

            //To Export all pages
            gvEOIInfo.AllowPaging = false;

            gvEOIInfo.DataSource = Session["TSSEOI"];
            gvEOIInfo.DataBind();

            gvEOIInfo.HeaderRow.BackColor = Color.White;
            foreach (TableCell cell in gvEOIInfo.HeaderRow.Cells)
            {
                cell.BackColor = gvEOIInfo.HeaderStyle.BackColor;
            }
            foreach (GridViewRow row in gvEOIInfo.Rows)
            {
                row.BackColor = Color.White;
                foreach (TableCell cell in row.Cells)
                {
                    if (row.RowIndex % 2 == 0)
                    {
                        cell.BackColor = gvEOIInfo.AlternatingRowStyle.BackColor;
                    }
                    else
                    {
                        cell.BackColor = gvEOIInfo.RowStyle.BackColor;
                    }
                    cell.CssClass = "textmode";
                }
            }

            gvEOIInfo.RenderControl(hw);

            //style to format numbers to string
            string style = @"<style> .textmode { } </style>";
            Response.Write(style);
            Response.Output.Write(sw.ToString());
            Response.Flush();
            Response.End();
        }
    }
    protected void btnCreateTSSJob_Click(object sender, EventArgs e)
    {
        Session["UrlRef"] = Request.Url.AbsoluteUri;
        Response.Redirect("~/TSS/CreateTSSJob.aspx", false);
    }

    protected void imgHome_Click(object sender, ImageClickEventArgs e)
    {
        Response.Redirect("~/TSS/TSSHomePage.aspx", false);
    }
    protected void btnBack_Click(object sender, EventArgs e)
    {
        if (Session["UserName"] == null)
        {
            Response.Redirect("~/LoginPage.aspx", false);
            return;
        }
        Response.Redirect(Session["UrlRef"].ToString());
    }
}