﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Drawing;
using System.Data;
using System.Web.UI.HtmlControls;

public partial class TSS_TSSHomePageOld : System.Web.UI.Page
{
    string connValue = System.Configuration.ConfigurationManager.ConnectionStrings["EBSDEBookConn"].ConnectionString;
    IList<string> userRightsColl = null;
    static int _currentUserID = 0; 
    protected void Page_Load(object sender, EventArgs e)
    {

        if (Session["UserName"] == null)
        {
            Response.Redirect("~/LoginPage.aspx", false);
            return;
        }
        _currentUserID = Convert.ToInt32(Session["UserID"]);
        userRightsColl = (IList<string>)Session["UserRightsColl"];

        lblUser.Text = Session["UserDisplayName"].ToString();
        lblUserProfile.Text = Session["ProfileName"].ToString();
        lblDept.Text = "ESD - " + Session["sectionName"].ToString();
        if (userRightsColl.Contains("4"))
        {
            Session["CanCreateProject"] = "0";
        }

        //if (jsExecuted.Value.ToString().Equals("1"))
        //{
        //    ClientScript.RegisterClientScriptBlock(this.GetType(), "Popup", "<script></script>", false);
        //}
            Session["IsTSSSearchedClicked"] = "0";
            //Session["TSSJobTypeName"] = null;
            lblUser.Text = Session["UserDisplayName"].ToString();
            lblUserProfile.Text = Session["ProfileName"].ToString();
            // lblDept.Text = Session["ProfileName"].ToString();

            getOnGoingTasksPerSection_New();
            Ongoing_Claims();

            getOnGoingTasksPerStaffChart();
            //getCommitteeWiseClaimsChart();

            RecentlyClosedClaims();
            getUnReadInchargeData();
        //}
    }

    //bool isPageRefreshed = false;
    protected void Page_Init(object sender, EventArgs e)
    {
        
        //if (jsExecuted.Value.ToString().Equals("1"))
        //{
        //    isPageRefreshed = true;
        //    ClientScript.RegisterClientScriptBlock(this.GetType(), "Popup", "<script></script>", false);
        //}
    }

    protected void btnNewPrj_Click(object sender, EventArgs e)
    {        
       Response.Redirect("~/TSS/CreateTSSJob.aspx", false);             
    }    
    protected void btnSearch_Click(object sender, EventArgs e)
    {
        Session["IsTSSSearchedClicked"] = "1";
        Response.Redirect("~/TSS/SearchTSSJobs.aspx", false);
    }
    protected void btnTndrNo_Click(object sender, EventArgs e)
    {
        //Session["TSSJobTypeName"] = null;
        Response.Redirect("~/DCLog/OverDueJobs.aspx", false);
    }
    protected void btnClaimSearch_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/Contracts/CreateClaim.aspx", false); 
    }
    protected void lnkLogOutBtn_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/LoginPage.aspx", false);
    }
    protected void ddlYaer_SelectedIndexChanged(object sender, EventArgs e)
    {
        getOnGoingTasksPerSection_New();
        Ongoing_Claims();
        getOnGoingTasksPerStaffChart(); 
        getCommitteeWiseClaimsChart();
    }
    private void getOnGoingTasksPerSection_New()
    {
        DataSet dsTndr = new DataSet();

        string sqlQuery = null; int secID = Convert.ToInt32(Session["SectionID"]);
        string strSeriesName = string.Empty;

        if (Session["userProfileID"].ToString().Equals("1"))   // For Admin
        {
            sqlQuery = " SELECT  COUNT(Job.jobID) AS JobCnt, Section.sectionName FROM  JobType INNER JOIN  Job ON JobType.jobTypeID = Job.jobTypeID INNER JOIN Section ON JobType.sectionID = Section.sectionID " +
               " WHERE (Job.jobDueDate < GETDATE()-1) AND (Job.jobStatusID IN (3, 8))  GROUP BY Section.sectionName, JobType.sectionID  UNION " +
                    "SELECT  COUNT(JobOwner.jobOwnerID) AS Expr1, Section.sectionName FROM  JobOwner INNER JOIN  Section ON JobOwner.sectionID = Section.sectionID " +
                          " WHERE  (JobOwner.payID IS NOT NULL) AND (JobOwner.actionDueDate < GETDATE()-1) AND (JobOwner.jobOwnerStatusID <> 7) GROUP BY Section.sectionName";
            strSeriesName = "sectionName";

            lblOngoingJobs.Text = "Over Due Job Order In All Sections";
        }       
        else if (Session["SectionID"].ToString().Equals("12"))          // Contracts Services Section
        {
            if (Session["UserProfileID"].ToString().Equals("2"))        // Admin Section
            {
                sqlQuery = "SELECT COUNT(Job.jobID) AS JobCnt, JobType_1.jobTypeName FROM JobType AS JobType_1 INNER JOIN JobType ON JobType_1.jobTypeID = JobType.CategoryID INNER JOIN  Job ON JobType.jobTypeID = Job.jobTypeID INNER JOIN " +
                   " Section ON JobType.sectionID = Section.sectionID WHERE (JobType.sectionID = " + secID + ") AND (Job.jobDueDate < GETDATE()-1) AND (Job.jobStatusID IN (3,8)) GROUP BY JobType_1.jobTypeName";

                strSeriesName = "jobTypeName";
                lblOngoingJobs.Text = "Over Due Job Order In Cost Control Section";
            }
            else if (Session["UserProfileID"].ToString().Equals("4"))        // Cost Control Admin 
            {
                sqlQuery = "SELECT COUNT(Job.jobID) AS JobCnt, JobType_1.jobTypeName FROM JobType AS JobType_1 INNER JOIN JobType ON JobType_1.jobTypeID = JobType.CategoryID INNER JOIN  Job ON JobType.jobTypeID = Job.jobTypeID INNER JOIN " +
                " Section ON JobType.sectionID = Section.sectionID WHERE (JobType.sectionID = " + secID + ") AND (Job.jobDueDate < GETDATE()-1) AND (Job.jobStatusID IN (3,8)) GROUP BY JobType_1.jobTypeName";

                strSeriesName = "jobTypeName";
                lblOngoingJobs.Text = "Over Due Job Order In Cost Control Section";
            }
            else if (Session["UserProfileID"].ToString().Equals("9"))        // Document Control Admin 
            {
                sqlQuery = "SELECT COUNT(Job.jobID) AS JobCnt, JobType_1.jobTypeName FROM JobType AS JobType_1 INNER JOIN JobType ON JobType_1.jobTypeID = JobType.CategoryID INNER JOIN  Job ON JobType.jobTypeID = Job.jobTypeID INNER JOIN " +
                " Section ON JobType.sectionID = Section.sectionID WHERE (JobType.sectionID = " + secID + ") AND (Job.jobDueDate < GETDATE()-1) AND (Job.jobStatusID IN (3,8)) GROUP BY JobType_1.jobTypeName";

                strSeriesName = "jobTypeName";
                lblOngoingJobs.Text = "Over Due Job Order In Cost Control Section";
            }
            else                                                            // Cost Control User 
            {
                sqlQuery = "SELECT COUNT(Job.jobID) AS JobCnt, JobType_1.jobTypeName FROM JobType AS JobType_1 INNER JOIN JobType ON JobType_1.jobTypeID = JobType.CategoryID INNER JOIN  Job ON JobType.jobTypeID = Job.jobTypeID INNER JOIN " +
               " Section ON JobType.sectionID = Section.sectionID WHERE (JobType.sectionID = " + secID + ") AND (Job.jobDueDate < GETDATE()-1) AND (Job.jobStatusID IN (3,8)) GROUP BY JobType_1.jobTypeName";

                strSeriesName = "jobTypeName";
                lblOngoingJobs.Text = "Over Due Job Order In Cost Control Section";
            }
        }
        else if (Session["SectionID"].ToString().Equals("13"))          // Tenders Services Section
        {
            if (Session["UserProfileID"].ToString().Equals("2"))        // Admin Section
            {
                sqlQuery = "SELECT COUNT(Job.jobID) AS JobCnt, JobType_1.jobTypeName FROM JobType AS JobType_1 INNER JOIN JobType ON JobType_1.jobTypeID = JobType.CategoryID INNER JOIN  Job ON JobType.jobTypeID = Job.jobTypeID INNER JOIN " +
                   " Section ON JobType.sectionID = Section.sectionID WHERE (JobType.sectionID = " + secID + ") AND (Job.jobDueDate < GETDATE()-1) AND (Job.jobStatusID IN (3,8)) GROUP BY JobType_1.jobTypeName";

                strSeriesName = "jobTypeName";
                lblOngoingJobs.Text = "Over Due Job Order In Cost Control Section";
            }
            else if (Session["UserProfileID"].ToString().Equals("4"))        // Cost Control Admin 
            {
                sqlQuery = "SELECT COUNT(Job.jobID) AS JobCnt, JobType_1.jobTypeName FROM JobType AS JobType_1 INNER JOIN JobType ON JobType_1.jobTypeID = JobType.CategoryID INNER JOIN  Job ON JobType.jobTypeID = Job.jobTypeID INNER JOIN " +
                " Section ON JobType.sectionID = Section.sectionID WHERE (JobType.sectionID = " + secID + ") AND (Job.jobDueDate < GETDATE()-1) AND (Job.jobStatusID IN (3,8)) GROUP BY JobType_1.jobTypeName";

                strSeriesName = "jobTypeName";
                lblOngoingJobs.Text = "Over Due Job Order In Cost Control Section";
            }
            else if (Session["UserProfileID"].ToString().Equals("9"))        // Document Control Admin 
            {
                sqlQuery = "SELECT COUNT(Job.jobID) AS JobCnt, JobType_1.jobTypeName FROM JobType AS JobType_1 INNER JOIN JobType ON JobType_1.jobTypeID = JobType.CategoryID INNER JOIN  Job ON JobType.jobTypeID = Job.jobTypeID INNER JOIN " +
                " Section ON JobType.sectionID = Section.sectionID WHERE (JobType.sectionID = " + secID + ") AND (Job.jobDueDate < GETDATE()-1) AND (Job.jobStatusID IN (3,8)) GROUP BY JobType_1.jobTypeName";

                strSeriesName = "jobTypeName";
                lblOngoingJobs.Text = "Over Due Job Order In Cost Control Section";
            }
            else                                                            // Cost Control User 
            {
                //sqlQuery = "SELECT COUNT(Job.jobID) AS JobCnt, JobType_1.jobTypeName FROM JobType AS JobType_1 INNER JOIN JobType ON JobType_1.jobTypeID = JobType.CategoryID INNER JOIN  Job ON JobType.jobTypeID = Job.jobTypeID INNER JOIN " +
                //" Section ON JobType.sectionID = Section.sectionID WHERE (JobType.sectionID = " + secID + ") AND (Job.jobDueDate < GETDATE()-1) AND (Job.jobStatusID IN (3,8)) GROUP BY JobType_1.jobTypeName";

                //Modified by Varun on 07/Jan/2020
                sqlQuery = "SELECT COUNT(Job.jobID) AS JobCnt, JobType_1.jobTypeName FROM JobType AS JobType_1 INNER JOIN JobType ON JobType_1.jobTypeID = JobType.CategoryID INNER JOIN  Job ON JobType.jobTypeID = Job.jobTypeID INNER JOIN " +
                " Section ON JobType.sectionID = Section.sectionID WHERE (Job.sectionID = " + secID + ") AND (Job.jobDueDate < GETDATE()-1) AND (Job.jobStatusID IN (3,8)) GROUP BY JobType_1.jobTypeName";

                strSeriesName = "jobTypeName";
                lblOngoingJobs.Text = "Over Due Job Order In Cost Control Section";
            }
        }  
        else
        {
            sqlQuery = "SELECT COUNT(Job.jobID) AS JobCnt, JobType_1.jobTypeName FROM JobType AS JobType_1 INNER JOIN JobType ON JobType_1.jobTypeID = JobType.CategoryID INNER JOIN  Job ON JobType.jobTypeID = Job.jobTypeID INNER JOIN " +
               " Section ON JobType.sectionID = Section.sectionID WHERE (JobType.sectionID = " + secID + ") AND (Job.jobDueDate < GETDATE()-1) AND (Job.jobStatusID IN (3,8)) GROUP BY JobType_1.jobTypeName";

            strSeriesName = "jobTypeName";
            lblOngoingJobs.Text = "Over Due Job Order In Cost Control Section";
        }

        // Chart_OverDueJobs

        SqlDataAdapter daTndr = new SqlDataAdapter(sqlQuery, connValue);
        daTndr.Fill(dsTndr);
        if (dsTndr.Tables[0].Rows.Count != 0)
        {
            onGoingTasksPerSectionChart.DataSource = dsTndr.Tables[0].DefaultView;
            onGoingTasksPerSectionChart.Series["Series1"].XValueMember = strSeriesName;
            onGoingTasksPerSectionChart.Series["Series1"].YValueMembers = "JobCnt";

            dsTndr.Tables.Clear();

            onGoingTasksPerSectionChart.ChartAreas[0].AxisX.MajorGrid.Enabled = false;
            onGoingTasksPerSectionChart.ChartAreas[0].AxisX.MinorGrid.Enabled = false;
            onGoingTasksPerSectionChart.ChartAreas[0].AxisY.MajorGrid.Enabled = false;
            onGoingTasksPerSectionChart.ChartAreas[0].AxisY.MinorGrid.Enabled = false;

            onGoingTasksPerSectionChart.ChartAreas[0].AxisX.LabelStyle.Angle = 30;
            onGoingTasksPerSectionChart.ChartAreas[0].AxisX.LabelStyle.ForeColor = Color.Maroon;

            onGoingTasksPerSectionChart.ChartAreas[0].AxisX.Interval = 1;
        }
        else
        {
            onGoingTasksPerSectionChart.DataSource = null;
        }
    }
    private void Ongoing_Claims()
    {
        DataSet dsTndr = new DataSet();

        string sqlQuery = null; int secID = Convert.ToInt32(Session["SectionID"]);
        string strSeriesName = string.Empty;

        if (Session["userProfileID"].ToString().Equals("1"))   // For Admin
        {
            sqlQuery = " SELECT  COUNT(Job.jobID) AS JobCnt, Section.sectionName FROM  JobType INNER JOIN  Job ON JobType.jobTypeID = Job.jobTypeID INNER JOIN Section ON JobType.sectionID = Section.sectionID " +
               " WHERE (Job.jobDueDate < GETDATE()-1) AND (Job.jobStatusID IN (3, 8))  GROUP BY Section.sectionName, JobType.sectionID  UNION " +
                    "SELECT  COUNT(JobOwner.jobOwnerID) AS Expr1, Section.sectionName FROM  JobOwner INNER JOIN  Section ON JobOwner.sectionID = Section.sectionID " +
                          " WHERE  (JobOwner.payID IS NOT NULL) AND (JobOwner.actionDueDate < GETDATE()-1) AND (JobOwner.jobOwnerStatusID <> 7) GROUP BY Section.sectionName";
            strSeriesName = "sectionName";

            lblOngoingJobs.Text = "Over Due Job Order In All Sections";
        }
        else if (Session["SectionID"].ToString().Equals("12"))          // Contracts Services Section
        {
            sqlQuery = "SELECT  COUNT(JobOwner.jobOwnerID) AS JobCnt, JobType_1.jobTypeName FROM JobType AS JobType_1 INNER JOIN JobType ON JobType_1.jobTypeID = JobType.CategoryID INNER JOIN  Job ON JobType.jobTypeID = Job.jobTypeID INNER JOIN " +
                        " Section ON JobOwner.sectionID = Section.sectionID INNER JOIN  JobType AS JobType_1 ON JobType.CategoryID = JobType_1.jobTypeID  WHERE (JobOwner.jobOwnerStatusID = 3) AND (JobOwner.contactID = " + _currentUserID + ") and JobOwner.sectionID=12 GROUP BY JobType.jobTypeName";
            strSeriesName = "jobTypeName";

            lblOngoingJobs.Text = "My On Going Tasks";
        }
        else if (Session["SectionID"].ToString().Equals("13"))          // Tender Services Section
        {
            sqlQuery = "SELECT  COUNT(JobOwner.jobOwnerID) AS JobCnt, JobType_1.jobTypeName FROM JobType INNER JOIN JobOwner ON JobType.jobTypeID = JobOwner.JobTypeID INNER JOIN Section ON JobOwner.sectionID = Section.sectionID INNER JOIN "+
            "JobType AS JobType_1 ON JobType.CategoryID = JobType_1.jobTypeID WHERE (JobOwner.jobOwnerStatusID = 3) AND (JobOwner.contactID = " + _currentUserID + ") and JobOwner.sectionID=13 GROUP BY JobType_1.jobTypeName";
            strSeriesName = "jobTypeName";

            lblOngoingJobs.Text = "My On Going Tasks";
        }
        else
        {
            sqlQuery = "SELECT  COUNT(JobOwner.jobOwnerID) AS JobCnt, JobType_1.jobTypeName FROM JobType INNER JOIN JobOwner ON JobType.jobTypeID = JobOwner.JobTypeID INNER JOIN Section ON JobOwner.sectionID = Section.sectionID INNER JOIN " +
            "JobType AS JobType_1 ON JobType.CategoryID = JobType_1.jobTypeID WHERE (JobOwner.jobOwnerStatusID = 3) AND (JobOwner.contactID = " + _currentUserID + ") and JobOwner.sectionID=13 GROUP BY JobType_1.jobTypeName";
            strSeriesName = "jobTypeName";
            lblOngoingJobs.Text = "My On Going Tasks";
        }

        // Chart_OverDueJobs

        SqlDataAdapter daTndr = new SqlDataAdapter(sqlQuery, connValue);
        daTndr.Fill(dsTndr);
        if (dsTndr.Tables[0].Rows.Count != 0)
        {
            tssOngoing.DataSource = dsTndr.Tables[0].DefaultView;

            tssOngoing.Series["Series1"].XValueMember = strSeriesName;
            tssOngoing.Series["Series1"].YValueMembers = "JobCnt";

            dsTndr.Tables.Clear();

            tssOngoing.ChartAreas[0].AxisX.MajorGrid.Enabled = false;
            tssOngoing.ChartAreas[0].AxisX.MinorGrid.Enabled = false;
            tssOngoing.ChartAreas[0].AxisY.MajorGrid.Enabled = false;
            tssOngoing.ChartAreas[0].AxisY.MinorGrid.Enabled = false;

            tssOngoing.ChartAreas[0].AxisX.LabelStyle.Angle = 30;
            tssOngoing.ChartAreas[0].AxisX.LabelStyle.ForeColor = Color.Maroon;

            tssOngoing.ChartAreas[0].AxisX.Interval = 1;
        }
        else
        {
            tssOngoing.DataSource = null;
        }
    }
    private void getOnGoingTasksPerStaffChart()   // chart 3
    {
        string sqlQuery = string.Empty; string strStaff = string.Empty;

        DataSet dsTndr = new DataSet();
        int sectionID = Convert.ToInt32(Session["SectionID"]);

        if (Session["userProfileID"].ToString().Equals("1"))
        {
            sqlQuery = "SELECT  TOP (20) COUNT(*) AS JobCnt, Contact.userShortName FROM  JobOwner INNER JOIN  Contact ON JobOwner.contactID = Contact.contactID  WHERE  (JobOwner.jobOwnerStatusID = 3) GROUP BY JobOwner.contactID, Contact.userShortName ORDER BY JobCnt DESC";

           // lblOngoingStaff.Text = "(Top 20) On Going Tasks Per Staff In All Sections Of EBSD";
        }
        else if (!userRightsColl.Equals("42") && Session["SectionID"].ToString().Equals("7")) //1 - All Sections
        {
            sqlQuery = "SELECT  COUNT(*) AS JobCnt, Contact.userShortName FROM JobOwner INNER JOIN Contact ON JobOwner.contactID = Contact.contactID WHERE (JobOwner.jobOwnerStatusID = 3) GROUP BY JobOwner.contactID, " +
            " Contact.userShortName ORDER BY Contact.userShortName";

           // lblOngoingStaff.Text = "On Going Tasks Per Staff In All Sections Of EBSD ";
        }
        else
        {
          //  lblOngoingStaff.Text = "On Going Tasks Per Staff In  " + Session["SectionName"].ToString();

            sqlQuery = "SELECT COUNT(*) AS JobCnt, Contact.userShortName FROM  JobOwner INNER JOIN Contact ON JobOwner.contactID = Contact.contactID " +
                      " WHERE  (JobOwner.sectionID = " + sectionID + ") AND (JobOwner.jobOwnerStatusID = 3) GROUP BY JobOwner.contactID, Contact.userShortName ORDER BY Contact.userShortName";
        }

        SqlDataAdapter daTndr = new SqlDataAdapter(sqlQuery, connValue);
        daTndr.Fill(dsTndr);
        if (dsTndr.Tables[0].Rows.Count != 0)
        {
            onGoingTasksPerStaffChart.DataSource = dsTndr.Tables[0].DefaultView;
            onGoingTasksPerStaffChart.Series["Series1"].XValueMember = "userShortName";
            onGoingTasksPerStaffChart.Series["Series1"].YValueMembers = "JobCnt";
            dsTndr.Tables.Clear();

            onGoingTasksPerStaffChart.ChartAreas[0].AxisX.MajorGrid.Enabled = false;
            onGoingTasksPerStaffChart.ChartAreas[0].AxisX.MinorGrid.Enabled = false;
            onGoingTasksPerStaffChart.ChartAreas[0].AxisY.MajorGrid.Enabled = false;
            onGoingTasksPerStaffChart.ChartAreas[0].AxisY.MinorGrid.Enabled = false;

            onGoingTasksPerStaffChart.ChartAreas[0].AxisX.LabelStyle.Angle = 30;
            onGoingTasksPerStaffChart.ChartAreas[0].AxisX.LabelStyle.ForeColor = Color.Maroon;

            onGoingTasksPerStaffChart.ChartAreas[0].AxisX.Interval = 1;
        }
        else
        {
            onGoingTasksPerStaffChart.DataSource = null;
        }
    }
    private void getCommitteeWiseClaimsChart()   // chart 3
    {
        string sqlQuery = string.Empty; string strStaff = string.Empty;

        DataSet dsTndr = new DataSet();
        int sectionID = Convert.ToInt32(Session["SectionID"]);

        if (Session["userProfileID"].ToString().Equals("1"))
        {
            sqlQuery = "SELECT   COUNT(Job.jobID) AS JobCnt, Committee.committee_name as userShortName FROM   Projects INNER JOIN    Committee ON Projects.committee_id = Committee.committee_id INNER JOIN " +
                        " Job ON Projects.proj_id = Job.tcmProj_ID GROUP BY Committee.committee_name";


            // lblOngoingStaff.Text = "(Top 20) On Going Tasks Per Staff In All Sections Of EBSD";
        }
        else if (!userRightsColl.Equals("42") && Session["SectionID"].ToString().Equals("7")) //1 - All Sections
        {
            sqlQuery = "SELECT   COUNT(Job.jobID) AS JobCnt, Committee.committee_name as userShortName FROM   Projects INNER JOIN    Committee ON Projects.committee_id = Committee.committee_id INNER JOIN " + 
                        " Job ON Projects.proj_id = Job.tcmProj_ID GROUP BY Committee.committee_name";

            // lblOngoingStaff.Text = "On Going Tasks Per Staff In All Sections Of EBSD ";
        }
        else
        {
            //  lblOngoingStaff.Text = "On Going Tasks Per Staff In  " + Session["SectionName"].ToString();

            sqlQuery = "SELECT   COUNT(Job.jobID) AS JobCnt, Committee.committee_name as Committee FROM   Projects INNER JOIN    Committee ON Projects.committee_id = Committee.committee_id INNER JOIN " +
                        " Job ON Projects.proj_id = Job.tcmProj_ID GROUP BY Committee.committee_name";

        }

        SqlDataAdapter daTndr = new SqlDataAdapter(sqlQuery, connValue);
        daTndr.Fill(dsTndr);
        if (dsTndr.Tables[0].Rows.Count != 0)
        {
            chartCommeetee.DataSource = dsTndr.Tables[0].DefaultView;
            chartCommeetee.Series["Series1"].XValueMember = "Committee";
            chartCommeetee.Series["Series1"].YValueMembers = "JobCnt";
            dsTndr.Tables.Clear();

            chartCommeetee.ChartAreas[0].AxisX.MajorGrid.Enabled = false;
            chartCommeetee.ChartAreas[0].AxisX.MinorGrid.Enabled = false;
            chartCommeetee.ChartAreas[0].AxisY.MajorGrid.Enabled = false;
            chartCommeetee.ChartAreas[0].AxisY.MinorGrid.Enabled = false;

            chartCommeetee.ChartAreas[0].AxisX.LabelStyle.Angle = 30;
            chartCommeetee.ChartAreas[0].AxisX.LabelStyle.ForeColor = Color.Maroon;

            chartCommeetee.Series["Series1"].Label = "Committee : #VALX , #VALY";         

            chartCommeetee.ChartAreas[0].AxisX.Interval = 1;
        }
        else
        {
            chartCommeetee.DataSource = null;
        }
    }
    protected void chartCommeetee_Load(object sender, EventArgs e)
    {
       // chartCommeetee.Series["Series1"].Label = "Committee : #VALX , #VALY";
    }
    protected void btnDoc_Click(object sender, EventArgs e)
    {
        Session["docID"] = null;
        Session["JobID"] = null;
        Session["PayID"] = null;

        Response.Redirect("~/Documents/DocumentDetailsWindow.aspx?btnDocNew=1&RecSentCatID=1", false);  // 1- for rec

       // Response.Redirect("~/Documents/DocumentDetailsWindow.aspx", false);

      
    }
    private void RecentlyClosedClaims()
    {
        DataSet dsTndr = new DataSet();

        string sqlQuery = null; int secID = Convert.ToInt32(Session["SectionID"]);
        string strSeriesName = string.Empty;

        sqlQuery = " SELECT  TOP (5) JobNo, ContractNo, ProjectTitle,jobReceivedDate,jobStatusClosedDate  FROM   Job WHERE (sectionID = 12) AND (jobStatusClosedDate IS NOT NULL) ORDER BY jobID DESC";

        SqlDataAdapter daTndr = new SqlDataAdapter(sqlQuery, connValue);
        daTndr.Fill(dsTndr);
        if (dsTndr.Tables[0].Rows.Count != 0)
        {
            gvJoborder.DataSource = dsTndr;
            gvJoborder.DataBind();
        }
    }

    protected void tssOngoing_Click(object sender, ImageMapEventArgs e)
    {
        Session["ActionBy"] = null;
        string sectionName = Session["SectionName"].ToString();
        Session["OverDueName"] = e.PostBackValue.ToString();
        Session["OverDue"] = "Yes";

        Session["OnGoingJobStatus"] = e.PostBackValue;

        if (Session["UserProfileID"].Equals("1"))
        {
            Response.Redirect("~/DCLog/ViewDCLog.aspx", false);
        }
        else
        {
            Response.Redirect("~/DCLog/ViewDCLog.aspx", false);
        }
    }

    protected void tssOngoing1_Click(object sender, ImageMapEventArgs e)
    {
        //Session["TSSJobTypeName"] = null;
        Session["IsTSSSearchedClicked"] = "0";
        Session["ActionBy"] = null;
        string sectionName = Session["SectionName"].ToString();
        Session["OverDueName"] = e.PostBackValue.ToString();
        Session["OverDue"] = "Yes";
        Session["OnGoingJobTypeName"] = e.PostBackValue;

        if (Session["UserProfileID"].Equals("1"))
        {
            Response.Redirect("~/DCLog/ViewDCLog.aspx", false);                 
        }
        else
        {
            Response.Redirect("~/DCLog/ViewDCLog.aspx", false);               
        }
    }


    protected void onGoingTasksPerStaffChart_Click(object sender, ImageMapEventArgs e)
    {
        Session["ShortName"] = e.PostBackValue.ToString();        
        Session["ActionBy"] = e.PostBackValue.ToString();

        if (Session["SectionID"].Equals("9"))
            Response.Redirect("~/Planning/ViewSRInfo.aspx", false);
        else if (!Session["SectionID"].Equals("4"))
            Response.Redirect("~/JobOrder/SearchAllJobs.aspx", false);
        else
            Response.Redirect("~/Survey/SurveyStaffJobs.aspx", false);
    }
    protected void onGoingTasksPerStaffChart_Click1(object sender, ImageMapEventArgs e)
    {
        //Session["TSSJobTypeName"] = null;
        
        Session["ShortName"] = e.PostBackValue.ToString();
        Session["ActionBy"] = null;
        Session["ActionBy"] = e.PostBackValue.ToString();
        if (Session["SectionID"].Equals("12"))
        {
            Session["IsTSSSearchedClicked"] = "0";
            Response.Redirect("~/Guest/SearchClaims.aspx", false);
        }
        else if (Session["SectionID"].Equals("13"))
        {
            Session["IsTSSSearchedClicked"] = "0";
            Response.Redirect("~/TSS/SearchTSSJobs.aspx", false);
        }
        else if (Session["SectionID"].Equals("9"))
            Response.Redirect("~/Planning/ViewSRInfo.aspx", false);
        else if (!Session["SectionID"].Equals("4"))
            Response.Redirect("~/JobOrder/SearchAllJobs.aspx", false);
        else
            Response.Redirect("~/Survey/SurveyStaffJobs.aspx", false);
    }

    protected void onGoingTasksPerSectionChart_Click(object sender, ImageMapEventArgs e)
    {
        Session["ShortName"] = e.PostBackValue.ToString();
        Session["ActionBy"] = null;
        Session["ActionBy"] = e.PostBackValue.ToString();

        if (Session["SectionID"].Equals("12"))
            Response.Redirect("~/DCLog/OverDueJobs.aspx", false);
        else if (!Session["SectionID"].Equals("4"))
            Response.Redirect("~/JobOrder/SearchAllJobs.aspx", false);
        else
            Response.Redirect("~/Survey/SurveyStaffJobs.aspx", false);
    }

    protected void onGoingTasksPerSectionChart1_Click(object sender, ImageMapEventArgs e)
    {         
        Session["IsTSSSearchedClicked"] = "0";
        //Session["TSSJobTypeName"] = e.PostBackValue.ToString();
        Session["ShortName"] = "";
        if (Session["SectionID"].Equals("13"))
            Response.Redirect("~/DCLog/OverDueJobs.aspx", false);
        else if (!Session["SectionID"].Equals("4"))
            Response.Redirect("~/JobOrder/SearchAllJobs.aspx", false);
        else
            Response.Redirect("~/Survey/SurveyStaffJobs.aspx", false);
    }
    private void getUnReadInchargeData()
    {
        string sqlQuery = string.Empty;

        if (Session["SectionID"].ToString().Equals("2")) // Pay
        {
            sqlQuery = "SELECT JobOwner.projectTitle,  JobOwner.jobID, JobOwner.jobNo, JobType_1.jobTypeName, [Document].referenceNo, REPLACE(CONVERT(NVARCHAR, JobOwner.staffIssueDate, 106), ' ', '-')  AS DateOfIssue, JobType_1.CategoryID AS jobCatID, JobOwner.sectionID, JobOwner.jobOwnerID, JobOwner.contactID, JobOwner.jobDocRefID, " +
                   " JobOwner.distributedBy, Contact.firstName + '  ' + Contact.lastName AS IssuedBy, JobOwner.payID, JobOwner.srID FROM   JobOwner INNER JOIN JobType ON JobOwner.JobTypeID = JobType.jobTypeID INNER JOIN  JobType AS JobType_1 ON JobType.CategoryID = JobType_1.jobTypeID INNER JOIN " +
                " [Document] ON JobOwner.jobDocRefID = [Document].documentID INNER JOIN  Contact ON JobOwner.distributedBy = Contact.contactID  WHERE  (JobOwner.jobOwnerStatusID=3) AND (JobOwner.contactID = " + _currentUserID + ") ORDER BY JobOwner.JobownerID DESC";
        }
        else if (Session["SectionID"].ToString().Equals("9")) // BS
        {

            sqlQuery = " SELECT JobOwner.projectTitle, JobOwner.srID, JobOwner.jobID, JobOwner.jobNo, '' AS referenceNo, REPLACE(CONVERT(NVARCHAR, JobOwner.staffIssueDate, 106), ' ', '-') " +
                " AS DateOfIssue, JobOwner.sectionID, JobOwner.jobOwnerID, JobOwner.contactID, JobOwner.jobDocRefID, JobOwner.distributedBy, Contact.firstName + '  ' + Contact.lastName AS IssuedBy, JobOwner.payID, ServiceType.serviceTypeDescription as jobTypeName, JobOwner.JobTypeID as jobCatID  " +
           " FROM JobOwner INNER JOIN Contact ON JobOwner.distributedBy = Contact.contactID INNER JOIN ServiceType ON JobOwner.JobTypeID = ServiceType.serviceTypeID " +
           " WHERE        (JobOwner.jobOwnerStatusID = 3) AND (JobOwner.sectionID = 9) AND (JobOwner.contactID = " + _currentUserID + ") ORDER BY JobOwner.jobOwnerID DESC";

        }
        else
        {
            sqlQuery = "SELECT   JobOwner.projectTitle, JobOwner.jobID, JobOwner.jobNo,JobOwner.projectTitle, JobType_1.jobTypeName, [Document].referenceNo, REPLACE(CONVERT(NVARCHAR, JobOwner.staffIssueDate, 106), ' ', '-')  AS DateOfIssue, JobType_1.CategoryID AS jobCatID, JobOwner.sectionID, JobOwner.jobOwnerID, JobOwner.contactID, JobOwner.jobDocRefID, " +
                       " JobOwner.distributedBy, Contact.firstName + '  ' + Contact.lastName AS IssuedBy, JobOwner.payID, JobOwner.srID FROM   JobOwner INNER JOIN JobType ON JobOwner.JobTypeID = JobType.jobTypeID INNER JOIN  JobType AS JobType_1 ON JobType.CategoryID = JobType_1.jobTypeID INNER JOIN " +
                    " [Document] ON JobOwner.jobDocRefID = [Document].documentID INNER JOIN  Contact ON JobOwner.distributedBy = Contact.contactID  WHERE  (JobOwner.dateRead IS NULL) AND (JobOwner.contactID = " + _currentUserID + ") ORDER BY JobOwner.JobownerID DESC";
        }


        SqlConnection objCon = new SqlConnection(connValue);
        SqlCommand objCmd = new SqlCommand(sqlQuery, objCon);
        SqlDataAdapter objDA = new SqlDataAdapter(objCmd);

        objDA.SelectCommand.CommandText = objCmd.CommandText.ToString();
        DataTable dt = new DataTable();
        objDA.Fill(dt);

        Session["getPayData"] = dt;

        if (dt.Rows.Count != 0)
            gridTasks.DataSource = dt.DefaultView;
        else
        {
            gridTasks.DataSource = null;
            // gridTasks.Visible = false;
        }
        gridTasks.DataBind();
    }


    protected void lnkBtnJobID_Click(object sender, EventArgs e)
    {
        Session["PayID"] = null;
        Session["JobID"] = null;
        Session["SRID"] = null;

        string strUpdateJob = Request.Url.AbsoluteUri;
        Session["UrlRef"] = strUpdateJob;
        try
        {
            //Get the LinkButton that raised the event
            LinkButton lnkJobID = (LinkButton)sender;
            //Get the row that contains this dropdown
            GridViewRow gvr = (GridViewRow)lnkJobID.NamingContainer;

            //Session["JobID"] = ((HtmlGenericControl)gvr.FindControl("divJobID")).InnerText;

            
                Session["JobID"] = ((HtmlGenericControl)gvr.FindControl("divJobID")).InnerText;

                if (Session["JobID"] == null)
                    Session["PayID"] = ((HtmlGenericControl)gvr.FindControl("divPayID")).InnerText;

                if (Session["JobID"].ToString() == "")
                    Session["PayID"] = ((HtmlGenericControl)gvr.FindControl("divPayID")).InnerText;
           
            Session["JobInchargeID"] = lnkJobID.ToolTip;

            if (Session["SectionID"].ToString().Equals("4"))
            {
                Response.Redirect("~/Survey/SurveyDetails.aspx?REQUEST_ID= " + Session["JobInchargeID"] + "", false);
            }
            else
            {
                if ((Session["PayID"] == null))
                {
                    Session["JobCatID"] = ((HtmlGenericControl)gvr.FindControl("divJobCatID")).InnerText;
                    UpdateJobOwner(Convert.ToInt32(lnkJobID.ToolTip));

                    string catID = ((HtmlGenericControl)gvr.FindControl("divJobCatID")).InnerText.Trim();

                    if (catID.Equals("108"))
                        Response.Redirect("~/Contracts/ClaimDetails.aspx?JobID= " + Session["JobID"] + "", false);
                    else if (catID.Equals("112"))
                        Response.Redirect("~/TSS/TSSJobDetails.aspx?JobID= " + Session["JobID"] + "", false);                   
                    else
                        Response.Redirect("~/JobOrder/DefaultGrid.aspx?JobID= " + Session["JobID"] + "", false);
                }
                else
                {
                    Response.Redirect("~/Payments/PaymentDetails.aspx?PayID= " + Session["PayID"] + "", false);
                }
            }
        }
        catch (Exception ex)
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Error occurred while processing the request')</script>", false);
        }
    }
   
    public void UpdateJobOwner(int jobInchargeID)
    {
        try
        {
            using (SqlConnection con = new SqlConnection(connValue))
            {
                using (SqlCommand sqlCmd = new SqlCommand())
                {
                    sqlCmd.Connection = con;
                    sqlCmd.CommandType = CommandType.Text;
                    sqlCmd.CommandText = "UPDATE JobOwner SET dateRead =@jobReadDate where jobOwnerID = @jobOwnerID";
                    sqlCmd.Parameters.AddWithValue("@jobOwnerID", jobInchargeID);
                    sqlCmd.Parameters.AddWithValue("@jobReadDate", System.DateTime.Now.ToString("dd/MMM/yyyy"));

                    con.Open();
                    sqlCmd.ExecuteNonQuery();
                }
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
}