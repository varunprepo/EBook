﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Data.SqlClient;
using System.Configuration;
using System.Data;
using System.Drawing;


public partial class TSS_TSSHome : System.Web.UI.Page
{
    string strConn = ConfigurationManager.ConnectionStrings["TCMSConn"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            getChart_ProjectStatusWise();
            getChart_ProjectTypeWise();
            getChart_ProjectTypeWise();
            getChart_TenderStatusWise();
            getChart_CommeetteeWise();           
            
            lblUser.Text = Session["UserDisplayName"].ToString();
            lblUserProfile.Text = Session["ProfileName"].ToString();           

            // mUserRightsColl = userRightsCollPrjState;
        }
    }
    private void ProjectArcives_RunningProjects()
    {
        DataSet dsDoc = new DataSet();
        string sqlQuery = null;
        sqlQuery = "SELECT        PROJECTS.project_code, PROJECTS.project_newname_en, PROJECTS.tender_no, TenderStatus.Status_Name, TenderTypes.tender_type_name, " + 
                       "  Committee.committee_name, FiscalYear.FiscalYear, Department.Department FROM   PROJECTS INNER JOIN  TenderStatus ON PROJECTS.Tender_Status_id = TenderStatus.Tender_Status_id INNER JOIN " + 
                         " TenderTypes ON PROJECTS.tender_type_id = TenderTypes.tender_type_id INNER JOIN  Committee ON PROJECTS.committee_id = Committee.committee_id INNER JOIN " + 
                         " FiscalYear ON PROJECTS.FYID = FiscalYear.FYID INNER JOIN   Department ON PROJECTS.department_id = Department.department_id WHERE        (PROJECTS.Tender_Status_id IN (1, 2))";

        SqlDataAdapter daDoc = new SqlDataAdapter(sqlQuery, strConn);
        daDoc.Fill(dsDoc);
        if (dsDoc.Tables[0].Rows.Count != 0)
        {
            grvProjArchive.DataSource = dsDoc.Tables[0];
            grvProjArchive.DataBind();
        }
    }
    private void getChart_ProjectStatusWise()
    {
        DataSet dsDoc = new DataSet();

        string sqlQuery = null;

        sqlQuery = "SELECT  STAGES.Stage_Name AS PrjStatus, COUNT(PROJECTS.proj_id) AS PrjCnt FROM PROJECTS INNER JOIN STAGES ON PROJECTS.stage_id = STAGES.stage_id WHERE (YEAR(PROJECTS.create_date) = " + ddlYaer.SelectedItem.Text + ") GROUP BY STAGES.Stage_Name, YEAR(PROJECTS.create_date)";
        
        SqlDataAdapter daDoc = new SqlDataAdapter(sqlQuery, strConn);
        daDoc.Fill(dsDoc);
        if (dsDoc.Tables[0].Rows.Count != 0)
        {
            projectsStatusWise.DataSource = dsDoc.Tables[0].DefaultView;
            projectsStatusWise.Series["Series1"].XValueMember = "PrjStatus";
            projectsStatusWise.Series["Series1"].YValueMembers = "prjCnt";

            dsDoc.Tables.Clear();

            projectsStatusWise.ChartAreas[0].AxisX.MajorGrid.Enabled = false;
            projectsStatusWise.ChartAreas[0].AxisX.MinorGrid.Enabled = false;
            projectsStatusWise.ChartAreas[0].AxisY.MajorGrid.Enabled = false;
            projectsStatusWise.ChartAreas[0].AxisY.MinorGrid.Enabled = false;

            projectsStatusWise.ChartAreas[0].AxisX.LabelStyle.Angle = 30;
            projectsStatusWise.ChartAreas[0].AxisX.LabelStyle.ForeColor = Color.Maroon;

            projectsStatusWise.ChartAreas[0].AxisX.Interval = 1;
        }
    }
    private void getChart_ProjectTypeWise()
    {
        DataSet dsDoc = new DataSet();

        string sqlQuery = null;

        sqlQuery = "SELECT   COUNT(PROJECTS.proj_id) AS PrjCnt, ContractTypes.TypeofContract FROM   PROJECTS INNER JOIN  ContractTypes ON PROJECTS.contract_type_id = ContractTypes.contract_type_id " +
                "WHERE  (YEAR(PROJECTS.create_date) = " + ddlYaer.SelectedItem.Text + ") GROUP BY ContractTypes.TypeofContract, YEAR(PROJECTS.create_date)";

        SqlDataAdapter daDoc = new SqlDataAdapter(sqlQuery, strConn);
        daDoc.Fill(dsDoc);
        if (dsDoc.Tables[0].Rows.Count != 0)
        {
            projectTypeWise.DataSource = dsDoc.Tables[0].DefaultView;
            projectTypeWise.Series["Series1"].XValueMember = "TypeofContract";
            projectTypeWise.Series["Series1"].YValueMembers = "prjCnt";

            dsDoc.Tables.Clear();

            projectTypeWise.ChartAreas[0].AxisX.MajorGrid.Enabled = false;
            projectTypeWise.ChartAreas[0].AxisX.MinorGrid.Enabled = false;
            projectTypeWise.ChartAreas[0].AxisY.MajorGrid.Enabled = false;
            projectTypeWise.ChartAreas[0].AxisY.MinorGrid.Enabled = false;

            projectTypeWise.ChartAreas[0].AxisX.LabelStyle.Angle = 30;
            projectTypeWise.ChartAreas[0].AxisX.LabelStyle.ForeColor = Color.Maroon;

            projectTypeWise.ChartAreas[0].AxisX.Interval = 1;
        }
    }
  
    private void getChart_TenderStatusWise()
    {
        DataSet dsDoc = new DataSet();

        string sqlQuery = null;
        sqlQuery = "SELECT        COUNT(PROJECTS.proj_id) AS PrjCnt, TenderStatus.Status_Name FROM PROJECTS INNER JOIN TenderStatus ON PROJECTS.Tender_Status_id = TenderStatus.Tender_Status_id" +
                    " WHERE        (YEAR(PROJECTS.create_date) = " + ddlYaer.SelectedItem.Text + ") GROUP BY YEAR(PROJECTS.create_date), TenderStatus.Status_Name";

        SqlDataAdapter daDoc = new SqlDataAdapter(sqlQuery, strConn);
        daDoc.Fill(dsDoc);
        if (dsDoc.Tables[0].Rows.Count != 0)
        {
            chartStatus.DataSource = dsDoc.Tables[0].DefaultView;
            chartStatus.Series["Series1"].XValueMember = "Status_Name";
            chartStatus.Series["Series1"].YValueMembers = "prjCnt";

            dsDoc.Tables.Clear();

            chartStatus.ChartAreas[0].AxisX.MajorGrid.Enabled = false;
            chartStatus.ChartAreas[0].AxisX.MinorGrid.Enabled = false;
            chartStatus.ChartAreas[0].AxisY.MajorGrid.Enabled = false;
            chartStatus.ChartAreas[0].AxisY.MinorGrid.Enabled = false;

            chartStatus.ChartAreas[0].AxisX.LabelStyle.Angle = 30;
            chartStatus.ChartAreas[0].AxisX.LabelStyle.ForeColor = Color.Maroon;

            chartStatus.ChartAreas[0].AxisX.Interval = 1;
        }
    }
    private void getChart_CommeetteeWise()
    {
        DataSet dsDoc = new DataSet();
        string sqlQuery = null;
        sqlQuery = "SELECT        COUNT(PROJECTS.proj_id) AS PrjCnt, Committee.committee_name FROM PROJECTS INNER JOIN   Committee ON PROJECTS.committee_id = Committee.committee_id " +
              " WHERE        (YEAR(PROJECTS.create_date) = " + ddlYaer.SelectedItem.Text + ") GROUP BY YEAR(PROJECTS.create_date), Committee.committee_name";

        SqlDataAdapter daDoc = new SqlDataAdapter(sqlQuery, strConn);
        daDoc.Fill(dsDoc);
        if (dsDoc.Tables[0].Rows.Count != 0)
        {
            chartCommeetee.DataSource = dsDoc.Tables[0].DefaultView;
            chartCommeetee.Series["Series1"].XValueMember = "committee_name";
            chartCommeetee.Series["Series1"].YValueMembers = "prjCnt";

            dsDoc.Tables.Clear();

            chartCommeetee.ChartAreas[0].AxisX.MajorGrid.Enabled = false;
            chartCommeetee.ChartAreas[0].AxisX.MinorGrid.Enabled = false; 
            chartCommeetee.ChartAreas[0].AxisY.MajorGrid.Enabled = false;
            chartCommeetee.ChartAreas[0].AxisY.MinorGrid.Enabled = false;

            chartCommeetee.ChartAreas[0].AxisX.LabelStyle.Angle = 30;
            chartCommeetee.ChartAreas[0].AxisX.LabelStyle.ForeColor = Color.Maroon;

            chartCommeetee.ChartAreas[0].AxisX.Interval = 1;
        }
    }

    protected void ddlTeam_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void ddlYaer_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlYaer.SelectedIndex != 0)
        {
            getChart_ProjectStatusWise();

            getChart_ProjectTypeWise();         

            getChart_ProjectTypeWise();          

            getChart_TenderStatusWise();

            getChart_CommeetteeWise();
        }
    }    
    protected void btnSearch_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/TSS/SearchTSSJobs.aspx", false);
    }
    protected void btnNewPrj_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/TSS/CreateTSSJob.aspx", false);
    }
    protected void chartStatus_Load(object sender, EventArgs e)
    {

    }
    protected void lnkLogOutBtn_Click(object sender, EventArgs e)
    {
      //  Session.Abandon();
        Response.Redirect("~/LoginPage.aspx", false);
    }
    protected void btnTndrNo_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/Guest/ViewProjects.aspx", false);
    }
    protected void btnClaimSearch_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/TSS/SearchTSSJobs.aspx", false);
    }
    protected void btnDele_Click(object sender, EventArgs e)
    {
        ProjectArcives_RunningProjects();
    }
}