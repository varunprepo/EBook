﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Globalization;

public partial class AutoReply : System.Web.UI.Page
{
    string connValue = ConfigurationManager.ConnectionStrings["EBSDEBookConn"].ToString();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["UserName"] != null)
            {                 
                DAL dal = null;
                try
                {                                 
                    dal = new DAL(connValue);
                    if (dal.ConnectDB(this.Page) == 'E')
                        return;
                    SqlCommand sqlCommand = new SqlCommand("select isAutoReplyActive,REPLACE(CONVERT(nvarchar,startDate,106),' ','/') as startDate,REPLACE(CONVERT(nvarchar,endDate,106),' ','/') as endDate,userMsg from Contact where contactID=@contactID", dal.SqlConnection);
                    sqlCommand.Parameters.AddWithValue("@contactID", Session["UserID"].ToString());
                    SqlDataReader sqlDtReader = sqlCommand.ExecuteReader();

                    if (sqlDtReader.Read())
                    {
                        if(sqlDtReader[0].ToString()=="False")
                        {
                            rdbNoActivation.Checked = true;
                            EnableDisableControls(true);
                        }
                        else
                        {
                            rdbActivation.Checked = true;                               
                            EnableDisableControls(false);
                            txtStartDate.Value = DateTime.ParseExact(sqlDtReader[1].ToString().Split(' ')[0], "dd/MMM/yyyy", CultureInfo.InvariantCulture).ToString("dd/MMM/yyyy");
                            txtEndDate.Value = DateTime.ParseExact(sqlDtReader[2].ToString().Split(' ')[0], "dd/MMM/yyyy", CultureInfo.InvariantCulture).ToString("dd/MMM/yyyy");
                            txtArea.Value = sqlDtReader[3].ToString();
                        }
                    }
                    sqlDtReader.Close();                    
                }
                catch (Exception ex)
                {
                    ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Error occurred while performing database operation')</script>", false);
                }
                finally
                {
                    if (dal != null)
                        dal.DisconnectDB();
                }
               
            }
            else
                Response.Redirect("~/LoginPage.aspx", false);
        }
    }
    protected void rdbNoActivation_CheckedChanged(object sender, EventArgs e)
    {
        EnableDisableControls(true);
    }
    protected void rdbActivation_CheckedChanged(object sender, EventArgs e)
    {
        EnableDisableControls(false);
    }

    private void EnableDisableControls(bool isEnabled)
    {
        txtStartDate.Disabled = isEnabled;
        txtEndDate.Disabled = isEnabled;  
        txtArea.Disabled = isEnabled;         
    }
    protected void btnSaveAutoReplySettings_Click(object sender, EventArgs e)
    {
        if (Session["UserName"] != null)
        {            
            DAL dal = null;
            try
            {                          
                dal = new DAL(connValue);
                if (dal.ConnectDB(this.Page) == 'E')
                    return;
                SqlCommand sqlCmd = new SqlCommand("update Contact set startDate=@startDate,endDate=@endDate,userMsg=@userMsg,isAutoReplyActive=@isAutoReplyActive where contactID=@contactID", dal.SqlConnection);
                sqlCmd.Parameters.AddWithValue("@contactID", Session["UserID"].ToString());
                if (rdbActivation.Checked)
                {
                    sqlCmd.Parameters.AddWithValue("@startDate", DateTime.ParseExact(txtStartDate.Value, "dd/MMM/yyyy", CultureInfo.InvariantCulture));
                    sqlCmd.Parameters.AddWithValue("@endDate", DateTime.ParseExact(txtEndDate.Value, "dd/MMM/yyyy", CultureInfo.InvariantCulture));
                    sqlCmd.Parameters.AddWithValue("@isAutoReplyActive", 1);
                    sqlCmd.Parameters.AddWithValue("@userMsg", txtArea.InnerText);
                    sqlCmd.ExecuteNonQuery();                     
                }
                else
                {
                    sqlCmd.Parameters.AddWithValue("@startDate", DBNull.Value);
                    sqlCmd.Parameters.AddWithValue("@endDate", DBNull.Value);
                    sqlCmd.Parameters.AddWithValue("@isAutoReplyActive", 0);
                    sqlCmd.Parameters.AddWithValue("@userMsg", DBNull.Value);
                    sqlCmd.ExecuteNonQuery();                     
                }     
                    
            }
            catch (Exception ex)
            {
                ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('"+ex.Message.Replace("'","")+"')</script>", false);              
            }
            finally
            {
                if (dal != null)
                    dal.DisconnectDB();
            }
            string script = "this.window.close();";
            ClientScript.RegisterClientScriptBlock(this.GetType(), "PageClose", script, true);
        }
        else
            Response.Redirect("~/LoginPage.aspx", false);
    }
}