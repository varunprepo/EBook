﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using Datalayer;
using System.Data;
using System.Drawing;
using Microsoft.Reporting.WebForms;
using System.Configuration;
using System.Net;


public partial class Reports_CostEstimateReport : System.Web.UI.Page
{   
    string connValue = ConfigurationManager.ConnectionStrings["EBSDEBookConn"].ToString();
    UtilityClass uCls = null;
    DAL dal = null;
    static string strRptURL = string.Empty;
    string strRptFilter = string.Empty;
    protected void Page_Load(object sender, EventArgs e)
    {
        strRptURL = getServerURL();
        if (Session["UserName"] == null)
        {
            Response.Redirect("~/LoginPage.aspx", false);
            return;
        }

       // userRightsColl = (IList<string>)Session["UserRightsColl"];
        if (!IsPostBack)
        {
           // if (Session["userProfileID"].Equals("1"))
            {
                
                               
                trClearButton.Visible = false;

                string sqlQueryYear = "SELECT COUNT(Job.jobID) AS jobCnt, YEAR(Job.jobReceivedDate) AS Year FROM   JobVOSI INNER JOIN    Job ON JobVOSI.jobID = Job.jobID INNER JOIN " +
                            " JobType ON Job.jobTypeID = JobType.jobTypeID WHERE  (JobType.CategoryID IN (4)) GROUP BY YEAR(Job.jobReceivedDate)";
                PopulateDropDownBox(ddlYear, sqlQueryYear, "Year", "Year");

                string sqlQueryDept = "SELECT  COUNT(Job.jobID) AS jobCnt, Job.deptID, Department.deptName FROM     JobVOSI INNER JOIN    Job ON JobVOSI.jobID = Job.jobID INNER JOIN " +
                             " JobType ON Job.jobTypeID = JobType.jobTypeID INNER JOIN Department ON Job.deptID = Department.departmentID  WHERE  (JobType.CategoryID IN (4)) GROUP BY Job.deptID, Department.deptName ORDER BY Department.deptName";
                
                PopulateDropDownBox(ddlDept, sqlQueryDept, "deptID", "deptName");

                string strAffair = "SELECT  COUNT(Job.jobID) AS jobCnt, Department_1.deptName AS AffairName, Department_1.departmentID AS AffairID FROM  JobVOSI INNER JOIN  Job ON JobVOSI.jobID = Job.jobID INNER JOIN " +
                            " JobType ON Job.jobTypeID = JobType.jobTypeID INNER JOIN   Department ON Job.deptID = Department.departmentID INNER JOIN   Department AS Department_1 ON Department.affairID = Department_1.departmentID " +
                              " WHERE   (JobType.CategoryID IN (4)) GROUP BY Department_1.deptName, Department_1.departmentID ORDER BY AffairName";

                PopulateDropDownBox(ddlAffair, strAffair, "AffairID", "AffairName");

                string strMinistry = "SELECT    Job.ministryCode FROM  JobVOSI INNER JOIN   Job ON JobVOSI.jobID = Job.jobID INNER JOIN    JobType ON Job.jobTypeID = JobType.jobTypeID WHERE  (JobType.CategoryID IN (4))  GROUP BY Job.ministryCode HAVING   (Job.ministryCode IS NOT NULL)";
                PopulateDropDownBox(ddlMinistry, strMinistry, "ministryCode", "ministryCode");

                string strBudRef = "SELECT Job.budgetRefNo  FROM  JobVOSI INNER JOIN   Job ON JobVOSI.jobID = Job.jobID INNER JOIN    JobType ON Job.jobTypeID = JobType.jobTypeID WHERE  (JobType.CategoryID IN (4))  GROUP BY Job.budgetRefNo  HAVING   (Job.budgetRefNo  IS NOT NULL)";
                PopulateDropDownBox(ddlBudget, strBudRef, "budgetRefNo", "budgetRefNo");

                string strProvision = "SELECT Job.provisionNo  FROM  JobVOSI INNER JOIN   Job ON JobVOSI.jobID = Job.jobID INNER JOIN    JobType ON Job.jobTypeID = JobType.jobTypeID WHERE  (JobType.CategoryID IN (4))  GROUP BY Job.provisionNo  HAVING   (Job.provisionNo  IS NOT NULL)";
                PopulateDropDownBox(ddlProv, strProvision, "provisionNo", "provisionNo");

                string strRptFilter = "CostEstimate";

                IList<string> rptColl = GetReportParameters(strRptFilter);


                try
                {

                    ServerReport serverReport = rptViewer.ServerReport;
                    IReportServerCredentials irsc = new CustomReportCredentials(ConfigurationManager.AppSettings["userNameForReport"].ToString(), ConfigurationManager.AppSettings["passWordForReport"].ToString(),
                    ConfigurationManager.AppSettings["domainName"].ToString());
                    serverReport.ReportServerCredentials = irsc;
                    rptViewer.ProcessingMode = ProcessingMode.Remote;
                    serverReport.ReportServerUrl = new Uri(strRptURL);
                   
                  //  serverReport.ReportPath = "/" + rptColl[0] + "/" + rptColl[1];


                    string val = null;

                    //if (ddlYear.SelectedIndex != 0)
                    //    rptViewer.ServerReport.SetParameters(new ReportParameter("Year", ddlYear.SelectedValue, false));
                    //else
                    //    rptViewer.ServerReport.SetParameters(new ReportParameter("Year", val, false));

                    //if (ddlAffair.SelectedIndex != 0)
                    //    rptViewer.ServerReport.SetParameters(new ReportParameter("Affair", ddlAffair.SelectedValue, false));
                    //else
                    //    rptViewer.ServerReport.SetParameters(new ReportParameter("Affair", val, false));

                    serverReport.ReportPath = "/" + rptColl[0] + "/" + rptColl[1];
                    this.rptViewer.ServerReport.Refresh();  
                  
                }
                catch (Exception ex)
                {

                }
                finally
                {
                   
                }
            }
        }
    }
    private string getServerURL()
    {
        string strURL = string.Empty;
        try
        {
            string strQuery = "SELECT reportURL From ReportServer";
            SqlConnection conn = new SqlConnection(connValue);
            conn.Open();

            SqlCommand sqlCmd = new SqlCommand(strQuery, conn);
            sqlCmd.CommandText = strQuery;
            sqlCmd.CommandType = CommandType.Text;
            sqlCmd.Connection = conn;
            using (SqlDataReader sqlDtReader = sqlCmd.ExecuteReader())
            {
                while (sqlDtReader.Read())
                {
                    strURL = sqlDtReader["reportURL"].ToString();
                }
            }
        }
        catch (Exception ex)
        {
        }

        return strURL;
    }

    private void PopulateDropDownBox(DropDownList ddlBox, string sqlQuery, string valueMember, string displayName)
    {
        ddlBox.DataBound += new EventHandler(this.ddlBox_DataBound);
        ddlBox.DataSource = new JobOrderData().FillDropdown(sqlQuery);
        ddlBox.DataTextField = displayName;
        ddlBox.DataValueField = valueMember;
        ddlBox.SelectedIndex = -1;
        ddlBox.DataBind();
    }
    protected void ddlBox_DataBound(object sender, EventArgs e)
    {
        DropDownList ddl = (DropDownList)sender;
        ListItem emptyItem = new ListItem("", "");
        ddl.Items.Insert(0, emptyItem);
    }
    
    
    protected void btnClear_Click(object sender, EventArgs e)
    {

    }
    protected void ddlYear_SelectedIndexChanged(object sender, EventArgs e)
    {
        string strRptFilter = "CostEstimate";

        IList<string> rptColl = GetReportParameters(strRptFilter);

        string sqlQueryDept = "SELECT  COUNT(Job.jobID) AS jobCnt, Job.deptID, Department.deptName FROM JobVOSI INNER JOIN  Job ON JobVOSI.jobID = Job.jobID INNER JOIN " +
                             " JobType ON Job.jobTypeID = JobType.jobTypeID INNER JOIN Department ON Job.deptID = Department.departmentID  WHERE  (JobType.CategoryID IN (4)) GROUP BY Job.deptID, Department.deptName ORDER BY Department.deptName";

        ddlDept.DataSource = null;

        PopulateDropDownBox(ddlDept, sqlQueryDept, "deptID", "deptName");


        string strMinistry = "SELECT Job.ministryCode FROM  JobVOSI INNER JOIN   Job ON JobVOSI.jobID = Job.jobID INNER JOIN    JobType ON Job.jobTypeID = JobType.jobTypeID WHERE  (JobType.CategoryID IN (4))  AND (Job.affairID = 2) GROUP BY Job.ministryCode HAVING   (Job.ministryCode IS NOT NULL) ";

        ddlMinistry.DataSource = null;

        PopulateDropDownBox(ddlMinistry, strMinistry, "ministryCode", "ministryCode");


        try
        {

            // serverReport.ReportPath = "/COST_CONTROL_EXT/CostEstimateManagement_TEST"; 

            ServerReport serverReport = rptViewer.ServerReport;
            IReportServerCredentials irsc = new CustomReportCredentials(ConfigurationManager.AppSettings["userNameForReport"].ToString(), ConfigurationManager.AppSettings["passWordForReport"].ToString(),
            ConfigurationManager.AppSettings["domainName"].ToString());
            serverReport.ReportServerCredentials = irsc;
            rptViewer.ProcessingMode = ProcessingMode.Remote;
            serverReport.ReportServerUrl = new Uri(strRptURL);
            ReportParameter jobOrderYear = new ReportParameter();
            //  serverReport.ReportPath = "/" + rptColl[0] + "/" + rptColl[1];


            string val = null;

            if (ddlYear.SelectedIndex != 0)
                rptViewer.ServerReport.SetParameters(new ReportParameter("Year", ddlYear.SelectedValue, false));
            else
                rptViewer.ServerReport.SetParameters(new ReportParameter("Year", val, false));

            if (ddlAffair.SelectedIndex != 0)
                rptViewer.ServerReport.SetParameters(new ReportParameter("Affair", ddlAffair.SelectedValue, false));
            else
                rptViewer.ServerReport.SetParameters(new ReportParameter("Affair", val, false));

            serverReport.ReportPath = "/" + rptColl[0] + "/" + rptColl[1];
            this.rptViewer.ServerReport.Refresh();
        }
        catch (Exception ex)
        {

        }
        finally
        {

        }
    }
    protected void ddlAffair_SelectedIndexChanged(object sender, EventArgs e)
    {

        string strRptFilter = "CostEstimate";

        IList<string> rptColl = GetReportParameters(strRptFilter);

        string sqlQueryDept = "SELECT  COUNT(Job.jobID) AS jobCnt, Job.deptID, Department.deptName FROM JobVOSI INNER JOIN  Job ON JobVOSI.jobID = Job.jobID INNER JOIN " +
                             " JobType ON Job.jobTypeID = JobType.jobTypeID INNER JOIN Department ON Job.deptID = Department.departmentID  WHERE  (JobType.CategoryID IN (4))  AND (Department.affairID = " + ddlAffair.SelectedValue +")  GROUP BY Job.deptID, Department.deptName ORDER BY Department.deptName";

        ddlDept.DataSource = null;

        PopulateDropDownBox(ddlDept, sqlQueryDept, "deptID", "deptName");


        string strMinistry = "SELECT Job.ministryCode FROM  JobVOSI INNER JOIN   Job ON JobVOSI.jobID = Job.jobID INNER JOIN    JobType ON Job.jobTypeID = JobType.jobTypeID WHERE  (JobType.CategoryID IN (4))  AND (Job.affairID = 2) GROUP BY Job.ministryCode HAVING   (Job.ministryCode IS NOT NULL) ";

        ddlMinistry.DataSource = null;

        PopulateDropDownBox(ddlMinistry, strMinistry, "ministryCode", "ministryCode");


        try
        {
          
           // serverReport.ReportPath = "/COST_CONTROL_EXT/CostEstimateManagement_TEST"; 

            ServerReport serverReport = rptViewer.ServerReport;
            IReportServerCredentials irsc = new CustomReportCredentials(ConfigurationManager.AppSettings["userNameForReport"].ToString(), ConfigurationManager.AppSettings["passWordForReport"].ToString(),
            ConfigurationManager.AppSettings["domainName"].ToString());
            serverReport.ReportServerCredentials = irsc;
            rptViewer.ProcessingMode = ProcessingMode.Remote;
            serverReport.ReportServerUrl = new Uri(strRptURL);
            ReportParameter jobOrderYear = new ReportParameter();
          //  serverReport.ReportPath = "/" + rptColl[0] + "/" + rptColl[1];


            string val = null;

            if (ddlYear.SelectedIndex != 0)
                rptViewer.ServerReport.SetParameters(new ReportParameter("Year", ddlYear.SelectedValue, false));
            else
                rptViewer.ServerReport.SetParameters(new ReportParameter("Year", val, false));

            if (ddlAffair.SelectedIndex != 0)
                rptViewer.ServerReport.SetParameters(new ReportParameter("Affair", ddlAffair.SelectedValue, false));
            else
                rptViewer.ServerReport.SetParameters(new ReportParameter("Affair", val, false));

            serverReport.ReportPath = "/" + rptColl[0] + "/" + rptColl[1];
            this.rptViewer.ServerReport.Refresh();  
        }
        catch (Exception ex)
        {

        }
        finally
        {

        }
    }
    private IList<string> GetReportParameters(string filterName)
    {
        IList<string> strColl = null;
        try
        {
            dal = new DAL(connValue);
            if (dal.ConnectDB(this.Page) != 'E')
            {


                string strQuery = "SELECT r.* FROM Reports r,ReportsFilter f,ReportsMainMenu m,ReportsSubMenu s WHERE r.rptMainMenuID = m.rptMainMenuID AND r.rptSubMenuID = s.rptSubMenuID AND r.rptFilterID = f.rptfilterID AND " +
                " f.rptfilterdescription = '" + filterName + "' and " +
                                      " r.rptMainMenuID = @rptMainMenuID and r.rptSubMenuID = @rptSubMenuID";

                SqlCommand sqlCmd = new SqlCommand(strQuery, dal.SqlConnection);

                //"select moduleName,reportName,parameters from Reports join ReportsMainMenu on Reports.rptMainMenuID=ReportsMainMenu.rptMainMenuID join ReportsSubMenu on Reports.rptSubMenuID=ReportsSubMenu.rptSubMenuID " +
                //"where Reports.rptMainMenuID=@rptMainMenuID and Reports.rptSubMenuID=@rptSubMenuID  AND (Reports.rptFilterID = @rptFilterID)"

                sqlCmd.Parameters.AddWithValue("@rptMainMenuID", 5);
                sqlCmd.Parameters.AddWithValue("@rptSubMenuID", 5);
                sqlCmd.Parameters.AddWithValue("@rptFilterID", 0);

                SqlDataReader sqlDtReader = sqlCmd.ExecuteReader();

                if (sqlDtReader.Read())
                {
                    strColl = new List<string>();
                    strColl.Add(sqlDtReader["moduleName"].ToString());
                    strColl.Add(sqlDtReader["reportName"].ToString());
                    strColl.Add(sqlDtReader["parameters"].ToString());
                }
            }
            dal.DisconnectDB();

        }
        catch (Exception ex)
        {

        }
        return strColl;
    }
    protected void ddlDept_SelectedIndexChanged(object sender, EventArgs e)
    {
       
    }
    protected void ddlMinistry_SelectedIndexChanged(object sender, EventArgs e)
    {

       

        //string sqlQueryDept = "SELECT  COUNT(Job.jobID) AS jobCnt, Job.deptID, Department.deptName FROM JobVOSI INNER JOIN  Job ON JobVOSI.jobID = Job.jobID INNER JOIN " +
        //                     " JobType ON Job.jobTypeID = JobType.jobTypeID INNER JOIN Department ON Job.deptID = Department.departmentID  WHERE  (JobType.CategoryID IN (4))  AND (Department.affairID = " + ddlAffair.SelectedValue + ")  GROUP BY Job.deptID, Department.deptName ORDER BY Department.deptName";

        //ddlDept.DataSource = null;

        //PopulateDropDownBox(ddlDept, sqlQueryDept, "deptID", "deptName");
    }
    protected void ddlBudget_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void ddlProv_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {

    }
    protected void btnExport_Click(object sender, EventArgs e)
    {

    }
    protected void gvCostEstimate_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {

    }
    protected void gvCostEstimate_RowDataBound(object sender, GridViewRowEventArgs e)
    {

    }
    protected void myDocsChart_Click(object sender, ImageMapEventArgs e)
    {

    }
    protected void sectionWiseDoc_Click(object sender, ImageMapEventArgs e)
    {

    }

    public class CustomReportCredentials : IReportServerCredentials
    {
        private string _UserName;
        private string _PassWord;
        private string _DomainName;

        public CustomReportCredentials(string UserName, string PassWord, string DomainName)
        {
            _UserName = UserName;
            _PassWord = PassWord;
            _DomainName = DomainName;
        }

        public System.Security.Principal.WindowsIdentity ImpersonationUser
        {
            get { return null; }
        }

        public ICredentials NetworkCredentials
        {
            get { return new NetworkCredential(_UserName, _PassWord, _DomainName); }
        }

        public bool GetFormsCredentials(out Cookie authCookie, out string user,
         out string password, out string authority)
        {
            authCookie = null;
            user = password = authority = null;
            return false;
        }
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        ddlYear.SelectedIndex = 0;
        ddlAffair.SelectedIndex = 0;
        ddlDept.SelectedIndex = 0;
        ddlMinistry.SelectedIndex = 0;
        ddlProv.SelectedIndex = 0;
        ddlBudget.SelectedIndex = 0;
    }
}