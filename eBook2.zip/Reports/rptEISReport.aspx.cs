﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using Microsoft.Reporting.WebForms;
using System.Net;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using Datalayer;

public partial class Reports_rptEISReport : System.Web.UI.Page
{
    string connValue = ConfigurationManager.ConnectionStrings["EBSDEBookConn"].ToString();
    static string strRptURL = string.Empty;
    string strRptFilter = string.Empty;
    IList<string> userRightsColl = new List<string>();
    IList<string> rptColl = new List<string>();
    string rptName = string.Empty;
    string sqlJobType = null;
    string sqlJobCat = null;
    #region MyRegion

    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (Session["UserRightsColl"] != null)
            {
                userRightsColl = (IList<string>)Session["UserRightsColl"];
                strRptURL = getServerURL();

                if (!Page.IsPostBack)
                {
                    ClearTextInControls();
                    generateDefaultReport("11", "21");

                    string sqlQueryMain = string.Empty;
                    if (Session["UserProfileID"].ToString().Equals("1"))
                    {
                        sqlQueryMain = "select rptMainMenuID,rptMainMenuDescription from ReportsMainMenu where rptMainMenuID <> 0 and sectionID = 11 order by rptMainMenuID";
                        sqlJobType = "SELECT  jobTypeID, jobTypeName FROM JobType WHERE sectionID = " + Session["SectionID"] + " and (jobTypeID <> CategoryID) and jobTypeID IN (80,84,88,100,101,102,103,104,105,86,83)";
                        sqlJobCat = "SELECT  CategoryID, jobTypeName FROM JobType WHERE sectionID = " + Session["SectionID"] + " and (jobTypeID = CategoryID) and CategoryID not in(76,77,78,79)";
                    }
                    else
                    {
                        if (!userRightsColl.Contains("24"))
                            sqlQueryMain = "select rptMainMenuID,rptMainMenuDescription from ReportsMainMenu where rptMainMenuID <> 0 and sectionID = " + Convert.ToInt16(Session["SectionID"]) + " order by rptMainMenuID";
                        else
                            sqlQueryMain = "select rptMainMenuID,rptMainMenuDescription from ReportsMainMenu where rptMainMenuID not in(0,5,6) and sectionID = " + Convert.ToInt16(Session["SectionID"]) + " order by rptMainMenuID";
                        sqlJobType = "SELECT jobTypeID, jobTypeName FROM JobType WHERE (sectionID = " + Session["SectionID"] + ") AND (jobTypeID <> CategoryID) and jobTypeID IN (80,84,88,100,101,102,103,104,105,86,83)";
                        sqlJobCat = "SELECT CategoryID, jobTypeName FROM JobType WHERE (sectionID = " + Session["SectionID"] + ") AND (jobTypeID = CategoryID) and CategoryID not in(76,77,78,79)";
                    }
                    PopulateDropDownBox(ddlReportsMainMenu, sqlQueryMain, "rptMainMenuID", "rptMainMenuDescription");
                    PopulateDropDownBox(ddlJobType, sqlJobType, "jobTypeID", "jobTypeName");
                    PopulateDropDownBox(ddlJobCat, sqlJobCat, "CategoryID", "jobTypeName");
                    PopulateDropDownBox(ddlJobStatus, "SELECT JobStatusID, JobStatusName FROM JobStatus Where JobStatusID in(1,2,3,5,6,7) ORDER BY JobStatusName", "JobStatusID", "JobStatusName");
                }
            }
            else
            {
                Response.Redirect("~/LoginPage.aspx", false);
            }
        }
        catch (Exception ex)
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "Popup", "<script>alert('Error occurred while displaying the report.')</script>", false);
        }
        
    }
    private void generateDefaultReport(string mainID, string subID)
    {
        ServerReport serverReport = rptViewer.ServerReport;
        IReportServerCredentials irsc = new CustomReportCredentials(ConfigurationManager.AppSettings["userNameForReport"].ToString(), ConfigurationManager.AppSettings["passWordForReport"].ToString(),
        ConfigurationManager.AppSettings["domainName"].ToString());
        serverReport.ReportServerCredentials = irsc;
        rptViewer.ProcessingMode = ProcessingMode.Remote;
        serverReport.ReportServerUrl = new Uri(strRptURL);
        IList<string> strReportColl = null;
        if (mainID != "" && subID != "")
        {
            strReportColl = GetReportParametersBySelectionDefault(mainID, subID, 0);
        }
        else if (mainID != "" && (subID == "" || subID == "0"))
        {
            strReportColl = GetReportParametersBySelectionDefault(mainID, "21", 0);
        }
        serverReport.ReportPath = "/" + strReportColl[0] + "/" + strReportColl[1];
        CreateParametersForReport(strReportColl);
        this.rptViewer.ServerReport.Refresh();
    }
    private string CreateParametersForReport(IList<string> rptColl)
    {
        string rptName = string.Empty;
        rptName = "/" + rptColl[0] + "/" + rptColl[1];

        string[] parameterColl = rptColl[2].Split(',');
        foreach (var rptParameter in parameterColl)          // jobStatusID,contactID,jobUnread 
        {
            string val = null;

            if (rptParameter.Equals("StartDate"))
            {
                if (txtStartDate.Text != "")
                    val = txtStartDate.Text;
                else
                {
                    val = "01/Jan/" + DateTime.Now.Year;
                    txtStartDate.Text = val;
                }
            }
            else if (rptParameter.Equals("EndDate"))
            {
                if (txtEndDate.Text != "")
                    val = txtEndDate.Text;
            }
            else if (rptParameter.Equals("JobNo"))
            {
                if (txtJobNo.Text != "")
                {
                    val = txtJobNo.Text;
                }                 
            }
            else if (rptParameter.Equals("jobTypeID"))
            {
                if (ddlJobType.SelectedItem != null)
                {
                    if (ddlJobType.SelectedValue != "")
                        val = ddlJobType.SelectedValue;
                    else
                        val = null;
                }
            }
            else if (rptParameter.Equals("jobCatID"))
            {
                if (ddlJobCat.SelectedItem != null)
                {
                    if (ddlJobCat.SelectedValue != "")
                        val = ddlJobCat.SelectedValue;
                }
            }
            else if (rptParameter.Equals("jobStatusID"))
            {
                if (ddlJobStatus.SelectedItem != null)
                {
                    if (ddlJobStatus.SelectedValue != "")
                        val = ddlJobStatus.SelectedValue;
                }
            }
            else if (rptParameter.Equals("assignedTo"))
            {
                if (assignedStaff.Text != "")
                {
                    val = assignedStaff.Text;                     
                }
            }            

            rptViewer.ServerReport.SetParameters(new ReportParameter(rptParameter, val, false));
        }
        return rptName;
    }
    private IList<string> GetReportParametersBySelectionDefault(string mainID, string subID, int filterID)
    {
        IList<string> strColl = null;
        try
        {
            using (SqlConnection cn = new SqlConnection(connValue))
            {
                string strQuery = "SELECT  r.reportID, r.moduleName, r.reportName, r.rptMainMenuID, r.rptSubMenuID, r.rptFilterID, r.parameters, r.createUser, r.createDate, r.updateUser, r.updateDate, " +
                       "  m.sectionID FROM Reports AS r INNER JOIN ReportsMainMenu AS m ON r.rptMainMenuID = m.rptMainMenuID INNER JOIN ReportsSubMenu AS s ON r.rptSubMenuID = s.rptSubMenuID INNER JOIN " +
                        " ReportsFilter AS f ON r.rptFilterID = f.rptfilterID WHERE (r.rptMainMenuID = @rptMainMenuID) AND (r.rptSubMenuID = @rptSubMenuID)";

                cn.Open();

                using (SqlCommand sqlCmd = new SqlCommand(strQuery, cn))
                {
                    sqlCmd.Parameters.AddWithValue("@rptMainMenuID", mainID);
                    sqlCmd.Parameters.AddWithValue("@rptSubMenuID", subID);
                    sqlCmd.Parameters.AddWithValue("@rptFilterID", filterID);

                    using (SqlDataReader sqlDtReader = sqlCmd.ExecuteReader())
                    {
                        if (sqlDtReader.Read())
                        {
                            strColl = new List<string>();
                            strColl.Add(sqlDtReader["moduleName"].ToString().Trim());
                            strColl.Add(sqlDtReader["reportName"].ToString().Trim());
                            strColl.Add(sqlDtReader["parameters"].ToString().Trim());
                        }
                    }
                }
            }
        }
        catch (Exception ex)
        {

        }
        return strColl;
    }
    protected void ddlReportsMainMenu_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlReportsMainMenu.SelectedIndex != 0)
        {
            ddlReportsSubMenu.DataSource = null;
            string sqlQuery = "SELECT  rptSubMenuID, rptSubMenuDescription, sectionID, rptMainMenuID, isActive FROM ReportsSubMenu WHERE (rptMainMenuID = " + ddlReportsMainMenu.SelectedValue + ") ";
            PopulateDropDownBox(ddlReportsSubMenu, sqlQuery, "rptSubMenuID", "rptSubMenuDescription");
        }
        else if (ddlReportsMainMenu.SelectedValue == "5")
        {
            ddlReportsSubMenu.DataSource = null;
            string sqlQuery = "select rptSubMenuID,rptSubMenuDescription from ReportsSubMenu where rptSubMenuID >= 5 and sectionID =" + Convert.ToInt16(Session["SectionID"]) + "";
            PopulateDropDownBox(ddlReportsSubMenu, sqlQuery, "rptSubMenuID", "rptSubMenuDescription");
        }
        else if (ddlReportsMainMenu.SelectedValue == "6")
        {
            ddlReportsSubMenu.DataSource = null;
            string sqlQuery = "select rptSubMenuID,rptSubMenuDescription from ReportsSubMenu where rptSubMenuID < 5 and sectionID =" + Convert.ToInt16(Session["SectionID"]) + "";
            PopulateDropDownBox(ddlReportsSubMenu, sqlQuery, "rptSubMenuID", "rptSubMenuDescription");
        }
        //else if (ddlReportsMainMenu.SelectedValue == "6")
        //{
        //    ddlReportsSubMenu.DataSource = null;
        //    string sqlQuery = "select rptSubMenuID,rptSubMenuDescription from ReportsSubMenu where rptSubMenuID < 5 and sectionID =" + Convert.ToInt16(Session["SectionID"]) + "";
        //    PopulateDropDownBox(ddlReportsSubMenu, sqlQuery, "rptSubMenuID", "rptSubMenuDescription");
        //}
        else
        {
            ddlReportsSubMenu.DataSource = null;
            string sqlQuery = "select rptSubMenuID,rptSubMenuDescription from ReportsSubMenu where  sectionID = " + Convert.ToInt16(Session["SectionID"]) + "";
            PopulateDropDownBox(ddlReportsSubMenu, sqlQuery, "rptSubMenuID", "rptSubMenuDescription");
        }
    }

    private string getServerURL()
    {
        string strURL = string.Empty;
        try
        {
            string strQuery = "SELECT reportURL From ReportServer";
            using (SqlConnection conn = new SqlConnection(connValue))
            {
                conn.Open();

                SqlCommand sqlCmd = new SqlCommand(strQuery, conn);
                sqlCmd.CommandText = strQuery;
                sqlCmd.CommandType = CommandType.Text;
                sqlCmd.Connection = conn;
                using (SqlDataReader sqlDtReader = sqlCmd.ExecuteReader())
                {
                    while (sqlDtReader.Read())
                    {
                        strURL = sqlDtReader["reportURL"].ToString();
                    }
                }
            }
        }
        catch (Exception ex)
        {

        }

        return strURL;
    }

    private void PopulateDropDownBox(DropDownList ddlBox, string sqlQuery, string valueMember, string displayName)
    {
        ddlBox.DataBound += new EventHandler(this.ddlBox_DataBound);
        ddlBox.DataSource = new JobOrderData().FillDropdown(sqlQuery);
        ddlBox.DataTextField = displayName;
        ddlBox.DataValueField = valueMember;
        ddlBox.SelectedIndex = -1;
        ddlBox.DataBind();
    }
    protected void ddlBox_DataBound(object sender, EventArgs e)
    {
        DropDownList ddl = (DropDownList)sender;
        ListItem emptyItem = new ListItem("", "");
        ddl.Items.Insert(0, emptyItem);
    }
    public class CustomReportCredentials : IReportServerCredentials
    {
        private string _UserName;
        private string _PassWord;
        private string _DomainName;

        public CustomReportCredentials(string UserName, string PassWord, string DomainName)
        {
            _UserName = UserName;
            _PassWord = PassWord;
            _DomainName = DomainName;
        }

        public System.Security.Principal.WindowsIdentity ImpersonationUser
        {
            get { return null; }
        }

        public ICredentials NetworkCredentials
        {
            get { return new NetworkCredential(_UserName, _PassWord, _DomainName); }
        }

        public bool GetFormsCredentials(out Cookie authCookie, out string user,
         out string password, out string authority)
        {
            authCookie = null;
            user = password = authority = null;
            return false;
        }
    }

    //Created by Varun on 28-Dec-2020
    private void ClearTextInControls()
    {
        txtJobNo.Text = "";
        ddlJobType.SelectedIndex = 0;
        ddlJobStatus.SelectedIndex = 0;
        txtStartDate.Text = "";
        txtEndDate.Text = "";
    }

    protected void ddlReportsSubMenu_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            ServerReport serverReport = rptViewer.ServerReport;
            IReportServerCredentials irsc = new CustomReportCredentials(ConfigurationManager.AppSettings["userNameForReport"].ToString(), ConfigurationManager.AppSettings["passWordForReport"].ToString(),
            ConfigurationManager.AppSettings["domainName"].ToString());
            serverReport.ReportServerCredentials = irsc;
            rptViewer.ProcessingMode = ProcessingMode.Remote;
            serverReport.ReportServerUrl = new Uri(strRptURL);
            IList<string> strReportColl = null;
            if (ddlReportsMainMenu.SelectedValue != "" && (ddlReportsSubMenu.SelectedValue == "" || ddlReportsSubMenu.SelectedValue == "0" || ddlReportsSubMenu.SelectedValue == "21")) //21=="EIS Jobs Report"
            {
                tblJobNoInfo.Visible = true;
                tblJobTypeStatus.Visible = true;
                strReportColl = GetReportParametersBySelectionDefault(ddlReportsMainMenu.SelectedValue, "21", 0);
            }
            else
            {
                tblJobNoInfo.Visible = false;
                tblJobTypeStatus.Visible = false;
                strReportColl = GetReportParametersBySelectionDefault(ddlReportsMainMenu.SelectedValue, ddlReportsSubMenu.SelectedValue, 0); //22=="EIS KPI Report"
            }
            ClearTextInControls();
            serverReport.ReportPath = "/" + strReportColl[0] + "/" + strReportColl[1];

            CreateParametersForReport(strReportColl);

            this.rptViewer.ServerReport.Refresh();
        }
        catch (Exception)
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "Popup", "<script>alert('Error occurred while displaying the report.')</script>", false);            
        }
        
    }
    protected void txtEndDate_TextChanged(object sender, EventArgs e)
    {
        if (ddlReportsMainMenu.SelectedValue != "" && ddlReportsSubMenu.SelectedValue != "")
        {
            generateDefaultReport(ddlReportsMainMenu.SelectedValue, ddlReportsSubMenu.SelectedValue);
        }
        else
        {
            generateDefaultReport("11", "21");
        }
    }
    protected void txtStartDate_TextChanged(object sender, EventArgs e)
    {
        if (ddlReportsMainMenu.SelectedValue != "" && ddlReportsSubMenu.SelectedValue != "")
        {
            generateDefaultReport(ddlReportsMainMenu.SelectedValue, ddlReportsSubMenu.SelectedValue);
        }
        else
        {
            generateDefaultReport("11", "21");
        }
    }
    #endregion
    
    protected void txtJobNo_TextChanged(object sender, EventArgs e)
    {
        generateDefaultReport("11", "21");
    }

    protected void txtAssignedStaff_TextChanged(object sender, EventArgs e)
    {
        generateDefaultReport("11", "21");
    }

    protected void ddlJobType_SelectedIndexChanged(object sender, EventArgs e)
    {
        
        //sqlJobCat = "SELECT CategoryID, jobTypeName FROM JobType WHERE (sectionID = " + Session["SectionID"] + ") and CategoryID=" + ddlJobCat.SelectedValue + " and CategoryID not in(76,77,78,79) AND (jobTypeID <> CategoryID)";
        //PopulateDropDownBox(ddlJobCat, sqlJobCat, "CategoryID", "jobTypeName");
        
        generateDefaultReport("11", "21");
    }
    protected void ddlJobCat_SelectedIndexChanged(object sender, EventArgs e)
    {
        sqlJobType = "SELECT jobTypeID, jobTypeName FROM JobType WHERE (sectionID = " + Session["SectionID"] + ") AND (jobTypeID <> CategoryID) and CategoryID=" + ddlJobCat.SelectedValue;
        PopulateDropDownBox(ddlJobType, sqlJobType, "jobTypeID", "jobTypeName");
        generateDefaultReport("11", "21");
    }
    protected void ddlJobStatus_SelectedIndexChanged(object sender, EventArgs e)
    {
        generateDefaultReport("11", "21");
    }
}