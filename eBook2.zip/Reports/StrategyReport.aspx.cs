﻿using Datalayer;
using Microsoft.Reporting.WebForms;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Reports_StrategyReport : System.Web.UI.Page
{
    string connValue = ConfigurationManager.ConnectionStrings["EBSDEBookConn"].ToString();
    static string strRptURL = string.Empty;
    string strRptFilter = string.Empty;
    IList<string> userRightsColl = new List<string>();
    IList<string> rptColl = new List<string>();
    string rptName = string.Empty;

    string sqlQueryYear = null;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["userProfileID"] != null)
        {
            //if ((Session["SectionID"].ToString().Equals("1")) || (Session["userProfileID"].ToString().Equals("1")))
            //{
            if (!Page.IsPostBack)
            {
                userRightsColl = (IList<string>)Session["UserRightsColl"];
                strRptURL = getServerURL();
                ddlReportsSubMenu.Enabled = false;
                generateDefaultReport("12", "65", "0");

                string sqlQueryMain = string.Empty;


                sqlQueryMain = "select rptMainMenuID,rptMainMenuDescription from ReportsMainMenu where rptMainMenuID not in(0,5) and sectionID=7 order by rptMainMenuID"; //sectionID=7(Strategy) +Convert.ToInt16(Session["SectionID"]) + " order by rptMainMenuID";   // Normal user hide adoc reports                     
                //sqlQueryYear = "SELECT YEAR(jobReceivedDate) AS Year FROM  Job where sectionID =13 GROUP BY  YEAR(jobReceivedDate) ORDER BY Year DESC"; // " + Convert.ToInt16(Session["SectionID"]) + "

                sqlQueryYear = "SELECT periodYear AS Year FROM  StrategyKPIResult GROUP BY  periodYear ORDER BY periodYear DESC";

                PopulateDropDownBox(ddlReportsMainMenu, sqlQueryMain, "rptMainMenuID", "rptMainMenuDescription");
                PopulateDropDownBox(ddlYear, sqlQueryYear, "Year", "Year");
                ddlYear.Enabled = true;
                ddlYear.SelectedIndex = 0;
                tblStartEndDate.Visible = false;

            }
            //}
            //else
            //{
            //    ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Restricted Access.')</script>", false);
            //}
        }
        else
        {
            Response.Redirect("~/LoginPage.aspx", false);
        }
    }
    protected void ddlReportsSubMenu_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlReportsSubMenu.SelectedValue != "")
        {
            if (Session["userProfileID"] != null)
            {
                txtStartDate.Visible = true;
                lblStrDate.Visible = true;
                if ((ddlReportsMainMenu.SelectedIndex == 1) && ddlReportsSubMenu.SelectedValue.Equals("65"))       //Business Dev Reports - PCC Strategy KPI Report
                {
                    tblStartEndDate.Visible = true;
                }
                else if ((ddlReportsMainMenu.SelectedIndex == 1) && ddlReportsSubMenu.SelectedValue.Equals("62"))       //Business Dev Reports - PCC Strategy KPI Report
                {
                    tblStartEndDate.Visible = true;
                }
                else if ((ddlReportsMainMenu.SelectedIndex == 5) && ddlReportsSubMenu.SelectedValue.Equals("60"))       //Adoc and Cost Estimate - PCC Strategy KPI Report
                {
                    tblStartEndDate.Visible = true;
                }
                else if ((ddlReportsMainMenu.SelectedIndex == 5) && ddlReportsSubMenu.SelectedValue.Equals("8"))       //Adoc and Cost Estimate
                {
                    //tblStartEndDate.Visible = true;
                    tblStartEndDate.Visible = false;
                }
                else if ((ddlReportsMainMenu.SelectedIndex == 5) && (Convert.ToInt16(ddlReportsSubMenu.SelectedValue) >= 40 && Convert.ToInt16(ddlReportsSubMenu.SelectedValue) <= 54) || Convert.ToInt16(ddlReportsSubMenu.SelectedValue) == 64)       //EBD Jobs (Up To-Date)
                {
                    if (ddlReportsSubMenu.SelectedItem.Text.Equals("Incoming Jobs (Monthly)"))
                    {
                        tblStartEndDate.Visible = false;
                    }
                    else
                    {
                        tblStartEndDate.Visible = true;
                        if (Convert.ToInt16(ddlReportsSubMenu.SelectedValue) == 64)
                        {
                            txtStartDate.Text = "01/Jan/" + DateTime.Now.Year;
                        }
                    }

                    //txtStartDate.Visible = false;
                    //lblStrDate.Visible = false;
                }
                else if (ddlReportsMainMenu.SelectedIndex <= 5 && Convert.ToInt16(ddlReportsSubMenu.SelectedValue) <= 5 || (Convert.ToInt16(ddlReportsSubMenu.SelectedValue) >= 25 && Convert.ToInt16(ddlReportsSubMenu.SelectedValue) <= 31)) //ddlReportsSubMenu.SelectedValue==2 Reports By Average Work Days
                {
                    tblStartEndDate.Visible = false;
                }
                else if (Convert.ToInt16(ddlReportsSubMenu.SelectedValue) == 6 || Convert.ToInt16(ddlReportsSubMenu.SelectedValue) == 7)
                {
                    ddlYear.Visible = false;
                    tblStartEndDate.Visible = false;
                }
                else
                {
                    ddlYear.Visible = false;
                    tblStartEndDate.Visible = false;
                }


                //else
                //{
                //    ddlYear.Visible = true;
                //}

                CheckFilter();

                //CheckDDLSelections();
                //generateDefaultReport(ddlReportsMainMenu.SelectedValue, ddlReportsSubMenu.SelectedValue, "0");
            }
            else
            {
                Response.Redirect("~/LoginPage.aspx", false);
            }
        }
        else
        {
            ResetControls(true);
        }


    }
    protected void ddlYear_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlReportsSubMenu.SelectedIndex == 0)  // D,E,J = 11,12,13  
        {
            return;
        }

        if (ddlReportsMainMenu.SelectedValue.Equals("12"))
        {
            CheckFilter();
        }
        else
        {
            generateReport(9, false);
        }

    }
    protected void txtEndDate_TextChanged(object sender, EventArgs e)
    {
        if (ddlReportsSubMenu.SelectedValue != "")
        {
            if (!(Convert.ToInt16(ddlReportsSubMenu.SelectedValue) >= 40 && Convert.ToInt16(ddlReportsSubMenu.SelectedValue) <= 54) && Convert.ToInt16(ddlReportsSubMenu.SelectedValue) != 64)
            {
                generateReport(13, false);
            }
            else if (!(Convert.ToInt16(ddlReportsSubMenu.SelectedValue) >= 40 && Convert.ToInt16(ddlReportsSubMenu.SelectedValue) <= 54) && Convert.ToInt16(ddlReportsSubMenu.SelectedValue) == 64)
            {
                generateReport(0, false);
            }
            else
            {
                generateReport(9, true);
            }
        }
        else
        {
            generateReport(9, true);
        }
    }
    private void CheckFilter()
    {
        if (ddlReportsSubMenu.SelectedValue != "" && ddlReportsSubMenu.SelectedValue != "0")
        {
            if (Convert.ToInt16(ddlReportsSubMenu.SelectedValue) == 5)  // D,E,J = 11,12,13  == 5 Cost Estimate
                generateReport(10, false);
            else if (Convert.ToInt16(ddlReportsSubMenu.SelectedValue) == 6)  // D,E,J = 11,12,13  Document KPIs
                generateReport(11, false);
            else if (Convert.ToInt16(ddlReportsSubMenu.SelectedValue) == 7)  // D,E,J = 11,12,13  Employee KPIs
                generateReport(12, false);
            else if (Convert.ToInt16(ddlReportsSubMenu.SelectedValue) == 8)  // D,E,J = 11,12,13  JobOrder KPIs 
                generateReport(13, false);
            else if (Convert.ToInt16(ddlReportsSubMenu.SelectedValue) == 99 || Convert.ToInt16(ddlReportsSubMenu.SelectedValue) == 62
                || Convert.ToInt16(ddlReportsSubMenu.SelectedValue) == 60 || Convert.ToInt16(ddlReportsSubMenu.SelectedValue) == 64 || Convert.ToInt16(ddlReportsSubMenu.SelectedValue) == 65)   // D,E,J = 11,12,13 Test Report  62, 61 -> PCC Strategy KPI Report
                generateReport(0, false);
            else
                generateReport(9, false);
        }
        else
            generateReport(9, false);
    }
    private IList<string> GetReportParametersBySelection(string mainID, string subID, int filterID)
    {
        IList<string> strColl = null;
        try
        {
            using (SqlConnection cn = new SqlConnection(connValue))
            {
                string strQuery = "SELECT Reports.moduleName, Reports.reportName, Reports.parameters FROM ReportsSubMenu INNER JOIN ReportsMainMenu INNER JOIN ReportsFilter INNER JOIN Reports " +
                "ON ReportsFilter.rptfilterID = Reports.rptFilterID ON ReportsMainMenu.rptMainMenuID = Reports.rptMainMenuID ON ReportsSubMenu.rptSubMenuID = Reports.rptSubMenuID WHERE " +
                "(Reports.rptMainMenuID = @rptMainMenuID) AND (ReportsSubMenu.rptSubMenuID = @rptSubMenuID) AND (Reports.rptFilterID = @rptFilterID)";

                cn.Open();

                using (SqlCommand sqlCmd = new SqlCommand(strQuery, cn))
                {

                    sqlCmd.Parameters.AddWithValue("@rptMainMenuID", mainID);
                    sqlCmd.Parameters.AddWithValue("@rptSubMenuID", subID);
                    sqlCmd.Parameters.AddWithValue("@rptFilterID", filterID);

                    using (SqlDataReader sqlDtReader = sqlCmd.ExecuteReader())
                    {
                        if (sqlDtReader.Read())
                        {
                            strColl = new List<string>();
                            strColl.Add(sqlDtReader["moduleName"].ToString());
                            strColl.Add(sqlDtReader["reportName"].ToString());
                            strColl.Add(sqlDtReader["parameters"].ToString());
                        }
                    }
                }

            }
        }
        catch (Exception ex)
        {

        }
        return strColl;
    }
    private string SetParametersForTab1Report(IList<string> rptColl)
    {
        string rptName = string.Empty;
        rptName = "/" + rptColl[0] + "/" + rptColl[1];

        string[] parameterColl = rptColl[2].Split(',');

        if (txtEndDate.Text != "")
        {
            if (Convert.ToDateTime(txtEndDate.Text).CompareTo(Convert.ToDateTime(getMonthLastDate())) == 0)
            {
                txtEndDate.Text = getMonthLastDate();
            }
        }

        foreach (var rptParameter in parameterColl)          // jobStatusID,contactID,jobUnread 
        {
            string val = null;
            if (rptParameter.Equals("Year"))
            {
                if (ddlYear.SelectedValue == "0" || ddlYear.SelectedValue == "")
                {
                    val = DateTime.Now.Year.ToString();
                }
                else if (ddlYear.SelectedValue != "0" && ddlYear.SelectedValue != "")
                {
                    val = ddlYear.SelectedValue;
                }
            }
            else if (rptParameter.Equals("StartDate") & txtStartDate.Text != "")
                val = txtStartDate.Text;
            else if (rptParameter.Equals("EndDate") & txtEndDate.Text != "")
                val = txtEndDate.Text;

            rptViewer.ServerReport.SetParameters(new ReportParameter(rptParameter, val, false));
        }
        return rptName;
    }
    private void generateReport(int filterID, bool isDateSelected)
    {
        try
        {
            ServerReport serverReport = rptViewer.ServerReport;

            IReportServerCredentials irsc = new CustomReportCredentials(ConfigurationManager.AppSettings["userNameForReport"].ToString(), ConfigurationManager.AppSettings["passWordForReport"].ToString(),

            ConfigurationManager.AppSettings["domainName"].ToString());
            serverReport.ReportServerCredentials = irsc;
            rptViewer.ProcessingMode = ProcessingMode.Remote;
            if (strRptURL == "")
            {
                strRptURL = getServerURL();
            }
            serverReport.ReportServerUrl = new Uri(strRptURL);

            IList<string> strReportColl = GetReportParametersBySelection(ddlReportsMainMenu.SelectedValue, ddlReportsSubMenu.SelectedValue, filterID);

            if (strReportColl == null)
                return;

            serverReport.ReportPath = "/" + strReportColl[0] + "/" + strReportColl[1];

            if (ddlReportsSubMenu.SelectedValue != "")
            {
                //if (Convert.ToInt16(ddlReportsSubMenu.SelectedValue) == 8)
                //    SetParametersForJobOrderKPIReport(strReportColl);
                if (Convert.ToInt16(ddlReportsSubMenu.SelectedValue) == 65) //60==35_PCCKPI
                {
                    SetParametersForTab1Report(strReportColl);
                }
                else if ((Convert.ToInt16(ddlReportsSubMenu.SelectedValue) >= 40 && Convert.ToInt16(ddlReportsSubMenu.SelectedValue) <= 54) || Convert.ToInt16(ddlReportsSubMenu.SelectedValue) == 60) //60==35_PCCKPI
                {
                    if (!isDateSelected && (Convert.ToInt16(ddlReportsSubMenu.SelectedValue) == 40 || Convert.ToInt16(ddlReportsSubMenu.SelectedValue) == 41))
                    {
                        txtEndDate.Text = getMonthLastDate();
                    }
                    else if (Convert.ToInt16(ddlReportsSubMenu.SelectedValue) == 42 || Convert.ToInt16(ddlReportsSubMenu.SelectedValue) == 60) //60==35_PCCKPI
                    {
                        if (Convert.ToInt16(ddlReportsSubMenu.SelectedValue) == 60)
                        {
                            txtStartDate.Text = "01/Jan/" + DateTime.Now.Year; // ToString("dd/MMM/yyyy");
                        }
                        else
                        {
                            if (!isDateSelected)
                            {
                                txtEndDate.Text = Convert.ToDateTime(DateTime.Now.ToString()).ToString("dd/MMM/yyyy");
                            }
                            if (txtStartDate.Text == "")
                            {
                                txtStartDate.Text = Convert.ToDateTime(DateTime.Now.AddYears(-1)).ToString("dd/MMM/yyyy");
                            }
                        }
                    }
                    else if (!isDateSelected)
                    {
                        txtEndDate.Text = "";
                    }
                    SetParametersForTab1Report(strReportColl);
                }
                //else if (!(Convert.ToInt16(ddlReportsSubMenu.SelectedValue) >= 6 && Convert.ToInt16(ddlReportsSubMenu.SelectedValue) <= 8))
                //{
                //    if (Convert.ToInt16(ddlReportsSubMenu.SelectedValue) == 64)
                //    {
                //        if (txtStartDate.Text.ToString() == "")
                //        {
                //            txtStartDate.Text = "01/Jan/" + DateTime.Now.Year; // ToString("dd/MMM/yyyy");
                //        }
                //        if (txtEndDate.Text.ToString() == "")
                //        {
                //            txtEndDate.Text = Convert.ToDateTime(DateTime.Now.ToString()).ToString("dd/MMM/yyyy");
                //        }
                //    }
                //    SetParametersForTab2Report(strReportColl);
                //}


                //if (!(Convert.ToInt16(ddlReportsSubMenu.SelectedValue) >= 6 && Convert.ToInt16(ddlReportsSubMenu.SelectedValue) <= 8))
                //    SetParametersForTab2Report(strReportColl);
                //else if (Convert.ToInt16(ddlReportsSubMenu.SelectedValue) == 8)
                //    SetParametersForTab1Report(strReportColl);
                //else
                //    CreateParametersForKPI(strReportColl);
            }

            this.rptViewer.ServerReport.Refresh();
        }
        catch (Exception ex)
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('" + ex.Message + "')</script>", false);
        }
    }

    private string getMonthLastDate()
    {
        string monthEndDate = string.Empty;

        string sqlQuery = "SELECT CASE WHEN (YEAR(DATEADD(D,1,@endmonth)) > YEAR(@endmonth)) THEN @endmonth WHEN MONTH(DATEADD(D,1,@endmonth)) > MONTH(@endmonth) THEN " +
                       " @endmonth ELSE DATEADD(D,-1,DATEADD(M, DATEDIFF(M, 0, @endmonth), 0)) END endLastMonth";

        try
        {
            using (SqlConnection sqlCn = new SqlConnection(connValue))
            {
                sqlCn.Open();
                using (SqlCommand sqlCmd = new SqlCommand(sqlQuery, sqlCn))
                {
                    sqlCmd.Parameters.AddWithValue("@endmonth", Convert.ToDateTime(System.DateTime.Now.ToString()).ToString("dd/MMM/yyyy"));

                    using (SqlDataReader dr = sqlCmd.ExecuteReader())
                    {
                        while (dr.Read())
                        {
                            monthEndDate = Convert.ToDateTime(dr["endLastMonth"].ToString()).ToString("dd/MMM/yyyy");
                        }
                    }
                }
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
        return monthEndDate;
    }
    protected void txtStartDate_TextChanged(object sender, EventArgs e)
    {
        if (ddlReportsSubMenu.SelectedValue.Equals("42"))
        {
            if (txtStartDate.Text.Trim() != "")
            {
                txtEndDate.Text = "";
                generateReport(9, true);
            }
            else
            {
                generateReport(9, false);
            }
        }
        else
        {
            if (ddlReportsSubMenu.SelectedValue != "")
            {
                if (Convert.ToInt16(ddlReportsSubMenu.SelectedValue) == 60 || Convert.ToInt16(ddlReportsSubMenu.SelectedValue) == 62) // Business Dev Reports - PCC Strategy KPI Report  , Adoc and Cost Estimate - PCC Strategy KPI Report
                {
                    generateReport(0, false);
                }
                else if (!(Convert.ToInt16(ddlReportsSubMenu.SelectedValue) >= 40 && Convert.ToInt16(ddlReportsSubMenu.SelectedValue) <= 54) && Convert.ToInt16(ddlReportsSubMenu.SelectedValue) != 64)
                {
                    generateReport(13, false); // Affair,dept,budgetcode 
                }
                else if (!(Convert.ToInt16(ddlReportsSubMenu.SelectedValue) >= 40 && Convert.ToInt16(ddlReportsSubMenu.SelectedValue) <= 54) && Convert.ToInt16(ddlReportsSubMenu.SelectedValue) == 64)
                {
                    generateReport(0, false); // Affair,dept,budgetcode 
                }
                else
                {
                    generateReport(9, true);
                }
            }
            else
            {
                generateReport(9, true);
            }
        }
    }

    protected void ddlReportsMainMenu_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (Session["userProfileID"] != null)
        {
            ddlReportsSubMenu.Enabled = true;

            if (Session["userProfileID"].ToString().Equals("1"))
            {
                if (ddlReportsMainMenu.SelectedValue != "")
                {
                    ddlReportsSubMenu.DataSource = null;
                    string sqlQuery = "select rptSubMenuID,rptSubMenuDescription from ReportsSubMenu where rptMainMenuID=" + ddlReportsMainMenu.SelectedValue + " AND (isActive = 1)";
                    PopulateDropDownBox(ddlReportsSubMenu, sqlQuery, "rptSubMenuID", "rptSubMenuDescription");
                    ResetControls(false);
                }
                else if (ddlReportsMainMenu.SelectedValue == "")
                {
                    ddlReportsSubMenu.DataSource = null;
                    ResetControls(true);
                }
            }
            else
            {
                if (ddlReportsMainMenu.SelectedValue.Equals("5")) // Ad HOC
                {
                    ddlReportsSubMenu.DataSource = null;
                    string sqlQuery = "SELECT rptSubMenuID, rptSubMenuDescription FROM ReportsSubMenu WHERE (rptMainMenuID IN (5)) AND (sectionID = 1) AND (isActive = 1) ";
                    PopulateDropDownBox(ddlReportsSubMenu, sqlQuery, "rptSubMenuID", "rptSubMenuDescription");
                    ResetControls(false);
                }
                else if (ddlReportsMainMenu.SelectedValue != "")
                {
                    ddlReportsSubMenu.DataSource = null;
                    string sqlQuery = "select rptSubMenuID,rptSubMenuDescription from ReportsSubMenu where (isActive = 1) and rptMainMenuID=" + ddlReportsMainMenu.SelectedValue;  // sectionID = " + Convert.ToInt16(Session["SectionID"]) + " AND
                    PopulateDropDownBox(ddlReportsSubMenu, sqlQuery, "rptSubMenuID", "rptSubMenuDescription");
                    ResetControls(false);
                }
                else if (ddlReportsMainMenu.SelectedValue == "")
                {
                    ddlReportsSubMenu.DataSource = null;
                    ResetControls(true);
                }
            }
        }
        else
        {
            Response.Redirect("~/LoginPage.aspx", false);
        }
    }
    private void ResetControls(bool isItemBlank)
    {

        if (isItemBlank)
        {
            //ddlReportsMainMenu.SelectedIndex = -1;
            //ddlReportsSubMenu.SelectedIndex = -1;
            //ddlReportsSubMenu.DataSource = null;
            //ddlReportsSubMenu.Enabled = false;
            //ddlYear.DataSource = null;
            //ddlYear.SelectedIndex = -1;
            //ddlYear.Enabled = false;
            //generateDefaultReport("0", "0", "0");
        }
        else
        {
            ddlReportsSubMenu.SelectedIndex = -1;
            ddlReportsSubMenu.Enabled = true;
            ddlYear.Enabled = true;
            string sqlQueryYear = "SELECT COUNT(jobID) AS jobCnt, YEAR(jobReceivedDate) AS Year FROM Job GROUP BY YEAR(jobReceivedDate) ORDER BY Year DESC";
            PopulateDropDownBox(ddlYear, sqlQueryYear, "Year", "Year");
        }

        //if (ddlYear.Visible)
        //{
        //    ddlYear.SelectedIndex = -1;
        //}
        //else
        //{
        //    ddlYear.Visible = true;
        //    ddlYear.SelectedIndex = -1;
        //}
        //tblAffairs.Visible = false;
        //tblKPI.Visible = false;

    }
    private void generateDefaultReport(string mainID, string subID, string filterID)
    {
        try
        {
            ServerReport serverReport = rptViewer.ServerReport;
            IReportServerCredentials irsc = new CustomReportCredentials(ConfigurationManager.AppSettings["userNameForReport"].ToString(), ConfigurationManager.AppSettings["passWordForReport"].ToString(),
            ConfigurationManager.AppSettings["domainName"].ToString());
            serverReport.ReportServerCredentials = irsc;
            rptViewer.ProcessingMode = ProcessingMode.Remote;
            serverReport.ReportServerUrl = new Uri(strRptURL);
            IList<string> strReportColl = GetReport(mainID, subID, filterID);
            if (strReportColl != null)
            {
                serverReport.ReportPath = "/" + strReportColl[0] + "/" + strReportColl[1];
                this.rptViewer.ServerReport.Refresh();
            }
        }
        catch (Exception ex)
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('" + ex.Message + "')</script>", false);
        }
    }
    private IList<string> GetReport(string mainID, string subID, string filterID)
    {
        IList<string> strColl = null;
        try
        {
            using (SqlConnection cn = new SqlConnection(connValue))
            {
                if (!filterID.Equals("0"))
                {

                    string strQuery = "SELECT Reports.moduleName, Reports.reportName, Reports.parameters FROM ReportsSubMenu INNER JOIN " +
                    "ReportsMainMenu INNER JOIN ReportsFilter INNER JOIN Reports ON ReportsFilter.rptfilterID = Reports.rptFilterID ON ReportsMainMenu.rptMainMenuID = Reports.rptMainMenuID ON " +
                    "ReportsSubMenu.rptSubMenuID = Reports.rptSubMenuID WHERE (Reports.rptMainMenuID = @rptMainMenuID) AND (ReportsSubMenu.rptSubMenuID = @rptSubMenuID) AND (Reports.rptFilterID = @rptFilterID)";


                    cn.Open();

                    using (SqlCommand sqlCmd = new SqlCommand(strQuery, cn))
                    {

                        sqlCmd.Parameters.AddWithValue("@rptMainMenuID", mainID);
                        sqlCmd.Parameters.AddWithValue("@rptSubMenuID", subID);
                        sqlCmd.Parameters.AddWithValue("@rptFilterID", filterID);

                        using (SqlDataReader sqlDtReader = sqlCmd.ExecuteReader())
                        {
                            if (sqlDtReader.Read())
                            {
                                strColl = new List<string>();
                                strColl.Add(sqlDtReader["moduleName"].ToString().Trim());
                                strColl.Add(sqlDtReader["reportName"].ToString().Trim());
                                strColl.Add(sqlDtReader["parameters"].ToString().Trim());
                            }
                        }
                    }
                }
                else
                {
                    string strQuery = "SELECT r.* FROM Reports r,ReportsMainMenu m,ReportsSubMenu s WHERE r.rptMainMenuID = m.rptMainMenuID AND r.rptSubMenuID = s.rptSubMenuID AND " +
                    " r.rptMainMenuID = @rptMainMenuID and r.rptSubMenuID = @rptSubMenuID";

                    cn.Open();

                    using (SqlCommand sqlCmd = new SqlCommand(strQuery, cn))
                    {

                        sqlCmd.Parameters.AddWithValue("@rptMainMenuID", mainID);
                        sqlCmd.Parameters.AddWithValue("@rptSubMenuID", subID);
                        //sqlCmd.Parameters.AddWithValue("@rptFilterID", filterID);

                        using (SqlDataReader sqlDtReader = sqlCmd.ExecuteReader())
                        {
                            if (sqlDtReader.Read())
                            {
                                strColl = new List<string>();
                                strColl.Add(sqlDtReader["moduleName"].ToString().Trim());
                                strColl.Add(sqlDtReader["reportName"].ToString().Trim());
                                strColl.Add(sqlDtReader["parameters"].ToString().Trim());
                            }
                        }
                    }
                }

            }
        }
        catch (Exception ex)
        {

        }
        return strColl;
    }
    private string getServerURL()
    {
        string strURL = string.Empty;
        try
        {
            string strQuery = "SELECT reportURL From ReportServer";
            using (SqlConnection conn = new SqlConnection(connValue))
            {
                conn.Open();

                SqlCommand sqlCmd = new SqlCommand(strQuery, conn);
                sqlCmd.CommandText = strQuery;
                sqlCmd.CommandType = CommandType.Text;
                sqlCmd.Connection = conn;
                using (SqlDataReader sqlDtReader = sqlCmd.ExecuteReader())
                {
                    while (sqlDtReader.Read())
                    {
                        strURL = sqlDtReader["reportURL"].ToString();
                    }
                }
            }
        }
        catch (Exception ex)
        {

        }

        return strURL;
    }
    private void PopulateDropDownBox(DropDownList ddlBox, string sqlQuery, string valueMember, string displayName)
    {
        ddlBox.DataBound += new EventHandler(this.ddlBox_DataBound);

        DAL dal = new DAL(ConfigurationManager.ConnectionStrings["EBSDEBookConn"].ToString());

        //if (dal.ConnectDB(this.Page) == 'E')
        //{
        //    ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "alert('Error occurred while establishing connection to the database')");
        //    return;
        //}
        ddlBox.DataSource = new JobOrderData().FillDropdown(sqlQuery);
        ddlBox.DataTextField = displayName;
        ddlBox.DataValueField = valueMember;
        ddlBox.SelectedIndex = -1;
        ddlBox.DataBind();
    }
    protected void ddlBox_DataBound(object sender, EventArgs e)
    {
        DropDownList ddl = (DropDownList)sender;
        ListItem emptyItem = new ListItem("", "");
        ddl.Items.Insert(0, emptyItem);
    }

    public class CustomReportCredentials : IReportServerCredentials
    {
        private string _UserName;
        private string _PassWord;
        private string _DomainName;

        public CustomReportCredentials(string UserName, string PassWord, string DomainName)
        {
            _UserName = UserName;
            _PassWord = PassWord;
            _DomainName = DomainName;
        }

        public System.Security.Principal.WindowsIdentity ImpersonationUser
        {
            get { return null; }
        }

        public ICredentials NetworkCredentials
        {
            get { return new NetworkCredential(_UserName, _PassWord, _DomainName); }
        }

        public bool GetFormsCredentials(out Cookie authCookie, out string user,
         out string password, out string authority)
        {
            authCookie = null;
            user = password = authority = null;
            return false;
        }
    }
}