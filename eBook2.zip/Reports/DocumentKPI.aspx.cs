﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Microsoft.Reporting.WebForms;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
using Datalayer;
using System.Net;
public partial class Reports_DocumentKPI : System.Web.UI.Page
{
    string rptName = string.Empty;

    string connValue = ConfigurationManager.ConnectionStrings["EBSDEBookConn"].ToString();
    UtilityClass uCls = null;
    DAL dal = null;
    static string strRptURL = string.Empty;
    string strRptFilter = string.Empty;
    IList<string> rptColl = new List<string>();


    protected void Page_Load(object sender, EventArgs e)
    {
        rptName = Request.QueryString["rptName"].ToString();

        if (!IsPostBack)
        {
            if (rptName.Equals("6"))
            {
                string sqlQueryYear = "SELECT docStatusID,DocStatusName from DocumentStatus";
                PopulateDropDownBox(ddldocStatus, sqlQueryYear, "docStatusID", "DocStatusName");
            }
            else if (rptName.Equals("7"))
            {
                string sqlQueryYear = "SELECT jobStatusID,jobStatusName from JobStatus where jobStatusID < 8";
                PopulateDropDownBox(ddldocStatus, sqlQueryYear, "jobStatusID", "jobStatusName");
            }
            else if (rptName.Equals("8"))
            {
                string sqlQueryYear = "SELECT jobStatusID,jobStatusName from JobStatus where jobStatusID < 8";
                PopulateDropDownBox(ddldocStatus, sqlQueryYear, "docStatusID", "DocStatusName");
            }           

            string sqlQueryEmp = "SELECT contactID,(firstName + ' ' + lastName) as userName from contact order by firstName";
            PopulateDropDownBox(ddlEmployee, sqlQueryEmp, "contactID", "userName");

            getReport();
            ReportParameter jobOrderYear = new ReportParameter();
            jobOrderYear.Name = "Year";
            jobOrderYear.Values.Add("2017");

            rptViewer.ServerReport.SetParameters(new ReportParameter[] { jobOrderYear });
            this.rptViewer.ServerReport.Refresh();
        }
    }
    private void getReport()
    {
        strRptURL = getServerURL();
        ServerReport serverReport = rptViewer.ServerReport;
        IReportServerCredentials irsc = new CustomReportCredentials(ConfigurationManager.AppSettings["userNameForReport"].ToString(), ConfigurationManager.AppSettings["passWordForReport"].ToString(),
        ConfigurationManager.AppSettings["domainName"].ToString());
        serverReport.ReportServerCredentials = irsc;
        rptViewer.ProcessingMode = ProcessingMode.Remote;
        serverReport.ReportServerUrl = new Uri(strRptURL);

        if (rptName.Equals("5"))
        {            
            string strRptFilter = "CostEstimate";
            rptColl = GetReportParameters(strRptFilter, 5, 5, 0);
            serverReport.ReportPath = "/" + rptColl[0] + "/" + rptColl[1];
            lblRptName.Text = "Cost Estimate Report";
        }
        else if (rptName.Equals("6"))
        {           
            string strRptFilter = "DocumentKPI";
            rptColl = GetReportParameters(strRptFilter, 5, 6, 0);
            serverReport.ReportPath = "/" + rptColl[0] + "/" + rptColl[1];
            lblRptName.Text = "Document KPI Report";
        }
        else if (rptName.Equals("7"))
        {           
            string strRptFilter = "EmployeeKPI";
            rptColl = GetReportParameters(strRptFilter, 5, 7, 0);
            serverReport.ReportPath = "/" + rptColl[0] + "/" + rptColl[1];

            lblRptName.Text = "Employee KPI Report";
        }
        else if (rptName.Equals("8"))
        {
            string strRptFilter = "JobOrderKPI";
            rptColl = GetReportParameters(strRptFilter, 5, 8, 0);
            serverReport.ReportPath = "/" + rptColl[0] + "/" + rptColl[1];
            lblRptName.Text = "JobOrder KPI Report";
        }
        else
        {
            return;
        }       
    }
    private string getServerURL()
    {
        string strURL = string.Empty;
        try
        {
            string strQuery = "SELECT reportURL From ReportServer";
            using (SqlConnection conn = new SqlConnection(connValue))
            {
                conn.Open();

                SqlCommand sqlCmd = new SqlCommand(strQuery, conn);
                sqlCmd.CommandText = strQuery;
                sqlCmd.CommandType = CommandType.Text;
                sqlCmd.Connection = conn;
                using (SqlDataReader sqlDtReader = sqlCmd.ExecuteReader())
                {
                    while (sqlDtReader.Read())
                    {
                        strURL = sqlDtReader["reportURL"].ToString();
                    }
                }
            }
        }
        catch (Exception ex)
        {
        }

        return strURL;
    }
    public class CustomReportCredentials : IReportServerCredentials
    {
        private string _UserName;
        private string _PassWord;
        private string _DomainName;

        public CustomReportCredentials(string UserName, string PassWord, string DomainName)
        {
            _UserName = UserName;
            _PassWord = PassWord;
            _DomainName = DomainName;
        }

        public System.Security.Principal.WindowsIdentity ImpersonationUser
        {
            get { return null; }
        }

        public ICredentials NetworkCredentials
        {
            get { return new NetworkCredential(_UserName, _PassWord, _DomainName); }
        }

        public bool GetFormsCredentials(out Cookie authCookie, out string user,
         out string password, out string authority)
        {
            authCookie = null;
            user = password = authority = null;
            return false;
        }
    }
    private IList<string> GetReportParameters(string filterName,int mainID,int subID,int filterID)
    {
        IList<string> strColl = null;
        try
        {
            dal = new DAL(connValue);
            if (dal.ConnectDB(this.Page) != 'E')
            {
                string strQuery = "SELECT r.* FROM Reports r,ReportsFilter f,ReportsMainMenu m,ReportsSubMenu s WHERE r.rptMainMenuID = m.rptMainMenuID AND r.rptSubMenuID = s.rptSubMenuID AND r.rptFilterID = f.rptfilterID AND " +
                " f.rptfilterdescription = '" + filterName + "' and  r.rptMainMenuID = @rptMainMenuID and r.rptSubMenuID = @rptSubMenuID";
                SqlCommand sqlCmd = new SqlCommand(strQuery, dal.SqlConnection);
                sqlCmd.Parameters.AddWithValue("@rptMainMenuID", mainID);
                sqlCmd.Parameters.AddWithValue("@rptSubMenuID", subID);
                sqlCmd.Parameters.AddWithValue("@rptFilterID", filterID);
                SqlDataReader sqlDtReader = sqlCmd.ExecuteReader();

                if (sqlDtReader.Read())
                {
                    strColl = new List<string>();
                    strColl.Add(sqlDtReader["moduleName"].ToString());
                    strColl.Add(sqlDtReader["reportName"].ToString());
                    strColl.Add(sqlDtReader["parameters"].ToString());
                }
            }
            dal.DisconnectDB();

        }
        catch (Exception ex)
        {

        }
        return strColl;
    }
    private void PopulateDropDownBox(DropDownList ddlBox, string sqlQuery, string valueMember, string displayName)
    {
        ddlBox.DataBound += new EventHandler(this.ddlBox_DataBound);
        ddlBox.DataSource = new JobOrderData().FillDropdown(sqlQuery);
        ddlBox.DataTextField = displayName;
        ddlBox.DataValueField = valueMember;
        ddlBox.SelectedIndex = -1;
        ddlBox.DataBind();
    }
    protected void ddlBox_DataBound(object sender, EventArgs e)
    {
        DropDownList ddl = (DropDownList)sender;
        ListItem emptyItem = new ListItem("", "");
        ddl.Items.Insert(0, emptyItem);
    }
    protected void d(object sender, EventArgs e)
    {

    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        
    }
    protected void btnClear_Click(object sender, EventArgs e)
    {
        ddlYear.SelectedIndex = 0;
        ddldocStatus.SelectedIndex = 0;
        ddlEmployee.SelectedIndex = 0;
        ddlDateRead.SelectedIndex = 0;
    }
    protected void ddlKPIType_SelectedIndexChanged(object sender, EventArgs e)
    {
        getReport();

        ReportParameter jobOrderYear = new ReportParameter();
        jobOrderYear.Name = "Year";
        jobOrderYear.Values.Add("2017");

        rptViewer.ServerReport.SetParameters(new ReportParameter[] { jobOrderYear });
        this.rptViewer.ServerReport.Refresh();
    }
    protected void ddlReportsMainMenu_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void ddlYear_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void ddlReportsSubMenu_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
}