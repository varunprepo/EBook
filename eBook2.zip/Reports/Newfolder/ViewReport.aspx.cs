﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Microsoft.Reporting.WebForms;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;

public partial class Reports_ViewReport : System.Web.UI.Page
{
    string connValue = ConfigurationManager.ConnectionStrings["EBSDEBookConn"].ToString();
    static string strRptURL = string.Empty;
    protected void Page_Load(object sender, EventArgs e)
    {
        strRptURL = getServerURL();
        if (!Page.IsPostBack)
        {
            rptViewer.ProcessingMode = ProcessingMode.Remote;
            ServerReport serverReport = rptViewer.ServerReport;
            serverReport.ReportServerUrl = new Uri(strRptURL);
            serverReport.ReportPath = "/COST_CONTROL_EXT/DocumentKPIs_TEST";

            this.rptViewer.ServerReport.Refresh();
        }
    }
    private string getServerURL()
    {
        string strURL = string.Empty;
        try
        {
            string strQuery = "SELECT reportURL From ReportServer";
            SqlConnection conn = new SqlConnection(connValue);
            conn.Open();

            SqlCommand sqlCmd = new SqlCommand(strQuery, conn);
            sqlCmd.CommandText = strQuery;
            sqlCmd.CommandType = CommandType.Text;
            sqlCmd.Connection = conn;
            using (SqlDataReader sqlDtReader = sqlCmd.ExecuteReader())
            {
                while (sqlDtReader.Read())
                {
                    strURL = sqlDtReader["reportURL"].ToString();
                }
            }
        }
        catch (Exception ex)
        {
        }

        return getServerURL();
    }
    protected void lnkGenerateReports_Click(object sender, EventArgs e)
    {
        rptViewer.ProcessingMode = ProcessingMode.Remote;
        ServerReport serverReport = rptViewer.ServerReport;       
        serverReport.ReportServerUrl = new Uri(strRptURL);
        serverReport.ReportPath = "/EBOOK_DEV/CurOnGoingJobs";          
        this.rptViewer.ServerReport.Refresh();
    }
    protected void lnkSearchMyDocs_Click(object sender, EventArgs e)
    {
       
    }
    protected void lnkSearchAddendumLog_Click(object sender, EventArgs e)
    {

    }
    protected void lnkPaymentRequest_Click(object sender, EventArgs e)
    {

    }
    protected void lnkPaymentRequestCP_Click(object sender, EventArgs e)
    {

    }
    protected void lnkNewJobOrder_Click(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        rptViewer.ProcessingMode = ProcessingMode.Remote;
        ServerReport serverReport = rptViewer.ServerReport;       

        serverReport.ReportServerUrl = new Uri(strRptURL);
        serverReport.ReportPath = "/EBOOK_DEV/YrlyJobCountByAffairComp";
        ReportParameter jobOrderYear = new ReportParameter();
        jobOrderYear.Name = "JobYear";
        jobOrderYear.Values.Add("2014");

        rptViewer.ServerReport.SetParameters(new ReportParameter[] { jobOrderYear });

        // Set the report parameters for the report
        // rptViewer.ServerReport.SetParameters(new ReportParameter[] { jobOrderYear });
        this.rptViewer.ServerReport.Refresh();
    }

    //===============================================================================================================================

    protected void rdbNoActivation_CheckedChanged(object sender, EventArgs e)
    {
        EnableDisableControls(true);
    }
    protected void rdbActivation_CheckedChanged(object sender, EventArgs e)
    {
        EnableDisableControls(false);
    }
    private void EnableDisableControls(bool isEnabled)
    {
        txtStartDate.Disabled = isEnabled;
        txtEndDate.Disabled = isEnabled;
       
    }
}