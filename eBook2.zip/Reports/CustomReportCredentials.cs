﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for CustomReportCredentials
/// </summary>
public class CustomReportCredentials
{
	public CustomReportCredentials()
	{
		//
		// TODO: Add constructor logic here
		//
	}
}