﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using Microsoft.Reporting.WebForms;
using System.Net;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using Datalayer;

public partial class Reports_rptNewReports : System.Web.UI.Page
{
    string connValue = ConfigurationManager.ConnectionStrings["EBSDEBookConn"].ToString();  
    static string strRptURL = string.Empty;
    string strRptFilter = string.Empty;
    IList<string> userRightsColl = new List<string>();
    IList<string> rptColl = new List<string>();
    string rptName = string.Empty;

    string sqlQueryYear = null;


    #region MyRegion


    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["userProfileID"] != null)
        {
            if ((Session["SectionID"].ToString().Equals("1")) || (Session["userProfileID"].ToString().Equals("1")))
            {
                if (!Page.IsPostBack)
                {
                    userRightsColl = (IList<string>)Session["UserRightsColl"];
                    strRptURL = getServerURL();
                    ddlReportsSubMenu.Enabled = false;
                    generateDefaultReport("0", "0", "0");

                    string sqlQueryMain = string.Empty;
                    if ((Session["userProfileID"].ToString().Equals("1")) || !userRightsColl.Contains("34"))                 // 34- View REPORTS Cost Control Section
                    {
                        sqlQueryMain = "select rptMainMenuID,rptMainMenuDescription from ReportsMainMenu where rptMainMenuID <> 0 and sectionID = 1 order by rptMainMenuID";
                        sqlQueryYear = "SELECT YEAR(jobReceivedDate) AS Year FROM  Job where sectionID = 1 GROUP BY  YEAR(jobReceivedDate) ORDER BY Year DESC";
                    }
                    else
                    {
                        if (!userRightsColl.Contains("24"))
                            sqlQueryMain = "select rptMainMenuID,rptMainMenuDescription from ReportsMainMenu where rptMainMenuID <> 0 and sectionID = " + Convert.ToInt16(Session["SectionID"]) + " order by rptMainMenuID";
                        else
                            sqlQueryMain = "select rptMainMenuID,rptMainMenuDescription from ReportsMainMenu where rptMainMenuID not in(0,5) and sectionID = " + Convert.ToInt16(Session["SectionID"]) + " order by rptMainMenuID";   // Normal user hide adoc reports                     
                        sqlQueryYear = "SELECT YEAR(jobReceivedDate) AS Year FROM  Job where sectionID = " + Convert.ToInt16(Session["SectionID"]) + " GROUP BY  YEAR(jobReceivedDate) ORDER BY Year DESC";

                    }

                    PopulateDropDownBox(ddlReportsMainMenu, sqlQueryMain, "rptMainMenuID", "rptMainMenuDescription");
                    PopulateDropDownBox(ddlYear, sqlQueryYear, "Year", "Year");
                    ddlYear.Enabled = false;
                    ddlYear.SelectedIndex = 0;
                    tblStartEndDate.Visible = true;
                    tblAffairs.Visible = false;

                    tblKPI.Visible = false;
                }
            }
            else
            {
                ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Restricted Access.')</script>", false);
            }
        }
        else
        {
            Response.Redirect("~/LoginPage.aspx", false);
        }

    }
    protected void ddlReportsMainMenu_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (Session["userProfileID"] != null)
        {
            ddlReportsSubMenu.Enabled = true;
            tblAffairs.Visible = false;
            tblKPI.Visible = false;
            if (Session["userProfileID"].ToString().Equals("1"))
            {
                if (ddlReportsMainMenu.SelectedValue != "")
                {
                    ddlReportsSubMenu.DataSource = null;
                    string sqlQuery = "select rptSubMenuID,rptSubMenuDescription from ReportsSubMenu where rptMainMenuID=" + ddlReportsMainMenu.SelectedValue + " AND (isActive = 1)";
                    PopulateDropDownBox(ddlReportsSubMenu, sqlQuery, "rptSubMenuID", "rptSubMenuDescription");
                    ResetControls(false);
                }
                else if (ddlReportsMainMenu.SelectedValue == "")
                {
                    ddlReportsSubMenu.DataSource = null;
                    ResetControls(true);
                }
            }
            else
            {
                if (ddlReportsMainMenu.SelectedValue.Equals("5")) // Ad HOC
                {
                    ddlReportsSubMenu.DataSource = null;
                    string sqlQuery = "SELECT rptSubMenuID, rptSubMenuDescription FROM ReportsSubMenu WHERE (rptMainMenuID IN (5)) AND (sectionID = 1) AND (isActive = 1) ";
                    PopulateDropDownBox(ddlReportsSubMenu, sqlQuery, "rptSubMenuID", "rptSubMenuDescription");
                    ResetControls(false);
                }
                else if (ddlReportsMainMenu.SelectedValue != "")
                {
                    ddlReportsSubMenu.DataSource = null;
                    string sqlQuery = "select rptSubMenuID,rptSubMenuDescription from ReportsSubMenu where (isActive = 1) and rptMainMenuID=" + ddlReportsMainMenu.SelectedValue;  // sectionID = " + Convert.ToInt16(Session["SectionID"]) + " AND
                    PopulateDropDownBox(ddlReportsSubMenu, sqlQuery, "rptSubMenuID", "rptSubMenuDescription");
                    ResetControls(false);
                }
                else if (ddlReportsMainMenu.SelectedValue == "")
                {
                    ddlReportsSubMenu.DataSource = null;
                    ResetControls(true);
                }
            }
        }
        else
        {
            Response.Redirect("~/LoginPage.aspx", false);
        }
    }
    private void fillAffairAndMinistryData()
    {
        //string strAffair = "SELECT  COUNT(Job.jobID) AS jobCnt, Department_1.deptName AS AffairName, Department_1.departmentID AS AffairID FROM  JobVOSI INNER JOIN  Job ON JobVOSI.jobID = Job.jobID INNER JOIN " +
        //            " JobType ON Job.jobTypeID = JobType.jobTypeID INNER JOIN   Department ON Job.deptID = Department.departmentID INNER JOIN   Department AS Department_1 ON Department.affairID = Department_1.departmentID " +
        //              " WHERE (JobType.CategoryID IN (4) and Department_1.isActive=1) GROUP BY Department_1.deptName, Department_1.departmentID ORDER BY AffairName";

        string strAffair = "SELECT DISTINCT affairName AS AffairName, affairID AS AffairID FROM Affair WHERE (isActive = 1) ORDER BY AffairID";
        PopulateDropDownBox(ddlAffair, strAffair, "AffairID", "AffairName");

        // WHERE (JobType.CategoryID IN (4))

        string strMinistry = "SELECT Job.ministryCode FROM  JobVOSI INNER JOIN   Job ON JobVOSI.jobID = Job.jobID INNER JOIN JobType ON Job.jobTypeID = JobType.jobTypeID GROUP BY Job.ministryCode HAVING (Job.ministryCode IS NOT NULL) ORDER BY Job.ministryCode";
        PopulateDropDownBox(ddlMinistry, strMinistry, "ministryCode", "ministryCode");

        string strBudRef = "SELECT Job.budgetRefNo  FROM  JobVOSI INNER JOIN   Job ON JobVOSI.jobID = Job.jobID INNER JOIN JobType ON Job.jobTypeID = JobType.jobTypeID GROUP BY Job.budgetRefNo HAVING (Job.budgetRefNo IS NOT NULL) ORDER BY Job.budgetRefNo";
        PopulateDropDownBox(ddlBudget, strBudRef, "budgetRefNo", "budgetRefNo");

        string strProvision = "SELECT Job.provisionNo  FROM  JobVOSI INNER JOIN   Job ON JobVOSI.jobID = Job.jobID INNER JOIN JobType ON Job.jobTypeID = JobType.jobTypeID GROUP BY Job.provisionNo HAVING (Job.provisionNo  IS NOT NULL) ORDER BY Job.provisionNo";
        PopulateDropDownBox(ddlProv, strProvision, "provisionNo", "provisionNo");
    }


    /// <summary>
    /// Generate Report for the admin without filter parameter
    /// </summary>
    private void generateDefaultReport(string mainID, string subID, string filterID)
    {
        try
        {
            ServerReport serverReport = rptViewer.ServerReport;
            IReportServerCredentials irsc = new CustomReportCredentials(ConfigurationManager.AppSettings["userNameForReport"].ToString(), ConfigurationManager.AppSettings["passWordForReport"].ToString(),
            ConfigurationManager.AppSettings["domainName"].ToString());
            serverReport.ReportServerCredentials = irsc;
            rptViewer.ProcessingMode = ProcessingMode.Remote;
            serverReport.ReportServerUrl = new Uri(strRptURL);
            IList<string> strReportColl = GetReport(mainID, subID, filterID);
            if (strReportColl != null)
            {
                serverReport.ReportPath = "/" + strReportColl[0] + "/" + strReportColl[1];
                this.rptViewer.ServerReport.Refresh();
            }
        }
        catch (Exception ex)
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('" + ex.Message + "')</script>", false);
        }
    }


    private void generateReport(int filterID, bool isDateSelected)
    {
        try
        {
            ServerReport serverReport = rptViewer.ServerReport;

            IReportServerCredentials irsc = new CustomReportCredentials(ConfigurationManager.AppSettings["userNameForReport"].ToString(), ConfigurationManager.AppSettings["passWordForReport"].ToString(),

            ConfigurationManager.AppSettings["domainName"].ToString());
            serverReport.ReportServerCredentials = irsc;
            rptViewer.ProcessingMode = ProcessingMode.Remote;
            serverReport.ReportServerUrl = new Uri(strRptURL);

            IList<string> strReportColl = GetReportParametersBySelection(ddlReportsMainMenu.SelectedValue, ddlReportsSubMenu.SelectedValue, filterID);

            if (strReportColl == null)
                return;

            serverReport.ReportPath = "/" + strReportColl[0] + "/" + strReportColl[1];

            if (ddlReportsSubMenu.SelectedValue != "")
            {
                if (Convert.ToInt16(ddlReportsSubMenu.SelectedValue) == 8)
                    SetParametersForJobOrderKPIReport(strReportColl);
                else if ((Convert.ToInt16(ddlReportsSubMenu.SelectedValue) >= 40 && Convert.ToInt16(ddlReportsSubMenu.SelectedValue) <= 54) || Convert.ToInt16(ddlReportsSubMenu.SelectedValue) == 60 ||
                    Convert.ToInt16(ddlReportsSubMenu.SelectedValue) == 77) //60==35_PCCKPI; 77=36_ProjectAndAssetVOKPI
                {
                    if (!isDateSelected && (Convert.ToInt16(ddlReportsSubMenu.SelectedValue) == 40 || Convert.ToInt16(ddlReportsSubMenu.SelectedValue) == 41))
                    {
                        txtEndDate.Text = getMonthLastDate();
                    }
                    else if (Convert.ToInt16(ddlReportsSubMenu.SelectedValue) == 42 || Convert.ToInt16(ddlReportsSubMenu.SelectedValue) == 60 || Convert.ToInt16(ddlReportsSubMenu.SelectedValue) == 77) //60==35_PCCKPI
                    {
                        if (Convert.ToInt16(ddlReportsSubMenu.SelectedValue) == 60)
                        {
                            txtStartDate.Text = "01/Jan/" + DateTime.Now.Year; // ToString("dd/MMM/yyyy");
                        }
                        else
                        {
                            if(ddlYear.SelectedIndex!=0)
                            {
                                txtStartDate.Text = "";
                                txtEndDate.Text = "";
                            }
                            else if (!isDateSelected)
                            {
                                txtEndDate.Text = Convert.ToDateTime(DateTime.Now.ToString()).ToString("dd/MMM/yyyy");
                            }

                            if (ddlYear.SelectedIndex == 0)
                            {
                                if (ddlReportsSubMenu.SelectedValue == "77")
                                {
                                    if (txtStartDate.Text == "")
                                    {
                                        txtStartDate.Text = "01/Jan/" + DateTime.Now.Year;
                                    }
                                }
                                else
                                {
                                    if (txtStartDate.Text == "")
                                    {
                                        txtStartDate.Text = Convert.ToDateTime(DateTime.Now.AddYears(-1)).ToString("dd/MMM/yyyy");
                                    }
                                }
                            }                            
                        }
                    }
                    else if (!isDateSelected) 
                    {
                        txtEndDate.Text = "";
                    }
                    SetParametersForTab1Report(strReportColl);
                }
                else if (!(Convert.ToInt16(ddlReportsSubMenu.SelectedValue) >= 6 && Convert.ToInt16(ddlReportsSubMenu.SelectedValue) <= 8))
                {
                    if (Convert.ToInt16(ddlReportsSubMenu.SelectedValue) == 64)
                    {
                        if (txtStartDate.Text.ToString() == "")
                        {
                            txtStartDate.Text = "01/Jan/" + DateTime.Now.Year; // ToString("dd/MMM/yyyy");
                        }
                        if (txtEndDate.Text.ToString() == "")
                        {
                            txtEndDate.Text = Convert.ToDateTime(DateTime.Now.ToString()).ToString("dd/MMM/yyyy");
                        }
                    }
                    SetParametersForTab2Report(strReportColl);
                }
                else
                    CreateParametersForKPI(strReportColl);

                //if (!(Convert.ToInt16(ddlReportsSubMenu.SelectedValue) >= 6 && Convert.ToInt16(ddlReportsSubMenu.SelectedValue) <= 8))
                //    SetParametersForTab2Report(strReportColl);
                //else if (Convert.ToInt16(ddlReportsSubMenu.SelectedValue) == 8)
                //    SetParametersForTab1Report(strReportColl);
                //else
                //    CreateParametersForKPI(strReportColl);
            }

            this.rptViewer.ServerReport.Refresh();
        }
        catch (Exception ex)
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('" + ex.Message.Replace("'","") + "')</script>", false);
        }
    }

    private void SetVisibilityOfControls(bool isVisible)
    {
        tdEmp.Visible = isVisible;
        tdDDLEmployee.Visible = isVisible;
        tdDDLDateRead.Visible = isVisible;
        tdUnRead.Visible = isVisible;
    }

    protected void ddlReportsSubMenu_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlReportsSubMenu.SelectedValue != "")
        {
            if (Session["userProfileID"] != null)
            {
                txtStartDate.Visible = true;
                lblStrDate.Visible = true;

                if ((ddlReportsMainMenu.SelectedIndex == 1) && ddlReportsSubMenu.SelectedValue.Equals("62"))       //Business Dev Reports - PCC Strategy KPI Report
                {
                    tblStartEndDate.Visible = true;
                    ResetTab1Controls();
                    tblAffairs.Visible = false;
                    tblKPI.Visible = false;
                }
                else if ((ddlReportsMainMenu.SelectedIndex == 5) && ddlReportsSubMenu.SelectedValue.Equals("60"))       //Adoc and Cost Estimate - PCC Strategy KPI Report
                {
                    tblStartEndDate.Visible = true;
                    ResetTab1Controls();
                    tblAffairs.Visible = false;
                    tblKPI.Visible = false;
                }
                else if ((ddlReportsMainMenu.SelectedIndex == 5) && ddlReportsSubMenu.SelectedValue.Equals("8"))       //Adoc and Cost Estimate
                {
                    //tblStartEndDate.Visible = true;
                    tblStartEndDate.Visible = false;
                    ResetTab1Controls();
                    tblAffairs.Visible = false;
                    tblKPI.Visible = true;
                    SetVisibilityOfControls(false);
                    tdContractNo.Visible = true;
                    tdDDLContractNo.Visible = true;
                }
                else if ((ddlReportsMainMenu.SelectedIndex == 5) && (Convert.ToInt16(ddlReportsSubMenu.SelectedValue) >= 40 && Convert.ToInt16(ddlReportsSubMenu.SelectedValue) <= 54) || ddlReportsSubMenu.SelectedValue == "64" || ddlReportsSubMenu.SelectedValue == "77")       //EBD Jobs (Up To-Date)
                {
                    if (ddlReportsSubMenu.SelectedItem.Text.Equals("Incoming Jobs (Monthly)"))
                    {
                        tblStartEndDate.Visible = false;
                    }
                    else
                    {
                        tblStartEndDate.Visible = true;
                        if (Convert.ToInt16(ddlReportsSubMenu.SelectedValue) == 64)
                        {
                            txtStartDate.Text = "01/Jan/" + DateTime.Now.Year;
                        }
                    }
                    ResetTab1Controls();
                    tblAffairs.Visible = false;
                    tblKPI.Visible = false;

                    //txtStartDate.Visible = false;
                    //lblStrDate.Visible = false;
                }
                else if (ddlReportsMainMenu.SelectedIndex <= 5 && Convert.ToInt16(ddlReportsSubMenu.SelectedValue) <= 5 || (Convert.ToInt16(ddlReportsSubMenu.SelectedValue) >= 25 && Convert.ToInt16(ddlReportsSubMenu.SelectedValue) <= 31)) //ddlReportsSubMenu.SelectedValue==2 Reports By Average Work Days
                {
                    tblAffairs.Visible = true;
                    fillAffairAndMinistryData();
                    tblKPI.Visible = false;
                    tblStartEndDate.Visible = false;
                }
                else if (Convert.ToInt16(ddlReportsSubMenu.SelectedValue) == 6 || Convert.ToInt16(ddlReportsSubMenu.SelectedValue) == 7)
                {
                    tblKPI.Visible = true;
                    SetVisibilityOfControls(true);
                    tdContractNo.Visible = false;
                    tdDDLContractNo.Visible = false;
                    ddlYear.Visible = false;
                    tblAffairs.Visible = false;
                    tblStartEndDate.Visible = false;
                }
                else
                {
                    tblKPI.Visible = true;
                    ddlYear.Visible = false;
                    tblAffairs.Visible = false;
                    tblStartEndDate.Visible = false;
                }

                ResetTab2Controls();
                if (tblKPI.Visible)
                {
                    string sqlQueryYear = "SELECT COUNT(jobID) AS jobCnt, YEAR(jobReceivedDate) AS Year FROM Job GROUP BY YEAR(jobReceivedDate) ORDER BY Year DESC";
                    PopulateDropDownBox(ddlKPIYear, sqlQueryYear, "Year", "Year");
                    ddlKPIYear.SelectedIndex = 1;
                }

                fillDropDown();


                //else
                //{
                //    ddlYear.Visible = true;
                //}

                CheckFilter();

                //CheckDDLSelections();
                //generateDefaultReport(ddlReportsMainMenu.SelectedValue, ddlReportsSubMenu.SelectedValue, "0");
            }
            else
            {
                Response.Redirect("~/LoginPage.aspx", false);
            }
        }
        else
        {
            ResetControls(true);
        }


    }

    private void CheckFilter()
    {
        if (ddlReportsSubMenu.SelectedValue != "" && ddlReportsSubMenu.SelectedValue != "0")
        {
            if (Convert.ToInt16(ddlReportsSubMenu.SelectedValue) == 5)  // D,E,J = 11,12,13  == 5 Cost Estimate
                generateReport(10, false);
            else if (Convert.ToInt16(ddlReportsSubMenu.SelectedValue) == 6)  // D,E,J = 11,12,13  Document KPIs
                generateReport(11, false);
            else if (Convert.ToInt16(ddlReportsSubMenu.SelectedValue) == 7)  // D,E,J = 11,12,13  Employee KPIs
                generateReport(12, false);
            else if (Convert.ToInt16(ddlReportsSubMenu.SelectedValue) == 8)  // D,E,J = 11,12,13  JobOrder KPIs 
                generateReport(13, false);
            else if (Convert.ToInt16(ddlReportsSubMenu.SelectedValue) == 99 || Convert.ToInt16(ddlReportsSubMenu.SelectedValue) == 62
                || Convert.ToInt16(ddlReportsSubMenu.SelectedValue) == 60 || Convert.ToInt16(ddlReportsSubMenu.SelectedValue) == 64 || ddlReportsSubMenu.SelectedValue == "77")   // D,E,J = 11,12,13 Test Report  62, 61 -> PCC Strategy KPI Report
                generateReport(0, false);
            else
                generateReport(9, false);
        }
        else
            generateReport(9, false);
    }

    private void ResetControls(bool isItemBlank)
    {

        if (isItemBlank)
        {
            //ddlReportsMainMenu.SelectedIndex = -1;
            //ddlReportsSubMenu.SelectedIndex = -1;
            //ddlReportsSubMenu.DataSource = null;
            //ddlReportsSubMenu.Enabled = false;
            //ddlYear.DataSource = null;
            //ddlYear.SelectedIndex = -1;
            //ddlYear.Enabled = false;
            //generateDefaultReport("0", "0", "0");
        }
        else
        {
            ddlReportsSubMenu.SelectedIndex = -1;
            ddlReportsSubMenu.Enabled = true;
            ddlYear.Enabled = true;
            string sqlQueryYear = "SELECT COUNT(jobID) AS jobCnt, YEAR(jobReceivedDate) AS Year FROM Job GROUP BY YEAR(jobReceivedDate) ORDER BY Year DESC";
            PopulateDropDownBox(ddlYear, sqlQueryYear, "Year", "Year");
        }

        //if (ddlYear.Visible)
        //{
        //    ddlYear.SelectedIndex = -1;
        //}
        //else
        //{
        //    ddlYear.Visible = true;
        //    ddlYear.SelectedIndex = -1;
        //}
        //tblAffairs.Visible = false;
        //tblKPI.Visible = false;

    }

    private void ResetTab2Controls()
    {
        if (tblAffairs.Visible)
        {
            ddlYear.Visible = true;
            ddlYear.SelectedIndex = 0;
            ddlAffair.SelectedIndex = 0;

            ddlDept.Items.Clear();
            ddlDept.Enabled = false;
            //ddlDept.SelectedIndex = -1;

            ddlMinistry.SelectedIndex = 0;

            ddlProv.SelectedIndex = 0;

            ddlBudget.SelectedIndex = 0;
            ClearDDLItems();
        }


        if (tblKPI.Visible)
        {
            ddlKPIYear.SelectedIndex = -1;
            ddldocStatus.SelectedIndex = -1;
            ddlEmployee.SelectedIndex = -1;
            ddlDateRead.SelectedIndex = 0;
        }
    }


    protected void ddlYear_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlReportsSubMenu.SelectedIndex == 0)  // D,E,J = 11,12,13  
        {
            return;
        }

        ddlMinistry.DataSource = null;
        LoadMinistryCodes();

        ddlBudget.DataSource = null;
        LoadBudjetCodes();

        ddlProv.DataSource = null;
        LoadProvisionCodes();

        if (ddlReportsMainMenu.SelectedValue.Equals("5"))
        {
            CheckFilter();
        }
        else
        {
            generateReport(9, false);
        }

    }

    private DataTable getMinistryData()
    {
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        try
        {
            string strYear = string.Empty;
            if (ddlYear.SelectedIndex != 0)
                strYear = ddlYear.Text;

            Int16 afrID;
            Int16.TryParse(ddlAffair.SelectedValue, out afrID);

            Int16 deptID;
            Int16.TryParse(ddlDept.SelectedValue, out deptID);

            string strMinCode = string.Empty;
            if (ddlMinistry.SelectedIndex != 0)
                strMinCode = ddlMinistry.SelectedValue;

            string strBudCode = string.Empty;
            if (ddlBudget.SelectedIndex != 0)
                strBudCode = ddlBudget.SelectedValue;

            string strProvCode = string.Empty;
            if (ddlProv.SelectedIndex != 0)
                strProvCode = ddlProv.SelectedValue;

            ds = (new JobOrderData().getMinistryData(strYear, afrID, deptID, strMinCode, strBudCode, strProvCode));       //SpName - GetPaymentData     
        }
        catch (Exception ex)
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('" + ex.Message.Replace("'", "") + "')</script>", false);
        }

        if (ds.Tables.Count == 0)
            return dt;
        else
            return ds.Tables[0];
    }
    private DataTable getBudjetCodeData()
    {
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        try
        {
            string strYear = string.Empty;
            if (ddlYear.SelectedIndex != 0)
                strYear = ddlYear.Text;

            Int16 afrID;
            Int16.TryParse(ddlAffair.SelectedValue, out afrID);

            Int16 deptID;
            Int16.TryParse(ddlDept.SelectedValue, out deptID);

            string strMinCode = string.Empty;
            if (ddlMinistry.SelectedIndex != 0)
                strMinCode = ddlMinistry.SelectedValue;

            string strBudCode = string.Empty;
            if (ddlBudget.SelectedIndex != 0)
                strBudCode = ddlBudget.SelectedValue;

            string strProvCode = string.Empty;
            if (ddlProv.SelectedIndex != 0)
                strProvCode = ddlProv.SelectedValue;

            ds = (new JobOrderData().getBudjetData(strYear, afrID, deptID, strMinCode, strBudCode, strProvCode));       //SpName - GetPaymentData     
        }
        catch (Exception ex)
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('" + ex.Message.Replace("'", "") + "')</script>", false);
        }

        if (ds.Tables.Count == 0)
            return dt;
        else
            return ds.Tables[0];
    }

    private DataTable getProvisionData()
    {
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        try
        {
            string strYaer = string.Empty;
            if (ddlYear.SelectedIndex != 0)
                strYaer = ddlYear.Text;

            Int16 afrID;
            Int16.TryParse(ddlAffair.SelectedValue, out afrID);

            Int16 deptID;
            Int16.TryParse(ddlDept.SelectedValue, out deptID);

            string strMinCode = string.Empty;
            if (ddlMinistry.SelectedIndex != 0)
                strMinCode = ddlMinistry.SelectedValue;

            string strBudCode = string.Empty;
            if (ddlBudget.SelectedIndex != 0)
                strBudCode = ddlBudget.SelectedValue;

            string strProvCode = string.Empty;
            if (ddlProv.SelectedIndex != 0)
                strProvCode = ddlProv.SelectedValue;

            ds = (new JobOrderData().getProvisionData(strYaer, afrID, deptID, strMinCode, strBudCode, strProvCode));       //SpName - GetPaymentData     
        }
        catch (Exception ex)
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('" + ex.Message.Replace("'", "") + "')</script>", false);
        }

        if (ds.Tables.Count == 0)
            return dt;
        else
            return ds.Tables[0];
    }
    private void LoadMinistryCodes()
    {
        DataTable subjects = getMinistryData();
        using (SqlConnection con = new SqlConnection(connValue))
        {
            try
            {
                ddlMinistry.DataSource = subjects;
                ddlMinistry.DataTextField = "ministryCode";
                ddlMinistry.DataValueField = "ministryCode";
                ddlMinistry.DataBind();
            }
            catch (Exception ex)
            {

            }
        }

        ddlMinistry.Items.Insert(0, new ListItem("", "0"));

    }
    private void LoadBudjetCodes()
    {
        DataTable subjects = getBudjetCodeData();
        using (SqlConnection con = new SqlConnection(connValue))
        {
            try
            {
                ddlBudget.DataSource = subjects;
                ddlBudget.DataTextField = "budgetRefNo";
                ddlBudget.DataValueField = "budgetRefNo";
                ddlBudget.DataBind();
            }
            catch (Exception ex)
            {

            }
        }

        ddlBudget.Items.Insert(0, new ListItem("", "0"));

    }
    private void LoadProvisionCodes()
    {
        DataTable subjects = getProvisionData();
        using (SqlConnection con = new SqlConnection(connValue))
        {
            try
            {
                ddlProv.DataSource = subjects;
                ddlProv.DataTextField = "provisionNo";
                ddlProv.DataValueField = "provisionNo";
                ddlProv.DataBind();
            }
            catch (Exception ex)
            {

            }
        }

        ddlProv.Items.Insert(0, new ListItem("", "0"));

    }
    protected void ddlDept_SelectedIndexChanged(object sender, EventArgs e)
    {
        ClearDDLItems();
        ddlMinistry.DataSource = null;
        try
        {
            LoadMinistryCodes();

            ddlBudget.DataSource = null;
            LoadBudjetCodes();

            ddlProv.DataSource = null;
            LoadProvisionCodes();
        }
        catch (Exception ex)
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('" + ex.Message.Replace("'", "") + "')</script>", false);
        }
        CheckFilter();
    }

    // Year,AffairID,DeptID,MinCode,BudRef,ProvNo
    protected void ddlMinistry_SelectedIndexChanged(object sender, EventArgs e)
    {
        ddlBudget.Items.Clear();
        ddlBudget.SelectedIndex = -1;
        ddlProv.Items.Clear();
        ddlProv.SelectedIndex = -1;

        ddlBudget.DataSource = null;
        LoadBudjetCodes();

        ddlProv.DataSource = null;
        LoadProvisionCodes();
        CheckFilter();
    }
    protected void ddlBudget_SelectedIndexChanged(object sender, EventArgs e)
    {
        ddlProv.Items.Clear();
        ddlProv.SelectedIndex = -1;
        ddlProv.DataSource = null;
        LoadProvisionCodes();
        CheckFilter();
    }
    protected void ddlProv_SelectedIndexChanged(object sender, EventArgs e)
    {
        CheckFilter();
    }


    #region KPI

    #endregion
    // --------------------------------------------------------------------------------------------------------------------------------------------------------------



    private void fillDropDown()
    {
        rptName = ddlReportsSubMenu.SelectedValue;
        ddldocStatus.DataSource = null;
        if (rptName.Equals("3") || rptName.Equals("7"))
        {
            string sqlQueryEmp = "SELECT   contactID, firstName + ' ' + lastName AS userName, sectionID FROM Contact  WHERE (sectionID = 1) ORDER BY userName";
            PopulateDropDownBox(ddlEmployee, sqlQueryEmp, "contactID", "userName");

            string sqlQryYear = "SELECT jobStatusID,jobStatusName from JobStatus where jobStatusID < 8";
            PopulateDropDownBox(ddldocStatus, sqlQryYear, "jobStatusID", "jobStatusName");
        }
        else if (rptName.Equals("6"))               // Document KPI
        {
            //lblRptName.Text = "Document KPI";             
            string sqlQryYear = "SELECT docStatusID,DocStatusName from DocumentStatus";
            PopulateDropDownBox(ddldocStatus, sqlQryYear, "docStatusID", "DocStatusName");

            string sqlQueryEmp = "SELECT contactID, firstName + ' ' + lastName AS userName, sectionID FROM Contact  WHERE (sectionID = 1) ORDER BY userName";
            PopulateDropDownBox(ddlEmployee, sqlQueryEmp, "contactID", "userName");
        }
        //else if (rptName.Equals("6"))               // Document KPI
        //{
        //    //lblRptName.Text = "Document KPI";
        //    lblName.Text = "Employee";
        //    string sqlQryYear = "SELECT docStatusID,DocStatusName from DocumentStatus";
        //    PopulateDropDownBox(ddldocStatus, sqlQryYear, "docStatusID", "DocStatusName");

        //    string sqlQueryEmp = "SELECT contactID, firstName + ' ' + lastName AS userName, sectionID FROM Contact  WHERE (sectionID = 1) ORDER BY userName";
        //    PopulateDropDownBox(ddlEmployee, sqlQueryEmp, "contactID", "userName");
        //}
        //else if (rptName.Equals("7"))              // Employee KPI
        //{
        //    lblRptName.Text = "Employee KPI";
        //    lblName.Text = "Employee";
        //    string sqlQryYear = "SELECT jobStatusID,jobStatusName from JobStatus where jobStatusID < 8";
        //    PopulateDropDownBox(ddldocStatus, sqlQryYear, "jobStatusID", "jobStatusName");

        //    string sqlQueryEmp = "SELECT contactID, firstName + ' ' + lastName AS userName, sectionID FROM Contact WHERE (sectionID = 1) ORDER BY userName";
        //    PopulateDropDownBox(ddlEmployee, sqlQueryEmp, "contactID", "userName");
        //}
        else if (rptName.Equals("8"))               // JobOrder or Strategy KPI
        {

            //lblRptName.Text = "JobOrder KPI";
            //if (rptName.Equals("60"))               // Strategy KPI
            //    lblRptName.Text = "PCC Strategy KPI";

            string sqlQryYear = "SELECT jobStatusID,jobStatusName from JobStatus where jobStatusID < 8";
            PopulateDropDownBox(ddldocStatus, sqlQryYear, "jobStatusID", "jobStatusName");

            lblName.Text = "Project";

            string sqlQueryPrj = "SELECT DISTINCT contractNo,contractNo as cntr FROM Job WHERE (contractNo IS NOT NULL) AND (contractNo <> '') ORDER BY contractNo";
            PopulateDropDownBox(ddlContractNo, sqlQueryPrj, "contractNo", "cntr");

            //string sqlQueryEmp = "SELECT   contactID, firstName + ' ' + lastName AS userName, sectionID FROM Contact WHERE (sectionID = 1) ORDER BY userName";
            //PopulateDropDownBox(ddlEmployee, sqlQueryEmp, "contactID", "userName");
        }

    }
    private IList<string> GetReportParametersBySelection(string mainID, string subID, int filterID)
    {
        IList<string> strColl = null;
        try
        {
            using (SqlConnection cn = new SqlConnection(connValue))
            {
                string strQuery = "SELECT Reports.moduleName, Reports.reportName, Reports.parameters FROM ReportsSubMenu INNER JOIN ReportsMainMenu INNER JOIN ReportsFilter INNER JOIN Reports " +
                "ON ReportsFilter.rptfilterID = Reports.rptFilterID ON ReportsMainMenu.rptMainMenuID = Reports.rptMainMenuID ON ReportsSubMenu.rptSubMenuID = Reports.rptSubMenuID WHERE " +
                "(Reports.rptMainMenuID = @rptMainMenuID) AND (ReportsSubMenu.rptSubMenuID = @rptSubMenuID) AND (Reports.rptFilterID = @rptFilterID)";

                cn.Open();

                using (SqlCommand sqlCmd = new SqlCommand(strQuery, cn))
                {

                    sqlCmd.Parameters.AddWithValue("@rptMainMenuID", mainID);
                    sqlCmd.Parameters.AddWithValue("@rptSubMenuID", subID);
                    sqlCmd.Parameters.AddWithValue("@rptFilterID", filterID);

                    using (SqlDataReader sqlDtReader = sqlCmd.ExecuteReader())
                    {
                        if (sqlDtReader.Read())
                        {
                            strColl = new List<string>();
                            strColl.Add(sqlDtReader["moduleName"].ToString());
                            strColl.Add(sqlDtReader["reportName"].ToString());
                            strColl.Add(sqlDtReader["parameters"].ToString());
                        }
                    }
                }

            }
        }
        catch (Exception ex)
        {

        }
        return strColl;
    }

    private IList<string> GetReport(string mainID, string subID, string filterID)
    {
        IList<string> strColl = null;
        try
        {
            using (SqlConnection cn = new SqlConnection(connValue))
            {
                if (!filterID.Equals("0"))
                {

                    string strQuery = "SELECT Reports.moduleName, Reports.reportName, Reports.parameters FROM ReportsSubMenu INNER JOIN " +
                    "ReportsMainMenu INNER JOIN ReportsFilter INNER JOIN Reports ON ReportsFilter.rptfilterID = Reports.rptFilterID ON ReportsMainMenu.rptMainMenuID = Reports.rptMainMenuID ON " +
                    "ReportsSubMenu.rptSubMenuID = Reports.rptSubMenuID WHERE (Reports.rptMainMenuID = @rptMainMenuID) AND (ReportsSubMenu.rptSubMenuID = @rptSubMenuID) AND (Reports.rptFilterID = @rptFilterID)";


                    cn.Open();

                    using (SqlCommand sqlCmd = new SqlCommand(strQuery, cn))
                    {

                        sqlCmd.Parameters.AddWithValue("@rptMainMenuID", mainID);
                        sqlCmd.Parameters.AddWithValue("@rptSubMenuID", subID);
                        sqlCmd.Parameters.AddWithValue("@rptFilterID", filterID);

                        using (SqlDataReader sqlDtReader = sqlCmd.ExecuteReader())
                        {
                            if (sqlDtReader.Read())
                            {
                                strColl = new List<string>();
                                strColl.Add(sqlDtReader["moduleName"].ToString().Trim());
                                strColl.Add(sqlDtReader["reportName"].ToString().Trim());
                                strColl.Add(sqlDtReader["parameters"].ToString().Trim());
                            }
                        }
                    }
                }
                else
                {
                    string strQuery = "SELECT r.* FROM Reports r,ReportsMainMenu m,ReportsSubMenu s WHERE r.rptMainMenuID = m.rptMainMenuID AND r.rptSubMenuID = s.rptSubMenuID AND " +
                    " r.rptMainMenuID = @rptMainMenuID and r.rptSubMenuID = @rptSubMenuID";

                    cn.Open();

                    using (SqlCommand sqlCmd = new SqlCommand(strQuery, cn))
                    {

                        sqlCmd.Parameters.AddWithValue("@rptMainMenuID", mainID);
                        sqlCmd.Parameters.AddWithValue("@rptSubMenuID", subID);
                        //sqlCmd.Parameters.AddWithValue("@rptFilterID", filterID);

                        using (SqlDataReader sqlDtReader = sqlCmd.ExecuteReader())
                        {
                            if (sqlDtReader.Read())
                            {
                                strColl = new List<string>();
                                strColl.Add(sqlDtReader["moduleName"].ToString().Trim());
                                strColl.Add(sqlDtReader["reportName"].ToString().Trim());
                                strColl.Add(sqlDtReader["parameters"].ToString().Trim());
                            }
                        }
                    }
                }

            }
        }
        catch (Exception ex)
        {

        }
        return strColl;
    }

    private string SetParametersForTab2Report(IList<string> rptColl)
    {
        string rptName = string.Empty;
        rptName = "/" + rptColl[0] + "/" + rptColl[1];

        string[] parameterColl = rptColl[2].Split(',');
        foreach (var rptParameter in parameterColl)          // jobStatusID,contactID,jobUnread 
        {
            string val = null;
            if (rptParameter.Equals("Year") && ddlYear.SelectedValue != "0" && ddlYear.SelectedValue != "")
                val = ddlYear.SelectedValue;
            else if (rptParameter.Equals("AffairID") && ddlAffair.SelectedValue != "0" && ddlAffair.SelectedValue != "")
                val = ddlAffair.SelectedValue;
            else if (rptParameter.Equals("DeptID") && ddlDept.SelectedValue != "0" && ddlDept.SelectedValue != "")
                val = ddlDept.SelectedValue;
            else if (rptParameter.Equals("MinCode") && ddlMinistry.SelectedValue != "0" && ddlMinistry.SelectedValue != "")
                val = ddlMinistry.SelectedValue;
            else if (rptParameter.Equals("BudRef") && ddlBudget.SelectedValue != "0" && ddlBudget.SelectedValue != "")
                val = ddlBudget.SelectedValue;
            else if (rptParameter.Equals("ProvNo") && ddlProv.SelectedValue != "0" && ddlProv.SelectedValue != "")
                val = ddlProv.SelectedValue;
            else if (rptParameter.Equals("StartDate") & txtStartDate.Text != "")
                val = txtStartDate.Text;
            else if (rptParameter.Equals("EndDate") & txtEndDate.Text != "")
                val = txtEndDate.Text;

            rptViewer.ServerReport.SetParameters(new ReportParameter(rptParameter, val, false));
        }
        return rptName;
    }

    private string SetParametersForTab1Report(IList<string> rptColl)
    {
        string rptName = string.Empty;
        rptName = "/" + rptColl[0] + "/" + rptColl[1];

        string[] parameterColl = rptColl[2].Split(',');

        if (txtEndDate.Text != "")
        {
            if (Convert.ToDateTime(txtEndDate.Text).CompareTo(Convert.ToDateTime(getMonthLastDate())) == 0)
            {
                txtEndDate.Text = getMonthLastDate();
            }
        }

        foreach (var rptParameter in parameterColl)          // jobStatusID,contactID,jobUnread 
        {
            string val = null;
            if ((rptParameter=="Year" || rptParameter=="year") && ddlYear.SelectedValue != "0" && ddlYear.SelectedValue != "")
                val = ddlYear.SelectedValue;
            else if (rptParameter.Equals("StartDate") & txtStartDate.Text != "")
                val = txtStartDate.Text;
            else if (rptParameter.Equals("EndDate") & txtEndDate.Text != "")
                val = txtEndDate.Text;

            rptViewer.ServerReport.SetParameters(new ReportParameter(rptParameter, val, false));
        }
        return rptName;
    }

    private string SetParametersForJobOrderKPIReport(IList<string> rptColl)
    {
        string rptName = string.Empty;
        rptName = "/" + rptColl[0] + "/" + rptColl[1];

        string[] parameterColl = rptColl[2].Split(',');

        if (txtEndDate.Text != "")
        {
            if (Convert.ToDateTime(txtEndDate.Text).CompareTo(Convert.ToDateTime(getMonthLastDate())) == 0)
            {
                txtEndDate.Text = getMonthLastDate();
            }
        }

        foreach (var rptParameter in parameterColl)          // jobStatusID,contactID,jobUnread 
        {
            string val = null;
            if (rptParameter.Equals("Year") && ddlKPIYear.SelectedValue != "0" && ddlKPIYear.SelectedValue != "")
                val = ddlKPIYear.SelectedValue;
            else if (rptParameter.Equals("jobStatusID") & ddldocStatus.SelectedValue != "0" && ddldocStatus.SelectedValue != "")
                val = ddldocStatus.SelectedValue;
            else if (rptParameter.Equals("projectID") & ddlContractNo.SelectedValue != "0" && ddlContractNo.SelectedValue != "")
                val = ddlContractNo.SelectedValue;

            rptViewer.ServerReport.SetParameters(new ReportParameter(rptParameter, val, false));
        }
        return rptName;
    }


    private string CreateParametersForKPI(IList<string> rptColl)
    {
        string rptName = string.Empty;
        rptName = "/" + rptColl[0] + "/" + rptColl[1];

        string[] parameterColl = rptColl[2].Split(',');
        foreach (var rptParameter in parameterColl)
        {
            string val = null;
            if (rptParameter.Equals("Year") & ddlKPIYear.SelectedValue != "")
                val = ddlKPIYear.SelectedValue;

            if (rptParameter.Equals("jobStatusID") & ddldocStatus.SelectedValue != "")
                val = ddldocStatus.SelectedValue;

            if (rptParameter.Equals("docStatusID") & ddldocStatus.SelectedValue != "")
                val = ddldocStatus.SelectedValue;

            if (rptParameter.Equals("contactID") & ddlEmployee.SelectedValue != "")
                val = ddlEmployee.SelectedValue;

            if (rptParameter.Equals("jobUnread") & ddlDateRead.SelectedValue != "")
                val = ddlDateRead.SelectedValue;

            if (rptParameter.Equals("docUnread") & ddlDateRead.SelectedValue != "")
                val = ddlDateRead.SelectedValue;

            if (rptParameter.Equals("projectID") & ddlContractNo.SelectedValue != "")
                val = ddlContractNo.SelectedValue;

            rptViewer.ServerReport.SetParameters(new ReportParameter(rptParameter, val, false));
        }
        return rptName;
    }

    // --------------------------------------------------------------------------------------------------------------------------------------------------------------------------

    protected void btnClearKPI_Click(object sender, EventArgs e)
    {
        ddlKPIYear.SelectedIndex = 0;
        ddldocStatus.SelectedIndex = 0;
        ddlEmployee.SelectedIndex = 0;
        ddlDateRead.SelectedIndex = 0;
    }



    #region MyRegion
    private string getServerURL()
    {
        string strURL = string.Empty;
        try
        {
            string strQuery = "SELECT reportURL From ReportServer";
            using (SqlConnection conn = new SqlConnection(connValue))
            {
                conn.Open();

                SqlCommand sqlCmd = new SqlCommand(strQuery, conn);
                sqlCmd.CommandText = strQuery;
                sqlCmd.CommandType = CommandType.Text;
                sqlCmd.Connection = conn;
                using (SqlDataReader sqlDtReader = sqlCmd.ExecuteReader())
                {
                    while (sqlDtReader.Read())
                    {
                        strURL = sqlDtReader["reportURL"].ToString();
                    }
                }
            }
        }
        catch (Exception ex)
        {

        }

        return strURL;
    }
    private void PopulateDropDownBox(DropDownList ddlBox, string sqlQuery, string valueMember, string displayName)
    {
        ddlBox.DataBound += new EventHandler(this.ddlBox_DataBound);
        ddlBox.DataSource = new JobOrderData().FillDropdown(sqlQuery);
        ddlBox.DataTextField = displayName;
        ddlBox.DataValueField = valueMember;
        ddlBox.SelectedIndex = -1;
        ddlBox.DataBind();
    }
    protected void ddlBox_DataBound(object sender, EventArgs e)
    {
        DropDownList ddl = (DropDownList)sender;
        ListItem emptyItem = new ListItem("", "");
        ddl.Items.Insert(0, emptyItem);
    }
    public class CustomReportCredentials : IReportServerCredentials
    {
        private string _UserName;
        private string _PassWord;
        private string _DomainName;

        public CustomReportCredentials(string UserName, string PassWord, string DomainName)
        {
            _UserName = UserName;
            _PassWord = PassWord;
            _DomainName = DomainName;
        }

        public System.Security.Principal.WindowsIdentity ImpersonationUser
        {
            get { return null; }
        }

        public ICredentials NetworkCredentials
        {
            get { return new NetworkCredential(_UserName, _PassWord, _DomainName); }
        }

        public bool GetFormsCredentials(out Cookie authCookie, out string user,
         out string password, out string authority)
        {
            authCookie = null;
            user = password = authority = null;
            return false;
        }
    }

    private void forCostControlWithKPIs()
    {
        if (ddlReportsSubMenu.SelectedIndex != 0)
        {
            if (ddlReportsSubMenu.SelectedValue == "")
            {
                generateDefaultReport("3", "1", "1"); //COST_CONTROL_DEV/CostSavingsY_TEST
            }
            else if (Convert.ToInt16(ddlReportsSubMenu.SelectedValue) == 5)  // D,E,J = 11,12,13   
                generateReport(10, false);
            else if (Convert.ToInt16(ddlReportsSubMenu.SelectedValue) == 6)  // D,E,J = 11,12,13   
                generateReport(11, false);
            else if (Convert.ToInt16(ddlReportsSubMenu.SelectedValue) == 7)  // D,E,J = 11,12,13 
                generateReport(12, false);
            else if (Convert.ToInt16(ddlReportsSubMenu.SelectedValue) == 8)  // D,E,J = 11,12,13   
                generateReport(13, false);
            else if (Convert.ToInt16(ddlReportsSubMenu.SelectedValue) == 99)  // D,E,J = 11,12,13   
                generateReport(0, false);
            else
                generateReport(0, false);

            //if (!ddlReportsSubMenu.SelectedValue.Equals(""))
            //{
            //    if (Convert.ToInt16(ddlReportsSubMenu.SelectedValue) >= 5)
            //    {
            //        //  fillDropDown();
            //        ddlYear.Visible = false;
            //    }
            //}
        }
    }

    #endregion

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        forCostControlWithKPIs();
    }


    private void ClearDDLItems()
    {
        ddlMinistry.Items.Clear();
        ddlMinistry.SelectedIndex = -1;
        ddlBudget.Items.Clear();
        ddlBudget.SelectedIndex = -1;
        ddlProv.Items.Clear();
        ddlProv.SelectedIndex = -1;
    }

    protected void ddlAffair_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlAffair.SelectedIndex != -1 && ddlAffair.SelectedIndex != 0)
        {
            string sqlQueryDept = "SELECT departmentID,deptName From Department where affairID = " + ddlAffair.SelectedValue + " and isActive=1 AND (affairID <> departmentID) " +
            "order by deptName";
            ddlDept.DataSource = null;
            PopulateDropDownBox(ddlDept, sqlQueryDept, "departmentID", "deptName");
            ddlDept.Enabled = true;
            ClearDDLItems();
        }
        else
        {
            ddlDept.Items.Clear();
            ddlDept.SelectedIndex = -1;
            ddlDept.Enabled = false;
            ClearDDLItems();
        }

        if (ddlAffair.SelectedIndex != 0)
            ddlDept.Enabled = true;

        ddlMinistry.DataSource = null;
        LoadMinistryCodes();

        ddlBudget.DataSource = null;
        LoadBudjetCodes();

        ddlProv.DataSource = null;
        LoadProvisionCodes();

        CheckFilter();
    }
    protected void ddlKPIYear_SelectedIndexChanged(object sender, EventArgs e)
    {
        forCostControlWithKPIs();
    }
    protected void ddldocStatus_SelectedIndexChanged(object sender, EventArgs e)
    {
        forCostControlWithKPIs();
    }
    protected void ddlContractNo_SelectedIndexChanged(object sender, EventArgs e)
    {
        forCostControlWithKPIs();
    }
    protected void ddlEmployee_SelectedIndexChanged(object sender, EventArgs e)
    {
        forCostControlWithKPIs();
    }
    protected void ddlDateRead_SelectedIndexChanged(object sender, EventArgs e)
    {
        forCostControlWithKPIs();
    }
    protected void btnClearTab1_Click(object sender, EventArgs e)
    {
        ResetTab1Controls();
    }
    protected void btnClearTab2_Click(object sender, EventArgs e)
    {
        ResetTab2Controls();
    }

    private void ResetTab1Controls()
    {
        txtStartDate.Text = "";
        txtEndDate.Text = "";
    }

    protected void txtStartDate_TextChanged(object sender, EventArgs e)
    {
        if (ddlReportsSubMenu.SelectedValue.Equals("42"))
        {
            if (txtStartDate.Text.Trim() != "")
            {
                txtEndDate.Text = "";
                generateReport(9, true);
            }
            else
            {
                generateReport(9, false);
            }
        }
        else
        {
            if (ddlReportsSubMenu.SelectedValue != "")
            {
                if (Convert.ToInt16(ddlReportsSubMenu.SelectedValue) == 60 || Convert.ToInt16(ddlReportsSubMenu.SelectedValue) == 62) // Business Dev Reports - PCC Strategy KPI Report  , Adoc and Cost Estimate - PCC Strategy KPI Report
                {
                    generateReport(0, false);
                }
                else if (!(Convert.ToInt16(ddlReportsSubMenu.SelectedValue) >= 40 && Convert.ToInt16(ddlReportsSubMenu.SelectedValue) <= 54) && Convert.ToInt16(ddlReportsSubMenu.SelectedValue) != 64)
                {
                    generateReport(13, false); // Affair,dept,budgetcode 
                }
                else if (!(Convert.ToInt16(ddlReportsSubMenu.SelectedValue) >= 40 && Convert.ToInt16(ddlReportsSubMenu.SelectedValue) <= 54) && Convert.ToInt16(ddlReportsSubMenu.SelectedValue) == 64)
                {
                    generateReport(0, false); // Affair,dept,budgetcode 
                }
                else
                {
                    generateReport(9, true);
                }
            }
            else
            {
                generateReport(9, true);
            }
        }
    }
    protected void txtEndDate_TextChanged(object sender, EventArgs e)
    {
        if (!(Convert.ToInt16(ddlReportsSubMenu.SelectedValue) >= 40 && Convert.ToInt16(ddlReportsSubMenu.SelectedValue) <= 54) && Convert.ToInt16(ddlReportsSubMenu.SelectedValue) != 64)
        {
            generateReport(13, false);
        }
        else if (!(Convert.ToInt16(ddlReportsSubMenu.SelectedValue) >= 40 && Convert.ToInt16(ddlReportsSubMenu.SelectedValue) <= 54) && Convert.ToInt16(ddlReportsSubMenu.SelectedValue) == 64)
        {
            generateReport(0, false);
        }
        else
        {
            generateReport(9, true);
        }
    }

    #endregion


    private string getMonthLastDate()
    {
        string monthEndDate = string.Empty;

        string sqlQuery = "SELECT CASE WHEN (YEAR(DATEADD(D,1,@endmonth)) > YEAR(@endmonth)) THEN @endmonth WHEN MONTH(DATEADD(D,1,@endmonth)) > MONTH(@endmonth) THEN " +
                       " @endmonth ELSE DATEADD(D,-1,DATEADD(M, DATEDIFF(M, 0, @endmonth), 0)) END endLastMonth";

        try
        {
            using (SqlConnection sqlCn = new SqlConnection(connValue))
            {
                sqlCn.Open();
                using (SqlCommand sqlCmd = new SqlCommand(sqlQuery, sqlCn))
                {
                    sqlCmd.Parameters.AddWithValue("@endmonth", Convert.ToDateTime(System.DateTime.Now.ToString()).ToString("dd/MMM/yyyy"));

                    using (SqlDataReader dr = sqlCmd.ExecuteReader())
                    {
                        while (dr.Read())
                        {
                            monthEndDate = Convert.ToDateTime(dr["endLastMonth"].ToString()).ToString("dd/MMM/yyyy");
                        }
                    }
                }
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
        return monthEndDate;
    }

}