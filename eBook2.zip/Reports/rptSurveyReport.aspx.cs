﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using Microsoft.Reporting.WebForms;
using System.Net;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using Datalayer;
public partial class Reports_rptSurveyReport : System.Web.UI.Page
{
    string connValue = ConfigurationManager.ConnectionStrings["EBSDEBookConn"].ToString();
    static string strRptURL = string.Empty;
    string strRptFilter = string.Empty;
    IList<string> userRightsColl = new List<string>();
    IList<string> rptColl = new List<string>();
    string rptName = string.Empty;          
    protected void Page_Load(object sender, EventArgs e)
    {
        userRightsColl = (IList<string>)Session["UserRightsColl"];
        strRptURL = getServerURL();
        if (!Page.IsPostBack)
        {
            genarateDefaultReport();          

            string sqlQueryMain = string.Empty;
            if (Session["UserProfileID"].ToString().Equals("1"))
            {
                sqlQueryMain = "select rptMainMenuID,rptMainMenuDescription from ReportsMainMenu where rptMainMenuID <> 0 and sectionID = 4 order by rptMainMenuID";
            }
            else if (!userRightsColl.Contains("24"))
                sqlQueryMain = "select rptMainMenuID,rptMainMenuDescription from ReportsMainMenu where rptMainMenuID <> 0 and sectionID = " + Convert.ToInt16(Session["SectionID"]) + " order by rptMainMenuID";
            else
                sqlQueryMain = "select rptMainMenuID,rptMainMenuDescription from ReportsMainMenu where rptMainMenuID not in(0,5,6) and sectionID = " + Convert.ToInt16(Session["SectionID"]) + " order by rptMainMenuID";

            PopulateDropDownBox(ddlReportsMainMenu, sqlQueryMain, "rptMainMenuID", "rptMainMenuDescription");

            string sqlQueryYear = "SELECT COUNT(jobID) AS jobCnt, YEAR(jobReceivedDate) AS Year FROM  Job WHERE (sectionID = 3) GROUP BY  YEAR(jobReceivedDate) ORDER BY Year DESC";
            
        }
    }
    private void genarateDefaultReport()
    {
        ServerReport serverReport = rptViewer.ServerReport;
        IReportServerCredentials irsc = new CustomReportCredentials(ConfigurationManager.AppSettings["userNameForReport"].ToString(), ConfigurationManager.AppSettings["passWordForReport"].ToString(),
        ConfigurationManager.AppSettings["domainName"].ToString());
        serverReport.ReportServerCredentials = irsc;
        rptViewer.ProcessingMode = ProcessingMode.Remote;
        serverReport.ReportServerUrl = new Uri(strRptURL);
        IList<string> strReportColl = GetReportParametersBySelectionDefault("8", "21", 0);
        serverReport.ReportPath = "/" + strReportColl[0] + "/" + strReportColl[1];

        CreateParametersForReport(strReportColl);

        this.rptViewer.ServerReport.Refresh();
    }
    private string CreateParametersForReport(IList<string> rptColl)
    {
        string rptName = string.Empty;
        rptName = "/" + rptColl[0] + "/" + rptColl[1];

        string[] parameterColl = rptColl[2].Split(',');
        foreach (var rptParameter in parameterColl)          // jobStatusID,contactID,jobUnread 
        {
            string val = null;

            if (rptParameter.Equals("StartDate"))
            {
                if (txtStartDate.Text != "")
                    val = txtStartDate.Text;
                else
                    val = "02/07/2017";
            }
            else if (rptParameter.Equals("EndDate"))
            {
                if (txtEndDate.Text != "")
                    val = txtEndDate.Text;
                else
                    val = "01/10/2017";
            }

            rptViewer.ServerReport.SetParameters(new ReportParameter(rptParameter, val, false));
        }
        return rptName;
    }
    private IList<string> GetReportParametersBySelectionDefault(string mainID, string subID, int filterID)
    {
        IList<string> strColl = null;
        try
        {
            using (SqlConnection cn = new SqlConnection(connValue))
            {
                string strQuery = "SELECT  r.reportID, r.moduleName, r.reportName, r.rptMainMenuID, r.rptSubMenuID, r.rptFilterID, r.parameters, r.createUser, r.createDate, r.updateUser, r.updateDate, " +
                       "  m.sectionID FROM Reports AS r INNER JOIN ReportsMainMenu AS m ON r.rptMainMenuID = m.rptMainMenuID INNER JOIN ReportsSubMenu AS s ON r.rptSubMenuID = s.rptSubMenuID INNER JOIN " +
                        " ReportsFilter AS f ON r.rptFilterID = f.rptfilterID WHERE (r.rptMainMenuID = @rptMainMenuID) AND (r.rptSubMenuID = @rptSubMenuID)";

                cn.Open();

                using (SqlCommand sqlCmd = new SqlCommand(strQuery, cn))
                {
                    sqlCmd.Parameters.AddWithValue("@rptMainMenuID", mainID);
                    sqlCmd.Parameters.AddWithValue("@rptSubMenuID", subID);
                    sqlCmd.Parameters.AddWithValue("@rptFilterID", filterID);

                    using (SqlDataReader sqlDtReader = sqlCmd.ExecuteReader())
                    {
                        if (sqlDtReader.Read())
                        {
                            strColl = new List<string>();
                            strColl.Add(sqlDtReader["moduleName"].ToString());
                            strColl.Add(sqlDtReader["reportName"].ToString());
                            strColl.Add(sqlDtReader["parameters"].ToString());
                        }
                    }
                }
            }
        }
        catch (Exception ex)
        {

        }
        return strColl;
    }
    protected void ddlReportsMainMenu_SelectedIndexChanged(object sender, EventArgs e)
    {   
        if (ddlReportsMainMenu.SelectedIndex !=0)
        {
            ddlReportsSubMenu.DataSource = null;
            string sqlQuery = "SELECT  rptSubMenuID, rptSubMenuDescription, sectionID, rptMainMenuID, isActive FROM ReportsSubMenu WHERE (rptMainMenuID = " + ddlReportsMainMenu.SelectedValue + ") ";
            PopulateDropDownBox(ddlReportsSubMenu, sqlQuery, "rptSubMenuID", "rptSubMenuDescription");
        }
        else if (ddlReportsMainMenu.SelectedValue == "5")
        {
            ddlReportsSubMenu.DataSource = null;
            string sqlQuery = "select rptSubMenuID,rptSubMenuDescription from ReportsSubMenu where rptSubMenuID >= 5 and sectionID =" + Convert.ToInt16(Session["SectionID"]) + "";
            PopulateDropDownBox(ddlReportsSubMenu, sqlQuery, "rptSubMenuID", "rptSubMenuDescription");
        }
        else if (ddlReportsMainMenu.SelectedValue == "6")
        {
            ddlReportsSubMenu.DataSource = null;
            string sqlQuery = "select rptSubMenuID,rptSubMenuDescription from ReportsSubMenu where rptSubMenuID < 5 and sectionID =" + Convert.ToInt16(Session["SectionID"]) + "";
            PopulateDropDownBox(ddlReportsSubMenu, sqlQuery, "rptSubMenuID", "rptSubMenuDescription");
        }
        else
        {
            ddlReportsSubMenu.DataSource = null;
            string sqlQuery = "select rptSubMenuID,rptSubMenuDescription from ReportsSubMenu where  sectionID = " + Convert.ToInt16(Session["SectionID"]) + "";
            PopulateDropDownBox(ddlReportsSubMenu, sqlQuery, "rptSubMenuID", "rptSubMenuDescription");
        }
    }

    private string getServerURL()
    {
        string strURL = string.Empty;
        try
        {
            string strQuery = "SELECT reportURL From ReportServer";
            using (SqlConnection conn = new SqlConnection(connValue))
            {
                conn.Open();

                SqlCommand sqlCmd = new SqlCommand(strQuery, conn);
                sqlCmd.CommandText = strQuery;
                sqlCmd.CommandType = CommandType.Text;
                sqlCmd.Connection = conn;
                using (SqlDataReader sqlDtReader = sqlCmd.ExecuteReader())
                {
                    while (sqlDtReader.Read())
                    {
                        strURL = sqlDtReader["reportURL"].ToString();
                    }
                }
            }
        }
        catch (Exception ex)
        {

        }

        return strURL;
    }

    private void PopulateDropDownBox(DropDownList ddlBox, string sqlQuery, string valueMember, string displayName)
    {
        ddlBox.DataBound += new EventHandler(this.ddlBox_DataBound);
        ddlBox.DataSource = new JobOrderData().FillDropdown(sqlQuery);
        ddlBox.DataTextField = displayName;
        ddlBox.DataValueField = valueMember;
        ddlBox.SelectedIndex = -1;
        ddlBox.DataBind();
    }
    protected void ddlBox_DataBound(object sender, EventArgs e)
    {
        DropDownList ddl = (DropDownList)sender;
        ListItem emptyItem = new ListItem("", "");
        ddl.Items.Insert(0, emptyItem);
    }
    public class CustomReportCredentials : IReportServerCredentials
    {
        private string _UserName;
        private string _PassWord;
        private string _DomainName;

        public CustomReportCredentials(string UserName, string PassWord, string DomainName)
        {
            _UserName = UserName;
            _PassWord = PassWord;
            _DomainName = DomainName;
        }

        public System.Security.Principal.WindowsIdentity ImpersonationUser
        {
            get { return null; }
        }

        public ICredentials NetworkCredentials
        {
            get { return new NetworkCredential(_UserName, _PassWord, _DomainName); }
        }

        public bool GetFormsCredentials(out Cookie authCookie, out string user,
         out string password, out string authority)
        {
            authCookie = null;
            user = password = authority = null;
            return false;
        }
    }

    protected void ddlReportsSubMenu_SelectedIndexChanged(object sender, EventArgs e)
    {
        ServerReport serverReport = rptViewer.ServerReport;
        IReportServerCredentials irsc = new CustomReportCredentials(ConfigurationManager.AppSettings["userNameForReport"].ToString(), ConfigurationManager.AppSettings["passWordForReport"].ToString(),
        ConfigurationManager.AppSettings["domainName"].ToString());
        serverReport.ReportServerCredentials = irsc;
        rptViewer.ProcessingMode = ProcessingMode.Remote;
        serverReport.ReportServerUrl = new Uri(strRptURL);
        IList<string> strReportColl = GetReportParametersBySelectionDefault(ddlReportsMainMenu.SelectedValue, ddlReportsSubMenu.SelectedValue, 0);
        serverReport.ReportPath = "/" + strReportColl[0] + "/" + strReportColl[1];

        CreateParametersForReport(strReportColl);

        this.rptViewer.ServerReport.Refresh();
    }
    protected void txtEndDate_TextChanged(object sender, EventArgs e)
    {
        genarateDefaultReport();
    }
}