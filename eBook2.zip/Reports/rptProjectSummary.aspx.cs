﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using Microsoft.Reporting.WebForms;
using System.Data.SqlClient;
using System.Data;

using System.Net;
using Datalayer;

public partial class Reports_rptProjectSummary : System.Web.UI.Page
{
    string connValue = ConfigurationManager.ConnectionStrings["EBSDEBookConn"].ToString();
    string CommitmentNo = string.Empty;
    protected void Page_Load(object sender, EventArgs e)
    {
        CommitmentNo = Session["CntrNo"].ToString();
       
        if (!IsPostBack)
        {
            TestReport();
           
            //prjSummary();
        }
    }
    private void prjSummary()
    {
        string strRptURL = getServerURL();
        ServerReport serverReport = rptViewer.ServerReport;
        IReportServerCredentials irsc = new CustomReportCredentials(ConfigurationManager.AppSettings["userNameForReport"].ToString(), ConfigurationManager.AppSettings["passWordForReport"].ToString(),
        ConfigurationManager.AppSettings["domainName"].ToString());
        serverReport.ReportServerCredentials = irsc;
        rptViewer.ProcessingMode = ProcessingMode.Remote;
        serverReport.ReportServerUrl = new Uri(strRptURL);

        string strRptFilter = "Blank";
        IList<string> rptColl = GetReportParameters(strRptFilter, 6, 14, 0);
        serverReport.ReportPath = "/" + rptColl[0] + "/" + rptColl[1];

        rptViewer.ServerReport.SetParameters(new ReportParameter("CommitmentNo", CommitmentNo, false));

        this.rptViewer.ServerReport.Refresh();
    }
    private void TestReport()
    {
        string strRptURL = getServerURL();
        ServerReport serverReport = rptViewer.ServerReport;
        IReportServerCredentials irsc = new CustomReportCredentials(ConfigurationManager.AppSettings["userNameForReport"].ToString(), ConfigurationManager.AppSettings["passWordForReport"].ToString(),
        ConfigurationManager.AppSettings["domainName"].ToString());
        serverReport.ReportServerCredentials = irsc;
        rptViewer.ProcessingMode = ProcessingMode.Remote;
        serverReport.ReportServerUrl = new Uri(strRptURL);

        string strRptFilter = "Blank";
        IList<string> rptColl = GetReportParameters(strRptFilter, 5, 99, 0);
        serverReport.ReportPath = "/" + rptColl[0] + "/" + rptColl[1];

        rptViewer.ServerReport.SetParameters(new ReportParameter("Year", "2017", false));

        this.rptViewer.ServerReport.Refresh();
    }
    private IList<string> GetReportParameters(string filterName, int mainID, int subID, int filterID)
    {
        IList<string> strColl = null;
        try
        {
            //string strQuery = "SELECT r.* FROM Reports r,ReportsFilter f,ReportsMainMenu m,ReportsSubMenu s WHERE r.rptMainMenuID = m.rptMainMenuID AND r.rptSubMenuID = s.rptSubMenuID AND r.rptFilterID = f.rptfilterID AND " +
            //    "  r.rptMainMenuID = @rptMainMenuID and r.rptSubMenuID = @rptSubMenuID";

            string strQuery = "SELECT reportID, moduleName, reportName, rptMainMenuID, rptSubMenuID, rptFilterID, parameters, createUser, createDate, updateUser, updateDate" +
                               " FROM Reports AS r WHERE (rptMainMenuID = @rptMainMenuID) AND (rptSubMenuID = @rptSubMenuID)";

                SqlConnection cn = new SqlConnection(connValue);
                cn.Open();
                SqlCommand sqlCmd = new SqlCommand(strQuery, cn);
                sqlCmd.Parameters.AddWithValue("@rptMainMenuID", mainID);
                sqlCmd.Parameters.AddWithValue("@rptSubMenuID", subID);
                sqlCmd.Parameters.AddWithValue("@rptFilterID", filterID);
                SqlDataReader sqlDtReader = sqlCmd.ExecuteReader();

                if (sqlDtReader.Read())
                {
                    strColl = new List<string>();
                    strColl.Add(sqlDtReader["moduleName"].ToString());
                    strColl.Add(sqlDtReader["reportName"].ToString());
                    strColl.Add(sqlDtReader["parameters"].ToString());
                } 
        }
        catch (Exception ex)
        {

        }
        return strColl;
    }

    protected void btnBack_Click(object sender, EventArgs e)
    {
        Response.Redirect(Session["PrevPage"].ToString(), false);
    }

    #region MyRegion
    


    private string getServerURL()
    {
        string strURL = string.Empty;
        try
        {
            string strQuery = "SELECT reportURL From ReportServer";
            using (SqlConnection conn = new SqlConnection(connValue))
            {
                conn.Open();

                SqlCommand sqlCmd = new SqlCommand(strQuery, conn);
                sqlCmd.CommandText = strQuery;
                sqlCmd.CommandType = CommandType.Text;
                sqlCmd.Connection = conn;
                using (SqlDataReader sqlDtReader = sqlCmd.ExecuteReader())
                {
                    while (sqlDtReader.Read())
                    {
                        strURL = sqlDtReader["reportURL"].ToString();
                    }
                }
            }
        }
        catch (Exception ex)
        {
        }

        return strURL;
    }

    public class CustomReportCredentials : IReportServerCredentials
    {
        private string _UserName;
        private string _PassWord;
        private string _DomainName;

        public CustomReportCredentials(string UserName, string PassWord, string DomainName)
        {
            _UserName = UserName;
            _PassWord = PassWord;
            _DomainName = DomainName;
        }

        public System.Security.Principal.WindowsIdentity ImpersonationUser
        {
            get { return null; }
        }

        public ICredentials NetworkCredentials
        {
            get { return new NetworkCredential(_UserName, _PassWord, _DomainName); }
        }

        public bool GetFormsCredentials(out Cookie authCookie, out string user,
         out string password, out string authority)
        {
            authCookie = null;
            user = password = authority = null;
            return false;
        }
    }


    #endregion
    
}