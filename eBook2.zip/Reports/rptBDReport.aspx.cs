﻿using Datalayer;
using Microsoft.Reporting.WebForms;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Reports_rptBDReport : System.Web.UI.Page
{
    string connValue = ConfigurationManager.ConnectionStrings["EBSDEBookConn"].ToString();  
    IList<string> userRightsColl = new List<string>();
    static string strRptURL = string.Empty;

    #region MyRegion
    
   
    protected void Page_Load(object sender, EventArgs e)
    { 
         
        if (Session["userProfileID"] != null)
        {
            if (!Page.IsPostBack)
            {
                userRightsColl = (IList<string>)Session["UserRightsColl"];
                strRptURL = getServerURL();

                string sqlQueryMain = string.Empty;

                if (Session["userProfileID"].ToString().Equals("1"))
                {
                    sqlQueryMain = "select rptMainMenuID,rptMainMenuDescription from ReportsMainMenu where rptMainMenuID <> 0 and sectionID =9 order by rptMainMenuID";
                }
                else
                {
                    //if (!userRightsColl.Contains("24"))
                    //    sqlQueryMain = "select rptMainMenuID,rptMainMenuDescription from ReportsMainMenu where rptMainMenuID <> 0 and sectionID = " + Convert.ToInt16(Session["SectionID"]) + " order by rptMainMenuID";
                    //else
                    sqlQueryMain = "select rptMainMenuID,rptMainMenuDescription from ReportsMainMenu where rptMainMenuID <> 0 and sectionID = " + Convert.ToInt16(Session["SectionID"]) + " order by rptMainMenuID";
                }

                txtStartDate.Text = "01/Jan/" + DateTime.Now.Year; // ToString("dd/MMM/yyyy");
                generateDefaultReport("10", "38");
                PopulateDropDownBox(ddlReportsMainMenu, sqlQueryMain, "rptMainMenuID", "rptMainMenuDescription");
                ddlReportsSubMenu.Enabled = false;               
                
                   
                
                //PopulateDropDownBox(ddlServiceType, "select serviceTypeID,serviceTypeDescription from ServiceType", "serviceTypeID", "serviceTypeDescription");
                //PopulateDropDownBox(ddlStatus, "select jobStatusID,jobStatusName from JobStatus", "jobStatusID", "jobStatusName");
                //PopulateDropDownBox(ddlAssign, "select distinct contactID,empName from EBDServiceRequests order by empName", "contactID", "empName");
            }
        }        
        else
        {
            Response.Redirect("~/LoginPage.aspx", false);
        }
    }

    private void generateDefaultReport(string mainID, string subID)
    {
        try
        {
            ServerReport serverReport = rptViewer.ServerReport;
            IReportServerCredentials irsc = new CustomReportCredentials(ConfigurationManager.AppSettings["userNameForReport"].ToString(), ConfigurationManager.AppSettings["passWordForReport"].ToString(),
            ConfigurationManager.AppSettings["domainName"].ToString());
            serverReport.ReportServerCredentials = irsc;
            rptViewer.ProcessingMode = ProcessingMode.Remote;
            serverReport.ReportServerUrl = new Uri(strRptURL);
            // 9 & 23 equals to MgmtSummary_TEST reportName
            IList<string> strReportColl = null;
             
            //tblMoreInfo.Visible = false;
            //tblJobNoInfo.Visible = true;
            strReportColl = GetReportParametersBySelectionDefault(mainID, subID);
            serverReport.ReportPath = "/" + strReportColl[0] + "/" + strReportColl[1];
            CreateParametersForReport(strReportColl, true);            

            this.rptViewer.ServerReport.Refresh();
        }
        catch (Exception ex)
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('" + ex.Message.Replace("'", "") + "')</script>", false);
        }

    }

    private void CreateParametersForReport(IList<string> rptColl, bool isJobNo)
    {       

        string[] parameterColl = rptColl[2].Split(',');
         
        foreach (var rptParameter in parameterColl)          // jobStatusID,contactID,jobUnread 
        {
            string val = null;

            if (rptParameter.Equals("StartDate"))
            {
                if (txtStartDate.Text != "")
                    val = txtStartDate.Text;               


            }
            else if (rptParameter.Equals("EndDate"))
            {
                if (txtEndDate.Text != "")
                    val = txtEndDate.Text;
                //else
                //    val = Convert.ToDateTime(DateTime.Now.ToString()).ToString("dd/MMM/yyyy");
            }
            //else if (rptParameter.Equals("ServiceType"))
            //{
            //    if (ddlServiceType.SelectedValue.ToString() != "")
            //        val = ddlServiceType.SelectedValue;
            //}
            //else if (rptParameter.Equals("SystemType"))
            //{
            //    if (ddlServiceSubType.SelectedValue.ToString() != "")
            //        val = ddlServiceSubType.SelectedValue;
            //}                
            //else if (rptParameter.Equals("JobStatus"))
            //{
            //    if (ddlStatus.SelectedValue.ToString() != "")
            //        val = ddlStatus.SelectedValue;
            //}
            //else if (rptParameter.Equals("ActionBy"))
            //{
            //    if (ddlAssign.SelectedValue.ToString() != "")
            //        val = ddlAssign.SelectedValue;
            //}
                
            rptViewer.ServerReport.SetParameters(new ReportParameter(rptParameter, val, false));
        }        
         
    }

    private void OnChangeEvent()
    {
        if (Session["userProfileID"] != null)
        {
            if (ddlReportsMainMenu.SelectedValue == "" && ddlReportsSubMenu.SelectedValue == "")
            {
                generateDefaultReport("10", "38");
            }
            else if (ddlReportsMainMenu.SelectedValue != "" && ddlReportsSubMenu.SelectedValue == "")
            {
                generateDefaultReport(ddlReportsMainMenu.SelectedValue, "38");
            }
            else if (ddlReportsMainMenu.SelectedValue == "" && ddlReportsSubMenu.SelectedValue != "")
            {
                generateDefaultReport("10", ddlReportsSubMenu.SelectedValue);
            }
            else
            {
                generateDefaultReport(ddlReportsMainMenu.SelectedValue, ddlReportsSubMenu.SelectedValue);
            }
        }
        else
        {
            Response.Redirect("~/LoginPage.aspx", false);
        }
    }

    public class CustomReportCredentials : IReportServerCredentials
    {
        private string _UserName;
        private string _PassWord;
        private string _DomainName;

        public CustomReportCredentials(string UserName, string PassWord, string DomainName)
        {
            _UserName = UserName;
            _PassWord = PassWord;
            _DomainName = DomainName;
        }

        public System.Security.Principal.WindowsIdentity ImpersonationUser
        {
            get { return null; }
        }

        public ICredentials NetworkCredentials
        {
            get { return new NetworkCredential(_UserName, _PassWord, _DomainName); }
        }

        public bool GetFormsCredentials(out Cookie authCookie, out string user,
         out string password, out string authority)
        {
            authCookie = null;
            user = password = authority = null;
            return false;
        }
    }

    private IList<string> GetReportParametersBySelectionDefault(string mainID, string subID)
    {
        IList<string> strColl = null;
        try
        {
            using (SqlConnection cn = new SqlConnection(connValue))
            {
                string strQuery = "SELECT  r.reportID, r.moduleName, r.reportName, r.rptMainMenuID, r.rptSubMenuID, r.rptFilterID, r.parameters, r.createUser, r.createDate, r.updateUser, r.updateDate, " +
                "  m.sectionID FROM Reports AS r INNER JOIN ReportsMainMenu AS m ON r.rptMainMenuID = m.rptMainMenuID INNER JOIN ReportsSubMenu AS s ON r.rptSubMenuID = s.rptSubMenuID " +
                "  WHERE (r.rptMainMenuID = @rptMainMenuID) AND (r.rptSubMenuID = @rptSubMenuID)";

                cn.Open();

                using (SqlCommand sqlCmd = new SqlCommand(strQuery, cn))
                {
                    sqlCmd.Parameters.AddWithValue("@rptMainMenuID", mainID);
                    sqlCmd.Parameters.AddWithValue("@rptSubMenuID", subID);
                    //sqlCmd.Parameters.AddWithValue("@rptFilterID", filterID);

                    using (SqlDataReader sqlDtReader = sqlCmd.ExecuteReader())
                    {
                        if (sqlDtReader.Read())
                        {
                            strColl = new List<string>();
                            strColl.Add(sqlDtReader["moduleName"].ToString());
                            strColl.Add(sqlDtReader["reportName"].ToString());
                            strColl.Add(sqlDtReader["parameters"].ToString());
                        }
                    }
                }
            }
        }
        catch (Exception ex)
        {

        }
        return strColl;
    }

    private string getServerURL()
    {
        string strURL = string.Empty;
        try
        {
            string strQuery = "SELECT reportURL From ReportServer";
            using (SqlConnection conn = new SqlConnection(connValue))
            {
                conn.Open();

                SqlCommand sqlCmd = new SqlCommand(strQuery, conn);
                sqlCmd.CommandText = strQuery;
                sqlCmd.CommandType = CommandType.Text;
                sqlCmd.Connection = conn;
                using (SqlDataReader sqlDtReader = sqlCmd.ExecuteReader())
                {
                    while (sqlDtReader.Read())
                    {
                        strURL = sqlDtReader["reportURL"].ToString();
                    }
                }
            }
        }
        catch (Exception ex)
        {

        }

        return strURL;
    }

    private void PopulateDropDownBox(DropDownList ddlBox, string sqlQuery, string valueMember, string displayName)
    {
        ddlBox.DataBound += new EventHandler(this.ddlBox_DataBound);
        ddlBox.DataSource = new JobOrderData().FillDropdown(sqlQuery);
        ddlBox.DataTextField = displayName;
        ddlBox.DataValueField = valueMember;
        ddlBox.SelectedIndex = -1;
        ddlBox.DataBind();
    }

    protected void ddlBox_DataBound(object sender, EventArgs e)
    {
        DropDownList ddl = (DropDownList)sender;
        ListItem emptyItem = new ListItem("", "");
        ddl.Items.Insert(0, emptyItem);
    }

    protected void btnClear_Click(object sender, EventArgs e)
    {
        //ddlServiceSubType.Items.Clear();
        //ddlServiceSubType.Enabled = false;
        //ddlServiceType.SelectedIndex = -1;
        //ddlAssign.SelectedIndex = -1;
        txtStartDate.Text = "";
        txtEndDate.Text = "";
        //ddlStatus.SelectedIndex = -1;        
    }
    protected void ddlServiceType_SelectedIndexChanged(object sender, EventArgs e)
    {
        //if (ddlServiceType.SelectedIndex != -1 && ddlServiceType.SelectedIndex != 0)
        //{
        //    string sqlQueryDept = "SELECT serviceTypeSystemID,serviceTypeSystem From ServiceTypeSubCategory where serviceTypeID = " + ddlServiceType.SelectedValue + " order by serviceTypeSystemID";
        //    ddlServiceSubType.DataSource = null;
        //    PopulateDropDownBox(ddlServiceSubType, sqlQueryDept, "serviceTypeSystemID", "serviceTypeSystem");
        //    ddlServiceSubType.Enabled = true;            
        //}
        //else
        //{
        //    ddlServiceSubType.Items.Clear();
        //    ddlServiceSubType.SelectedIndex = -1;
        //    ddlServiceSubType.Enabled = false;             
        //}
        OnChangeEvent();
    }

    private void ClearDDLItems()
    {
        //ddlServiceType.SelectedIndex = -1;
        //ddlServiceSubType.SelectedIndex = -1;
        //ddlAssign.SelectedIndex = -1;
        txtStartDate.Text = "";
        txtEndDate.Text = "";
        //ddlStatus.SelectedIndex = -1;       
    }

    protected void ddlServiceSubType_SelectedIndexChanged(object sender, EventArgs e)
    {
        OnChangeEvent();
    }
    protected void ddlAssign_SelectedIndexChanged(object sender, EventArgs e)
    {
        OnChangeEvent();
    }
    protected void txtStartDate_TextChanged(object sender, EventArgs e)
    {
        OnChangeEvent();
    }
    protected void txtEndDate_TextChanged(object sender, EventArgs e)
    {
        OnChangeEvent();
    }
    protected void ddlStatus_SelectedIndexChanged(object sender, EventArgs e)
    {
        OnChangeEvent();
    }
     

    private void Reset(bool isBlank)
    {
        if (isBlank)
        {
            ddlReportsMainMenu.SelectedIndex = -1;
            ddlReportsSubMenu.SelectedIndex = -1;
            ddlReportsSubMenu.DataSource = null;
            ddlReportsSubMenu.Enabled = false;
        }
        else
        {
            ddlReportsSubMenu.Enabled = true;
        }
        //tblJobNoInfo.Visible = false;
        //tblMoreInfo.Visible = false;
        ClearDDLItems();
        //generateDefaultReport("9", "23");
    }

    protected void ddlReportsMainMenu_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (!Session["userProfileID"].ToString().Equals("1"))
        {
            if (ddlReportsMainMenu.SelectedValue != "")
            {
                ddlReportsSubMenu.DataSource = null;
                string sqlQuery = "select rptSubMenuID,rptSubMenuDescription from ReportsSubMenu where rptMainMenuID=" + ddlReportsMainMenu.SelectedValue + " and sectionID =" + Convert.ToInt16(Session["SectionID"]) + " AND (isActive = 1)";
                PopulateDropDownBox(ddlReportsSubMenu, sqlQuery, "rptSubMenuID", "rptSubMenuDescription");
                ddlReportsSubMenu.Enabled = true;
                Reset(false);
            }
            else if (ddlReportsMainMenu.SelectedValue == "")
            {
                Reset(true);
            }
        }
        else
        {
            if (ddlReportsMainMenu.SelectedValue != "")
            {
                ddlReportsSubMenu.DataSource = null;
                string sqlQuery = "select rptSubMenuID,rptSubMenuDescription from ReportsSubMenu where rptMainMenuID=" + ddlReportsMainMenu.SelectedValue + " AND (isActive = 1)";
                PopulateDropDownBox(ddlReportsSubMenu, sqlQuery, "rptSubMenuID", "rptSubMenuDescription");
                ddlReportsSubMenu.Enabled = true;
                Reset(false);
            }
            else if (ddlReportsMainMenu.SelectedValue == "")
            {
                Reset(true);
            }
        }       
        
    }
    protected void ddlReportsSubMenu_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlReportsSubMenu.SelectedValue != "")
        {
            ClearDDLItems();
            txtStartDate.Text = "01/Jan/" + DateTime.Now.Year;
            OnChangeEvent();            
        }
        else
        {
            Reset(true);            
        }      
         
    }

    #endregion
}