﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using Microsoft.Reporting.WebForms;
using System.Net;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using Datalayer;
public partial class Reports_rptDocumentReports : System.Web.UI.Page
{
    string connValue = ConfigurationManager.ConnectionStrings["EBSDEBookConn"].ToString();
    static string strRptURL = string.Empty;
    string strRptFilter = string.Empty;
    IList<string> userRightsColl = new List<string>();
    IList<string> rptColl = new List<string>();
    string rptName = string.Empty;


    #region MyRegion



    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["userProfileID"] != null)
        {
            if (!Page.IsPostBack)
            {
                userRightsColl = (IList<string>)Session["UserRightsColl"];
                strRptURL = getServerURL();
                string sqlQueryMain = string.Empty;
                string sqlQueryYear = string.Empty;
                generateReport("7", "16");
                ddlReportsSubMenu.Enabled = false;
                ddlMonth.Enabled = false;
                sqlQueryYear = "SELECT COUNT(jobID) AS jobCnt, YEAR(jobReceivedDate) AS Year FROM  Job GROUP BY  YEAR(jobReceivedDate) ORDER BY Year DESC";
               
                if (Session["userProfileID"].ToString().Equals("1"))
                {
                    sqlQueryMain = "select rptMainMenuID,rptMainMenuDescription from ReportsMainMenu where rptMainMenuID <> 0 and sectionID=3 order by rptMainMenuID";                   
                }
                else if (!userRightsColl.Contains("36"))                 // 36- View REPORTS DC Control Section
                {
                    sqlQueryMain = "select rptMainMenuID,rptMainMenuDescription from ReportsMainMenu where rptMainMenuID <> 0 and sectionID=3 order by rptMainMenuID";
                }
                else
                {
                    if (!userRightsColl.Contains("24"))
                        sqlQueryMain = "select rptMainMenuID,rptMainMenuDescription from ReportsMainMenu where rptMainMenuID <> 0 and sectionID = " + Convert.ToInt16(Session["SectionID"]) + " order by rptMainMenuID";
                    else
                        sqlQueryMain = "select rptMainMenuID,rptMainMenuDescription from ReportsMainMenu where rptMainMenuID not in(0,5,6) and sectionID = " + Convert.ToInt16(Session["SectionID"]) + " order by rptMainMenuID";
                }

                tblJobs.Visible = false;
                //tblKPI.Visible = false;  
                PopulateDropDownBox(ddlReportsMainMenu, sqlQueryMain, "rptMainMenuID", "rptMainMenuDescription");
                PopulateDropDownBox(ddlYear, sqlQueryYear, "Year", "Year");
            }
        }
        else
        {
            Response.Redirect("~/LoginPage.aspx", false);
        }
    }
    protected void ddlReportsMainMenu_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (Session["userProfileID"] != null)
        {
            //if (Convert.ToInt16(ddlReportsMainMenu.SelectedIndex) == 7)
            //{
            //    //tblKPI.Visible = false;
            //    tblJobs.Visible = true;

            //    //fillDropDowns();
            //}      
            //else
            //{
            if (ddlReportsMainMenu.SelectedValue != "")
            {
                string strAffair = "SELECT  COUNT(Job.jobID) AS jobCnt, Department_1.deptName AS AffairName, Department_1.departmentID AS AffairID FROM  JobVOSI INNER JOIN  Job ON JobVOSI.jobID = Job.jobID INNER JOIN " +
                       " JobType ON Job.jobTypeID = JobType.jobTypeID INNER JOIN   Department ON Job.deptID = Department.departmentID INNER JOIN   Department AS Department_1 ON Department.affairID = Department_1.departmentID " +
                         " WHERE   (JobType.CategoryID IN (4)) GROUP BY Department_1.deptName, Department_1.departmentID ORDER BY AffairName";

                PopulateDropDownBox(ddlAffair, strAffair, "AffairID", "AffairName");
                //}

                if (Session["userProfileID"].ToString().Equals("1") || (!userRightsColl.Contains("36")))
                {
                    if (ddlReportsMainMenu.SelectedValue != "")
                    {
                        ddlReportsSubMenu.DataSource = null;
                        ddlReportsSubMenu.Enabled = true;
                        string sqlQuery = "select rptSubMenuID,rptSubMenuDescription from ReportsSubMenu where rptMainMenuID=" + ddlReportsMainMenu.SelectedValue + " AND (isActive = 1)";
                        PopulateDropDownBox(ddlReportsSubMenu, sqlQuery, "rptSubMenuID", "rptSubMenuDescription");
                    }                    
                }
                else
                {
                    ddlReportsSubMenu.Enabled = true;
                    if (ddlReportsMainMenu.SelectedValue != "")
                    {
                        ddlReportsSubMenu.DataSource = null;
                        string sqlQuery = "select rptSubMenuID,rptSubMenuDescription from ReportsSubMenu where rptMainMenuID=" + ddlReportsMainMenu.SelectedValue + " and sectionID =" + Convert.ToInt16(Session["SectionID"]) + " AND (isActive = 1)";
                        PopulateDropDownBox(ddlReportsSubMenu, sqlQuery, "rptSubMenuID", "rptSubMenuDescription");
                    }
                    else
                    {
                        ddlReportsSubMenu.DataSource = null;
                        string sqlQuery = "select rptSubMenuID,rptSubMenuDescription from ReportsSubMenu where  sectionID = " + Convert.ToInt16(Session["SectionID"]) + " AND (isActive = 1)";
                        PopulateDropDownBox(ddlReportsSubMenu, sqlQuery, "rptSubMenuID", "rptSubMenuDescription");
                    }
                }
                Reset(false);
            }
            else
            {
                Reset(true);
            }
        }
        else
        {
            Response.Redirect("~/LoginPage.aspx", false);
        }
    }


    //private void fillDropDowns()
    //{


    //    // WHERE (JobType.CategoryID IN (4))

    //    string strMinistry = "SELECT Job.ministryCode FROM  JobVOSI INNER JOIN   Job ON JobVOSI.jobID = Job.jobID INNER JOIN JobType ON Job.jobTypeID = JobType.jobTypeID GROUP BY Job.ministryCode HAVING (Job.ministryCode IS NOT NULL)";
    //    PopulateDropDownBox(ddlMinistry, strMinistry, "ministryCode", "ministryCode");

    //    string strBudRef = "SELECT Job.budgetRefNo  FROM  JobVOSI INNER JOIN   Job ON JobVOSI.jobID = Job.jobID INNER JOIN JobType ON Job.jobTypeID = JobType.jobTypeID GROUP BY Job.budgetRefNo  HAVING (Job.budgetRefNo  IS NOT NULL)";
    //    PopulateDropDownBox(ddlBudget, strBudRef, "budgetRefNo", "budgetRefNo");

    //    string strProvision = "SELECT Job.provisionNo  FROM  JobVOSI INNER JOIN   Job ON JobVOSI.jobID = Job.jobID INNER JOIN JobType ON Job.jobTypeID = JobType.jobTypeID GROUP BY Job.provisionNo  HAVING (Job.provisionNo  IS NOT NULL)";
    //    PopulateDropDownBox(ddlProv, strProvision, "provisionNo", "provisionNo");
    //}


    private void generateReport(string mainID, string subID)
    {
        try
        {
            ServerReport serverReport = rptViewer.ServerReport;
            IReportServerCredentials irsc = new CustomReportCredentials(ConfigurationManager.AppSettings["userNameForReport"].ToString(), ConfigurationManager.AppSettings["passWordForReport"].ToString(),
            ConfigurationManager.AppSettings["domainName"].ToString());
            serverReport.ReportServerCredentials = irsc;
            rptViewer.ProcessingMode = ProcessingMode.Remote;
            serverReport.ReportServerUrl = new Uri(strRptURL);

            IList<string> strReportColl = GetReportParametersBySelection(mainID, subID);

            if (strReportColl == null)
                return;

            serverReport.ReportPath = "/" + strReportColl[0] + "/" + strReportColl[1];

            if (ddlReportsSubMenu.SelectedValue == "")
            {
                CreateParametersForReport(strReportColl);
            }
            else if (!(Convert.ToInt16(ddlReportsSubMenu.SelectedValue) >= 6 && Convert.ToInt16(ddlReportsSubMenu.SelectedValue) <= 8))
            {
                CreateParametersForReport(strReportColl);
            }

            this.rptViewer.ServerReport.Refresh();
        }
        catch (Exception ex)
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('" + ex.Message + "')</script>", false);
        }
    }
    protected void ddlReportsSubMenu_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlReportsSubMenu.SelectedValue != "")
        {
            if (Session["userProfileID"] != null)
            {
                Reset(false);
                if (Convert.ToInt16(ddlReportsSubMenu.SelectedValue) >= 6 && Convert.ToInt16(ddlReportsSubMenu.SelectedValue) <= 8)       //Adoc and Cost Estimate
                {
                    //tblJobs.Visible = true;
                    //tblKPI.Visible = false;
                    //tblKPI.Visible = true;
                    tblJobs.Visible = false;
                    //fillDropDowns();
                }
                else
                {
                    //tblKPI.Visible = true;
                    //tblJobs.Visible = false;
                    //tblKPI.Visible = false;
                    tblJobs.Visible = true;
                }

                //if (Convert.ToInt16(ddlReportsSubMenu.SelectedValue) == 5)  // D,E,J = 11,12,13  
                //    generateReport(); 
                //else if (Convert.ToInt16(ddlReportsSubMenu.SelectedValue) == 6)  // D,E,J = 11,12,13   
                //    generateReport();
                //else if (Convert.ToInt16(ddlReportsSubMenu.SelectedValue) == 7)  // D,E,J = 11,12,13 
                //    generateReport();
                //else if (Convert.ToInt16(ddlReportsSubMenu.SelectedValue) == 8)  // D,E,J = 11,12,13   
                //    generateReport();
                //else if (Convert.ToInt16(ddlReportsSubMenu.SelectedValue) == 99)  // D,E,J = 11,12,13   
                //    generateReport();
                //else
                //generateReport();

                //if (Convert.ToInt16(ddlReportsSubMenu.SelectedValue) > 5)
                //{
                //    fillDropDown();                    
                //    ddlYear.Visible = false;
                //}
                //else
                //{

                //}


                if (ddlReportsSubMenu.SelectedIndex == 0)  // D,E,J = 11,12,13  
                {
                    //ddlYear.SelectedIndex = 0;
                    generateReport(ddlReportsMainMenu.SelectedValue, "16");
                }
                else
                {
                    generateReport(ddlReportsMainMenu.SelectedValue, ddlReportsSubMenu.SelectedValue);
                }

            }
            else
            {
                Response.Redirect("~/LoginPage.aspx", false);
            }
        }
        else
        {
            Reset(true);
        }



    }
    private void Reset(bool isItemBlank)
    {
        ddlYear.SelectedIndex = 0;
        ddlMonth.Enabled = false;
        ddlMonth.SelectedIndex = -1;
        ddlDept.Items.Clear();
        ddlDept.Enabled = false;
        ddlAffair.SelectedIndex = 0;

        if (isItemBlank)
        {
            ddlReportsMainMenu.SelectedIndex = -1;
            ddlReportsSubMenu.DataSource = null;
            ddlReportsSubMenu.SelectedIndex = -1;
            ddlReportsSubMenu.Enabled = false;
            generateReport("7", "16");
        }
        else
        {
            //ddlReportsSubMenu.SelectedIndex = -1;
            //ddlReportsSubMenu.DataSource = null;
            ddlReportsSubMenu.Enabled = true;
            if (ddlAffair.SelectedIndex != -1)
            {
                ddlAffair.SelectedIndex = 0;
            }
            else if (ddlAffair.SelectedIndex != -1)
            {
                ddlDept.Enabled = false;
            }
            generateReport(ddlReportsMainMenu.SelectedValue, ddlReportsSubMenu.SelectedValue);
        }

    }
    protected void ddlYear_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlReportsSubMenu.SelectedIndex == 0)  // D,E,J = 11,12,13                     
            return;

        if (ddlYear.SelectedIndex == 0)
        {
            ddlMonth.Enabled = false;
            ddlMonth.SelectedIndex = 0;
        }
        else
            ddlMonth.Enabled = true;

        //ddlMinistry.DataSource = null;
        //LoadMinistryCodes();

        //ddlBudget.DataSource = null;
        //LoadBudjetCodes();

        //ddlProv.DataSource = null;
        //LoadProvisionCodes();

        generateReport(ddlReportsMainMenu.SelectedValue, ddlReportsSubMenu.SelectedValue);
    }
    protected void ddlAffair_SelectedIndexChanged(object sender, EventArgs e)
    {

        if (ddlAffair.SelectedIndex != 0)
        {
            string sqlQueryDept = "SELECT  departmentID,deptName From Department where affairID = " + ddlAffair.SelectedValue + "";
            ddlDept.DataSource = null;
            PopulateDropDownBox(ddlDept, sqlQueryDept, "departmentID", "deptName");
            ddlDept.Enabled = true;
        }

        if (ddlAffair.SelectedIndex != 0)
            ddlDept.Enabled = true;

        if (ddlAffair.SelectedValue == "")
        {
            ddlDept.Items.Clear();
            ddlDept.SelectedIndex = -1;
            ddlDept.Enabled = false;
        }

        //ddlMinistry.DataSource = null;
        //LoadMinistryCodes();

        //ddlBudget.DataSource = null;
        //LoadBudjetCodes();

        //ddlProv.DataSource = null;
        //LoadProvisionCodes();


        generateReport(ddlReportsMainMenu.SelectedValue, ddlReportsSubMenu.SelectedValue);

    }
    private DataTable getMinistryData()
    {
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        try
        {
            string strYaer = string.Empty;
            if (ddlYear.SelectedIndex != 0)
                strYaer = ddlYear.Text;

            Int16 afrID;
            Int16.TryParse(ddlAffair.SelectedValue, out afrID);

            Int16 deptID;
            Int16.TryParse(ddlDept.SelectedValue, out deptID);

            //string strMinCode = string.Empty;
            //if (ddlMinistry.SelectedIndex != 0)
            //    strMinCode = ddlMinistry.SelectedValue;

            //string strBudCode = string.Empty;
            //if (ddlBudget.SelectedIndex != 0)
            //    strBudCode = ddlBudget.SelectedValue;

            //string strProvCode = string.Empty;
            //if (ddlProv.SelectedIndex != 0)
            //    strProvCode = ddlProv.SelectedValue;

            //ds = (new JobOrderData().getMinistryData(strYaer, afrID, deptID, strMinCode, strBudCode, strProvCode));       //SpName - GetPaymentData     
        }
        catch (Exception ex)
        {
            throw ex;
        }

        if (ds.Tables.Count == 0)
            return dt;
        else
            return ds.Tables[0];
    }
    private DataTable getBudjetCodeData()
    {
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        try
        {
            string strYaer = string.Empty;
            if (ddlYear.SelectedIndex != 0)
                strYaer = ddlYear.Text;

            Int16 afrID;
            Int16.TryParse(ddlAffair.SelectedValue, out afrID);

            Int16 deptID;
            Int16.TryParse(ddlDept.SelectedValue, out deptID);

            string strMinCode = string.Empty;
            //if (ddlMinistry.SelectedIndex != 0)
            //    strMinCode = ddlMinistry.SelectedValue;

            //string strBudCode = string.Empty;
            //if (ddlBudget.SelectedIndex != 0)
            //    strBudCode = ddlBudget.SelectedValue;

            //string strProvCode = string.Empty;
            //if (ddlProv.SelectedIndex != 0)
            //    strProvCode = ddlProv.SelectedValue;

            //ds = (new JobOrderData().getBudjetData(strYaer, afrID, deptID, strMinCode, strBudCode, strProvCode));       //SpName - GetPaymentData     
        }
        catch (Exception ex)
        {
            throw ex;
        }

        if (ds.Tables.Count == 0)
            return dt;
        else
            return ds.Tables[0];
    }

    private DataTable getProvisionData()
    {
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        try
        {
            string strYaer = string.Empty;
            if (ddlYear.SelectedIndex != 0)
                strYaer = ddlYear.Text;

            Int16 afrID;
            Int16.TryParse(ddlAffair.SelectedValue, out afrID);

            Int16 deptID;
            Int16.TryParse(ddlDept.SelectedValue, out deptID);

            string strMinCode = string.Empty;
            //if (ddlMinistry.SelectedIndex != 0)
            //    strMinCode = ddlMinistry.SelectedValue;

            //string strBudCode = string.Empty;
            //if (ddlBudget.SelectedIndex != 0)
            //    strBudCode = ddlBudget.SelectedValue;

            //string strProvCode = string.Empty;
            //if (ddlProv.SelectedIndex != 0)
            //    strProvCode = ddlProv.SelectedValue;

            //ds = (new JobOrderData().getProvisionData(strYaer, afrID, deptID, strMinCode, strBudCode, strProvCode));       //SpName - GetPaymentData     
        }
        catch (Exception ex)
        {
            throw ex;
        }

        if (ds.Tables.Count == 0)
            return dt;
        else
            return ds.Tables[0];
    }
    //private void LoadMinistryCodes()
    //{
    //    DataTable subjects = getMinistryData();
    //    using (SqlConnection con = new SqlConnection(connValue))
    //    {
    //        try
    //        {                
    //            ddlMinistry.DataSource = subjects;
    //            ddlMinistry.DataTextField = "ministryCode";
    //            ddlMinistry.DataValueField = "ministryCode";
    //            ddlMinistry.DataBind();
    //        }
    //        catch (Exception ex)
    //        {

    //        }
    //    }
    //    ddlMinistry.Items.Insert(0, new ListItem("", "0"));
    //}
    //private void LoadBudjetCodes()
    //{
    //    DataTable subjects = getBudjetCodeData();
    //    using (SqlConnection con = new SqlConnection(connValue))
    //    {
    //        try
    //        {
    //            ddlBudget.DataSource = subjects;
    //            ddlBudget.DataTextField = "budgetRefNo";
    //            ddlBudget.DataValueField = "budgetRefNo";
    //            ddlBudget.DataBind();
    //        }
    //        catch (Exception ex)
    //        {

    //        }
    //    }
    //    ddlBudget.Items.Insert(0, new ListItem("", "0"));
    //}
    //private void LoadProvisionCodes()
    //{
    //    DataTable subjects = getProvisionData();
    //    using (SqlConnection con = new SqlConnection(connValue))
    //    {
    //        try
    //        {
    //            ddlProv.DataSource = subjects;
    //            ddlProv.DataTextField = "provisionNo";
    //            ddlProv.DataValueField = "provisionNo";
    //            ddlProv.DataBind();
    //        }
    //        catch (Exception ex)
    //        {

    //        }
    //    }
    //    ddlProv.Items.Insert(0, new ListItem("", "0"));
    //}
    protected void ddlDept_SelectedIndexChanged(object sender, EventArgs e)
    {

        generateReport(ddlReportsMainMenu.SelectedValue, ddlReportsSubMenu.SelectedValue);

        //ddlMinistry.DataSource = null;
        //LoadMinistryCodes();

        //ddlBudget.DataSource = null;
        //LoadBudjetCodes();

        //ddlProv.DataSource = null;
        //LoadProvisionCodes();

    }

    // Year,AffairID,DeptID,MinCode,BudRef,ProvNo
    protected void ddlMinistry_SelectedIndexChanged(object sender, EventArgs e)
    {
        generateReport(ddlReportsMainMenu.SelectedValue, ddlReportsSubMenu.SelectedValue);

        //ddlBudget.DataSource = null;
        //LoadBudjetCodes();

        //ddlProv.DataSource = null;
        //LoadProvisionCodes();

    }
    protected void ddlBudget_SelectedIndexChanged(object sender, EventArgs e)
    {
        generateReport(ddlReportsMainMenu.SelectedValue, ddlReportsSubMenu.SelectedValue);

        //ddlProv.DataSource = null;
        //LoadProvisionCodes();        
    }
    protected void ddlProv_SelectedIndexChanged(object sender, EventArgs e)
    {
        generateReport(ddlReportsMainMenu.SelectedValue, ddlReportsSubMenu.SelectedValue);
    }
    protected void btnClear_Click(object sender, EventArgs e)
    {
        ddlAffair.SelectedIndex = 0;
        // ddlDept.SelectedIndex = -1;
        //ddlMinistry.SelectedIndex = 0;
        //ddlProv.SelectedIndex = 0;
        //ddlBudget.SelectedIndex = 0;         
        ddlYear.SelectedIndex = 0;
        //generateReport("7", "16");         
        ddlDept.SelectedIndex = -1;
        ddlMonth.SelectedIndex = 0;
        generateReport(ddlReportsMainMenu.SelectedValue, ddlReportsSubMenu.SelectedValue);
    }

    #region KPI

    #endregion
    // --------------------------------------------------------------------------------------------------------------------------------------------------------------



    private void fillDropDown()
    {
        if (Session["userProfileID"] != null)
        {
            rptName = ddlReportsSubMenu.SelectedValue;
            //ddldocStatus.DataSource = null;
            //if (ddlKPIYear.Items.Count == 0)
            //{
            //    string sqlQueryYear = "SELECT COUNT(jobID) AS jobCnt, YEAR(jobReceivedDate) AS Year FROM Job GROUP BY YEAR(jobReceivedDate) ORDER BY Year DESC";                 
            //    PopulateDropDownBox(ddlYear, sqlQueryYear, "Year", "Year");
            //}
            //if (rptName.Equals("6"))               // Document KPI
            //{
            //    lblRptName.Text = "Document KPI";

            //    string sqlQryYear = "SELECT docStatusID,DocStatusName from DocumentStatus";
            //    PopulateDropDownBox(ddldocStatus, sqlQryYear, "docStatusID", "DocStatusName");

            //    string sqlQueryEmp = "SELECT   contactID, firstName + ' ' + lastName AS userName, sectionID FROM Contact  WHERE (sectionID = 1) ORDER BY userName";
            //    PopulateDropDownBox(ddlEmployee, sqlQueryEmp, "contactID", "userName");
            //}
            //else if (rptName.Equals("7"))              // Employee KPI
            //{
            //    lblRptName.Text = "Employee KPI";

            //    string sqlQryYear = "SELECT jobStatusID,jobStatusName from JobStatus where jobStatusID < 8";
            //    PopulateDropDownBox(ddldocStatus, sqlQryYear, "jobStatusID", "jobStatusName");

            //    string sqlQueryEmp = "SELECT   contactID, firstName + ' ' + lastName AS userName, sectionID FROM Contact WHERE (sectionID = 1) ORDER BY userName";
            //    PopulateDropDownBox(ddlEmployee, sqlQueryEmp, "contactID", "userName");
            //}
            //else if (rptName.Equals("8"))               // JobOrder KPI
            //{
            //    lblRptName.Text = "JobOrder KPI";

            //    string sqlQryYear = "SELECT jobStatusID,jobStatusName from JobStatus where jobStatusID < 8";
            //    PopulateDropDownBox(ddldocStatus, sqlQryYear, "jobStatusID", "jobStatusName");

            //    lblName.Text = "Project";

            //    string sqlQueryEmp = "SELECT DISTINCT contractNo,contractNo as cntr FROM Job WHERE (contractNo IS NOT NULL) AND (contractNo <> '') ORDER BY contractNo";
            //    PopulateDropDownBox(ddlEmployee, sqlQueryEmp, "contractNo", "cntr");
            //}
        }
        else
        {
            Response.Redirect("~/LoginPage.aspx", false);
        }

    }
    private IList<string> GetReportParametersBySelection(string mainID, string subID)
    {
        IList<string> strColl = null;
        try
        {
            using (SqlConnection cn = new SqlConnection(connValue))
            {
                string strQuery = "SELECT r.reportID, r.moduleName, r.reportName, r.rptMainMenuID, r.rptSubMenuID, r.rptFilterID, r.parameters, r.createUser, r.createDate, r.updateUser, r.updateDate, " +
                       "  m.sectionID FROM Reports AS r INNER JOIN ReportsMainMenu AS m ON r.rptMainMenuID = m.rptMainMenuID INNER JOIN ReportsSubMenu AS s ON r.rptSubMenuID = s.rptSubMenuID " +
                        " WHERE  (r.rptMainMenuID = @rptMainMenuID) AND (r.rptSubMenuID = @rptSubMenuID)";

                cn.Open();

                using (SqlCommand sqlCmd = new SqlCommand(strQuery, cn))
                {

                    sqlCmd.Parameters.AddWithValue("@rptMainMenuID", mainID);
                    sqlCmd.Parameters.AddWithValue("@rptSubMenuID", subID);

                    using (SqlDataReader sqlDtReader = sqlCmd.ExecuteReader())
                    {
                        if (sqlDtReader.Read())
                        {
                            strColl = new List<string>();
                            strColl.Add(sqlDtReader["moduleName"].ToString());
                            strColl.Add(sqlDtReader["reportName"].ToString());
                            strColl.Add(sqlDtReader["parameters"].ToString());
                        }
                    }
                }

            }
        }
        catch (Exception ex)
        {

        }
        return strColl;
    }


    private string CreateParametersForReport(IList<string> rptColl)
    {
        string rptName = string.Empty;
        rptName = "/" + rptColl[0] + "/" + rptColl[1];

        string[] parameterColl = rptColl[2].Split(',');
        foreach (var rptParameter in parameterColl)          // jobStatusID,contactID,jobUnread 
        {
            string val = null;
            if (rptParameter.Equals("Year") && (ddlYear.SelectedIndex != 0 && ddlYear.SelectedIndex != -1))
                val = ddlYear.SelectedValue;
            else if (rptParameter.Equals("AffairID") && (ddlAffair.SelectedIndex != 0 && ddlAffair.SelectedIndex != -1))
                val = ddlAffair.SelectedValue;
            else if (rptParameter.Equals("DeptID") && (ddlDept.SelectedIndex != 0 && ddlDept.SelectedIndex != -1))
            {
                val = ddlDept.SelectedValue;
            }
            else if (rptParameter.Equals("Month") && (ddlMonth.SelectedIndex != 0 && ddlMonth.SelectedIndex != -1))
            {
                val = ddlMonth.SelectedIndex.ToString();
            }

            //else if (rptParameter.Equals("MinCode") && (ddlMinistry.SelectedIndex != 0 && ddlMinistry.SelectedIndex != -1))
            //    val = ddlMinistry.SelectedValue;
            //else if (rptParameter.Equals("BudRef") && (ddlBudget.SelectedIndex != 0 && ddlBudget.SelectedIndex != -1))
            //    val = ddlBudget.SelectedValue;
            //else if (rptParameter.Equals("ProvNo") && (ddlProv.SelectedIndex != 0 && ddlProv.SelectedIndex != -1))
            //    val = ddlProv.SelectedValue;


            rptViewer.ServerReport.SetParameters(new ReportParameter(rptParameter, val, false));
        }
        return rptName;
    }

    //private string CreateParametersForKPI(IList<string> rptColl)
    //{
    //    string rptName = string.Empty;
    //    rptName = "/" + rptColl[0] + "/" + rptColl[1];

    //    string[] parameterColl = rptColl[2].Split(',');
    //    foreach (var rptParameter in parameterColl)          // jobStatusID,contactID,jobUnread     docStatusID docUnread
    //    {
    //        string val = null;
    //        if (rptParameter.Equals("Year") && (ddlKPIYear.SelectedIndex != 0 && ddlKPIYear.SelectedIndex != -1))
    //            val = ddlKPIYear.SelectedValue;

    //        if (rptParameter.Equals("jobStatusID") && (ddldocStatus.SelectedIndex != 0 && ddldocStatus.SelectedIndex != -1))
    //            val = ddldocStatus.SelectedValue;

    //        if (rptParameter.Equals("docStatusID") && (ddldocStatus.SelectedIndex != 0 && ddldocStatus.SelectedIndex != -1))
    //             val = ddldocStatus.SelectedValue;


    //        if (rptParameter.Equals("contactID") && (ddlEmployee.SelectedIndex != 0 && ddlEmployee.SelectedIndex != -1))
    //            val = ddlEmployee.SelectedValue;

    //        if (rptParameter.Equals("jobUnread") && (ddlDateRead.SelectedIndex != 0 && ddlDateRead.SelectedIndex != -1))
    //            val = ddlDateRead.SelectedValue;

    //        if (rptParameter.Equals("docUnread") && (ddlDateRead.SelectedIndex != 0 && ddlDateRead.SelectedIndex != -1))
    //             val = ddlDateRead.SelectedValue;

    //        if (rptParameter.Equals("projectID") && (ddlEmployee.SelectedIndex != 0 && ddlEmployee.SelectedIndex != -1))
    //             val = ddlEmployee.SelectedValue;

    //        rptViewer.ServerReport.SetParameters(new ReportParameter(rptParameter, val, false));
    //    }
    //    return rptName;
    //}

    // --------------------------------------------------------------------------------------------------------------------------------------------------------------------------

    //protected void btnClearKPI_Click(object sender, EventArgs e)
    //{
    //    ddlYear.SelectedIndex = 0;
    //    ddldocStatus.SelectedIndex = 0;
    //    ddlEmployee.SelectedIndex = 0;
    //    ddlDateRead.SelectedIndex = 0;
    //}




    #region MyRegion




    private string getServerURL()
    {
        string strURL = string.Empty;
        try
        {
            string strQuery = "SELECT reportURL From ReportServer";
            using (SqlConnection conn = new SqlConnection(connValue))
            {
                conn.Open();

                SqlCommand sqlCmd = new SqlCommand(strQuery, conn);
                sqlCmd.CommandText = strQuery;
                sqlCmd.CommandType = CommandType.Text;
                sqlCmd.Connection = conn;
                using (SqlDataReader sqlDtReader = sqlCmd.ExecuteReader())
                {
                    while (sqlDtReader.Read())
                    {
                        strURL = sqlDtReader["reportURL"].ToString();
                    }
                }
            }
        }
        catch (Exception ex)
        {

        }

        return strURL;
    }
    private void PopulateDropDownBox(DropDownList ddlBox, string sqlQuery, string valueMember, string displayName)
    {
        ddlBox.DataBound += new EventHandler(this.ddlBox_DataBound);
        ddlBox.DataSource = new JobOrderData().FillDropdown(sqlQuery);
        ddlBox.DataTextField = displayName;
        ddlBox.DataValueField = valueMember;
        ddlBox.SelectedIndex = -1;
        ddlBox.DataBind();
    }
    protected void ddlBox_DataBound(object sender, EventArgs e)
    {
        DropDownList ddl = (DropDownList)sender;
        ListItem emptyItem = new ListItem("", "");
        ddl.Items.Insert(0, emptyItem);
    }
    public class CustomReportCredentials : IReportServerCredentials
    {
        private string _UserName;
        private string _PassWord;
        private string _DomainName;

        public CustomReportCredentials(string UserName, string PassWord, string DomainName)
        {
            _UserName = UserName;
            _PassWord = PassWord;
            _DomainName = DomainName;
        }

        public System.Security.Principal.WindowsIdentity ImpersonationUser
        {
            get { return null; }
        }

        public ICredentials NetworkCredentials
        {
            get { return new NetworkCredential(_UserName, _PassWord, _DomainName); }
        }

        public bool GetFormsCredentials(out Cookie authCookie, out string user,
         out string password, out string authority)
        {
            authCookie = null;
            user = password = authority = null;
            return false;
        }
    }


    #endregion

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        if (ddlReportsSubMenu.SelectedIndex != 0)
        {
            //if (Convert.ToInt16(ddlReportsSubMenu.SelectedValue) == 5)  // D,E,J = 11,12,13   
            //    genarateReport(10);
            //else if (Convert.ToInt16(ddlReportsSubMenu.SelectedValue) == 6)  // D,E,J = 11,12,13   
            //    genarateReport(11);
            //else if (Convert.ToInt16(ddlReportsSubMenu.SelectedValue) == 7)  // D,E,J = 11,12,13 
            //    genarateReport(12);
            //else if (Convert.ToInt16(ddlReportsSubMenu.SelectedValue) == 8)  // D,E,J = 11,12,13   
            //    genarateReport(13);
            //else if (Convert.ToInt16(ddlReportsSubMenu.SelectedValue) == 99)  // D,E,J = 11,12,13   
            //    genarateReport(0);
            //else
            //    genarateReport(0);

            //if (Convert.ToInt16(ddlReportsSubMenu.SelectedValue) > 5)
            //{
            //    //  fillDropDown();
            //    ddlYear.Visible = false;
            //}

            generateReport(ddlReportsMainMenu.SelectedValue, ddlReportsSubMenu.SelectedValue);

        }
    }

    private void genarateReport_Test(int filterID)
    {
        ServerReport serverReport = rptViewer.ServerReport;
        IReportServerCredentials irsc = new CustomReportCredentials(ConfigurationManager.AppSettings["userNameForReport"].ToString(), ConfigurationManager.AppSettings["passWordForReport"].ToString(),
        ConfigurationManager.AppSettings["domainName"].ToString());
        serverReport.ReportServerCredentials = irsc;
        rptViewer.ProcessingMode = ProcessingMode.Remote;
        serverReport.ReportServerUrl = new Uri(strRptURL);

        IList<string> strReportColl = GetReportParametersBySelection("5", "99");

        serverReport.ReportPath = "/" + strReportColl[0] + "/" + strReportColl[1];
        CreateParametersForReport(strReportColl);
        this.rptViewer.ServerReport.Refresh();
    }


    protected void btnFilter_Click(object sender, EventArgs e)
    {
        if (ddlReportsSubMenu.SelectedIndex != 0)
        {
            if (ddlReportsMainMenu.SelectedIndex != 0)
                generateReport(ddlReportsMainMenu.SelectedValue, ddlReportsSubMenu.SelectedValue);
        }

    }
    protected void ddlMonth_SelectedIndexChanged(object sender, EventArgs e)
    {
        generateReport(ddlReportsMainMenu.SelectedValue, ddlReportsSubMenu.SelectedValue);
    }


    #endregion



}