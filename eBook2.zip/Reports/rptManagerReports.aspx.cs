﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using Microsoft.Reporting.WebForms;
using System.Net;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using Datalayer;
public partial class Reports_rptManagerReports : System.Web.UI.Page
{
    string connValue = ConfigurationManager.ConnectionStrings["EBSDEBookConn"].ToString();
    static string strRptURL = string.Empty;
    string strRptFilter = string.Empty;
    IList<string> userRightsColl = new List<string>();
    IList<string> rptColl = new List<string>();
    string rptName = string.Empty;
    string sqlQueryYear = null;
    string sqlJobType = null;
    string sqlActionBy = null;
    string sqlQueryPrj = null;


    #region MyRegion



    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["userProfileID"] != null)
        {
            userRightsColl = (IList<string>)Session["UserRightsColl"];
            strRptURL = getServerURL();
            if (!Page.IsPostBack)
            {
                generateDefaultReport();
                string sqlQueryMain = string.Empty;
                sqlQueryYear = "SELECT distinct jobYr AS Year FROM EBD_TEAM_MTHLY_DIRECT_COSTS ORDER BY Year DESC";
                //sqlQueryPrj = "SELECT DISTINCT Job.contractNo FROM CONTRACTORS INNER JOIN Job ON CONTRACTORS.contract_no = Job.contractNo COLLATE SQL_Latin1_General_CP1_CI_AS WHERE (contractNo IS NOT NULL) AND (contractNo <> '') ORDER BY contractNo";
                sqlQueryPrj = "SELECT DISTINCT contractNo,contractNo+'->'+projectTitle as ctrNoProjTitle FROM Job WHERE (contractNo IS NOT NULL) AND (contractNo <> '') ORDER BY contractNo";

                if (Session["userProfileID"].ToString().Equals("1"))
                {
                    sqlQueryMain = "select rptMainMenuID,rptMainMenuDescription from ReportsMainMenu where rptMainMenuID <> 0 and sectionID = 10 order by rptMainMenuID";
                    sqlJobType = "SELECT  jobTypeID, jobTypeName, CategoryID, sectionID FROM JobType WHERE (jobTypeID <> CategoryID)";
                    sqlActionBy = "select distinct c.contactID,c.firstName + ' ' + c.lastName as UserName from job j INNER JOIN JobOwner jo ON j.jobID = jo.jobID INNER JOIN Contact AS c ON jo.contactID = c.contactID where j.sectionID = 10";
                }
                else
                {
                    if (!userRightsColl.Contains("24"))
                        sqlQueryMain = "select rptMainMenuID,rptMainMenuDescription from ReportsMainMenu where rptMainMenuID <> 0 and sectionID = " + Convert.ToInt16(Session["SectionID"]) + " order by rptMainMenuID";
                    else
                        sqlQueryMain = "select rptMainMenuID,rptMainMenuDescription from ReportsMainMenu where rptMainMenuID not in(0,5,6) and sectionID = " + Convert.ToInt16(Session["SectionID"]) + " order by rptMainMenuID";
                    sqlJobType = "SELECT  jobTypeID, jobTypeName, CategoryID, sectionID FROM JobType WHERE  (sectionID = " + Session["SectionID"] + ") AND (jobTypeID <> CategoryID)";
                    sqlActionBy = "select distinct c.contactID,c.firstName + ' ' + c.lastName as UserName from job j INNER JOIN JobOwner jo ON j.jobID = jo.jobID INNER JOIN Contact AS c ON jo.contactID = c.contactID where j.sectionID = " + Session["SectionID"];
                }

                PopulateDropDownBox(ddlContractNo, sqlQueryPrj, "contractNo", "ctrNoProjTitle");
                PopulateDropDownBox(ddlReportsMainMenu, sqlQueryMain, "rptMainMenuID", "rptMainMenuDescription");
                PopulateDropDownBox(ddlJobType, sqlJobType, "jobTypeID", "jobTypeName");
                PopulateDropDownBox(ddlJobStatus, "SELECT JobStatusID, JobStatusName FROM JobStatus Where JobStatusID in(1,2,3,5,6,7) ORDER BY JobStatusName", "JobStatusID", "JobStatusName");
                PopulateDropDownBox(ddlActionBy, sqlActionBy, "contactID", "UserName");
                PopulateDropDownBox(ddlYear, sqlQueryYear, "Year", "Year");
            }
        }

    }

    protected void ddlContractNo_SelectedIndexChanged(object sender, EventArgs e)
    {
        generateDefaultReport();
    }

    private void generateDefaultReport()
    {
        try
        {
            ServerReport serverReport = rptViewer.ServerReport;
            IReportServerCredentials irsc = new CustomReportCredentials(ConfigurationManager.AppSettings["userNameForReport"].ToString(), ConfigurationManager.AppSettings["passWordForReport"].ToString(),
            ConfigurationManager.AppSettings["domainName"].ToString());
            serverReport.ReportServerCredentials = irsc;
            rptViewer.ProcessingMode = ProcessingMode.Remote;
            serverReport.ReportServerUrl = new Uri(strRptURL);
            // 9 & 23 equals to MgmtSummary_TEST reportName
            IList<string> strReportColl = null;
            if (ddlReportsSubMenu.SelectedValue == "24") //MgmtJobDetail=24 Report
            {
                tblContractNo.Visible = false;
                tblMoreInfo.Visible = false;
                tblJobNoInfo.Visible = true;
                tblDates.Visible = false;
                tblYear.Visible = false;
                strReportColl = GetReportParametersBySelectionDefault("9", ddlReportsSubMenu.SelectedValue, 0);
                serverReport.ReportPath = "/" + strReportColl[0] + "/" + strReportColl[1];
                CreateParametersForReport(strReportColl, true);
            }
            else if (ddlReportsSubMenu.SelectedValue == "23" || ddlReportsSubMenu.SelectedValue == "37") //MgmtSummary=23 or MgmtDetail=37 Report
            {
                if (ddlReportsSubMenu.SelectedValue == "23")
                {
                    txtJobNo.Text = "";
                    tblContractNo.Visible = false;
                    tblJobNoInfo.Visible = false;
                    tblMoreInfo.Visible = true;
                    tblYear.Visible = false;
                    tblDates.Visible = false;
                }
                else
                {
                    tblContractNo.Visible = true;
                    tblJobNoInfo.Visible = false;
                    tblMoreInfo.Visible = false;
                    tblYear.Visible = false;
                    tblDates.Visible = false;
                }

                strReportColl = GetReportParametersBySelectionDefault("9", ddlReportsSubMenu.SelectedValue, 0);
                serverReport.ReportPath = "/" + strReportColl[0] + "/" + strReportColl[1];
                CreateParametersForReport(strReportColl, false);
            }
            else
            {
                txtJobNo.Text = "";
                tblContractNo.Visible = false;
                if (ddlReportsSubMenu.SelectedValue == "" || ddlReportsSubMenu.SelectedValue == "0")
                {
                    tblJobNoInfo.Visible = false;
                    tblMoreInfo.Visible = true;
                    tblDates.Visible = false;
                    tblYear.Visible = false;
                    strReportColl = GetReportParametersBySelectionDefault("9", "23", 0); //MgmtSummary=23 Report
                }
                else
                {
                    tblJobNoInfo.Visible = false;
                    tblMoreInfo.Visible = false;

                    if (ddlReportsSubMenu.SelectedValue == "58") //COC_PCC Report
                    {
                        tblYear.Visible = true;
                        tblDates.Visible = false;
                        strReportColl = GetReportParametersBySelectionDefault("9", ddlReportsSubMenu.SelectedValue, 0);
                        if (ddlYear.SelectedIndex == 0 || ddlYear.SelectedValue == "")
                        {
                            ddlYear.SelectedIndex = 1;
                        }
                    }
                    else if (ddlReportsSubMenu.SelectedValue == "59") //05_COC_PAY Report
                    {
                        tblDates.Visible = false;
                        tblYear.Visible = true;
                        strReportColl = GetReportParametersBySelectionDefault("9", "59", 0);
                    }
                    else if (ddlReportsSubMenu.SelectedValue == "62") //ESD KPI  Report
                    {
                        tblDates.Visible = true;
                        tblYear.Visible = false;
                        strReportColl = GetReportParametersBySelectionDefault("9", ddlReportsSubMenu.SelectedValue, 0);
                    }
                    else if (ddlReportsSubMenu.SelectedValue == "63") //07_DATA_GAPS  Report
                    {
                        tblDates.Visible = true;
                        tblYear.Visible = false;
                        txtStartDate.Text = "01/Jan/" + DateTime.Now.Year;
                        strReportColl = GetReportParametersBySelectionDefault("9", ddlReportsSubMenu.SelectedValue, 0);
                    }
                }
                serverReport.ReportPath = "/" + strReportColl[0] + "/" + strReportColl[1];
                CreateParametersForReport(strReportColl, false);
            }

            this.rptViewer.ServerReport.Refresh();
        }
        catch (Exception ex)
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('" + ex.Message.Replace("'", "") + "')</script>", false);
        }

    }

    private string CreateParametersForReport(IList<string> rptColl, bool isJobNo)
    {
        string rptName = string.Empty;

        rptName = "/" + rptColl[0] + "/" + rptColl[1];

        string[] parameterColl = rptColl[2].Split(',');
        if (!isJobNo)
        {
            if (rptColl[1].ToString() == "MgmtDetail" || rptColl[1].ToString() == "01_MgmtSummary" || rptColl[1].ToString() == "COC_PCC") //rptColl[1]==reportName
            {
                foreach (var rptParameter in parameterColl)
                {
                    string val = null;

                    if (rptParameter.Equals("StartDate"))
                    {
                        if (txtStartDate.Text != "")
                            val = txtStartDate.Text;

                    }
                    else if (rptParameter.Equals("EndDate"))
                    {
                        if (txtEndDate.Text != "")
                            val = txtEndDate.Text;

                    }
                    else if (rptParameter.Equals("JobType"))
                    {
                        if (ddlJobType.SelectedValue.ToString() != "")
                            val = ddlJobType.SelectedValue.ToString();

                    }
                    else if (rptParameter.Equals("JobStatus"))
                    {
                        if (ddlJobStatus.SelectedValue.ToString() != "")
                            val = ddlJobStatus.SelectedValue.ToString();

                    }
                    else if (rptParameter.Equals("ActionBy"))
                    {
                        if (ddlActionBy.SelectedValue.ToString() != "")
                            val = ddlActionBy.SelectedValue.ToString();

                    }
                    else if (rptParameter.Equals("Year"))
                    {
                        if (ddlYear.SelectedValue.ToString() != "")
                            val = ddlYear.SelectedValue.ToString();

                    }
                    rptViewer.ServerReport.SetParameters(new ReportParameter(rptParameter, val, false));
                }
            }
            else if (rptColl[1].ToString() == "04_COC_PCC" || rptColl[1].ToString() == "05_COC_PAY")
            {
                foreach (var rptParameter in parameterColl)
                {
                    string val = null;
                    if (rptParameter.Equals("Year"))
                    {
                        if (ddlYear.SelectedValue.ToString() != "")
                            val = ddlYear.SelectedValue.ToString();

                    }
                    rptViewer.ServerReport.SetParameters(new ReportParameter(rptParameter, val, false));
                }
            }
            else if (rptColl[1].ToString() == "03_ProjectSummary") //rptColl[1]==reportName
            {
                foreach (var rptParameter in parameterColl)          // jobStatusID,contactID,jobUnread 
                {
                    string val = null;

                    if (rptParameter.Equals("CommitmentNo"))
                    {
                        if (ddlContractNo.SelectedValue != "0" && ddlContractNo.SelectedValue != "")
                        {
                            val = ddlContractNo.SelectedValue;
                        }
                        //else
                        //{
                        //    val = "EBD170001";
                        //    txtJobNo.Text = "EBD170001";
                        //}
                    }
                    rptViewer.ServerReport.SetParameters(new ReportParameter(rptParameter, val, false));
                }
            }
            else
            {
                foreach (var rptParameter in parameterColl)          // jobStatusID,contactID,jobUnread 
                {
                    string val = null;
                    if (rptParameter.Equals("StartDate"))
                    {
                        if (dataGapsStartDate.Text != "")
                            val = dataGapsStartDate.Text;

                    }
                    else if (rptParameter.Equals("EndDate"))
                    {
                        if (dataGapsEndDate.Text != "")
                            val = dataGapsEndDate.Text;
                    }
                    rptViewer.ServerReport.SetParameters(new ReportParameter(rptParameter, val, false));
                }
            }
        }
        else
        {
            foreach (var rptParameter in parameterColl)          // jobStatusID,contactID,jobUnread 
            {
                string val = null;

                if (rptParameter.Equals("JobNo"))
                {
                    if (txtJobNo.Text != "")
                    {
                        val = txtJobNo.Text;
                    }
                    //else
                    //{
                    //    val = "EBD170001";
                    //    txtJobNo.Text = "EBD170001";
                    //}
                }
                rptViewer.ServerReport.SetParameters(new ReportParameter(rptParameter, val, false));
            }
        }
        return rptName;
    }

    private IList<string> GetReportParametersBySelectionDefault(string mainID, string subID, int filterID)
    {
        IList<string> strColl = null;
        try
        {
            using (SqlConnection cn = new SqlConnection(connValue))
            {
                string strQuery = "SELECT  r.reportID, r.moduleName, r.reportName, r.rptMainMenuID, r.rptSubMenuID, r.rptFilterID, r.parameters, r.createUser, r.createDate, r.updateUser, r.updateDate, " +
                "  m.sectionID FROM Reports AS r INNER JOIN ReportsMainMenu AS m ON r.rptMainMenuID = m.rptMainMenuID INNER JOIN ReportsSubMenu AS s ON r.rptSubMenuID = s.rptSubMenuID INNER JOIN " +
                " ReportsFilter AS f ON r.rptFilterID = f.rptfilterID WHERE (r.rptMainMenuID = @rptMainMenuID) AND (r.rptSubMenuID = @rptSubMenuID)";

                cn.Open();

                using (SqlCommand sqlCmd = new SqlCommand(strQuery, cn))
                {
                    sqlCmd.Parameters.AddWithValue("@rptMainMenuID", mainID);
                    sqlCmd.Parameters.AddWithValue("@rptSubMenuID", subID);
                    //sqlCmd.Parameters.AddWithValue("@rptFilterID", filterID);

                    using (SqlDataReader sqlDtReader = sqlCmd.ExecuteReader())
                    {
                        if (sqlDtReader.Read())
                        {
                            strColl = new List<string>();
                            strColl.Add(sqlDtReader["moduleName"].ToString().Trim());
                            strColl.Add(sqlDtReader["reportName"].ToString().Trim());
                            strColl.Add(sqlDtReader["parameters"].ToString().Trim());
                        }
                    }
                }
            }
        }
        catch (Exception ex)
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('" + ex.Message.Replace("'", "") + "')</script>", false);
        }
        return strColl;
    }

    protected void ddlReportsMainMenu_SelectedIndexChanged(object sender, EventArgs e)
    {
        //if (ddlReportsMainMenu.SelectedValue == "5")
        //{
        //    ddlReportsSubMenu.DataSource = null;
        //    string sqlQuery = "select rptSubMenuID,rptSubMenuDescription from ReportsSubMenu where rptSubMenuID >= 5 and sectionID =" + Convert.ToInt16(Session["SectionID"]) + "";
        //    PopulateDropDownBox(ddlReportsSubMenu, sqlQuery, "rptSubMenuID", "rptSubMenuDescription");
        //}
        //else if (ddlReportsMainMenu.SelectedValue == "6")
        //{
        //    ddlReportsSubMenu.DataSource = null;
        //    string sqlQuery = "select rptSubMenuID,rptSubMenuDescription from ReportsSubMenu where rptSubMenuID < 5 and sectionID =" + Convert.ToInt16(Session["SectionID"]) + "";
        //    PopulateDropDownBox(ddlReportsSubMenu, sqlQuery, "rptSubMenuID", "rptSubMenuDescription");
        //}
        //else
        //{
        if (ddlReportsMainMenu.SelectedValue != "")
        {
            ddlReportsSubMenu.DataSource = null;
            string sqlQuery = "select rptSubMenuID,rptSubMenuDescription from ReportsSubMenu where rptMainMenuID=" + ddlReportsMainMenu.SelectedValue;
            PopulateDropDownBox(ddlReportsSubMenu, sqlQuery, "rptSubMenuID", "rptSubMenuDescription");
        }
        ////}
    }


    private string getServerURL()
    {
        string strURL = string.Empty;
        try
        {
            string strQuery = "SELECT reportURL From ReportServer";
            using (SqlConnection conn = new SqlConnection(connValue))
            {
                conn.Open();

                SqlCommand sqlCmd = new SqlCommand(strQuery, conn);
                sqlCmd.CommandText = strQuery;
                sqlCmd.CommandType = CommandType.Text;
                sqlCmd.Connection = conn;
                using (SqlDataReader sqlDtReader = sqlCmd.ExecuteReader())
                {
                    while (sqlDtReader.Read())
                    {
                        strURL = sqlDtReader["reportURL"].ToString();
                    }
                }
            }
        }
        catch (Exception ex)
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('" + ex.Message.Replace("'", "") + "')</script>", false);
        }

        return strURL;
    }

    private void PopulateDropDownBox(DropDownList ddlBox, string sqlQuery, string valueMember, string displayName)
    {
        ddlBox.DataBound += new EventHandler(this.ddlBox_DataBound);
        ddlBox.DataSource = new JobOrderData().FillDropdown(sqlQuery);
        ddlBox.DataTextField = displayName;
        ddlBox.DataValueField = valueMember;
        ddlBox.SelectedIndex = -1;
        ddlBox.DataBind();
    }
    protected void ddlBox_DataBound(object sender, EventArgs e)
    {
        DropDownList ddl = (DropDownList)sender;
        ListItem emptyItem = new ListItem("", "");
        ddl.Items.Insert(0, emptyItem);
    }
    public class CustomReportCredentials : IReportServerCredentials
    {
        private string _UserName;
        private string _PassWord;
        private string _DomainName;

        public CustomReportCredentials(string UserName, string PassWord, string DomainName)
        {
            _UserName = UserName;
            _PassWord = PassWord;
            _DomainName = DomainName;
        }

        public System.Security.Principal.WindowsIdentity ImpersonationUser
        {
            get { return null; }
        }

        public ICredentials NetworkCredentials
        {
            get { return new NetworkCredential(_UserName, _PassWord, _DomainName); }
        }

        public bool GetFormsCredentials(out Cookie authCookie, out string user,
         out string password, out string authority)
        {
            authCookie = null;
            user = password = authority = null;
            return false;
        }
    }

    protected void ddlReportsSubMenu_SelectedIndexChanged(object sender, EventArgs e)
    {
        generateDefaultReport();
    }
    protected void txtEndDate_TextChanged(object sender, EventArgs e)
    {
        generateDefaultReport();
    }

    protected void ddlJobType_SelectedIndexChanged(object sender, EventArgs e)
    {
        generateDefaultReport();
    }
    protected void ddlJobStatus_SelectedIndexChanged(object sender, EventArgs e)
    {
        generateDefaultReport();
    }
    protected void ddlActionBy_SelectedIndexChanged(object sender, EventArgs e)
    {
        generateDefaultReport();
    }
    protected void txtStartDate_TextChanged(object sender, EventArgs e)
    {
        generateDefaultReport();
    }
    protected void txtJobNo_TextChanged(object sender, EventArgs e)
    {
        generateDefaultReport();
    }
    #endregion

}