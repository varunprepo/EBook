﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;


using Microsoft.Reporting.WebForms;
using System.Net;
using Datalayer;

public partial class Reports_rptPaymentReports : System.Web.UI.Page
{
    string connValue = ConfigurationManager.ConnectionStrings["EBSDEBookConn"].ToString();   
    static string strRptURL = string.Empty;
    string strRptFilter = string.Empty;
    string rptName = string.Empty;
    IList<string> rptColl = new List<string>();

    IList<string> userRightsColl = new List<string>();


    #region MyRegion


    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["userProfileID"] != null)
        {
            if (!Page.IsPostBack)
            {
                userRightsColl = (IList<string>)Session["UserRightsColl"];

                string sqlQueryMain = null;
                strRptURL = getServerURL();
                ddlReportsSubMenu.Enabled = false;
                fillYear();
                ddlYear.SelectedIndex = 1;
                if ((Session["userProfileID"].ToString().Equals("1")) || !userRightsColl.Contains("35"))                 // 35- View REPORTS Payment Section
                {
                    sqlQueryMain = "select rptMainMenuID,rptMainMenuDescription from ReportsMainMenu where rptMainMenuID <> 0 and sectionID=2 order by rptMainMenuID";
                    PopulateDropDownBox(ddlReportsMainMenu, sqlQueryMain, "rptMainMenuID", "rptMainMenuDescription");
                    //string sqlQuery = "select rptSubMenuID,rptSubMenuDescription from ReportsSubMenu where rptMainMenuID=" + ddlReportsMainMenu.SelectedValue;
                    //PopulateDropDownBox(ddlReportsSubMenu, sqlQuery, "rptSubMenuID", "rptSubMenuDescription");
                    getPaymentReport("6", "10"); // Default Index for default payment report   PaymentScorecard                 
                }
                else
                {
                    sqlQueryMain = "select rptMainMenuID,rptMainMenuDescription from ReportsMainMenu where rptMainMenuID <> 0 and sectionID=" + Convert.ToInt16(Session["SectionID"]) + " order by rptMainMenuID";
                    PopulateDropDownBox(ddlReportsMainMenu, sqlQueryMain, "rptMainMenuID", "rptMainMenuDescription");
                    getPaymentReport("6", "10"); // Default Index for default payment report   PaymentScorecard               
                }
                tblKPI.Visible = false;
                tblCommittmentNo.Visible = false;
                //lblCntrNo.Visible = false;
                //txtCntrNo.Visible = false;
                tblDates.Visible = false;
                TblBtns.Visible = false;
                txtEndDate.Enabled = false;
                ddlYear.Enabled = false;
            }
        }
        else
        {
            Response.Redirect("~/LoginPage.aspx", false);
        }

    }



    # region New Code

    private IList<string> GetReportsInfo(int mainID, int subID)
    {
        IList<string> strColl = null;
        try
        {
            string strQuery = "SELECT r.* FROM Reports r,ReportsFilter f,ReportsMainMenu m,ReportsSubMenu s WHERE r.rptMainMenuID = m.rptMainMenuID AND r.rptSubMenuID = s.rptSubMenuID AND r.rptFilterID = f.rptfilterID AND " +
            "   r.rptMainMenuID = @rptMainMenuID and r.rptSubMenuID = @rptSubMenuID";

            using (SqlConnection sqlCn = new SqlConnection(connValue))
            {
                sqlCn.Open();
                using (SqlCommand sqlCmd = new SqlCommand(strQuery, sqlCn))
                {
                    sqlCmd.Parameters.AddWithValue("@rptMainMenuID", mainID);
                    sqlCmd.Parameters.AddWithValue("@rptSubMenuID", subID);

                    using (SqlDataReader sqlDtReader = sqlCmd.ExecuteReader())
                    {
                        while (sqlDtReader.Read())
                        {
                            strColl = new List<string>();

                            strColl.Add(sqlDtReader["moduleName"].ToString().Trim());
                            strColl.Add(sqlDtReader["reportName"].ToString().Trim());
                            strColl.Add(sqlDtReader["parameters"].ToString().Trim());
                        }
                    }
                }
            }
        }
        catch (Exception ex)
        {

        }
        return strColl;
    }
    private void getPaymentReport(string rptMainID, string rptSubID)
    {
        try
        {
            IList<string> strPayInfoColl = new List<string>();

            if ((rptMainID != "") & (rptSubID != ""))
                rptColl = GetReportsInfo(Convert.ToInt16(rptMainID), Convert.ToInt16(rptSubID));

            ServerReport serverReport = rptViewer.ServerReport;
            IReportServerCredentials irsc = new CustomReportCredentials(ConfigurationManager.AppSettings["userNameForReport"].ToString(), ConfigurationManager.AppSettings["passWordForReport"].ToString(),
            ConfigurationManager.AppSettings["domainName"].ToString());
            serverReport.ReportServerCredentials = irsc;
            rptViewer.ProcessingMode = ProcessingMode.Remote;
            serverReport.ReportServerUrl = new Uri(strRptURL);
            serverReport.ReportPath = "/" + rptColl[0] + "/" + rptColl[1];

            string[] strColl = rptColl[2].Split(',');
            foreach (string _paramName in strColl)
            {
                string _pramValue = string.Empty;
                _pramValue = getControlNameByParamater(_paramName);

                if (_paramName != "")
                    rptViewer.ServerReport.SetParameters(new ReportParameter(_paramName, _pramValue, false));
            }

            this.rptViewer.ServerReport.Refresh();

            ControlEnable();

        }
        catch (Exception ex)
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('" + ex.Message + "')</script>", false);
        }

    }
    private void ControlEnable()
    {
        // 14- Project Summary      19- Payment Project KPIs 
        if (ddlReportsSubMenu.SelectedValue == "14")
        {
            tblCommittmentNo.Visible = true;
            tblDates.Visible = false;
            tblKPI.Visible = false;
        }
        //else if (ddlReportsSubMenu.SelectedValue == "19")
        //{
        //    lblCntrNo.Visible = false;
        //    txtCntrNo.Visible = false;
        //    tblKPI.Visible = true;
        //}
        else
        {
            tblCommittmentNo.Visible = false;
            tblKPI.Visible = false;
            tblDates.Visible = true;
        }

    }
    private string getControlNameByParamater(string paramName)
    {
        string paramVal = null;
        if (paramName.Equals("Year"))
        {
            if (ddlYear.SelectedValue != "")
            {
                paramVal = ddlYear.SelectedValue;
            }
            else
            {
                paramVal = DateTime.Now.Year.ToString();
            }
        }
        else if (paramName.Equals("docStatusID"))
        {
            if (ddldocStatus.SelectedValue != "")
                paramVal = ddldocStatus.SelectedValue;
        }
        else if (paramName.Equals("jobStatusID"))
        {
            if (ddldocStatus.SelectedValue != "")
                paramVal = ddldocStatus.SelectedValue;
        }
        else if (paramName.Equals("contactID"))
        {
            if (ddlEmployee.SelectedValue != "")
                paramVal = ddlEmployee.SelectedValue;
        }
        else if (paramName.Equals("docUnread"))
        {
            if (ddlDateRead.SelectedValue != "")
                paramVal = ddlDateRead.SelectedValue;
        }
        else if (paramName.Equals("jobUnread"))
        {
            if (ddlDateRead.SelectedValue != "")
                paramVal = ddlDateRead.SelectedValue;
        }
        else if (paramName.Equals("projectID"))
        {
            if (ddlEmployee.SelectedValue != "")
                paramVal = ddlEmployee.SelectedValue;
        }
        else if (paramName.Equals("StartDate"))
        {
            if (txtStartDate.Text != "")
                paramVal = txtStartDate.Text;
        }
        else if (paramName.Equals("EndDate"))
        {
            if (txtEndDate.Text != "")
                paramVal = txtEndDate.Text;
        }
        else if (paramName.Equals("CommitmentNo"))
        {
            if (txtCntrNo.Text != "")
                paramVal = txtCntrNo.Text;
        }
        return paramVal;
    }
    private string getServerURL()
    {
        string strURL = string.Empty;
        try
        {
            string strQuery = "SELECT reportURL From ReportServer";
            using (SqlConnection conn = new SqlConnection(connValue))
            {
                conn.Open();

                SqlCommand sqlCmd = new SqlCommand(strQuery, conn);
                sqlCmd.CommandText = strQuery;
                sqlCmd.CommandType = CommandType.Text;
                sqlCmd.Connection = conn;
                using (SqlDataReader sqlDtReader = sqlCmd.ExecuteReader())
                {
                    while (sqlDtReader.Read())
                    {
                        strURL = sqlDtReader["reportURL"].ToString();
                    }
                }
            }
        }
        catch (Exception ex)
        {
        }

        return strURL;
    }

    private void FillDropdownValues()
    {
        if (ddlReportsSubMenu.SelectedValue == "19")     //Payment Project KPIs
        {
            string sqlQueryYear = "SELECT COUNT(jobID) AS jobCnt, YEAR(jobReceivedDate) AS Year FROM Job GROUP BY YEAR(jobReceivedDate) ORDER BY Year DESC";
            PopulateDropDownBox(ddlKPIYear, sqlQueryYear, "Year", "Year");
            ddlKPIYear.SelectedIndex = 1;

            string sqlQryYear = "SELECT jobStatusID,jobStatusName from JobStatus where jobStatusID < 8";
            PopulateDropDownBox(ddldocStatus, sqlQryYear, "jobStatusID", "jobStatusName");

            string sqlQryPrj = "SELECT distinct commitmentNo from Payment Where commitmentNo is not null order by commitmentNo";
            PopulateDropDownBox(ddlEmployee, sqlQryPrj, "commitmentNo", "commitmentNo");
        }

        Label2.Text = "Project Code ";
    }
    private void PopulateDropDownBox(DropDownList ddlBox, string sqlQuery, string valueMember, string displayName)
    {
        ddlBox.DataBound += new EventHandler(this.ddlBox_DataBound);
        ddlBox.DataSource = new JobOrderData().FillDropdown(sqlQuery);
        ddlBox.DataTextField = displayName;
        ddlBox.DataValueField = valueMember;
        ddlBox.SelectedIndex = -1;
        ddlBox.DataBind();
    }
    protected void ddlBox_DataBound(object sender, EventArgs e)
    {
        DropDownList ddl = (DropDownList)sender;
        ListItem emptyItem = new ListItem("", "");
        ddl.Items.Insert(0, emptyItem);
    }

    private void fillYear()
    {
        string sqlQueryYear = "SELECT COUNT(jobID) AS jobCnt, YEAR(jobReceivedDate) AS Year FROM Job GROUP BY YEAR(jobReceivedDate) ORDER BY Year DESC";
        PopulateDropDownBox(ddlYear, sqlQueryYear, "Year", "Year");
    }

    protected void ddlReportsMainMenu_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (Session["userProfileID"] != null)
        {
            if ((Session["userProfileID"].ToString().Equals("1") || !userRightsColl.Contains("35")))
            {
                if (ddlYear.Items.Count == 0)
                {
                    fillYear();
                }

                if (ddlReportsMainMenu.SelectedValue != "")
                {
                    if (ddlReportsMainMenu.SelectedIndex != 0)
                        ddlReportsSubMenu.Enabled = true;

                    ddlReportsSubMenu.DataSource = null;
                    string sqlQuery = "select rptSubMenuID,rptSubMenuDescription from ReportsSubMenu where rptSubMenuID <> 0 and rptMainMenuID=" + ddlReportsMainMenu.SelectedValue + " AND (isActive = 1) order by rptSubMenuID"; // and sectionID=2
                    PopulateDropDownBox(ddlReportsSubMenu, sqlQuery, "rptSubMenuID", "rptSubMenuDescription");
                    ddlYear.Enabled = true;
                    ddlYear.SelectedIndex = 1;
                    Reset(false);
                }
                else
                {
                    Reset(true);
                }
            }
            else
            {
                if (ddlReportsMainMenu.SelectedValue != "")
                {
                    ddlReportsSubMenu.DataSource = null;
                    string sqlQuerySub = "select rptSubMenuID,rptSubMenuDescription from ReportsSubMenu where rptSubMenuID <> 0  AND (isActive = 1) and rptMainMenuID=" + ddlReportsMainMenu.SelectedValue + " order by rptSubMenuID"; //and sectionID=" + Session["SectionID"].ToString() + "
                    PopulateDropDownBox(ddlReportsSubMenu, sqlQuerySub, "rptSubMenuID", "rptSubMenuDescription");
                    ddlYear.Enabled = true;
                    ddlYear.SelectedIndex = 1;
                    Reset(false);
                }
                else
                {
                    Reset(true);
                }
            }
        }
        else
        {
            Response.Redirect("~/LoginPage.aspx", false);
        }

    }

    private void Reset(bool isItemBlank)
    {
        if (isItemBlank)
        {
            ddlReportsMainMenu.SelectedIndex = -1;
            ddlReportsSubMenu.SelectedIndex = -1;
            ddlReportsSubMenu.Enabled = false;
            ddlYear.SelectedIndex = 0;
            ddlYear.Enabled = false;
            getPaymentReport("6", "10");
        }
        ddlReportsSubMenu.Enabled = true;
        tblDates.Visible = false;
        tblKPI.Visible = false;
    }


    protected void ddlReportsSubMenu_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlReportsSubMenu.SelectedValue != "")
        {
            if (Session["userProfileID"] != null)
            {
                if (ddlReportsSubMenu.SelectedValue == "")
                {
                    tblCommittmentNo.Visible = false;
                    tblDates.Visible = false;
                    TblBtns.Visible = false;
                    ddlYear.SelectedIndex = 0;
                    ddlYear.Enabled = false;
                }
                else
                {
                    tblDates.Visible = true;
                    TblBtns.Visible = true;
                }
                if (ddlReportsSubMenu.SelectedValue == "14")
                {
                    tblCommittmentNo.Visible = true;
                }
                FillDropdownValues();
                ClearAll(false);
                getPaymentReport(ddlReportsMainMenu.SelectedValue, ddlReportsSubMenu.SelectedValue);
            }
            else
            {
                Response.Redirect("~/LoginPage.aspx", false);
            }
        }
        else
        {
            Reset(true);
        }

    }


    #endregion

    protected void ddlYear_SelectedIndexChanged(object sender, EventArgs e)
    {
        OnChangeEvent();
    }

    private void OnChangeEvent()
    {
        if (Session["userProfileID"] != null)
        {
            if (ddlReportsSubMenu.SelectedValue != "0" && ddlReportsSubMenu.SelectedValue != "")
            {
                getPaymentReport(ddlReportsMainMenu.SelectedValue, ddlReportsSubMenu.SelectedValue);
            }
        }
        else
        {
            Response.Redirect("~/LoginPage.aspx", false);
        }
    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        OnChangeEvent();
    }
    protected void btnClear_Click(object sender, EventArgs e)
    {
        ddldocStatus.SelectedIndex = -1;
        ddlEmployee.SelectedIndex = -1;
        ddlDateRead.SelectedIndex = 0;
        txtCntrNo.Text = "";
        txtStartDate.Text = "";
        txtEndDate.Text = "";
        txtEndDate.Enabled = false;
        ddlKPIYear.SelectedIndex = -1;
    }
    private void ClearAll(bool isReportsDLLReset)
    {
        ddldocStatus.SelectedIndex = -1;
        ddlEmployee.SelectedIndex = -1;
        ddlDateRead.SelectedIndex = 0;

        txtStartDate.Text = "";
        txtEndDate.Text = "";
        txtEndDate.Enabled = false;
        ddlKPIYear.SelectedIndex = -1;

        if (isReportsDLLReset)
        {
            if (ddlReportsMainMenu.SelectedIndex != -1)
            {
                ddlReportsMainMenu.SelectedIndex = 0;
            }

            if (ddlReportsSubMenu.SelectedIndex != -1)
            {
                ddlReportsSubMenu.SelectedIndex = 0;
            }
            ddlReportsSubMenu.DataSource = null;
            ddlReportsSubMenu.Enabled = false;
            ddlYear.Enabled = false;
            ddlYear.SelectedIndex = 1;
            //getPaymentReport("6", "10");
        }

    }

    protected void txtCntrNo_TextChanged(object sender, EventArgs e)
    {
        if (ddlReportsSubMenu.SelectedValue != "")
            OnChangeEvent();
    }
    protected void txtStartDate_TextChanged(object sender, EventArgs e)
    {
        if (txtStartDate.Text == "")
        {
            txtEndDate.Text = "";
            txtEndDate.Enabled = false;
        }
        else
            txtEndDate.Enabled = true;

        OnChangeEvent();

    }
    public class CustomReportCredentials : IReportServerCredentials
    {
        private string _UserName;
        private string _PassWord;
        private string _DomainName;

        public CustomReportCredentials(string UserName, string PassWord, string DomainName)
        {
            _UserName = UserName;
            _PassWord = PassWord;
            _DomainName = DomainName;
        }

        public System.Security.Principal.WindowsIdentity ImpersonationUser
        {
            get { return null; }
        }

        public ICredentials NetworkCredentials
        {
            get { return new NetworkCredential(_UserName, _PassWord, _DomainName); }
        }

        public bool GetFormsCredentials(out Cookie authCookie, out string user,
         out string password, out string authority)
        {
            authCookie = null;
            user = password = authority = null;
            return false;
        }
    }

    protected void txtEndDate_TextChanged(object sender, EventArgs e)
    {
        OnChangeEvent();
    }
    protected void ddlKPIYear_SelectedIndexChanged(object sender, EventArgs e)
    {
        OnChangeEvent();
    }
    protected void ddldocStatus_SelectedIndexChanged(object sender, EventArgs e)
    {
        OnChangeEvent();
    }
    protected void ddlEmployee_SelectedIndexChanged(object sender, EventArgs e)
    {
        OnChangeEvent();
    }
    protected void ddlDateRead_SelectedIndexChanged(object sender, EventArgs e)
    {
        OnChangeEvent();
    }
    #endregion


}