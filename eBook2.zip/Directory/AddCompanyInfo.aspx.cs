﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

public partial class Directory_addCompanyInfo : System.Web.UI.Page
{
    string connValue = System.Configuration.ConfigurationManager.ConnectionStrings["EBSDEBookConn"].ConnectionString;
    int updCOID = 0;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (HttpContext.Current.Session["UserID"] != null)
        {
            if (!IsPostBack)
            {
                updCOID = Convert.ToInt32(Request.QueryString["companyID"]);
                PopulateDropDownBox(ddlCat, "SELECT companyCatID, categoryName FROM COMPANYCATEGORY; ", "companyCatID", "categoryName");
                PopulateDropDownBox(ddlType, "SELECT companyTypeID, companyType FROM  COMPANYTYPE", "companyTypeID", "companyType");

                if (updCOID != 0)
                {
                    getCompanyInfo(updCOID);
                    Session["updCmpID"] = updCOID.ToString();
                }
            }

        }
        else
        {
            Response.Redirect("~/LoginPage.aspx");
        }
    }
    private void getCompanyInfo(int updCOID)
    {
        string sqlQuery = "SELECT companyID, cmpName, cmpShortName, cmpRole, cmpCatID, cmpTypeID, address1, address2, address3, city, country, " +
        " postCode, telephone, fax, emailAddress, nationality, " +
        " qatariShare, crNo, CONVERT(nvarchar, crExpiryDate, 103) AS crExpiryDate, comments, blockListed, webPage, zip, state, remarks FROM   Company WHERE (companyID = " + updCOID + ") "; //JobNo 

        SqlConnection objCon = new SqlConnection(connValue);
        objCon.Open();
        SqlCommand objCmd = new SqlCommand(sqlQuery, objCon);
        SqlDataReader sqlReader = objCmd.ExecuteReader();
        while (sqlReader.Read())
        {
            txtCmpName.Text = sqlReader["cmpName"].ToString();
            txtAddress.Text = sqlReader["address1"].ToString();
            txtCity.Text = sqlReader["city"].ToString();
            // txtCmpName.Text = sqlReader["cmpID"].ToString();

            txtCountry.Text = sqlReader["country"].ToString();
            txtCRno.Text = sqlReader["crNo"].ToString();

            txtCRRegistr.Text = sqlReader["crExpiryDate"].ToString();
            txtEmail.Text = sqlReader["emailAddress"].ToString();

            txtFaxNo.Text = sqlReader["fax"].ToString();
            txtNationality.Text = sqlReader["nationality"].ToString();

            // txtNote.Text = sqlReader["address1"].ToString();
            txtQataryShare.Text = sqlReader["qatariShare"].ToString();

            txtShortName.Text = sqlReader["cmpShortName"].ToString();
            txtState.Text = sqlReader["state"].ToString();

            txtTelNo.Text = sqlReader["telephone"].ToString();
            txtWebPage.Text = sqlReader["webpage"].ToString();

            txtZipCode.Text = sqlReader["zip"].ToString();
            txtNote.Text = sqlReader["remarks"].ToString();
            ddlCat.SelectedValue = sqlReader["cmpCatID"].ToString();
            chkBlockListCmp.Checked = Convert.ToBoolean(sqlReader["blockListed"].ToString());
            ddlType.SelectedValue = sqlReader["cmpTypeID"].ToString();
        }
        sqlReader.Close();
        objCon.Close();
    }
    private void PopulateDropDownBox(DropDownList ddlBox, string sqlQuery, string valueMember, string displayName)
    {
        DataTable table = new DataTable();
        try
        {
            using (SqlConnection sqlConn = new SqlConnection(connValue))
            {
                using (SqlDataAdapter da = new SqlDataAdapter(sqlQuery, sqlConn))
                {
                    sqlConn.Open();
                    da.Fill(table);
                }
            }
            //cmbBox.Items.Add("Select");
            ddlBox.DataSource = table;

            ddlBox.DataTextField = displayName;
            ddlBox.DataValueField = valueMember;

            ddlBox.DataBind();

            //  ddlBox.Items.Insert(0, new ListItem("--Select--"));

            ListItem emptyItem = new ListItem("", "");
            ddlBox.Items.Insert(0, emptyItem);

            ddlBox.SelectedIndex = 0;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    private int MaxCompanyID()
    {
        int UserID = 0;
        try
        {
            SqlConnection sqlConn = new SqlConnection(connValue);
            sqlConn.Open();
            SqlCommand sqlCom = new SqlCommand("select max(companyID) from COMPANY", sqlConn);
            SqlDataReader sqlReader = sqlCom.ExecuteReader();
            sqlReader.Read();
            UserID = Convert.ToInt32(sqlReader[0]) + 1;
            sqlReader.Close();
            sqlConn.Close();
        }
        catch (Exception ex)
        {
            throw ex;
        }
        return UserID;
    }
    private void InsertComapnyInfo()
    {
        //if (ValidateControls() == false)
        //    return;

        int maxCmpID = MaxCompanyID();
        //companyID, 
        string insertQuery = "INSERT INTO COMPANY(cmpName, cmpCatID,cmpTypeID,cmpShortName,address1,city, " +
                             " state,country,zip,comments, blockListed, telephone,fax,emailAddress,nationality, " +      //crExpiryDate   ,@cr_expiry_date
        "qatariShare,CRNo,WebPage,remarks,cr_expiry_date) " +           //, QS_Name ,@QS_Name
                             " VALUES(@co_name,@co_category_id,@co_type_id,@co_shortname,@co_address,@co_city,@co_state,@co_country,@co_zip,@co_comments,@block_listed,@co_tel, " +
        "@co_fax,@co_email_address,@nationality,@qatari_share,@CRNo,@WebPage,@Remarks,@cr_expiry_date)";

        try
        {
            SqlConnection sqlCon = new SqlConnection(connValue);
            sqlCon.Open();

            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = insertQuery;
            cmd.Connection = sqlCon;

            // cmd.Parameters.AddWithValue("@Co_ID", maxCmpID);
            cmd.Parameters.AddWithValue("@co_name", txtCmpName.Text);
            cmd.Parameters.AddWithValue("@co_category_id", ddlCat.SelectedValue);
            cmd.Parameters.AddWithValue("@co_type_id", ddlType.SelectedValue);

            cmd.Parameters.AddWithValue("@co_shortname", txtShortName.Text);
            cmd.Parameters.AddWithValue("@co_address", txtAddress.Text);
            cmd.Parameters.AddWithValue("@co_city", txtCity.Text);

            cmd.Parameters.AddWithValue("@co_state", txtState.Text);
            cmd.Parameters.AddWithValue("@co_country", txtCountry.Text);

            cmd.Parameters.AddWithValue("@co_zip", txtZipCode.Text);
            cmd.Parameters.AddWithValue("@co_comments", txtNote.Text);
            cmd.Parameters.AddWithValue("@block_listed", chkBlockListCmp.Checked);
            cmd.Parameters.AddWithValue("@co_tel", txtTelNo.Text);

            cmd.Parameters.AddWithValue("@co_fax", txtFaxNo.Text);
            cmd.Parameters.AddWithValue("@co_email_address", txtEmail.Text);
            cmd.Parameters.AddWithValue("@nationality", txtNationality.Text);


            // cmd.Parameters.AddWithValue("@cr_expiry_date", "");
            cmd.Parameters.AddWithValue("@qatari_share", txtQataryShare.Text);
            cmd.Parameters.AddWithValue("@CRNo", txtCRno.Text);

            cmd.Parameters.AddWithValue("@WebPage", txtWebPage.Text);
            cmd.Parameters.AddWithValue("@Remarks", txtNote.Text);
            if (txtCRRegistr.Text != "")
                cmd.Parameters.AddWithValue("@cr_expiry_date", Convert.ToDateTime(txtCRRegistr.Text).ToString("dd/MMM/yyyy"));
            else
                cmd.Parameters.AddWithValue("@cr_expiry_date", System.DBNull.Value);

            cmd.ExecuteNonQuery();
            sqlCon.Close();

            Response.Write("JobOrder Data Added Successfully");
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    private Boolean ValidateControls()
    {
        Boolean chkCntrl = true;
        if (txtCmpName.Text == "")
        {
            // Response.Write("<script language='javascript'>alert('Please Enter JobNo');</script>");
            chkCntrl = false;
        }
        if (ddlCat.SelectedIndex == 0)
        {
            // Response.Write("<script language='javascript'>alert('Please Select Category');</script>");
            chkCntrl = false;
        }
        if (ddlType.SelectedIndex == 0)
        {
            //Response.Write("<script language='javascript'>alert('Please Select DocRef');</script>");
            chkCntrl = false;
        }
        if (txtShortName.Text == "")
        {
            // Response.Write("<script language='javascript'>alert('Please Enter JobNo');</script>");
            chkCntrl = false;
        }

        return chkCntrl;
    }
    private void UpdateCompanyInfo(int updCOID)
    {
        if (!ValidateControls())
            return;

        //string insertQuery = "UPDATE COMPANY SET companyID = @Co_ID, cmpName = @co_name, cmpCatId =@co_category_id,cmpTypeId = @co_type_id ,ShortName =@co_shortname,co_address = @co_address,co_city =@co_city, " +
        //                     " state = @co_state,country =@co_country,zip =@co_zip,co_comments =@co_comments, blockListed =@block_listed, telephone =@co_tel, country =@co_country,co_zip =@co_zip,co_comments =@co_comments," +
        //" block_listed =@block_listed,telephone =@co_tel,fax =@co_fax,emailAddress =@co_email_address " +
        //"nationality =@nationality ,crExpiryDate =@cr_expiry_date,qatariShare =@qatari_share,CRNo =@CRNo,WebPage =@WebPage,remarks =@Remarks WHERE companyID =@co_ID ";       //, QS_Name ,@QS_Name                


        string insertQuery = "UPDATE COMPANY SET  cmpName = @co_name, cmpCatId =@co_category_id,cmpTypeId = @co_type_id ,cmpShortName =@co_shortname, " +
        " address1 = @co_address,city =@co_city,  state = @co_state,country =@co_country,zip =@co_zip,comments =@co_comments, blockListed =@block_listed, " +
        " telephone =@co_tel, fax =@co_fax,emailAddress =@co_email_address, " +
        " nationality =@nationality ,crExpiryDate =@cr_expiry_date,qatariShare =@qatari_share,CRNo =@CRNo,WebPage =@WebPage,remarks =@Remarks WHERE companyID =@co_ID ";       //, QS_Name ,@QS_Name                

        try
        {
            SqlConnection sqlCon = new SqlConnection(connValue);
            sqlCon.Open();

            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = insertQuery;
            cmd.Connection = sqlCon;

            cmd.Parameters.AddWithValue("@Co_ID", Convert.ToInt32(Session["updCmpID"]));
            cmd.Parameters.AddWithValue("@co_name", txtCmpName.Text);
            cmd.Parameters.AddWithValue("@co_category_id", ddlCat.SelectedValue);
            cmd.Parameters.AddWithValue("@co_type_id", ddlType.SelectedValue);

            cmd.Parameters.AddWithValue("@co_shortname", txtShortName.Text);
            cmd.Parameters.AddWithValue("@co_address", txtAddress.Text);
            cmd.Parameters.AddWithValue("@co_city", txtCity.Text);

            cmd.Parameters.AddWithValue("@co_state", txtState.Text);
            cmd.Parameters.AddWithValue("@co_country", txtCountry.Text);

            cmd.Parameters.AddWithValue("@co_zip", txtZipCode.Text);
            cmd.Parameters.AddWithValue("@co_comments", txtNote.Text);
            cmd.Parameters.AddWithValue("@block_listed", chkBlockListCmp.Checked);
            cmd.Parameters.AddWithValue("@co_tel", txtTelNo.Text);

            cmd.Parameters.AddWithValue("@co_fax", txtFaxNo.Text);
            cmd.Parameters.AddWithValue("@co_email_address", txtEmail.Text);
            cmd.Parameters.AddWithValue("@nationality", txtNationality.Text);
            if (txtCRRegistr.Text != "")
                cmd.Parameters.AddWithValue("@cr_expiry_date", Convert.ToDateTime(txtCRRegistr.Text).ToString("dd/MMM/yyyy"));
            else
                cmd.Parameters.AddWithValue("@cr_expiry_date", System.DBNull.Value);
            cmd.Parameters.AddWithValue("@qatari_share", txtQataryShare.Text);
            cmd.Parameters.AddWithValue("@CRNo", txtCRno.Text);

            cmd.Parameters.AddWithValue("@WebPage", txtWebPage.Text);
            cmd.Parameters.AddWithValue("@Remarks", txtNote.Text);

            cmd.ExecuteNonQuery();
            sqlCon.Close();

            // Response.Write("JobOrder Data Added Successfully");
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    protected void btnSave_Click(object sender, EventArgs e)
    {
        if (Convert.ToInt32(Session["updCmpID"]) == 0)
            InsertComapnyInfo();
        else
            UpdateCompanyInfo(Convert.ToInt32(Session["updCmpID"]));


        //string script = "this.window.opener.location=this.window.opener.location;this.window.close();";
        //if (!ClientScript.IsClientScriptBlockRegistered("REFRESH_PARENT"))
        //{
        //    ClientScript.RegisterClientScriptBlock(typeof(string), "REFRESH_PARENT", script, true);
        //}

        ScriptManager.RegisterStartupScript(this, typeof(string), "script",
                 "<script type=text/javascript> parent.location.href = parent.location.href;</script>", false);
    }
    public void RedirectToSpecificPage()
    {
        object refUrl = Session["UrlRef"];
        if (refUrl != null)
            Response.Redirect(refUrl.ToString(), false);
        else
            Response.Redirect("~/ViewCompany.aspx", false);
    }
    protected void txtCRRegistr_TextChanged(object sender, EventArgs e)
    {

    }
}