﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using Datalayer;

public partial class Directory_ViewCompany : System.Web.UI.Page
{
    string connValue = System.Configuration.ConfigurationManager.ConnectionStrings["EBSDEBookConn"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            FillGridView_Details();
            PopulateDropDownBox(ddlCmpCat, "SELECT companyCatID, categoryName FROM  companyCategory ORDER BY categoryName ", "companyCatID", "categoryName");
            PopulateDropDownBox(ddlCmpType, "SELECT companyTypeID, companyType FROM  companyType ORDER BY companyType ", "companyTypeID", "companyType");
        }
    }

    private DataTable FillGridView_Details()
    {
        string sqlQuery = "SELECT cmpName, cmpShortname, nationality, telephone, emailAddress, WebPage, companyID FROM COMPANY "; //JobNo 
        SqlConnection objCon = new SqlConnection(connValue);
        SqlCommand objCmd = new SqlCommand(sqlQuery, objCon);
        SqlDataAdapter objDA = new SqlDataAdapter(objCmd);

        objDA.SelectCommand.CommandText = objCmd.CommandText.ToString();
        DataTable dt = new DataTable();
        objDA.Fill(dt);

        gridJobs.DataSource = dt.DefaultView;
        gridJobs.DataBind();

        Session["company"] = dt;

        return dt;

        // lblCnt.Text = " Jobs Count :  " + gridJobs.Rows.Count.ToString();
    }
    private void Search_Details()
    {
        string sqlQuery = "SELECT cmpName, cmpShortname, nationality, telephone, emailAddress, WebPage, companyID FROM COMPANY Where cmpName Like '" + txtCmpName.Text + "%" + "'"; //JobNo 
        SqlConnection objCon = new SqlConnection(connValue);
        SqlCommand objCmd = new SqlCommand(sqlQuery, objCon);
        SqlDataAdapter objDA = new SqlDataAdapter(objCmd);

        objDA.SelectCommand.CommandText = objCmd.CommandText.ToString();
        DataTable dt = new DataTable();
        objDA.Fill(dt);       

        gridJobs.DataSource = dt.DefaultView;
        gridJobs.DataBind();

        // lblCnt.Text = " Jobs Count :  " + gridJobs.Rows.Count.ToString();
    }
    protected void gridJobs_RowCommand(object sender, GridViewCommandEventArgs e)
    {

    }
    protected void btnSearch_Click(object sender, EventArgs e)
    {
        Search_Details();
    }
    protected void chkview_CheckedChanged(object sender, EventArgs e)
    {
        Response.Write("CheckBox fired.");
    }
    protected void btnAdd_Click(object sender, EventArgs e)
    {
       // Response.Write("<script language='javascript'> window.open('AddCompanyInfo.aspx','','width=830,Height=550,fullscreen=1,location=0,scrollbars=0,menubar=1,toolbar=1, align=center,top=100,left=500'); </script>");
    }
    private void PopulateDropDownBox(DropDownList ddlBox, string sqlQuery, string valueMember, string displayName)
    {
        ddlBox.DataSource = new JobOrderData().FillDropdown(sqlQuery);
        ddlBox.DataTextField = displayName;
        ddlBox.DataValueField = valueMember;
        ddlBox.SelectedIndex = -1;
        ddlBox.DataBind();
        ddlBox.Items.Insert(0, new ListItem("--Select--"));
    }
    protected void gridJobs_PageIndexChanged(object sender, EventArgs e)
    {

    }
    protected void gridJobs_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        gridJobs.PageIndex = e.NewPageIndex;
        bindGridView();

        //gridJobs.DataSource = dt;
        //gridJobs.DataBind();

        FillGridView_Details();
    }
    private void bindGridView()
    {
        gridJobs.DataSource = Session["company"];
        gridJobs.DataBind();
    }
}