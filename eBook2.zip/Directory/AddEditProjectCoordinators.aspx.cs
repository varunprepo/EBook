﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

public partial class Directory_AddEditProjectCoordinators : System.Web.UI.Page
{
    string connValue = System.Configuration.ConfigurationManager.ConnectionStrings["EBSDEBookConn"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (HttpContext.Current.Session["UserID"] != null)
            {
                if (Request.QueryString["prjCoordID"] != null)
                {
                    tdProjCoordHeader.InnerText = "Edit Project Coordinators Details";
                    ReadProjectCoordinatorInfo(Request.QueryString["prjCoordID"].ToString());
                }
            }
            else
            {
                Response.Redirect("~/LoginPage.aspx");
            }
        }
    }

    protected void btnAdd_Click(object sender, EventArgs e)
    {
        if (Request.QueryString["prjCoordID"] == null)
        {
            if (!CheckProjCoordNameExistsBeforeInserting())
            {
                InsertProjectCoordinatorInfo();
               // ClientScript.RegisterClientScriptBlock(this.GetType(), "Popup", "<script>alert('Successfully inserted project coordinator information')</script>", false);    
                string script = "this.window.opener.location=this.window.opener.location;this.window.close();";
                if (!ClientScript.IsClientScriptBlockRegistered("REFRESH_PARENT"))
                    ClientScript.RegisterClientScriptBlock(typeof(string), "REFRESH_PARENT", script, true);
                return;
            }
            else
            {
                ClientScript.RegisterClientScriptBlock(this.GetType(), "Popup", "<script>alert('Project coordinator name already exists, enter a unique name.')</script>", false);  
            }
        }
        else
        {
            if (!CheckProjCoordNameExistsBeforeUpdating(Request.QueryString["prjCoordID"].ToString()))
            {
                UpdateProjectCoordinatorInfo(Request.QueryString["prjCoordID"].ToString());
               // ClientScript.RegisterClientScriptBlock(this.GetType(), "Popup", "<script>alert('Successfully updated project coordinator information')</script>", false);
               
                string script = "this.window.opener.location=this.window.opener.location;this.window.close();";
                if (!ClientScript.IsClientScriptBlockRegistered("REFRESH_PARENT"))
                    ClientScript.RegisterClientScriptBlock(typeof(string), "REFRESH_PARENT", script, true);
                return;
            }
            else
            {
                ClientScript.RegisterClientScriptBlock(this.GetType(), "Popup", "<script>alert('Project coordinator name already exists, enter a unique name.');</script>", false); 
            }
        }
      
    }

    private void InsertProjectCoordinatorInfo()
    {
        //if (ValidateControls() == false)
        //    return;

        //  int maxCmpID = MaxCompanyID();

        string insertQuery = "INSERT INTO ProjCoordinator(coordName,eMail,phoneNo) VALUES(@coordName,@eMail,@phoneNo)";

        try
        {
            SqlConnection sqlCon = new SqlConnection(connValue);
            sqlCon.Open();

            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = insertQuery;
            cmd.Connection = sqlCon;

            cmd.Parameters.AddWithValue("@coordName", txtProjCoordFullName.Text.Trim());

            cmd.Parameters.AddWithValue("@eMail", txtProjCoordEmailId.Text.Trim());

            cmd.Parameters.AddWithValue("@phoneNo", txtProjCoordMobilePhone.Text.Trim());                    

            cmd.ExecuteNonQuery();
            cmd.Dispose();
            sqlCon.Close();
        }
        catch (Exception ex)
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "Popup", "<script>alert('Error Occurred while inserting project coordinator info.')</script>", false);   // later than
        }

        //string script = "this.window.opener.location=this.window.opener.location;this.window.close();";
        //if (!ClientScript.IsClientScriptBlockRegistered("REFRESH_PARENT"))
        //{
        //    ClientScript.RegisterClientScriptBlock(typeof(string), "REFRESH_PARENT", script, true);
        //}

    }

    private void ReadProjectCoordinatorInfo(string projCoordId)
    {

        string selectQuery = "select coordName,eMail,phoneNo from ProjCoordinator where prjCoordID=@prjCoordID";

        try
        {
            SqlConnection sqlCon = new SqlConnection(connValue);
            sqlCon.Open();

            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = selectQuery;
            cmd.Connection = sqlCon;
            cmd.Parameters.AddWithValue("@prjCoordID", projCoordId);
            SqlDataReader sqlDtRead = cmd.ExecuteReader();

            if (sqlDtRead.Read())
            {
                txtProjCoordFullName.Text = sqlDtRead[0].ToString();

                txtProjCoordEmailId.Text = sqlDtRead[1].ToString();

                txtProjCoordMobilePhone.Text = sqlDtRead[2].ToString();
                
            }

            sqlDtRead.Close();
            cmd.Dispose();
            sqlCon.Close();

        }
        catch (Exception ex)
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "Popup", "<script>alert('Error Occurred while reading project coordinator info.')</script>", false);   // later than
        }    

    }

    private void UpdateProjectCoordinatorInfo(string projCoordId)
    {

        string updateQuery = "Update ProjCoordinator set coordName=@coordName,eMail=@eMail,phoneNo=@phoneNo where prjCoordID=@prjCoordID";

        try
        {
            SqlConnection sqlCon = new SqlConnection(connValue);
            sqlCon.Open();

            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = updateQuery;
            cmd.Connection = sqlCon;

            cmd.Parameters.AddWithValue("@coordName", txtProjCoordFullName.Text.Trim());

            cmd.Parameters.AddWithValue("@eMail", txtProjCoordEmailId.Text.Trim());

            cmd.Parameters.AddWithValue("@phoneNo", txtProjCoordMobilePhone.Text.Trim());

            cmd.Parameters.AddWithValue("@prjCoordID", projCoordId);

            cmd.ExecuteNonQuery();
            cmd.Dispose();
            sqlCon.Close();
        }
        catch (Exception ex)
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "Popup", "<script>alert('Error Occurred while updating project coordinator info.')</script>", false);   // later than
        }

    }
   
    private bool CheckProjCoordNameExistsBeforeInserting()
    {
        bool isProjCoordExist = false;
        try
        {
            string sqlQuery = "SELECT prjCoordID FROM ProjCoordinator where coordName = '" + txtProjCoordFullName.Text.Trim() + "'";
            SqlConnection objCon = new SqlConnection(connValue);
            objCon.Open();
            SqlCommand objCmd = new SqlCommand(sqlQuery, objCon);
            SqlDataReader sqlReader = objCmd.ExecuteReader();

            if (sqlReader.Read())
            {
                isProjCoordExist = true;
            }
            else
            {
                isProjCoordExist = false;
            }
            sqlReader.Close();
            objCmd.Dispose();
            objCon.Close();
        }
        catch (Exception)
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "Popup", "<script>alert('Error Occurred while checking project coordinator name')</script>", false);   // later than
        }
        return isProjCoordExist;
    }
    private bool CheckProjCoordNameExistsBeforeUpdating(string prjCoordID)
    {
        bool isProjCoordExist = false;
        try
        {
            string sqlQuery = "SELECT prjCoordID FROM ProjCoordinator where coordName = '" + txtProjCoordFullName.Text.Trim() + "' and prjCoordID<>" + prjCoordID;
            SqlConnection objCon = new SqlConnection(connValue);
            objCon.Open();
            SqlCommand objCmd = new SqlCommand(sqlQuery, objCon);
            SqlDataReader sqlReader = objCmd.ExecuteReader();

            if (sqlReader.Read())
            {
                isProjCoordExist = true;
            }
            else
            {
                isProjCoordExist = false;
            }
            sqlReader.Close();
            objCmd.Dispose();
            objCon.Close();
        }
        catch (Exception)
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "Popup", "<script>alert('Error Occurred while checking project coordinator name')</script>", false);   // later than
        }
        return isProjCoordExist;
    }
    private Boolean CheckprjCoordinatorIDExist(int prjCoordID)
    {
        Boolean isProjCoordExist = false;
        try
        {
            string sqlQuery = "SELECT projCoordinatorID FROM Job where projCoordinatorID = " + prjCoordID;
            SqlConnection objCon = new SqlConnection(connValue);
            objCon.Open();
            SqlCommand objCmd = new SqlCommand(sqlQuery, objCon);
            SqlDataReader sqlReader = objCmd.ExecuteReader();

            if (sqlReader.HasRows)
            {
                isProjCoordExist = true;
            }
            else
            {
                isProjCoordExist = false;
            }
            sqlReader.Close();
            objCmd.Dispose();
            objCon.Close();
        }
        catch (Exception)
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "Popup", "<script>alert('Error Occurred while checking project coordinator name')</script>", false);   // later than
        }
        return isProjCoordExist;
    }
    protected void btnDelete_Click(object sender, EventArgs e)
    {
        if (Request.QueryString["prjCoordID"] != null)
        {
            Boolean jobPrjCoord = CheckprjCoordinatorIDExist(Convert.ToInt32(Request.QueryString["prjCoordID"].ToString()));

            if (jobPrjCoord == true)
            {
                ClientScript.RegisterClientScriptBlock(this.GetType(), "Popup", "<script>alert('This Project Coordinator already associated with Job')</script>", false);
                return;
            }

            string deleteQuery = "delete from ProjCoordinator where prjCoordID=@prjCoordID";
            try
            {
                SqlConnection sqlCon = new SqlConnection(connValue);
                sqlCon.Open();

                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = deleteQuery;
                cmd.Connection = sqlCon;
                cmd.Parameters.AddWithValue("@prjCoordID", Request.QueryString["prjCoordID"].ToString());
                cmd.ExecuteNonQuery();
                cmd.Dispose();
                sqlCon.Close();
              
                string script = "this.window.opener.location=this.window.opener.location;this.window.close();";
                if (!ClientScript.IsClientScriptBlockRegistered("REFRESH_PARENT"))
                    ClientScript.RegisterClientScriptBlock(typeof(string), "REFRESH_PARENT", script, true);
                return;
            }
            catch (Exception)
            {
                ClientScript.RegisterClientScriptBlock(this.GetType(), "Popup", "<script>alert('Error Occurred while deleting project coordinator info.')</script>", false);   // later than
            }
        }
    }
    protected void btnSave_Click(object sender, EventArgs e)
    {
        if (Request.QueryString["prjCoordID"] == null)
        {
            if (!CheckProjCoordNameExistsBeforeInserting())
            {
                InsertProjectCoordinatorInfo();
                // ClientScript.RegisterClientScriptBlock(this.GetType(), "Popup", "<script>alert('Successfully inserted project coordinator information')</script>", false);    
                string script = "this.window.opener.location=this.window.opener.location;this.window.close();";
                if (!ClientScript.IsClientScriptBlockRegistered("REFRESH_PARENT"))
                    ClientScript.RegisterClientScriptBlock(typeof(string), "REFRESH_PARENT", script, true);
                return;
            }
            else
            {
                ClientScript.RegisterClientScriptBlock(this.GetType(), "Popup", "<script>alert('Project coordinator name already exists, enter a unique name.')</script>", false);
            }
        }
        else
        {
            if (!CheckProjCoordNameExistsBeforeUpdating(Request.QueryString["prjCoordID"].ToString()))
            {
                UpdateProjectCoordinatorInfo(Request.QueryString["prjCoordID"].ToString());
                // ClientScript.RegisterClientScriptBlock(this.GetType(), "Popup", "<script>alert('Successfully updated project coordinator information')</script>", false);

                string script = "this.window.opener.location=this.window.opener.location;this.window.close();";
                if (!ClientScript.IsClientScriptBlockRegistered("REFRESH_PARENT"))
                    ClientScript.RegisterClientScriptBlock(typeof(string), "REFRESH_PARENT", script, true);
                return;
            }
            else
            {
                ClientScript.RegisterClientScriptBlock(this.GetType(), "Popup", "<script>alert('Project coordinator name already exists, enter a unique name.');</script>", false);
            }
        }
    }
    protected void txtProjCoordEmailId_TextChanged(object sender, EventArgs e)
    {

    }
}