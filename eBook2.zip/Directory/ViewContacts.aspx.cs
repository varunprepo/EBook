﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Web.UI.HtmlControls;
public partial class Directory_ViewContacts : System.Web.UI.Page
{
    string connValue = System.Configuration.ConfigurationManager.ConnectionStrings["EBSDEBookConn"].ConnectionString;   
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            FillGridView_Details();
        }
    }
    private void FillGridView_Details()
    {
        string sqlQuery = "SELECT (Contact.firstName + '  ' + Contact.lastName) as firstName, Contact.jobPosition, Contact.homePhone, Contact.mobPhone, Contact.officePhone, Contact.faxNumber, Company.cmpName, " +
                         " Contact.emailAddress, Contact.contactID, Contact.firstName FROM  Contact INNER JOIN  Company ON Contact.companyID = Company.companyID Order By Contact.firstName ";

        SqlConnection objCon = new SqlConnection(connValue);
        SqlCommand objCmd = new SqlCommand(sqlQuery, objCon);
        SqlDataAdapter objDA = new SqlDataAdapter(objCmd);

        objDA.SelectCommand.CommandText = objCmd.CommandText.ToString();
        DataTable dt = new DataTable();
        objDA.Fill(dt);

        gridJobs.DataSource = dt.DefaultView;
        gridJobs.DataBind();

        Session["contactData"]= dt;

        // lblCnt.Text = " Jobs Count :  " + gridJobs.Rows.Count.ToString();
    }
    private void Search_Details()
    {
        string sqlQuery = "SELECT  (Contact.firstName + '  ' +Contact.lastName) as firstName, Contact.jobPosition, Contact.homePhone, Contact.mobPhone, Contact.officePhone, Contact.faxNumber, Company.cmpName, " +
                         " Contact.emailAddress, Contact.contactID, Contact.firstName FROM  Contact INNER JOIN  Company ON Contact.companyID = Company.companyID  Where (Contact.firstName + '  ' +Contact.lastName) Like '" + "%" + txtUserSearch.Text + "%" + "' "; //JobNo 
      
        SqlConnection objCon = new SqlConnection(connValue);
        SqlCommand objCmd = new SqlCommand(sqlQuery, objCon);
        SqlDataAdapter objDA = new SqlDataAdapter(objCmd);

        objDA.SelectCommand.CommandText = objCmd.CommandText.ToString();
        DataTable dt = new DataTable();
        objDA.Fill(dt);

        gridJobs.DataSource = dt.DefaultView;
        gridJobs.DataBind();

        // lblCnt.Text = " Jobs Count :  " + gridJobs.Rows.Count.ToString();
    }
    protected void chkview_CheckedChanged(object sender, EventArgs e)
    {
        Response.Write("CheckBox fired.");
    }
    protected void gridJobs_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void gridJobs_RowDataBound(object sender, GridViewRowEventArgs e)
    {

    }
    protected void gridJobs_RowCommand(object sender, GridViewCommandEventArgs e)
    {

    }
    protected void btnSearch_Click(object sender, EventArgs e)
    {
        Search_Details();
    }
    protected void lnkBtnAddContact_Click(object sender, EventArgs e)
    {
        try
        {
            LinkButton lnkDistributrID = (LinkButton)sender;
            GridViewRow gvr = (GridViewRow)lnkDistributrID.NamingContainer;
            string cntctID = ((HtmlGenericControl)gvr.FindControl("divCntctID")).InnerText;
          

           // Response.Redirect("~/Directory/AddContactsInfo.aspx?contactID=" + cntctID + "", false);

            UtilityClass utils = null;
            try
            {
                utils = new UtilityClass(this.Page);
                string url = Request.Url.AbsoluteUri;
                Session["Url"] = Request.Url.AbsoluteUri;
                if (url.Contains(":"))
                    url = url.Substring(0, utils.GetNthIndex(url, '/', 4));
                else
                    url = url.Substring(0, utils.GetNthIndex(url, '/', 2));
                url = url + "/Directory/AddContactsInfo.aspx?contactID=" + cntctID + "";
                OpenPageByUsingJS(url, "730", "800");
            }
            catch (Exception ex)
            {
                this.Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Error occurred while processing the request')</script>", false);
            }
        }
        catch (Exception ex)
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Error occurred while processing the request')</script>", false);
        }
    }   
    protected void btnAdd_Click(object sender, EventArgs e)
    {
        UtilityClass utils = null;
        try
        {
            utils = new UtilityClass(this.Page);
            string url = Request.Url.AbsoluteUri;
            Session["Url"] = Request.Url.AbsoluteUri;
            if (url.Contains(":"))
                url = url.Substring(0, utils.GetNthIndex(url, '/', 4));
            else
                url = url.Substring(0, utils.GetNthIndex(url, '/', 2));
            url = url + "/Directory/AddContactsInfo.aspx";
            OpenPageByUsingJS(url, "850", "580");
        }
        catch (Exception ex)
        {
            this.Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Error occurred while processing the request')</script>", false);
        }
    }
    private void OpenPageByUsingJS(string url, string width, string height)
    {
        string s = "window.open('" + url + "', 'popup_window', 'width=" + width + ",height=" + height + "left=100,top=100,resizable=yes');";
        Page.ClientScript.RegisterStartupScript(this.GetType(), "script", s, true);
    }
    protected void btnDelete_Click(object sender, EventArgs e)
    {
        // $("[id*=btnAdd]").live("click", function () {
        //        $("#dialog").dialog({
        //            title: "Contact Information ",
        //            height: 580,
        //            width: 876,

        //            buttons: {
        //                Close: function () {
        //                    $(this).dialog('close');
        //                }
        //            }
        //        });
        //        return false;
        //    });
        //});

    }
    protected void gridJobs_PageIndexChanging(object sender, System.Web.UI.WebControls.GridViewPageEventArgs e)
    {
        gridJobs.PageIndex = e.NewPageIndex;
        bindGridView();

        FillGridView_Details();
    }
    private void bindGridView()
    {
        gridJobs.DataSource = Session["contactData"];
        gridJobs.DataBind();
    }
    protected void btnClear_Click(object sender, EventArgs e)
    {
        txtUserSearch.Text = "";
        FillGridView_Details();
    }
    protected void txtUser_TextChanged(object sender, EventArgs e)
    {

    }
}