﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using Datalayer;

public partial class Directory_addContactsInfo : System.Web.UI.Page
{
    string connValue = System.Configuration.ConfigurationManager.ConnectionStrings["EBSDEBookConn"].ConnectionString;
    static int _contactID = 0;
    protected void Page_Load(object sender, EventArgs e)
    {
        _contactID = 0;

        if (HttpContext.Current.Session["UserID"] != null)
        {
            if (Request.QueryString["contactID"]!=null)
                _contactID = Convert.ToInt32(Request.QueryString["contactID"]);

            if (Session["FromMstr"] != null)
            {
                if (Session["FromMstr"].ToString() == "True")
                    _contactID = Convert.ToInt32(Session["UserID"]);
            }
        
            if (!IsPostBack)
            {
                PopulateDropDownBox(ddlSection, "SELECT SectionID, SectionName FROM Section", "SectionID", "SectionName");
                PopulateDropDownBox(ddlTeamLead, "SELECT teamLeaderID, teamLeaderName FROM EBSDTeamLeaders", "teamLeaderID", "teamLeaderName");
                PopulateDropDownBox(ddlCmp, "SELECT companyID, cmpName FROM Company ORDER BY cmpName", "companyID", "cmpName");

                PopulateDropDownBox(drpRole, "SELECT jobOwnerCatID,jobOwnerCategory FROM JobOwnerCategory", "jobOwnerCatID", "jobOwnerCategory");

                if (_contactID != 0)
                {
                    // getCompanyInfo(updcntID);
                    Session["updcntID"] = _contactID.ToString();
                    getContactInfo(_contactID);

                    if (!Session["userProfileID"].ToString().Equals("1"))
                    {
                        ddlSection.Enabled = false;
                        ddlCmp.Enabled = false;
                    }
                }
            }
        }
        else
        {
            Response.Redirect("~/LoginPage.aspx");
        }
    }
    private void PopulateDropDownBox_TCMS(DropDownList ddlBox, string sqlQuery, string valueMember, string displayName)
    {
        ddlBox.DataBound += new EventHandler(this.ddlBox_DataBound);
        ddlBox.DataSource = new JobOrderData().FillDropdown_TCMS(sqlQuery);
        ddlBox.DataTextField = displayName;
        ddlBox.DataValueField = valueMember;
        ddlBox.SelectedIndex = -1;
        ddlBox.DataBind();
    }
    protected void ddlBox_DataBound(object sender, EventArgs e)
    {
        DropDownList ddl = (DropDownList)sender;
        ListItem emptyItem = new ListItem("", "");
        ddl.Items.Insert(0, emptyItem);
    }
    private string AddUser(int contactID)
    {       
        using (SqlConnection sqlConn = new SqlConnection(connValue))
        {
            using (SqlCommand sqlCmd = new SqlCommand())
            {
                try
                {
                    sqlCmd.Parameters.AddWithValue("@firstName", txtFirstName.Text.Trim());
                    sqlCmd.Parameters.AddWithValue("@lastName", txtLastName.Text.Trim());
                    sqlCmd.Parameters.AddWithValue("@middleName", System.DBNull.Value);
                    sqlCmd.Parameters.AddWithValue("@companyID", ddlCmp.SelectedValue);
                    sqlCmd.Parameters.AddWithValue("@officeAddress", txtOfficeAddress.Text.Trim());
                    sqlCmd.Parameters.AddWithValue("@officePhone", txtOffTelNo.Text.Trim());

                    sqlCmd.Parameters.AddWithValue("@mobPhone", txtMobilePhone.Text.Trim());
                    sqlCmd.Parameters.AddWithValue("@country", txtCountry.Text.Trim());
                    sqlCmd.Parameters.AddWithValue("@emailAddress", txtEmailId.Text.Trim());
                   
                    sqlCmd.Parameters.AddWithValue("@jobPosition", txtJobTitle.Text.Trim());

                    if (ddlSection.SelectedIndex!=0)
                        sqlCmd.Parameters.AddWithValue("@sectionID", ddlSection.SelectedValue);
                    else
                        sqlCmd.Parameters.AddWithValue("@sectionID", 8); //guest user sectionId is not applicable = 8 

                    if (ddlTeamLead.SelectedIndex != 0)
                        sqlCmd.Parameters.AddWithValue("@teamLeaderID", ddlTeamLead.SelectedValue);
                    else
                        sqlCmd.Parameters.AddWithValue("@teamLeaderID", 6); //guest user teamLeadID is not applicable = 6                    

                    if (contactID == 0)
                        sqlCmd.Parameters.AddWithValue("@contactID", SqlDbType.SmallInt).Direction = ParameterDirection.Output;
                    else
                        sqlCmd.Parameters.AddWithValue("@contactID", contactID); 
              
                    sqlCmd.Parameters.AddWithValue("@currentUser", Session["UserName"].ToString());
                    sqlCmd.Parameters.AddWithValue("@userComments", txtRemarks.Text);

                    sqlCmd.Parameters.AddWithValue("@userShortName", txtShortName.Text);

                    sqlCmd.Parameters.AddWithValue("@isAuthRepres", chkRepresent.Checked);

                    sqlCmd.Parameters.AddWithValue("@isCoordinator", chkCoordinator.Checked);

                    sqlConn.Open();
                    sqlCmd.Connection = sqlConn;
                    sqlCmd.CommandType = CommandType.StoredProcedure;
                    sqlCmd.CommandText = "InsertUpdateContact";
                    sqlCmd.ExecuteNonQuery();


                    Session["docOrginCmpID"] = ddlCmp.SelectedValue; 

                    return sqlCmd.Parameters["@contactID"].Value.ToString(); 
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
        }

       
    }
    protected void btnAdd_Click(object sender, EventArgs e)
    {       
          Session["docSender"] =  AddUser(_contactID);      // Return contactID for Add Sender in Document Creation

          if (Request.QueryString["docFlag"] == null) 
          {
              Session["docSender"] = null;
              Session["docOrginCmpID"] = null;
          }     
      
        
        string script = "this.window.opener.location=this.window.opener.location;this.window.close();";
        if (!ClientScript.IsClientScriptBlockRegistered("REFRESH_PARENT"))
            ClientScript.RegisterClientScriptBlock(typeof(string), "REFRESH_PARENT", script, true);
      
        return;

        //Removed_valCode();        
    }
    private void Removed_valCode()
    {
        IList<string> userColl = new List<string>(); Boolean chkEmail = false;
        if (Convert.ToInt32(Session["updcntID"]) == 0)
        {
            bool userFlagInsert = ValidateUserInsert(txtFirstName.Text, txtLastName.Text, Convert.ToInt32(ddlCmp.SelectedItem.Value));
            if (userFlagInsert == true)
                InsertContactInfo();
            else
                ClientScript.RegisterClientScriptBlock(this.GetType(), "Popup", "<script>alert('User Already Exists.')</script>", false);   // later than
        }
        else
        {
            userColl = getContactDataForCheck(Convert.ToInt32(Session["updcntID"]));
            if (userColl.Count > 0)
            {
                if (userColl[3] != "")
                    chkEmail = txtEmailId.Text.Equals(userColl[2]);
            }

            bool userFlagUpdate = ValidateUserUpdate(txtFirstName.Text, txtLastName.Text, Convert.ToInt32(ddlCmp.SelectedItem.Value), Convert.ToInt32(Session["updcntID"]));
        }    
    } 
    private bool ValidateUserInsert(string firstName, string lastName, int companyID)
    {
        //IList<string> lstUserData = new List<string>();
        string sqlQuery = "SELECT Contact.contactID FROM Company INNER JOIN  Contact ON Company.companyID = Contact.companyID where firstName='" + firstName.Trim() + "' and lastName='" + lastName.Trim() + "' and Company.companyID=" + companyID + "";
        SqlConnection objCon = new SqlConnection(connValue);
        objCon.Open();
        SqlCommand objCmd = new SqlCommand(sqlQuery, objCon);
        SqlDataReader sqlReader = objCmd.ExecuteReader();

        if (sqlReader.HasRows == true)
        {
            return false;
        }
        else
        {
            return true;
        }
        // }
        sqlReader.Close();
        objCon.Close();

    }
    private bool ValidateUserUpdate(string firstName, string lastName, int companyID,int contactID)
    {
        //IList<string> lstUserData = new List<string>();
        string sqlQuery = "SELECT  Contact.contactID FROM Company INNER JOIN  Contact ON Company.companyID = Contact.companyID where contactID <> " + contactID + " and firstName='" + firstName.Trim() + "' and lastName='" + lastName.Trim() + "' and Company.companyID=" + companyID + "";
        SqlConnection objCon = new SqlConnection(connValue);
        objCon.Open();
        SqlCommand objCmd = new SqlCommand(sqlQuery, objCon);
        SqlDataReader sqlReader = objCmd.ExecuteReader();

        if (sqlReader.HasRows == true)
        {
            return false;
        }
        else
        {
            return true;
        }      
        sqlReader.Close();
        objCon.Close();
    }
    public void RedirectToSpecificPage()
    {

        object refUrl = Session["UrlRef"];
        if (refUrl != null)
            Response.Redirect(refUrl.ToString(), false);
        else
            Response.Redirect("~/ViewContacts.aspx", false);

    }
    private IList<string> getContactDataForCheck(int cntctID)
    {
        IList<string> lstUserData = new List<string>();
        string sqlQuery = "SELECT  Contact.contactID, Contact.firstName, Contact.lastName,  Contact.emailAddress, Contact.companyID FROM  Contact WHERE (Contact.contactID = " + _contactID + ")";


        SqlConnection objCon = new SqlConnection(connValue);
        objCon.Open();
        SqlCommand objCmd = new SqlCommand(sqlQuery, objCon);
        SqlDataReader sqlReader = objCmd.ExecuteReader();
        while (sqlReader.Read())
        {
            lstUserData.Add(sqlReader["contactID"].ToString());
            lstUserData.Add(sqlReader["firstName"].ToString());
            lstUserData.Add(sqlReader["lastName"].ToString());
            lstUserData.Add(sqlReader["emailAddress"].ToString());
            lstUserData.Add(sqlReader["companyID"].ToString());            
        }
        sqlReader.Close();
        objCon.Close();

        return lstUserData;
    }
    private void PopulateDropDownBox(DropDownList ddlBox, string sqlQuery, string valueMember, string displayName)
    {
        DataTable table = new DataTable();
        try
        {
            using (SqlConnection sqlConn = new SqlConnection(connValue))
            {
                using (SqlDataAdapter da = new SqlDataAdapter(sqlQuery, sqlConn))
                {
                    sqlConn.Open();
                    da.Fill(table);
                }
            }
            //cmbBox.Items.Add("Select");
            ddlBox.DataSource = table;

            ddlBox.DataTextField = displayName;
            ddlBox.DataValueField = valueMember;

            ddlBox.DataBind();
            ddlBox.SelectedIndex = -1;
            ddlBox.Items.Insert(0, new ListItem(""));
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    private int MaxCompanyID()
    {
        int UserID = 0;
        try
        {
            SqlConnection sqlConn = new SqlConnection(connValue);
            sqlConn.Open();
            SqlCommand sqlCom = new SqlCommand("select max(contactID) from CONTACT", sqlConn);       
            SqlDataReader sqlReader = sqlCom.ExecuteReader();
            sqlReader.Read();
            UserID = Convert.ToInt32(sqlReader[0]) + 1;
            sqlReader.Close();
            sqlConn.Close();
        }
        catch (Exception ex)
        {
            throw ex;
        }
        return UserID;
    }
    private void InsertContactInfo()
    {
        //if (ValidateControls() == false)
        //    return;

      //  int maxCmpID = MaxCompanyID();

        string insertQuery = "INSERT INTO CONTACT(firstName,lastName,emailAddress,officeAddress,BusinessPhone,jobPosition,homePhone,mobPhone,faxNumber,UserName,password," +
        " officePhone,City,StateProvince,postCode,companyID,teamLeaderID,userProfileID,sectionID) " +           //, QS_Name ,@QS_Name
                             " VALUES(@firstName,@latName,@email,@address,@businesNo,@jobTitle,@homePhone,@mblNo,@faxNo,@UserName,@password,@officePhone,@city,@stateProvince, " +
        "@zipPostal,@CmpID,@teamLeaderID,@userProfileID,@sectionID)";

        try
        {
            SqlConnection sqlCon = new SqlConnection(connValue);
            sqlCon.Open();

            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = insertQuery;
            cmd.Connection = sqlCon;

           // cmd.Parameters.AddWithValue("@cntID", maxCmpID);
            cmd.Parameters.AddWithValue("@firstName", txtFirstName.Text);
            cmd.Parameters.AddWithValue("@latName", txtLastName.Text);

            cmd.Parameters.AddWithValue("@email", txtEmailId.Text);
            cmd.Parameters.AddWithValue("@address", txtOfficeAddress.Text);
            cmd.Parameters.AddWithValue("@businesNo", "");

            cmd.Parameters.AddWithValue("@jobTitle", txtJobTitle.Text);         
            cmd.Parameters.AddWithValue("@mblNo", txtMobilePhone.Text);

           
            cmd.Parameters.AddWithValue("@UserName", txtFirstName.Text);
            cmd.Parameters.AddWithValue("@passWord", "");

            cmd.Parameters.AddWithValue("@officePhone", txtOffTelNo.Text);
         
         

            cmd.Parameters.AddWithValue("@CmpID", ddlCmp.SelectedValue);     

    

            if (ddlSection.SelectedIndex!=0)
                cmd.Parameters.AddWithValue("@sectionID", ddlSection.SelectedValue);
            else
                cmd.Parameters.AddWithValue("@sectionID", "8");    // Not Applicable

            if (ddlTeamLead.SelectedIndex != 0)
                cmd.Parameters.AddWithValue("@teamLeaderID", ddlTeamLead.SelectedValue);
            else
                cmd.Parameters.AddWithValue("@teamLeaderID", 6);    // Not Applicable or Other

            cmd.Parameters.AddWithValue("@userProfileID", 3);    // Guest
                    
            cmd.ExecuteNonQuery();
            sqlCon.Close();

           
        }
        catch (Exception ex)
        {
            throw ex;
        }

        //string script = "this.window.opener.location=this.window.opener.location;this.window.close();";
        //if (!ClientScript.IsClientScriptBlockRegistered("REFRESH_PARENT"))
        //{
        //    ClientScript.RegisterClientScriptBlock(typeof(string), "REFRESH_PARENT", script, true);
        //}

    }
   

    private void getContactInfo(int contactID)
    {
        string sqlQuery = "SELECT  Contact.contactID, Contact.firstName, Contact.lastName, Contact.jobPosition, Contact.emailAddress, Company.cmpName, Contact.officePhone, Section.sectionID, " +  
                        " Contact.mobPhone, EBSDTeamLeaders.teamLeaderName, Contact.officeAddress, Contact.homePhone, Contact.city, Contact.stateProvince, Contact.postCode, " +
                        " Contact.country,Contact.companyID,Contact.teamLeaderID,Contact.userShortName,Contact.comments,Contact.BusinessPhone,Contact.isAuthRepres,Contact.isCoordinator FROM  Contact LEFT OUTER JOIN Company ON Contact.companyID = Company.companyID LEFT OUTER JOIN  " + 
                        " EBSDTeamLeaders ON Contact.teamLeaderID = EBSDTeamLeaders.teamLeaderID LEFT OUTER JOIN  Section ON Contact.sectionID = Section.sectionID WHERE (Contact.contactID = " + contactID + ")"; //JobNo 

        SqlConnection objCon = new SqlConnection(connValue);
        objCon.Open();
        SqlCommand objCmd = new SqlCommand(sqlQuery, objCon);
        SqlDataReader sqlReader = objCmd.ExecuteReader();
        while (sqlReader.Read())
        {
            txtFirstName.Text = sqlReader["firstName"].ToString();
            txtLastName.Text = sqlReader["lastName"].ToString();
            txtJobTitle.Text = sqlReader["jobPosition"].ToString();
            txtEmailId.Text = sqlReader["emailAddress"].ToString();
            ddlCmp.SelectedValue = sqlReader["companyID"].ToString();
            txtOffTelNo.Text = sqlReader["officePhone"].ToString();
            if (sqlReader["sectionID"].ToString()!="")
               ddlSection.SelectedValue = sqlReader["sectionID"].ToString();
            txtMobilePhone.Text = sqlReader["mobPhone"].ToString();
            ddlTeamLead.SelectedValue = sqlReader["teamLeaderID"].ToString();         
            txtOfficeAddress.Text = sqlReader["officeAddress"].ToString();          
            txtCountry.Text = sqlReader["country"].ToString();
            txtRemarks.Text = sqlReader["comments"].ToString();
            //txtOffTelNo.Text = sqlReader["BusinessPhone"].ToString();
            txtShortName.Text = sqlReader["userShortName"].ToString();

            chkRepresent.Checked =  Convert.ToBoolean(sqlReader["isAuthRepres"]);

            chkCoordinator.Checked = Convert.ToBoolean(sqlReader["isCoordinator"]);
        }
        sqlReader.Close();
        objCon.Close();
    }   
    protected void btnClose_Click(object sender, EventArgs e)
    {
       // Session["Url"].ToString();

        ScriptManager.RegisterStartupScript(this, typeof(string), "script",
                "<script type=text/javascript> parent.location.href = parent.location.href;</script>", false);
    }
    protected void txtEmail_TextChanged(object sender, EventArgs e)
    {
        if (txtEmailId.Text != "")
        {
            if (new JobOrderData().checkEmailExist(txtEmailId.Text, _contactID) != "")
            {
                ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Email Address already existed ')</script>", false);
                txtEmailId.Text = "";
                txtEmailId.Focus();
            }
        }
        return;  
    }


    protected void drpRole_SelectedIndexChanged(object sender, EventArgs e)
    {
        //string insertQuery = "Update Contact set empCatID = @empCatID where contactID = @contactID";

        //try
        //{
        //    SqlConnection sqlCon = new SqlConnection(connValue);
        //    sqlCon.Open();

        //    SqlCommand cmd = new SqlCommand();
        //    cmd.CommandText = insertQuery;
        //    cmd.Connection = sqlCon;


        //    cmd.Parameters.AddWithValue("@contactID", _contactID);

        //    cmd.Parameters.AddWithValue("@empCatID", drpRole.SelectedValue);

        //    cmd.ExecuteNonQuery();
        //    sqlCon.Close();


        //}
        //catch (Exception ex)
        //{
        //    throw ex;
        //}      
    }
}