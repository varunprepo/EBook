﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Web.UI.HtmlControls;

public partial class Directory_ViewProjectCoordinators : System.Web.UI.Page
{
    string connValue = System.Configuration.ConfigurationManager.ConnectionStrings["EBSDEBookConn"].ConnectionString;   
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            FillGridView_Details();
        }
    }

    private void FillGridView_Details()
    {
        string sqlQuery = "SELECT prjCoordID, coordName, phoneNo , eMail FROM ProjCoordinator Order By coordName";

        SqlConnection objCon = new SqlConnection(connValue);
        SqlCommand objCmd = new SqlCommand(sqlQuery, objCon);
        SqlDataAdapter objDA = new SqlDataAdapter(objCmd);

        objDA.SelectCommand.CommandText = objCmd.CommandText.ToString();
        DataTable dt = new DataTable();
        objDA.Fill(dt);

        grdProjectCoordinators.DataSource = dt.DefaultView;
        grdProjectCoordinators.DataBind();

        //Session["ProjCoordinatorsData"] = dt;

        // lblCnt.Text = " Jobs Count :  " + gridJobs.Rows.Count.ToString();
    }

    protected void lnkBtnEditProjCoordinator_Click(object sender, EventArgs e)
    {
        try
        {
            LinkButton lnkDistributrID = (LinkButton)sender;
            GridViewRow gvr = (GridViewRow)lnkDistributrID.NamingContainer;
            string projCoordID = ((HtmlGenericControl)gvr.FindControl("divProjCoordID")).InnerText.Trim();

            // Response.Redirect("~/Directory/AddContactsInfo.aspx?contactID=" + cntctID + "", false);

            UtilityClass utils = null;
            try
            {
                utils = new UtilityClass(this.Page);
                string url = Request.Url.AbsoluteUri;
                Session["Url"] = Request.Url.AbsoluteUri;
                if (url.Contains(":"))
                    url = url.Substring(0, utils.GetNthIndex(url, '/', 4));
                else
                    url = url.Substring(0, utils.GetNthIndex(url, '/', 2));
                url = url + "/Directory/AddEditProjectCoordinators.aspx?prjCoordID=" + projCoordID + "";
                OpenPageByUsingJS(url, "800", "600");
            }
            catch (Exception ex)
            {
                this.Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Error occurred while processing the request')</script>", false);
            }
        }
        catch (Exception ex)
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Error occurred while processing the request')</script>", false);
        }
    }

    private void OpenPageByUsingJS(string url, string width, string height)
    {
        string s = "window.open('" + url + "', 'popup_window', 'width=" + width + ",height=" + height + "left=100,top=100,resizable=yes');";
        Page.ClientScript.RegisterStartupScript(this.GetType(), "script", s, true);
    }

    protected void btnAdd_Click(object sender, EventArgs e)
    {
        UtilityClass utils = null;
        try
        {
            utils = new UtilityClass(this.Page);
            string url = Request.Url.AbsoluteUri;
            Session["Url"] = Request.Url.AbsoluteUri;
            if (url.Contains(":"))
                url = url.Substring(0, utils.GetNthIndex(url, '/', 4));
            else
                url = url.Substring(0, utils.GetNthIndex(url, '/', 2));
            url = url + "/Directory/AddEditProjectCoordinators.aspx";
            OpenPageByUsingJS(url, "800", "600");
        }
        catch (Exception ex)
        {
            this.Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Error occurred while processing the request')</script>", false);
        }
    }
    protected void btnClear_Click(object sender, EventArgs e)
    {
        txtProjCoordNameSearch.Text = "";
        FillGridView_Details();
    }
    protected void btnSearch_Click(object sender, EventArgs e)
    {
        try
        {
            string sqlQuery = "select prjCoordID,coordName,eMail,phoneNo from ProjCoordinator Where coordName Like '%" + txtProjCoordNameSearch.Text + "%'"; //JobNo 
            SqlConnection objCon = new SqlConnection(connValue);
            SqlCommand objCmd = new SqlCommand(sqlQuery, objCon);
            SqlDataAdapter objDA = new SqlDataAdapter(objCmd);

            objDA.SelectCommand.CommandText = objCmd.CommandText.ToString();
            DataTable dt = new DataTable();
            objDA.Fill(dt);

            grdProjectCoordinators.DataSource = dt.DefaultView;
            grdProjectCoordinators.DataBind();
        }
        catch (Exception)
        {
            this.Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Error occurred while performing search operation')</script>", false);
        }      
    }
    protected void btnDelete_Click(object sender, EventArgs e)
    {

    }

    protected void grdProjectCoordinators_PageIndexChanging(object sender, System.Web.UI.WebControls.GridViewPageEventArgs e)
    {
        grdProjectCoordinators.PageIndex = e.NewPageIndex;
        //bindGridView();
        FillGridView_Details();
    }
    //private void bindGridView()
    //{
    //    grdProjectCoordinators.DataSource = Session["contactData"];
    //    grdProjectCoordinators.DataBind();
    //}
    protected void txtProjCoordNameSearch_TextChanged(object sender, EventArgs e)
    {
        try
        {
            string sqlQuery = "select prjCoordID,coordName,eMail,phoneNo from ProjCoordinator Where coordName Like '%" + txtProjCoordNameSearch.Text + "%'"; //JobNo 
            SqlConnection objCon = new SqlConnection(connValue);
            SqlCommand objCmd = new SqlCommand(sqlQuery, objCon);
            SqlDataAdapter objDA = new SqlDataAdapter(objCmd);

            objDA.SelectCommand.CommandText = objCmd.CommandText.ToString();
            DataTable dt = new DataTable();
            objDA.Fill(dt);

            grdProjectCoordinators.DataSource = dt.DefaultView;
            grdProjectCoordinators.DataBind();
        }
        catch (Exception)
        {
            this.Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Error occurred while performing search operation')</script>", false);
        }  
    }
}