﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using Datalayer;

public partial class NewFolder1_VoDemo : System.Web.UI.Page
{
    string connValue = System.Configuration.ConfigurationManager.ConnectionStrings["EBSDEBookConn"].ConnectionString;
    int _jobID = 0;
    UtilityClass uCls = null;

    protected void Page_Load(object sender, EventArgs e)
    {
        lbljobNo.Text = Session["JobNo"].ToString();
        lblProjectCode.Text = Session["prjCode"].ToString();
    }
    //(" + jobid + "," + aprid + ",'"+text+"' )";
    protected override void OnInit(EventArgs e)
    {
        _jobID = Convert.ToInt32(Session["Upd_jobID"]);

        if (!IsPostBack)
        {
            PopulateDropDownBox(DropDownList1, "SELECT voID, voDesc FROM VODetails Order by voDesc; ", "voID", "voDesc");
            gridload();
        }
    }    
    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (DropDownList1.SelectedIndex != 0)
        {
            new JobOrderData().Add_VOvalues(1, _jobID, Convert.ToInt32(DropDownList1.SelectedValue));

            DropDownList1.SelectedIndex = 0;

            gridload();


        }
    }   
    public void gridload()
    {
        DataSet ds = new DataSet();
        ds = (new JobOrderData().GetVODetails(_jobID));
        GridView1.DataSource = ds;
        GridView1.DataBind();
    }
    private void PopulateDropDownBox(DropDownList ddlBox, string sqlQuery, string valueMember, string displayName)
    {
        DataTable table = new DataTable();
        try
        {
            using (SqlConnection sqlConn = new SqlConnection(connValue))
            {
                using (SqlDataAdapter da = new SqlDataAdapter(sqlQuery, sqlConn))
                {
                    sqlConn.Open();
                    da.Fill(table);
                }
            }
            //cmbBox.Items.Add("Select");
            ddlBox.DataSource = table;

            ddlBox.DataTextField = displayName;
            ddlBox.DataValueField = valueMember;

            //ddlBox.SelectedIndex = -1;

            ddlBox.DataBind();

            ddlBox.Items.Insert(0, new ListItem("--Select--"));
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "delete")
        {
            string arguments = e.CommandArgument.ToString();
            string[] args = arguments.Split(';');

            string detID = args[0];
            //string jobid = args[1];
            //jobid = "1";

            new JobOrderData().Delete_VOvalues(Convert.ToInt32(detID));
        }
    }
    protected void GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        gridload();
    }
}