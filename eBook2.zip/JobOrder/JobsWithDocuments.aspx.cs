﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using Datalayer;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.IO;

public partial class JobOrder_JobsWithDocuments : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            DataSet ds = new JobOrderData().FillGridView_DetailsForFiles("");  // SpName - SearchAllJobs
            DataTable dt = ds.Tables[0];

            DataView dvCommitted = new DataView(dt);
        
            gvFileUpload.DataSource = dvCommitted;
            gvFileUpload.DataBind();
        }
    }
    protected void gvJoborder_RowDataBound(object sender, GridViewRowEventArgs e)
    {

    }
    protected void gvJoborder_RowCommand(object sender, GridViewCommandEventArgs e)
    {

    }
    protected void lnkBtnJobID_Click(object sender, EventArgs e)
    {
        string strUpdateJob = Request.Url.AbsoluteUri;
        try
        {
            LinkButton lnkJobID = (LinkButton)sender;
            GridViewRow gvr = (GridViewRow)lnkJobID.NamingContainer;
            Session["JobID"] = ((HtmlGenericControl)gvr.FindControl("divJobID")).InnerText;

            Session["PayID"] = ((HtmlGenericControl)gvr.FindControl("divPayID")).InnerText;

            Session["JobInchargeID"] = lnkJobID.ToolTip;

            Session["JobCatID"] = ((HtmlGenericControl)gvr.FindControl("divJoCatbID")).InnerText;

            if (((HtmlGenericControl)gvr.FindControl("divJoCatbID")).InnerText == "2")     //payment
            {
                Session["UrlRef"] = strUpdateJob;
                Response.Redirect("~/Payments/PaymentDetails.aspx?PayID= " + Session["PayID"] + "", false);
            }
            else if (((HtmlGenericControl)gvr.FindControl("divJoCatbID")).InnerText == "8")
            {
                Session["UrlRef"] = strUpdateJob;
                Response.Redirect("~/DCLog/DCDetails.aspx?JobID= " + Session["JobID"] + "", false);
            }
            else if (((HtmlGenericControl)gvr.FindControl("divJoCatbID")).InnerText != "1")
            {
                Session["UrlRef"] = strUpdateJob;
                Response.Redirect("~/JobOrder/DefaultGrid.aspx?JobID= " + Session["JobID"] + "", false);
            }
            else
            {
                // Session["UrlRef"] = "~/JobOrder/PSAJobDetails.aspx";
                Session["UrlRef"] = strUpdateJob;
                Response.Redirect("~/JobOrder/PSAJobDetails.aspx?JobID= " + Session["JobID"] + "", false);
            }
        }
        catch (Exception ex)
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Error occurred while processing the request')</script>", false);
        }
    }

    protected void lnkDownload_Click(object sender, EventArgs e)
    {
        //if (checkUserExist(Convert.ToInt32(fileID), 1, Convert.ToInt32(Session["UserID"])))
        {
            LinkButton lnkbtn = sender as LinkButton;
            GridViewRow gvrow = lnkbtn.NamingContainer as GridViewRow;

            string filePath = gvFileUpload.DataKeys[gvrow.RowIndex].Value.ToString();

            // Only use in case Application Server File foldes not in C Drive

            //filePath = filePath.Replace("C:", "E:");

            Response.AddHeader("Content-Disposition", "attachment;filename=\"" + filePath + "\"");
            //Response.TransmitFile(Server.MapPath(filePath));

            if (!File.Exists((string)filePath))
            {
                Response.Write("File not available at specific path");
                return;
            }

            Response.TransmitFile(filePath);
            Response.End();
        }
    }
    protected void lnkDelete_Click(object sender, EventArgs e)
    {
        //try
        //{
        //    LinkButton lnkbtn = sender as LinkButton;
        //    GridViewRow gvrow = lnkbtn.NamingContainer as GridViewRow;
        //    string fileID = gvJoborder.DataKeys[gvrow.RowIndex].Values[1].ToString();

        //    if (!userRightsColl.Contains("26"))
        //    {
        //        if (checkUserExist(Convert.ToInt32(fileID), 1, Convert.ToInt32(Session["UserID"])))
        //        {
        //            try
        //            {
        //                using (SqlConnection con = new SqlConnection(connValue))
        //                {
        //                    con.Open();
        //                    using (SqlCommand cmd = new SqlCommand("Update FilesTable Set isFileActive = 0,updateUser = @updateUser,updateDate = @updateDate where fileID = " + fileID, con))
        //                    {
        //                        cmd.Parameters.AddWithValue("@updateUser", Session["Username"].ToString());
        //                        cmd.Parameters.AddWithValue("@updateDate", System.DateTime.Now);
        //                        cmd.ExecuteNonQuery();
        //                    }
        //                }
        //            }
        //            catch (Exception ex)
        //            {

        //            }

        //            BindGridviewData();
        //        }

        //        else
        //        {
        //            Response.Write("You don't have rights to delete this file..");
        //        }
        //    }
        //    else
        //    {
        //        Response.Write("Please contact Administrator,You don't have rights to delete this file..'");
        //    }
        //}
        //catch (Exception ex)
        //{
        //    ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Error occurred while processing the request')</script>", false);
        //}
    }

    protected void lnkAdd_Click(object sender, EventArgs e)
    {
        //try
        //{
        //    LinkButton lnkbtn = sender as LinkButton;
        //    GridViewRow gvrow = lnkbtn.NamingContainer as GridViewRow;
        //    string fileID = gvJoborder.DataKeys[gvrow.RowIndex].Values[1].ToString();

        //    if (!userRightsColl.Contains("26"))
        //    {
        //        if (checkUserExist(Convert.ToInt32(fileID), 1, Convert.ToInt32(Session["UserID"])))
        //        {
        //            try
        //            {
        //                using (SqlConnection con = new SqlConnection(connValue))
        //                {
        //                    con.Open();
        //                    using (SqlCommand cmd = new SqlCommand("Update FilesTable Set isFileActive = 0,updateUser = @updateUser,updateDate = @updateDate where fileID = " + fileID, con))
        //                    {
        //                        cmd.Parameters.AddWithValue("@updateUser", Session["Username"].ToString());
        //                        cmd.Parameters.AddWithValue("@updateDate", System.DateTime.Now);
        //                        cmd.ExecuteNonQuery();
        //                    }
        //                }
        //            }
        //            catch (Exception ex)
        //            {

        //            }

        //            BindGridviewData();
        //        }

        //        else
        //        {
        //            Response.Write("You don't have rights to delete this file..");
        //        }
        //    }
        //    else
        //    {
        //        Response.Write("Please contact Administrator,You don't have rights to delete this file..'");
        //    }
        //}
        //catch (Exception ex)
        //{
        //    ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Error occurred while processing the request')</script>", false);
        //}
    }
    
    
    protected void txtJobNo_TextChanged(object sender, EventArgs e)
    {
        DataSet ds = new JobOrderData().FillGridView_DetailsForFiles(txtJobNo.Text);  // SpName - SearchAllJobs
        DataTable dt = ds.Tables[0];

        DataView dvCommitted = new DataView(dt);
        gvFileUpload.DataSource = dvCommitted;
        gvFileUpload.DataBind();
    }
    protected void gvFileUpload_RowCommand(object sender, GridViewCommandEventArgs e)
    {

    }
    protected void gvFileUpload_RowDataBound(object sender, GridViewRowEventArgs e)
    {

    }
}