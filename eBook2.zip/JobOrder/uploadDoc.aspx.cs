﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using Datalayer;
using System.Globalization;

public partial class JobOrder_uploadDoc : System.Web.UI.Page
{
    string connValue = System.Configuration.ConfigurationManager.ConnectionStrings["EBSDEBookConn"].ConnectionString;
    int updateJobID = 0; int updatePayID = 0;
    protected void Page_Load(object sender, EventArgs e)
    {
         updateJobID = Convert.ToInt32(Session["lnkJobID"]);
         updatePayID = Convert.ToInt32(Session["lnkPayID"]);

        if (!IsPostBack)
        {
            if (Session["CatID"].ToString().Equals("2"))
                   PopulateDropDownBox(ddlDocRef, "SELECT [Document].documentID, [Document].referenceNo, Job.jobID, [Document].docCatID FROM  Job RIGHT OUTER JOIN  [Document] ON Job.docRefID = [Document].documentID " +
                                 " WHERE (Document.jobID IS NULL)  And (Document.paymentID IS NULL) AND ([Document].docCatID = 2) ORDER BY [Document].createDate", "documentID", "referenceNo"); 
            else
                    PopulateDropDownBox(ddlDocRef, "SELECT [Document].documentID, [Document].referenceNo, Job.jobID, [Document].docCatID FROM  Job RIGHT OUTER JOIN  [Document] ON Job.docRefID = [Document].documentID " +
                                  " WHERE (Document.jobID IS NULL) And (Document.paymentID IS NULL) AND ([Document].docCatID = 1) ORDER BY [Document].createDate", "documentID", "referenceNo"); 
        }
    }    
    private void PopulateDropDownBox(DropDownList ddlBox, string sqlQuery, string valueMember, string displayName)
    {
        DataTable table = new DataTable();
        try
        {
            using (SqlConnection sqlConn = new SqlConnection(connValue))
            {
                using (SqlDataAdapter da = new SqlDataAdapter(sqlQuery, sqlConn))
                {
                    sqlConn.Open();
                    da.Fill(table);
                }
            }
            //cmbBox.Items.Add("Select");
            ddlBox.DataSource = table;

            ddlBox.DataTextField = displayName;
            ddlBox.DataValueField = valueMember;

            ddlBox.SelectedIndex = -1;
            ddlBox.DataBind();
            ddlBox.Items.Insert(0, new ListItem("--Select--"));
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    protected void btnLink_Click(object sender, EventArgs e)
    {
        if (ddlDocRef.SelectedIndex != 0)
        {
            int docID =Convert.ToInt32(ddlDocRef.SelectedValue);

            if (Session["lnkJobID"]!=null)
               new JobOrderData().UpdateJobIDforDocument(Convert.ToInt32(Session["lnkJobID"]), docID);
            //new JobOrderData().UpdateJobCloseDate(Convert.ToInt32(Session["lnkJobID"]), docID);

            if (Session["lnkPayID"]!=null)
              new JobOrderData().UpdatePayIDforDocument(Convert.ToInt32(Session["lnkPayID"]), docID);
           // new JobOrderData().UpdateJobCloseDate(Convert.ToInt32(Session["lnkPayID"]), docID);

            AddDistributionData();

            CheckandDeleteDistributionData(docID);
        }      

        Session["lnkJobID"] = null; 

        string script = "this.window.opener.location=this.window.opener.location;this.window.close();";
        if (!ClientScript.IsClientScriptBlockRegistered("REFRESH_PARENT"))
            ClientScript.RegisterClientScriptBlock(typeof(string), "REFRESH_PARENT", script, true);
    }
    private IList<int> getDocIDCollection(int _jobID)
    {
        IList<int> docIDColl = new List<int>();
        try
        {
            SqlConnection sqlConn = new SqlConnection(connValue);
            sqlConn.Open();
            SqlCommand sqlCom = new SqlCommand("Select jobOwnerID,jobID,contactID,docID,distributedBy,actionDueDate,daysToAct,completionDate from JobOwner where jobID = " + _jobID + "", sqlConn);       
            SqlDataReader sqlReader = sqlCom.ExecuteReader();
            while (sqlReader.Read())
            {
                docIDColl.Add(Convert.ToInt32(sqlReader["DocumentID"]));
            }
            sqlReader.Close();
            sqlConn.Close();
        }
        catch (System.Exception ex)
        {
            throw ex;
        }

        return docIDColl;
    }  
    protected void ddlDocRef_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlDocRef.SelectedIndex != 0)
        {
            Session["lnkdocID"] = Convert.ToInt32(ddlDocRef.SelectedValue);
            btnLink.Enabled = true;
        }
    }
    private void AddDistributionData()
    {
        //Session["DocID"] = 203;

        string sqlQuery = string.Empty;
        if (updateJobID!=0)
         sqlQuery = "SELECT contactID, daysToAct, convert(nvarchar,actionDueDate,103) as ActionDueDate,jobOwnerStatusID,JobOwnerID,distributedBy,docID FROM JobOwner WHERE jobID =" + updateJobID;
        else
            sqlQuery = "SELECT contactID, daysToAct, convert(nvarchar,actionDueDate,103) as ActionDueDate,jobOwnerStatusID,JobOwnerID,distributedBy,docID FROM JobOwner WHERE payID =" + updatePayID;

        DataTable dtJobOwner = GetDataFromDB("JobOwner", sqlQuery);

        short jobOwnerCounter = 0;
        while (jobOwnerCounter < dtJobOwner.Rows.Count)
        {
            string InchargeStat = dtJobOwner.Rows[jobOwnerCounter]["jobOwnerStatusID"].ToString();

                SqlConnection sqlConn = new SqlConnection(connValue);
                SqlCommand sqlCmd = new SqlCommand();
                sqlCmd.Connection = sqlConn;

                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.CommandText = "InsertDocDistributionFromJob";
                sqlCmd.Parameters.AddWithValue("@contactID", dtJobOwner.Rows[jobOwnerCounter]["contactID"].ToString());               
              

                if (InchargeStat != "7")       //
                {
                    sqlCmd.Parameters.AddWithValue("@docPurposeID", 1); //// For Action
                    sqlCmd.Parameters.AddWithValue("@docStatusID", 1);
                    sqlCmd.Parameters.AddWithValue("@actionDueDate", DateTime.ParseExact(dtJobOwner.Rows[jobOwnerCounter][2].ToString().Split(' ')[0].Split(' ')[0], "dd/MM/yyyy", CultureInfo.InvariantCulture));
                    sqlCmd.Parameters.AddWithValue("@daysToReply", dtJobOwner.Rows[jobOwnerCounter]["daysToAct"].ToString());
                    sqlCmd.Parameters.AddWithValue("@dateread", System.DBNull.Value); 
                }
                else
                {
                    sqlCmd.Parameters.AddWithValue("@docPurposeID", 2);       // For Info
                    sqlCmd.Parameters.AddWithValue("@docStatusID", 4);
                    sqlCmd.Parameters.AddWithValue("@actionDueDate", System.DBNull.Value);
                    sqlCmd.Parameters.AddWithValue("@daysToReply", System.DBNull.Value);
                    sqlCmd.Parameters.AddWithValue("@dateRead", System.DateTime.Now.ToString("dd/MMM/yyyy"));
                }

                sqlCmd.Parameters.AddWithValue("@issuedByContactID", dtJobOwner.Rows[jobOwnerCounter]["distributedBy"].ToString());      // Session["UserID"].ToString()
                sqlCmd.Parameters.AddWithValue("@createUser", Session["UserName"].ToString());                

                sqlCmd.Parameters.AddWithValue("@documentID", Convert.ToInt32(Session["lnkdocID"]));
                sqlCmd.Parameters.AddWithValue("@inchargeID", dtJobOwner.Rows[jobOwnerCounter]["JobOwnerID"].ToString());

               // sqlCmd.Parameters.AddWithValue("@docIssuedDate", System.DateTime.Now.ToString("dd/MMM/yyyy"));
                sqlCmd.Parameters.AddWithValue("@docCatID", 1);

                sqlConn.Open();
                sqlCmd.ExecuteNonQuery();
                sqlConn.Close();                    

            jobOwnerCounter++;
        }       
    }
    private void CheckandDeleteDistributionData(int DocID)
    {
        string sqlQuery = "SELECT documentID, docCatID, distributeID, contactID FROM  DocumentDistribution WHERE (documentID IN (SELECT documentID FROM  DocumentDistribution AS Tmp  GROUP BY documentID, contactID HAVING   (COUNT(*) > 1) AND (contactID = DocumentDistribution.contactID) AND (documentID = " + DocID + ")))  ORDER BY documentID, docCatID, distributeID";
        DataTable dtDocumentDistribution = GetDataFromDB("DocumentDistribution", sqlQuery);

        if (dtDocumentDistribution.Rows.Count != 0)
            DeleteDistributionData(Convert.ToInt32(dtDocumentDistribution.Rows[0]["distributeID"]));
    }
    private void DeleteDistributionData(int documentID)
    {
        string updateSql = "Delete From DocumentDistribution Where distributeID = " + documentID + " ";
        SqlConnection sqlConn = new SqlConnection(connValue);
        SqlCommand cmd = new SqlCommand();
        cmd.CommandText = updateSql;
        cmd.Connection = sqlConn;

        try
        {
            //cmd.Parameters.AddWithValue("@contactID", documentID);   
            sqlConn.Open();
            cmd.ExecuteNonQuery();
            sqlConn.Close();
        }
        catch (Exception ex)
        {

        }
    }
    //private void UpdateJobIDforDocument(string contactID, DateTime actionDueDate, DateTime docIssuedDate, string docID, string jobOwnerStatusID, string jobOwnerID, SqlConnection sqlConn)
    //{
    //    string updateSql = "UPDATE DocumentDistribution SET actionDueDate = @actionDueDate,docStatusID=@docStatusID,docPurposeID=@docPurposeID,jobOwnerID=@jobOwnerID Where DocumentID = @docRefID and contactID=@contactID";
    //    SqlCommand cmd = new SqlCommand();
    //    cmd.CommandText = updateSql;
    //    cmd.Connection = sqlConn;
    //    try
    //    {
    //        if (jobOwnerStatusID == "7")
    //            cmd.Parameters.AddWithValue("@docPurposeID", 2);
    //        else
    //            cmd.Parameters.AddWithValue("@docPurposeID", 1);

    //        if (jobOwnerStatusID == "7")
    //        {
    //            cmd.Parameters.AddWithValue("@docStatusID", 4);
    //            cmd.Parameters.AddWithValue("@actionDueDate", DBNull.Value);
    //            cmd.Parameters.AddWithValue("@docIssuedDate", DBNull.Value);
    //        }
    //        else
    //        {
    //            if (actionDueDate.CompareTo(DateTime.ParseExact(System.DateTime.Now.ToString("dd/MM/yyyy"), "dd/MM/yyyy", CultureInfo.InvariantCulture)) <= -1)
    //                cmd.Parameters.AddWithValue("@docStatusID", 2);
    //            else
    //                cmd.Parameters.AddWithValue("@docStatusID", 1);
    //            cmd.Parameters.AddWithValue("@actionDueDate", actionDueDate);
    //            cmd.Parameters.AddWithValue("@docIssuedDate", docIssuedDate);
    //        }
    //        cmd.Parameters.AddWithValue("@contactID", contactID);
    //        cmd.Parameters.AddWithValue("@docRefID", docID);
    //        cmd.Parameters.AddWithValue("@jobOwnerID", jobOwnerID);
    //        cmd.ExecuteNonQuery();
    //        cmd = null;
    //    }
    //    catch (Exception ex)
    //    {

    //    }
    //}

    
    public DataTable GetDataFromDB(string dataTabName, string sqlQuery)
    {
        DataTable table = null;
        SqlConnection sqlConn = new SqlConnection(connValue);
        sqlConn.Open();
        SqlDataAdapter sqlDtAdptr = null;
        table = new DataTable(dataTabName);
        sqlDtAdptr = new SqlDataAdapter(@sqlQuery, sqlConn);
        sqlDtAdptr.Fill(table);
        sqlConn.Close();
        return table;
    }
}

 