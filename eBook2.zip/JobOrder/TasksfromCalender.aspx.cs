﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Web.UI.HtmlControls;

public partial class JobOrder_TasksfromCalender : System.Web.UI.Page
{
    string connValue = System.Configuration.ConfigurationManager.ConnectionStrings["EBSDEBookConn"].ConnectionString;
    IList<string> userRightsColl = new List<string>();
    string profile_Name = string.Empty;
    static int _jobID = 0; static string _jobNo = string.Empty;
    protected void Page_Load(object sender, EventArgs e)
    {
      //  _jobID = Convert.ToInt32(Request.QueryString["JobID"]);


        // _jobID =   Convert.ToInt32(Session["lnkJobID"]);

         _jobNo = Session["lnkJobNo"].ToString();

       // _jobID = 1;
        if (!IsPostBack)
        {
            //getUserAccessList(lblUserName.Text);
            FillGridView_Details(_jobNo);
        }
    }
    private void FillGridView_Details(string _jobNo)
    {
        if (userRightsColl.Contains("61"))   //Add New Project
        {
            Response.Write("You have no privilege,Contact administrator");
            return;
        }
       string sqlQuery = string.Empty;
       if (_jobNo == "")
           sqlQuery = "SELECT JobOwner.jobNo, JobType.jobTypeName, JobOwner.completionDate AS DateReceived, Contact.firstName AS IssuedBy, JobOwner.actionDueDate, " +
                       " JobStatus.jobStatusID,JobOwner.jobOwnerCatID FROM  JobOwner INNER JOIN JobStatus ON JobOwner.jobOwnerStatusID = JobStatus.jobStatusID INNER JOIN " +   
                         " Contact ON JobOwner.contactID = Contact.contactID INNER JOIN JobType ON JobOwner.jobOwnerCatID = JobType.CategoryID";

          else
           sqlQuery = "SELECT JobOwner.jobID,JobOwner.jobNo, JobType.jobTypeName, CONVERT(DATETIME, JobOwner.completionDate, 102) as DateReceived, Contact.firstName + '  ' + Contact.lastName AS IssuedBy, " +
                      " CONVERT(DATETIME, JobOwner.actionDueDate, 102) as actionDueDate,JobOwner.jobOwnerCatID  FROM       JobOwner INNER JOIN     JobStatus ON JobOwner.jobOwnerStatusID = JobStatus.jobStatusID INNER JOIN " +
                       " Contact ON JobOwner.contactID = Contact.contactID INNER JOIN    JobType ON JobOwner.jobOwnerCatID = JobType.jobTypeID  WHERE  (JobOwner.jobNo = '" + _jobNo + "') AND (Contact.contactID = " + Session["UserID"] + ")";
        
            SqlConnection objCon = new SqlConnection(connValue);
            SqlCommand objCmd = new SqlCommand(sqlQuery, objCon);
            SqlDataAdapter objDA = new SqlDataAdapter(objCmd);

            objDA.SelectCommand.CommandText = objCmd.CommandText.ToString();
            DataTable dt = new DataTable();
            objDA.Fill(dt);

            gridJobs.DataSource = dt;
            gridJobs.DataBind();
       
    }
    private IList<string> getUserAccessList(string _userName)
    {
        userRightsColl.Clear();

        SqlConnection sqlConn = new SqlConnection(connValue);

        string sqlQuery = "SELECT   UserAccessRights.AccessID, UserAccessRights.Access_Rights, UserPrivelege.HasPrivelege, UserPrivelege.user_profile_id, UserSecurityProfile.profile_name, " +
        " Contacts.ID, Contacts.user_name AS Expr1 FROM  UserAccessRights INNER JOIN UserPrivelege ON UserAccessRights.AccessID = UserPrivelege.AccessID INNER JOIN UserSecurityProfile ON UserPrivelege.user_profile_id = UserSecurityProfile.user_profile_id " +
        " INNER JOIN Contacts ON UserSecurityProfile.user_profile_id = Contacts.user_profile_id WHERE (UserPrivelege.HasPrivelege = 1) AND (Contacts.user_name = 'ebsd_svadakapuram') " +
             " ORDER BY UserAccessRights.AccessID ";
        try
        {
            sqlConn.Open();
            SqlCommand sqlCom = new SqlCommand(sqlQuery, sqlConn);
            SqlDataReader sqlReader = sqlCom.ExecuteReader();
            while (sqlReader.Read())
            {
                userRightsColl.Add(sqlReader[0].ToString());

                if (profile_Name == "")
                    profile_Name = sqlReader[4].ToString();
            }
            sqlReader.Close();
        }
        catch (Exception ex)
        {
            Response.Write("Error getting while reading data !" + ex.Message);
        }
        finally
        {
            sqlConn.Close();
        }
        return userRightsColl;
    }
    protected void gridTasks_RowDataBound(object sender, GridViewRowEventArgs e)
    {

    }
    protected void gridJobs_RowCommand(object sender, GridViewCommandEventArgs e)
    {

    }
    protected void gridJobs_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void gridJobs_RowDataBound(object sender, GridViewRowEventArgs e)
    {

    }
    protected void lnkBtnJobID_Click(object sender, EventArgs e)
    {
        try
        {
            LinkButton lnkJobID = (LinkButton)sender;          
            GridViewRow gvr = (GridViewRow)lnkJobID.NamingContainer;
            Session["JobID"] = ((HtmlGenericControl)gvr.FindControl("divJobID")).InnerText;

            Session["JobInchargeID"] = lnkJobID.ToolTip;


            Session["JobCatID"] = ((HtmlGenericControl)gvr.FindControl("divJoCatbID")).InnerText;

            if (((HtmlGenericControl)gvr.FindControl("divJoCatbID")).InnerText != "1")
            {
                Session["UrlRef"] = "~/JobOrder/DefaultGrid.aspx";
                Response.Redirect("~/JobOrder/DefaultGrid.aspx?JobID= " + Session["JobID"] + "", false); 
            }
            else
            {
                Session["UrlRef"] = "~/JobOrder/PSAJobDetails.aspx";
                Response.Redirect("~/JobOrder/PSAJobDetails.aspx?JobID= " + Session["JobID"] + "", false);
            }          
        }
        catch (Exception ex)
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Error occurred while processing the request')</script>", false);
        }
    }
    protected void Back_Click(object sender, EventArgs e)
    {
        //string url = Session["UrlRef"].ToString();

          string url = "CalenderAlert.aspx";
          string s = "window.open('" + url + "', 'popup_window', 'width=1000,height=500,left=800,top=100,resizable=yes');";
          Page.ClientScript.RegisterStartupScript(this.GetType(), "script", s, true);
    }
}