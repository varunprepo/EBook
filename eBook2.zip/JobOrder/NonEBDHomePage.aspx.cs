﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.DataVisualization.Charting;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using Datalayer;

public partial class JobOrder_NonEBDHomePage : System.Web.UI.Page
{
    string connValue = System.Configuration.ConfigurationManager.ConnectionStrings["EBSDEBookConn"].ConnectionString;
    IList<string> userRightsColl = null;
    string profile_Name = string.Empty;
    UtilityClass uCls = null;

    static int _currentUserID = 0; 
    protected void Page_Load(object sender, EventArgs e)
    {

        if (Session["UserName"] == null)
        {
            Response.Redirect("~/LoginPage.aspx", false);
            return;
        }      

        _currentUserID = Convert.ToInt32(Session["UserID"]);

        userRightsColl = (IList<string>)Session["UserRightsColl"];

        if (!IsPostBack)
        {
            PageloadData();
          
            new JobOrderData().UpdateForFoloowupDocstatus();

            new JobOrderData().UpdateUserAutoReplyStatus();            

            Session["docSender"] = null;      // add sender from document form           
            
        }  
    }  
    private void PageloadData()
    {
        getMyDocumentChart();

        getUnreadDocumentData();

        getMyDocumentTypeChart();


    }
    private void PopulateDropDownBox(DropDownList ddlBox, string sqlQuery, string valueMember, string displayName)
    {
        ddlBox.DataBound += new EventHandler(this.ddlBox_DataBound);
        ddlBox.DataSource = new JobOrderData().FillDropdown(sqlQuery);
        ddlBox.DataTextField = displayName;
        ddlBox.DataValueField = valueMember;
        ddlBox.SelectedIndex = -1;
        ddlBox.DataBind();
    }
    protected void ddlBox_DataBound(object sender, EventArgs e)
    {
        DropDownList ddl = (DropDownList)sender;
        ListItem emptyItem = new ListItem("", "");
        ddl.Items.Insert(0, emptyItem);
    }
    protected void lnkSearchMyDocs_Click(object sender, EventArgs e)
    {
        string strUpdateJob = Request.Url.AbsoluteUri;
        Session["UrlRef"] = strUpdateJob;
        //uCls = new UtilityClass(this.Page);
        //uCls.ResetTheSessionVariables();
        Session["SearchMyDocs"] = "1";
        Response.Redirect("~/Documents/SearchDocument.aspx", false);
    }
    protected void lnkGenerateReports_Click(object sender, EventArgs e)
    {
        string strUpdateJob = Request.Url.AbsoluteUri;
        Session["UrlRef"] = strUpdateJob;
        Response.Redirect("UnderProcess.aspx", false);
    }
    protected void lnkBtnDocReadDate_Click(object sender, EventArgs e)
    {
        string strUpdateJob = Request.Url.AbsoluteUri;
        Session["UrlRef"] = strUpdateJob;
        try
        {
            LinkButton lnkDistributrID = (LinkButton)sender;
            GridViewRow gvr = (GridViewRow)lnkDistributrID.NamingContainer;
            Session["distributeID"] = ((HtmlGenericControl)gvr.FindControl("divDistributeID")).InnerText;
            new JobOrderData().UpdateDistributionDateRead(Convert.ToInt32(((HtmlGenericControl)gvr.FindControl("divDistributeID")).InnerText), _currentUserID);
            int docid = Convert.ToInt32(((HtmlGenericControl)gvr.FindControl("divDocID")).InnerText);
            Response.Redirect("~/Documents/NonEBDDocumentInfo.aspx?docRecID=" + docid + "&RecSentCatID=1", false);
        }
        catch (Exception ex)
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Error occurred while processing the request')</script>", false);
        }
    }
    public void UpdateJobOwner(int jobInchargeID)
    {
        try
        {
            using (SqlConnection con = new SqlConnection(connValue))
            {
                using (SqlCommand sqlCmd = new SqlCommand())
                {
                    sqlCmd.Connection = con;
                    sqlCmd.CommandType = CommandType.Text;
                    sqlCmd.CommandText = "UPDATE JobOwner SET dateRead =@jobReadDate where jobOwnerID = @jobOwnerID";
                    sqlCmd.Parameters.AddWithValue("@jobOwnerID", jobInchargeID);
                    sqlCmd.Parameters.AddWithValue("@jobReadDate", System.DateTime.Now.ToString("dd/MMM/yyyy"));

                    con.Open();
                    sqlCmd.ExecuteNonQuery();
                }
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }




    private void getUnreadDocumentData()
    {
        string sqlQuery = string.Empty;
        sqlQuery = "SELECT   [Document].referenceNo, DocumentType.documentType, DocumentStatus.docStatusName, DocumentDistribution.docCatID, DocumentDistribution.contactID, " +
                        " DocumentDistribution.documentID, DocumentDistribution.dateRead, [Document].superseded,DocumentDistribution.distributeID FROM    [Document] INNER JOIN  DocumentDistribution ON [Document].documentID = DocumentDistribution.documentID INNER JOIN " +
                         " DocumentType ON [Document].docTypeID = DocumentType.docTypeID INNER JOIN  DocumentStatus ON DocumentDistribution.docStatusID = DocumentStatus.docStatusID " +
                          " WHERE  (DocumentDistribution.contactID = " + _currentUserID + ") AND ([Document].docCreatedByID = " + _currentUserID + ") Order By distributeID desc ";      //(DocumentDistribution.dateRead IS NULL) AND

        SqlConnection objCon = new SqlConnection(connValue);
        SqlCommand objCmd = new SqlCommand(sqlQuery, objCon);
        SqlDataAdapter objDA = new SqlDataAdapter(objCmd);
        objDA.SelectCommand.CommandText = objCmd.CommandText.ToString();
        DataTable dtReceiveDocs = new DataTable();

        Session["getPayDataDocs"] = dtReceiveDocs;
        objDA.Fill(dtReceiveDocs);
        gridDocs.DataSource = dtReceiveDocs;
        gridDocs.DataBind();
    }
    private void getMyDocumentChart()
    {
        DataSet dsDoc = new DataSet();

        string sqlQuery = null;

        //sqlQuery = "SELECT COUNT(DocumentDistribution.distributeID) AS DocCount, DocumentStatus.docStatusName " +
        //       " FROM DocumentDistribution INNER JOIN  DocumentStatus ON DocumentDistribution.docStatusID = DocumentStatus.docStatusID WHERE (DocumentDistribution.contactID = " + Convert.ToInt32(Session["UserID"]) + ") " +
        //               " AND ([Document].docCreatedByID = " + _currentUserID + ") GROUP BY DocumentStatus.docStatusName";

        sqlQuery = "SELECT COUNT(DocumentDistribution.distributeID) AS DocCount, DocumentStatus.docStatusName FROM DocumentDistribution INNER JOIN " +
                    "  DocumentStatus ON DocumentDistribution.docStatusID = DocumentStatus.docStatusID INNER JOIN  [Document] ON DocumentDistribution.documentID = [Document].documentID " +
                 " WHERE (DocumentDistribution.contactID = " + _currentUserID + ") AND ([Document].docCreatedByID = " + _currentUserID + ") GROUP BY DocumentStatus.docStatusName, [Document].docCreatedByID";

        SqlDataAdapter daDoc = new SqlDataAdapter(sqlQuery, connValue);
        daDoc.Fill(dsDoc);
        if (dsDoc.Tables[0].Rows.Count != 0)
        {
            myDocsChart.DataSource = dsDoc.Tables[0].DefaultView;
            myDocsChart.Series["Series1"].XValueMember = "docStatusName";
            myDocsChart.Series["Series1"].YValueMembers = "DocCount";

            dsDoc.Tables.Clear();

            myDocsChart.ChartAreas[0].AxisX.MajorGrid.Enabled = false;
            myDocsChart.ChartAreas[0].AxisX.MinorGrid.Enabled = false;
            myDocsChart.ChartAreas[0].AxisY.MajorGrid.Enabled = false;
            myDocsChart.ChartAreas[0].AxisY.MinorGrid.Enabled = false;

            myDocsChart.ChartAreas[0].AxisX.LabelStyle.Angle = 30;
            myDocsChart.ChartAreas[0].AxisX.LabelStyle.ForeColor = Color.Maroon;

            myDocsChart.ChartAreas[0].AxisX.Interval = 1;
        }
    }
    protected void myDocsChart_Click(object sender, ImageMapEventArgs e)
    {
        string strUpdateJob = Request.Url.AbsoluteUri;
        Session["UrlRef"] = strUpdateJob;

        uCls = new UtilityClass(this.Page);
        uCls.ResetTheSessionVariables();
        Session["MyChartClickDocStatus"] = e.PostBackValue;
        int docStatusID = 1;
        if (e.PostBackValue.Equals("Open"))
            docStatusID = 1;
        else if (e.PostBackValue.Equals("For Follow Up"))
            docStatusID = 2;
        else if (e.PostBackValue.Equals("Pending"))
            docStatusID = 3;
        else if (e.PostBackValue.Equals("Closed"))
            docStatusID = 4;

        Response.Redirect("~/Documents/SearchDocument.aspx?docStatID=" + docStatusID, false);
    }
    protected void sectionWiseDoc_Click(object sender, ImageMapEventArgs e)
    {
        uCls = new UtilityClass(this.Page);
        uCls.ResetTheSessionVariables();
        Session["SectionWiseDocStatus"] = e.PostBackValue;
        Session["SectionWiseSearch"] = "1";

        int docStatusID = 1;
        if (e.PostBackValue.Equals("Open"))
            docStatusID = 1;
        else if (e.PostBackValue.Equals("For Follow Up"))
            docStatusID = 2;
        else if (e.PostBackValue.Equals("Pending"))
            docStatusID = 3;

        Response.Redirect("~/Documents/DocumentRegister.aspx?docStatID=" + docStatusID, false);
    }
    protected void onGoingTasksPerSectionChart_Click(object sender, ImageMapEventArgs e)
    {
        Session["JobType"] = e.PostBackValue;
        uCls = new UtilityClass(this.Page);
        uCls.ResetTheSessionVariables();
        Response.Redirect("~/Documents/MyDocuments.aspx", false);
    }
    protected void lnkBtnRefNo_Click(object sender, EventArgs e)
    {
        string strUpdateJob = Request.Url.AbsoluteUri;
        Session["UrlRef"] = strUpdateJob;
        try
        {
            //Get the LinkButton that raised the event
            LinkButton lnkDocRefNo = (LinkButton)sender;
            //Get the row that contains this dropdown
            GridViewRow gvr = (GridViewRow)lnkDocRefNo.NamingContainer;
            Session["DocID"] = ((HtmlGenericControl)gvr.FindControl("divDocID")).InnerText;
            Session["DocCategoryID"] = ((HtmlGenericControl)gvr.FindControl("divDocCatID")).InnerText;
            Session["UrlRef"] = "~/JobOrder/DefaultWindow.aspx";
            Response.Redirect("~/Documents/DocumentDetailsWindow.aspx?docCaiD=1", false);
        }
        catch (Exception ex)
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Error occurred while processing the request')</script>", false);
        }
    }
    protected void gridDocs_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            try
            {
                uCls = new UtilityClass(this.Page);
                Control ctrlSuperseded = e.Row.FindControl("divReceiveSuperseded");

                if (ctrlSuperseded != null)
                {
                    HtmlGenericControl htmlCtrlSuperseded = ctrlSuperseded as HtmlGenericControl;
                    e.Row.Cells[1].BackColor = System.Drawing.Color.WhiteSmoke;
                    e.Row.Cells[1].ForeColor = System.Drawing.Color.Gray;

                    e.Row.Cells[2].BackColor = System.Drawing.Color.WhiteSmoke;
                    e.Row.Cells[2].ForeColor = System.Drawing.Color.Gray;
                }
            }
            catch (Exception ex)
            {
                ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Error occurred while performing database operation')</script>", false);
            }
        }
    }
    private void overdueJobs(string sectionName)
    {
        if (Session["SectionName"].ToString().Equals("Cost Control Section") || Session["SectionName"].ToString().Equals("Planning and Scheduling"))
        {
            if (!userRightsColl.Contains("5") || !userRightsColl.Contains("42"))
            {

                string cmtName = Session["OnGoingJobStatus"].ToString().Trim();

                if ((Session["SectionID"].ToString() == "1") || (Session["SectionID"].ToString() == "6"))
                {
                    if (cmtName.Equals("Cost Control Section"))
                        Response.Redirect("~/DCLog/OverDueJobs.aspx", false);

                    else if (cmtName.Trim().Equals("Comitted Contract"))
                        Response.Redirect("~/JobOrder/JobOrder.aspx", false);


                    else if (cmtName.Equals("Non Committed Contracts"))
                        Response.Redirect("~/JobOrder/JobOrder.aspx", false);


                    else if (cmtName.Equals("Basic Materials"))
                        Response.Redirect("~/JobOrder/JobOrder.aspx", false);


                    else if (cmtName.Equals("Cost Estimate"))
                        Response.Redirect("~/JobOrder/JobOrder.aspx", false);


                    else if (cmtName.Contains("Planning Schedule"))
                        Response.Redirect("~/JobOrder/JobOrder.aspx", false);


                    else if (cmtName.Equals("A_ (PSA Contract)"))
                        Response.Redirect("~/JobOrder/JobOrder.aspx", false);

                }
            }
        }
        else if (sectionName.Equals("Payment Section") || sectionName.Equals("Payment Request"))
        {
            Response.Redirect("~/Payments/ViewPayments.aspx", false);
        }
        else if (sectionName.Equals("Document Request") || sectionName.Equals("Review Baseline Schedule"))           //Document Request     Document Control Section
        {
            Response.Redirect("~/DCLog/ViewDCLog.aspx", false);
        }
        else
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "Popup", "<script>alert('Restricted Access!')</script>", false);
        }
    }

    protected void onGoingTasksPerStaffChart_Click(object sender, ImageMapEventArgs e)
    {
        //Session["OnGoingJobStatus"] = e.PostBackValue;
        // int cntID = getContactID(e.PostBackValue.ToString());
        Session["ShortName"] = e.PostBackValue.ToString();
        Response.Redirect("~/JobOrder/SearchAllJobs.aspx", false);
    }
    private int getContactID(string userName)
    {
        int cnctID = 0;
        SqlConnection sqlConn = new SqlConnection(connValue);
        string sqlQuery = "SELECT contactID From Contact Where userShortName = '" + userName + "' ";

        try
        {
            sqlConn.Open();
            SqlCommand sqlCom = new SqlCommand(sqlQuery, sqlConn);
            SqlDataReader sqlReader = sqlCom.ExecuteReader();
            while (sqlReader.Read())
            {
                cnctID = Convert.ToInt32(sqlReader["contactID"].ToString());
            }
            sqlReader.Close();
        }
        catch (Exception ex)
        {
            Response.Write("Error getting while reading data !" + ex.Message);
        }
        finally
        {
            sqlConn.Close();
        }
        return cnctID;
    }
    // lnkSearchDoc_Click
    protected void lnkSearchDoc_Click(object sender, EventArgs e)
    {
        string strUpdateJob = Request.Url.AbsoluteUri;
        Session["UrlRef"] = strUpdateJob;

        Session["SearchAllDocs"] = "1";
        Response.Redirect("~/Documents/DocumentRegister.aspx", false);
    }
    protected void onGoingTasksPerStaffChart_Load(object sender, EventArgs e)
    {

    }
    private void UpdateDocumentActionDueDate()
    {
        string actionDate = string.Empty;
        SqlConnection sqlConn = new SqlConnection(connValue);
        string sqlQuery = "SELECT  actionDueDate FROM DocumentDistribution  ";

        try
        {
            sqlConn.Open();
            SqlCommand sqlCom = new SqlCommand(sqlQuery, sqlConn);
            SqlDataReader sqlReader = sqlCom.ExecuteReader();
            while (sqlReader.Read())
            {
                actionDate = sqlReader["actionDueDate"].ToString();
                DateTime date1 = ConvertToDateTime(actionDate);
                DateTime date2 = ConvertToDateTime(System.DateTime.Now.ToString());
                int result123 = DateTime.Compare(date2, date1);
                if (result123 == 1)
                {

                }
            }
            sqlReader.Close();
        }
        catch (Exception ex)
        {
            Response.Write("Error getting while reading data !" + ex.Message);
        }
        finally
        {
            sqlConn.Close();
        }
    }
    private DateTime ConvertToDateTime(string strDateTime)
    {
        DateTime dtFinaldate; string sDateTime;
        try
        {
            //dtFinaldate = Convert.ToDateTime(strDateTime); 

            string[] sDate = strDateTime.Split('/');
            sDateTime = sDate[1] + '/' + sDate[0] + '/' + sDate[2];
            dtFinaldate = Convert.ToDateTime(sDateTime);
        }
        catch (Exception e)
        {
            string[] sDate = strDateTime.Split('/');
            sDateTime = sDate[0] + '/' + sDate[1] + '/' + sDate[2];
            dtFinaldate = Convert.ToDateTime(sDateTime);
        }
        return dtFinaldate;
    }


    public override void VerifyRenderingInServerForm(Control control)
    {
        /* Confirms that an HtmlForm control is rendered for the specified ASP.NET
           server control at run time. */
    }
    protected void chartPayAffair_Click(object sender, ImageMapEventArgs e)
    {

    }
    protected void onGoingTasksPerSectionChart_Load(object sender, EventArgs e)
    {

    }
    protected void gridDocs_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        gridDocs.PageIndex = e.NewPageIndex;
        //  bindGridView();

        DataTable dt = new DataTable();
        dt = Session["getPayDataDocs"] as DataTable;

        // lblCntDoc.Text = "(" + dt.Rows.Count.ToString() + ")";

        gridDocs.DataSource = dt;
        gridDocs.DataBind();

        PageloadData();
    }
    protected void lnkUploadDoc_Click(object sender, EventArgs e)
    {
        Session["docID"] = null;
        Session["JobID"] = null;
        Session["PayID"] = null;

        Response.Redirect("~/Documents/DocumentDetailsWindow.aspx?btnDocNew=2&RecSentCatID=2", false);
    }
    protected void lnkVO_CC_Click(object sender, EventArgs e)
    {
        Session["docType"] = null;
        Session["docType"] = "9";   // vo
        Response.Redirect("~/Documents/DocumentDetailsWindow.aspx?btnDocNew=2&RecSentCatID=2", false);
    }
    protected void lnkCE_CS_Click(object sender, EventArgs e)
    {
        Session["docType"] = null;
        Session["docType"] = "10"; //CE
        Response.Redirect("~/Documents/DocumentDetailsWindow.aspx?btnDocNew=2&RecSentCatID=2", false);
    }
    protected void lnkAdm_Consultant_Click(object sender, EventArgs e)
    {
        Session["docType"] = null;
        Session["docType"] = "11";  //Addendum
        Response.Redirect("~/Documents/DocumentDetailsWindow.aspx?btnDocNew=2&RecSentCatID=2", false);
    }
    protected void lnkPayment_Click(object sender, EventArgs e)
    {
        Session["docType"] = null;
        Session["docType"] = "12";    //Pay
        Response.Redirect("~/Documents/DocumentDetailsWindow.aspx?btnDocNew=2&RecSentCatID=2", false);
    }
    protected void lnkSurvey_Click(object sender, EventArgs e)
    {

    }
    protected void btnSearchDoc_Click(object sender, EventArgs e)
    {
        string strUpdateJob = Request.Url.AbsoluteUri;
        Session["UrlRef"] = strUpdateJob;
        //uCls = new UtilityClass(this.Page);
        //uCls.ResetTheSessionVariables();
        Session["SearchMyDocs"] = "1";
        Response.Redirect("~/Documents/SearchDocument.aspx", false);
    }
    protected void btnUploadDoc_Click(object sender, EventArgs e)
    {
        Session["docID"] = null;
        Session["JobID"] = null;
        Session["PayID"] = null;

        //Response.Redirect("~/Documents/DocumentDetailsWindow.aspx?btnDocNew=2&RecSentCatID=2", false);

        Response.Redirect("~/Documents/NonEBDDocumentInfo.aspx?btnDocNew=2&RecSentCatID=2", false);
    }
    protected void btnUploadVO_Click(object sender, EventArgs e)
    {
        Session["docType"] = null;
        Session["docType"] = "9";   // vo
        Response.Redirect("~/Documents/NonEBDDocumentInfo.aspx?btnDocNew=2&RecSentCatID=2", false);
    }
    protected void btnUploadCE_Click(object sender, EventArgs e)
    {
        Session["docType"] = null;
        Session["docType"] = "10"; //CE
        Response.Redirect("~/Documents/NonEBDDocumentInfo.aspx?btnDocNew=2&RecSentCatID=2", false);
    }
    protected void btnUploadAdm_Click(object sender, EventArgs e)
    {
        Session["docType"] = null;
        Session["docType"] = "11";  //Addendum
        Response.Redirect("~/Documents/NonEBDDocumentInfo.aspx?btnDocNew=2&RecSentCatID=2", false);
    }
    protected void btnUploadPay_Click(object sender, EventArgs e)
    {
        Session["docType"] = null;
        Session["docType"] = "12";    //Pay
        Response.Redirect("~/Documents/NonEBDDocumentInfo.aspx?btnDocNew=2&RecSentCatID=2", false);
    }
    protected void myDocsTypes_Click(object sender, ImageMapEventArgs e)
    {

    }

    private void getMyDocumentTypeChart()
    {
        DataSet dsDoc = new DataSet();

        string sqlQuery = null;

        sqlQuery = "SELECT DocumentType.documentType, COUNT([Document].documentID) AS DocCnt FROM DocumentType INNER JOIN " +
                       "  [Document] ON DocumentType.docTypeID = [Document].docTypeID WHERE ([Document].docCreatedByID = " + _currentUserID + ") GROUP BY DocumentType.documentType";

        SqlDataAdapter daDoc = new SqlDataAdapter(sqlQuery, connValue);
        daDoc.Fill(dsDoc);
        if (dsDoc.Tables[0].Rows.Count != 0)
        {
            myDocsTypesChart.DataSource = dsDoc.Tables[0].DefaultView;
            myDocsTypesChart.Series["Series1"].XValueMember = "documentType";
            myDocsTypesChart.Series["Series1"].YValueMembers = "DocCnt";

            dsDoc.Tables.Clear();

            myDocsTypesChart.ChartAreas[0].AxisX.MajorGrid.Enabled = false;
            myDocsTypesChart.ChartAreas[0].AxisX.MinorGrid.Enabled = false;
            myDocsTypesChart.ChartAreas[0].AxisY.MajorGrid.Enabled = false;
            myDocsTypesChart.ChartAreas[0].AxisY.MinorGrid.Enabled = false;

            myDocsTypesChart.ChartAreas[0].AxisX.LabelStyle.Angle = 30;
            myDocsTypesChart.ChartAreas[0].AxisX.LabelStyle.ForeColor = Color.Maroon;

            myDocsTypesChart.ChartAreas[0].AxisX.Interval = 1;
        }
        else
        {
            trTypes.Visible = false;
            myDocsTypesChart.Visible = false;
        }
    }
    protected void myDocsTypesChart_Click(object sender, ImageMapEventArgs e)
    {
        getMyDocumentChart();
        getMyDocumentTypeChart();
    }
    protected void myDocsTypesChart_Click1(object sender, ImageMapEventArgs e)
    {
        getMyDocumentChart();
        getMyDocumentTypeChart();

    }
}