﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using Datalayer;
using System.Data.SqlClient;
using System.Globalization;

public partial class JobOrder_AddendumForm : System.Web.UI.Page
{
    string connValue = System.Configuration.ConfigurationManager.ConnectionStrings["EBSDEBookConn"].ConnectionString;

    int _jobID = 0;
    IList<string> userRightsColl = new List<string>();
    int admID = 0;
    protected void Page_Load(object sender, EventArgs e)
    {
        _jobID = Convert.ToInt32(Request.QueryString["JobID"]);

        userRightsColl = (IList<string>)Session["UserRightsColl"];

        if (!IsPostBack)
        {
            tblAdd.Visible = false;
            lblJobNo.Text = Request.QueryString["JobNo"].ToString();

            lnkJobNo.Text = Request.QueryString["JobNo"].ToString();
          //  FillTab2();
        }
        FillAddendumData();
    }
    private void FillAddendumData()
    {
        try
        {
            DataSet ds = new DataSet();
            ds = (new JobOrderData().GetDDlDetails_JOBAddendumInfo(_jobID));

            //   Convert.ToInt32(txtjobid.Text), txtJobNo.Text, Convert.ToInt32(txtaffair.Text), Convert.ToInt32(txtdept.Text), txtprojcode.Text, txtprojtitle.Text, Convert.ToInt32(txtconsult.Text)));

            if (ds.Tables[0].Rows.Count == 0)
            {
                ds.Tables[0].Rows.Add(ds.Tables[0].NewRow());
            }


            grvAdmData.DataSource = ds;
            grvAdmData.DataBind();
        }
        catch (Exception ex)
        {

        }
    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        if (lblAdmID.Text != "")
            admID = Convert.ToInt32(lblAdmID.Text);

        if ((grvAdmData.Rows.Count == 0) & (txtFaxConsult.Text == ""))        //if ((grvAdmData.Rows.Count != 0) & (txtFaxConsult.Text == ""))
        {
            // rqConsultantSig.Visible = true;

            lblValidate.Text = "Please enter FaxToConsultant Value";
            return;
        }
        else
            lblValidate.Text = "";

            Add_AddendumData(admID);   

        // UpdateJobStatus();

            FillAddendumData();

        ClearData();

        tblAdd.Visible = false;
    }
    private string setAlertMessage(ref string alertDate)
    {
        string strAlertRemarks = string.Empty;

        if (txtFrwdFinance.Text != "")
        {
            strAlertRemarks = "";
            // alertDate = getEndDateByGivenDays(0, txtFrwdFinance.Text);

            alertDate = txtFrwdFinance.Text; 
        }
        else if (txtPresidentApprove.Text != "")
        {
            strAlertRemarks = "Follow Up President's Office to Sign the Addendum";
            alertDate = getEndDateByGivenDays(3, txtPresidentApprove.Text);            
        }
        else if (txtBondTransfer.Text != "")
        {
            strAlertRemarks = " Consultant Remarks";            
            //alertDate = getEndDateByGivenDays(0, txtBondTransfer.Text); 

            alertDate = txtBondTransfer.Text; 
        }
        else if (txtReminderBond.Text != "")
        {
            strAlertRemarks = "Follow Up Consultant to Sign the Addendum";           
            alertDate = getEndDateByGivenDays(3, txtReminderBond.Text);

           // alertDate = txtReminderBond.Text; 
        }
        else if (txtCnsultBondExt.Text != "")
        {
            strAlertRemarks = "Follow Up Consultant to Extend Performance Bond";          
            alertDate = getEndDateByGivenDays(3, txtCnsultBondExt.Text);           
        }
        else if (txtSentSign.Text != "")
        {
            strAlertRemarks = "Follow Up Department to Sign the Addendum";           
            alertDate = getEndDateByGivenDays(5, txtSentSign.Text); 
        }
        else if (txtReturnedByCmt.Text != "")
        {
            strAlertRemarks = "Follow Up Department to Sign the Addendum";            
           // alertDate = getEndDateByGivenDays(0, txtReturnedByCmt.Text);

            alertDate = txtReturnedByCmt.Text; 
        }
        else if (txtSentCmt.Text != "")
        {
            strAlertRemarks = "Follow Up the Addendum to Committee";
            alertDate = getEndDateByGivenDays(12, txtSentCmt.Text); 
        }
        else if (txtReminderConsult.Text != "")
        {
            strAlertRemarks = "Follow Up Consultant to Sign the Addendum";           
            alertDate = getEndDateByGivenDays(5, txtReminderConsult.Text); 
        }
        else if (txtFaxConsult.Text != "")
        {
            strAlertRemarks = "Follow Up Consultant to Sign the Addendum";
            alertDate = getEndDateByGivenDays(5, txtFaxConsult.Text); 
        }

        return strAlertRemarks;

    }
    private void ChangePSAjobStatus()
    {
        if (grvAdmData.Rows.Count > 0)
        {
            if (grvAdmData.Rows[0].Cells[0].ToString() != "")
            {

            }
        }
    }
    private string getEndDateByGivenDays(int days, string strDate)
    {
        // strDate = Convert.ToDateTime(strDate).ToString("MM/dd/yyyy", CultureInfo.InvariantCulture);


      //  DateTime strDt = DateTime.ParseExact(strDate, "MM/dd/yyyy", CultureInfo.InvariantCulture);

        SqlConnection con = new SqlConnection(connValue);
        SqlCommand cmd = new SqlCommand();
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Connection = con;
        if (days != 0)
        {
            cmd.CommandText = "AddWorkdays";
            SqlParameter prm = cmd.Parameters.Add("@ad_startDate", SqlDbType.DateTime);
            prm.Value = strDate;

            prm = cmd.Parameters.Add("@actual_workDays", SqlDbType.Int);
            prm.Value = days;     //Convert.ToInt32(txtWorkDays.Text)

            prm = cmd.Parameters.Add("@endDate", SqlDbType.DateTime);
            prm.Direction = ParameterDirection.Output;

            con.Open();
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
                Console.WriteLine(dr.GetString(0));
            con.Dispose();
            con.Close();
        }
        return cmd.Parameters[2].Value.ToString();
    }
    private void UpdateJobStatus()
    {
        #region

        if (txtFrwdFinance.Text != "")
        {
            StatusUpdate(_jobID, 1, txtFrwdFinance.Text);
            lblJobStatus.Text =  " Current Job Order Status is "  + "Closed";
        }
        else if (txtPresidentApprove.Text != "")
        {
            StatusUpdate(_jobID, 13, txtPresidentApprove.Text);
            lblJobStatus.Text = " Current Job Order Status is " + "Waiting President Signature";
        }
        else if (txtBondTransfer.Text != "")
        {
            //StatusUpdate(_jobID, 1); 
        }
        else if (txtReminderBond.Text != "")
        {
            StatusUpdate(_jobID, 12, txtReminderBond.Text);
            lblJobStatus.Text = " Current Job Order Status is " +  "Waiting PB From Consultant";
        }
        else if (txtCnsultBondExt.Text != "")
        {
            StatusUpdate(_jobID, 12, txtCnsultBondExt.Text);
            lblJobStatus.Text = " Current Job Order Status is " +  "Waiting PB From Consultant";
        }
        else if (txtSentSign.Text != "")
        {
            StatusUpdate(_jobID, 11, txtSentSign.Text);
            lblJobStatus.Text = " Current Job Order Status is " +  "Waiting Dept. Manager Signature";
        }
        else if (txtReturnedByCmt.Text != "")
        {
            StatusUpdate(_jobID, 10, txtReturnedByCmt.Text);
            lblJobStatus.Text = " Current Job Order Status is " +  "Pending with the Committee";
        }
        else if (txtSentCmt.Text != "")
        {
            StatusUpdate(_jobID, 10, txtSentCmt.Text);
            lblJobStatus.Text = " Current Job Order Status is " +  "Pending with the Committee";
        }
        else if (txtReminderConsult.Text != "")
        {
            StatusUpdate(_jobID, 9, txtReminderConsult.Text);
            lblJobStatus.Text = " Current Job Order Status is " +  "Waiting Consultant Signature";
        }
        else if (txtFaxConsult.Text != "")
        {
            StatusUpdate(_jobID, 9, txtFaxConsult.Text);
            lblJobStatus.Text = " Current Job Order Status is " +  "Waiting Consultant Signature";
        }
        else
        {
            StatusUpdate(_jobID, 8, txtFaxConsult.Text);
            lblJobStatus.Text = " Current Job Order Status is " + "Under Process with EBSD";
        }

        #endregion
    }

    private void StatusUpdateNew(int _jobID, int statID, string jobStatCompleteDate)
    {
        string updateQuery = string.Empty;
        string dateCompleted = string.Empty;        

        SqlConnection _con = new SqlConnection(connValue);
       
        if (statID != 8)
            updateQuery = "Update Job Set jobStatusID = @statusID,jobStatusClosedDate = @jobStatusClosedDate where jobID = @jobID";
        else
            updateQuery = "Update Job Set jobStatusID =@statusID,jobStatusClosedDate= @jobStatusClosedDate,jobClosedDate = @jobClosedDate,closedDocRefID = @closedDocRefID where jobID = @jobID";

        SqlCommand _cmdInsert = new SqlCommand(updateQuery, _con);
        _cmdInsert.Parameters.AddWithValue("@jobID", _jobID);
        _cmdInsert.Parameters.AddWithValue("@statusID", statID);

        if (jobStatCompleteDate != "")
            _cmdInsert.Parameters.AddWithValue("@jobStatusClosedDate", Convert.ToDateTime(jobStatCompleteDate).ToString("dd/MMM/yyyy"));
        else
            _cmdInsert.Parameters.AddWithValue("@jobStatusClosedDate", System.DBNull.Value);

        if (statID == 8)
        {
            _cmdInsert.Parameters.AddWithValue("@jobClosedDate", System.DBNull.Value);
            _cmdInsert.Parameters.AddWithValue("@closedDocRefID", System.DBNull.Value);
        }

        try
        {
            _con.Open();
            _cmdInsert.ExecuteNonQuery();
        }
        finally
        {
            _con.Close();
        }
    }

    private void StatusUpdate(int _jobID, int statID, string jobStatCompleteDate)
    {
        string updateQuery = string.Empty;
        string dateCompleted = string.Empty;
                

        SqlConnection _con = new SqlConnection(connValue);
        if (statID != 8)
            updateQuery = "Update Job Set jobStatusID =@statusID,jobStatusClosedDate=@jobStatusClosedDate where jobID = @jobID";
        else
            updateQuery = "Update Job Set jobStatusID =@statusID,jobStatusClosedDate=@jobStatusClosedDate,jobClosedDate = @jobClosedDate,closedDocRefID=@closedDocRefID where jobID = @jobID";

        SqlCommand _cmdInsert = new SqlCommand(updateQuery, _con);

        _cmdInsert.Parameters.AddWithValue("@jobID", _jobID);
        _cmdInsert.Parameters.AddWithValue("@statusID", statID);

        if (jobStatCompleteDate != "")
            _cmdInsert.Parameters.AddWithValue("@jobStatusClosedDate", Convert.ToDateTime(jobStatCompleteDate).ToString("dd/MMM/yyyy"));
        else
            _cmdInsert.Parameters.AddWithValue("@jobStatusClosedDate", System.DBNull.Value);

        if (statID == 8)
        {
            _cmdInsert.Parameters.AddWithValue("@jobClosedDate", System.DBNull.Value);
            _cmdInsert.Parameters.AddWithValue("@closedDocRefID", System.DBNull.Value);
        }

        try
        {
            _con.Open();
            _cmdInsert.ExecuteNonQuery();
        }
        finally
        {
            _con.Close();
        }
    }
    private DateTime ConvertToDateTime(string strDateTime)
    {
        DateTime dtFinaldate;
        string sDateTime;

        try
        {
            //dtFinaldate = Convert.ToDateTime(strDateTime); 
            string[] sDate = strDateTime.Split('/');
            sDateTime = sDate[1] + '/' + sDate[0] + '/' + sDate[2];
            dtFinaldate = Convert.ToDateTime(sDateTime);
        }
        catch (Exception e)
        {
            string[] sDate = strDateTime.Split('/');
            sDateTime = sDate[0] + '/' + sDate[1] + '/' + sDate[2];
            dtFinaldate = Convert.ToDateTime(sDateTime);
        }
        return dtFinaldate;
    }
    private void ClearData()
    {
        txtFaxConsult.Text = "";
        txtReminderConsult.Text = "";
        txtSentCmt.Text = "";

        txtReturnedByCmt.Text = "";
        txtSentSign.Text = "";
        txtCnsultBondExt.Text = "";

        txtReminderBond.Text = "";
        txtBondTransfer.Text = "";
        txtPresidentApprove.Text = "";

        txtFrwdFinance.Text = "";
        txtRemarks.Text = "";

        lblAdmID.Text = "";
    }
    protected void btnDelete_Click(object sender, EventArgs e)
    {
        if (lblAdmID.Text != "")
        {
            if (checkTopAddendumData(_jobID) != Convert.ToInt32(lblAdmID.Text))
              DeleteAddendumData(Convert.ToInt32(lblAdmID.Text));
           
            ClearData();
            FillAddendumData();

            tblAdd.Visible = false;
        }
    }
    private int checkTopAddendumData(int jobID)
    {
        int admID = 0;
        string deleteQry = "Select Top 1 adID from JobAddendumInfo Where jobID =" + jobID;
        using (SqlConnection cn = new SqlConnection(connValue))
        {
            cn.Open();
            using (SqlCommand cmd = new SqlCommand(deleteQry, cn))
            {
                using (SqlDataReader dr = cmd.ExecuteReader())
                {
                    while (dr.Read())
                    {
                        admID = Convert.ToInt32(dr["adID"]);
                    }
                }
            }
        }
        return admID;
        
    }
    private void DeleteAddendumData(int admID)
    {
        string deleteQry = "Delete from JobAddendumInfo Where adID =" + admID;
        using (SqlConnection cn = new SqlConnection(connValue))
        {
            cn.Open();
            using (SqlCommand cmd = new SqlCommand(deleteQry, cn))
            {
                cmd.ExecuteNonQuery();
            }
        }
    }
    protected void grvAdmData_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName.Equals("SelectAdm"))
        {
            //if (userRightsColl.Contains("4"))
            //{
            //    ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('You have no access rights to delete staff incharge.')</script>", false);
            //    return;
            //}

            tblAdd.Visible = true;

            string arguments = e.CommandArgument.ToString();

            if (arguments == "")
                return;

            string[] args = arguments.Split(';');
           
            admID = Convert.ToInt32(args[0]);

          //  if (userRightsColl.Contains("4")) // Access Right is 4 
            {
                fillAddendumData(admID);
            }

            btnSubmit.Text = " Update Data";
        }
    }
    private void fillAddendumData(int admID)
    {
       string qry = "SELECT  REPLACE(CONVERT(NVARCHAR, faxToConsultantOn, 106), ' ', '-') AS faxToConsultantOn, REPLACE(CONVERT(NVARCHAR, reminderConsultantOn, 106), ' ', '-') as reminderConsultantOn  , " + 
        " REPLACE(CONVERT(NVARCHAR, sentCommitteeOn, 106), ' ', '-') as sentCommitteeOn,  " +
                    " REPLACE(CONVERT(NVARCHAR, returnedCommitteeOn, 106), ' ', '-') AS returnedCommitteeOn , REPLACE(CONVERT(NVARCHAR, sentDeptSignatureOn, 106), ' ', '-') AS sentDeptSignatureOn , REPLACE(CONVERT(NVARCHAR, faxToConPBondExtOn, 106), ' ', '-') AS faxToConPBondExtOn , REPLACE(CONVERT(NVARCHAR, remPBondExtOn, 106), ' ', '-') AS remPBondExtOn , " +
                       "REPLACE(CONVERT(NVARCHAR, budgetTransferOn, 106), ' ', '-') AS budgetTransferOn, REPLACE(CONVERT(NVARCHAR, presidentApprovalOn, 106), ' ', '-') AS presidentApprovalOn,  REPLACE(CONVERT(NVARCHAR, forwardedFinanceOn, 106), ' ', '-') AS forwardedFinanceOn , Remarks,REPLACE(CONVERT(NVARCHAR, AlertDate, 106), ' ', '-') AS AlertDate, AlertReminderMsg,jobID, adID FROM  JobAddendumInfo " +
                       " WHERE (adID = " + admID + ") Order by adID";

       using (SqlConnection cn = new SqlConnection(connValue))
       {
           cn.Open();
           using (SqlCommand cmd = new SqlCommand(qry,cn))
           {
               using (SqlDataReader dr = cmd.ExecuteReader())
               {
                   while (dr.Read())
                   {
                       txtFaxConsult.Text = dr["faxToConsultantOn"].ToString();
                       txtReminderConsult.Text = dr["reminderConsultantOn"].ToString();

                       txtSentCmt.Text = dr["sentCommitteeOn"].ToString();
                       txtReturnedByCmt.Text = dr["returnedCommitteeOn"].ToString();

                       txtSentSign.Text = dr["sentDeptSignatureOn"].ToString();
                       txtCnsultBondExt.Text = dr["faxToConPBondExtOn"].ToString();

                       txtReminderBond.Text = dr["remPBondExtOn"].ToString();
                       txtBondTransfer.Text = dr["budgetTransferOn"].ToString();

                       txtPresidentApprove.Text = dr["presidentApprovalOn"].ToString();
                       txtFrwdFinance.Text = dr["forwardedFinanceOn"].ToString();

                       lblAdmID.Text = admID.ToString();

                       txtRemarks.Text = dr["Remarks"].ToString();

                       lblAlert.Text = "Alert Date : - " + dr["AlertDate"].ToString() + " --- Alert Message : - " + dr["AlertReminderMsg"].ToString();

                   }
               }
           }
       }
    }

    private void Add_AddendumData(int admID)
    {
        string _txtfaxToConsultantOn = string.Empty;
        string txtConsulOn_ = string.Empty;
        string txtSentCmtOn_ = string.Empty;
        string txtRetCmtOn_ = string.Empty;

        string txtDeptSignOn_ = string.Empty;
        string txtfaxToConPBondExtOn_ = string.Empty;
        string txtremPBondExtOn_ = string.Empty;

        string txtbudgetTransferOn_ = string.Empty;
        string txtpresidentApprovalOn_ = string.Empty;
        string txtforwardedFinanceOn_ = string.Empty;

        string remarks = string.Empty;

        string alertDate = string.Empty;
        string alertRemarks = string.Empty;



       _txtfaxToConsultantOn= txtFaxConsult.Text; 
        txtConsulOn_ =  txtReminderConsult.Text;
        txtSentCmtOn_ = txtSentCmt.Text;

        txtRetCmtOn_ =  txtReturnedByCmt.Text;

        txtDeptSignOn_ = txtSentSign.Text; 
        txtfaxToConPBondExtOn_=   txtCnsultBondExt.Text;

        txtremPBondExtOn_= txtReminderBond.Text;
        txtbudgetTransferOn_ = txtBondTransfer.Text; 

        txtpresidentApprovalOn_=  txtPresidentApprove.Text;
        txtforwardedFinanceOn_ = txtFrwdFinance.Text;

        remarks = txtRemarks.Text;

        alertRemarks = setAlertMessage(ref alertDate);

        //SpName - InsertAddendumData

       //new JobOrderData().Add_JOBAddendumInfo(admID, _jobID, _txtfaxToConsultantOn, txtConsulOn_, txtSentCmtOn_, txtRetCmtOn_, txtDeptSignOn_, txtfaxToConPBondExtOn_, txtremPBondExtOn_, txtbudgetTransferOn_, txtpresidentApprovalOn_, txtforwardedFinanceOn_, remarks, alertDate, alertRemarks);


        if (txtforwardedFinanceOn_ != "")
        {
            // JobStatusID = 1
            UpdateJobFinalClosedDate(_jobID, txtforwardedFinanceOn_,1);
        }
        else if (txtpresidentApprovalOn_ != "")  //3
        {
            // JobStatusID = 13
            UpdateJobStatus(_jobID, 13);
        }
        else if (txtfaxToConPBondExtOn_ != "") // 6 
        {
            // JobStatusID = 12
            UpdateJobStatus(_jobID, 12);
        }
        else if (txtDeptSignOn_ != "") // 5 
        {
            // JobStatusID = 11
            UpdateJobStatus(_jobID, 11);
        }
        else if (txtSentCmtOn_ != "") // 12 
        {
            // JobStatusID = 10
            UpdateJobStatus(_jobID, 10);
        }
        else if (_txtfaxToConsultantOn != "") // 5 
        {
            UpdateJobCompletedDate(_jobID, _txtfaxToConsultantOn,9);
        }        
    }
    private void UpdateJobCompletedDate(int _jobid, string _txtfaxToConsultantOn,int statusID)
    {
        string updateQuery = "Update Job Set jobStatusClosedDate = @jobStatusClosedDate,jobStatusID = @jobStatusID where jobID = @jobID";
        using (SqlConnection cn = new SqlConnection(connValue))
        {
            cn.Open();
            using (SqlCommand cmd = new SqlCommand(updateQuery, cn))
            {
                cmd.Parameters.AddWithValue("@jobStatusClosedDate", Convert.ToDateTime(_txtfaxToConsultantOn).ToString("dd/MMM/yyyy"));
                cmd.Parameters.AddWithValue("@jobStatusID", statusID);
                cmd.Parameters.AddWithValue("@jobID", _jobid);
                cmd.ExecuteNonQuery();
            }
        }
    }
    private void UpdateJobFinalClosedDate(int _jobid, string _txtfaxToConsultantOn,int statusID)
    {
        string updateQuery = "Update Job Set jobClosedDate = @jobClosedDate,jobStatusID = @jobStatusID where jobID = @jobID";
        using (SqlConnection cn = new SqlConnection(connValue))
        {
            cn.Open();
            using (SqlCommand cmd = new SqlCommand(updateQuery, cn))
            {
                cmd.Parameters.AddWithValue("@jobClosedDate", Convert.ToDateTime(_txtfaxToConsultantOn).ToString("dd/MMM/yyyy"));
                cmd.Parameters.AddWithValue("@jobStatusID", statusID);
                cmd.Parameters.AddWithValue("@jobID", _jobid);

                cmd.ExecuteNonQuery();
            }
        }
    }
    private void UpdateJobStatus(int _jobid, int statusID)
    {
        string updateQuery = "Update Job Set jobStatusID = @jobStatusID where jobID = @jobID";
        using (SqlConnection cn = new SqlConnection(connValue))
        {
            cn.Open();
            using (SqlCommand cmd = new SqlCommand(updateQuery, cn))
            {
               
                cmd.Parameters.AddWithValue("@jobStatusID", statusID);
                cmd.Parameters.AddWithValue("@jobID", _jobid);

                cmd.ExecuteNonQuery();
            }
        }
    }
    protected void btnClear_Click(object sender, EventArgs e)
    {
        ClearData();
    }
    protected void btnBack_Click(object sender, EventArgs e)
    {
        ClearData();
      
        Response.Redirect("~/JobOrder/SearchAdmData.aspx", false);
    }
    protected void txtSentSign_TextChanged(object sender, EventArgs e)
    {

    }
    protected void txtFaxConsult_TextChanged(object sender, EventArgs e)
    {

    }
    int topAdmID = 0; int iCnt = 0;
    protected void grvAdmData_RowDataBound(object sender, GridViewRowEventArgs e)
    {       
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            iCnt = iCnt + 1;

            if (iCnt==1)
            {              
                Label lblAdmID = (Label)e.Row.FindControl("lblAdmID");
                topAdmID = Convert.ToInt32(lblAdmID.Text);
            }

        }
    }
    protected void btnAdd_Click(object sender, EventArgs e)
    {
        ClearData();
       
        tblAdd.Visible = true;

    }
    protected void lnkJobNo_Click2(object sender, EventArgs e)
    {
        string strUpdateJob = Request.Url.AbsoluteUri;
        try
        {
            LinkButton lnkJobID = (LinkButton)sender;

            Session["JobID"] = lnkJobID.ToolTip;  

            Session["UrlRef"] = "~/JobOrder/PSAJobDetails.aspx";
            Response.Redirect("~/JobOrder/PSAJobDetails.aspx?JobID= " + Session["JobID"] + "", false);
          
        }
        catch (Exception ex)
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Error occurred while processing the request')</script>", false);
        }
    }
}