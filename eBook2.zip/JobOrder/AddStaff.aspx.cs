﻿using System;
using System.Collections.Generic;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using Datalayer;
using PropertyLayer;
using System.Globalization;
using System.Runtime.InteropServices;
using Microsoft.Office.Interop.Outlook;

using Outlook = Microsoft.Office.Interop.Outlook;
using System.Net.Mail;
using System.Configuration;

using System.Net.Security;
using System.Security.Cryptography.X509Certificates;
using System.Net;

public partial class JobOrder_AddStaff : System.Web.UI.Page
{
    string connValue = System.Configuration.ConfigurationManager.ConnectionStrings["EBSDEBookConn"].ConnectionString;
    int _jobID = 0;
    string _jobNo = string.Empty;
    int teamleadID = 0; int InchargeID = 0;
    IList<string> userRightsColl = new List<string>();
    protected void Page_Load(object sender, EventArgs e)
    {
        _jobID = Convert.ToInt32(Session["Upd_jobID"]); 
        teamleadID = Convert.ToInt32(Session["teamLeaderID"]);

        userRightsColl = (IList<string>)Session["UserRightsColl"];

        if (Request.QueryString["InchargeID"]!=null)
           InchargeID = Convert.ToInt32(Request.QueryString["InchargeID"]);

        if (!IsPostBack)
        {
            string getStaff =  string.Empty;
            if (teamleadID.Equals(6))
            {
                getStaff = "Select contactID,teamLeaderName From EBSDTeamLeaders where teamLeaderID <>6  order by teamLeaderName";
                PopulateDropDownBox(ddlQS, getStaff, "contactID", "teamLeaderName");
            }            
            else
            {
                getStaff = "SELECT contactID, userShortName FROM Contact WHERE (userShortName IS NOT NULL) AND (contactID <> " + Session["UserID"] + ") AND (isActive = 1) AND (sectionID = " + Convert.ToInt32(Session["SectionID"]) + " OR sectionID = 6 OR sectionID = 7) AND (companyID = 362) AND teamleaderID =" + teamleadID + " ORDER BY userShortName";
                PopulateDropDownBox(ddlQS, getStaff, "contactID", "userShortName");
            }            

            //else if (Session["userProfileID"].Equals("1"))
            //{
            //    getStaff = "SELECT contactID, userShortName FROM Contact WHERE (userShortName IS NOT NULL) AND (contactID <> " + Session["UserID"] + ") AND (isActive = 1) AND (sectionID = " + Convert.ToInt32(Session["SectionID"]) + " OR sectionID = 6 OR sectionID = 7) AND (companyID = 362) AND teamleaderID =" + teamleadID + " ORDER BY userShortName";            

            //}

            PopulateDropDownBox(ddlTeamLead, "Select teamLeaderID,teamLeaderName From EBSDTeamLeaders where sectionID =1 order by teamLeaderName", "teamLeaderID", "teamLeaderName");  
            
            PopulateDropDownBox(ddlTask, "SELECT jobPurposeID, jobPurposeName FROM JobPurpose ", "jobPurposeID", "jobPurposeName"); 
            PopulateDropDownBoxForStaffRole(ddlStaffType, "SELECT jobOwnerCatID, jobOwnerCategory FROM JobOwnerCategory ", "jobOwnerCatID", "jobOwnerCategory");

            if (Request.QueryString["InchargeID"] != null)
            {
                trTeamLead.Visible = false;

                lblTitle.Text = "View/Update Staff In Charge";

                ddlQS.DataSource = null;
                getStaff = "SELECT contactID, userShortName FROM Contact WHERE (userShortName IS NOT NULL) AND (contactID <> " + Session["UserID"] + ") AND (isActive = 1) AND (sectionID = " + Convert.ToInt32(Session["SectionID"]) + " OR sectionID = 6 OR sectionID = 7) AND (companyID = 362)  ORDER BY userShortName";
                PopulateDropDownBox(ddlQS, getStaff, "contactID", "userShortName");

                InchargeID = Convert.ToInt32(Request.QueryString["InchargeID"]);
                getStaffData(InchargeID);

                btnAdd.Text = "Update Data";
                btnDelete.Visible = true;

                if (lblDateOfIssue.Text == "")
                  lblDateOfIssue.Text = System.DateTime.Now.ToString();

                Session["QSRoleID"] = ddlStaffType.SelectedItem.Value;

            }
            else
            {
                trTeamLead.Visible = true;

                ddlStaffType.SelectedIndex = 0;

                btnAdd.Text = "Add Staff Incharge";
                btnDelete.Visible = false;

                IList<string> _staffColl = new List<string>();
                _staffColl = getInchargeList();
                
                txtWorkDays.Text = "4";

                 // string endDate = getEndDateByGivenDays(Convert.ToInt32(txtWorkDays.Text), lblDateOfIssue.Text);

                string endDate = getEndDateByGivenDays(Convert.ToInt32(txtWorkDays.Text), System.DateTime.Now.ToString());
                txtDueDate.Text = Convert.ToDateTime(endDate).ToString("dd/MMM/yyyy");

                ddlTask.SelectedValue = "4";
                ddlTeamLead.SelectedValue = teamleadID.ToString();

                lblDateOfIssue.Text = System.DateTime.Now.ToString();
            }
        }       
    }
    public void getStaffData(int inchargeID)
    {
        IList<string> staffColl = new List<string>();
        try
        {
            SqlConnection sqlConn = new SqlConnection(connValue);
            sqlConn.Open();
            SqlCommand sqlCom = new SqlCommand("select contactID, StaffRoleID,jobPurposeID,actionDueDate, daysToAct,completionDate,StaffRoleID,remarks,isTLApprove,distributedBy,staffIssueDate from JobOwner where jobOwnerID = " + inchargeID + " ", sqlConn);
            SqlDataReader sqlReader = sqlCom.ExecuteReader();
            while (sqlReader.Read())
            {
                ddlQS.SelectedValue = sqlReader["contactID"].ToString();
                ddlTask.SelectedValue = sqlReader["jobPurposeID"].ToString();
                txtWorkDays.Text = sqlReader["daysToAct"].ToString();
                txtDueDate.Text = Convert.ToDateTime(sqlReader["actionDueDate"]).ToString("dd/MMM/yyyy");

                ddlStaffType.SelectedValue = sqlReader["StaffRoleID"].ToString();
                txtRemarks.Text = sqlReader["remarks"].ToString();

                chkTLApprove.Checked = Convert.ToBoolean(sqlReader["isTLApprove"]);

                lblDistributedBy.Text = sqlReader["distributedBy"].ToString();
                lblDateOfIssue.Text = Convert.ToDateTime(sqlReader["staffIssueDate"]).ToString("dd/MMM/yyyy");

                if (!lblDistributedBy.Text.Equals(Session["UserID"].ToString()))
                {
                    txtWorkDays.Enabled = false;
                    txtDueDate.Enabled = false;
                }
                else
                {
                    txtWorkDays.Enabled = true;
                    txtDueDate.Enabled = true;
                }
            }
            sqlReader.Close();
            sqlConn.Close();
        }
        catch (System.Exception ex)
        {
            throw ex;
        }        
    }
    public void UpdateInchargeData(int inchargeID)
    {
        int _ownerID = 0;
        using (SqlConnection con = new SqlConnection(connValue))
        {
            using (SqlCommand cmd = new SqlCommand())
            {
                try
                {
                    cmd.CommandType = CommandType.Text;
                    cmd.Connection = con;

                    if (lblDistributedBy.Text.Equals(Session["UserID"].ToString()))
                    {
                        cmd.CommandText = "Update JobOwner Set daysToAct =@daysToAct,remarks =@inchargeRemarks,jobPurposeID = @jobPurposeID,StaffRoleID = @StaffRoleID,actionDueDate =@actionDueDate where jobOwnerID = " + InchargeID;

                        cmd.Parameters.AddWithValue("@actionDueDate", Convert.ToDateTime(txtDueDate.Text).ToString("dd/MMM/yyyy"));
                        cmd.Parameters.AddWithValue("@daysToAct", txtWorkDays.Text);
                    }
                    else
                    {
                        cmd.CommandText = "Update JobOwner Set remarks =@inchargeRemarks,jobPurposeID = @jobPurposeID,StaffRoleID = @StaffRoleID where jobOwnerID = " + InchargeID;                        
                    }

                    //isTLApprove = @isTLApprove ,

                    // cmd.Parameters.AddWithValue("@contactID", _InchargeData.contactID);

                    //cmd.Parameters.AddWithValue("@distributedBy", _currentUserID);

                    

                    cmd.Parameters.AddWithValue("@inchargeRemarks", txtRemarks.Text);

                    cmd.Parameters.AddWithValue("@StaffRoleID", ddlStaffType.SelectedValue);

                    cmd.Parameters.AddWithValue("@jobPurposeID", ddlTask.SelectedValue);
                  
                    cmd.Parameters.AddWithValue("@jobOwnerID", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                  //  cmd.Parameters.AddWithValue("@isTLApprove", chkTLApprove.Checked);

                    con.Open();
                    cmd.ExecuteNonQuery();
                }
                catch (System.Exception ex)
                {
                    throw ex;
                }                
            }
        }
    }
    public IList<string> getInchargeList()
    {
        IList<string> staffColl = new List<string>();
        try
        {
            SqlConnection sqlConn = new SqlConnection(connValue);
            sqlConn.Open();
            SqlCommand sqlCom = new SqlCommand("select contactID from JobOwner where jobID = " + _jobID + " ", sqlConn);      
            SqlDataReader sqlReader = sqlCom.ExecuteReader();
            while (sqlReader.Read())
            {
                staffColl.Add(sqlReader["contactID"].ToString());               
            }
            sqlReader.Close();
            sqlConn.Close();
        }
        catch (System.Exception ex)
        {
            throw ex;
        }
        return staffColl;
    }
    
    private IList<string> getQSIDFromJobs()
    {
        IList<string> qsColl = new List<string>();
        try
        {
            SqlConnection sqlConn = new SqlConnection(connValue);
            sqlConn.Open();
            SqlCommand sqlCom = new SqlCommand("select qsID,ceID,peID from Job where jobID = " + _jobID + " ", sqlConn);       
            SqlDataReader sqlReader = sqlCom.ExecuteReader();
            while (sqlReader.Read())
            {
                qsColl.Add(sqlReader["qsID"].ToString());
                qsColl.Add(sqlReader["ceID"].ToString());
                qsColl.Add(sqlReader["peID"].ToString());
            }
            sqlReader.Close();
            sqlConn.Close();
        }
        catch (System.Exception ex)
        {
            throw ex;
        }
        return qsColl;
    }
    private void PopulateDropDownBox(DropDownList ddlBox, string sqlQuery, string valueMember, string displayName)
    {
        DataTable table = new DataTable();
        try
        {
            using (SqlConnection sqlConn = new SqlConnection(connValue))
            {
                using (SqlDataAdapter da = new SqlDataAdapter(sqlQuery, sqlConn))
                {
                    sqlConn.Open();
                    da.Fill(table);
                }
            }
            //cmbBox.Items.Add("Select");

            ddlBox.DataSource = table;
            ddlBox.DataTextField = displayName;
            ddlBox.DataValueField = valueMember;

            ddlBox.SelectedIndex = -1;
            ddlBox.DataBind();
            ddlBox.Items.Insert(0, new ListItem("--Select--"));
        }
        catch (System.Exception ex)
        {
            throw ex;
        }
    }
    private void PopulateDropDownBoxForStaffRole(DropDownList ddlBox, string sqlQuery, string valueMember, string displayName)
    {
        DataTable table = new DataTable();
        try
        {
            using (SqlConnection sqlConn = new SqlConnection(connValue))
            {
                using (SqlDataAdapter da = new SqlDataAdapter(sqlQuery, sqlConn))
                {
                    sqlConn.Open();
                    da.Fill(table);
                }
            }
            //cmbBox.Items.Add("Select");

            ddlBox.DataSource = table;
            ddlBox.DataTextField = displayName;
            ddlBox.DataValueField = valueMember;

            ddlBox.SelectedIndex = -1;
            ddlBox.DataBind();
            
        }
        catch (System.Exception ex)
        {
            throw ex;
        }
    }
    private Boolean ValidateControls()
    {
        Boolean chkCntrl = true;
        if (txtDueDate.Text == "")
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Please Enter DueDate')</script>", false);  
            chkCntrl = false;
        }
        if (ddlQS.SelectedIndex == 0)
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Please Select QS')</script>", false);  
            chkCntrl = false;
        }
        if (ddlTask.SelectedIndex == 0)
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Please Select Assigned Task')</script>", false);  
            chkCntrl = false;
        }
        if (ddlStaffType.SelectedIndex == -1)
        {
            chkCntrl = false;
        }
        return chkCntrl;
    }   
    public void CollectInchargeData()
    {
        jobInchargePLayer.contactID = Convert.ToInt32(ddlQS.SelectedValue);
        jobInchargePLayer.prjCode = "";
        jobInchargePLayer.prjTitle = "";
        jobInchargePLayer.jobNo = "";
        jobInchargePLayer.jobID = _jobID;       
        jobInchargePLayer.actionDueDate = txtDueDate.Text;
        jobInchargePLayer.daysToAct = Convert.ToInt32(txtWorkDays.Text);
        jobInchargePLayer.staffRoleID = Convert.ToInt32(ddlStaffType.SelectedValue);
        jobInchargePLayer.jobPurposeID = Convert.ToInt32(ddlTask.SelectedValue);       
    }
   
    int _jobStatID = 0;
    string _prjCode = string.Empty;
    string _prjTitle = string.Empty;

    private int getContactIDFromDocDisribution(int _contactID,int docID)
    {
        int cntctID = 0;
        try
        {
            SqlConnection sqlConn = new SqlConnection(connValue);
            sqlConn.Open();
            SqlCommand sqlCom = new SqlCommand("Select contactID from DocumentDistribution where ContactID = " + _contactID + " and documentID = " + docID + "", sqlConn);       
            
            SqlDataReader sqlReader = sqlCom.ExecuteReader();
            while (sqlReader.Read())
            {
                cntctID = Convert.ToInt32(sqlReader["contactID"]);
            }
            sqlReader.Close();
            sqlConn.Close();
        }
        catch (System.Exception ex)
        {
            throw ex;
        }
        return cntctID;
    }
    private Boolean checkInchargeRole(int _contactID, int roleID, int jobID)
    {
        try
        {
            SqlConnection sqlConn = new SqlConnection(connValue);
            sqlConn.Open();
            SqlCommand sqlCom = new SqlCommand("Select contactID from JobOwner where JobID = " + jobID + " and ContactID = " + _contactID + " and StaffRoleID = " + roleID + "", sqlConn);

            SqlDataReader sqlReader = sqlCom.ExecuteReader();
            if (sqlReader.HasRows)
            {
                return true;
            }
            sqlReader.Close();
            sqlConn.Close();
        }
        catch (System.Exception ex)
        {
            throw ex;
        }
        return false;
    }

    JobOrderProperty jobInchargePLayer = new JobOrderProperty();
    protected void btnAdd_Click(object sender, EventArgs e)
    {
        InchargeID = Convert.ToInt32(Request.QueryString["InchargeID"]);

        if (ddlQS.SelectedIndex != 0)
        {            
            if (!ValidateControls())
                return;
            if (InchargeID == 0)
            {
                InsertStaffData();

                  string _eMail = getEmail(ddlQS.SelectedValue);

                // string _eMail = "svadakapuram@ashghal.gov.qa";

                // OutLookAlert(_eMail);

                 //OutLookAlert_Quick(_eMail);    
            }
            else
            {
                UpdateInchargeData(InchargeID);

                int _qsID =0; int _peID =0; int _ceID = 0;

                Temp_GetAndUpdateStaffData(ref _qsID, ref _peID, ref _ceID);     // In Job Table           
            }

            string script = "this.window.opener.location=this.window.opener.location;this.window.close();";
            if (!ClientScript.IsClientScriptBlockRegistered("REFRESH_PARENT"))
            {
                ClientScript.RegisterClientScriptBlock(typeof(string), "REFRESH_PARENT", script, true);
            }
        }
    }

    private void Temp_GetAndUpdateStaffData(ref int qsID,ref int peID,ref int ceID)
    {
        string strQuery = "SELECT jobOwnerID, jobID, contactID, StaffRoleID FROM JobOwner WHERE (jobID = " + _jobID + ") Order by jobOwnerID";     //15353

        using (SqlConnection cn = new SqlConnection(connValue))
        {
            using (SqlCommand cmd = new SqlCommand())
            {
                cmd.Connection = cn;
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = strQuery;
                cn.Open();

                using (SqlDataReader dr = cmd.ExecuteReader())
                {
                    if (dr.HasRows)
                    {
                        while (dr.Read())
                        {
                            if (dr["StaffRoleID"].ToString().Equals("1"))   // QS
                            {
                               qsID = Convert.ToInt32(dr["contactID"].ToString());
                            }
                            else if (dr["StaffRoleID"].ToString().Equals("2"))   // PE
                            {
                                peID = Convert.ToInt32(dr["contactID"].ToString());
                            }
                            else if (dr["StaffRoleID"].ToString().Equals("3"))   // CE
                            {
                                ceID = Convert.ToInt32(dr["contactID"].ToString());
                            }  
                        }
                    }
                }
            }
        }

        Temp_UpdateJobQSByDataTable(qsID, peID, ceID);
    }


    private void Temp_UpdateJobQSByDataTable(int QS_staffID, int PE_staffID, int CE_staffID)
    {
        using (SqlConnection con = new SqlConnection(connValue))
        {
            using (SqlCommand sqlCmd = new SqlCommand())
            {
                string strUpdate = string.Empty;
                strUpdate = "Update Job Set QSID = @QSID,PEID = @PEID,CEID = @CEID Where JobID =@JobID";

                if (QS_staffID != 0)
                    sqlCmd.Parameters.AddWithValue("@QSID", QS_staffID);
                else
                    sqlCmd.Parameters.AddWithValue("@QSID", System.DBNull.Value);

                if (PE_staffID != 0)
                    sqlCmd.Parameters.AddWithValue("@PEID", PE_staffID);
                else
                    sqlCmd.Parameters.AddWithValue("@PEID", System.DBNull.Value);

                if (CE_staffID != 0)
                    sqlCmd.Parameters.AddWithValue("@CEID", CE_staffID);
                else
                    sqlCmd.Parameters.AddWithValue("@CEID", System.DBNull.Value);

                sqlCmd.Parameters.AddWithValue("@JobID", _jobID);
               

                try
                {
                    con.Open();
                    sqlCmd.CommandType = CommandType.Text;
                    sqlCmd.Connection = con;
                    sqlCmd.CommandText = strUpdate;
                    sqlCmd.ExecuteNonQuery();
                }
                catch (System.Exception ex)
                {
                    throw ex;
                }
                finally
                {
                    con.Close();
                }
            }
        }
    }
    private DataTable GetAndUpdateStaffData()
    {
        DataTable dtStaffData = null;
        IList<string> staffRollData = new List<string>();

        string strQuery = "SELECT jobOwnerID, jobID, contactID, StaffRoleID FROM JobOwner WHERE (jobID = " + _jobID + ") Order by jobOwnerID";       //15353
        
        using (SqlConnection cn = new SqlConnection(connValue))
        {
            using (SqlCommand cmd = new SqlCommand())
            {
                cmd.Connection = cn;
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = strQuery;
                cn.Open();    
           
                using (SqlDataReader dr = cmd.ExecuteReader())
                {
                    if (dr.HasRows)
                    {
                        while (dr.Read())
                        {
                            if (!dr["StaffRoleID"].ToString().Equals("4"))
                               UpdateJobQS(Convert.ToInt32(dr["StaffRoleID"]), Convert.ToInt32(dr["contactID"]));                                             
                        }
                    }                    
                }
            }
        }

        return dtStaffData;
    }
    private DataTable getStaffData()
    {
        DataTable table = null;

        string strQuery = "SELECT jobOwnerID, jobID, contactID, StaffRoleID FROM JobOwner WHERE (jobID = " + _jobID + ") and (StaffRoleID <> 4) Order by jobOwnerID";     //15353
       
        using (SqlConnection sqlConn = new SqlConnection(connValue))
        {
            sqlConn.Open();
            SqlDataAdapter sqlDtAdptr = null;
            table = new DataTable("staddTbl");
            sqlDtAdptr = new SqlDataAdapter(strQuery, sqlConn);
            sqlDtAdptr.Fill(table);
           
        }
        return table;
    }
    private void UpdateJobQSByDataTable(DataTable dtStaff, int QS_staffID, int PE_staffID, int CE_staffID)
    {
       short jobOwnerCounter = 0;
       while (jobOwnerCounter < dtStaff.Rows.Count)
       {
          
           string staffID = dtStaff.Rows[jobOwnerCounter]["contactID"].ToString();
           int roleID = Convert.ToInt16(dtStaff.Rows[jobOwnerCounter]["StaffRoleID"].ToString());

           using (SqlConnection con = new SqlConnection(connValue))
           {
               using (SqlCommand sqlCmd = new SqlCommand())
               {
                   string strUpdate = string.Empty;
                   strUpdate = "Update Job Set QSID = @QSID,PEID = @PEID,CEID = @CEID Where JobID =@JobID";

                   if (QS_staffID!=0)
                      sqlCmd.Parameters.AddWithValue("@QSID", QS_staffID);
                   else
                       sqlCmd.Parameters.AddWithValue("@QSID", System.DBNull.Value);

                   if (PE_staffID != 0)
                      sqlCmd.Parameters.AddWithValue("@PEID", PE_staffID);
                   else
                       sqlCmd.Parameters.AddWithValue("@PEID", System.DBNull.Value);

                   if (CE_staffID != 0) 
                      sqlCmd.Parameters.AddWithValue("@CEID", CE_staffID);
                   else
                       sqlCmd.Parameters.AddWithValue("@CEID", System.DBNull.Value);

                   sqlCmd.Parameters.AddWithValue("@JobID", _jobID);


                   if (roleID == 1)
                   {
                       strUpdate = "Update Job Set QSID= @QSID where JobID = @JobID";      // Assigned QS 
                       sqlCmd.Parameters.AddWithValue("@QSID", staffID);

                   }
                   else if (roleID == 2)
                   {
                       strUpdate = "Update Job Set PEID= @PEID where JobID = @JobID";      // Assigned Planning Engineer 
                       sqlCmd.Parameters.AddWithValue("@PEID", staffID);

                   }
                   else if (roleID == 3)
                   {
                       strUpdate = "Update Job Set CEID= @CEID where JobID = @JobID";      // Assigned Cost Engineer  
                       sqlCmd.Parameters.AddWithValue("@CEID", staffID);

                   }
                   else if (roleID == 4)
                   {
                       strUpdate = "Update Job Set DCID= @DCID where JobID = @JobID";     // Assigned Document Controller
                       sqlCmd.Parameters.AddWithValue("@DCID", staffID);

                   }

                   try
                   {
                       con.Open();
                      

                       sqlCmd.CommandType = CommandType.Text;
                       sqlCmd.Connection = con;
                       sqlCmd.CommandText = strUpdate;

                       sqlCmd.ExecuteNonQuery();
                   }
                   catch (System.Exception ex)
                   {
                       throw ex;
                   }
                   finally
                   {
                       con.Close();
                   }
               }
           }

           jobOwnerCounter++;
       }
       
    }
    private void UpdateJobQS(int roleID, int staffID)
    {
        IList<int> roleColl = new List<int>();
        using (SqlConnection con = new SqlConnection(connValue))
        {
            using (SqlCommand sqlCmd = new SqlCommand())
            {               
                string strUpdate = string.Empty;
                if (roleID == 1)
                {
                    strUpdate = "Update Job Set QSID= @QSID where JobID = @JobID";      // Assigned QS 
                    sqlCmd.Parameters.AddWithValue("@QSID", staffID);
                    roleColl.Add(1);
                }
                else if (roleID == 2)
                {
                    strUpdate = "Update Job Set PEID= @PEID where JobID = @JobID";      // Assigned Planning Engineer 
                    sqlCmd.Parameters.AddWithValue("@PEID", staffID);
                    roleColl.Add(2);
                }
                else if (roleID == 3)
                {
                    strUpdate = "Update Job Set CEID= @CEID where JobID = @JobID";      // Assigned Cost Engineer  
                    sqlCmd.Parameters.AddWithValue("@CEID", staffID);
                    roleColl.Add(3);
                }
                else if (roleID == 4)
                {
                    strUpdate = "Update Job Set DCID= @DCID where JobID = @JobID";     // Assigned Document Controller
                    sqlCmd.Parameters.AddWithValue("@DCID", staffID);
                    roleColl.Add(4);
                }       

                try
                {
                    con.Open();
                    sqlCmd.Parameters.AddWithValue("@JobID", _jobID);

                    sqlCmd.CommandType = CommandType.Text;                  
                    sqlCmd.Connection = con;
                    sqlCmd.CommandText = strUpdate; 

                    sqlCmd.ExecuteNonQuery();
                }
                catch (System.Exception ex)
                {
                    throw ex;
                }
                finally
                {
                    con.Close();
                }
            }
        }
    }
    private void OutLookAlert(string eMail)
    {
        using (SmtpClient smtpclient = new SmtpClient("10.250.50.201", 587))
        {
            System.Net.Mail.MailMessage mail = new System.Net.Mail.MailMessage();
            MailAddress fromaddress = new MailAddress("EBSD@ashghal.gov.qa");
            mail.From = fromaddress;
            mail.To.Add(eMail);
            mail.Subject = ("eBook Job No. " + Session["jobNo"].ToString());
            mail.IsBodyHtml = true;



            mail.Body = "<html><body><i style='font-family:Calibri; font-size:15'>Dear eBook Team,</i><br/><br/><i style='font-family:Calibri; font-size:15'>This is an automated alert from Document & Task Management System.</i><br/><br/><i style='font-family:Calibri;font-size:15'>" +
                              "Please be noted that</i><i style='color:Maroon;font-family:Calibri; font-size:15'> Job No. " + Session["jobNo"].ToString() + "</i><i style='font-family:Calibri; font-size:15'> a new Job Order was assigned to you and the details are as follows:-</i><br /><br />" +
                              "<table style='width:80%' border='1'><tr><td align='center' colspan='2' style='background-color:Maroon;color:White;font-family:Calibri;font-size:18;font-weight:bold'>JOB NO: " + Session["jobNo"].ToString() + "</td>" +
                              "</tr><tr><td style='background-color:#B58AA5;font-family:Calibri;font-size:15'><i>Contract No / Project Code </i></td><td style='font-family:Calibri;font-size:15'>" + Session["contractNo"].ToString() + "</td></tr>" +
                              "<tr><td style='background-color:#B58AA5;font-family:Calibri;font-size:15'><i>eBook URL</i></td><td style='font-family:Calibri;font-size:15'> http://mv2ebdbookp01/eBook/LoginPage.aspx  </td></tr>" +
                              "<tr><td style='background-color:#B58AA5;font-family:Calibri;font-size:15'><i>Date of Creation</i></td><td style='font-family:Calibri;font-size:15'>" + System.DateTime.Now + "</td></tr>" +
                              "</table><br/><br/><div style='font-family:Calibri; font-size:15'>Best Regards,<br/>eBook Team</div></body></html>";




            // mail.Body = "Please be informed that a new Job Order was assigned to you under the above subject. Please log on to eBook Application to see the details of the Job Order.";  
            smtpclient.EnableSsl = true;
            smtpclient.UseDefaultCredentials = true;



            try
            {
                smtpclient.Credentials = new System.Net.NetworkCredential(@"Ashghal\EBSD", ConfigurationManager.AppSettings["passWordForReport"].ToString()); 
                ServicePointManager.ServerCertificateValidationCallback = delegate(object s, X509Certificate certificate, X509Chain chain, SslPolicyErrors sslPolicyErrors) { return true; };
                smtpclient.Send(mail);
            }
            catch (System.Exception ex)
            {
                Console.WriteLine(ex);
                if (ex.InnerException != null)
                {
                    Console.WriteLine("InnerException is: {0}", ex.InnerException);
                }
            }
            finally
            {
                mail.Dispose();
                mail = null;
               // smtpclient = null;
            }
        }
    }

    private void OutLookAlert_old(string eMail)
    {
        // Session["AlertJobNo"] = "CE160099";

        SmtpClient smtpclient = new SmtpClient("10.250.50.201", 587);   //  172.30.30.44
        System.Net.Mail.MailMessage mail = new System.Net.Mail.MailMessage();
        MailAddress fromaddress = new MailAddress("EBSD@ashghal.gov.qa");          // vpuchnanda@ashghal.gov.qa
        mail.From = fromaddress;
        mail.To.Add(eMail);
        mail.Subject = ("eBook Job No. " + Session["jobNo"].ToString());
        mail.IsBodyHtml = true;
        mail.Body = "Please be informed that a new Job Order was assigned to you under the above subject. Please log on to eBook Application to see the details of the Job Order.";  // Dear Team " + "\r\n" + 
        smtpclient.EnableSsl = true;
        smtpclient.UseDefaultCredentials = true;

        try
        {
            // SmtpClient smtpclient = new SmtpClient(ConfigurationManager.AppSettings["SmtpHostIP"].ToString(), Convert.ToInt32(ConfigurationManager.AppSettings["SmtpHostPort"].ToString()));

            // smtpclient.Credentials = new System.Net.NetworkCredential(ConfigurationManager.AppSettings["userNameForReport"].ToString(), ConfigurationManager.AppSettings["passWordForReport"].ToString());   //,"ASHGHAL"

            // smtpclient.Credentials = new System.Net.NetworkCredential("EBSD@ashghal.gov.qa", "ashghal2014");   //,"ASHGHAL"

            smtpclient.Credentials = new System.Net.NetworkCredential(@"Ashghal\EBSD", ConfigurationManager.AppSettings["passWordForReport"].ToString());   //,"ASHGHAL"

            ServicePointManager.ServerCertificateValidationCallback = delegate(object s, X509Certificate certificate, X509Chain chain, SslPolicyErrors sslPolicyErrors) { return true; };

            smtpclient.Send(mail);

        }
        catch (System.Exception ex)
        {
            Response.Write("Error Occurred");

            Console.WriteLine(ex);   //Should print stacktrace + details of inner exception

            if (ex.InnerException != null)
            {
                Console.WriteLine("InnerException is: {0}", ex.InnerException);
            }
        }
        finally
        {
            //msg.Dispose();
            //msg = null;
            smtpclient = null;
        }

        // ServicePointManager.ServerCertificateValidationCallback = delegate(object s, X509Certificate certificate, X509Chain chain, SslPolicyErrors sslPolicyErrors) { return true; };
    }
    
    private void SendEmail_old(string emailFrom)
    {
       // string emailFrom = Session["emailAdr"].ToString();

        //DateTime startDate = Convert.ToDateTime(txtDueDate.Text);
       // DateTime endDate = Convert.ToDateTime(startDate).AddDays(5);
       // string RemindDate = Convert.ToDateTime(txtDueDate.Text).ToString("dd/MM/yyyy HH:mm:ss");

       // String[] token = RemindDate.Split(' ');
      //  String[] datetime = token[1].Split(':');
       // String timeText = datetime[0];
       // timeText = "8";     

       // string fnlDateTime = txtDueDate.Text + " " + timeText;
        //DateTime time = Convert.ToDateTime(fnlDateTime); 

        string strTime = "8"; 
        Outlook._Application OutlookApp = new Outlook.Application();

        Outlook.RecurrencePattern pattern = null;
        Outlook.TaskItem task = null;

        try
        {
            task = OutlookApp.CreateItem(Outlook.OlItemType.olTaskItem) as Outlook.TaskItem;
            pattern = task.GetRecurrencePattern();
            pattern.RecurrenceType = Outlook.OlRecurrenceType.olRecursDaily;

           // pattern.PatternStartDate = DateTime.Parse(RemindDate.ToString());
           // pattern.PatternEndDate = DateTime.Parse(RemindDate.ToString());

           // task.ReminderSet = true;

           // task.ReminderTime = time;

            // task.ReminderTime = DateTime.Parse("7:58:00 AM");

            task.Subject = "Reminder for Job No. ";
            task.Body = "This is a reminder from EBSD eBook regarding Job No. is due on ";
            task.Save();
            task.Display(false);
        }
        catch (System.Exception ex)
        {
            //System.Windows.Forms.MessageBox.Show(ex.Message);
        }
        finally
        {
            if (pattern != null) Marshal.ReleaseComObject(pattern);
            if (task != null) Marshal.ReleaseComObject(task);
        }

        ClientScript.RegisterClientScriptBlock(this.GetType(), "Popup", "<script>alert('Task has been set to Outlook')</script>", false);
    }
    //private void SendMail(string _eMail)
    //{
    //    Application OutlookApplication = new Application();
    //    MailItem email = (MailItem)OutlookApplication.CreateItem(OlItemType.olMailItem);
    //    email.Recipients.Add(_eMail);
    //    email.Subject = "Test";
    //    email.Body = "This is a test email to check outlook email sending code";
    //    string DisplayName = "MyAttachment";
    //    int iPosition = email.Body.Length + 1;
    //    int AttachType = (int)OlAttachmentType.olByValue;
    //    Attachment Attach = email.Attachments.Add("D:\\test.txt", AttachType, iPosition, DisplayName);
    //    email.Send();
    //}

    //private void SendSalesReport()
    //{
    //    Microsoft.Office.Interop.Outlook.MailItem mail = Application.CreateItem(Microsoft.Office.Interop.Outlook.OlItemType.olMailItem) as Microsoft.Office.Interop.Outlook.MailItem;
    //    mail.Subject = "Quarterly Sales Report FY06 Q4";
    //    Microsoft.Office.Interop.Outlook.AddressEntry currentUser =   Application.Session.CurrentUser.AddressEntry;
    //    if (currentUser.Type == "EX")
    //    {
    //        Microsoft.Office.Interop.Outlook.ExchangeUser manager =  currentUser.GetExchangeUser().GetExchangeUserManager();       
    //        mail.Recipients.Add(manager.PrimarySmtpAddress);
    //        mail.Recipients.ResolveAll();
    //        mail.Attachments.Add(@"c:\sales reports\fy06q4.xlsx",  Microsoft.Office.Interop.Outlook.OlAttachmentType.olByValue, Type.Missing,  Type.Missing);
    //        mail.Send();
    //    }
    //}

    private string getEmail(string contactID)
    {
        string streMail = string.Empty;
        try
        {
            SqlConnection sqlConn = new SqlConnection(connValue);
            sqlConn.Open();
            SqlCommand sqlCom = new SqlCommand("Select emailAddress from Contact where ContactID = " + Convert.ToInt32(contactID) + "", sqlConn);
            SqlDataReader sqlReader = sqlCom.ExecuteReader();
            while (sqlReader.Read())
            {
                streMail = sqlReader["emailAddress"].ToString();
            }
            sqlReader.Close();
            sqlConn.Close();
        }
        catch (System.Exception ex)
        {
            throw ex;
        }

        return streMail;
    }
   
    private void InsertStaffData()
    {
        IList<int> docIDColl = new List<int>();
        int _jobDocID = getDocIDFromJob(_jobID);

        int _ownerID = 0;
        CollectInchargeData();

        _ownerID = new JobOrderData().AddInchargeData(jobInchargePLayer, Session["Username"].ToString(), Convert.ToInt32(Session["UserID"]), Convert.ToInt32(Session["SectionID"]));


        docIDColl = getDocIDCollection(_jobID);

        foreach (var docID in docIDColl)
        {
            InsertDocDistributionData(_ownerID, _jobID, docID);
            CheckandDeleteDistributionData(docID);
        }

        if (ddlStaffType.SelectedIndex == 0) //qs
            UpdateJobQSID(Convert.ToInt32(ddlQS.SelectedValue));
        else if (ddlStaffType.SelectedIndex == 1) //pe
            UpdateJobPEID(Convert.ToInt32(ddlQS.SelectedValue));
        else if (ddlStaffType.SelectedIndex == 2)  //ce
            UpdateJobCEID(Convert.ToInt32(ddlQS.SelectedValue));
    }
    private void CheckandDeleteDistributionData(int DocID)
    {
        //string sqlQuery = "SELECT  distributeID, docCatID, documentID, contactID FROM  DocumentDistribution WHERE (documentID = " + DocID + ")";
               
        string sqlQuery = "SELECT documentID, docCatID, distributeID, contactID FROM  DocumentDistribution WHERE   (documentID IN (SELECT documentID FROM  DocumentDistribution AS Tmp  GROUP BY documentID, contactID HAVING   (COUNT(*) > 1) AND (contactID = DocumentDistribution.contactID) AND (documentID = " + DocID + ")))  ORDER BY documentID, docCatID, distributeID";
        DataTable dtDocumentDistribution = GetDataFromDB("DocumentDistribution", sqlQuery);

        if (dtDocumentDistribution.Rows.Count != 0)
            DeleteDistributionData(Convert.ToInt32(dtDocumentDistribution.Rows[0]["distributeID"]));

        if (getData(DocID).Rows.Count > 0)
            DeleteDistributionData(Convert.ToInt32(getData(DocID).Rows[0]["distributeID"]));  

    }
    private DataTable getData(int DocID)
    {
        string sqlQuery = "SELECT documentID, docCatID, distributeID, contactID FROM  DocumentDistribution WHERE " + 
            " (documentID IN (SELECT documentID FROM  DocumentDistribution AS Tmp  GROUP BY documentID, contactID HAVING (COUNT(*) > 1) AND (contactID = DocumentDistribution.contactID) AND (documentID = " + DocID + ")))  ORDER BY documentID, docCatID, distributeID";


        return GetDataFromDB("DocumentDistribution", sqlQuery);    
    }

    private void DeleteDistributionData(int documentID)
    {
        string updateSql = "Delete From DocumentDistribution Where distributeID = " + documentID + " ";
        SqlConnection sqlConn = new SqlConnection(connValue);
        SqlCommand cmd = new SqlCommand();
        cmd.CommandText = updateSql;
        cmd.Connection = sqlConn;

        try
        {
            //cmd.Parameters.AddWithValue("@contactID", documentID);   
            sqlConn.Open();
            cmd.ExecuteNonQuery();
            sqlConn.Close();
        }
        catch (System.Exception ex)
        {

        }
    }
    public DataTable GetDataFromDB(string dataTabName, string sqlQuery)
    {
        SqlConnection con = new SqlConnection(connValue);
        SqlCommand cmd = new SqlCommand();
        DataTable table = null;
        SqlDataAdapter sqlDtAdptr = null;
        table = new DataTable(dataTabName);
        sqlDtAdptr = new SqlDataAdapter(@sqlQuery, con);
        sqlDtAdptr.Fill(table);
        return table;
    }

   
    
    private void InsertDocDistributionData(int inchargeID, int _jobID, int docID)
    {
        SqlConnection con = new SqlConnection(connValue);
        SqlCommand sqlCmd = new SqlCommand();
        sqlCmd.CommandType = CommandType.StoredProcedure;
        sqlCmd.Connection = con;
        sqlCmd.CommandText = "InsertDocDistributionFromJob";

        sqlCmd.Parameters.AddWithValue("@contactID", ddlQS.SelectedValue);
        sqlCmd.Parameters.AddWithValue("@docPurposeID", 1); // 2- For Info   // 1- For Action
        sqlCmd.Parameters.AddWithValue("@docStatusID", 1);  // 4 - Closed  // 1- Open
        sqlCmd.Parameters.AddWithValue("@daysToReply", txtWorkDays.Text);        
        sqlCmd.Parameters.AddWithValue("@actionDueDate", txtDueDate.Text);

        sqlCmd.Parameters.AddWithValue("@issuedByContactID", Session["UserID"].ToString());
       
       
        sqlCmd.Parameters.AddWithValue("@createUser", Session["UserName"].ToString());      

        sqlCmd.Parameters.AddWithValue("@documentID", docID);
        sqlCmd.Parameters.AddWithValue("@inchargeID", inchargeID);

        sqlCmd.Parameters.AddWithValue("@docCatID", 1);

        sqlCmd.Parameters.AddWithValue("@dateread", System.DBNull.Value); 
    
        try
        {
            con.Open();
            sqlCmd.ExecuteNonQuery();                
        }
        catch (System.Exception ex)
        {
            throw ex;
        }
        finally
        {
            con.Close();
        }      
    }
    private void UpdateJobQSID(int jobqsID)
    {
        SqlConnection con = new SqlConnection(connValue);
        SqlCommand cmd = new SqlCommand();
        cmd.CommandType = CommandType.Text;
        cmd.Connection = con;
        cmd.CommandText = "Update Job Set QSID = @qsID Where jobID = @jobID";
        cmd.Parameters.AddWithValue("@jobID", _jobID);
        cmd.Parameters.AddWithValue("@qsID", jobqsID);
        try
        {
            con.Open();
            cmd.ExecuteNonQuery();
            con.Dispose();
        }
        catch (System.Exception ex)
        {
            throw ex;
        }
        finally
        {
            con.Close();
        }
    }
    private void UpdateJobCEID(int jobceID)
    {
        SqlConnection con = new SqlConnection(connValue);
        SqlCommand cmd = new SqlCommand();
        cmd.CommandType = CommandType.Text;
        cmd.Connection = con;
        cmd.CommandText = "Update Job Set CEID = @ceID Where jobID = @jobID";
        cmd.Parameters.AddWithValue("@jobID", _jobID);
        cmd.Parameters.AddWithValue("@ceID", jobceID);
        try
        {
            con.Open();
            cmd.ExecuteNonQuery();
            con.Dispose();
        }
        catch (System.Exception ex)
        {
            throw ex;
        }
        finally
        {
            con.Close();
        }
    }
    private void UpdateJobPEID(int jobpeID)
    {
        SqlConnection con = new SqlConnection(connValue);
        SqlCommand cmd = new SqlCommand();
        cmd.CommandType = CommandType.Text;
        cmd.Connection = con;
        cmd.CommandText = "Update Job Set peID = @peID Where jobID = @jobID";
        cmd.Parameters.AddWithValue("@jobID", _jobID);
        cmd.Parameters.AddWithValue("@peID", jobpeID);
        try
        {
            con.Open();
            cmd.ExecuteNonQuery();
            con.Dispose();
        }
        catch (System.Exception ex)
        {
            throw ex;
        }
        finally
        {
            con.Close();
        }
    }
  
    private int getDocIDFromJob(int jobID)
    {       
        int jobDocID = 0;
        try
        {
            SqlConnection sqlConn = new SqlConnection(connValue);
            sqlConn.Open();
            SqlCommand sqlCom = new SqlCommand("Select DocRefID from Job where jobID = " + jobID + "", sqlConn);       
            SqlDataReader sqlReader = sqlCom.ExecuteReader();
            while (sqlReader.Read())
            {
                jobDocID = Convert.ToInt32(sqlReader["DocRefID"]);
            }
            sqlReader.Close();
            sqlConn.Close();
        }
        catch (System.Exception ex)
        {
            throw ex;
        }
        return jobDocID;
    }
    private IList<int> getDocIDCollection(int _jobID)
    {
        IList<int> docIDColl = new List<int>();      
        try
        {
            SqlConnection sqlConn = new SqlConnection(connValue);
            sqlConn.Open();
            SqlCommand sqlCom = new SqlCommand("Select DocumentID from Document where jobID = " + _jobID + "", sqlConn);      
            SqlDataReader sqlReader = sqlCom.ExecuteReader();
            while (sqlReader.Read())
            {
                docIDColl.Add(Convert.ToInt32(sqlReader["DocumentID"]));
            }            
            sqlReader.Close();
            sqlConn.Close();
        }
        catch (System.Exception ex)
        {
            throw ex;
        }

        return docIDColl;
    }  

    /// <summary>
    /// 
    ///
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    
    
    protected void btnSendTask_Click(object sender, EventArgs e)
    {
        DateTime startDate = Convert.ToDateTime(txtDueDate.Text);
        DateTime endDate = Convert.ToDateTime(startDate).AddDays(5);
      
        Microsoft.Office.Interop.Outlook._Application OutlookApp = new Microsoft.Office.Interop.Outlook.Application();

        Microsoft.Office.Interop.Outlook.RecurrencePattern pattern = null;
        Microsoft.Office.Interop.Outlook.TaskItem task = null;
        try
        {
            task = OutlookApp.CreateItem(Microsoft.Office.Interop.Outlook.OlItemType.olTaskItem) as Microsoft.Office.Interop.Outlook.TaskItem;
            pattern = task.GetRecurrencePattern();
            pattern.RecurrenceType = Microsoft.Office.Interop.Outlook.OlRecurrenceType.olRecursDaily;
            pattern.PatternStartDate = DateTime.Parse(startDate.ToString());
            pattern.PatternEndDate = DateTime.Parse(startDate.ToString());
            task.ReminderSet = true;
            task.ReminderTime = DateTime.Parse("8:30:00 AM");
            task.Subject = "Reminder for Job No. " + Session["jobNo"].ToString() + "";
            task.Body = "This is a reminder from EBSD eBook regarding Job No. " + Session["jobNo"].ToString() + " is due on " + Session["ActionDate"] + "";
            task.Save();
            task.Display(false);
        }
        catch (System.Exception ex)
        {
            //System.Windows.Forms.MessageBox.Show(ex.Message);
        }
        finally
        {
            if (pattern != null) Marshal.ReleaseComObject(pattern);
            if (task != null) Marshal.ReleaseComObject(task);
        }
    }
    protected void txtWorkDays_TextChanged(object sender, EventArgs e)
    { 
        if (txtWorkDays.Text != "0")
        {
            string endDate = getEndDateByGivenDays(Convert.ToInt32(txtWorkDays.Text), lblDateOfIssue.Text);
            txtDueDate.Text = Convert.ToDateTime(endDate).ToString("dd/MMM/yyyy");
        }
        else
        {
            txtWorkDays.Text = "1";
            ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Minimum Work days to act is one.')</script>", false);
        }      
    }
    protected void Calendar1_SelectionChanged(object sender, EventArgs e)
    {
        DateTime start = new DateTime(1990, 1, 1);
        if(txtDueDate.Text!= "")
        start = Convert.ToDateTime(txtDueDate.Text);
        DateTime end = new DateTime(1990, 1, 31);
        end = System.DateTime.Now;

        int dateCnt = Convert.ToInt32((start - end).Days);
        if (dateCnt <= 0)
        {
           // txtDueDate.Text = Convert.ToDateTime(Calendar1.SelectedDate).ToString("dd/MMM/yyyy");
            return;
        }

        // Console.WriteLine((end - start).Days);

        //if (Convert.ToDateTime(Calendar1.SelectedDate).ToString("dd/MMM/yyyy") >= System.DateTime.Now.ToString("dd/MMM/yyyy"))
        //{
        //}

        txtWorkDays.Text = getDaysByGivenEndDate(System.DateTime.Now.ToString(),txtDueDate.Text);
        txtDueDate.Text = Convert.ToDateTime(txtDueDate.Text).ToString("dd/MMM/yyyy");
       // Calendar1.Visible = false;
    }
    private string getEndDateByGivenDays(int Days,string inputDate)
    {
        SqlConnection con = new SqlConnection(connValue);      
        SqlCommand cmd = new SqlCommand();
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Connection = con;
        if (txtWorkDays.Text != "")
        {
            cmd.CommandText = "AddWorkdays";
            SqlParameter prm = cmd.Parameters.Add("@ad_startDate", SqlDbType.DateTime);
            prm.Value = inputDate;
            prm = cmd.Parameters.Add("@actual_workDays", SqlDbType.Int);
            prm.Value = Days;
            prm = cmd.Parameters.Add("@endDate", SqlDbType.DateTime);
            prm.Direction = ParameterDirection.Output;
            con.Open();
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
                Console.WriteLine(dr.GetString(0));
            con.Dispose();
            con.Close();            
        }
        return cmd.Parameters[2].Value.ToString();
    }
    private string getDaysByGivenEndDate(string endDate)
    {
        SqlConnection con = new SqlConnection(connValue);
        SqlCommand cmd = new SqlCommand();
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Connection = con;
        cmd.CommandText = "testSP";
        SqlParameter prm = cmd.Parameters.Add("@ad_startDate", SqlDbType.DateTime);
        prm.Value = System.DateTime.Now;
        prm = cmd.Parameters.Add("@ad_endDate", SqlDbType.DateTime);
        prm.Value = Convert.ToDateTime(endDate);

        prm = cmd.Parameters.Add("@ai_workDays", SqlDbType.Int);
        prm.Direction = ParameterDirection.Output;
        con.Open();
        SqlDataReader dr = cmd.ExecuteReader();
        while (dr.Read())
            Console.WriteLine(dr.GetString(0));
        con.Dispose();
        con.Close();

        return cmd.Parameters[2].Value.ToString();
    }

    //protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
    //{
    //    if (Calendar1.Visible)
    //        Calendar1.Visible = false;
    //    else
    //        Calendar1.Visible = true;  
    //}
    private string getDaysByGivenEndDate(string strDate, string endDate)
    {
        strDate = Convert.ToDateTime(strDate).ToString("MM/dd/yyyy", CultureInfo.InvariantCulture);
        endDate = Convert.ToDateTime(endDate).ToString("MM/dd/yyyy", CultureInfo.InvariantCulture);

        DateTime strDt = DateTime.ParseExact(strDate, "MM/dd/yyyy", CultureInfo.InvariantCulture);
        DateTime endDt = DateTime.ParseExact(endDate, "MM/dd/yyyy", CultureInfo.InvariantCulture);

        SqlConnection con = new SqlConnection(connValue);
        SqlCommand cmd = new SqlCommand();

        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Connection = con;

        cmd.CommandText = "testSP";

        SqlParameter prm = cmd.Parameters.Add("@ad_startDate", SqlDbType.DateTime);
        prm.Value = strDt;

        prm = cmd.Parameters.Add("@ad_endDate", SqlDbType.DateTime);
        prm.Value = endDt;

        prm = cmd.Parameters.Add("@ai_workDays", SqlDbType.Int);
        prm.Direction = ParameterDirection.Output;

        //prm = cmd.Parameters.Add("@as_errMsg", SqlDbType.VarChar);
        //prm.Direction = ParameterDirection.Output;

        con.Open();
        SqlDataReader dr = cmd.ExecuteReader();
        while (dr.Read())
            Console.WriteLine(dr.GetString(0));
        con.Dispose();
        con.Close();

        return cmd.Parameters[2].Value.ToString();
    }
   
    
    protected void txtDueDate_TextChanged(object sender, EventArgs e)
    {
        DateTime dateCur = System.DateTime.Now;
        DateTime dtTest = ConvertToDateTime(txtDueDate.Text);

        int resultCurnt = DateTime.Compare(dateCur, dtTest);
        if (resultCurnt == 1)
        {
            txtWorkDays.Text = "1";
            string endDate = getEndDateByGivenDays(Convert.ToInt32(txtWorkDays.Text),lblDateOfIssue.Text);
           
            txtDueDate.Text = Convert.ToDateTime(endDate).ToString("dd/MMM/yyyy");

            ClientScript.RegisterClientScriptBlock(this.GetType(), "Popup", "<script>alert('Action Due Date must be later than today')</script>", false);
        }
        else
        {
            //string endDate = getEndDateByGivenDays(Convert.ToInt32(txtWorkDays.Text));
           // txtDueDate.Text = Convert.ToDateTime(endDate).ToString("dd/MMM/yyyy");

            txtWorkDays.Text = getDaysByGivenEndDate(lblDateOfIssue.Text,txtDueDate.Text);
        }
    }


    //private string getDaysByGivenEndDate(string strDate, string endDate)
    //{
    //    SqlConnection con = new SqlConnection(connValue);
    //    SqlCommand cmd = new SqlCommand();
    //    cmd.CommandType = CommandType.StoredProcedure;
    //    cmd.Connection = con;
    //    cmd.CommandText = "testSP";
    //    SqlParameter prm = cmd.Parameters.Add("@ad_startDate", SqlDbType.DateTime);
    //    prm.Value = System.DateTime.Now;
    //    prm = cmd.Parameters.Add("@ad_endDate", SqlDbType.DateTime);
    //    prm.Value = Convert.ToDateTime(endDate);

    //    prm = cmd.Parameters.Add("@ai_workDays", SqlDbType.Int);
    //    prm.Direction = ParameterDirection.Output;
    //    con.Open();
    //    SqlDataReader dr = cmd.ExecuteReader();
    //    while (dr.Read())
    //        Console.WriteLine(dr.GetString(0));
    //    con.Dispose();
    //    con.Close();

    //    return cmd.Parameters[2].Value.ToString();
    //}


    private DateTime ConvertToDateTime(string strDateTime)
    {
        DateTime dtFinaldate; string sDateTime;
        try
        {
            //dtFinaldate = Convert.ToDateTime(strDateTime); 

            string[] sDate = strDateTime.Split('/');
            sDateTime = sDate[1] + '/' + sDate[0] + '/' + sDate[2];
            dtFinaldate = Convert.ToDateTime(sDateTime);
        }
        catch (System.Exception e)
        {
            string[] sDate = strDateTime.Split('/');
            sDateTime = sDate[0] + '/' + sDate[1] + '/' + sDate[2];
            dtFinaldate = Convert.ToDateTime(sDateTime);
        }
        return dtFinaldate;
    }
    protected void btnDelete_Click(object sender, EventArgs e)
    {
        string c;
        c = "qwe";
    }
    protected void ddlQS_SelectedIndexChanged(object sender, EventArgs e)
    {
        string _AlertMsg = string.Empty;
        if (chkUserLeaveStatus(ref _AlertMsg))
        {
            ddlQS.SelectedIndex = 0;
            ClientScript.RegisterClientScriptBlock(this.GetType(), "Popup", "<script>alert('" + _AlertMsg + "')</script>", false);
            return;
        }

        int staffID = Convert.ToInt32(ddlQS.SelectedItem.Value);
        
        // Newly added Feb 23rd 2016
        int empCatID = getEmpCatID(Convert.ToInt16(ddlQS.SelectedItem.Value));

        ddlStaffType.SelectedValue = empCatID.ToString();

        int roleID = Convert.ToInt32(ddlStaffType.SelectedItem.Value);        

        if (checkInchargeRole(staffID, roleID, _jobID))
        {
            ddlQS.SelectedIndex = 0;
            ClientScript.RegisterClientScriptBlock(this.GetType(), "Popup", "<script>alert('Selected employee was already assigned to the task')</script>", false);
            return;
        }

        if (ddlStaffType.SelectedValue == "1")
            ddlTask.SelectedValue = "4";
        else if (ddlStaffType.SelectedValue == "2")
            ddlTask.SelectedValue = "6";
        else if (ddlStaffType.SelectedValue == "3")
            ddlTask.SelectedValue = "12";
        else if (ddlStaffType.SelectedValue == "4")
        {
            ddlTask.SelectedValue = "1";
            txtWorkDays.Text = "1";
            string endDate = getEndDateByGivenDays(Convert.ToInt32(txtWorkDays.Text), lblDateOfIssue.Text);
            txtDueDate.Text = Convert.ToDateTime(endDate).ToString("dd/MMM/yyyy");
        }


    }
    private int getEmpCatID(int contactID)
    {
        int empCatID = 0;
        try
        {
            SqlConnection sqlConn = new SqlConnection(connValue);
            sqlConn.Open();
            SqlCommand sqlCom = new SqlCommand("SELECT empCatID from Contact where contactID = " + contactID, sqlConn);
            SqlDataReader sqlReader = sqlCom.ExecuteReader();
            while (sqlReader.Read())
            {
                if (sqlReader["empCatID"].ToString() != "")
                    empCatID = Convert.ToInt16(sqlReader["empCatID"].ToString());
                else
                    empCatID = 1;
            }
            sqlReader.Close();
            sqlConn.Close();
        }
        catch (System.Exception ex)
        {
            throw ex;
        }
        return empCatID; 
    }
    private Boolean chkUserLeaveStatus(ref string AlertMsg)
    {
        try
        {
            SqlConnection sqlConn = new SqlConnection(connValue);
            sqlConn.Open();
            SqlCommand sqlCom = new SqlCommand("SELECT contactID, startDate,endDate,userMsg FROM  Contact WHERE  (contactID = " + ddlQS.SelectedValue + ") AND (startDate <= GETDATE()) AND (endDate >= GETDATE())", sqlConn);
            SqlDataReader sqlReader = sqlCom.ExecuteReader();
            while (sqlReader.Read())
            {
                AlertMsg = sqlReader["userMsg"].ToString();
                return true; 
            }
            sqlReader.Close();
            sqlConn.Close();
        }
        catch (System.Exception ex)
        {
            throw ex;
        }
        return false; 
    }
    protected void btnAddIncharge_Click(object sender, EventArgs e)
    {
        CollectInchargeData();
        new JobOrderData().AddInchargeData(jobInchargePLayer, Session["Username"].ToString(), Convert.ToInt32(Session["UserID"]), Convert.ToInt32(Session["SectionID"]));
                
       // new JobOrderData().DeleteDuplicateDataFromDistribution(_jobID);

        IList<int> docIDColl = getDocIDCollection(_jobID);
        foreach (var docID in docIDColl)
        {
            CheckandDeleteDistributionData(docID);          
        }
    }
    protected void ddlTask_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlTask.SelectedValue == "1")    // Distribution
        {
            txtWorkDays.Text = "1";
           // string endDate = getEndDateByGivenDays(Convert.ToInt32(txtWorkDays.Text), lblDateOfIssue.Text);

            string endDate = getEndDateByGivenDays(Convert.ToInt32(txtWorkDays.Text), System.DateTime.Now.ToString());            
            txtDueDate.Text = Convert.ToDateTime(endDate).ToString("dd/MMM/yyyy");
        }
        else
        {
            txtWorkDays.Text = "4";
           // string endDate = getEndDateByGivenDays(Convert.ToInt32(txtWorkDays.Text), lblDateOfIssue.Text);

            string endDate = getEndDateByGivenDays(Convert.ToInt32(txtWorkDays.Text), System.DateTime.Now.ToString());
            txtDueDate.Text = Convert.ToDateTime(endDate).ToString("dd/MMM/yyyy");
        }
    }
    protected void ddlStaffType_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlStaffType.SelectedValue =="1")
        ddlTask.SelectedValue = "4";
        else if (ddlStaffType.SelectedValue == "2")
            ddlTask.SelectedValue = "6";
        else if (ddlStaffType.SelectedValue == "3")
            ddlTask.SelectedValue = "12";
        else if (ddlStaffType.SelectedValue == "4")
        {
            ddlTask.SelectedValue = "1";
            txtWorkDays.Text = "1";
            string endDate = getEndDateByGivenDays(Convert.ToInt32(txtWorkDays.Text), lblDateOfIssue.Text);
            txtDueDate.Text = Convert.ToDateTime(endDate).ToString("dd/MMM/yyyy");
        }
    }
    protected void ddlTeamLead_SelectedIndexChanged(object sender, EventArgs e)
    {
        string getStaff = "SELECT contactID, userShortName FROM Contact WHERE (userShortName IS NOT NULL) AND (contactID <> " + Session["UserID"] + ") AND (isActive = 1) AND (sectionID = " + Convert.ToInt32(Session["SectionID"]) + " OR sectionID = 6 OR sectionID = 7) AND (companyID = 362) AND teamleaderID =" + ddlTeamLead.SelectedValue + " ORDER BY userShortName";

        ddlQS.Items.Clear();
        PopulateDropDownBox(ddlQS, getStaff, "contactID", "userShortName");
    }
    protected void btnUpdate_Click(object sender, EventArgs e)
    {
        //InchargeID = Convert.ToInt32(Request.QueryString["InchargeID"]);
        //UpdateInchargeData(InchargeID);
    }
    protected void btnDelete_Click1(object sender, EventArgs e)
    {
        if (userRightsColl.Contains("4"))
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('You have no access rights to Delete staff incharge.')</script>", false);
            return;
        }
      
        new JobOrderData().DeleteIncharge(InchargeID);

         int _qsID =0; int _peID =0; int _ceID = 0;
         Temp_GetAndUpdateStaffData(ref _qsID, ref _peID, ref _ceID);
       
        string script = "this.window.opener.location=this.window.opener.location;this.window.close();";
        if (!ClientScript.IsClientScriptBlockRegistered("REFRESH_PARENT"))
        {
            ClientScript.RegisterClientScriptBlock(typeof(string), "REFRESH_PARENT", script, true);
        }       
    }
    private IList<string> getStaffID(int _jobID, int staffRoleID, int inchargeID)
    {
        IList<string> staffDataColl = new List<string>();
        SqlConnection sqlConn = new SqlConnection(connValue);
        string sqlQuery = "SELECT StaffRoleID,contactID from JobOwner where jobID = " + _jobID + " and StaffRoleID = " + staffRoleID + " and jobOwnerID <> " + inchargeID + " ORDER BY jobOwnerID Desc ";

        // "SELECT  StaffRoleID, jobID FROM   JobOwner  WHERE  (StaffRoleID = 1) ORDER BY jobOwnerID"

        try
        {
            sqlConn.Open();
            SqlCommand sqlCom = new SqlCommand(sqlQuery, sqlConn);
            SqlDataReader sqlReader = sqlCom.ExecuteReader();
            while (sqlReader.Read())
            {
                staffDataColl.Add(sqlReader[0].ToString());
                staffDataColl.Add(sqlReader[1].ToString());
            }
            sqlReader.Close();
        }
        catch (System.Exception ex)
        {
            // Response.Write("Error getting while reading data !" + ex.Message);
        }
        finally
        {
            sqlConn.Close();
        }

        return staffDataColl;
    }
    private int gertRoleID(int inchargeID)
    {
        int roleID = 0;
        using (SqlConnection cn = new SqlConnection(connValue))
        {
            using (SqlCommand cmd = new SqlCommand())
            {
                cmd.Connection = cn;
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "Select StaffRoleID from JobOwner where jobOwnerID =" + inchargeID;

                cn.Open();
                //int roleID = (int)cmd.ExecuteScalar();
                using (SqlDataReader dr = cmd.ExecuteReader())
                {
                    if (dr.HasRows)
                    {
                        while (dr.Read())
                        {
                            roleID = Convert.ToInt32(dr["StaffRoleID"]);
                        }
                    }
                    else
                    {
                        roleID = 0;
                    }
                }
            }
        }
        return roleID;
    }
 
      // ServicePointManager.ServerCertificateValidationCallback = MyCertHandler;

    static bool MyCertHandler(object sender, X509Certificate certificate, X509Chain chain, SslPolicyErrors error)
    {
        // Ignore errors
        return true;
    }



    #region MyRegion

    private void SendCompletedCallback(SmtpClient smtpclient, System.Net.Mail.MailMessage mail) //private static void SendCompletedCallback(object sender, AsyncCompletedEventArgs e
    {
        try
        {
            smtpclient.Send(mail);
        }
        catch (System.Exception ex)
        {
            Console.WriteLine(ex);
            if (ex.InnerException != null)
            {
                Console.WriteLine("InnerException is: {0}", ex.InnerException);
            }
        }
        //finally
        //{
        //    mail.Dispose();
        //    mail = null;
        //    // smtpclient = null;
        //}
    }


    private void OutLookAlert_Quick(string eMail)
    {
        SmtpClient smtpclient = new SmtpClient("10.250.50.201", 587);
        System.Net.Mail.MailMessage mail = new System.Net.Mail.MailMessage();
        MailAddress fromaddress = new MailAddress("EBSD@ashghal.gov.qa");
        mail.From = fromaddress;
        mail.To.Add(eMail);
        mail.Subject = ("eBook Job No. " + Session["jobNo"].ToString());
        mail.IsBodyHtml = true;



        mail.Body = "<html><body><i style='font-family:Calibri; font-size:15'>Dear eBook Team,</i><br/><br/><i style='font-family:Calibri; font-size:15'>This is an automated alert from Document & Task Management System.</i><br/><br/><i style='font-family:Calibri;font-size:15'>" +
                            "Please be noted that</i><i style='color:Maroon;font-family:Calibri; font-size:15'> Job No. " + Session["jobNo"].ToString() + "</i><i style='font-family:Calibri; font-size:15'> a new Job Order was assigned to you and the details are as follows:-</i><br /><br />" +
                            "<table style='width:80%' border='1'><tr><td align='center' colspan='2' style='background-color:Maroon;color:White;font-family:Calibri;font-size:18;font-weight:bold'>JOB NO: " + Session["jobNo"].ToString() + "</td>" +
                            "</tr><tr><td style='background-color:#B58AA5;font-family:Calibri;font-size:15'><i>Contract No / Project Code </i></td><td style='font-family:Calibri;font-size:15'>" + Session["contractNo"].ToString() + "</td></tr>" +
                            "<tr><td style='background-color:#B58AA5;font-family:Calibri;font-size:15'><i>eBook URL</i></td><td style='font-family:Calibri;font-size:15'> http://mv2ebdbookp01/eBook/LoginPage.aspx  </td></tr>" +
                            "<tr><td style='background-color:#B58AA5;font-family:Calibri;font-size:15'><i>Date of Creation</i></td><td style='font-family:Calibri;font-size:15'>" + System.DateTime.Now + "</td></tr>" +
                            "</table><br/><br/><div style='font-family:Calibri; font-size:15'>Best Regards,<br/>eBook Team</div></body></html>";
                

        // mail.Body = "Please be informed that a new Job Order was assigned to you under the above subject. Please log on to eBook Application to see the details of the Job Order.";  
        smtpclient.EnableSsl = true;
        smtpclient.UseDefaultCredentials = true;

        try
        {
            smtpclient.Credentials = new System.Net.NetworkCredential(@"Ashghal\EBSD", ConfigurationManager.AppSettings["passWordForReport"].ToString()); 
            ServicePointManager.ServerCertificateValidationCallback = delegate(object s, X509Certificate certificate, X509Chain chain, SslPolicyErrors sslPolicyErrors) { return true; };

            SendEmail myAction = new SendEmail(SendCompletedCallback);
            myAction.BeginInvoke(smtpclient, mail, null, null);

           // smtpclient.Send(mail);
        }
        catch (System.Exception ex)
        {
            Console.WriteLine(ex);
            if (ex.InnerException != null)
            {
                Console.WriteLine("InnerException is: {0}", ex.InnerException);
            }
        }  
    }
    

    private delegate void SendEmail(SmtpClient smtpclient, System.Net.Mail.MailMessage mail);



    #endregion
   


}