﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Text;

public partial class JobOrder_ViewLinkJobData : System.Web.UI.Page
{
    string connValue = System.Configuration.ConfigurationManager.ConnectionStrings["EBSDEBookConn"].ConnectionString;
    SqlDataAdapter da;
    DataSet ds = new DataSet();
    StringBuilder htmlTable = new StringBuilder();  
  
  //  string _jobNo = string.Empty;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            if (Session["CntrNo"] != null)
            {
                BindDataMasterContractNo(Session["CntrNo"].ToString());
            }
            else if (Session["LinkjobNo"]!=null)
            {              
               BindData(Session["LinkjobNo"].ToString());
            }
            else if (Session["ReworkjobNo"] != null) 
            {
                BindDataMaster(Session["ReworkjobNo"].ToString());
            }
        }
    }

    private void BindData(string _jobNo)
    {
        SqlConnection con = new SqlConnection();
        con.ConnectionString = connValue;

        string sqlQuery = "SELECT   Job.jobNo, Job.jobDesc, Job.projectTitle, Job.remarks, Job.contractNo, REPLACE(CONVERT(NVARCHAR, Job.jobReceivedDate, 106), ' ', '-')  AS jobReceivedDate,REPLACE(CONVERT(NVARCHAR, Job.jobDueDate, 106), ' ', '-')  AS jobDueDate,REPLACE(CONVERT(NVARCHAR, Job.jobStatusClosedDate, 106), ' ', '-')  AS jobStatusClosedDate, Contact_1.userShortName AS QS, " + 
                         " Contact_2.firstName AS CE, Contact.firstName AS PE FROM    Job LEFT OUTER JOIN   Contact ON Job.peID = Contact.contactID LEFT OUTER JOIN  Contact AS Contact_2 ON Job.ceID = Contact_2.contactID LEFT OUTER JOIN " +
                        " Contact AS Contact_1 ON Job.qsID = Contact_1.contactID WHERE (Job.JobNo = '" + _jobNo + "')";

        SqlCommand cmd = new SqlCommand(sqlQuery, con);
        da = new SqlDataAdapter(cmd);
        da.Fill(ds);
        con.Open();
        cmd.ExecuteNonQuery();
        con.Close();

        htmlTable.Append("<table border='1' width = '60%'>");

        // htmlTable.Append("<tr style='background-color:green; color: White;'><th>Customer ID.</th></tr>");
        //  htmlTable.Append("<tr style='background-color:green; color: White;'><th>Customer ID.</th></tr>");  //<th>Name</th><th>Address</th><th>Contact No</th>
        // htmlTable.Append("<tr style='background-color:green; color: White;'><th>Customer ID.</th></tr>");

        if (!object.Equals(ds.Tables[0], null))
        {
            if (ds.Tables[0].Rows.Count > 0)
            {

                for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                {
                    htmlTable.Append("<tr style='color: Black;'>");
                    htmlTable.Append("<td> Job No. </td>");
                    htmlTable.Append("<td>" + ds.Tables[0].Rows[i]["Jobno"] + "</td>");
                    htmlTable.Append("</tr>");

                    htmlTable.Append("<tr style='color: Black;'>");
                    htmlTable.Append("<td> Contract No. </td>");
                    htmlTable.Append("<td>" + ds.Tables[0].Rows[i]["ContractNo"] + "</td>");
                    htmlTable.Append("</tr>");

                    htmlTable.Append("<tr style='color: Black;'>");
                    htmlTable.Append("<td> Received Date </td>");
                    htmlTable.Append("<td>" + ds.Tables[0].Rows[i]["JobReceivedDate"] + "</td>");
                    htmlTable.Append("</tr>");

                    htmlTable.Append("<tr style='color: Black;'>");
                    htmlTable.Append("<td> Due Date </td>");
                    htmlTable.Append("<td>" + ds.Tables[0].Rows[i]["JobDueDate"] + "</td>");
                    htmlTable.Append("</tr>");

                    htmlTable.Append("<tr style='color: Black;'>");
                    htmlTable.Append("<td> Completed On </td>");
                    htmlTable.Append("<td>" + ds.Tables[0].Rows[i]["jobStatusClosedDate"] + "</td>");
                    htmlTable.Append("</tr>");

                    htmlTable.Append("<tr style='color: Black;'>");
                    htmlTable.Append("<td> Job Desc </td>");
                    htmlTable.Append("<td>" + ds.Tables[0].Rows[i]["JobDesc"] + "</td>");
                    htmlTable.Append("</tr>");

                    htmlTable.Append("<tr style='color: Black;'>");
                    htmlTable.Append("<td> Project Title </td>");
                    htmlTable.Append("<td>" + ds.Tables[0].Rows[i]["ProjectTitle"] + "</td>");
                    htmlTable.Append("</tr>");


                    htmlTable.Append("<tr style='color: Black;'>");
                    htmlTable.Append("<td> Remarks </td>");
                    htmlTable.Append("<td>" + ds.Tables[0].Rows[i]["Remarks"] + "</td>");
                    htmlTable.Append("</tr>");

                    htmlTable.Append("<tr style='color: Black;'>");
                    htmlTable.Append("<td> QS </td>");
                    htmlTable.Append("<td>" + ds.Tables[0].Rows[i]["QS"] + "</td>");
                    htmlTable.Append("</tr>");

                    htmlTable.Append("<tr style='color: Black;'>");
                    htmlTable.Append("<td> PE </td>");
                    htmlTable.Append("<td>" + ds.Tables[0].Rows[i]["PE"] + "</td>");
                    htmlTable.Append("</tr>");

                    htmlTable.Append("<tr style='color: Black;'>");
                    htmlTable.Append("<td> CE </td>");
                    htmlTable.Append("<td>" + ds.Tables[0].Rows[i]["CE"] + "</td>");
                    htmlTable.Append("</tr>");
                }

                htmlTable.Append("</table>");
                DBDataPlaceHolder.Controls.Add(new Literal { Text = htmlTable.ToString() });
            }
            else
            {
                htmlTable.Append("<tr>");
                htmlTable.Append("<td align='center' colspan='2'>There is no Record.</td>");
                htmlTable.Append("</tr>");
            }
        }
    }
    private void BindDataMaster(string rework_jobNo)
    {
        SqlConnection con = new SqlConnection();
        con.ConnectionString = connValue;

       // "SELECT jobno,jobDesc,projectTitle,remarks,contractNo,jobReceivedDate,jobStatusClosedDate FROM Job where reWorkJobNo =  '" + rework_jobNo + "' "

        string strQuery = "SELECT   Job.jobNo, Job.jobDesc, Job.projectTitle, Job.remarks, Job.contractNo, Job.jobReceivedDate, Job.jobDueDate,Job.jobStatusClosedDate, Contact_1.userShortName AS QS, " + 
                        " Contact_2.firstName AS CE, Contact.firstName AS PE FROM    Job LEFT OUTER JOIN   Contact ON Job.peID = Contact.contactID LEFT OUTER JOIN  Contact AS Contact_2 ON Job.ceID = Contact_2.contactID LEFT OUTER JOIN " +
                        " Contact AS Contact_1 ON Job.qsID = Contact_1.contactID WHERE (Job.reworkJobNo = '" + rework_jobNo + "')";

        SqlCommand cmd = new SqlCommand(strQuery, con);
        da = new SqlDataAdapter(cmd);
        da.Fill(ds);
        con.Open();
        cmd.ExecuteNonQuery();
        con.Close();

        htmlTable.Append("<table border='1'>");       
                 
        if (!object.Equals(ds.Tables[0], null))
        {
            if (ds.Tables[0].Rows.Count > 0)
            {
                gridRework.DataSource = ds.Tables[0];
                gridRework.DataBind();
            }            
        }
     }
    private void BindDataMasterContractNo(string rework_jobNo)
    {
        SqlConnection con = new SqlConnection();
     
        con.ConnectionString = connValue;
        con.Open();

        // "SELECT jobno,jobDesc,projectTitle,remarks,contractNo,jobReceivedDate,jobStatusClosedDate FROM Job where reWorkJobNo =  '" + rework_jobNo + "' "

        string strQuery = "SELECT   Job.jobNo, Job.jobDesc, Job.projectTitle, Job.remarks, Job.contractNo, Job.jobReceivedDate, Job.jobDueDate,Job.jobStatusClosedDate, Contact_1.userShortName AS QS, " +
                        " Contact_2.firstName AS CE, Contact.firstName AS PE,Job.reworkJobNo FROM    Job LEFT OUTER JOIN   Contact ON Job.peID = Contact.contactID LEFT OUTER JOIN  Contact AS Contact_2 ON Job.ceID = Contact_2.contactID LEFT OUTER JOIN " +
                        " Contact AS Contact_1 ON Job.qsID = Contact_1.contactID " +
                        " WHERE (Job.contractNo = '" + Session["CntrNo"].ToString() + "') AND (Job.reworkJobNo IS NOT NULL) OR (Job.contractNo = '" + Session["CntrNo"].ToString() + "') AND (Job.reworkCnt IS NOT NULL) ";                    

        SqlCommand cmd = new SqlCommand(strQuery, con);
        da = new SqlDataAdapter(cmd);
        da.Fill(ds);
       
        cmd.ExecuteNonQuery();
        con.Close();

        htmlTable.Append("<table border='1'>");

        if (!object.Equals(ds.Tables[0], null))
        {
            if (ds.Tables[0].Rows.Count > 0)
            {
                gridRework.DataSource = ds.Tables[0];
                gridRework.DataBind();
            }
        }
    } 

    private IList<string> getReworkJobList(int _jobID)
    {
        IList<string> jobColl = new List<string>();

        using (SqlConnection cn = new SqlConnection(connValue))
        {
            using (SqlCommand cmd = new SqlCommand())
            {
                cmd.Connection = cn;
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "Select reworkJobNo from Job where JobID =" + _jobID;

                cn.Open();
                using (SqlDataReader dr = cmd.ExecuteReader())
                {
                    if (dr.HasRows)
                    {
                        while (dr.Read())
                        {
                            jobColl.Add(dr["reworkJobNo"].ToString());
                        }
                    }
                }
            }
        }
        return jobColl;
    }
}