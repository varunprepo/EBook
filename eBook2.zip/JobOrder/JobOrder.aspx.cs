﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using Datalayer;
using System.Net.Mail;
using System.Text;
using System.Globalization;
using System.Diagnostics;
using System.Web.UI.HtmlControls;

public partial class JobOrder_Default : System.Web.UI.Page
{
    string connValue = System.Configuration.ConfigurationManager.ConnectionStrings["EBSDEBookConn"].ConnectionString;
    int flag;
    JobOrderData jobdata; 
    DataSet ds;
    static IList<string> userRightsColl = new List<string>();
    string profile_Name = string.Empty;
    AdminInfo adminData = new AdminInfo();
   
    protected void Page_Load(object sender, EventArgs e)
    {
        Session["docSender"] = null;
    }  
    protected void OpenWindow(object sender, EventArgs e)
    {
        if (userRightsColl.Contains("2"))   //Add New Project
        {
            Session["lblText"] = "You are not allowed to Add New Job Order.Please contact system Administrator for further inquiry.";
            Session["lblSub"] = "Restricted Access to Add New Job Order.";
            Session["lblBody"] = "This is in reference to Restricted Access to Add New Job Order. I would like to inquire about the restriction.";


            string url = "RestrictedMsgWindow.aspx";
            string s = "window.open('" + url + "', 'popup_window', 'width=500,height=250,left=100,top=100,resizable=yes,scrollbars=yes');";
            ClientScript.RegisterStartupScript(this.GetType(), "script", s, true);

            
            //ClientScript.RegisterClientScriptBlock(this.GetType(), "Popup", "<script>alert('You have no privilege to add this Job,Contact administrator.')</script>", false);
            //return;
        }
        else if (Session["SectionID"].ToString().Equals("1"))
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "Popup", "<script>alert('This is not applicable to all employees from EBSD Payment Section.')</script>", false);
            return;
        }
        else
        {
            string url = "JobEntryForm.aspx";
            string s = "window.open('" + url + "', 'popup_window', 'width=990,height=700,left=100,top=100,resizable=yes,scrollbars=yes');";
            ClientScript.RegisterStartupScript(this.GetType(), "script", s, true);
        }
    }

      //IList<string> userRights = new List<string>(); 
  
    public void linkGoSomewhere_Click(object sender, EventArgs e)
    {
        LinkButton lnkBtn = sender as LinkButton;
        DataView dvCommitted = new DataView();
        dvCommitted = Session["CommittedInfo"] as DataView;

        dvCommitted.RowFilter = "project_code = '" + lnkBtn.Text + "'";
        gvJoborder.DataSource = dvCommitted;              // Closed,Cancelled,Completed 
        gvJoborder.DataBind();
    }

    public void lnkCmtTab_Click1(object sender, EventArgs e)
    {
        LinkButton lnkBtn = sender as LinkButton;
        DataView dvCommitted = new DataView();
        dvCommitted = Session["CommittedInfo"] as DataView;

        dvCommitted.RowFilter = "project_code = '" + lnkBtn.Text + "'";
        gvJoborder.DataSource = dvCommitted;              // Closed,Cancelled,Completed 
        gvJoborder.DataBind();
    } 
  
   // 
    private void PopulateDropDownBox(DropDownList ddlBox, string sqlQuery, string valueMember, string displayName)
    {
        ddlBox.DataBound += new EventHandler(this.ddlBox_DataBound);
        ddlBox.DataSource = new JobOrderData().FillDropdown(sqlQuery);
        ddlBox.DataTextField = displayName;
        ddlBox.DataValueField = valueMember;
        ddlBox.SelectedIndex = -1;
        ddlBox.DataBind();
        ddlBox.Items.Insert(0, new ListItem("--Select--"));
    }
    protected void ddlBox_DataBound(object sender, EventArgs e)
    {
        DropDownList ddl = (DropDownList)sender;
        ListItem emptyItem = new ListItem("", "");
        ddl.Items.Insert(0, emptyItem);
    }
    private void PopulateDropDownBox_TCMS(DropDownList ddlBox, string sqlQuery, string valueMember, string displayName)
    {
        ddlBox.DataSource = new JobOrderData().FillDropdown_TCMS(sqlQuery);
        ddlBox.DataTextField = displayName;
        ddlBox.DataValueField = valueMember;
        ddlBox.SelectedIndex = -1;
        ddlBox.DataBind();
    }
    protected override void OnInit(EventArgs e)
    {
        //if (!IsPostBack)
        //{
        //    FillGridView_Details(0);
        //}

        if (Session["UserName"] == null)
        {
            Response.Redirect("~/LoginPage.aspx", false);
            return;
        }
            


        userRightsColl = (IList<string>)Session["UserRightsColl"];

        if (!IsPostBack)
        {
            // userRightsColl = new JobOrderData().GetUserAccessList(Convert.ToInt32(Session["userID"]));

             if (!userRightsColl.Contains("5") && !userRightsColl.Contains("42"))
                 HiddenField1.Value = "AllShow";
             else if (userRightsColl.Contains("42"))             
                 HiddenField1.Value = "JobOrderShow";
             else
                 HiddenField1.Value = "JobOrderShow";

             FillGridView_Details(0);

            //if (userRightsColl.Count == 0)            
            //    HiddenField1.Value = "AllShow";  
            //else
            //    HiddenField1.Value = "JobOrderShow";           


            //if (!userRights.Contains("5") && (!userRights.Contains("42")))
            //{
            //    HiddenField1.Value = "AllShow";
            //}
            //else
            //{
            //    // HiddenField1.Value = "AllShow";

            //    HiddenField1.Value = "JobOrderShow";

            //    // HiddenField1.Value = "DontShow";

            //    //ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('You are not an Authenticated User')</script>", false);
            //}
        }

       
    }
    DataView dvCommitted = new DataView();
    DataView dvNonCommitted = new DataView();
    DataView dvPSA = new DataView();
   
    private void FillGridView_Details(int jobid)
    {
        if (userRightsColl.Contains("61"))   //Add New Project
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "Popup", "<script>alert('You have no privilege to add this task,Contact administrator.')</script>", false);
            return;
        }

           // Status 6 for Ongoing - Status - 10 for PSA stage

        string userAcess_42 = userRightsColl.Contains("42").ToString();
        string userAcess_5 = userRightsColl.Contains("5").ToString();
        string userAcess = string.Empty;

        if (userAcess_42.Equals("False") && userAcess_5.Equals("False"))
        {
            userAcess = "False";
            HiddenFieldAdmin.Value = "1";
        }
        else
        {
            userAcess = "True";
            HiddenFieldAdmin.Value = "2";
        }

         DataSet ds = new JobOrderData().GetJobOrderData(userAcess, Convert.ToInt32(Session["UserID"]));

         if (ds.Tables.Count == 0)
             return;


           // if (userRightsColl.Contains("5") && userRightsColl.Contains("42"))
            {
                DataView dvJobOrder = new DataView(ds.Tables[0]);
                //dvJobOrder.RowFilter = "JobTypeID in (3,7) or CategoryID in (3,7) or jobStatusID in(6,8)";    //Status ongoing n Hold(6,8) n UserID
                            
                

                dvCommitted = new DataView(ds.Tables[0]);
                dvCommitted.RowFilter = "jobCatID in (3,5) and jobClosedDate is Null";      //JobStatusID not in(1,2,5,7)          // for getting Committed {Projects}

                dvNonCommitted = new DataView(ds.Tables[0]);
                dvNonCommitted.RowFilter = "jobCatID in(4,6,7) and jobClosedDate is Null";   //JobStatusID not in(1,2,5,7)    // for getting Non- Committed {Projects}


                if (userAcess.Equals("False"))
                {
                    dvJobOrder.RowFilter = "jobCatID in (3,4,5,6,7)";        //dvJobOrder.RowFilter = "jobStatusID in(3) and jobCatID in (3,4,5,6,7)";

                    gvJoborder.DataSource = dvCommitted;
                    gvJoborder.DataBind();
                    Session["CommittedInfo"] = dvCommitted;

                    grvNonCommited.DataSource = dvNonCommitted;
                    grvNonCommited.DataBind();
                    Session["NonCommittedInfo"] = dvNonCommitted;
                }
                else
                {
                    dvJobOrder.RowFilter = "(jobOwnerStatusID not in(7) and jobCatID in (3,4,5,6,7))";            //dvJobOrder.RowFilter = "(jobOwnerStatusID in(3,6) and jobCatID in (3,4,5,6,7))";

                    grvJobOrder.DataSource = dvJobOrder;
                    grvJobOrder.DataBind();
                    Session["JobOrder"] = dvJobOrder;
                }

                if (userAcess.Equals("False"))
                {
                    DataView dvPSA = new DataView(ds.Tables[0]);
                    dvPSA.RowFilter = "(jobCatID = 1) and jobClosedDate is Null";                 // JobStatusID not in(1,5,7)       // for getting PSA {Projects}

                    grvPSA.DataSource = dvPSA;               // <> = Closed,Cancelled,Completed (2,4,5)
                    grvPSA.DataBind();
                    Session["PSAInfo"] = dvPSA;// for getting PSA {Projects}
                }
                else
                {
                    DataView MydvPSA = new DataView(ds.Tables[0]);
                    MydvPSA.RowFilter = "(jobCatID = 1) and jobOwnerStatusID not in(7)";

                    grvPSA.DataSource = MydvPSA;               // <> = Closed,Cancelled,Completed (2,4,5)
                    grvPSA.DataBind();
                    Session["PSAInfo"] = MydvPSA;// for getting PSA {Projects}
                } 

                // JobStatusID IN (2,4,5)

               

                // Job_Status = "";  Job_Status_id

               
                

              

                if (HttpContext.Current.Session["JobID123"] != null) 
                {
                    if (!userRightsColl.Contains("5") && !userRightsColl.Contains("42"))
                    {
                        if (Request.QueryString["catID"] == "3")   // Committed
                            HiddenFieldCmt.Value = "tabz2";
                        if (Request.QueryString["catID"] == "7")   //Non-comm
                            HiddenFieldNon.Value = "tabz3";
                        if (Request.QueryString["catID"] == "1")  //PSA
                            HiddenFieldPSA.Value = "tabz4";                       
                    }
                    else
                    {
                        if (Request.QueryString["catID"] == "3")   // Committed
                            HiddenFieldCmt.Value = "tabz5";
                        if (Request.QueryString["catID"] == "7")   //Non-comm
                            HiddenFieldNon.Value = "tabz5";
                        if (Request.QueryString["catID"] == "1")  //PSA
                            HiddenFieldPSA.Value = "tabz4";                        
                    }

                    Session["JobID123"] = null;
                }



                //string lnk = Request.QueryString["catID"].ToString();
                //if (lnk == "3")
                //{
                //    HiddenField3.Value = "abc";

                //}
                                  
           }
        // lblCnt.Text = " Jobs Count :  " + gridJobs.Rows.Count.ToString(); 
    }

    private void AccessRightsForReply()
    {
        if (userRightsColl.Contains("9"))   //Add New Project
        {
            Session["lblText"] = "You are not allowed to directly Reply and Close a Job Order.Please contact system Administrator for further inquiry.";
            Session["lblSub"] = "Restricted Access to Reply and Close a Job Order.";
            Session["lblBody"] = "This is in reference to Restricted Access to Reply and Close a Job Order. I would like to inquire about the restriction.";


            string url = "RestrictedMsgWindow.aspx";
            string s = "window.open('" + url + "', 'popup_window', 'width=500,height=250,left=100,top=100,resizable=yes,scrollbars=yes');";
            ClientScript.RegisterStartupScript(this.GetType(), "script", s, true);
        }

        return;
       
    }
    private void AccessRightsForDelete()
    {
        if (userRightsColl.Contains("3"))   //Add New Project
        {
            Session["lblText"] = "You are not allowed to delete a Job Order.Please contact system Administrator for further inquiry.";
            Session["lblSub"] = "Restricted Access to delete a Job Order.";
            Session["lblBody"] = "This is in reference to Restricted Access to delete a Job Order. I would like to inquire about the restriction.";


            string url = "RestrictedMsgWindow.aspx";
            string s = "window.open('" + url + "', 'popup_window', 'width=500,height=250,left=100,top=100,resizable=yes,scrollbars=yes');";
            ClientScript.RegisterStartupScript(this.GetType(), "script", s, true);
        }
    }
    protected void gvJoborder_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandArgument != "")
        {
            int jobid = Convert.ToInt32(e.CommandArgument);
            switch (e.CommandName)
            {
                case "EditJobid":

                    AccessRightsForReply();
                    if ((checkJobStatusCompleteDate(jobid) == "") & (!userRightsColl.Contains("9")))
                    {
                        ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('The Job Order not yet completed. Please update the Job Status before closing the Job.')</script>", false);
                        return;
                    }

                    ReplytoCloseCommittedJobs(jobid);
                    break;

                case "DeleteJobid":

                    AccessRightsForDelete();

                    if (!userRightsColl.Contains("3"))
                    {
                        flag = (new JobOrderData().DeleteJobOrder(jobid));
                        new JobOrderData().DeactivateDocumentForJobDelete(jobid);
                        // Delete job.Incharge.VOSI.Addendum.Update docID ,inchargeID in disribtion.
                        // flag = (new JobOrderData().DeactivateDocument(docID));


                        new JobOrderData().UpdateIsConfirmFalseOnJobDelete(jobid);

                        if (flag > 0)
                        {
                            FillGridView_Details(0);
                        }
                    }
                   
                    break;
            }
        }
    }

    private string checkJobStatusCompleteDate(int _jobID)
    {
        string jobStatusClosedDate = string.Empty;
        SqlConnection sqlConn = new SqlConnection(connValue);
        string sqlQuery = "SELECT jobStatusClosedDate From Job Where jobID = '" + _jobID + "' ";

        try
        {
            sqlConn.Open();
            SqlCommand sqlCom = new SqlCommand(sqlQuery, sqlConn);
            SqlDataReader sqlReader = sqlCom.ExecuteReader();
            while (sqlReader.Read())
            {
                jobStatusClosedDate = sqlReader["jobStatusClosedDate"].ToString();
            }
            sqlReader.Close();
        }
        catch (Exception ex)
        {
            Response.Write("Error getting while reading data !" + ex.Message);
        }
        finally
        {
            sqlConn.Close();
        }
        return jobStatusClosedDate;
    }
    protected void gvJoborder_RowDataBound(object sender, GridViewRowEventArgs e)
    {        
         //HyperLink1.Enabled = true; 
        Boolean chkStaff = false;
        //if (userRightsColl.Contains("3"))   //Add New Project
        //{
        //    // ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('You have no privilege to delete this Job,Contact administrator')</script>", false);
        //    return;
        //}
        //else
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                Label qs = (Label)e.Row.FindControl("lblQS");
                Label ce = (Label)e.Row.FindControl("lblCE");
                Label pe = (Label)e.Row.FindControl("lblPE");
                Label dc = (Label)e.Row.FindControl("lblDC");

                Label jobNo = (Label)e.Row.FindControl("lblJobNo");


                Label lblJobRecDate = (Label)e.Row.FindControl("lblCmtRecDate");
                Label lblJobStatus = (Label)e.Row.FindControl("lblJobStatus");



                // string jobOrderStat = Convert.ToInt32(lblJobStatus.Text);

                string jobOrderStat = lblJobStatus.Text;    //On-going

                if ((lblJobRecDate.Text != ""))       //& (lblJobStatus.Text.Equals("Under Process with EBSD"))
                {
                    string elapsedDays = getDaysByGivenEndDate(lblJobRecDate.Text, System.DateTime.Now.ToString());
                    Label WorkDays = (Label)e.Row.FindControl("lblDays");
                    int extraDays = Convert.ToInt32(WorkDays.Text);
                    extraDays = (extraDays / 2);

                    int totalDays = Convert.ToInt32(WorkDays.Text) + extraDays;

                    if ((jobOrderStat.Equals("On-going")) || (jobOrderStat.Equals("Pending")) || (jobOrderStat.Equals("On Hold")))
                    {
                        if (totalDays < Convert.ToInt32(elapsedDays))
                        {
                            e.Row.BackColor = System.Drawing.Color.LightPink;
                            e.Row.ForeColor = System.Drawing.Color.Red;

                            e.Row.Font.Bold = true;

                            jobNo.BackColor = System.Drawing.Color.Yellow;
                            e.Row.Cells[1].BackColor = System.Drawing.Color.White;
                        }
                        else if (Convert.ToInt32(WorkDays.Text) < Convert.ToInt32(elapsedDays))
                        {
                            e.Row.BackColor = System.Drawing.Color.MistyRose;


                            jobNo.BackColor = System.Drawing.Color.Yellow;
                            e.Row.Cells[1].BackColor = System.Drawing.Color.White;
                        }
                    }
                }

               // if ((qs != null) || (pe != null) || ((ce != null)))
                {
                    string strQS = qs.Text; string strCE = ce.Text; string strPE = pe.Text; string strDC = dc.Text;
                    if ((strQS == "") & (strPE == "") & (strCE == "") & (strDC == ""))
                    {
                        jobNo.BackColor = System.Drawing.Color.Red;
                        e.Row.Cells[1].BackColor = System.Drawing.Color.Red;

                        chkStaff = true;
                        lblCmt.Visible = true;
                        //ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('There is an active job order in Committed Contracts with no assigned staff.')</script>", false);
                    }

                    LinkButton l = (LinkButton)e.Row.FindControl("btnDelete");
                    l.Attributes.Add("onclick", "javascript:return " + "confirm('Are you sure you want to delete this Job')");
                    l.CssClass = "btndelete";

                    //l.Attributes.Add("CssClass", "btnSearch");                   
                }
            }
        }     

        //if (e.Row.RowType == DataControlRowType.DataRow)
        //{
        //    e.Row.Attributes["onmouseover"] = "this.style.backgroundColor='aquamarine';";
        //    e.Row.Attributes["onmouseout"] = "this.style.backgroundColor='white';";
        //    e.Row.ToolTip = "Click last column for selecting this row.";
        //}
    }
    protected void chkstate_CheckedChanged(object sender, EventArgs e)
    {
        //if (ddlProfileName.SelectedIndex == 0)
        //    return;

        CheckBox chk = (CheckBox)sender;

        Response.Redirect("SearchJobMstr.aspx");
      
    }
    protected void gvJoborder_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        gvJoborder.PageIndex = e.NewPageIndex;
        bindGridView();

        FillGridView_Details(0);
    }
    private void bindGridView()
    {
        gvJoborder.DataSource = Session["CommittedInfo"];
        gvJoborder.DataBind(); 
    }
    private void bindGridViewNonCmted()
    {
        grvNonCommited.DataSource = Session["NonCommittedInfo"];
        grvNonCommited.DataBind();
    }
    private void bindGridViewPSA()
    {
        grvPSA.DataSource = Session["PSAInfo"];
        grvPSA.DataBind();
    }
    private void bindGridViewJobOrder()
    {
        grvJobOrder.DataSource = Session["JobOrder"];
        grvJobOrder.DataBind();
    }  
    protected void GridView2_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        grvNonCommited.PageIndex = e.NewPageIndex;
        bindGridViewNonCmted();

        FillGridView_Details(0);
    }
    protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        grvPSA.PageIndex = e.NewPageIndex;
        bindGridViewPSA();

    }
    protected void btnAdd_Click(object sender, EventArgs e)
    {
        if (userRightsColl.Contains("2"))   //Add New Project
        {
            Session["lblText"] = "You are not allowed to Add New Job Order.Please contact system Administrator for further inquiry.";
            Session["lblSub"] = "Restricted Access to Add New Job Order.";
            Session["lblBody"] = "This is in reference to Restricted Access to Add New Job Order. I would like to inquire about the restriction.";


            string url = "RestrictedMsgWindow.aspx";
            string s = "window.open('" + url + "', 'popup_window', 'width=500,height=250,left=100,top=100,resizable=yes,scrollbars=yes');";
            ClientScript.RegisterStartupScript(this.GetType(), "script", s, true);

            //Response.Write("You have no privilege to delete this contract,Contact administrator");
            //return;
        }
        else if (Session["SectionID"].ToString().Equals("41"))
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "Popup", "<script>alert('This is not applicable to all employees from EBSD Payment Section .')</script>", false);
            return;
        }
        else
        {

        }
    }


    protected void btnReply_Click(object sender, EventArgs e)
    {
        int jobID = 0;
        GridView gridTemp = sender as GridView;
        if (userRightsColl.Contains("9"))   //Add New Document
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('You have no privilege to this action,Contact administrator')</script>", false);
            return;
        }
        else
        {
            int z = 0;
            foreach (GridViewRow x in gvJoborder.Rows)
            {
                CheckBox chk = (CheckBox)x.FindControl("ad");
                if (chk.Checked == true)
                {
                    z = z + 1;
                }
            }
            if (z == 1)
            {
                foreach (GridViewRow x in gvJoborder.Rows)
                {
                    CheckBox chk = (CheckBox)x.FindControl("ad");
                    Label _lbljobID = (Label)x.FindControl("lblJobID");
                    jobID = Convert.ToInt32(_lbljobID.Text);
                    if (chk.Checked == true)
                    {
                        Session["ReplyToClose"] = "1";
                        Session["DocCategoryID"] = "2";
                        Session["DocID"] = null;
                        Session["UrlRef"] = "~/JobOrder/JobOrder.aspx";
                        Session["JobID"] = jobID;
                        Response.Redirect("~/Documents/DocumentDetails.aspx", false);
                    }
                }
            }
            else
            {
                ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Please select checkBox for Reply to Close')</script>", false);
            }            
        }

        new JobOrderData().UpdateJobStatus_ReplyToCloseDocument(jobID);

        //new JobOrderData().UpdateLetterNo_ReplyToCloseDocument(jobID,"");   // update at job_ 

       // getandUpdateElapsedWorkDaysCount(jobID);
    }
    
    protected void gvJoborder_SelectedIndexChanged(object sender, EventArgs e)
    {
        int index = gvJoborder.SelectedRow.RowIndex;
        string name = gvJoborder.SelectedRow.Cells[0].Text;
        string country = gvJoborder.SelectedRow.Cells[1].Text;
        string message = "Row Index: " + index + "\\nName: " + name + "\\nCountry: " + country;
        ClientScript.RegisterStartupScript(this.GetType(), "alert", "alert('" + message + "');", true);
    }
    protected void btnDueTasks_Click(object sender, EventArgs e)
    {
       // Response.Redirect("OverDueJobs.aspx");

        Response.Write("<script language='javascript'> window.open('OverDueJobs.aspx','','width=700,Height=500,fullscreen=1,location=0,scrollbars=0,menubar=1,toolbar=1, align=center,top=100,left=500'); </script>");
    }
    protected void btnAddendum_Click(object sender, EventArgs e)
    {
       
        //Response.Redirect("TasksfromCalender.aspx");
       // Response.Write("<script language='javascript'> window.open('TasksfromCalender.aspx','','width=600,Height=500,fullscreen=1,location=0,scrollbars=0,menubar=1,toolbar=1, align=center,top=100,left=500'); </script>");
    }
    

    //protected void btnSearch_Click(object sender, EventArgs e)
    //{
    //    Response.Redirect("SearchJobMstr.aspx");

    //    //Response.Write("<script language='javascript'> window.open('SearchJob.aspx','','width= 1024px,Height=600px,fullscreen=1,location=0,scrollbars=0,menubar=1,toolbar=1, align=center,top=100,left=500'); </script>");
    //}

    protected void btnSearch_Click(object sender, EventArgs e)
    {
        if (userRightsColl.Contains("10"))   //Add New Project
        {
            Session["lblText"] = "You are not allowed to View Job Order Log.Please contact System Administrator for further inquiry.";
            Session["lblSub"] = "Restricted Access to View Job Order Log.";
            Session["lblBody"] = "This is in reference to Restricted Access to View Job Order Log. I would like to inquire about the restriction.";


            string url = "RestrictedMsgWindow.aspx";
            string s = "window.open('" + url + "', 'popup_window', 'width=500,height=250,left=100,top=100,resizable=yes,scrollbars=yes');";
            ClientScript.RegisterStartupScript(this.GetType(), "script", s, true);

            //ClientScript.RegisterClientScriptBlock(this.GetType(), "Popup", "<script>alert('You have no privilege to add this Job,Contact administrator.')</script>", false);
            //return;
        }
        else
        {
            Session["OnGoingJobStatus"] = null;
            Session["Flag"] = "1";
            Response.Redirect("SearchJobMstr.aspx");
        }
    }

    protected void gridJobOrder_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        
    }
    protected void gridJobOrder_PageIndexChanged(object sender, EventArgs e)
    {
      
    }
    protected void gridJobOrder_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandArgument != "")
        {
            int jobid = Convert.ToInt32(e.CommandArgument);
            switch (e.CommandName)
            {
                case "EditJobid":

                    AccessRightsForReply();

                    if ((checkJobStatusCompleteDate(jobid) == "") & (!userRightsColl.Contains("9")))
                    {
                        ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('The Job Order not yet completed. Please update the Job Status before closing the Job.')</script>", false);
                        return;
                    }

                    ReplytoCloseCommittedJobs(jobid);

                    break;

                case "DeleteJobid":

                    AccessRightsForDelete();
                    flag = (new JobOrderData().DeleteJobOrder(jobid));

                    new JobOrderData().DeactivateDocumentForJobDelete(jobid);

                    new JobOrderData().UpdateIsConfirmFalseOnJobDelete(jobid);

                    if (flag > 0)
                    {
                       // Response.Write("deleted");
                    }
                    break;
            }
        }
    }
    protected void gridJobOrder_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void gridJobOrder_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        gvJoborder.PageIndex = e.NewPageIndex;
        bindGridViewJobOrder();

        FillGridView_Details(0);
    }
    private string getDaysByGivenEndDate(string strDate, string endDate)
    {
        strDate = Convert.ToDateTime(strDate).ToString("MM/dd/yyyy", CultureInfo.InvariantCulture);
        endDate = Convert.ToDateTime(endDate).ToString("MM/dd/yyyy", CultureInfo.InvariantCulture);

        DateTime strDt = DateTime.ParseExact(strDate, "MM/dd/yyyy", CultureInfo.InvariantCulture);
        DateTime endDt = DateTime.ParseExact(endDate, "MM/dd/yyyy", CultureInfo.InvariantCulture);

        SqlConnection con = new SqlConnection(connValue);
        SqlCommand cmd = new SqlCommand();

        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Connection = con;

        cmd.CommandText = "testSP";

        SqlParameter prm = cmd.Parameters.Add("@ad_startDate", SqlDbType.DateTime);
        prm.Value = strDt;

        prm = cmd.Parameters.Add("@ad_endDate", SqlDbType.DateTime);
        prm.Value = endDt;

        prm = cmd.Parameters.Add("@ai_workDays", SqlDbType.Int);
        prm.Direction = ParameterDirection.Output;

        //prm = cmd.Parameters.Add("@as_errMsg", SqlDbType.VarChar);
        //prm.Direction = ParameterDirection.Output;

        con.Open();
        SqlDataReader dr = cmd.ExecuteReader();
        while (dr.Read())
            Console.WriteLine(dr.GetString(0));
        con.Dispose();
        con.Close();

        return cmd.Parameters[2].Value.ToString();
    }
    protected void grvPSA_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        Boolean chkStaff = false;
       
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
               //e.Row.Cells[2].Visible = false;

                //e.Row.Cells[2].Visible = false;

                //e.Row.Visible = false;

               // Label lblMyJobStatus = (Label)e.Row.FindControl("lblMyJobStatus");

               // lblMyJobStatus.Visible = false;

                Label qs = (Label)e.Row.FindControl("lblQS");
                Label ce = (Label)e.Row.FindControl("lblCE");
                Label pe = (Label)e.Row.FindControl("lblPE");
                Label dc = (Label)e.Row.FindControl("lblDC");


                Label jobNo = (Label)e.Row.FindControl("lblJobNo");

                Label lblJobRecDate = (Label)e.Row.FindControl("lblPsaRecDate");
                Label lblJobStatus = (Label)e.Row.FindControl("lblJobStatus");

                if ((lblJobRecDate.Text != "") & (lblJobStatus.Text.Equals("Under Process with EBSD")))
                {
                    string elapsedDays = getDaysByGivenEndDate(lblJobRecDate.Text, System.DateTime.Now.ToString());
                    Label WorkDays = (Label)e.Row.FindControl("lblDays");
                    int extraDays = Convert.ToInt32(WorkDays.Text);
                    extraDays = (extraDays / 2);
                    int totalDays = Convert.ToInt32(WorkDays.Text) + extraDays;
                    if (totalDays < Convert.ToInt32(elapsedDays))
                    {
                        e.Row.BackColor = System.Drawing.Color.LightPink;
                        e.Row.ForeColor = System.Drawing.Color.Red;
                        e.Row.Font.Bold = true;

                        jobNo.BackColor = System.Drawing.Color.Yellow;
                        e.Row.Cells[1].BackColor = System.Drawing.Color.White;
                    }
                    else if (Convert.ToInt32(WorkDays.Text) < Convert.ToInt32(elapsedDays))
                    {
                        e.Row.BackColor = System.Drawing.Color.MistyRose;
                        jobNo.BackColor = System.Drawing.Color.Yellow;
                        e.Row.Cells[1].BackColor = System.Drawing.Color.White;
                    }
                }

                if (qs != null)
                {                    
                    string strQS = qs.Text; string strCE = ce.Text; string strPE = pe.Text; string strDC = dc.Text;

                    if ((strQS == "") & (strPE == "") & (strCE == "") & (strDC== ""))
                    {
                        jobNo.BackColor = System.Drawing.Color.Red;
                        e.Row.Cells[1].BackColor = System.Drawing.Color.Red;
                        chkStaff = true;

                        lblPSA.Visible = true;

                       // ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('There is an active job order in PSA Contracts with no assigned staff.')</script>", false);
                    }

                    if (!userRightsColl.Contains("3"))
                    {
                        LinkButton l = (LinkButton)e.Row.FindControl("btnDelete");
                        l.Attributes.Add("onclick", "javascript:return " + "confirm('Are you sure you want to delete this Job')");
                        l.CssClass = "btndelete";
                    }

                    CheckBox chkstate = (CheckBox)e.Row.FindControl("ad");
                    chkstate.ToolTip = "";
                    chkstate.CheckedChanged += new EventHandler(chkstate_CheckedChanged);
                }

                if (!userRightsColl.Contains("5") && !userRightsColl.Contains("42"))
                    grvPSA.Columns[4].Visible = false;  //MyJobStatus   

                          

            }
        }
        //if (chkStaff)
        //     // ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('There is job order in PSA Contracts with no assigned staff.')</script>", false);  
    }
    protected void grvPSA_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandArgument != "")
        {
            int jobid = Convert.ToInt32(e.CommandArgument);
            switch (e.CommandName)
            {
                case "EditJobid":

                     AccessRightsForReply();

                    if ((checkJobStatusCompleteDate(jobid) == "") & (!userRightsColl.Contains("9")))
                    {
                        ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('The Job Order not yet completed. Please update the Job Status before closing the Job.')</script>", false);
                        return;
                    }

                    ReplytoCloseCommittedJobs(jobid);

                    break;

                case "DeleteJobid":

                    AccessRightsForDelete();

                    if (!userRightsColl.Contains("3"))
                    {
                        flag = (new JobOrderData().DeleteJobOrder(jobid));
                        new JobOrderData().DeactivateDocumentForJobDelete(jobid);

                        new JobOrderData().UpdateIsConfirmFalseOnJobDelete(jobid);

                        if (flag > 0)
                        {
                            FillGridView_Details(0);
                        }
                    }
                    
                    break;
            }
        }
    }

    protected void grvPSA_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        grvPSA.PageIndex = e.NewPageIndex;
        bindGridViewPSA();

        FillGridView_Details(0);
    }
    
    protected void grvNonCommited_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        grvNonCommited.PageIndex = e.NewPageIndex;
        bindGridView();

        FillGridView_Details(0);
    }
    protected void grvNonCommited_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandArgument != "")
        {
            int jobid = Convert.ToInt32(e.CommandArgument);
            switch (e.CommandName)
            {
                case "EditJobid":

                     AccessRightsForReply();

                     if ((checkJobStatusCompleteDate(jobid) == "") & (!userRightsColl.Contains("9")))
                    {
                        ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('The Job Order not yet completed. Please update the Job Status before closing the Job.')</script>", false);
                        return;
                    }

                    ReplytoCloseCommittedJobs(jobid);

                    break;

                case "DeleteJobid":

                    AccessRightsForDelete();

                    if (!userRightsColl.Contains("3"))
                    {
                        flag = (new JobOrderData().DeleteJobOrder(jobid));
                        new JobOrderData().DeactivateDocumentForJobDelete(jobid);

                        new JobOrderData().UpdateIsConfirmFalseOnJobDelete(jobid);

                        if (flag > 0)
                        {
                            FillGridView_Details(0);
                        }
                    }                    
                   
                    break;
            }
        }
    }
 
    protected void grvNonCommited_RowDataBound(object sender, GridViewRowEventArgs e)
    {        
       
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                Label qs = (Label)e.Row.FindControl("lblQS");
                Label ce = (Label)e.Row.FindControl("lblCE");
                Label pe = (Label)e.Row.FindControl("lblPE");
                Label dc = (Label)e.Row.FindControl("lblDC");

                Label jobNo = (Label)e.Row.FindControl("lblJobNo");

                Label lblJobRecDate = (Label)e.Row.FindControl("lblNonRecDate");
                Label lblJobStatus = (Label)e.Row.FindControl("lblJobStatus");
                string jobOrderStat = lblJobStatus.Text;    //On-going

                if ((lblJobRecDate.Text != ""))       //& (lblJobStatus.Text.Equals("Under Process with EBSD"))
                {
                    string elapsedDays = getDaysByGivenEndDate(lblJobRecDate.Text, System.DateTime.Now.ToString());
                    Label WorkDays = (Label)e.Row.FindControl("lblDays");
                    int extraDays = Convert.ToInt32(WorkDays.Text);
                    extraDays = (extraDays / 2);

                    int totalDays = Convert.ToInt32(WorkDays.Text) + extraDays;

                    if ((jobOrderStat.Equals("On-going")) || (jobOrderStat.Equals("Pending")) || (jobOrderStat.Equals("On Hold")))
                    {
                        if (totalDays < Convert.ToInt32(elapsedDays))
                        {
                            e.Row.BackColor = System.Drawing.Color.LightPink;
                            e.Row.ForeColor = System.Drawing.Color.Red;

                            e.Row.Font.Bold = true;

                            jobNo.BackColor = System.Drawing.Color.Yellow;
                            e.Row.Cells[1].BackColor = System.Drawing.Color.White;
                        }
                        else if (Convert.ToInt32(WorkDays.Text) < Convert.ToInt32(elapsedDays))
                        {
                            e.Row.BackColor = System.Drawing.Color.MistyRose;


                            jobNo.BackColor = System.Drawing.Color.Yellow;
                            e.Row.Cells[1].BackColor = System.Drawing.Color.White;
                        }
                    }
                }

                if (qs != null)
                {
                    string strQS = qs.Text; string strCE = ce.Text; string strPE = pe.Text; string strDC = dc.Text;

                    if ((strQS == "") & (strPE == "") & (strCE == "") & (strDC == ""))
                    {
                        jobNo.BackColor = System.Drawing.Color.Red;
                        e.Row.Cells[1].BackColor = System.Drawing.Color.Red;
                        lblNonCmt.Visible = true;
                       // ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('There is an active job order in Non-Committed Contracts with no assigned staff.')</script>", false);
                    }

                    if (!userRightsColl.Contains("3"))
                    {
                        LinkButton l = (LinkButton)e.Row.FindControl("btnDelete");
                        l.Attributes.Add("onclick", "javascript:return " + "confirm('Are you sure you want to delete this Job')");
                        l.CssClass = "btndelete";
                        //l.Attributes.Add("CssClass", "btnSearch");
                    }

                    CheckBox chkstate = (CheckBox)e.Row.FindControl("ad");
                    chkstate.ToolTip = "";
                    chkstate.CheckedChanged += new EventHandler(chkstate_CheckedChanged);
                }
            }
        }

        //if (chkStaff)
        //    ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('There is job order in Non Committed Contracts with no assigned staff.')</script>", false);  
    }
    
    protected void grvJobOrder_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            Label qs = (Label)e.Row.FindControl("lblQS");
            Label ce = (Label)e.Row.FindControl("lblCE");
            Label pe = (Label)e.Row.FindControl("lblPE");
            Label dc = (Label)e.Row.FindControl("lblDC");

            Label jobNo = (Label)e.Row.FindControl("lblJobNo"); //
            // Label ancrJobNo = (Label)e.Row.FindControl("ancrJobNo");



            Label lblJobRecDate = (Label)e.Row.FindControl("lblJobRecDate");
            Label lblJobStatus = (Label)e.Row.FindControl("lblJobStatus");

            // string jobOrderStat = Convert.ToInt32(lblJobStatus.Text);

            string jobOrderStat = lblJobStatus.Text;    //On-going

            if ((lblJobRecDate.Text != ""))       //& (lblJobStatus.Text.Equals("Under Process with EBSD"))
            {
                string elapsedDays = getDaysByGivenEndDate(lblJobRecDate.Text, System.DateTime.Now.ToString());
                Label WorkDays = (Label)e.Row.FindControl("lblDays");
                int extraDays = Convert.ToInt32(WorkDays.Text);
                extraDays = (extraDays / 2);

                int totalDays = Convert.ToInt32(WorkDays.Text) + extraDays;

                if ((jobOrderStat.Equals("On-going")) || (jobOrderStat.Equals("Pending")) || (jobOrderStat.Equals("On Hold")))
                {
                    if (totalDays < Convert.ToInt32(elapsedDays))
                    {
                        e.Row.BackColor = System.Drawing.Color.LightPink;
                        e.Row.ForeColor = System.Drawing.Color.Red;

                        e.Row.Font.Bold = true;

                        jobNo.BackColor = System.Drawing.Color.Yellow;
                        e.Row.Cells[1].BackColor = System.Drawing.Color.White;
                    }
                    else if (Convert.ToInt32(WorkDays.Text) < Convert.ToInt32(elapsedDays))
                    {
                        e.Row.BackColor = System.Drawing.Color.MistyRose;


                        jobNo.BackColor = System.Drawing.Color.Yellow;
                        e.Row.Cells[1].BackColor = System.Drawing.Color.White;
                    }
                }
            }


            string strQS = qs.Text; string strCE = ce.Text; string strPE = pe.Text; string strDC = dc.Text;

            if ((strQS == "") & (strPE == "") & (strCE == "") & (strDC == ""))
            {
                jobNo.BackColor = System.Drawing.Color.Red;
                e.Row.Cells[1].BackColor = System.Drawing.Color.Red;
            }
            // 3
            if (!userRightsColl.Contains("3"))
            {
                LinkButton l = (LinkButton)e.Row.FindControl("btnDelete");
                l.Attributes.Add("onclick", "javascript:return " + "confirm('Are you sure you want to delete this Job')");
                l.CssClass = "btndelete";
            }


        }
        //if (chkStaff)
        //    ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('There is job order in Committed Contracts with no assigned staff.')</script>", false);  
    }
    
    protected void grvJobOrder_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandArgument != "")
        {
            int jobid = Convert.ToInt32(e.CommandArgument);
            switch (e.CommandName)
            {
                case "EditJobid":

                     AccessRightsForReply();

                    if ((checkJobStatusCompleteDate(jobid) == "") & (!userRightsColl.Contains("9")))
                    {
                        ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('The Job Order not yet completed. Please update the Job Status before closing the Job.')</script>", false);
                        return;
                    }

                    ReplytoCloseCommittedJobs(jobid);

                    break;

                case "DeleteJobid":

                    AccessRightsForDelete();

                    if (!userRightsColl.Contains("3"))
                    {
                        flag = (new JobOrderData().DeleteJobOrder(jobid));
                        new JobOrderData().DeactivateDocumentForJobDelete(jobid);

                        new JobOrderData().UpdateIsConfirmFalseOnJobDelete(jobid);

                        // Delete job.Incharge.VOSI.Addendum.Update docID ,inchargeID in disribtion.
                        // flag = (new JobOrderData().DeactivateDocument(docID));

                        if (flag > 0)
                        {
                            FillGridView_Details(0);
                        }
                    }
                   
                    break;
            }
        }
    }
    protected void grvJobOrder_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        grvJobOrder.PageIndex = e.NewPageIndex;
        bindGridView();

        FillGridView_Details(0);
    }
    protected void btnReplyJob_Click(object sender, EventArgs e)
    {
        ReplytoCloseCommittedJobs();
    }
    private void ReplytoCloseCommittedJobs()
    {
        int jobID = 0;
        //GridView gridTemp = sender as GridView;
        if (userRightsColl.Contains("9"))   //Add New Document
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('You have no privilege to this action,Contact administrator')</script>", false);
            return;
        }
        else
        {
            int z = 0;
            foreach (GridViewRow x in grvJobOrder.Rows)
            {
                CheckBox chk = (CheckBox)x.FindControl("ad");
                if (chk.Checked == true)
                {
                    z = z + 1;
                }
            }
            if (z == 1)
            {
                foreach (GridViewRow x in grvJobOrder.Rows)
                {
                    CheckBox chk = (CheckBox)x.FindControl("ad");
                    Label _lbljobID = (Label)x.FindControl("lblJobID");
                    jobID = Convert.ToInt32(_lbljobID.Text);
                    if (chk.Checked == true)
                    {
                        Session["ReplyToClose"] = "1";
                        Session["DocCategoryID"] = "2";
                        Session["DocID"] = null;
                        Session["UrlRef"] = "~/JobOrder/JobOrder.aspx";
                        Session["JobID"] = jobID;
                        Response.Redirect("~/Documents/DocumentDetails.aspx", false);
                    }
                }
            }
            else
            {
                ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Please select checkBox for Reply to Close')</script>", false);
            }
        }
       // getandUpdateElapsedWorkDaysCount(jobID);
    }
    protected void btnSearchJob_Click(object sender, EventArgs e)
    {
        if (userRightsColl.Contains("10"))   //Add New Project
        {
            Session["lblText"] = "You are not allowed to View Job Order Log.Please contact System Administrator for further inquiry.";
            Session["lblSub"] = "Restricted Access to View Job Order Log.";
            Session["lblBody"] = "This is in reference to Restricted Access to View Job Order Log. I would like to inquire about the restriction.";
            
            string url = "RestrictedMsgWindow.aspx";
            string s = "window.open('" + url + "', 'popup_window', 'width=500,height=250,left=100,top=100,resizable=yes,scrollbars=yes');";
            ClientScript.RegisterStartupScript(this.GetType(), "script", s, true);

            //ClientScript.RegisterClientScriptBlock(this.GetType(), "Popup", "<script>alert('You have no privilege to add this Job,Contact administrator.')</script>", false);
            //return;
        }
        else
        {
            Session["OnGoingJobStatus"] = null;
            Session["Flag"] = "1";
            Response.Redirect("SearchJobMstr.aspx");
        }
    }
    protected void btnReplyPSA_Click(object sender, EventArgs e)
    {
        int jobID = 0;
        //GridView gridTemp = sender as GridView;
        if (userRightsColl.Contains("9"))   //Add New Document
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('You have no privilege to this action,Contact administrator')</script>", false);
            return;
        }
        else
        {
            int z = 0;
            foreach (GridViewRow x in grvPSA.Rows)
            {
                CheckBox chk = (CheckBox)x.FindControl("ad");
                if (chk.Checked == true)
                {
                    z = z + 1;
                }
            }
            if (z == 1)
            {
                foreach (GridViewRow x in grvPSA.Rows)
                {
                    CheckBox chk = (CheckBox)x.FindControl("ad");
                    Label _lbljobID = (Label)x.FindControl("lblJobID");
                    jobID = Convert.ToInt32(_lbljobID.Text);

                    if (chk.Checked == true)
                    {
                       
                        Session["ReplyToClose"] = "1";
                        Session["DocCategoryID"] = "2";
                        Session["DocID"] = null;
                        Session["UrlRef"] = "~/JobOrder/JobOrder.aspx";
                        Session["JobID"] = jobID;
                        Response.Redirect("~/Documents/DocumentDetails.aspx", false);
                    }
                }
            }
            else
            {
                ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Please select checkBox for Reply to Close')</script>", false);
            }
        }
       // getandUpdateElapsedWorkDaysCount(jobID);
    }
    protected void btnSearchPSA_Click(object sender, EventArgs e)
    {
        if (userRightsColl.Contains("11"))   //Add New Project
        {
            Session["lblText"] = "You are not allowed to View Addendum Log.Please contact System Administrator for further inquiry.";
            Session["lblSub"] = "Restricted Access to View Addendum Log.";
            Session["lblBody"] = "This is in reference to Restricted Access to View Addendum Log. I would like to inquire about the restriction.";


            string url = "RestrictedMsgWindow.aspx";
            string s = "window.open('" + url + "', 'popup_window', 'width=500,height=250,left=100,top=100,resizable=yes,scrollbars=yes');";
            ClientScript.RegisterStartupScript(this.GetType(), "script", s, true);



            //ClientScript.RegisterClientScriptBlock(this.GetType(), "Popup", "<script>alert('You have no privilege to add this Job,Contact administrator.')</script>", false);
            //return;
        }
        else
        {
            Session["OnGoingJobStatus"] = null;
            Session["Flag"] = "1";
            Response.Redirect("SearchAdmData.aspx");         //SearchAddendum.aspx
        }
    }
    protected void btnSearchNon_Click(object sender, EventArgs e)
    {
        Session["OnGoingJobStatus"] = null;
        Session["Flag"] = "1";
        Response.Redirect("SearchJobMstr.aspx");        
    }
    protected void btnRepltNon_Click(object sender, EventArgs e)
    {
        int jobID = 0;
        //GridView gridTemp = sender as GridView;
        if (userRightsColl.Contains("9"))   //Add New Document
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('You have no privilege to this action,Contact administrator')</script>", false);
            return;
        }
        else
        {
            int z = 0;
            foreach (GridViewRow x in grvNonCommited.Rows)
            {
                CheckBox chk = (CheckBox)x.FindControl("ad");
                if (chk.Checked == true)
                {
                    z = z + 1;
                }
            }
            if (z == 1)
            {
                foreach (GridViewRow x in grvNonCommited.Rows)
                {
                    CheckBox chk = (CheckBox)x.FindControl("ad");
                    Label _lbljobID = (Label)x.FindControl("lblJobID");
                    jobID = Convert.ToInt32(_lbljobID.Text);
                    if (chk.Checked == true)
                    {
                        Session["ReplyToClose"] = "1";
                        Session["DocCategoryID"] = "2";
                        Session["DocID"] = null;
                        Session["UrlRef"] = "~/JobOrder/JobOrder.aspx";
                        Session["JobID"] = jobID;
                        Response.Redirect("~/Documents/DocumentDetails.aspx", false);
                    }
                }
            }
            else
            {
                ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Please select checkBox for Reply to Close')</script>", false);
            }
        }

       // getandUpdateElapsedWorkDaysCount(jobID);

        //UpdateJobElapseDate(jobID, 5);
    }
    private void getandUpdateElapsedWorkDaysCount(int jobID)
    {
       string _createDate =  getJobCreateDate(jobID);
       string elapseDays = getDaysByGivenEndDate(System.DateTime.Now.ToString(), _createDate);
       UpdateJobElapseDate(jobID, Convert.ToInt32(elapseDays));

        //DateTime start = new DateTime(1990, 1, 1);
        //start = Convert.ToDateTime(_createDate);
        //DateTime end = new DateTime(1990, 1, 31);
        //end = System.DateTime.Now;

        //int dateCnt = Convert.ToInt32((start - end).Days);
        //if (dateCnt <= 0)
        //{
        //    // txtDueDate.Text = Convert.ToDateTime(Calendar1.SelectedDate).ToString("dd/MMM/yyyy");
        //    return;
        //}
    }
   
    private void UpdateJobElapseDate(int _jobIDElapse,int elapseDays)
    {
        SqlConnection con = new SqlConnection(connValue);
        SqlCommand cmd = new SqlCommand();
        cmd.CommandType = CommandType.Text;
        cmd.Connection = con;
        cmd.CommandText = "Update Job Set elapsedWorkDays = @elapsedWorkDays Where jobID = @jobID";
        cmd.Parameters.AddWithValue("@jobID", _jobIDElapse);
        cmd.Parameters.AddWithValue("@elapsedWorkDays", elapseDays);
        try
        {
            con.Open();
            cmd.ExecuteNonQuery();
            con.Dispose();
        }
        catch (System.Exception ex)
        {
            throw ex;
        }
        finally
        {
            con.Close();
        }
    }
    public string getJobCreateDate(int _jobID)
    {
        string jobCreateDate = string.Empty;
        try
        {
            SqlConnection sqlConn = new SqlConnection(connValue);
            sqlConn.Open();
            SqlCommand sqlCom = new SqlCommand("Select createDate from Job Where jobID = " + _jobID + " ", sqlConn);    
            SqlDataReader sqlReader = sqlCom.ExecuteReader();
            while (sqlReader.Read())
            {
                jobCreateDate = sqlReader["createDate"].ToString();
            }
            sqlReader.Close();
            sqlConn.Close();
        }
        catch (System.Exception ex)
        {
            throw ex;
        }
        return jobCreateDate;
    }
    private void ReplytoCloseCommittedJobs(int jobid)
    {
        if (userRightsColl.Contains("9"))   //Add New Document
        {
            Session["lblText"] = "You are not allowed to directly Reply and Close a Job Order.Please contact system Administrator for further inquiry.";
            Session["lblSub"] = "Restricted Access to Reply and Close a Job Order.";
            Session["lblBody"] = "This is in reference to Restricted Access to Reply and Close a Job Order. I would like to inquire about the restriction.";

            string url = "RestrictedMsgWindow.aspx";
            string s = "window.open('" + url + "', 'popup_window', 'width=500,height=250,left=100,top=100,resizable=yes,scrollbars=yes');";
            ClientScript.RegisterStartupScript(this.GetType(), "script", s, true);
        }
        else
        {
            if (getJobStatusClosingDate())      //if (Convert.ToBoolean(getJobStatusClosingDate)==true)
            {
                Session["UrlRef"] = "~/JobOrder/JobOrder.aspx";
                Session["JobID"] = jobid;
                Response.Redirect("~/Documents/DocumentDetails.aspx?RecSentCatID=2", false);
            }
            else
            {
                ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('The job order is not yet completed. Please update the Job Order Status before closing the job.')</script>", false);
            }
        }
    }


    private Boolean getJobStatusClosingDate()
    {
        //jobStatusClosedDate

        return true;
    } 

     # region


    protected void lnkProjectCodeCmted_Click(object sender, EventArgs e)     //ForCommitted
    {
        try
        {
            LinkButton lnkJobID = (LinkButton)sender;
            GridViewRow gvr = (GridViewRow)lnkJobID.NamingContainer;
            Session["ProjectCode"] = ((HtmlGenericControl)gvr.FindControl("divProjectCodeCmted")).InnerText;

            Session["UrlRef"] = Request.Url.AbsoluteUri;
            Response.Redirect("~/JobOrder/SearchJobMstr.aspx?Project_Code = " + Session["ProjectCode"] + "", false);

        }
        catch
        {

        }

    }
    protected void lnkProjectCodeNon_Click(object sender, EventArgs e)     //ForCommitted
    {
        try
        {
            LinkButton lnkJobID = (LinkButton)sender;
            GridViewRow gvr = (GridViewRow)lnkJobID.NamingContainer;
            Session["ProjectCode"] = ((HtmlGenericControl)gvr.FindControl("divProjectCodeNon")).InnerText;

            Session["UrlRef"] = Request.Url.AbsoluteUri;
            Response.Redirect("~/JobOrder/SearchJobMstr.aspx?Project_Code = " + Session["ProjectCode"] + "", false);

        }
        catch
        {

        }

    }
    protected void lnkProjectCodeMyJob_Click(object sender, EventArgs e)     //For Cmt and Non Cmted Projects
    {
        try
        {
            LinkButton lnkJobID = (LinkButton)sender;
            GridViewRow gvr = (GridViewRow)lnkJobID.NamingContainer;
            Session["ProjectCode"] = ((HtmlGenericControl)gvr.FindControl("divProjectCodeMyJob")).InnerText;

            Session["UrlRef"] = Request.Url.AbsoluteUri;
            Response.Redirect("~/JobOrder/SearchJobMstr.aspx?Project_Code = " + Session["ProjectCode"] + "", false);

        }
        catch
        {

        }
    }
    protected void lnkPSAPrjCode_Click(object sender, EventArgs e)     
    {
        try
        {
            LinkButton lnkJobID = (LinkButton)sender;
            GridViewRow gvr = (GridViewRow)lnkJobID.NamingContainer;
            Session["ProjectCode"] = ((HtmlGenericControl)gvr.FindControl("divProjectCodePSA")).InnerText;

            Session["UrlRef"] = Request.Url.AbsoluteUri;
            Response.Redirect("~/JobOrder/SearchAdmData.aspx?Project_Code = " + Session["ProjectCode"] + "", false);

        }
        catch
        {

        }
    }
    protected void lnkBtnCmtJobID_Click(object sender, EventArgs e)
    {
        try
        {

            LinkButton lnkJobID = (LinkButton)sender;
            GridViewRow gvr = (GridViewRow)lnkJobID.NamingContainer;
            Session["JobID"] = ((HtmlGenericControl)gvr.FindControl("divJobID")).InnerText;

           // UpdateJobOwner(Convert.ToInt32(lnkJobID.ToolTip));

           // Request.Url.AbsoluteUri;
            Session["UrlRef"] = Request.Url.AbsoluteUri;
            Response.Redirect("~/JobOrder/DefaultGrid.aspx?JobID= " + Session["JobID"] + "", false);
                      
        }
        catch
        {

        }
    }   
    protected void lnkBtnJobJobID_Click(object sender, EventArgs e)
    {
        try
        {
            LinkButton lnkJobID = (LinkButton)sender;
            GridViewRow gvr = (GridViewRow)lnkJobID.NamingContainer;
            Session["JobID"] = ((HtmlGenericControl)gvr.FindControl("divJobID")).InnerText;
           // UpdateJobOwner(Convert.ToInt32(lnkJobID.ToolTip));
            Session["UrlRef"] = Request.Url.AbsoluteUri;
            Response.Redirect("~/JobOrder/DefaultGrid.aspx?JobID= " + Session["JobID"] + "", false);
        }
        catch
        {

        }
    }
    public void UpdateJobOwner(int jobInchargeID)
    {
        using (SqlConnection con = new SqlConnection(connValue))
        {
            using (SqlCommand cmd = new SqlCommand())
            {
                using (SqlCommand sqlCmd = new SqlCommand())
                {
                    sqlCmd.Connection = con;
                    sqlCmd.CommandType = CommandType.Text;
                    sqlCmd.CommandText = "UPDATE JobOwner SET dateRead =@jobReadDate where jobOwnerID = @jobOwnerID";

                    try
                    {
                        sqlCmd.Parameters.AddWithValue("@jobOwnerID", jobInchargeID);
                        sqlCmd.Parameters.AddWithValue("@jobReadDate", System.DateTime.Now.ToString("dd/MMM/yyyy"));
                        con.Open();
                        sqlCmd.ExecuteNonQuery();
                    }
                    catch (Exception ex)
                    {
                        throw ex;
                    }
                }
            }
        }        
    }
    //protected void lnkBtnNonCmtJobID_Click(object sender, EventArgs e)
    //{
    //    try
    //    {
    //        LinkButton lnkJobID = (LinkButton)sender;
    //        GridViewRow gvr = (GridViewRow)lnkJobID.NamingContainer;
    //        Session["ProjectCode"] = ((HtmlGenericControl)gvr.FindControl("divProjectCode")).InnerText;

    //        Session["UrlRef"] = Request.Url.AbsoluteUri;
    //        Response.Redirect("~/JobOrder/SearchJobMstr.aspx?Project_Code = " + Session["ProjectCode"] + "", false);

    //    }
    //    catch
    //    {

    //    }
    //}

     # endregion
}