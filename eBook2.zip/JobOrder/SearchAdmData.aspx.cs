﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using Datalayer;
using System.Globalization;
using System.Web.UI.HtmlControls;
using System.IO;
using System.Drawing;

public partial class JobOrder_SearchAdmData : System.Web.UI.Page
{
    string connValue = System.Configuration.ConfigurationManager.ConnectionStrings["EBSDEBookConn"].ConnectionString;
    string _prjCode = string.Empty; string flag = string.Empty;
    int jobType = 0;
    string _userName = string.Empty;
    IList<string> userRightsColl = new List<string>();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["UserName"] == null)
        {
            Response.Redirect("~/LoginPage.aspx", false);
            return;
        }

        userRightsColl = (IList<string>)Session["UserRightsColl"];

        if (!IsPostBack)
        {            
            //FillDropBox(Convert.ToInt32(Session["SectionID"]));
            tblSearch.Visible = false;
         
           // DataTable dt = FillTab2(1, _prjCode);

            DataTable dt = PartialSearchAddendumJobNo();             //FillTab2(1, _prjCode);
            grvPSA.DataSource = dt;
            grvPSA.DataBind();

            Session["PartialAdmData"] = dt;
            lblCnt.Text = dt.Rows.Count.ToString();                   
        }        
    }  
    protected void lnkJobOrderJobNo_Click(object sender, EventArgs e)     //ForCommitted
    {
        try
        {
            LinkButton lnkJobID = (LinkButton)sender;
            GridViewRow gvr = (GridViewRow)lnkJobID.NamingContainer;
            Session["JobID"] = ((HtmlGenericControl)gvr.FindControl("divJobID")).InnerText;
            Session["UrlRef"] = Request.Url.AbsoluteUri;          
            Response.Redirect("~/JobOrder/PSAJobDetails.aspx?JobID= " + Session["JobID"] + "", false);

        }
        catch
        {

        }
    }    
    public void FillDropBox(int _sectionID)
    {

     //   PopulateDropDownBox(ddlJobNo, "SELECT Job.jobID, Job.jobNo FROM Job INNER JOIN JobType ON Job.jobTypeID = JobType.jobTypeID WHERE (JobType.CategoryID IN (1)) ORDER BY Job.jobNo", "jobID", "jobNo");     
        PopulateDropDownBox(ddlJobType, "SELECT DISTINCT JobType.jobTypeID, JobType.jobTypeName FROM JobType INNER JOIN Job ON JobType.jobTypeID = Job.jobTypeID WHERE (JobType.CategoryID IN (1)) ORDER BY JobType.jobTypeName", "jobTypeID", "jobTypeName");
        
        PopulateDropDownBox(ddlJobStatus_, "SELECT jobStatusID, jobStatusName FROM JobStatus where jobStatusID not in(3) ORDER BY jobStatusName", "jobStatusID", "jobStatusName");
        string strDocQuery = "SELECT  [Document].documentID, [Document].referenceNo FROM  Job INNER JOIN  [Document] ON Job.docRefID = [Document].documentID INNER JOIN JobType ON Job.jobTypeID = JobType.jobTypeID  WHERE  (JobType.CategoryID IN (1)) ORDER BY [Document].referenceNo";
      
        //  PopulateDropDownBox(ddlDocRef, strDocQuery, "documentID", "referenceNo");

        PopulateDropDownBox(ddlAffair, "SELECT  departmentID, deptName FROM  Department WHERE (affairID IS NULL) ORDER BY deptName", "departmentID", "deptName");
        PopulateDropDownBox(ddlDept, "SELECT departmentID, deptName FROM  Department WHERE (affairID IS NOT NULL) ORDER BY deptName", "departmentID", "deptName");
        string strCntr = "SELECT DISTINCT Company.companyID, Company.cmpName FROM   Job INNER JOIN Company ON Job.contractorID = Company.companyID INNER JOIN JobType ON Job.jobTypeID = JobType.jobTypeID WHERE  (JobType.CategoryID IN (1)) ORDER BY Company.cmpName";
        PopulateDropDownBox(ddlVendor, strCntr, "companyID", "cmpName");

        PopulateDropDownBoxQS(ddlQS, "SELECT DISTINCT Contact.contactID, Contact.userShortName FROM  Contact INNER JOIN Job ON Contact.contactID = Job.qsID INNER JOIN JobType ON  Job.jobTypeID = JobType.jobTypeID WHERE (JobType.CategoryID in(1))  ORDER BY Contact.userShortName", "ContactID", "userShortName");
        PopulateDropDownBoxQS(ddlPE, "SELECT DISTINCT Contact.contactID, Contact.userShortName FROM  Contact INNER JOIN Job ON Contact.contactID = Job.peID INNER JOIN JobType ON  Job.jobTypeID = JobType.jobTypeID WHERE (JobType.CategoryID in(1))  ORDER BY Contact.userShortName", "ContactID", "userShortName");
        PopulateDropDownBoxQS(ddlCE, "SELECT DISTINCT Contact.contactID, Contact.userShortName FROM  Contact INNER JOIN Job ON Contact.contactID = Job.ceID INNER JOIN JobType ON  Job.jobTypeID = JobType.jobTypeID WHERE (JobType.CategoryID in(1))  ORDER BY Contact.userShortName", "ContactID", "userShortName");

     //   PopulateDropDownBox(ddlPrjCode, "SELECT DISTINCT Job.contractNo, Job.contractNo FROM job INNER JOIN JobType ON Job.jobTypeID = JobType.jobTypeID WHERE    (JobType.CategoryID IN (1)) ORDER BY Job.contractNo", "contractNo", "contractNo");
        
        //PopulateDropDownBox(ddlTeamLead, "SELECT teamLeaderID, teamLeaderName FROM EBSDTeamLeaders  ORDER BY teamLeaderName", "teamLeaderID", "teamLeaderName");        
    }
    protected void lnkBtnSearchAdm_Click(object sender, EventArgs e)
    {
        try
        {
            LinkButton lnkJobID = (LinkButton)sender;
            GridViewRow gvr = (GridViewRow)lnkJobID.NamingContainer;
            Session["ProjectCode"] = ((HtmlGenericControl)gvr.FindControl("divProjectCode")).InnerText;

            DataTable dt = ContractNoSearch(Session["ProjectCode"].ToString());             //FillTab2(1, _prjCode);
            grvPSA.DataSource = dt;
            grvPSA.DataBind();

            Session["PartialAdmData"] = dt;
            lblCnt.Text = dt.Rows.Count.ToString();  

           // Session["UrlRef"] = Request.Url.AbsoluteUri;
           // Response.Redirect("~/JobOrder/AddendumForm.aspx?Project_Code = " + Session["ProjectCode"] + "", false);

        }
        catch
        {

        }       
    }
    protected void btnSearch_Click(object sender, EventArgs e)
    {
        Session["OnGoingJobStatus"] = null; // Just making when u click on graph and go to search job page

        DataTable dt = GetAdvancedAdmData(0, "");     // SearchAdmJobByDates
        Session["PartialAdmData"] = dt;
        grvPSA.DataSource = dt;
        grvPSA.DataBind();

        lblCnt.Text = dt.Rows.Count.ToString();
    }
    private void PopulateDropDownBox(DropDownList ddlBox, string sqlQuery, string valueMember, string displayName)
    {       
        ddlBox.DataSource = new JobOrderData().FillDropdown(sqlQuery);
        ddlBox.DataTextField = displayName;
        ddlBox.DataValueField = valueMember;
        ddlBox.SelectedIndex = -1;
        ddlBox.DataBind();
        ListItem emptyItem = new ListItem("", "");
        ddlBox.Items.Insert(0, emptyItem);
    }  
    private void PopulateDropDownBox_TCMS(DropDownList ddlBox, string sqlQuery, string valueMember, string displayName)
    {
        ddlBox.DataSource = new JobOrderData().FillDropdown_TCMS(sqlQuery);
        ddlBox.DataTextField = displayName;
        ddlBox.DataValueField = valueMember;
        ddlBox.SelectedIndex = -1;
        ddlBox.DataBind();
    }
    private DataTable GetAdvancedAdmData(int searchType, string _prjCode)
    {
        DataSet ds = new DataSet();
        try
        {
            //Int32 jobid;
            //Int32.TryParse(ddlJobNo.SelectedValue, out jobid);

            Int32 afrID;
            Int32.TryParse(ddlAffair.SelectedValue, out afrID);

            Int32 dptID;
            Int32.TryParse(ddlDept.SelectedValue, out dptID);

            Int32 consID;
            Int32.TryParse(ddlVendor.SelectedValue, out consID);

            Int32 jobType;
            Int32.TryParse(ddlJobType.SelectedValue, out jobType);

            Int32 jobStatus;
            Int32.TryParse(ddlJobStatus_.SelectedValue, out jobStatus);

            //Int32 docRefID;
            //Int32.TryParse(ddlDocRef.SelectedValue, out docRefID);

            Int32 qsID;
            if (ddlQS.SelectedValue != "ALL")
                Int32.TryParse(ddlQS.SelectedValue, out qsID);
            else
            {
                qsID = -1;
                Int32.TryParse(qsID.ToString(), out qsID);
            }

            Int32 ceID;
            if (ddlCE.SelectedValue != "ALL")
                Int32.TryParse(ddlCE.SelectedValue, out ceID);
            else
            {
                ceID = -1;
                Int32.TryParse(ceID.ToString(), out ceID);
            }

            Int32 peID;
            if (ddlPE.SelectedValue != "ALL")
                Int32.TryParse(ddlPE.SelectedValue, out peID);
            else
            {
                peID = -1;
                Int32.TryParse(peID.ToString(), out peID);
            }

            string prjTitle = string.Empty;


            if (txtTitle.Text != "")
                prjTitle = "%" + txtTitle.Text + "%";

            Int32 cntrID;
            Int32.TryParse(ddlVendor.SelectedValue, out cntrID);

            Int32 consultID;
            Int32.TryParse(ddlVendor.SelectedValue, out consultID);

            string prjCode = string.Empty;

            //if (_prjCode != "")
            //{
            //    ddlPrjCode.SelectedItem.Text = _prjCode;
            //    prjCode = _prjCode;
            //}
            //else
            //    prjCode = ddlPrjCode.SelectedItem.Text;           

            string txtfrom = string.Empty;
            if (txtdept.Text != "")
                txtfrom = txtdept.Text;

             string docSubject = string.Empty;
            //if (txtSubject.Text != "")
            //    docSubject = "%" + txtSubject.Text + "%";

            
             string txtTo = string.Empty;
             if (txtToDate.Text != "")
                 txtTo = txtToDate.Text;

             //Int16 leadID;
             //Int16.TryParse(ddlTeamLead.SelectedValue, out leadID);


             //Int16 teamMemID;
             //Int16.TryParse(ddlTeamMember.SelectedValue, out teamMemID);

            // ds = (new JobOrderData().GetPSADetails(searchType, jobid, jobType, jobStatus, afrID, dptID, docRefID, qsID, peID, ceID, prjTitle, cntrID, consultID, prjCode, txtfrom, docSubject, txtTo, leadID, teamMemID));

             ds = (new JobOrderData().GetAllPSADetails(searchType, jobType, jobStatus, afrID, dptID, qsID, peID, ceID, prjTitle, consultID, txtfrom, txtTo));      

        }
        catch (Exception ex)
        {
            throw ex;
        }
        return ds.Tables[0];
    }
    private void bindGridView()
    {
        grvPSA.DataSource = Session["CommittedInfo"];
        grvPSA.DataBind();
    }
    protected void btnClear_Click(object sender, EventArgs e)
    {

        if (tblSearch.Visible == true)
        {
            ddlJobType.SelectedIndex = 0;
            ddlJobStatus_.SelectedIndex = 0;
            ddlAffair.SelectedIndex = 0;
            ddlDept.SelectedIndex = 0;
            ddlVendor.SelectedIndex = 0;
            ddlQS.SelectedIndex = 0;
            ddlPE.SelectedIndex = 0;
            ddlCE.SelectedIndex = 0;
        }
        else
        {
            ddlJobType.SelectedIndex = -1;
            ddlJobStatus_.SelectedIndex = -1;
            ddlAffair.SelectedIndex = -1;
            ddlDept.SelectedIndex = -1;
            ddlVendor.SelectedIndex = -1;
            ddlQS.SelectedIndex = -1;
            ddlPE.SelectedIndex = -1;
            ddlCE.SelectedIndex = -1;
        }

        txtTitle.Text = "";   
        txtdept.Text = "";
     
        Session["ProjectCode"] = null;

        txtJobNo.Text = "";
        txtDocRefNo.Text = "";
        txtPrjNo.Text = "";
        txtClsDocRefNo.Text = "";
        txtToDate.Text = "";

        DataTable dt = PartialSearchAddendumJobNo();
        Session["PartialAdmData"] = dt;
        grvPSA.DataSource = dt;
        grvPSA.DataBind();
        lblCnt.Text = dt.Rows.Count.ToString();
    }
    
    private void AccessRightsForReply()
    {
        if (userRightsColl.Contains("9"))   //Add New Project
        {
            Session["lblText"] = "You are not allowed to directly Reply and Close a Job Order.Please contact system Administrator for further inquiry.";
            Session["lblSub"] = "Restricted Access to Reply and Close a Job Order.";
            Session["lblBody"] = "This is in reference to Restricted Access to Reply and Close a Job Order. I would like to inquire about the restriction.";
            
            string url = "RestrictedMsgWindow.aspx";
            string s = "window.open('" + url + "', 'popup_window', 'width=500,height=250,left=100,top=100,resizable=yes,scrollbars=yes');";
            ClientScript.RegisterStartupScript(this.GetType(), "script", s, true);
        }
    }
    protected void grvPSA_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandArgument != "")
        {
            int jobid = Convert.ToInt32(e.CommandArgument);
            switch (e.CommandName)
            {
                case "EditJobid":                   

                    break;

                case "DeleteJobid":

                     AccessRightsForDelete();

                     if (!userRightsColl.Contains("3"))
                     {

                         int flag = (new JobOrderData().DeleteJobOrder(jobid));
                         new JobOrderData().DeactivateDocumentForJobDelete(jobid);

                         new JobOrderData().UpdateIsConfirmFalseOnJobDelete(jobid);

                         if (flag > 0)
                         {
                             // Response.Write("deleted");
                         }
                     }
                    break;
            }
        }
    }
    private void AccessRightsForDelete()
    {
        IList<string> userRightsColl = (IList<string>)Session["UserRightsColl"];
        if (userRightsColl.Contains("3"))   //Add New Project
        {
            Session["lblText"] = "You are not allowed to delete a Job Order.Please contact system Administrator for further inquiry.";
            Session["lblSub"] = "Restricted Access to delete a Job Order.";
            Session["lblBody"] = "This is in reference to Restricted Access to delete a Job Order. I would like to inquire about the restriction.";


            string url = "RestrictedMsgWindow.aspx";
            string s = "window.open('" + url + "', 'popup_window', 'width=500,height=250,left=100,top=100,resizable=yes,scrollbars=yes');";
            ClientScript.RegisterStartupScript(this.GetType(), "script", s, true);
        }
    }    
    protected void  grvPSA_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            Label qs = (Label)e.Row.FindControl("lblQS");
            Label ce = (Label)e.Row.FindControl("lblCE");
            Label pe = (Label)e.Row.FindControl("lblPE");
            Label dc = (Label)e.Row.FindControl("lblDC");

            Label jobNo = (Label)e.Row.FindControl("lblJobNo");

            Label lblJobRecDate = (Label)e.Row.FindControl("lblPsaRecDate");
            Label lblJobStatus = (Label)e.Row.FindControl("lblJobStatus");        


            if ((lblJobRecDate.Text != "") & (lblJobStatus.Text.Equals("Under Process with EBSD")))
            {
                string elapsedDays = new JobOrderData().getDaysByGivenEndDate(lblJobRecDate.Text, System.DateTime.Now.ToString());
                Label WorkDays = (Label)e.Row.FindControl("lblDays");
                int extraDays = Convert.ToInt32(WorkDays.Text);
                extraDays = (extraDays / 2);
                int totalDays = Convert.ToInt32(WorkDays.Text) + extraDays;
                if (totalDays < Convert.ToInt32(elapsedDays))
                {
                    e.Row.BackColor = System.Drawing.Color.LightPink;
                    e.Row.ForeColor = System.Drawing.Color.Red;
                    e.Row.Font.Bold = true;

                    jobNo.BackColor = System.Drawing.Color.Yellow;
                    e.Row.Cells[1].BackColor = System.Drawing.Color.White;
                }
                else if (Convert.ToInt32(WorkDays.Text) < Convert.ToInt32(elapsedDays))
                {
                    e.Row.BackColor = System.Drawing.Color.MistyRose;

                    jobNo.BackColor = System.Drawing.Color.Yellow;
                    e.Row.Cells[1].BackColor = System.Drawing.Color.White;
                }
            }
            string JobOrderstatus = lblJobStatus.Text;
            if ((JobOrderstatus.Trim() == "Closed") || (JobOrderstatus == "Cancelled") || (JobOrderstatus == "Completed"))
            {

            }
            else
            {
                string strQS = qs.Text; string strCE = ce.Text; string strPE = pe.Text;

                if ((strQS == "") & (strPE == "") & (strCE == ""))
                {
                    jobNo.BackColor = System.Drawing.Color.Red;
                    e.Row.Cells[1].BackColor = System.Drawing.Color.Red;
                   // Label1.Visible = true;
                }

                LinkButton l = (LinkButton)e.Row.FindControl("btnDelete");
                l.Attributes.Add("onclick", "javascript:return " + "confirm('Are you sure you want to delete this Job')");
                l.CssClass = "btndelete";
                //l.Attributes.Add("CssClass", "btnSearch");    
            }
        }
       
    }
    protected void  grvPSA_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        grvPSA.PageIndex = e.NewPageIndex;
        grvPSA.DataSource = Session["PartialAdmData"];
        grvPSA.DataBind();         
    }
   
    protected void OpenWindow(object sender, EventArgs e)
    {
         IList<string> userRightsColl  = (IList<string>)Session["UserRightsColl"];
        if (userRightsColl.Contains("2"))   //Add New Project
        {
            Session["lblText"] = "You are not allowed to Add New Job Order.Please contact system Administrator for further inquiry.";
            Session["lblSub"] = "Restricted Access to Add New Job Order.";
            Session["lblBody"] = "This is in reference to Restricted Access to Add New Job Order. I would like to inquire about the restriction.";


            string url = "RestrictedMsgWindow.aspx";
            string s = "window.open('" + url + "', 'popup_window', 'width=500,height=250,left=100,top=100,resizable=yes,scrollbars=yes');";
            ClientScript.RegisterStartupScript(this.GetType(), "script", s, true);
            
        }
        else if (Session["SectionID"].ToString().Equals("2"))
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "Popup", "<script>alert('This is not applicable to all employees from EBSD Payment Section.')</script>", false);
            return;
        }
        else
        {
            string url = "JobEntryForm.aspx";
            string s = "window.open('" + url + "', 'popup_window', 'width=990,height=700,left=100,top=100,resizable=yes,scrollbars=yes');";
            ClientScript.RegisterStartupScript(this.GetType(), "script", s, true);
        }
    }
    protected void OpenOverDueWindow(object sender, EventArgs e)
    {
       // if (!userRightsColl.Contains("16"))  
        
            if (FillOverDueAdmData() == true)
            {
                string url123 = "OverDueAddendum.aspx";   // OverDueAddendum.aspx               //OverDueJobs
                string s123 = "window.open('" + url123 + "', 'popup_window123', 'width=800,height=600,left=100,top=100,resizable=yes,scrollbars=0');";
                ClientScript.RegisterStartupScript(this.GetType(), "script", s123, true);
            }
        
    }
    private Boolean FillOverDueAdmData()
    {
        string sqlQuery = "SELECT Job.jobNo, JobStatus.jobStatusName, Job.contractNo, Job.addendumNO, JobAddendumInfo.AlertReminderMsg FROM jobAddendumInfo INNER JOIN   Job ON JobAddendumInfo.jobID = Job.jobID INNER JOIN " +
                       "  JobStatus ON Job.jobStatusID = JobStatus.jobStatusID WHERE (JobAddendumInfo.AlertDate <= GETDATE() AND JobAddendumInfo.AlertDate IS NOT NULL)";

        SqlConnection objCon = new SqlConnection(connValue);
        SqlCommand objCmd = new SqlCommand(sqlQuery, objCon);
        SqlDataAdapter objDA = new SqlDataAdapter(objCmd);

        objDA.SelectCommand.CommandText = objCmd.CommandText.ToString();
        DataTable dt = new DataTable();
        objDA.Fill(dt);

        if (dt.Rows.Count > 0)
            return true;
        else
            return false;
    }
    protected void btnBack_Click(object sender, EventArgs e)
    {
        if (Session["UrlRef"] != null)  
            Response.Redirect(Session["UrlRef"].ToString(), false);
        else
            Response.Redirect("~/JobOrder/JobOrder.aspx", false);
    }
    protected void btnPrint_Click(object sender, EventArgs e)
    {
        IList<string> userRightsColl = (IList<string>)Session["UserRightsColl"];
        if ((userRightsColl.Count == 0) || (!userRightsColl.Contains("2")))
        {
            try
            {
                ScriptManager.RegisterStartupScript(this, typeof(Page), "printGrid", "printGrid();", true);
            }
            catch { }
        }
    }
    protected void txtJobNo_TextChanged(object sender, EventArgs e)
    {
        Session["OnGoingJobStatus"] = null;

        DataTable dt = new DataTable();
        //dt = FillTabByAddendumJobNo(0, "");


        dt = PartialSearchAddendumJobNo();
        Session["PartialAdmData"] = dt;

        grvPSA.DataSource = dt;
        grvPSA.DataBind();

        lblCnt.Text = dt.Rows.Count.ToString();
    }
    private DataTable PartialSearchAddendumJobNo()
    {
        DataSet ds = new DataSet();
        try
        {
            string _jobNo = string.Empty;
            if (txtJobNo.Text != "")
                _jobNo = "%" + txtJobNo.Text + "%";

            string _refNo = string.Empty;
            if (txtDocRefNo.Text != "")
                _refNo = "%" + txtDocRefNo.Text + "%";

            string _contractNo = string.Empty;
            if (txtPrjNo.Text != "")
                _contractNo = "%" + txtPrjNo.Text + "%";

            string _clsrefNo = string.Empty;
            if (txtClsDocRefNo.Text != "")
                _clsrefNo = "%" + txtClsDocRefNo.Text + "%";


            ds = (new JobOrderData().PartialSearchAddendumDatastring(_jobNo, _refNo, _contractNo, _clsrefNo));

        }
        catch (Exception ex)
        {

        }
        return ds.Tables[0];
    }
    private DataTable ContractNoSearch(string _contractNo)
    {
        DataSet ds = new DataSet();
        try
        {

           // string _contractNo = string.Empty;
            //if (txtPrjNo.Text != "")
            //    _contractNo = "" + txtPrjNo.Text + "";

            ds = (new JobOrderData().ContractNoSearchAddendumDatastring(_contractNo));

        }
        catch (Exception ex)
        {

        }

        return ds.Tables[0];
    }
    //private DataTable FillTabByAddendumJobNo(int searchType, string _prjCode)
    //{
    //    DataSet ds = new DataSet();
    //    try
    //    {
    //        //Int32 jobid;
    //        //Int32.TryParse(ddlJobNo.SelectedValue, out jobid);

    //        Int32 afrID;
    //        Int32.TryParse(ddlAffair.SelectedValue, out afrID);

    //        Int32 dptID;
    //        Int32.TryParse(ddlDept.SelectedValue, out dptID);

    //        Int32 consID;
    //        Int32.TryParse(ddlVendor.SelectedValue, out consID);

    //        Int32 jobType;
    //        Int32.TryParse(ddlJobType.SelectedValue, out jobType);

    //        Int32 jobStatus;
    //        Int32.TryParse(ddlJobStatus_.SelectedValue, out jobStatus);

    //        //Int32 docRefID;
    //        //Int32.TryParse(ddlDocRef.SelectedValue, out docRefID);


    //        // added new as temp
    //        int k = 0;
    //        Int32 docClsRefID;
    //        Int32.TryParse(k.ToString(), out docClsRefID);

    //        //Int32 qsID;
    //        //Int32.TryParse(ddlQS.SelectedValue, out qsID);

    //        //Int32 ceID;
    //        //Int32.TryParse(ddlCE.SelectedValue, out ceID);

    //        //Int32 peID;
    //        //Int32.TryParse(ddlPE.SelectedValue, out peID);

    //        string prjTitle = string.Empty;


    //        if (txtTitle.Text != "")
    //            prjTitle = "%" + txtTitle.Text + "%";

    //        Int32 cntrID;
    //        Int32.TryParse(ddlVendor.SelectedValue, out cntrID);

    //        Int32 consultID;
    //        Int32.TryParse(ddlVendor.SelectedValue, out consultID);

    //        string prjCode = string.Empty;

    //        //if (_prjCode != "")
    //        //{
    //        //    ddlPrjCode.SelectedItem.Text = _prjCode;
    //        //    prjCode = _prjCode;
    //        //}
    //        //else
    //        //    prjCode = ddlPrjCode.SelectedItem.Text;

    //        string txtfrom = string.Empty;
    //        if (txtdept.Text != "")
    //            txtfrom = txtdept.Text;

    //        //string docSubject = string.Empty;
    //        //if (txtSubject.Text != "")
    //        //    docSubject = "%" + txtSubject.Text + "%";


    //        Int32 qsID;
    //        if (ddlQS.SelectedValue != "ALL")
    //            Int32.TryParse(ddlQS.SelectedValue, out qsID);
    //        else
    //        {
    //            qsID = -1;
    //            Int32.TryParse(qsID.ToString(), out qsID);
    //        }

    //        Int32 ceID;
    //        if (ddlCE.SelectedValue != "ALL")
    //            Int32.TryParse(ddlCE.SelectedValue, out ceID);
    //        else
    //        {
    //            ceID = -1;
    //            Int32.TryParse(ceID.ToString(), out ceID);
    //        }

    //        Int32 peID;
    //        if (ddlPE.SelectedValue != "ALL")
    //            Int32.TryParse(ddlPE.SelectedValue, out peID);
    //        else
    //        {
    //            peID = -1;
    //            Int32.TryParse(peID.ToString(), out peID);
    //        }

    //        string _jobNo = string.Empty;
    //        if (txtJobNo.Text != "")
    //            _jobNo = "%" + txtJobNo.Text + "%";

    //        string _refNo = string.Empty;
    //        if (txtDocRefNo.Text != "")
    //            _refNo = "%" + txtDocRefNo.Text + "%";

    //        string _contractNo = string.Empty;
    //        if (txtPrjNo.Text != "")
    //            _contractNo = "%" + txtPrjNo.Text + "%";

    //        string _clsrefNo = string.Empty;
    //        if (txtClsDocRefNo.Text != "")
    //            _clsrefNo = "%" + txtClsDocRefNo.Text + "%";


    //        string txtTo = string.Empty;
    //        if (txtToDate.Text != "")
    //            txtTo = txtToDate.Text;

    //        //Int16 leadID;
    //        //Int16.TryParse(ddlTeamLead.SelectedValue, out leadID);


    //        //Int16 teamMemID;
    //        //Int16.TryParse(ddlTeamMember.SelectedValue, out teamMemID);

    //        //   ds = (new JobOrderData().GetPSADetails(searchType, jobid, jobType, jobStatus, afrID, dptID, docRefID, qsID, peID, ceID, prjTitle, cntrID, consultID, prjCode, txtfrom, docSubject));


    //        // Sp Name SearchAdmJobByJobNo

    //      //  ds = (new JobOrderData().GetAddendumDetailsByJobNo(searchType, jobid, jobType, jobStatus, afrID, dptID, docRefID, qsID, ceID, peID, prjTitle, cntrID, consultID, prjCode, txtfrom, docSubject, docClsRefID, _jobNo, _refNo, _contractNo, _clsrefNo));

    //        ds = (new JobOrderData().GetAddendumDetailsByJobNo(searchType, jobType, jobStatus, afrID, dptID, qsID, ceID, peID, prjTitle, consultID, txtfrom, txtTo, leadID, teamMemID, _jobNo, _refNo, _contractNo, _clsrefNo));

    //    }
    //    catch (Exception ex)
    //    {

    //    }

    //    return ds.Tables[0];
    //}

    private void PopulateDropDownBoxQS(DropDownList ddlBox, string sqlQuery, string valueMember, string displayName)
    {

        ddlBox.DataSource = new JobOrderData().FillDropdown(sqlQuery);
        ddlBox.DataTextField = displayName;
        ddlBox.DataValueField = valueMember;
        ddlBox.SelectedIndex = -1;
        ddlBox.DataBind();


        ListItem emptyItem123 = new ListItem("ALL", "ALL");
        ddlBox.Items.Insert(0, emptyItem123);

        ListItem emptyItem = new ListItem("", "");
        ddlBox.Items.Insert(0, emptyItem);

    }
    //protected void ddlTeamLead_SelectedIndexChanged(object sender, EventArgs e)
    //{
    //    if (ddlTeamLead.SelectedIndex!=0)
    //     {
    //          ddlTeamMember.DataSource = null;
    //             PopulateDropDownBox(ddlTeamMember, "SELECT contactID, userShortName FROM contact where teamLeaderID = " + ddlTeamLead.SelectedValue + " ORDER BY userShortName", "contactID", "userShortName");
    //     }
    //}
    protected void lnkAdvSearch_Click(object sender, EventArgs e)
    {
        tblSearch.Visible = true;
        FillDropBox(Convert.ToInt32(Session["SectionID"]));
        GetAdvancedAdmData(1, "");
    }


    #region SearchAdmNote:-

    //  SpName -1 is PartialSearchAdmJobs

    // This sp will excute while loading data with jobno,docno and contract no

   

    //  SpName -2 is SearchAdmJobByDates

    // This sp will excute while fire when user looking for advance search like from date ,to date and status,type and Department search

    #endregion
    protected void btnOverdue_Click(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        ExportToExcel_Sree();
    }

    protected void lnkCostVOSILog_Click(object sender, EventArgs e)
    {
        try
        {
            LinkButton lnkcostVoLog = (LinkButton)sender;
            GridViewRow gvr = (GridViewRow)lnkcostVoLog.NamingContainer;

            Session["divCatID"] = ((HtmlGenericControl)gvr.FindControl("divCatID")).InnerText;
            Session["divProjectCodeCmted"] = ((HtmlGenericControl)gvr.FindControl("divProjectCode")).InnerText;  //divProjectCodeCmted
            Session["divJobID"] = ((HtmlGenericControl)gvr.FindControl("divJobID")).InnerText;
            Session["divJobNo"] = ((HtmlGenericControl)gvr.FindControl("divJobNo")).InnerText;

            Session["UrlRef"] = Request.Url.AbsoluteUri;
            if (Session["divCatID"].ToString().Equals("4") || Session["divCatID"].ToString().Equals("7"))
            {
                if (Session["userProfileID"].ToString().Equals("1") || Session["userProfileID"].ToString().Equals("2") || (getJobAccessStaff(Convert.ToInt32(Session["divJobID"])) == true))
                {
                    UtilityClass utils = null;
                    try
                    {
                        utils = new UtilityClass(this.Page);
                        string url = Request.Url.AbsoluteUri;
                        Session["Url"] = Request.Url.AbsoluteUri;
                        if (url.Contains(":"))
                            url = url.Substring(0, utils.GetNthIndex(url, '/', 4));
                        else
                            url = url.Substring(0, utils.GetNthIndex(url, '/', 2));

                        url = url + "/JobOrder/CostVOSILog.aspx?PSAprjCode=" + Session["divProjectCodeCmted"] + "&JobID= " + Session["divJobID"] + "&PSAJobNo= " + Session["divJobNo"] + "";

                        OpenPageByUsingJS(url, "850", "850");
                    }
                    catch (Exception ex)
                    {
                        this.Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Error occurred while processing the request')</script>", false);
                    }
                }
                else
                {
                    this.Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('You dont have rights to view VO/SI Log.')</script>", false);
                }
            }
            else
            {
                UtilityClass utils = null;
                try
                {
                    Response.Redirect("~/JobOrder/JobOrderVOSILog.aspx?PSAprjCode=" + Session["divProjectCodeCmted"] + "&JobID= " + Session["divJobID"] + "&PSAJobNo= " + Session["divJobNo"] + "", false);
                }
                catch (Exception ex)
                {
                    this.Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Error occurred while processing the request')</script>", false);
                }
            }
        }
        catch
        {

        }
    }

    private void OpenPageByUsingJS(string url, string width, string height)
    {
        string s = "window.open('" + url + "', 'popup_window', 'width=" + width + ",height=" + height + "left=100,top=100,resizable=yes');";
        Page.ClientScript.RegisterStartupScript(this.GetType(), "script", s, true);
    }

    private Boolean getJobAccessStaff(int _jobID)
    {
        Boolean chkStaffExist = false;
        SqlConnection cnn = new SqlConnection(connValue);
        cnn.Open();
        SqlCommand cmm = new SqlCommand();
        cmm.Connection = cnn;
        cmm.CommandText = "SELECT contactID FROM Jobowner WHERE (jobID = " + _jobID + ")"; //open n Follwup
        SqlDataReader sqlDtReader = cmm.ExecuteReader();
        if (sqlDtReader.HasRows)
        {
            while (sqlDtReader.Read())
            {
                if (Session["UserID"].ToString().Equals(sqlDtReader["contactID"].ToString()))
                {
                    chkStaffExist = true;
                }

            }
        }

        sqlDtReader.Close();
        cnn.Close();
        return chkStaffExist;
    }

    #region MyRegion

    private void ExportToExcel_Sree()
    {
        Response.Clear();
        Response.Buffer = true;
        Response.AddHeader("content-disposition", "attachment;filename=GridViewExport.xls");
        Response.Charset = "";
        Response.ContentType = "application/vnd.ms-excel";
        using (StringWriter sw = new StringWriter())
        {
            HtmlTextWriter hw = new HtmlTextWriter(sw);

            //To Export all pages
            grvPSA.AllowPaging = false;

            grvPSA.DataSource = Session["PartialAdmData"]; //Session["PartialAdmData"]
            grvPSA.DataBind();

            grvPSA.HeaderRow.BackColor = Color.White;
            foreach (TableCell cell in grvPSA.HeaderRow.Cells)
            {
                cell.BackColor = grvPSA.HeaderStyle.BackColor;
            }
            foreach (GridViewRow row in grvPSA.Rows)
            {
                row.BackColor = Color.White;
                foreach (TableCell cell in row.Cells)
                {
                    if (row.RowIndex % 2 == 0)
                    {
                        cell.BackColor = grvPSA.AlternatingRowStyle.BackColor;
                    }
                    else
                    {
                        cell.BackColor = grvPSA.RowStyle.BackColor;
                    }
                    cell.CssClass = "textmode";
                }
            }

            grvPSA.RenderControl(hw);

            //style to format numbers to string
            string style = @"<style> .textmode { } </style>";
            Response.Write(style);
            Response.Output.Write(sw.ToString());
            Response.Flush();
            Response.End();
        }
    }
    public override void VerifyRenderingInServerForm(Control control)
    {
        /* Verifies that the control is rendered */
    }

    #endregion
}