﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using Datalayer;
using System.Drawing;
using System.Data.SqlClient;
using System.Threading;
public partial class Test_Default : System.Web.UI.Page
{
    int _jobID = 0; int _jobVOID = 0;
    string connValue = System.Configuration.ConfigurationManager.ConnectionStrings["EBSDEBookConn"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
    {
        _jobID = Convert.ToInt32(Request.QueryString["JobID"]); 
        _jobVOID = Convert.ToInt32(Request.QueryString["jobVOID"]);

        Session["StakjobID"] = Convert.ToInt32(Request.QueryString["JobID"]);
        txtJobNo.Text = Request.QueryString["PSAJobNo"];

        //PSAprjCode
        Session["JobNo"] = Request.QueryString["PSAJobNo"];
        Session["PrjCode"] = Request.QueryString["PSAprjCode"];

        //PSAprjCode
        //PSAprjCode
        //lblJobNo.Text = Request.QueryString["JobNo"];
        //lblAbmNo.Text = Request.QueryString["AdndmNO"];

        if (!IsPostBack)
        {
            FillTab2();
        }
    }
    private void FillTab2()
    {
        try
        {
            DataSet ds = new DataSet();
            ds = (new JobOrderData().GetDDlDetails_JOBVOSI(_jobID));

            //   Convert.ToInt32(txtjobid.Text), txtJobNo.Text, Convert.ToInt32(txtaffair.Text), Convert.ToInt32(txtdept.Text), txtprojcode.Text, txtprojtitle.Text, Convert.ToInt32(txtconsult.Text)));

            if (ds.Tables[0].Rows.Count == 0)
            {
                ds.Tables[0].Rows.Add(ds.Tables[0].NewRow());
            }
           

                gvDetails.DataSource = ds;
                gvDetails.DataBind();
            
        }
        catch (Exception ex)
        {

        }
    }
    protected void LinkButton_Click(Object sender, EventArgs e)
    {
        //string url = "~/JobOrder/StakeHolder.aspx";
        // string url = "StakeHolder.aspx?jobVOID = <%#Eval(jobVOID)%>";  //subject=<%#Eval("Address") %>"   //jobID
        
        LinkButton txtBox = (sender as LinkButton);
        Session["txtName"] = txtBox.ClientID;
       // Session["txtValue"] = (sender as TextBox).Text;
        Session["JobAdmID"] = txtBox.ToolTip;
        Session["JobNo"] = txtJobNo.Text;

        string url = "StakeHolder.aspx?jobVOID123 = <%#Eval(jobVOID)%>";
        string s = "window.open('" + url + "', 'popup_window', 'width=600,height=600,left=100,top=100,resizable=yes');";
        ClientScript.RegisterStartupScript(this.GetType(), "script", s, true);

        // <a href='PSALog.aspx?JobID=<%#Eval("jobID")%>' onclick="openwindowPSALOG(this.href); return false;" style="color: #0000FF"> View Details </a>
    }



    protected void gvDetails_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
    {

    }
    protected void gvDetails_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        double _cntrAmt = 0; double _pmcAmt = 0; double _ebsdAmt = 0; double _consultAmt = 0; ;
        int _cntrTime = 0; int _pmcTime = 0; int _ebsdTime = 0; int _consultTime = 0;

        string _cntrVO = string.Empty; string _cntrSI = string.Empty;       
        string _cntrIssueDate = string.Empty; string _cntrPrjIssueDate = string.Empty;

        if (e.CommandName.Equals("AddNew"))
        {
            TextBox cntrVO = (TextBox)gvDetails.FooterRow.FindControl("txtVO_");
            if (cntrVO.Text != "")
                _cntrVO = cntrVO.Text;

            TextBox cntrSI = (TextBox)gvDetails.FooterRow.FindControl("txtSI_");
            if (cntrSI.Text != "")
                _cntrSI = cntrSI.Text;

            TextBox cntrIssueDate = (TextBox)gvDetails.FooterRow.FindControl("txtIssueDate_");
            if (cntrIssueDate.Text != "")
                _cntrIssueDate = cntrIssueDate.Text;

            TextBox cntrPrjIssueDate = (TextBox)gvDetails.FooterRow.FindControl("txtPrjIssueDate_");
            if (cntrPrjIssueDate.Text != "")
                _cntrPrjIssueDate = cntrPrjIssueDate.Text;

            TextBox cntrAmt = (TextBox)gvDetails.FooterRow.FindControl("txtft");
            if (cntrAmt.Text != "")
                _cntrAmt = Convert.ToDouble(cntrAmt.Text);

            TextBox cntrTime = (TextBox)gvDetails.FooterRow.FindControl("txtCntrEOT_");
            if (cntrTime.Text != "")
                _cntrTime = Convert.ToInt32(cntrTime.Text);

            TextBox pmcAmt = (TextBox)gvDetails.FooterRow.FindControl("txtPmcAmt_");
            if (pmcAmt.Text != "")
                _pmcAmt = Convert.ToDouble(pmcAmt.Text);

            TextBox pmcTime = (TextBox)gvDetails.FooterRow.FindControl("txtPmcEOT_");
            if (pmcTime.Text != "")
                _pmcTime = Convert.ToInt32(pmcTime.Text);

            TextBox ebsdAmt = (TextBox)gvDetails.FooterRow.FindControl("txtEbsdAmt_");
            if (ebsdAmt.Text != "")
                _ebsdAmt = Convert.ToDouble(ebsdAmt.Text);

            TextBox ebsdTime = (TextBox)gvDetails.FooterRow.FindControl("txtEbsdEOT_");
            if (ebsdTime.Text != "")
                _ebsdTime = Convert.ToInt32(ebsdTime.Text);

            TextBox consultAmt = (TextBox)gvDetails.FooterRow.FindControl("txtConsultAmt_");
            if (consultAmt.Text != "")
                _consultAmt = Convert.ToDouble(consultAmt.Text);

            TextBox consultTime = (TextBox)gvDetails.FooterRow.FindControl("txtConsultEOT_");
            if (consultTime.Text != "")
                _consultTime = Convert.ToInt32(consultTime.Text);


            new JobOrderData().Add_JOBVOandSI(0, _jobID, _cntrAmt, _cntrTime, _pmcAmt, _pmcTime, _ebsdAmt, _ebsdTime, _consultAmt, _consultTime, _cntrVO, _cntrSI, _cntrIssueDate, _cntrPrjIssueDate);
            
            FillTab2();
            lblresult.ForeColor = Color.Green;
        }
    }   
    protected void gvDetails_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        GridViewRow gr = (GridViewRow)gvDetails.Rows[e.RowIndex];

        Label txtid = (Label)gr.FindControl("JobVOID");
        // TextBox txtcr = (TextBox)gr.FindControl("lbldate");

        new JobOrderData().Delete_jobVOSI(Convert.ToInt32(txtid.Text));

        //if (result == 1)
        //{
        //    BindEmployeeDetails();
        lblresult.ForeColor = Color.Red;
        lblresult.Text = " details deleted successfully";
        FillTab2();
        //}

    }
    protected void gvDetails_RowEditing(object sender, GridViewEditEventArgs e)
    {
        gvDetails.EditIndex = e.NewEditIndex;
        FillTab2();
    }
    protected void gvDetails_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        double _cntrAmt = 0; double _pmcAmt = 0; double _ebsdAmt = 0; double _consultAmt = 0; ;
        int _cntrTime = 0; int _pmcTime = 0; int _ebsdTime = 0; int _consultTime = 0;
        string _cntrVO = string.Empty; string _cntrSI = string.Empty; string _cntrIssueDate = string.Empty; string _cntrPrjIssueDate = string.Empty;

        GridViewRow gr = (GridViewRow)gvDetails.Rows[e.RowIndex];

        TextBox cntrVO = (TextBox)gr.FindControl("txtVO");
        if (cntrVO.Text != "")
            _cntrVO = cntrVO.Text;

        TextBox cntrSI = (TextBox)gr.FindControl("txtSI");
        if (cntrSI.Text != "")
            _cntrSI = cntrSI.Text;

        TextBox cntrIssueDate = (TextBox)gr.FindControl("txtIssueDate");
        if (cntrIssueDate.Text != "")
            _cntrIssueDate = cntrIssueDate.Text;

        TextBox cntrPrjIssueDate = (TextBox)gr.FindControl("txtPrjIssueDate");
        if (cntrPrjIssueDate.Text != "")
            _cntrPrjIssueDate = cntrPrjIssueDate.Text;


        TextBox cntrAmt = (TextBox)gr.FindControl("lbleditusr");
        if (cntrAmt.Text != "")
            _cntrAmt = Convert.ToDouble(cntrAmt.Text);        

        TextBox cntrTime = (TextBox)gr.FindControl("txtCntrEOT");
        if (cntrTime.Text != "")
            _cntrTime = Convert.ToInt32(cntrTime.Text);

        TextBox pmcAmt = (TextBox)gr.FindControl("txtPmcAmt");
        if (pmcAmt.Text != "")
            _pmcAmt = Convert.ToDouble(pmcAmt.Text);

        TextBox pmcTime = (TextBox)gr.FindControl("txtPmcEOT");
        if (pmcTime.Text != "")
            _pmcTime = Convert.ToInt32(pmcTime.Text);

        TextBox ebsdAmt = (TextBox)gr.FindControl("txtEbsdAmt");
        if (ebsdAmt.Text != "")
            _ebsdAmt = Convert.ToDouble(ebsdAmt.Text);

        TextBox ebsdTime = (TextBox)gr.FindControl("txtEbsdEOT");
        if (ebsdTime.Text != "")
            _ebsdTime = Convert.ToInt32(ebsdTime.Text);

        TextBox consultAmt = (TextBox)gr.FindControl("txtConsultAmt");
        if (consultAmt.Text != "")
            _consultAmt = Convert.ToDouble(consultAmt.Text);

        TextBox consultTime = (TextBox)gr.FindControl("txtConsultEOT");
        if (consultTime.Text != "")
            _consultTime = Convert.ToInt32(consultTime.Text);
        
        Label id = (Label)gr.FindControl("JobVOID");

        //new JobOrderData().update_jobVOSI(Convert.ToInt32(id.Text), _cntrAmt, _cntrTime, _pmcAmt, _pmcTime, _ebsdAmt, _ebsdTime, _consultAmt, _consultTime, _cntrVO, _cntrSI, _cntrIssueDate);

        new JobOrderData().Add_JOBVOandSI(Convert.ToInt32(id.Text), _jobID, _cntrAmt, _cntrTime, _pmcAmt, _pmcTime, _ebsdAmt, _ebsdTime, _consultAmt, _consultTime, _cntrVO, _cntrSI, _cntrIssueDate, _cntrPrjIssueDate);
            
        
        lblresult.ForeColor = Color.Green;
        lblresult.Text = " Details Updated successfully";
        gvDetails.EditIndex = -1;
        FillTab2();
    }
    protected void gvDetails_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {            
            Label lblID = (Label)e.Row.FindControl("jobVOID");
            if (lblID.Text == "")
            {
                e.Row.Visible = false;
            }
        }
    }
    string parseValueIntoCurrency(double number)
    {
        // set currency format
        string curCulture = Thread.CurrentThread.CurrentCulture.ToString();
        System.Globalization.NumberFormatInfo currencyFormat = new System.Globalization.CultureInfo(curCulture).NumberFormat;
        currencyFormat.CurrencyNegativePattern = 1;

        return number.ToString("c", currencyFormat);

        //e.Row.Cells[4].Text = string.Format("{0:F3}", e.Row.Cells[4].Text);
        //Label cntrAmnt = (Label)e.Row.FindControl("lblitemUsr");
        //e.Row.Cells[4].Text = string.Format("{0:F3}", cntrAmnt.Text);
        //// Convert.ToDecimal(e.Row.Cells[4].Text).ToString("c");

        


    }
}