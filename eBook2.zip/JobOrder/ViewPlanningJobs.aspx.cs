﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Data.SqlClient;
using System.Data;
using Datalayer;
using System.Net.Mail;
using System.Text;
using System.Globalization;
using System.Diagnostics;
using System.Web.UI.HtmlControls;

public partial class JobOrder_ViewPlanningJobs : System.Web.UI.Page
{
    string connValue = System.Configuration.ConfigurationManager.ConnectionStrings["EBSDEBookConn"].ConnectionString;
    int flag;
    JobOrderData jobdata;
    DataSet ds;
    static IList<string> userRightsColl = new List<string>();
    string profile_Name = string.Empty;


    protected void Page_Load(object sender, EventArgs e)
    {
        userRightsColl = (IList<string>)Session["UserRightsColl"];
        if (!IsPostBack)
        {
            if (Session["UserID"].ToString().Equals("95") || Session["UserProfileID"].ToString().Equals("1"))
               FillGridView_Details(0);
        }
    }
    DataView dvCommitted = new DataView();
    private void FillGridView_Details(int jobid)
    {
        if (userRightsColl.Contains("61"))   //Add New Project
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "Popup", "<script>alert('You have no privilege to add this task,Contact administrator.')</script>", false);
            return;
        }

        // Status 6 for Ongoing - Status - 10 for PSA stage

        DataSet ds = new JobOrderData().GetJobOrderPlanningData("False", Convert.ToInt32(Session["UserID"]));

        if (ds.Tables.Count == 0)
            return;
        else
        {
            dvCommitted = new DataView(ds.Tables[0]);
            Session["CommittedInfo"] = dvCommitted;

            grvPlanning.DataSource = ds.Tables[0];
            grvPlanning.DataBind();
        }
    }
    protected void lnkProjectCodeNon_Click(object sender, EventArgs e)     //ForCommitted
    {
        try
        {
            LinkButton lnkJobID = (LinkButton)sender;
            GridViewRow gvr = (GridViewRow)lnkJobID.NamingContainer;
            Session["ProjectCode"] = ((HtmlGenericControl)gvr.FindControl("divProjectCodeNon")).InnerText;

            Session["UrlRef"] = Request.Url.AbsoluteUri;
            Response.Redirect("~/JobOrder/SearchJobMstr.aspx?Project_Code = " + Session["ProjectCode"] + "", false);

        }
        catch
        {

        }
    }
    protected void lnkPlannigJobNo_Click(object sender, EventArgs e)     //ForCommitted
    {
        try
        {
            LinkButton lnkJobID = (LinkButton)sender;
            GridViewRow gvr = (GridViewRow)lnkJobID.NamingContainer;
            Session["PlanJobID"] = ((HtmlGenericControl)gvr.FindControl("divJobID")).InnerText;

            Session["UrlRef"] = Request.Url.AbsoluteUri;
            Response.Redirect("~/JobOrder/DefaultGrid.aspx?JobID = " + Session["PlanJobID"] + "", false);

        }
        catch
        {

        }
    }
    protected void grvPlanning_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        grvPlanning.PageIndex = e.NewPageIndex;
        bindGridView();

        FillGridView_Details(0);
    }
    private void bindGridView()
    {
        grvPlanning.DataSource = Session["CommittedInfo"];
        grvPlanning.DataBind();
    }

    protected void btnSearch_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/Planning/SearchPSLog.aspx", false);
    }
}