﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Web.UI.HtmlControls;

public partial class JobOrder_OverDueAddendum : System.Web.UI.Page
{
    string connValue = System.Configuration.ConfigurationManager.ConnectionStrings["EBSDEBookConn"].ConnectionString;
    string profile_Name = string.Empty;
    static IList<string> userRightsColl = null;
    protected void Page_Load(object sender, EventArgs e)
    {
        userRightsColl = (IList<string>)Session["UserRightsColl"];
        if (!userRightsColl.Contains("16"))
             FillGridView_Details();
    }
    private void FillGridView_Details()
    {
        using (SqlConnection objCon = new SqlConnection(connValue))
        {
            using (SqlCommand objCmd = new SqlCommand())
            {
                objCmd.CommandType = CommandType.StoredProcedure;
                objCmd.Connection = objCon;
                objCmd.CommandText = "cc_OverDueAddendum";
                SqlDataAdapter objDA = new SqlDataAdapter(objCmd);
                DataTable dt = new DataTable();
                objDA.Fill(dt);
                gridJobs.DataSource = dt;
                gridJobs.DataBind();
            }
        }
    }   
    protected void lnkBtnJobID_Click(object sender, EventArgs e)
    {
        try
        {           
            LinkButton lnkJobID = (LinkButton)sender;          
            GridViewRow gvr = (GridViewRow)lnkJobID.NamingContainer;
            Session["JobID"] = ((HtmlGenericControl)gvr.FindControl("divJobID")).InnerText;
            Session["JobInchargeID"] = lnkJobID.ToolTip;
            Session["UrlRef"] = "~/JobOrder/OverDueAddendum.aspx";
            Response.Redirect("~/JobOrder/PSAJobDetails.aspx?JobID= " + Session["JobID"] + "", false);
        }
        catch (Exception ex)
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Error occurred while processing the request')</script>", false);
        }
    }
    protected void lnkBtnAdmStatus_Click(object sender, EventArgs e)
    {
        try
        {          
            LinkButton lnkJobID = (LinkButton)sender;           
            GridViewRow gvr = (GridViewRow)lnkJobID.NamingContainer;
            Session["JobID"] = ((HtmlGenericControl)gvr.FindControl("divJobID")).InnerText;
            string str =  ((HtmlGenericControl)gvr.FindControl("divAdmJobID")).InnerText;            
            Session["JobNo"] = ((HtmlGenericControl)gvr.FindControl("divJobNo")).InnerText;
            Session["JobInchargeID"] = lnkJobID.ToolTip;
            string strUpdateJob = Request.Url.AbsoluteUri;
            Session["UrlRef"] = strUpdateJob;
            Response.Redirect("~/JobOrder/AddendumForm.aspx?JobID= " + Session["JobID"] + "&JobNo= " + Session["JobNo"] + "", false);
        }
        catch (Exception ex)
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Error occurred while processing the request')</script>", false);
        }
    }   
}