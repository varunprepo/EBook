﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Data;
using Datalayer;
using System.Web.UI.HtmlControls;

public partial class JobOrder_SearchJobOrder : System.Web.UI.Page
{
    IList<string> userRightsColl = null;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            BindJobOrderGrid();           
        }
    }
    private void BindJobOrderGrid()
    {
        DataTable dt =   getPartialJobOrderData("");
        Session["SearchJobOrder"] = dt;

        gvJoborder.DataSource = dt;
        gvJoborder.DataBind();

        lblCnt.Text = "Job Count : - " + dt.Rows.Count.ToString();
    }
    protected void gvJoborder_RowDataBound(object sender, GridViewRowEventArgs e)
    {

    }
    protected void gvJoborder_RowCommand(object sender, GridViewCommandEventArgs e)
    {

    }
    protected void gvJoborder_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {

    }
    protected void OpenWindow(object sender, EventArgs e)
    {

    }
    protected void txtJobNo_TextChanged(object sender, EventArgs e)
    {

    }
    protected void lnkProjectCodeCmted_Click(object sender, EventArgs e)     //ForCommitted
    {
        try
        {
            LinkButton lnkJobID = (LinkButton)sender;
            GridViewRow gvr = (GridViewRow)lnkJobID.NamingContainer;
            Session["ProjectCode"] = ((HtmlGenericControl)gvr.FindControl("divProjectCodeCmted")).InnerText;

            Session["UrlRef"] = Request.Url.AbsoluteUri;
            Response.Redirect("~/JobOrder/SearchJobMstr.aspx?Project_Code = " + Session["ProjectCode"] + "", false);

        }
        catch
        {

        }
    }
    protected void lnkCostVOSILog_Click(object sender, EventArgs e)
    {
        try
        {
            LinkButton lnkcostVoLog = (LinkButton)sender;
            GridViewRow gvr = (GridViewRow)lnkcostVoLog.NamingContainer;
            Session["divCatID"] = ((HtmlGenericControl)gvr.FindControl("divCatID")).InnerText;
            Session["divProjectCodeCmted"] = ((HtmlGenericControl)gvr.FindControl("divProjectCodeCmted")).InnerText;
            Session["divJobID"] = ((HtmlGenericControl)gvr.FindControl("divJobID")).InnerText;
            Session["divJobNo"] = ((HtmlGenericControl)gvr.FindControl("divJobNo")).InnerText;

            Session["UrlRef"] = Request.Url.AbsoluteUri;
            if (Session["divCatID"].ToString().Equals("4") || Session["divCatID"].ToString().Equals("7"))
            {
                if (!userRightsColl.Contains("41"))
                {
                    UtilityClass utils = null;
                    try
                    {
                        utils = new UtilityClass(this.Page);
                        string url = Request.Url.AbsoluteUri;
                        Session["Url"] = Request.Url.AbsoluteUri;
                        if (url.Contains(":"))
                            url = url.Substring(0, utils.GetNthIndex(url, '/', 4));
                        else
                            url = url.Substring(0, utils.GetNthIndex(url, '/', 2));
                        url = url + "/JobOrder/CostVOSILog.aspx?PSAprjCode=" + Session["divProjectCodeCmted"] + "&JobID= " + Session["divJobID"] + "&PSAJobNo= " + Session["divJobNo"] + "";
                        OpenPageByUsingJS(url, "800", "650");
                    }
                    catch (Exception ex)
                    {
                        this.Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Error occurred while processing the request')</script>", false);
                    }
                }               
            }
            else
            {
                UtilityClass utils = null;
                try
                {
                    utils = new UtilityClass(this.Page);
                    string url = Request.Url.AbsoluteUri;
                    Session["Url"] = Request.Url.AbsoluteUri;
                    if (url.Contains(":"))
                        url = url.Substring(0, utils.GetNthIndex(url, '/', 4));
                    else
                        url = url.Substring(0, utils.GetNthIndex(url, '/', 2));
                    url = url + "/JobOrder/JobOrderVOLog.aspx?PSAprjCode=" + Session["divProjectCodeCmted"] + "&JobID= " + Session["divJobID"] + "&PSAJobNo= " + Session["divJobNo"] + "";
                    OpenPageByUsingJS(url, "970", "650");
                }
                catch (Exception ex)
                {
                    this.Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Error occurred while processing the request')</script>", false);
                }
            }
        }
        catch
        {

        }
    }
    private void OpenPageByUsingJS(string url, string width, string height)
    {
        string s = "window.open('" + url + "', 'popup_window', 'width=" + width + ",height=" + height + "left=100,top=100,resizable=yes');";
        Page.ClientScript.RegisterStartupScript(this.GetType(), "script", s, true);
    }
    protected void lnkJobOrderJobNo_Click(object sender, EventArgs e)     //ForCommitted
    {
        try
        {
            LinkButton lnkJobID = (LinkButton)sender;
            GridViewRow gvr = (GridViewRow)lnkJobID.NamingContainer;

            Session["JobID"] = ((HtmlGenericControl)gvr.FindControl("divJobID")).InnerText;

            Session["UrlRef"] = Request.Url.AbsoluteUri;
            Response.Redirect("~/JobOrder/DefaultGrid.aspx?JobID= " + Session["JobID"] + "", false);

        }
        catch
        {

        }
    }    


    #region jobOrderFunctions

    private DataTable getPartialJobOrderData(string category)
    {
        DataSet dsJobs = new DataSet();          // SpName -  [SearchJobOrderData]       
       
        try
        {
            string _jobNo = string.Empty;
            if (txtJobNo.Text != "")
                _jobNo = "%" + txtJobNo.Text + "%";

            string _refNo = string.Empty;
            if (txtDocRefNo.Text != "")
                _refNo = "%" + txtDocRefNo.Text + "%";

            string _contractNo = string.Empty;
            if (txtPrjNo.Text != "")
                _contractNo = "%" + txtPrjNo.Text + "%";

            string _clsrefNo = string.Empty;
            if (txtClsDocRefNo.Text != "")
                _clsrefNo = "%" + txtClsDocRefNo.Text + "%";

            dsJobs = (new JobOrderData().PartialSearchJobOrderData(_jobNo, _refNo, _contractNo, _clsrefNo));

        }
        catch (Exception ex)
        {

        }
        return dsJobs.Tables[0];    
    }

    #endregion
    protected void btnOverDue_Click(object sender, EventArgs e)
    {

    }
}