﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using Datalayer;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.Drawing;
using System.Globalization;

public partial class JobOrder_SearchAllJobs1 : System.Web.UI.Page
{
    string connValue = System.Configuration.ConfigurationManager.ConnectionStrings["EBSDEBookConn"].ConnectionString;
    static IList<string> userRightsColl = null;
    string profile_Name = string.Empty;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["UserName"] == null)
        {
            Response.Redirect("~/LoginPage.aspx", false);
            return;
        }

        userRightsColl = (IList<string>)Session["UserRightsColl"];

        if (!IsPostBack)
        {
            PopulateDropDownBox(ddlSection, "SELECT SectionID, SectionName FROM  Section Where departmentID_new = 49 ORDER BY SectionName  ", "SectionID", "SectionName");
            PopulateDropDownBox(ddlRole, "SELECT jobOwnerCatID, jobOwnerCategory FROM JobOwnerCategory ORDER BY jobOwnerCategory ", "jobOwnerCatID", "jobOwnerCategory");

            if (userRightsColl.Count != 0)
            {
                ddlSection.SelectedValue = Session["SectionID"].ToString(); // Convert.ToInt32(Session["SectionID"].ToString());                 

                string sqlQuery =  string.Empty;
               
                if (ddlSection.SelectedIndex!=0)
                    sqlQuery = "SELECT DISTINCT Contact.contactID, Contact.userShortName FROM   JobOwner INNER JOIN Contact ON JobOwner.contactID = Contact.contactID " +
                               " WHERE  (Contact.userShortName IS NOT NULL) AND (JobOwner.jobOwnerStatusID = 3) AND (Contact.sectionID = " + Convert.ToInt32(ddlSection.SelectedValue) + ") ORDER BY Contact.userShortName";
                else
                    sqlQuery = "SELECT DISTINCT Contact.contactID, Contact.userShortName FROM   JobOwner INNER JOIN Contact ON JobOwner.contactID = Contact.contactID " +
                               " WHERE  (Contact.userShortName IS NOT NULL) AND (JobOwner.jobOwnerStatusID = 3) ORDER BY Contact.userShortName";

                PopulateDropDownBox(ddlQS, sqlQuery, "ContactID", "userShortName");
                PopulateDropDownBox(ddlTeam, "SELECT teamLeaderID, teamLeaderName FROM EBSDTeamLeaders ORDER BY teamLeaderName", "teamLeaderID", "teamLeaderName");
               
                string sqlJobno = string.Empty;

                if (ddlSection.SelectedIndex!=0)
                    sqlJobno = "SELECT Distinct jobID, jobNo FROM  JobOwner where  jobOwnerStatusID = 3 and sectionID = " + Convert.ToInt32(ddlSection.SelectedValue) + " AND (jobNo IS NOT NULL) ORDER BY jobNo ";
                else
                    sqlJobno = "SELECT Distinct jobID, jobNo FROM  JobOwner where  jobOwnerStatusID = 3 AND (jobNo IS NOT NULL) ORDER BY jobNo ";

                PopulateDropDownBox(ddlJobNo, sqlJobno, "jobID", "jobNo");
            }
            else
            {
                PopulateDropDownBox(ddlQS, "SELECT DISTINCT JobOwner.contactID, Contact.userShortName FROM JobOwner INNER JOIN Contact ON JobOwner.contactID = Contact.contactID Where JobOwner.jobOwnerStatusID = 3 and Contact.userShortName IS NOT NULL Order By Contact.userShortName", "ContactID", "userShortName");
                PopulateDropDownBox(ddlTeam, "SELECT teamLeaderID, teamLeaderName FROM EBSDTeamLeaders Where SectionID = " + Convert.ToInt16(Session["SectionID"]) + " ORDER BY teamLeaderName", "teamLeaderID", "teamLeaderName");
                PopulateDropDownBox(ddlJobNo, "SELECT Distinct jobID, jobNo FROM  JobOwner where jobOwnerStatusID = 3  ORDER BY jobNo ", "jobID", "jobNo");
            }

            DataTable dt = new JobOrderData().FillGridView_Details(Session["SectionID"].ToString());  // SpName - SearchAllJobs
            lblStaffCnt.Text = dt.Rows.Count.ToString();
            DataView dvCommitted = new DataView(dt);

            //if (userRightsColl.Count == 0)
            //    Session["CommittedInfo"] = dvCommitted;
            //else
            //{
            //    dvCommitted.RowFilter = "SectionID = '" + Session["SectionID"].ToString() + "'";
                
            //}             
            Session["CommittedInfo"] = dvCommitted;
            gvJoborder.DataSource = Session["CommittedInfo"] as DataView;
            gvJoborder.DataBind();        

            //if (!userRightsColl.Contains("42"))
            //{
                FillOnGoingTasksPerStaffChart();
            //}

            if (!Session["SectionID"].Equals("4"))
            {
                string str = Session["ShortName"].ToString();
                string QSID = ddlQS.Items.FindByText(str.Replace(" ", "")).Value;
                ddlQS.SelectedValue = QSID;
                LoadDataByQS();
            }
            else
            {

            }
        }
    }
    private void FillOnGoingTasksPerStaffChart()   // chart 3
    {
        string sqlQuery = string.Empty; string strStaff = string.Empty;

        DataSet dsTndr = new DataSet();
        int sectionID = Convert.ToInt32(Session["SectionID"]);

        if (Session["userProfileID"].ToString().Equals("1"))
        {
            sqlQuery = "SELECT COUNT(*) AS JobCnt, Contact.userShortName, JobOwner.jobOwnerStatusID FROM  JobOwner INNER JOIN  Contact ON JobOwner.contactID = Contact.contactID GROUP BY JobOwner.contactID, Contact.userShortName, JobOwner.jobOwnerStatusID HAVING  (JobOwner.jobOwnerStatusID = 3) ORDER BY Contact.userShortName";

            lblOngoingStaff.Text = " On Going Tasks Per Staff In "+ddlSection.SelectedItem.Text+" Of ESD";
        }
        else if (!userRightsColl.Contains("1") && !Session["SectionID"].ToString().Equals("50"))
        {
            sqlQuery = "SELECT  COUNT(*) AS JobCnt, Contact.userShortName, JobOwner.jobOwnerStatusID, JobOwner.sectionID FROM   JobOwner INNER JOIN  Contact ON JobOwner.contactID = Contact.contactID " +
            " GROUP BY JobOwner.contactID, Contact.userShortName, JobOwner.jobOwnerStatusID, JobOwner.sectionID HAVING (JobOwner.jobOwnerStatusID = 3) AND (JobOwner.sectionID = " + sectionID + ") ORDER BY Contact.userShortName";
            lblOngoingStaff.Text = " On Going Tasks Per Staff In " + Session["SectionName"].ToString();
        }
        else if (!userRightsColl.Contains("1") && Session["SectionID"].ToString().Equals("50"))
        {
            lblOngoingStaff.Text = " On Going Tasks Per Staff In " + ddlSection.SelectedItem.Text + " Of ESD";

            sqlQuery = "SELECT  COUNT(*) AS JobCnt, Contact.userShortName, JobOwner.jobOwnerStatusID, JobOwner.sectionID FROM   JobOwner INNER JOIN  Contact ON JobOwner.contactID = Contact.contactID " +
            " GROUP BY JobOwner.contactID, Contact.userShortName, JobOwner.jobOwnerStatusID, JobOwner.sectionID HAVING (JobOwner.jobOwnerStatusID = 3) AND (JobOwner.sectionID = " + sectionID + ") ORDER BY Contact.userShortName";
        }
        else
        {
            lblOngoingStaff.Text = " On Going Tasks Per Staff In " + ddlSection.SelectedItem.Text + " Of ESD";
            if (ddlSection.SelectedIndex==0)          

              sqlQuery = "SELECT  COUNT(*) AS JobCnt, Contact.userShortName, JobOwner.jobOwnerStatusID, JobOwner.sectionID FROM   JobOwner INNER JOIN  Contact ON JobOwner.contactID = Contact.contactID " +
              " GROUP BY JobOwner.contactID, Contact.userShortName, JobOwner.jobOwnerStatusID, JobOwner.sectionID HAVING (JobOwner.jobOwnerStatusID = 3)  ORDER BY Contact.userShortName";
            else

                sqlQuery = "SELECT  COUNT(*) AS JobCnt, Contact.userShortName, JobOwner.jobOwnerStatusID, JobOwner.sectionID FROM   JobOwner INNER JOIN  Contact ON JobOwner.contactID = Contact.contactID " +
                " GROUP BY JobOwner.contactID, Contact.userShortName, JobOwner.jobOwnerStatusID, JobOwner.sectionID HAVING (JobOwner.jobOwnerStatusID = 3) AND (JobOwner.sectionID = " + sectionID + ") ORDER BY Contact.userShortName";
        }


        SqlDataAdapter daTndr = new SqlDataAdapter(sqlQuery, connValue);
        daTndr.Fill(dsTndr);
        if (dsTndr.Tables[0].Rows.Count != 0)
        {
            onGoingTasksPerStaffChart.DataSource = dsTndr.Tables[0].DefaultView;
            onGoingTasksPerStaffChart.Series["Series1"].XValueMember = "userShortName";
            onGoingTasksPerStaffChart.Series["Series1"].YValueMembers = "JobCnt";
            dsTndr.Tables.Clear();

            onGoingTasksPerStaffChart.ChartAreas[0].AxisX.MajorGrid.Enabled = false;
            onGoingTasksPerStaffChart.ChartAreas[0].AxisX.MinorGrid.Enabled = false;
            onGoingTasksPerStaffChart.ChartAreas[0].AxisY.MajorGrid.Enabled = false;
            onGoingTasksPerStaffChart.ChartAreas[0].AxisY.MinorGrid.Enabled = false;

            onGoingTasksPerStaffChart.ChartAreas[0].AxisX.LabelStyle.Angle = 30;
            onGoingTasksPerStaffChart.ChartAreas[0].AxisX.LabelStyle.ForeColor = Color.Maroon;

            onGoingTasksPerStaffChart.ChartAreas[0].AxisX.Interval = 1;
        }
    }
    private void PopulateDropDownBox(DropDownList ddlBox, string sqlQuery, string valueMember, string displayName)
    {
        ddlBox.DataBound += new EventHandler(this.ddlBox_DataBound);
        ddlBox.DataSource = new JobOrderData().FillDropdown(sqlQuery);
        ddlBox.DataTextField = displayName;
        ddlBox.DataValueField = valueMember;
        ddlBox.SelectedIndex = -1;
        ddlBox.DataBind();
    }
    protected void ddlBox_DataBound(object sender, EventArgs e)
    {
        DropDownList ddl = (DropDownList)sender;
        ListItem emptyItem = new ListItem("", "");
        ddl.Items.Insert(0, emptyItem);
    }
    protected void gvJoborder_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        gvJoborder.PageIndex = e.NewPageIndex; 
        //gvJoborder.DataSource = Session["SearchDoc"];
        //gvJoborder.DataBind();


        DataTable dt = new JobOrderData().FillGridView_Details(Session["SectionID"].ToString());
        //DataTable dtGrid = FillstaffDataForGrid();
        gvJoborder.DataSource = dt;
        gvJoborder.DataBind();
        if (!userRightsColl.Contains("42"))
        {
            FillOnGoingTasksPerStaffChart();
        }
    }
    protected void gvJoborder_RowCommand(object sender, GridViewCommandEventArgs e)
    {

    }
    protected void gvJoborder_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            Label jobNo = (Label)e.Row.FindControl("lblJobNo");          

           // Label lblJobRecDate = (Label)e.Row.FindControl("lblCmtRecDate");
            Label lblActionDueDate = (Label)e.Row.FindControl("lblActionDueDate");

            Label lblActionDueDateTemp = (Label)e.Row.FindControl("lblActionDueDateTemp");
                        

            if ((lblActionDueDate.Text != ""))
            {
                // string elapsedDays = getDaysByGivenEndDate(lblJobRecDate.Text, System.DateTime.Now.ToString());

                //Label WorkDays = (Label)e.Row.FindControl("lblDays");
                //int extraDays = Convert.ToInt16(WorkDays.Text);
                //extraDays = (extraDays / 2);

                //int totalDays = Convert.ToInt16(WorkDays.Text) + extraDays;

                // if (Convert.ToDateTime(lblActionDueDate.Text).ToString("dd/MMM/yyyy") < System.DateTime.Now.ToString("dd/MMM/yyyy"))

                if (Convert.ToDateTime(lblActionDueDate.Text) < System.DateTime.Today)
                {
                    e.Row.BackColor = System.Drawing.Color.Linen;
                    e.Row.ForeColor = System.Drawing.Color.Black;

                    e.Row.Font.Bold = true;

                    jobNo.BackColor = System.Drawing.Color.Yellow;
                    e.Row.Cells[1].BackColor = System.Drawing.Color.White;
                }
            }
            //if ((lblActionDueDateTemp.Text != ""))
            //{
            //    lblActionDueDateTemp.Text = Convert.ToDateTime(lblActionDueDateTemp.Text).ToString("dd/MM/yyyy");
            //}

        }
    }
    private string getDaysByGivenEndDate(string strDate, string endDate)
    {
        strDate = Convert.ToDateTime(strDate).ToString("MM/dd/yyyy", CultureInfo.InvariantCulture);
        endDate = Convert.ToDateTime(endDate).ToString("MM/dd/yyyy", CultureInfo.InvariantCulture);

        DateTime strDt = DateTime.ParseExact(strDate, "MM/dd/yyyy", CultureInfo.InvariantCulture);
        DateTime endDt = DateTime.ParseExact(endDate, "MM/dd/yyyy", CultureInfo.InvariantCulture);

        SqlConnection con = new SqlConnection(connValue);
        SqlCommand cmd = new SqlCommand();

        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Connection = con;

        cmd.CommandText = "testSP";

        SqlParameter prm = cmd.Parameters.Add("@ad_startDate", SqlDbType.DateTime);
        prm.Value = strDt;

        prm = cmd.Parameters.Add("@ad_endDate", SqlDbType.DateTime);
        prm.Value = endDt;

        prm = cmd.Parameters.Add("@ai_workDays", SqlDbType.Int);
        prm.Direction = ParameterDirection.Output;

        //prm = cmd.Parameters.Add("@as_errMsg", SqlDbType.VarChar);
        //prm.Direction = ParameterDirection.Output;

        con.Open();
        SqlDataReader dr = cmd.ExecuteReader();
        while (dr.Read())
            Console.WriteLine(dr.GetString(0));
        con.Dispose();
        con.Close();

        return cmd.Parameters[2].Value.ToString();
    }
    protected void btnSearch_Click(object sender, EventArgs e)
    {

    }
    protected void btnClear_Click(object sender, EventArgs e)
    {

    }
    protected void ddlJobNo_SelectedIndexChanged(object sender, EventArgs e)
    {
        DataView dvJobNo = new DataView();
        dvJobNo = Session["CommittedInfo"] as DataView;

        if ((ddlJobNo.SelectedItem.Text != "") & (ddlQS.SelectedItem.Text != ""))        
            dvJobNo.RowFilter = "JOBNO = '" + ddlJobNo.SelectedItem.Text + "' and QSNAME = '" + ddlQS.SelectedItem.Text + "'";
        else if (ddlJobNo.SelectedItem.Text != "")
            dvJobNo.RowFilter = "JOBNO = '" + ddlJobNo.SelectedItem.Text + "'";
        else if (ddlQS.SelectedItem.Text != "")
            dvJobNo.RowFilter = "QSNAME = '" + ddlQS.SelectedItem.Text + "'";
        
        gvJoborder.DataSource = dvJobNo;
        gvJoborder.DataBind();       
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        ddlQS.SelectedIndex = -1;
        ddlJobNo.SelectedIndex = -1;
       
        ddlTeam.SelectedIndex = 0;
        ddlRole.SelectedIndex = 0;

        if (userRightsColl.Count == 0)
          ddlSection.SelectedIndex = 0;

        DataTable dt = new JobOrderData().FillGridView_Details(Session["SectionID"].ToString());      // SpName - SearchAllJobs
        DataView dvCommitted = new DataView(); 

        dvCommitted = Session["CommittedInfo"] as DataView;
        //dvCommitted.RowFilter = "project_code = '" + lnkBtn.Text + "'";       
        
        lblStaffCnt.Text = dt.Rows.Count.ToString();

        if (Session["SectionID"].Equals("22"))
        {
            var filteredDataRows = dt.Select("SectionID =22");

            if (filteredDataRows.Length != 0)
                dt = filteredDataRows.CopyToDataTable();

            gvJoborder.DataSource = dt;
            gvJoborder.DataBind();
        }
        else
        {
            gvJoborder.DataSource = dvCommitted;
            gvJoborder.DataBind();
        }

        if (!userRightsColl.Contains("42"))
        {
            FillOnGoingTasksPerStaffChart();
        }

        if (userRightsColl.Count != 0)
        {
            PopulateDropDownBox(ddlQS, "SELECT DISTINCT JobOwner.contactID, Contact.userShortName FROM JobOwner INNER JOIN Contact ON JobOwner.contactID = Contact.contactID WHERE JobOwner.sectionID = " + Convert.ToInt32(Session["SectionID"]) + " and JobOwner.jobOwnerStatusID = 3 Order By Contact.userShortName ", "ContactID", "userShortName");
        }
        else
        {
            PopulateDropDownBox(ddlQS, "SELECT DISTINCT JobOwner.contactID, Contact.userShortName FROM JobOwner INNER JOIN Contact ON JobOwner.contactID = Contact.contactID Where JobOwner.jobOwnerStatusID = 3 Order By Contact.userShortName", "ContactID", "userShortName");           
        }

        string sqlJobno = string.Empty;

        if (ddlSection.SelectedIndex != 0)
            sqlJobno = "SELECT Distinct jobID, jobNo FROM  JobOwner where  jobOwnerStatusID = 3 and sectionID = " + Convert.ToInt32(ddlSection.SelectedValue) + "  ORDER BY jobNo ";
        else
            sqlJobno = "SELECT Distinct jobID, jobNo FROM  JobOwner where  jobOwnerStatusID = 3  ORDER BY jobNo ";

       PopulateDropDownBox(ddlJobNo, sqlJobno, "jobID", "jobNo");
    }   
    protected void lnkBtnJobID_Click(object sender, EventArgs e)
    {
        string strUpdateJob = Request.Url.AbsoluteUri;
        try
        {
            LinkButton lnkJobID = (LinkButton)sender;            
            GridViewRow gvr = (GridViewRow)lnkJobID.NamingContainer;

            Session["JobID"] = ((HtmlGenericControl)gvr.FindControl("divJobID")).InnerText;

            Session["PayID"] = ((HtmlGenericControl)gvr.FindControl("divPayID")).InnerText;

            Session["JobInchargeID"] = lnkJobID.ToolTip;

            Session["JobCatID"] = ((HtmlGenericControl)gvr.FindControl("divJoCatbID")).InnerText;

            if(Session["SectionID"].ToString().Equals("13"))
            {
                Session["UrlRef"] = strUpdateJob;
                Response.Redirect("~/TSS/TSSJobDetails.aspx?JobID= " + Session["JobID"] + "", false);
            }
            else if (((HtmlGenericControl)gvr.FindControl("divJoCatbID")).InnerText == "2")     //payment
            {
                Session["UrlRef"] = strUpdateJob;
                Response.Redirect("~/Payments/PaymentDetails.aspx?PayID= " + Session["PayID"] + "", false);
            }
            else if (((HtmlGenericControl)gvr.FindControl("divJoCatbID")).InnerText == "8")
            {
                Session["UrlRef"] = strUpdateJob;
                Response.Redirect("~/DCLog/DCDetails.aspx?JobID= " + Session["JobID"] + "", false);
            }
            else if (((HtmlGenericControl)gvr.FindControl("divJoCatbID")).InnerText == "46") // Manager office
            {
                Session["UrlRef"] = strUpdateJob;
                Response.Redirect("~/ManagerTask/MngrTaskDetails.aspx?JobID= " + Session["JobID"] + "", false);
            }
            else if (((HtmlGenericControl)gvr.FindControl("divJoCatbID")).InnerText == "67") // GS office
            {
                Session["UrlRef"] = strUpdateJob;
             
                Response.Redirect("~/GenaralService/GSDetails.aspx?JobID= " + Session["JobID"] + "", false);
            }
            else if ((((HtmlGenericControl)gvr.FindControl("divJoCatbID")).InnerText == "76") || (((HtmlGenericControl)gvr.FindControl("divJoCatbID")).InnerText == "77") || (((HtmlGenericControl)gvr.FindControl("divJoCatbID")).InnerText == "78") || (((HtmlGenericControl)gvr.FindControl("divJoCatbID")).InnerText == "79")) // GS office
            {
                Session["UrlRef"] = strUpdateJob;

                Response.Redirect("~/GIS/GISDetails.aspx?JobID= " + Session["JobID"] + "", false);
            }
            else if (((HtmlGenericControl)gvr.FindControl("divJoCatbID")).InnerText == "100")
            {
                Session["UrlRef"] = strUpdateJob;
                Response.Redirect("~/Contracts/ClaimDetails.aspx?JobID= " + Session["JobID"] + "", false);
            }
            else if (((HtmlGenericControl)gvr.FindControl("divJoCatbID")).InnerText != "1")
            {                
                Session["UrlRef"] = strUpdateJob;              
                Response.Redirect("~/JobOrder/DefaultGrid.aspx?JobID= " + Session["JobID"] + "", false);
            }
            
            else
            {
               // Session["UrlRef"] = "~/JobOrder/PSAJobDetails.aspx";
                Session["UrlRef"] = strUpdateJob;
                Response.Redirect("~/JobOrder/PSAJobDetails.aspx?JobID= " + Session["JobID"] + "", false);
            }
        }
        catch (Exception ex)
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Error occurred while processing the request')</script>", false);
        }
    }
    protected void onGoingTasksPerStaffChart_Load(object sender, EventArgs e)
    {

    }
    protected void onGoingTasksPerStaffChart_Click(object sender, ImageMapEventArgs e)
    {

    }
    protected void SetSection(object sender, EventArgs e)
    {
        if (ddlSection.SelectedIndex == 0)
            return;

        //Calendar1.VisibleDate = new DateTime(int.Parse(ddlYear.SelectedValue),
        //                               int.Parse(ddlMonth.SelectedValue),
        //                               1);

       // calColl = getCalanderDates(ddlYear.SelectedItem.Text, Convert.ToInt32(ddlMonth.SelectedValue));
        
        string sqlQuery = "SELECT  COUNT(*) AS JobCnt, Contact.userShortName, JobOwner.jobOwnerStatusID, JobOwner.sectionID FROM   JobOwner INNER JOIN  Contact ON JobOwner.contactID = Contact.contactID " +
                  " GROUP BY JobOwner.contactID, Contact.userShortName, JobOwner.jobOwnerStatusID, JobOwner.sectionID HAVING (JobOwner.jobOwnerStatusID = 3) AND (JobOwner.sectionID = " + ddlSection.SelectedValue + ") ORDER BY Contact.userShortName";

        DataSet dsTndr = new DataSet();
        SqlDataAdapter daTndr = new SqlDataAdapter(sqlQuery, connValue);
        daTndr.Fill(dsTndr);
        if (dsTndr.Tables[0].Rows.Count != 0)
        {
            onGoingTasksPerStaffChart.DataSource = dsTndr.Tables[0].DefaultView;
            onGoingTasksPerStaffChart.Series["Series1"].XValueMember = "userShortName";
            onGoingTasksPerStaffChart.Series["Series1"].YValueMembers = "JobCnt";
           
            dsTndr.Tables.Clear();

            onGoingTasksPerStaffChart.ChartAreas[0].AxisX.MajorGrid.Enabled = false;
            onGoingTasksPerStaffChart.ChartAreas[0].AxisX.MinorGrid.Enabled = false;
            onGoingTasksPerStaffChart.ChartAreas[0].AxisY.MajorGrid.Enabled = false;
            onGoingTasksPerStaffChart.ChartAreas[0].AxisY.MinorGrid.Enabled = false;

            onGoingTasksPerStaffChart.ChartAreas[0].AxisX.LabelStyle.Angle = 30;
            onGoingTasksPerStaffChart.ChartAreas[0].AxisX.LabelStyle.ForeColor = Color.Maroon;

            onGoingTasksPerStaffChart.ChartAreas[0].AxisX.Interval = 1;
        }
    }
    private DataTable FillstaffData()
    {
        DataSet ds = new DataSet();
        try
        {           

            Int32 sectionID;
            Int32.TryParse(ddlSection.SelectedValue, out sectionID);

            Int32 teamLeadID;
            Int32.TryParse(ddlTeam.SelectedValue, out teamLeadID);

            Int32 roleID;
            Int32.TryParse(ddlRole.SelectedValue, out roleID);

            ds = (new JobOrderData().GetStaffDetailsForChart(sectionID, teamLeadID, roleID));            // SpName SearchStaff

            DataView dvCommitted = new DataView(ds.Tables[0]);           

        }
        catch (Exception ex)
        {

        }
        return ds.Tables[0];
    }
    private DataTable FillstaffDataForGrid()
    {
        DataSet ds = new DataSet();
        try
        {

            Int32 sectionID;
            Int32.TryParse(ddlSection.SelectedValue, out sectionID);

            Int32 teamLeadID;
            Int32.TryParse(ddlTeam.SelectedValue, out teamLeadID);

            Int32 roleID;
            Int32.TryParse(ddlRole.SelectedValue, out roleID);

            Int32 jobID;
            Int32.TryParse(ddlJobNo.SelectedValue, out jobID);

            Int32 staffID;
            Int32.TryParse(ddlQS.SelectedValue, out staffID);

            ds = new JobOrderData().GetStaffDetailsForGrid(sectionID, teamLeadID, roleID, jobID, staffID);          // SpName FillStaffData

            DataView dvCommitted = new DataView(ds.Tables[0]);

        }
        catch (Exception ex)
        {

        }
        return ds.Tables[0];
    }

    private DataTable FillstaffDataForGridByJobNo()
    {
        DataSet ds = new DataSet();
        try
        {

            Int32 sectionID;
            Int32.TryParse(ddlSection.SelectedValue, out sectionID);

            Int32 teamLeadID;
            Int32.TryParse(ddlTeam.SelectedValue, out teamLeadID);

            Int32 roleID;
            Int32.TryParse(ddlRole.SelectedValue, out roleID);

            Int32 jobID;
            Int32.TryParse(ddlJobNo.SelectedValue, out jobID);

            Int32 staffID;
            Int32.TryParse(ddlQS.SelectedValue, out staffID);

            string strJobNo = string.Empty;
            if (txtJobNo.Text != "")
                strJobNo = "%" + txtJobNo.Text + "%";

            ds = new JobOrderData().GetStaffDetailsForGridByJobNo(sectionID, teamLeadID, roleID, strJobNo);             // SpName - SearchStaffByJobNo

            DataView dvCommitted = new DataView(ds.Tables[0]);

        }
        catch (Exception ex)
        {

        }
        return ds.Tables[0];
    }
    //
    protected void changedEventForStaff(object sender, EventArgs e)
    {
      DataTable dt = FillstaffData();
      DataTable dtGrid = FillstaffDataForGrid();            // Sp-Name FillStaffData

      lblStaffCnt.Text = dtGrid.Rows.Count.ToString();
     
      if (dt.Rows.Count != 0)
      {
          onGoingTasksPerStaffChart.DataSource = dt.DefaultView;
          onGoingTasksPerStaffChart.Series["Series1"].XValueMember = "userShortName";
          onGoingTasksPerStaffChart.Series["Series1"].YValueMembers = "JobCnt";
         // dt.Clear();

          onGoingTasksPerStaffChart.ChartAreas[0].AxisX.MajorGrid.Enabled = false;
          onGoingTasksPerStaffChart.ChartAreas[0].AxisX.MinorGrid.Enabled = false;
          onGoingTasksPerStaffChart.ChartAreas[0].AxisY.MajorGrid.Enabled = false;
          onGoingTasksPerStaffChart.ChartAreas[0].AxisY.MinorGrid.Enabled = false;

          onGoingTasksPerStaffChart.ChartAreas[0].AxisX.LabelStyle.Angle = 30;
          onGoingTasksPerStaffChart.ChartAreas[0].AxisX.LabelStyle.ForeColor = Color.Maroon;

          onGoingTasksPerStaffChart.ChartAreas[0].AxisX.Interval = 1;
      }

      gvJoborder.DataSource = dtGrid;
      gvJoborder.DataBind();

      ddlQS.Items.Clear();

      if (ddlQS.SelectedIndex != 0)
      {
          if (ddlTeam.SelectedIndex != 0)
              PopulateDropDownBox(ddlQS, "SELECT DISTINCT JobOwner.contactID, Contact.userShortName FROM JobOwner INNER JOIN Contact ON JobOwner.contactID = Contact.contactID where Contact.teamleaderID = " + ddlTeam.SelectedValue + " and JobOwner.jobOwnerStatusID = 3 Order By Contact.userShortName", "ContactID", "userShortName");
          else
              PopulateDropDownBox(ddlQS, "SELECT DISTINCT JobOwner.contactID, Contact.userShortName FROM JobOwner INNER JOIN Contact ON JobOwner.contactID = Contact.contactID Where JobOwner.jobOwnerStatusID = 3 Order By Contact.userShortName", "ContactID", "userShortName");
      }
      else
          PopulateDropDownBox(ddlQS, "SELECT DISTINCT JobOwner.contactID, Contact.userShortName FROM JobOwner INNER JOIN Contact ON JobOwner.contactID = Contact.contactID Where JobOwner.jobOwnerStatusID = 3 and sectionID = " + ddlSection.SelectedValue + " Order By Contact.userShortName", "ContactID", "userShortName");
        
   
      if (ddlSection.SelectedIndex != 0)
      {
          ddlJobNo.Items.Clear();
          PopulateDropDownBox(ddlJobNo, "SELECT DISTINCT jobID, jobNo FROM   JobOwner WHERE JobOwner.sectionID =  " + ddlSection.SelectedValue + " and JobOwner.jobOwnerStatusID = 3 Order By jobNo", "jobID", "jobNo");
      }     
      else
      {
          ddlJobNo.Items.Clear();
          PopulateDropDownBox(ddlJobNo, "SELECT DISTINCT JobOwner.jobID, JobOwner.jobNo, JobOwner.jobOwnerStatusID FROM  JobOwner INNER JOIN   Contact ON JobOwner.contactID = Contact.contactID WHERE   (JobOwner.jobOwnerStatusID = 3)  ORDER BY JobOwner.jobNo", "jobID", "jobNo");
      }
    }
    protected void SetTeamLead(object sender, EventArgs e)
    {
        FillstaffData();
        return;

        string sqlQuery = string.Empty;

        if ((ddlSection.SelectedIndex !=0)  & (ddlTeam.SelectedIndex !=0) & (ddlRole.SelectedIndex !=0))     
               sqlQuery = "  SELECT COUNT(*) AS JobCnt, Contact.userShortName, JobOwner.jobOwnerStatusID, JobOwner.sectionID, Contact.teamLeaderID " + 
                             " FROM JobOwner INNER JOIN  Contact ON JobOwner.contactID = Contact.contactID GROUP BY JobOwner.contactID, Contact.userShortName, JobOwner.jobOwnerStatusID, JobOwner.sectionID, Contact.teamLeaderID " +
                               " HAVING   (JobOwner.jobOwnerStatusID = 3) AND (JobOwner.sectionID =  " + ddlSection.SelectedValue + ")  AND (Contact.teamLeaderID = " + ddlTeam.SelectedValue + ") AND (JobOwner.staffroleID =  " + ddlRole.SelectedValue + ") ORDER BY Contact.userShortName";
        else if ((ddlSection.SelectedIndex !=0)  & (ddlTeam.SelectedIndex !=0))
            sqlQuery = "  SELECT COUNT(*) AS JobCnt, Contact.userShortName, JobOwner.jobOwnerStatusID, JobOwner.sectionID, Contact.teamLeaderID " +
                                 " FROM JobOwner INNER JOIN  Contact ON JobOwner.contactID = Contact.contactID GROUP BY JobOwner.contactID, Contact.userShortName, JobOwner.jobOwnerStatusID, JobOwner.sectionID, Contact.teamLeaderID " +
                                   " HAVING   (JobOwner.jobOwnerStatusID = 3) AND (JobOwner.sectionID =  " + ddlSection.SelectedValue + ")  AND (Contact.teamLeaderID = " + ddlTeam.SelectedValue + ")  ORDER BY Contact.userShortName";
        else if ((ddlSection.SelectedIndex != 0) & (ddlTeam.SelectedIndex != 0))
            sqlQuery = "  SELECT COUNT(*) AS JobCnt, Contact.userShortName, JobOwner.jobOwnerStatusID, JobOwner.sectionID, Contact.teamLeaderID " +
                                 " FROM JobOwner INNER JOIN  Contact ON JobOwner.contactID = Contact.contactID GROUP BY JobOwner.contactID, Contact.userShortName, JobOwner.jobOwnerStatusID, JobOwner.sectionID, Contact.teamLeaderID " +
                                   " HAVING   (JobOwner.jobOwnerStatusID = 3) AND (JobOwner.sectionID =  " + ddlSection.SelectedValue + ")  AND (Contact.teamLeaderID = " + ddlTeam.SelectedValue + ")  ORDER BY Contact.userShortName";
        else
            sqlQuery = "SELECT COUNT(*) AS JobCnt, Contact.userShortName, JobOwner.jobOwnerStatusID, JobOwner.sectionID, Contact.teamLeaderID " +
                            " FROM JobOwner INNER JOIN  Contact ON JobOwner.contactID = Contact.contactID GROUP BY JobOwner.contactID, Contact.userShortName, JobOwner.jobOwnerStatusID, JobOwner.sectionID, Contact.teamLeaderID " +
                              " HAVING (JobOwner.jobOwnerStatusID = 3) AND (Contact.teamLeaderID = " + ddlTeam.SelectedValue + ")  ORDER BY Contact.userShortName";

        sqlQuery = "SELECT COUNT(*) AS JobCnt, Contact.userShortName, JobOwner.jobOwnerStatusID, JobOwner.sectionID, Contact.teamLeaderID " +
                          " FROM JobOwner INNER JOIN  Contact ON JobOwner.contactID = Contact.contactID GROUP BY JobOwner.contactID, Contact.userShortName, JobOwner.jobOwnerStatusID, JobOwner.sectionID, Contact.teamLeaderID " +
                            " HAVING   (JobOwner.jobOwnerStatusID = 3)";

        if ((ddlSection.SelectedIndex != 0) & (ddlTeam.SelectedIndex != 0))
            sqlQuery = "SELECT COUNT(*) AS JobCnt, Contact.userShortName, JobOwner.jobOwnerStatusID, JobOwner.sectionID, Contact.teamLeaderID " +
                                 " FROM JobOwner INNER JOIN  Contact ON JobOwner.contactID = Contact.contactID GROUP BY JobOwner.contactID, Contact.userShortName, JobOwner.jobOwnerStatusID, JobOwner.sectionID, Contact.teamLeaderID " +
                                   " HAVING   (JobOwner.jobOwnerStatusID = 3) AND (JobOwner.sectionID =  " + ddlSection.SelectedValue + ")  AND (Contact.teamLeaderID = " + ddlTeam.SelectedValue + ")  ORDER BY Contact.userShortName";
        else if ((ddlSection.SelectedIndex != 0) & (ddlTeam.SelectedIndex != 0))
            sqlQuery = "  SELECT COUNT(*) AS JobCnt, Contact.userShortName, JobOwner.jobOwnerStatusID, JobOwner.sectionID, Contact.teamLeaderID " +
                                 " FROM JobOwner INNER JOIN  Contact ON JobOwner.contactID = Contact.contactID GROUP BY JobOwner.contactID, Contact.userShortName, JobOwner.jobOwnerStatusID, JobOwner.sectionID, Contact.teamLeaderID " +
                                   " HAVING   (JobOwner.jobOwnerStatusID = 3) AND (JobOwner.sectionID =  " + ddlSection.SelectedValue + ")  AND (Contact.teamLeaderID = " + ddlTeam.SelectedValue + ")  ORDER BY Contact.userShortName";
        else
            sqlQuery = "SELECT COUNT(*) AS JobCnt, Contact.userShortName, JobOwner.jobOwnerStatusID, JobOwner.sectionID, Contact.teamLeaderID " +
                            " FROM JobOwner INNER JOIN  Contact ON JobOwner.contactID = Contact.contactID GROUP BY JobOwner.contactID, Contact.userShortName, JobOwner.jobOwnerStatusID, JobOwner.sectionID, Contact.teamLeaderID " +
                              " HAVING (JobOwner.jobOwnerStatusID = 3) AND (Contact.teamLeaderID = " + ddlTeam.SelectedValue + ")  ORDER BY Contact.userShortName";

        DataSet dsTndr = new DataSet();

        SqlDataAdapter daTndr = new SqlDataAdapter(sqlQuery, connValue);
        daTndr.Fill(dsTndr);
        if (dsTndr.Tables[0].Rows.Count != 0)
        {
            onGoingTasksPerStaffChart.DataSource = dsTndr.Tables[0].DefaultView;
            onGoingTasksPerStaffChart.Series["Series1"].XValueMember = "userShortName";
            onGoingTasksPerStaffChart.Series["Series1"].YValueMembers = "JobCnt";
            dsTndr.Tables.Clear();

            onGoingTasksPerStaffChart.ChartAreas[0].AxisX.MajorGrid.Enabled = false;
            onGoingTasksPerStaffChart.ChartAreas[0].AxisX.MinorGrid.Enabled = false;
            onGoingTasksPerStaffChart.ChartAreas[0].AxisY.MajorGrid.Enabled = false;
            onGoingTasksPerStaffChart.ChartAreas[0].AxisY.MinorGrid.Enabled = false;

            onGoingTasksPerStaffChart.ChartAreas[0].AxisX.LabelStyle.Angle = 30;
            onGoingTasksPerStaffChart.ChartAreas[0].AxisX.LabelStyle.ForeColor = Color.Maroon;

            onGoingTasksPerStaffChart.ChartAreas[0].AxisX.Interval = 1;

        }
    }
    protected void SetStaffRoleLead(object sender, EventArgs e)
    {


        //Calendar1.VisibleDate = new DateTime(int.Parse(ddlYear.SelectedValue),
        //                               int.Parse(ddlMonth.SelectedValue),
        //                               1);

        // calColl = getCalanderDates(ddlYear.SelectedItem.Text, Convert.ToInt32(ddlMonth.SelectedValue));

        string sqlQuery = "SELECT  COUNT(*) AS JobCnt, Contact.userShortName, JobOwner.jobOwnerStatusID, JobOwner.sectionID FROM   JobOwner INNER JOIN  Contact ON JobOwner.contactID = Contact.contactID " +
                  " GROUP BY JobOwner.contactID, Contact.userShortName, JobOwner.jobOwnerStatusID, JobOwner.sectionID HAVING (JobOwner.jobOwnerStatusID = 3) AND (JobOwner.sectionID = " + ddlSection.SelectedValue + ") ORDER BY Contact.userShortName";


        DataSet dsTndr = new DataSet();


        SqlDataAdapter daTndr = new SqlDataAdapter(sqlQuery, connValue);
        daTndr.Fill(dsTndr);
        if (dsTndr.Tables[0].Rows.Count != 0)
        {
            onGoingTasksPerStaffChart.DataSource = dsTndr.Tables[0].DefaultView;
            onGoingTasksPerStaffChart.Series["Series1"].XValueMember = "userShortName";
            onGoingTasksPerStaffChart.Series["Series1"].YValueMembers = "JobCnt";
            dsTndr.Tables.Clear();

            onGoingTasksPerStaffChart.ChartAreas[0].AxisX.MajorGrid.Enabled = false;
            onGoingTasksPerStaffChart.ChartAreas[0].AxisX.MinorGrid.Enabled = false;
            onGoingTasksPerStaffChart.ChartAreas[0].AxisY.MajorGrid.Enabled = false;
            onGoingTasksPerStaffChart.ChartAreas[0].AxisY.MinorGrid.Enabled = false;

            onGoingTasksPerStaffChart.ChartAreas[0].AxisX.LabelStyle.Angle = 30;
            onGoingTasksPerStaffChart.ChartAreas[0].AxisX.LabelStyle.ForeColor = Color.Maroon;

            onGoingTasksPerStaffChart.ChartAreas[0].AxisX.Interval = 1;

        }
    }


    protected void changedEventForStaffJobNo(object sender, EventArgs e)
    {
        //if (ddlQS.SelectedIndex != 0)
        //{
        //    //ddlQS.Items.Clear();

        //    if (ddlTeam.SelectedIndex != 0)
        //        PopulateDropDownBox(ddlQS, "SELECT DISTINCT JobOwner.contactID, Contact.userShortName FROM JobOwner INNER JOIN Contact ON JobOwner.contactID = Contact.contactID where Contact.teamleaderID = " + ddlTeam.SelectedValue + " Order By Contact.userShortName", "ContactID", "userShortName");

        //}
        //else
        //    PopulateDropDownBox(ddlQS, "SELECT DISTINCT JobOwner.contactID, Contact.userShortName FROM JobOwner INNER JOIN Contact ON JobOwner.contactID = Contact.contactID  Order By Contact.userShortName", "ContactID", "userShortName");

        

        //if (ddlSection.SelectedIndex != 0)           
        //{
        //    ddlJobNo.Items.Clear();
        //    //if (ddlTeam.SelectedIndex != 0)
        //    PopulateDropDownBox(ddlJobNo, "SELECT DISTINCT jobID, jobNo FROM   JobOwner WHERE JobOwner.sectionID =  " + ddlSection.SelectedValue + " and JobOwner.jobOwnerStatusID = 3 Order By jobNo", "jobID", "jobNo");

        //}
        //else
        //    PopulateDropDownBox(ddlQS, "SELECT DISTINCT JobOwner.contactID, Contact.userShortName FROM JobOwner INNER JOIN Contact ON JobOwner.contactID = Contact.contactID  Order By Contact.userShortName", "ContactID", "userShortName");




        DataTable dtGrid = FillstaffDataForGrid();       // Sp-Name FillStaffData
        gvJoborder.DataSource = dtGrid;
        gvJoborder.DataBind();


        FillOnGoingTasksPerStaffChart();
        

    }


    protected void changedEventForStaffQS(object sender, EventArgs e)
    {
        LoadDataByQS();
    }
    private void LoadDataByQS()
    {
        //DataTable dtGrid = FillstaffDataForGrid();      // Sp-Name FillStaffData

        //Session["CommittedInfo"] = dtGrid;

        //gvJoborder.DataSource = dtGrid;
        //gvJoborder.DataBind();

        FillOnGoingTasksPerStaffChart();
        
    }

    protected void txtJobNo_TextChanged(object sender, EventArgs e)
    {
        DataTable dtGrid = FillstaffDataForGrid();   // Sp-Name FillStaffData
        gvJoborder.DataSource = dtGrid;
        gvJoborder.DataBind();
    }
    protected void changedEventForStaff_team(object sender, EventArgs e)
    {
        ddlQS.SelectedIndex = 0;

        DataTable dt = FillstaffData();
        DataTable dtGrid = FillstaffDataForGrid();         // Sp-Name FillStaffData

        lblStaffCnt.Text = dtGrid.Rows.Count.ToString();

        if (dt.Rows.Count != 0)
        {
            onGoingTasksPerStaffChart.DataSource = dt.DefaultView;
            onGoingTasksPerStaffChart.Series["Series1"].XValueMember = "userShortName";
            onGoingTasksPerStaffChart.Series["Series1"].YValueMembers = "JobCnt";
            // dt.Clear();

            onGoingTasksPerStaffChart.ChartAreas[0].AxisX.MajorGrid.Enabled = false;
            onGoingTasksPerStaffChart.ChartAreas[0].AxisX.MinorGrid.Enabled = false;
            onGoingTasksPerStaffChart.ChartAreas[0].AxisY.MajorGrid.Enabled = false;
            onGoingTasksPerStaffChart.ChartAreas[0].AxisY.MinorGrid.Enabled = false;

            onGoingTasksPerStaffChart.ChartAreas[0].AxisX.LabelStyle.Angle = 30;
            onGoingTasksPerStaffChart.ChartAreas[0].AxisX.LabelStyle.ForeColor = Color.Maroon;

            onGoingTasksPerStaffChart.ChartAreas[0].AxisX.Interval = 1;
        }

        gvJoborder.DataSource = dtGrid;
        gvJoborder.DataBind();

        ddlQS.Items.Clear();

        if (ddlQS.SelectedIndex != 0)
        {
            if (ddlTeam.SelectedIndex != 0)
                PopulateDropDownBox(ddlQS, "SELECT DISTINCT JobOwner.contactID, Contact.userShortName FROM JobOwner INNER JOIN Contact ON JobOwner.contactID = Contact.contactID where Contact.teamleaderID = " + ddlTeam.SelectedValue + " and JobOwner.jobOwnerStatusID = 3 Order By Contact.userShortName", "ContactID", "userShortName");
            else
                PopulateDropDownBox(ddlQS, "SELECT DISTINCT JobOwner.contactID, Contact.userShortName FROM JobOwner INNER JOIN Contact ON JobOwner.contactID = Contact.contactID Where JobOwner.jobOwnerStatusID = 3 Order By Contact.userShortName", "ContactID", "userShortName");
        }
        else
            PopulateDropDownBox(ddlQS, "SELECT DISTINCT JobOwner.contactID, Contact.userShortName FROM JobOwner INNER JOIN Contact ON JobOwner.contactID = Contact.contactID Where JobOwner.jobOwnerStatusID = 3  Order By Contact.userShortName", "ContactID", "userShortName");


        if (ddlTeam.SelectedIndex != 0)
        {
            ddlJobNo.Items.Clear();
            PopulateDropDownBox(ddlJobNo, "SELECT DISTINCT JobOwner.jobID, JobOwner.jobNo, Contact.teamLeaderID, JobOwner.jobOwnerStatusID FROM JobOwner INNER JOIN Contact ON JobOwner.contactID = Contact.contactID WHERE (Contact.teamLeaderID = " + ddlTeam.SelectedValue + ") AND (JobOwner.jobOwnerStatusID = 3) ORDER BY JobOwner.jobNo", "jobID", "jobNo");

        }       
        else
        {
            ddlJobNo.Items.Clear();
            PopulateDropDownBox(ddlJobNo, "SELECT DISTINCT JobOwner.jobID, JobOwner.jobNo, JobOwner.jobOwnerStatusID FROM  JobOwner INNER JOIN   Contact ON JobOwner.contactID = Contact.contactID WHERE   (JobOwner.jobOwnerStatusID = 3)  ORDER BY JobOwner.jobNo", "jobID", "jobNo");
        }
          
    }
    protected void changedEventForStaff_Role(object sender, EventArgs e)
    {
        DataTable dt = FillstaffData();
        DataTable dtGrid = FillstaffDataForGrid();      // Sp-Name FillStaffData

        lblStaffCnt.Text = dtGrid.Rows.Count.ToString();

        if (dt.Rows.Count != 0)
        {
            onGoingTasksPerStaffChart.DataSource = dt.DefaultView;
            onGoingTasksPerStaffChart.Series["Series1"].XValueMember = "userShortName";
            onGoingTasksPerStaffChart.Series["Series1"].YValueMembers = "JobCnt";
            // dt.Clear();

            onGoingTasksPerStaffChart.ChartAreas[0].AxisX.MajorGrid.Enabled = false;
            onGoingTasksPerStaffChart.ChartAreas[0].AxisX.MinorGrid.Enabled = false;
            onGoingTasksPerStaffChart.ChartAreas[0].AxisY.MajorGrid.Enabled = false;
            onGoingTasksPerStaffChart.ChartAreas[0].AxisY.MinorGrid.Enabled = false;

            onGoingTasksPerStaffChart.ChartAreas[0].AxisX.LabelStyle.Angle = 30;
            onGoingTasksPerStaffChart.ChartAreas[0].AxisX.LabelStyle.ForeColor = Color.Maroon;

            onGoingTasksPerStaffChart.ChartAreas[0].AxisX.Interval = 1;
        }

        gvJoborder.DataSource = dtGrid;
        gvJoborder.DataBind();

        ddlQS.Items.Clear();

        if (ddlQS.SelectedIndex != 0)
        {
            if (ddlTeam.SelectedIndex != 0)
                PopulateDropDownBox(ddlQS, "SELECT DISTINCT JobOwner.contactID, Contact.userShortName FROM JobOwner INNER JOIN Contact ON JobOwner.contactID = Contact.contactID where Contact.teamleaderID = " + ddlTeam.SelectedValue + " and JobOwner.jobOwnerStatusID = 3 Order By Contact.userShortName", "ContactID", "userShortName");
            else
                PopulateDropDownBox(ddlQS, "SELECT DISTINCT JobOwner.contactID, Contact.userShortName FROM JobOwner INNER JOIN Contact ON JobOwner.contactID = Contact.contactID Where JobOwner.jobOwnerStatusID = 3  Order By Contact.userShortName", "ContactID", "userShortName");
        
        }
        else
            PopulateDropDownBox(ddlQS, "SELECT DISTINCT JobOwner.contactID, Contact.userShortName FROM JobOwner INNER JOIN Contact ON JobOwner.contactID = Contact.contactID Where JobOwner.jobOwnerStatusID = 3   Order By Contact.userShortName", "ContactID", "userShortName");


        if (ddlRole.SelectedIndex != 0)
        {
            ddlJobNo.Items.Clear();
            string sqlQuery = "SELECT DISTINCT JobOwner.jobID, JobOwner.jobNo, JobOwner.jobOwnerStatusID, JobOwner.StaffRoleID FROM JobOwner INNER JOIN  Contact ON JobOwner.contactID = Contact.contactID  WHERE   (JobOwner.jobOwnerStatusID = 3) AND (JobOwner.StaffRoleID = 1) ORDER BY JobOwner.jobNo";
            PopulateDropDownBox(ddlJobNo, sqlQuery, "jobID", "jobNo");

            ddlQS.Items.Clear();           
                PopulateDropDownBox(ddlQS, "SELECT DISTINCT JobOwner.contactID, Contact.userShortName FROM JobOwner INNER JOIN Contact ON JobOwner.contactID = Contact.contactID where JobOwner.staffRoleID = " + ddlRole.SelectedValue + " and JobOwner.jobOwnerStatusID = 3 Order By Contact.userShortName", "ContactID", "userShortName");
        
        }
        else
        {
            ddlJobNo.Items.Clear();
            PopulateDropDownBox(ddlJobNo, "SELECT DISTINCT JobOwner.jobID, JobOwner.jobNo, JobOwner.jobOwnerStatusID FROM  JobOwner INNER JOIN   Contact ON JobOwner.contactID = Contact.contactID WHERE   (JobOwner.jobOwnerStatusID = 3)  ORDER BY JobOwner.jobNo", "jobID", "jobNo");

            ddlQS.Items.Clear();
            PopulateDropDownBox(ddlQS, "SELECT DISTINCT JobOwner.contactID, Contact.userShortName FROM JobOwner INNER JOIN Contact ON JobOwner.contactID = Contact.contactID where  JobOwner.jobOwnerStatusID = 3 Order By Contact.userShortName", "ContactID", "userShortName");
        
        
        }
          
    }


    // ================================================== Sorting ===========================================================================


    protected void SortRecords(object sender, GridViewSortEventArgs e)
    {
       
    }
    public SortDirection SortDirection
    {
        get
        {
            if (ViewState["SortDirection"] == null)
            {
                ViewState["SortDirection"] = SortDirection.Ascending;
            }
            return (SortDirection)ViewState["SortDirection"];
        }
        set
        {
            ViewState["SortDirection"] = value;
        }
    }

    // ==================================================  ===========================================================================


    protected void gvJoborder_Sorting(object sender, GridViewSortEventArgs e)
    {
        string sortExpression = e.SortExpression;
        string direction = string.Empty;

        if (SortDirection == SortDirection.Ascending)
        {
            SortDirection = SortDirection.Descending;
            direction = " DESC";
        }
        else
        {
            SortDirection = SortDirection.Ascending;
            direction = " ASC";
        }     

       DataTable table = (DataTable)Session["CommittedInfo"];

        table.DefaultView.Sort = sortExpression + direction;
        gvJoborder.DataSource = table;
        gvJoborder.DataBind();


       // Session["CommittedInfo"] = table;
      
    }
}