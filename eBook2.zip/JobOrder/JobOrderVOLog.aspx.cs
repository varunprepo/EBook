﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Datalayer;
using System.Data;
using System.Data.SqlClient;

public partial class JobOrder_JobOrderVOLog : System.Web.UI.Page
{
    int _jobID = 0; int _jobVOID = 0;
    string connValue = System.Configuration.ConfigurationManager.ConnectionStrings["EBSDEBookConn"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
    {
        
    }
    protected void Page_Init(object sender, EventArgs e)
    {
        _jobID = Convert.ToInt32(Request.QueryString["JobID"]);
        _jobVOID = Convert.ToInt32(Request.QueryString["jobVOID"]);

        Session["StakjobID"] = Convert.ToInt32(Request.QueryString["JobID"]);
        // txtJobNo.Text = Request.QueryString["PSAJobNo"];

        //PSAprjCode
        Session["JobNo"] = Request.QueryString["PSAJobNo"];
        lblJobNo.Text = Session["JobNo"].ToString();
        Session["PrjCode"] = Request.QueryString["PSAprjCode"];

        lblPrjCode.Text = Session["PrjCode"].ToString();

        if (Session["VoSIID"]!=null)
          lblVOSIID.Text = Session["VoSIID"].ToString();

        if (!IsPostBack)
        {
            PopulateDropDownBox(drpVODesc, "SELECT voID, voDesc FROM VoCategory ORDER BY voDesc", "voID", "voDesc");

            PopulateDropDownBox(drpVODescTime, "SELECT voID, voDesc FROM VoCategory ORDER BY voDesc", "voID", "voDesc");

            PopulateDropDownBox(drpSH, "SELECT  stakeID, stakeholderName FROM  StakeHolder ORDER BY stakeholderName", "stakeID", "stakeholderName");

            FillTab2(_jobID);

            getMinistryData(_jobID);

            //gridload_SH();

          //  trVOCat.Visible = false;
        }
        gridload_SH();

    }
    private void PopulateDropDownBox(DropDownList ddlBox, string sqlQuery, string valueMember, string displayName)
    {
        DataTable table = new DataTable();
        try
        {
            using (SqlConnection sqlConn = new SqlConnection(connValue))
            {
                using (SqlDataAdapter da = new SqlDataAdapter(sqlQuery, sqlConn))
                {
                    sqlConn.Open();
                    da.Fill(table);
                }
            }
            //cmbBox.Items.Add("Select");

            ddlBox.DataSource = table;
            ddlBox.DataTextField = displayName;
            ddlBox.DataValueField = valueMember;

            ddlBox.SelectedIndex = -1;
            ddlBox.DataBind();

            ddlBox.Items.Insert(0, new ListItem("--Select--"));
        }
        catch (System.Exception ex)
        {
            throw ex;
        }
    }

    public void getMinistryData(int jobID)
    {
        string qry = " SELECT ministryCode,budgetRefNo,provisionNo From Job where JobID =  " + jobID;
        using (SqlConnection cn = new SqlConnection(connValue))
        {
            using (SqlCommand cmd = new SqlCommand())
            {
                cmd.Connection = cn;
                cmd.CommandText = qry;
                cmd.CommandType = CommandType.Text;

                cn.Open();

                using (SqlDataReader dr = cmd.ExecuteReader())
                {
                    while (dr.Read())
                    {
                        txtMinCode.Text = dr["ministryCode"].ToString();
                        txtBudgetRef.Text = dr["budgetRefNo"].ToString();
                        txtProvNo.Text = dr["provisionNo"].ToString();
                    }
                }
            }
        }
    }
    private void FillTab2(int _jobID)
    {
        try
        {
            DataSet ds = new DataSet();
            ds = (new JobOrderData().GetDDlDetails_JOBVOSI_Time(_jobID));

            //   Convert.ToInt32(txtjobid.Text), txtJobNo.Text, Convert.ToInt32(txtaffair.Text), Convert.ToInt32(txtdept.Text), txtprojcode.Text, txtprojtitle.Text, Convert.ToInt32(txtconsult.Text)));

            if (ds.Tables[0].Rows.Count == 0)
            {
                ds.Tables[0].Rows.Add(ds.Tables[0].NewRow());
            }
            else
            {
                grvJObLog.DataSource = ds;
                grvJObLog.DataBind();
            }            
        }
        catch (Exception ex)
        {

        }
    }   
    protected void btnSave_Click(object sender, EventArgs e)
    {  
        int _voID = 0;

        if (lblVOSIID.Text != "")
            _voID = Convert.ToInt32(lblVOSIID.Text);
        else
            _voID = 0;
        
        int voCatID = 0; int voTimeCatID = 0;

        if (drpVODesc.SelectedIndex !=0)
           voCatID = Convert.ToInt32(drpVODesc.SelectedValue);

        if (drpVODescTime.SelectedIndex != 0)
            voTimeCatID = Convert.ToInt32(drpVODescTime.SelectedValue);

        Boolean chkVOActive = true;
         chkVOActive = chkActive.Checked;

        // We have to pass contract amount whre name as consultamount : dont change

         //new JobOrderData().AddUpade_JOBVOandSI(_voID, _jobID, txtCntrAmnt.Text, txtContractTime.Text, txtPmcAmnt.Text, txtPmcTime.Text, txtEbsdAmnt.Text, txtEbsdTime.Text, txtCnsltAmnt.Text, txtCnsltTime.Text, txtVO.Text, txtSI.Text, txtIssueDate.Text, txtPrjIssueDate.Text, txtRemarks.Text, Session["UserName"].ToString(), "", voCatID, chkVOActive, voTimeCatID,txtRemarksTime.Text);            
       
        ClearData();
        FillTab2(_jobID);
    }
    private void ClearData()
    {
        txtCntrAmnt.Text = "";
        txtCnsltAmnt.Text = "";
        txtPmcAmnt.Text = "";
        txtEbsdAmnt.Text = "";

        txtContractTime.Text = "";
        txtCnsltTime.Text = "";
        txtPmcTime.Text = "";
        txtEbsdTime.Text = "";
        txtRemarks.Text = "";

        lblVOSIID.Text = "";

        txtVO.Text = "";
        txtSI.Text = "";

        txtIssueDate.Text = "";
        txtPrjIssueDate.Text = "";

        drpVODesc.SelectedIndex = -1;
        drpVODescTime.SelectedIndex = -1;

    }
    protected void btnAdd_Click(object sender, EventArgs e)
    {
        Panel1.Visible = true;
        trstake.Visible = false;
        ClearData();
    }
    protected void grvJObLog_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "ViewEdit")
        {
            string arguments = e.CommandArgument.ToString();
            string[] args = arguments.Split(';');
            if (args[0] != "")
            {
                Panel1.Visible = true;
                int _void = Convert.ToInt32(args[0]);
                getVOData(_void);

                Session["VoSIID"] = _void.ToString();

                gridload_SH();

                trstake.Visible = true;
            }
        }      
    }
    protected void grvJObLog_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        GridViewRow gr = (GridViewRow)grvJObLog.Rows[e.RowIndex];
        Label txtid = (Label)gr.FindControl("lbljobVOID");
        if (txtid.Text != "")
        {
            new JobOrderData().Delete_PSALog(Convert.ToInt32(txtid.Text));
            FillTab2(_jobID);
        }
    }
    protected void grvJObLog_RowEditing(object sender, GridViewEditEventArgs e)
    {

    }
    protected void grvJObLog_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {

    }
    protected void LinkButton_Click(Object sender, EventArgs e)
    {
        if (lblVOSIID.Text != "")
        {
            LinkButton txtBox = (sender as LinkButton);
            Session["txtName"] = txtBox.ClientID;
            Session["JobAdmID"] = lblVOSIID.Text;

            string url = "StakeHolder.aspx?jobVOID = <%#Eval(jobVOID)%>";  //subject=<%#Eval("Address") %>"
            string s = "window.open('" + url + "', 'popup_window', 'width=600,height=600,left=100,top=100,resizable=yes');";
            ClientScript.RegisterStartupScript(this.GetType(), "script", s, true);
        }
    }

    private void getVOData(int _void) // Job Order
    {
        string qry = " SELECT jobVOID, jobID, contractorAmt, contractorEOT, pmcAmt, pmcEOT, consultantAmt, consultantEOT, ebsdAmt, ebsdEOT, invSH,voNumber,siNumber, " + 
        " REPLACE(CONVERT(NVARCHAR, issueDate, 106), ' ', '/') as issueDate,REPLACE(CONVERT(NVARCHAR, prjCompleteDate, 106), ' ', '/') as prjCompleteDate,  " +
                     " remarks,voCatID,VoIssuedate,isVOActive,voTimeCatID FROM JobVOSI WHERE (jobVOID = " + _void + ") ";                

        using (SqlConnection cn = new SqlConnection(connValue))
        {
            using (SqlCommand cmd = new SqlCommand())
            {

                cmd.Connection = cn;
                cmd.CommandText = qry;
                cmd.CommandType = CommandType.Text;

                cn.Open();

                using (SqlDataReader dr = cmd.ExecuteReader())
                {
                    while (dr.Read())
                    {
                        txtVO.Text = dr["voNumber"].ToString();
                        txtSI.Text = dr["siNumber"].ToString();

                        txtIssueDate.Text = dr["issueDate"].ToString();
                        txtPrjIssueDate.Text = dr["prjCompleteDate"].ToString();

                        txtCntrAmnt.Text = dr["contractorAmt"].ToString();
                        txtCnsltAmnt.Text = dr["consultantAmt"].ToString();
                        txtPmcAmnt.Text = dr["pmcAmt"].ToString();
                        txtEbsdAmnt.Text = dr["ebsdAmt"].ToString();

                        txtContractTime.Text = dr["contractorEOT"].ToString();
                        txtCnsltTime.Text = dr["consultantEOT"].ToString();
                        txtPmcTime.Text = dr["pmcEOT"].ToString();
                        txtEbsdTime.Text = dr["ebsdEOT"].ToString();

                        txtRemarks.Text = dr["remarks"].ToString();

                        lblVOSIID.Text = dr["jobVOID"].ToString();

                        if (dr["voCatID"].ToString()!="")
                          drpVODesc.SelectedValue = dr["voCatID"].ToString();

                        if (dr["voTimeCatID"].ToString() != "")
                          drpVODescTime.SelectedValue = dr["voTimeCatID"].ToString();

                        if (dr["isVOActive"].ToString().Equals("True"))
                           chkActive.Checked = true;
                        else
                           chkActive.Checked = false;
                    }
                }
            }
        }
    }
    protected void txtMinCode_TextChanged(object sender, EventArgs e)
    {
        new JobOrderData().UpdateMinistryDataForJob(0, txtMinCode.Text, txtBudgetRef.Text, txtProvNo.Text, lblPrjCode.Text);
    }
    protected void txtBudgetRef_TextChanged(object sender, EventArgs e)
    {
        new JobOrderData().UpdateMinistryDataForJob(0, txtMinCode.Text, txtBudgetRef.Text, txtProvNo.Text, lblPrjCode.Text);
    }
    protected void txtProvNo_TextChanged(object sender, EventArgs e)
    {
        new JobOrderData().UpdateMinistryDataForJob(0, txtMinCode.Text, txtBudgetRef.Text, txtProvNo.Text, lblPrjCode.Text);
    }

    protected void txtIssueDate_TextChanged(object sender, EventArgs e)
    {

    }
    protected void txtPrjIssueDate_TextChanged(object sender, EventArgs e)
    {

    }
    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (lblVOSIID.Text != "")
        {
            Session["JobAdmID"] = lblVOSIID.Text;
            if (drpSH.SelectedIndex != 0)
                new JobOrderData().Add_ddlStakeInfo_StakeHolder(1, Convert.ToInt32(lblVOSIID.Text), Convert.ToInt32(drpSH.SelectedValue), _jobID, Session["UserName"].ToString());

            drpSH.SelectedIndex = 0;
            gridload_SH();          
        }
    }
    public void gridload_SH()
    {
        if (lblVOSIID.Text != "")
        {
            DataSet ds = new DataSet();
            ds = (new JobOrderData().GetDDlDetails_StakeHolder(Convert.ToInt32(lblVOSIID.Text)));
            GridView1.DataSource = ds;
            GridView1.DataBind();
        }
    }
    protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "delete")
        {
            string arguments = e.CommandArgument.ToString();
            string[] args = arguments.Split(';');

            string detID = args[0];
            //string jobid = args[1];
            //jobid = "1";

            new JobOrderData().Delete_ddlStakeInfo_StakeHolder(Convert.ToInt32(detID));
            gridload_SH();        
        }
    }
    protected void GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        gridload_SH();
    }
    protected void btnBack_Click(object sender, EventArgs e)
    {

    }
    protected void GridView1_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            //DropDownList l = (DropDownList)e.Row.FindControl("ddljobtype");

            //PopulateDropDownBox(l, "SELECT voID,voDesc FROM  VODetails  Order By voDesc ", "voID", "voDesc");  // where JobStatusid in(5,6,7,8)

            //TextBox lm = (TextBox)e.Row.FindControl("jobid");
            //TextBox afr = (TextBox)e.Row.FindControl("TextBox1");
            //TextBox InchargeID = (TextBox)e.Row.FindControl("txtInchargeID");

            //Session["InchargeID"] = InchargeID.Text;

            //string lk = lm.Text;
            //l.ToolTip = InchargeID.Text;

            //l.SelectedValue = afr.Text;

            //Session["StatusVal"] = l.SelectedValue;

            //l.SelectedIndexChanged += new EventHandler(SelectedIndexChanged);      

        }
    }

    protected void SelectedIndexChanged(object sender, EventArgs e)
    {
        DropDownList ddl = (DropDownList)sender;
        if (ddl.SelectedIndex != 0)
        {
            string ID = ddl.ID;
            string g = ddl.SelectedValue;
            string inchargeID = ddl.ToolTip;

            UpdateStakeData(Convert.ToInt32(ddl.SelectedValue), Convert.ToInt32(inchargeID));

            //new JobOrderData().UpdateJobStatus(Convert.ToInt32(inchargeID), Convert.ToInt32(ddl.SelectedValue), Session["UserName"].ToString());           
        }
    }

    private void UpdateStakeData(int catID,int stakID)
    {
        string qry = "Update StakeHolderInfo Set voCatID =@voCatID where infoID = @infoID";
        using (SqlConnection cn = new SqlConnection(connValue))
        {
            using (SqlCommand cmd = new SqlCommand())
            {

                cmd.Connection = cn;
                cmd.CommandText = qry;
                cmd.CommandType = CommandType.Text;

                cn.Open();

                cmd.Parameters.AddWithValue("@voCatID", catID);
                cmd.Parameters.AddWithValue("@infoID", stakID);

                cmd.ExecuteNonQuery();

            }
        }
    }
}