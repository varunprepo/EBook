﻿using System;
using System.Collections.Generic;
using System.Linq;


using System.Web;
using System.Web.UI;
using System.Web.UI.DataVisualization.Charting;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using Datalayer;

using Oracle.ManagedDataAccess.Client;
using System.Data;
using System.Drawing;

public partial class JobOrder_SurveyDefaultWindow : System.Web.UI.Page
{
    string connValue = System.Configuration.ConfigurationManager.ConnectionStrings["EBSDEBookConn"].ConnectionString;
    string connValueOracle = System.Configuration.ConfigurationManager.ConnectionStrings["SurveyConnOracle"].ToString();


    IList<string> userRightsColl = null;
    string profile_Name = string.Empty;
    UtilityClass uCls = null;

    static int _currentUserID = 0; 
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["UserName"] == null)
        {
            Response.Redirect("~/LoginPage.aspx", false);
            return;
        }

        TextBox3.Text = Session["systemUserName"].ToString();      

        _currentUserID = Convert.ToInt32(Session["UserID"]);

        userRightsColl = (IList<string>)Session["UserRightsColl"];

        if (!IsPostBack)
        {
            getOnGoingTasksofSurveyOracle();   

            getUnReadInchargeDataOgSurveyOracle();

            if (Session["userProfileID"].ToString().Equals("12"))             //  Survey Admin
            {
               // onGoingTasksPerStaffChart.Visible = false;

                trStaff.Visible = false;
                trDCSurvey.Disabled = true;
            }
            else
            {
                getOnGoingTasksPerStaffChartForSurvey();
                onGoingTasksPerStaffChart.Visible = true;
                trDCSurvey.Visible = true;
            }
            
            getOverDueSurveyRequestOracle();


        }      

       // Label3.Text = "Cureent UserID " + _currentUserID + "  UserRightsCount " + userRightsColl.Count;  
    }

    private void getOnGoingTasksofSurveyOracle()
    {
        DataSet dsTndr = new DataSet();

        string sqlQuery = null; int secID = Convert.ToInt32(Session["SectionID"]);
        string strSeriesName = string.Empty;

        if (Session["userProfileID"].ToString().Equals("12"))   // For Admin          if (Session["UserProfileID"].Equals("12"))
        {
            //sqlQuery = "select Count(SURVEY_INFO.request_id) as JobCnt, SURVEY_INFO.status from SURVEY_INFO INNER JOIN app_resource_allocation ON " + 
            //                   " SURVEY_INFO.request_ID =app_resource_allocation.request_id  WHERE app_resource_allocation.user_id = '"+ Session["SystemUserName"].ToString() +"' and  SURVEY_INFO.status Not IN ('CLOSED','Old','CANCEL' ) group by SURVEY_INFO.status";


            sqlQuery = "Select Count(SURVEY_INFO.request_id) as JobCnt, app_resource_allocation.state_ID as status from SURVEY_INFO INNER JOIN app_resource_allocation ON " +
                 " SURVEY_INFO.request_ID =app_resource_allocation.request_id  WHERE app_resource_allocation.user_id = '" + Session["SystemUserName"].ToString() + "' and app_resource_allocation.state_ID NOT IN ('CLOSED','SURVEY COMPLETE','RESEARCH COMPLETE') group by app_resource_allocation.state_ID";
           
            strSeriesName = "sectionName";

            lblOngoingSurvey.Text = "My Survey Process Details";
        }
        else
        {
            //sqlQuery = "select Count(status) as JobCnt, status from survey_info where status Not IN ('CLOSED','Old','CANCEL' ) group by status";

            //sqlQuery = "select Count(status) as JobCnt, status from survey_info where request_time >= TO_DATE('01/JAN/2017','dd/mon/yyyy') and status IN ('OPEN','IN RESEARCH','RESEARCH COMPLETE','IN SURVEY','IN DATA PROCESSING','SURVEY COMPLETE','CLOSED','CANCEL') group by status " +
            //" order  by case when status = 'OPEN' then 1 " +
            //" when status = 'IN RESEARCH' then 2 " +
            //" when status = 'RESEARCH COMPLETE' then 3 " +
            //" when status = 'IN SURVEY' then 4 " +
            //" when status = 'IN DATA PROCESSING' then 5 " +
            //" when status = 'SURVEY COMPLETE' then 6 " +
            //" when status = 'CLOSED' then 7 " +
            //" when status = 'CANCEL' then 8 " + 
            //" else null end "; request_id >2017001             request_time >= TO_DATE('01/JAN/17','dd/mon/yyyy')

            sqlQuery = "select Count(status) as JobCnt, status from survey_info where Request_id >2017001  and status IN ('OPEN','IN RESEARCH','RESEARCH COMPLETE','IN SURVEY','IN DATA PROCESSING','SURVEY COMPLETE','CLOSED','CANCEL') group by status " +
            " order  by case when status = 'OPEN' then 1 " +
            " when status = 'IN RESEARCH' then 2 " +
            " when status = 'RESEARCH COMPLETE' then 3 " +
            " when status = 'IN SURVEY' then 4 " +
             " when status = 'IN DATA PROCESSING' then 5 " +
            " when status = 'SURVEY COMPLETE' then 6 " +
             " when status = 'CLOSED' then 7 " +
             " when status = 'CANCEL' then 8 " +
           " else null end ";


            strSeriesName = "sectionName";
            lblOngoingSurvey.Text = "Survey Process Details for the Year 2017";
        }

        OracleDataAdapter daTndr = new OracleDataAdapter(sqlQuery, connValueOracle);
        daTndr.Fill(dsTndr);

        if (dsTndr.Tables[0].Rows.Count != 0)
        {
            onGoingTasksofSurvey0.DataSource = dsTndr.Tables[0].DefaultView;

            onGoingTasksofSurvey0.Series["Series1"].XValueMember = "status";
            onGoingTasksofSurvey0.Series["Series1"].YValueMembers = "JobCnt";

            dsTndr.Tables.Clear();

            onGoingTasksofSurvey0.ChartAreas[0].AxisX.MajorGrid.Enabled = false;
            onGoingTasksofSurvey0.ChartAreas[0].AxisX.MinorGrid.Enabled = false;
            onGoingTasksofSurvey0.ChartAreas[0].AxisY.MajorGrid.Enabled = false;
            onGoingTasksofSurvey0.ChartAreas[0].AxisY.MinorGrid.Enabled = false;

            onGoingTasksofSurvey0.ChartAreas[0].AxisX.LabelStyle.Angle = 30;
            onGoingTasksofSurvey0.ChartAreas[0].AxisX.LabelStyle.ForeColor = Color.Maroon;

            onGoingTasksofSurvey0.ChartAreas[0].AxisX.Interval = 1;
        }
    }


    private void getUnReadInchargeDataOgSurveyOracle()
    {
        string sqlQuery = string.Empty;

        sqlQuery = "select request_id as jobOwnerID, user_id as IssuedBy, state_id as jobTypeName, TO_CHAR(start_date,'DD/Mon/YYYY') as DateOfIssue, '' as referenceNo, User_comments, '' as jobCatID,'' as payID,'' as JobID  " +
                                   "  from app_resource_allocation Where User_id = '" + Session["systemUserName"].ToString() + "' AND app_resource_allocation.STATE_ID IN ('OPEN','IN RESEARCH','IN DATA PROCESSING','IN SURVEY') Order by request_id Desc";

        OracleConnection objCon = new OracleConnection(connValueOracle);
        OracleCommand objCmd = new OracleCommand(sqlQuery, objCon);
        OracleDataAdapter objDA = new OracleDataAdapter(objCmd);

        objDA.SelectCommand.CommandText = objCmd.CommandText.ToString();
        DataTable dt = new DataTable();
        objDA.Fill(dt);

        Session["getPayData"] = dt;

        if (dt.Rows.Count != 0)
            gridTasks.DataSource = dt.DefaultView;
        else
        {
            gridTasks.DataSource = null;
            gridTasks.Visible = false;
        }
        gridTasks.DataBind();

        lblTask.Text = "My New Task";
    }

    private void getOnGoingTasksPerStaffChartForSurvey()   // chart 3
    {
        string sqlQuery = string.Empty; string strStaff = string.Empty;

        DataSet dsTndr = new DataSet();
        int sectionID = Convert.ToInt32(Session["SectionID"]);

        if (Session["userProfileID"].ToString().Equals("12"))     // Survey Control Staff
        {
            sqlQuery = "Select COUNT(app_resource_allocation.USER_ID) as JobCnt,APP_SCRTY_USERS.NAME as userShortName from app_resource_allocation INNER JOIN APP_SCRTY_USERS ON app_resource_allocation.USER_ID = APP_SCRTY_USERS.USER_ID " + 
                " where app_resource_allocation.state_id In ('OPEN','IN RESEARCH','IN DATA PROCESSING','IN SURVEY')  group by APP_SCRTY_USERS.NAME ";
            
            lblOngoingStaff.Text = "On Going Tasks Per Staff In Survey Section";
        }
        else
        {
            lblOngoingStaff.Text = "On Going Tasks Per Staff In EBSD " + Session["SectionName"].ToString();

            sqlQuery = "Select COUNT(app_resource_allocation.USER_ID) as JobCnt,APP_SCRTY_USERS.NAME as userShortName from app_resource_allocation INNER JOIN APP_SCRTY_USERS ON app_resource_allocation.USER_ID = APP_SCRTY_USERS.USER_ID " + 
                " where app_resource_allocation.state_id In ('OPEN','IN RESEARCH','IN DATA PROCESSING','IN SURVEY') group by APP_SCRTY_USERS.NAME ";
        }

        OracleDataAdapter daTndr = new OracleDataAdapter(sqlQuery, connValueOracle);
        daTndr.Fill(dsTndr);
        if (dsTndr.Tables[0].Rows.Count != 0)
        {
            onGoingTasksPerStaffChart.DataSource = dsTndr.Tables[0].DefaultView;
            onGoingTasksPerStaffChart.Series["Series1"].XValueMember = "userShortName";
            onGoingTasksPerStaffChart.Series["Series1"].YValueMembers = "JobCnt";
            dsTndr.Tables.Clear();

            onGoingTasksPerStaffChart.ChartAreas[0].AxisX.MajorGrid.Enabled = false;
            onGoingTasksPerStaffChart.ChartAreas[0].AxisX.MinorGrid.Enabled = false;
            onGoingTasksPerStaffChart.ChartAreas[0].AxisY.MajorGrid.Enabled = false;
            onGoingTasksPerStaffChart.ChartAreas[0].AxisY.MinorGrid.Enabled = false;

            onGoingTasksPerStaffChart.ChartAreas[0].AxisX.LabelStyle.Angle = 30;
            onGoingTasksPerStaffChart.ChartAreas[0].AxisX.LabelStyle.ForeColor = Color.Maroon;

            onGoingTasksPerStaffChart.ChartAreas[0].AxisX.Interval = 1;
        }
    }

    protected void lnkNewSurvey_Click(object sender, EventArgs e)
    {
        Session["ClickedOn"] = "~/JobOrder/SurveyDefaultWindow.aspx";
        Response.Redirect("~/Survey/AddNewSurvey.aspx", false);
    }
    protected void lnkSearchSurvey_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/Survey/SearchSurveyLog.aspx", false);
    }
    protected void lnkOnGoingSurvey_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/Survey/ViewSurveyInfo.aspx", false);
    }

    protected void onGoingTasksofSurvey_Click(object sender, ImageMapEventArgs e)
    {
        string sectionName = Session["SectionName"].ToString();

        Session["OverDueName"] = e.PostBackValue.ToString();

        Session["OnGoingJobStatus"] = e.PostBackValue;

        if (Session["SectionID"].Equals("4"))
        {
            Response.Redirect("~/Survey/SurveyProcessGraphInfo.aspx", false);
        }
        else
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "Popup", "<script>alert('Restricted Access!')</script>", false);
        }
    }

    protected void onGoingTasksPerStaffChart_Click(object sender, ImageMapEventArgs e)
    {
        //Session["OnGoingJobStatus"] = e.PostBackValue;
        // int cntID = getContactID(e.PostBackValue.ToString());

        Session["ShortName"] = e.PostBackValue.ToString();

        if (!Session["SectionID"].Equals("4"))
            Response.Redirect("~/JobOrder/SearchAllJobs.aspx", false);
        else
            Response.Redirect("~/Survey/SurveyStaffJobs.aspx", false);

    }
    protected void onGoingTasksPerStaffChart_Load(object sender, EventArgs e)
    {

    }
    protected void onGoingTasksofSurvey_Load(object sender, EventArgs e)
    {

    }
    protected void gridTasks_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {

    }
    protected void lnkBtnJobID_Click(object sender, EventArgs e)
    {   
        string strUpdateJob = Request.Url.AbsoluteUri;
        Session["UrlRef"] = strUpdateJob;
        try
        {           
            LinkButton lnkJobID = (LinkButton)sender;          
            GridViewRow gvr = (GridViewRow)lnkJobID.NamingContainer;

            Session["REQUEST_ID"] = lnkJobID.ToolTip;

            if (Session["SectionID"].ToString().Equals("4"))
            {
                Response.Redirect("~/Survey/SurveyDetails.aspx?REQUEST_ID= " + Session["REQUEST_ID"] + "", false);
            }            
        }
        catch (Exception ex)
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Error occurred while processing the request')</script>", false);
        }
    }
    protected void overDueSurveys_Click(object sender, ImageMapEventArgs e)
    {
        string sectionName = Session["SectionName"].ToString();

        Session["OverDueName"] = e.PostBackValue.ToString();

        Session["OnGoingJobStatus"] = e.PostBackValue;

        if (Session["SectionID"].Equals("4"))
        {
            Response.Redirect("~/Survey/OverDueRequest.aspx", false);
        }
        else
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "Popup", "<script>alert('Restricted Access!')</script>", false);
        }
    }
    protected void overDueSurveys_Load(object sender, EventArgs e)
    {

    }
    private void getOverDueSurveyRequestOracle()   
    {
        string sqlQuery = string.Empty; string strStaff = string.Empty;

        DataSet dsTndr = new DataSet();
        int sectionID = Convert.ToInt32(Session["SectionID"]);

        if (Session["UserProfileID"].Equals("12"))
        {
            sqlQuery = "Select COUNT(SURVEY_INFO.Request_ID) as JobCnt, SURVEY_INFO.purpose from  SURVEY_INFO INNER JOIN app_resource_allocation ON SURVEY_INFO.request_ID =app_resource_allocation.request_id " +
               " WHERE app_resource_allocation.user_id = '" + Session["systemUserName"].ToString() + "' and SURVEY_INFO.expected_comp_date < current_date and app_resource_allocation.state_ID in('OPEN','IN RESEARCH','IN DATA PROCESSING','IN SURVEY') group by SURVEY_INFO.purpose";

            lblOverDue.Text = "My Over Due Survey Request";            
        }
        else
        {
            sqlQuery = "Select COUNT(*) as JobCnt, purpose from survey_info where expected_comp_date < current_date and status in('OPEN','IN RESEARCH','IN DATA PROCESSING','IN SURVEY') group by purpose ";

            lblOverDue.Text = "Over Due Survey Request";
        }
        

        OracleDataAdapter daTndr = new OracleDataAdapter(sqlQuery, connValueOracle);
        daTndr.Fill(dsTndr);
        if (dsTndr.Tables[0].Rows.Count != 0)
        {
            overDueSurveysCharts.DataSource = dsTndr.Tables[0].DefaultView;
            overDueSurveysCharts.Series["Series1"].XValueMember = "purpose";
            overDueSurveysCharts.Series["Series1"].YValueMembers = "JobCnt";
            dsTndr.Tables.Clear();

            overDueSurveysCharts.ChartAreas[0].AxisX.MajorGrid.Enabled = false;
            overDueSurveysCharts.ChartAreas[0].AxisX.MinorGrid.Enabled = false;
            overDueSurveysCharts.ChartAreas[0].AxisY.MajorGrid.Enabled = false;
            overDueSurveysCharts.ChartAreas[0].AxisY.MinorGrid.Enabled = false;

            overDueSurveysCharts.ChartAreas[0].AxisX.LabelStyle.Angle = 30;
            overDueSurveysCharts.ChartAreas[0].AxisX.LabelStyle.ForeColor = Color.Maroon;

            overDueSurveysCharts.ChartAreas[0].AxisX.Interval = 1;
        }
        else
        {
            overDueSurveysCharts.Visible = false;
        }
    }
    protected void lnkOnGoingSurvey_DC_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/Survey/DCLogForSurvey.aspx", false);
    }

    protected void lnkAddKPI_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/GIS/AddKPI.aspx", false);
    }
}