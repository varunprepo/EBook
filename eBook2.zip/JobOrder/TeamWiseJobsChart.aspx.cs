﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;

public partial class JobOrder_TeamWiseJobsChart : System.Web.UI.Page
{
    string connValue = System.Configuration.ConfigurationManager.ConnectionStrings["EBSDEBookConn"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    private void getOnGoingTasksPerStaffChart(string sqlQuery)   
    {    

        DataSet dsTndr = new DataSet();
        int sectionID = Convert.ToInt32(Session["SectionID"]);       

        SqlDataAdapter daTndr = new SqlDataAdapter(sqlQuery, connValue);
        daTndr.Fill(dsTndr);
        if (dsTndr.Tables[0].Rows.Count != 0)
        {
            TeamwiseChart.DataSource = dsTndr.Tables[0].DefaultView;
            TeamwiseChart.Series["Series1"].XValueMember = "TeamLeader";
            TeamwiseChart.Series["Series1"].YValueMembers = "JobCnt";
            dsTndr.Tables.Clear();

            TeamwiseChart.ChartAreas[0].AxisX.MajorGrid.Enabled = false;
            TeamwiseChart.ChartAreas[0].AxisX.MinorGrid.Enabled = false;
            TeamwiseChart.ChartAreas[0].AxisY.MajorGrid.Enabled = false;
            TeamwiseChart.ChartAreas[0].AxisY.MinorGrid.Enabled = false;

            TeamwiseChart.ChartAreas[0].AxisX.LabelStyle.Angle = 30;
            TeamwiseChart.ChartAreas[0].AxisX.LabelStyle.ForeColor = Color.Maroon;

            TeamwiseChart.ChartAreas[0].AxisX.Interval = 1;
        }
    }
    protected void btnGraph_Click(object sender, EventArgs e)
    {

    }
    protected void onGoingTasksPerStaffChart_Load(object sender, EventArgs e)
    {
        string strQuery = "SELECT  COUNT(JobOwner.contactID) AS JobCnt, EBSDTeamLeaders.teamLeaderName AS TeamLeader FROM  JobOwner INNER JOIN  Contact ON JobOwner.contactID = Contact.contactID INNER JOIN  EBSDTeamLeaders ON Contact.teamLeaderID = EBSDTeamLeaders.teamLeaderID GROUP BY EBSDTeamLeaders.teamLeaderName ORDER BY JobCnt";
        getOnGoingTasksPerStaffChart(strQuery);
    }
    protected void txtdept_TextChanged(object sender, EventArgs e)
    {

    }
    protected void ddlTeamLead_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void onGoingTasksPerStaffChart_Click(object sender, ImageMapEventArgs e)
    {

    }
}