﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.DataVisualization.Charting;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using Datalayer;

using Oracle.ManagedDataAccess.Client;

public partial class JobOrder_DefaultWindow : System.Web.UI.Page
{
    string connValue = System.Configuration.ConfigurationManager.ConnectionStrings["EBSDEBookConn"].ConnectionString;
    string connValueOracle = System.Configuration.ConfigurationManager.ConnectionStrings["SurveyConnOracle"].ToString();


    IList<string> userRightsColl =null;
    string profile_Name = string.Empty;
    UtilityClass uCls = null;

    static int _currentUserID = 0;


    private void getOnGoingManager_TasksPerStaffChart()   // chart 3
    {
        string sqlQuery = string.Empty; string strStaff = string.Empty;

        DataSet dsTndr = new DataSet();
        int sectionID = Convert.ToInt32(Session["SectionID"]);

        if (Session["userProfileID"].ToString().Equals("1"))
        {
           // sqlQuery = "SELECT   COUNT(*) AS JobCnt, Contact.firstName as userShortName FROM   Contact INNER JOIN  Job ON Contact.contactID = Job.dcID  WHERE (Job.sectionID = 10) GROUP BY Contact.firstName ORDER BY Contact.firstName";

            sqlQuery = "SELECT   COUNT(*) AS JobCnt, Contact.userShortName, JobOwner.jobPurposeID FROM   JobOwner INNER JOIN   Contact ON JobOwner.contactID = Contact.contactID WHERE (JobOwner.sectionID = 10) AND (JobOwner.jobOwnerStatusID = 3)" +
                "GROUP BY JobOwner.contactID, Contact.userShortName, JobOwner.jobPurposeID HAVING  (JobOwner.jobPurposeID <> 18) ORDER BY Contact.userShortName ";
            
            lblOngoingStaff.Text = "On Going Tasks Per Staff In All Sections Of EBSD";
        }       
        else
        {
            lblOngoingStaff.Text = "On Going Tasks Per Staff In EBSD " + Session["SectionName"].ToString();

            //sqlQuery = "SELECT COUNT(*) AS JobCnt, Contact.userShortName FROM  JobOwner INNER JOIN  Contact ON JobOwner.contactID = Contact.contactID " +
            //          " WHERE  (JobOwner.sectionID = " + sectionID + ") AND (JobOwner.jobOwnerStatusID = 3) GROUP BY JobOwner.contactID, Contact.userShortName ORDER BY Contact.userShortName";


            sqlQuery = "SELECT   COUNT(*) AS JobCnt, Contact.userShortName, JobOwner.jobPurposeID FROM   JobOwner INNER JOIN   Contact ON JobOwner.contactID = Contact.contactID WHERE (JobOwner.sectionID = 10) AND (JobOwner.jobOwnerStatusID = 3)" +
                "GROUP BY JobOwner.contactID, Contact.userShortName, JobOwner.jobPurposeID HAVING  (JobOwner.jobPurposeID <> 18) ORDER BY Contact.userShortName ";
        
        }

        SqlDataAdapter daTndr = new SqlDataAdapter(sqlQuery, connValue);
        daTndr.Fill(dsTndr);
        if (dsTndr.Tables[0].Rows.Count != 0)
        {
            onGoingTaskMngr.DataSource = dsTndr.Tables[0].DefaultView;
            onGoingTaskMngr.Series["Series1"].XValueMember = "userShortName";
            onGoingTaskMngr.Series["Series1"].YValueMembers = "JobCnt";
            dsTndr.Tables.Clear();

            onGoingTaskMngr.ChartAreas[0].AxisX.MajorGrid.Enabled = false;
            onGoingTaskMngr.ChartAreas[0].AxisX.MinorGrid.Enabled = false;
            onGoingTaskMngr.ChartAreas[0].AxisY.MajorGrid.Enabled = false;
            onGoingTaskMngr.ChartAreas[0].AxisY.MinorGrid.Enabled = false;

            onGoingTaskMngr.ChartAreas[0].AxisX.LabelStyle.Angle = 30;
            onGoingTaskMngr.ChartAreas[0].AxisX.LabelStyle.ForeColor = Color.Maroon;

            onGoingTaskMngr.ChartAreas[0].AxisX.Interval = 1;
        }
    }

    private void getOnGoingManager_TasksPerCoordinatorChart()   // chart 3
    {
        string sqlQuery = string.Empty; string strStaff = string.Empty;

        DataSet dsTndr = new DataSet();
        int sectionID = Convert.ToInt32(Session["SectionID"]);

        if (Session["userProfileID"].ToString().Equals("1"))
        {
            sqlQuery = "SELECT  COUNT(*) AS JobCnt, Contact.userShortName FROM Job INNER JOIN Contact ON Job.projCoordinatorID = Contact.contactID " + 
               " WHERE (Job.sectionID = 10) GROUP BY Job.projCoordinatorID, Job.jobStatusID, Contact.userShortName HAVING (Job.jobStatusID = 3)";

            lblOngoingStaff.Text = "On Going Tasks Per Staff In All Sections Of EBSD";
        }
        else if (!userRightsColl.Contains("42") && Session["SectionID"].ToString().Equals("7")) //1 - All Sections
        {
            sqlQuery = "SELECT COUNT(*) AS JobCnt, Contact.userShortName FROM JobOwner INNER JOIN Contact ON JobOwner.contactID = Contact.contactID WHERE (JobOwner.jobOwnerStatusID = 3) GROUP BY JobOwner.contactID, Contact.userShortName ORDER BY Contact.userShortName";
            lblOngoingStaff.Text = "On Going Tasks Per Staff In All Sections Of EBSD";
        }
        else
        {
            lblOngoingStaff.Text = "On Going Tasks Per Staff In EBSD " + Session["SectionName"].ToString();

            sqlQuery = "SELECT COUNT(*) AS JobCnt, Contact.userShortName FROM JobOwner INNER JOIN  Contact ON JobOwner.contactID = Contact.contactID " + 
                 "WHERE (JobOwner.sectionID = 10) AND (JobOwner.jobOwnerStatusID = 3) GROUP BY JobOwner.contactID, Contact.userShortName, JobOwner.jobPurposeID HAVING (JobOwner.jobPurposeID = 18) ORDER BY Contact.userShortName";
        }

        SqlDataAdapter daTndr = new SqlDataAdapter(sqlQuery, connValue);
        daTndr.Fill(dsTndr);
        if (dsTndr.Tables[0].Rows.Count != 0)
        {
            onGoingTaskMngrCoord.DataSource = dsTndr.Tables[0].DefaultView;

            onGoingTaskMngrCoord.Series["Series1"].XValueMember = "userShortName";
            onGoingTaskMngrCoord.Series["Series1"].YValueMembers = "JobCnt";

            dsTndr.Tables.Clear();

            onGoingTaskMngrCoord.ChartAreas[0].AxisX.MajorGrid.Enabled = false;
            onGoingTaskMngrCoord.ChartAreas[0].AxisX.MinorGrid.Enabled = false;
            onGoingTaskMngrCoord.ChartAreas[0].AxisY.MajorGrid.Enabled = false;
            onGoingTaskMngrCoord.ChartAreas[0].AxisY.MinorGrid.Enabled = false;

            onGoingTaskMngrCoord.ChartAreas[0].AxisX.LabelStyle.Angle = 30;
            onGoingTaskMngrCoord.ChartAreas[0].AxisX.LabelStyle.ForeColor = Color.Maroon;

            onGoingTaskMngrCoord.ChartAreas[0].AxisX.Interval = 1;
        }
    }    

    protected void Page_Load(object sender, EventArgs e)
    {
        //UpdateDocumentActionDueDate();

        if (Session["UserName"] == null)
        {
            Response.Redirect("~/LoginPage.aspx", false);
            return;
        }

        if (!connValue.Contains("eBookProductionDB"))
            lblTestDb.Text = "This is Testdatabase" + connValue.Substring(0, 79);
        else
            lblTestDb.Visible = false;

        _currentUserID = Convert.ToInt32(Session["UserID"]);
        userRightsColl = (IList<string>)Session["UserRightsColl"];

        if (!IsPostBack)
        {
            PageloadData();
 
            trchart.Visible = false;
            trchart12.Visible = false;        // -       payment Chart

            //trNon.Visible = false;
            //trNonEBD.Visible = false;      // Non EBD   

           // getPayAffairWiseChart();

          //  // Impotant Function : Which used to change docStatus as Forfollowup, if actionduedate is lessthan current date globally

           new JobOrderData().UpdateForFoloowupDocstatus();
           new JobOrderData().UpdateUserAutoReplyStatus();

         //  getOnGoingSurveyTasks();

           //if ((Session["SectionID"].ToString().Equals("1")) || (Session["userProfileID"].Equals("1")))
           //    getAlertJobData(); 

          //  getStaffStatus();

           if (Session["userProfileID"].Equals("1"))
           {
               TableNewTask.Visible = false;
               TableOngoingTaskChart.Visible = false;

               PanelAdminReport.Visible = true;
               trClearButton.Visible = false;

               surChart456.Visible = false;

               trCP.Visible = false;
               trNCP.Visible = false;

               trAddSur.Visible = false;
               trNewJob.Visible = false;

               trchartTeamLead.Visible = true; // TeamLead

               string sqlQueryYear = "SELECT COUNT(Job.jobID) AS jobCnt, YEAR(Job.jobReceivedDate) AS Year FROM   JobVOSI INNER JOIN    Job ON JobVOSI.jobID = Job.jobID INNER JOIN " +
                           " JobType ON Job.jobTypeID = JobType.jobTypeID WHERE  (JobType.CategoryID IN (4)) GROUP BY YEAR(Job.jobReceivedDate)";

               PopulateDropDownBox(ddlYear, sqlQueryYear, "Year", "Year");

               string sqlQueryDept = "SELECT COUNT(Job.jobID) AS jobCnt, Job.deptID, Department.deptName FROM     JobVOSI INNER JOIN    Job ON JobVOSI.jobID = Job.jobID INNER JOIN " +
                            " JobType ON Job.jobTypeID = JobType.jobTypeID INNER JOIN Department ON Job.deptID = Department.departmentID  WHERE  (JobType.CategoryID IN (4)) GROUP BY Job.deptID, Department.deptName ORDER BY Department.deptName";

               PopulateDropDownBox(ddlDept, sqlQueryDept, "deptID", "deptName");

               string strAffair = "SELECT COUNT(Job.jobID) AS jobCnt, Department_1.deptName AS AffairName, Department_1.departmentID AS AffairID FROM  JobVOSI INNER JOIN  Job ON JobVOSI.jobID = Job.jobID INNER JOIN " +
                      " JobType ON Job.jobTypeID = JobType.jobTypeID INNER JOIN   Department ON Job.deptID = Department.departmentID INNER JOIN   Department AS Department_1 ON Department.affairID = Department_1.departmentID " +
                       " WHERE   (JobType.CategoryID IN (4)) GROUP BY Department_1.deptName, Department_1.departmentID ORDER BY AffairName";

               PopulateDropDownBox(ddlAffair, strAffair, "AffairID", "AffairName");

               string strMinistry = "SELECT Job.ministryCode FROM  JobVOSI INNER JOIN Job ON JobVOSI.jobID = Job.jobID INNER JOIN JobType ON Job.jobTypeID = JobType.jobTypeID WHERE  (JobType.CategoryID IN (4))  GROUP BY Job.ministryCode HAVING   (Job.ministryCode IS NOT NULL)";
               PopulateDropDownBox(ddlMinistry, strMinistry, "ministryCode", "ministryCode");

               string strBudRef = "SELECT Job.budgetRefNo  FROM  JobVOSI INNER JOIN   Job ON JobVOSI.jobID = Job.jobID INNER JOIN JobType ON Job.jobTypeID = JobType.jobTypeID WHERE  (JobType.CategoryID IN (4))  GROUP BY Job.budgetRefNo  HAVING   (Job.budgetRefNo  IS NOT NULL)";
               PopulateDropDownBox(ddlBudget, strBudRef, "budgetRefNo", "budgetRefNo");

               string strProvision = "SELECT Job.provisionNo  FROM  JobVOSI INNER JOIN   Job ON JobVOSI.jobID = Job.jobID INNER JOIN JobType ON Job.jobTypeID = JobType.jobTypeID WHERE  (JobType.CategoryID IN (4))  GROUP BY Job.provisionNo  HAVING   (Job.provisionNo  IS NOT NULL)";
               PopulateDropDownBox(ddlProv, strProvision, "provisionNo", "provisionNo");

               gCostEstimateChart();
               CostEstimateReport();
               gCostEstimateJobCountChart();              

               TextBox1.Text = fillCostEstimateAboveBudget().Rows[0][0].ToString();
               TextBox2.Text = fillCostEstimateBelowBudget().Rows[0][0].ToString();
           }
           else
           {
               trchartTeamLead.Visible = false; //TeamLead
           }

            Session["docSender"] = null;      // add sender from document form 

            //ModuleWiseControls();
            if (Session["SectionID"].ToString().Equals("7"))
            {

            }
            if (Session["SectionID"].ToString().Equals("3"))
            { 
                //// Job

               // trAdmSrch.Disabled = true;
               // trJobSrch.Disabled = true;                

                //// Pay

                //trPaySrch.Disabled = true;
                //trCP.Disabled = true;
                //trNCP.Disabled = true;

                trAdmSrch.Visible = false;
                trPaySrch.Visible = false;
                trCP.Visible = false;
                trNCP.Visible = false;

                trAddSur.Visible = false;
                trSearchSur.Visible = false;
                trOngSur.Visible = false;

                trLnkMngr.Visible = false;
                trLnkMngrRpt.Visible = false;

                trmngrChartCoord.Visible = false;
                lblOngoingPrjCoord.Visible = false;


                trmngrChart.Visible = false;
                lblOngoingMngr.Visible = false;

                trNewMngr.Visible = false;

                trSR_main.Visible = false;

                trSRLead.Visible = false;

            }
            else if (Session["SectionID"].ToString().Equals("9"))   // BS
            {               

                trAdmSrch.Visible = false;
                trPaySrch.Visible = false;
                trCP.Visible = false;
                trNCP.Visible = false;

                trAddSur.Visible = false;
                trSearchSur.Visible = false;
                trOngSur.Visible = false;

                trLnkMngr.Visible = false;
                trLnkMngrRpt.Visible = false;

                trmngrChartCoord.Visible = false;
                lblOngoingPrjCoord.Visible = false;


                trmngrChart.Visible = false;
                lblOngoingMngr.Visible = false;
                trNewMngr.Visible = false;

                getUnReadIncharge_LeadData();

               // trSRLead.Visible = true;

            }
           else if (Session["SectionID"].ToString().Equals("2"))
           {
                //// Job

                //trAdmSrch.Disabled = true;
                //trJobSrch.Disabled = true;
                //trNewJob.Disabled = true;

                trAdmSrch.Visible = false;
                trJobSrch.Visible = false;
                trNewJob.Visible = false;

               // trDueJobs.Disabled = true;

                //// Pay

                //trPaySrch.Disabled = false;
                //trCP.Disabled = false;
                //trNCP.Disabled = false;


                trPaySrch.Visible = true;
                trCP.Visible = true;
                trNCP.Visible = true;

               // DC Log

               // trDCSrch.Disabled = true;    

                trAddSur.Visible = false;
                trSearchSur.Visible = false;
                trOngSur.Visible = false;

                trLnkMngr.Visible = false;
                trLnkMngrRpt.Visible = false;

                trmngrChartCoord.Visible = false;
                lblOngoingPrjCoord.Visible = false;


                trmngrChart.Visible = false;
                lblOngoingMngr.Visible = false;
                trNewMngr.Visible = false;

                trSR_main.Visible = false;
                trSRLead.Visible = false;
               
            }
            else if (Session["SectionID"].ToString().Equals("1"))
            {
                //// Job

               // trAdmSrch.Disabled = false;
               //   trJobSrch.Disabled = false;
              

                //// Pay

                //trPaySrch.Disabled = true;
                //trCP.Disabled = true;
                //trNCP.Disabled = true;


                trNon.Visible = true;
                trNonEBD.Visible = true;      // Non EBD         

                trAdmSrch.Visible = true;
                trJobSrch.Visible = true;


                trPaySrch.Visible = false;
                trCP.Visible = false;
                trNCP.Visible = false;

                trAddSur.Visible = false;
                trSearchSur.Visible = false;
                trOngSur.Visible = false;

                // DC Log

              //  trDCSrch.Disabled = true;

                trLnkMngr.Visible = false;
                trLnkMngrRpt.Visible = false;

                trmngrChartCoord.Visible = false;
                lblOngoingPrjCoord.Visible = false;


                trmngrChart.Visible = false;
                lblOngoingMngr.Visible = false;
                trNewMngr.Visible = false;

                trSR_main.Visible = false;
                trSRLead.Visible = false;
            }
            else if (Session["SectionID"].ToString().Equals("4"))
            {
                //// Job

                // trAdmSrch.Disabled = false;
                //   trJobSrch.Disabled = false;

                //// Pay

                //trPaySrch.Disabled = true;
                //trCP.Disabled = true;
                //trNCP.Disabled = true;

                trAdmSrch.Visible = false;
                trJobSrch.Visible = false;
                trNewJob.Visible = false;               

                trPaySrch.Visible = false;
                trCP.Visible = false;
                trNCP.Visible = false;

                trSR_main.Visible = false;

                trNewMngr.Visible = false;
                trSRLead.Visible = false;

                // DC Log

                //  trDCSrch.Disabled = true;
            }  
        }

        //else if (Session["SectionID"].Equals("10"))
        //{
        //    surChart.Visible = true;
        //    getOnGoingTasksofSurveyOracle();
        //}

        if (Session["SectionID"].Equals("4"))
        {
            surChart.Visible = true;
            getOnGoingTasksofSurveyOracle();
        }        
        else
        {
            surChart.Visible = false;
        }

        if (Session["SectionID"].ToString().Equals("10") || Session["userProfileID"].Equals("1"))
        {
            getOnGoingManager_TasksPerStaffChart();
            Visible_Tablerows();

            trchartStaff.Visible = false;
            trlblStaff.Visible = false;

            trchartTeamLead.Visible = false;
            trchartTeamLead123.Visible = false;

            trSR_main.Visible = false;

            getOnGoingManager_TasksPerCoordinatorChart();

           
        }
        else
        {
            //trchartStaff.Visible = false;
            //trlblStaff.Visible = false;
        }


        Label3.Text = "Cureent UserID " + _currentUserID + "  UserRightsCount " + userRightsColl.Count;  

    }
    private void ModuleWiseControls()
    {
        if (Session["SectionID"].ToString().Equals("3"))
        {
            trRpt.Disabled = true;

            // Job

            trAdmSrch.Disabled = true;
            trJobSrch.Disabled = true;

            // Pay

            trPaySrch.Disabled = true;
            trCP.Disabled = true;
            trNCP.Disabled = true;           
        } 
    }
    private void PageloadData()
    {
        getMyDocumentChart();     

        getUnreadDocumentDataFromNonEBD();

        if (Session["SectionID"].Equals("4"))
            getUnReadInchargeDataOgSurveyOracle();
        else if (Session["UserProfileID"].Equals("1"))
        {

        }
        else
            getUnReadInchargeData();

        getOnGoingTasksPerSection_New();      //Ongoing or Over due jobs Chart - first one

        if (!userRightsColl.Contains("42") && !Session["SectionID"].Equals("4"))
        {
            getOnGoingTasksPerStaffChart();
            getOnGoingJobsByTeamLead();
        }
        else if (!userRightsColl.Contains("42") && Session["SectionID"].Equals("4"))
        {
            getOnGoingTasksPerStaffChartForSurvey();
        }
        else
        {
            trlblStaff.Visible = false;
            trchartStaff.Visible = false;
        }

        if (userRightsColl.Contains("1"))
            lnKShowAll.Visible = false;
    }
    private void PopulateDropDownBox(DropDownList ddlBox, string sqlQuery, string valueMember, string displayName)
    {
        ddlBox.DataBound += new EventHandler(this.ddlBox_DataBound);
        ddlBox.DataSource = new JobOrderData().FillDropdown(sqlQuery);
        ddlBox.DataTextField = displayName;
        ddlBox.DataValueField = valueMember;
        ddlBox.SelectedIndex = -1;
        ddlBox.DataBind();
    }
    protected void ddlBox_DataBound(object sender, EventArgs e)
    {
        DropDownList ddl = (DropDownList)sender;
        ListItem emptyItem = new ListItem("", "");
        ddl.Items.Insert(0, emptyItem);
    }
    private DataTable CostEstimateReport()
    {
        //JobVOSI.contractorAmt,(JobVOSI.ebsdAmt + JobVOSI.contractorAmt)

        System.Threading.Thread.CurrentThread.CurrentCulture = new System.Globalization.CultureInfo("ar-QA");
        
        //string sqlQuery = "SELECT Job.contractNo, Job.projectTitle, JobVOSI.budgetAmnt, JobVOSI.pmcAmt, JobVOSI.ebsdAmt , JobVOSI.contractorAmt, (JobVOSI.contractorAmt-JobVOSI.ebsdAmt)/JobVOSI.contractorAmt as EBSD_ratio, " +
        //            "(JobVOSI.contractorAmt-JobVOSI.budgetAmnt)/JobVOSI.contractorAmt as Budget_ratio" + 
        //            " FROM JobVOSI INNER JOIN Job ON JobVOSI.jobID = Job.jobID INNER JOIN  JobType ON Job.jobTypeID = JobType.jobTypeID WHERE (JobType.CategoryID IN (4, 7))";

        DataTable dt = new DataTable();
        using (SqlConnection objCon = new SqlConnection(connValue))
        {
            using (SqlCommand objCmd = new SqlCommand())
            {
                objCmd.CommandType = CommandType.StoredProcedure;
                objCmd.Connection = objCon;
                objCmd.CommandText = "CostEstimateReport";

                SqlDataAdapter objDA = new SqlDataAdapter(objCmd);

                objDA.SelectCommand.CommandText = objCmd.CommandText.ToString();

                objDA.Fill(dt);

                gvCostEstimate.DataSource = dt;
                gvCostEstimate.DataBind();

                
            }
        }

        return dt;        
    }
    private void getStaffStatus()
    {        

        string sqlQuery = "SELECT  JobOwner.jobOwnerID,JobOwner.jobNo, Contact.firstName, JobStatus.jobStatusName, JobOwner.isTLApprove, Contact.teamLeaderID, JobOwner.remarks,   JobOwner.jobOwnerStatusID, JobOwner.JobTypeID, JobType.CategoryID, " +
        "JobOwner.actionDueDate,JobOwner.jobID FROM   JobOwner INNER JOIN  Contact ON JobOwner.contactID = Contact.contactID INNER JOIN   JobStatus ON JobOwner.jobOwnerStatusID = JobStatus.jobStatusID INNER JOIN  JobType ON JobOwner.JobTypeID = JobType.jobTypeID " +
                     " WHERE (Contact.teamLeaderID = " + Session["teamLeaderID"] + ") AND (JobOwner.isTLApprove = 0) AND (JobOwner.jobOwnerStatusID <> 7)";

        SqlConnection objCon = new SqlConnection(connValue);
        SqlCommand objCmd = new SqlCommand(sqlQuery, objCon);
        SqlDataAdapter objDA = new SqlDataAdapter(objCmd);

        objDA.SelectCommand.CommandText = objCmd.CommandText.ToString();
        DataTable dt = new DataTable();
        objDA.Fill(dt);

        gridStaffStatus.DataSource = dt;
        gridStaffStatus.DataBind();
    }
    private void gCostEstimateJobCountChart()
    {
        DataSet dsDoc = new DataSet();

        string sqlQuery = null;

        sqlQuery = "SELECT COUNT(Job.jobID) AS jobCnt, YEAR(Job.jobReceivedDate) AS Year FROM   JobVOSI INNER JOIN    Job ON JobVOSI.jobID = Job.jobID INNER JOIN " + 
                        " JobType ON Job.jobTypeID = JobType.jobTypeID WHERE  (JobType.CategoryID IN (4)) GROUP BY YEAR(Job.jobReceivedDate)";

        SqlDataAdapter daDoc = new SqlDataAdapter(sqlQuery, connValue);
        daDoc.Fill(dsDoc);
        if (dsDoc.Tables[0].Rows.Count != 0)
        {
            chartCostJobCnt.DataSource = dsDoc.Tables[0].DefaultView;
            chartCostJobCnt.Series["Series1"].XValueMember = "Year";
            chartCostJobCnt.Series["Series1"].YValueMembers = "jobCnt";        

            dsDoc.Tables.Clear();

            chartCostJobCnt.ChartAreas[0].AxisX.MajorGrid.Enabled = false;
            chartCostJobCnt.ChartAreas[0].AxisX.MinorGrid.Enabled = false;
            chartCostJobCnt.ChartAreas[0].AxisY.MajorGrid.Enabled = false;
            chartCostJobCnt.ChartAreas[0].AxisY.MinorGrid.Enabled = false;

            chartCostJobCnt.ChartAreas[0].AxisX.LabelStyle.Angle = 30;
            chartCostJobCnt.ChartAreas[0].AxisX.LabelStyle.ForeColor = Color.Maroon;

            chartCostJobCnt.ChartAreas[0].AxisX.Interval = 1;
        }
    }

    
    private void gCostEstimateChart()
    {
        DataSet dsDoc = new DataSet();

        string sqlQuery = null;

        sqlQuery = "SELECT JobType.CategoryID, SUM(JobVOSI.budgetAmnt) AS BudgetAmnt, SUM(JobVOSI.pmcAmt) AS PMCAmnt, SUM(JobVOSI.ebsdAmt) AS EBSDAmnt, SUM(JobVOSI.contractorAmt) " +
                        " AS ContractAmnt FROM JobVOSI INNER JOIN   Job ON JobVOSI.jobID = Job.jobID INNER JOIN    JobType ON Job.jobTypeID = JobType.jobTypeID WHERE (JobType.CategoryID IN (4)) GROUP BY JobType.CategoryID";

        SqlDataAdapter daDoc = new SqlDataAdapter(sqlQuery, connValue);
        daDoc.Fill(dsDoc);

        if (dsDoc.Tables[0].Rows.Count > 0)
        {
            Session["TotalBudget"] = dsDoc.Tables[0].Rows[0][1].ToString();
            Session["TotalPMC"] = dsDoc.Tables[0].Rows[0][2].ToString();
            Session["TotalEbsd"] = dsDoc.Tables[0].Rows[0][3].ToString();
            Session["TotalAward"] = dsDoc.Tables[0].Rows[0][4].ToString();
        }

        if (dsDoc.Tables[0].Rows.Count != 0)
        {
            chartCostEstimate.DataSource = dsDoc.Tables[0].DefaultView;
        
            chartCostEstimate.Series["Series2"].XValueMember = "CategoryID";
            chartCostEstimate.Series["Series2"].YValueMembers = "PMCAmnt";

            chartCostEstimate.Series["Series3"].XValueMember = "CategoryID";
            chartCostEstimate.Series["Series3"].YValueMembers = "EBSDAmnt";

            chartCostEstimate.Series["Series1"].XValueMember = "CategoryID";
            chartCostEstimate.Series["Series1"].YValueMembers = "BudgetAmnt";


            chartCostEstimate.Series["Series4"].XValueMember = "CategoryID";
            chartCostEstimate.Series["Series4"].YValueMembers = "ContractAmnt";

            dsDoc.Tables.Clear();

            chartCostEstimate.ChartAreas[0].AxisX.MajorGrid.Enabled = false;
            chartCostEstimate.ChartAreas[0].AxisX.MinorGrid.Enabled = false;
            chartCostEstimate.ChartAreas[0].AxisY.MajorGrid.Enabled = false;
            chartCostEstimate.ChartAreas[0].AxisY.MinorGrid.Enabled = false;

            chartCostEstimate.ChartAreas[0].AxisX.LabelStyle.Angle = 30;
            chartCostEstimate.ChartAreas[0].AxisX.LabelStyle.ForeColor = Color.Maroon;

            chartCostEstimate.ChartAreas[0].AxisX.Interval = 1;
        }
    }   
   
    
    private void getAlertJobData()
    {
        if (Session["Opened"].ToString() == "False")        //if (Application["UsersOnline"].ToString() == "0")
        {
            Application["UsersOnline"] = 1;
            Session["Opened"] = "True";
                
                                
            for (int i = 0; i < 2; i++)
            {
                if (i == 0)
                {                    
                    if (FillGridView_Details() == true)
                    {
                        string url = "OverDueJobs.aspx";   // OverDueAddendum.aspx               //OverDueJobs
                        string s = "window.open('" + url + "', 'popup_window', 'width=900,height=700,left=100,top=100,resizable=yes,scrollbars=0');";
                        ClientScript.RegisterStartupScript(this.GetType(), "script", s, true);
                    }                    
                }
                else
                {
                    if (!userRightsColl.Contains("16"))
                    {
                        if (FillOverDueAdmData() == true)
                        {
                            string url123 = "OverDueAddendum.aspx";   // OverDueAddendum.aspx               //OverDueJobs
                             string s123 = "window.open('" + url123 + "', 'popup_window123', 'width=800,height=600,left=100,top=100,resizable=yes,scrollbars=0');";
                            ClientScript.RegisterStartupScript(this.GetType(), "script", s123, true);
                        }
                    }
                }
            }
        } 
    }
    private Boolean FillGridView_Details()
    {
        string sqlQuery = "SELECT JobOwner.jobNo, JobType.jobTypeName, JobOwner.staffIssueDate AS DateReceived, JobOwner.actionDueDate, " +
                         " Contact.firstName + ' ' + Contact.lastName AS IssuedBy, JobOwner.contactID, JobOwner.jobOwnerStatusID, JobOwner.JobTypeID " +
                              " FROM  JobOwner INNER JOIN   Contact ON JobOwner.distributedBy = Contact.contactID INNER JOIN  JobType ON JobOwner.JobTypeID = JobType.jobTypeID " +
                                  " WHERE (JobOwner.contactID = " + Convert.ToInt32(Session["userID"]) + ") AND (JobOwner.jobOwnerStatusID = 3) AND (JobOwner.actionDueDate < GETDATE())";

       //string sqlQuery = "SELECT JobOwner.jobNo, JobType.jobTypeName, JobOwner.staffIssueDate AS DateReceived, JobOwner.actionDueDate,   Contact.firstName + ' ' + Contact.lastName AS IssuedBy, JobOwner.contactID, JobOwner.jobOwnerStatusID " +
       //       " FROM  JobOwner INNER JOIN   Contact ON JobOwner.distributedBy = Contact.contactID INNER JOIN  JobType ON JobOwner.jobOwnerCatID = JobType.jobTypeID WHERE  
        //(JobOwner.contactID =" + Convert.ToInt32(Session["userID"]) + ") AND (JobOwner.jobOwnerStatusID = 3)  AND (JobOwner.actionDueDate < GETDATE())";

        SqlConnection objCon = new SqlConnection(connValue);
        SqlCommand objCmd = new SqlCommand(sqlQuery, objCon);
        SqlDataAdapter objDA = new SqlDataAdapter(objCmd);

        objDA.SelectCommand.CommandText = objCmd.CommandText.ToString();
        DataTable dt = new DataTable();
         objDA.Fill(dt);

         if (dt.Rows.Count>0)
                return true;
         else
             return false;
    }
    private Boolean FillOverDueAdmData()
    {
        //string sqlQuery = "SELECT Job.jobID,Job.jobNo, JobStatus.jobStatusName, Job.contractNo, Job.addendumNO, JobAddendumInfo.AlertReminderMsg FROM JobAddendumInfo INNER JOIN Job ON JobAddendumInfo.jobID = Job.jobID INNER JOIN " +
        //               " JobStatus ON Job.jobStatusID = JobStatus.jobStatusID WHERE (Contact.contactID = " + Convert.ToInt32(Session["userID"]) + ") AND (JobAddendumInfo.AlertDate >= GETDATE())";

        //string sqlQuery = "SELECT JobStatus.jobStatusName, JobAddendumInfo.AlertReminderMsg, JobOwner.contactID FROM  JobAddendumInfo INNER JOIN    JobOwner ON JobAddendumInfo.jobID = JobOwner.jobID INNER JOIN " +
        //  " JobStatus ON JobOwner.jobOwnerStatusID = JobStatus.jobStatusID WHERE (JobAddendumInfo.AlertDate >= GETDATE()) AND (JobOwner.contactID = 58)";

        string sqlQuery = "SELECT Job.jobNo, JobStatus.jobStatusName, Job.contractNo, Job.addendumNO, JobAddendumInfo.AlertReminderMsg FROM jobAddendumInfo INNER JOIN   Job ON JobAddendumInfo.jobID = Job.jobID INNER JOIN " +
                       "  JobStatus ON Job.jobStatusID = JobStatus.jobStatusID WHERE (JobAddendumInfo.AlertDate <= GETDATE() AND JobAddendumInfo.AlertDate IS NOT NULL)";
        

        SqlConnection objCon = new SqlConnection(connValue);
        SqlCommand objCmd = new SqlCommand(sqlQuery, objCon);
        SqlDataAdapter objDA = new SqlDataAdapter(objCmd);

        objDA.SelectCommand.CommandText = objCmd.CommandText.ToString();
        DataTable dt = new DataTable();
        objDA.Fill(dt);

        if (dt.Rows.Count > 0)
            return true;
        else
            return false;
    }
    private void BindGvData()
    {
        //gvData.DataSource = GetChartData();
        //gvData.DataBind();
    } 
    private void FillDocumentsForSections()
    {
        string sqlQuery = string.Empty; string strTitle = string.Empty;

        int secID = Convert.ToInt32(Session["SectionID"]);

        if (Session["userProfileID"].Equals("1")) //&& Session["userProfileID"].ToString() != "1"      //(Session["SectionID"].Equals("50"))
        {
            //sqlQuery = "SELECT COUNT([Document].documentID) AS docCount, DocumentStatus.docStatusName FROM [Document] INNER JOIN DocumentStatus ON [Document].docStatusID = DocumentStatus.docStatusID INNER JOIN " +
            //"Users ON [Document].originContactID = Users.contactID INNER JOIN Contact ON [Document].originContactID = Contact.contactID INNER JOIN Section ON Contact.sectionID = Section.sectionID WHERE (Contact.sectionID = 39) AND ([Document].docStatusID <> 4) " +
            //"GROUP BY DocumentStatus.docStatusName UNION ALL SELECT COUNT(DocumentDistribution.documentID) AS docCount, DocumentStatus_1.docStatusName FROM DocumentDistribution INNER JOIN [Document] AS Document_1 ON Document_1.documentID = DocumentDistribution.documentID AND " +
            //"DocumentDistribution.contactID <> Document_1.originContactID INNER JOIN DocumentStatus AS DocumentStatus_1 ON DocumentDistribution.docStatusID = DocumentStatus_1.docStatusID INNER JOIN Users AS Users_1 ON DocumentDistribution.contactID = Users_1.contactID INNER JOIN " +
            //"Contact AS Contact_1 ON DocumentDistribution.contactID = Contact_1.contactID INNER JOIN Section AS Section_1 ON Contact_1.sectionID = Section_1.sectionID WHERE (DocumentDistribution.docStatusID <> 4) AND (Contact_1.sectionID =" + secID + ") " +
            //"GROUP BY DocumentStatus_1.docStatusName";

            sqlQuery = "SELECT  COUNT(DocumentDistribution.distributeID) AS docCount, DocumentStatus.docStatusName FROM    DocumentDistribution INNER JOIN " +
                       "  Contact ON DocumentDistribution.contactID = Contact.contactID AND DocumentDistribution.contactID = Contact.contactID INNER JOIN " +
                        " DocumentStatus ON DocumentDistribution.docStatusID = DocumentStatus.docStatusID WHERE  (DocumentStatus.docStatusID <> 4) GROUP BY DocumentStatus.docStatusName";


          ///  lblAllDoc.Text = "Documents In All Sections of EBSD";
        }
        else if (Session["SectionID"].Equals("7") & userRightsColl.Contains("1"))
        {
            //sqlQuery = "SELECT COUNT([Document].documentID) AS docCount, DocumentStatus.docStatusName FROM [Document] INNER JOIN DocumentStatus ON [Document].docStatusID = DocumentStatus.docStatusID INNER JOIN " +
            //"Users ON [Document].originContactID = Users.contactID INNER JOIN Contact ON [Document].originContactID = Contact.contactID INNER JOIN Section ON Contact.sectionID = Section.sectionID WHERE (Contact.sectionID = 39) AND ([Document].docStatusID <> 4) " +
            //"GROUP BY DocumentStatus.docStatusName UNION ALL SELECT COUNT(DocumentDistribution.documentID) AS docCount, DocumentStatus_1.docStatusName FROM DocumentDistribution INNER JOIN [Document] AS Document_1 ON Document_1.documentID = DocumentDistribution.documentID AND " +
            //"DocumentDistribution.contactID <> Document_1.originContactID INNER JOIN DocumentStatus AS DocumentStatus_1 ON DocumentDistribution.docStatusID = DocumentStatus_1.docStatusID INNER JOIN Users AS Users_1 ON DocumentDistribution.contactID = Users_1.contactID INNER JOIN " +
            //"Contact AS Contact_1 ON DocumentDistribution.contactID = Contact_1.contactID INNER JOIN Section AS Section_1 ON Contact_1.sectionID = Section_1.sectionID WHERE (DocumentDistribution.docStatusID <> 4) " +
            //"GROUP BY DocumentStatus_1.docStatusName";

            sqlQuery = "SELECT  COUNT(DocumentDistribution.distributeID) AS docCount, DocumentStatus.docStatusName FROM    DocumentDistribution INNER JOIN " +
                      "  Contact ON DocumentDistribution.contactID = Contact.contactID AND DocumentDistribution.contactID = Contact.contactID INNER JOIN " +
                       " DocumentStatus ON DocumentDistribution.docStatusID = DocumentStatus.docStatusID WHERE  (DocumentStatus.docStatusID <> 4) GROUP BY DocumentStatus.docStatusName";


           // lblAllDoc.Text = "Documents In All Sections of EBSD";
        }
        else
        {
            sqlQuery = "SELECT  COUNT(DocumentDistribution.distributeID) AS docCount, DocumentStatus.docStatusName FROM   DocumentDistribution INNER JOIN  Contact ON DocumentDistribution.contactID = Contact.contactID AND DocumentDistribution.contactID = Contact.contactID INNER JOIN " +
                         " DocumentStatus ON DocumentDistribution.docStatusID = DocumentStatus.docStatusID WHERE   (DocumentStatus.docStatusID <> 4) AND (Contact.sectionID = " + secID + ") GROUP BY DocumentStatus.docStatusName";

            //lblAllDoc.Text = "All Documents in " + Session["SectionName"].ToString();
        }


        SqlConnection objCon = new SqlConnection(connValue);
        objCon.Open();
        SqlCommand objCmd = new SqlCommand(sqlQuery, objCon);
        SqlDataAdapter objDA = new SqlDataAdapter(objCmd);
        DataSet dsTndr123 = new DataSet();
        objDA.Fill(dsTndr123);

        if (dsTndr123.Tables[0].Rows.Count != 0)
        {
            chartSectionWiseDoc.DataSource = dsTndr123.Tables[0].DefaultView;
            chartSectionWiseDoc.Series["Series1"].XValueMember = "docStatusName";
            chartSectionWiseDoc.Series["Series1"].YValueMembers = "docCount";

            chartSectionWiseDoc.ChartAreas[0].AxisX.MajorGrid.Enabled = false;
            chartSectionWiseDoc.ChartAreas[0].AxisX.MinorGrid.Enabled = false;
            chartSectionWiseDoc.ChartAreas[0].AxisY.MajorGrid.Enabled = false;
            chartSectionWiseDoc.ChartAreas[0].AxisY.MinorGrid.Enabled = false;

            chartSectionWiseDoc.ChartAreas[0].AxisX.LabelStyle.Angle = 30;
            chartSectionWiseDoc.ChartAreas[0].AxisX.LabelStyle.ForeColor = Color.Maroon;

            chartSectionWiseDoc.ChartAreas[0].AxisX.Interval = 1;
        }
        objCon.Close();
    }
    private DataTable GetChartData()
    {
        DataSet dsData = new DataSet();
        try
        {
            SqlConnection sqlCon = new SqlConnection(connValue);
            SqlDataAdapter sqlCmd = new SqlDataAdapter("SELECT  COUNT(JobOwner.jobID) AS JobCnt, Contact.firstName FROM Contact INNER JOIN " +
            " JobOwner ON Contact.contactID = JobOwner.contactID GROUP BY Contact.firstName", sqlCon);

            sqlCmd.SelectCommand.CommandType = CommandType.Text;

            sqlCon.Open();

            sqlCmd.Fill(dsData);

            sqlCon.Close();
        }
        catch
        {
            throw;
        }
        return dsData.Tables[0];
    }    
    private DataTable GetOngoingJobsChartData()
    {
        DataSet dsData = new DataSet();
        try
        {
           
            string strQuery = "SELECT COUNT(JobOwner.jobOwnerID) AS JobCnt,Contact.firstName  FROM Contact INNER JOIN JobOwner ON Contact.contactID = JobOwner.contactID GROUP BY Contact.firstName";

          
            SqlConnection sqlCon = new SqlConnection(connValue);
            SqlDataAdapter sqlCmd = new SqlDataAdapter(strQuery, sqlCon);
            sqlCmd.SelectCommand.CommandType = CommandType.Text;
            sqlCon.Open();
            sqlCmd.Fill(dsData);
            sqlCon.Close();
        }
        catch
        {
            throw;
        }
        return dsData.Tables[0];
    }
    protected void lnkSearchMyDocs_Click(object sender, EventArgs e)
    {
        string strUpdateJob = Request.Url.AbsoluteUri;
        Session["UrlRef"] = strUpdateJob;
        //uCls = new UtilityClass(this.Page);
        //uCls.ResetTheSessionVariables();
        Session["SearchMyDocs"] = "1";
        Response.Redirect("~/Documents/SearchDocument.aspx", false);

    }
    protected void lnkGenerateReports_Click(object sender, EventArgs e)
    {
        string strUpdateJob = Request.Url.AbsoluteUri;
        Session["UrlRef"] = strUpdateJob;
        Response.Redirect("UnderProcess.aspx",false);
    }  
    protected void lnkBtnJobID_Click(object sender, EventArgs e)
    {
        Session["PayID"] = null;
        Session["JobID"] = null;
        Session["SRID"] = null;

        string strUpdateJob = Request.Url.AbsoluteUri;
        Session["UrlRef"] = strUpdateJob;
        try
        {
            //Get the LinkButton that raised the event
            LinkButton lnkJobID = (LinkButton)sender;
            //Get the row that contains this dropdown
            GridViewRow gvr = (GridViewRow)lnkJobID.NamingContainer;

            //Session["JobID"] = ((HtmlGenericControl)gvr.FindControl("divJobID")).InnerText;

            Session["SRID"]  = ((HtmlGenericControl)gvr.FindControl("divSRID")).InnerText;

            if ((Session["SRID"] != null) & (Session["SRID"] != ""))
            {
                Response.Redirect("~/Planning/SRDetails.aspx?SrJobID= " + Session["SRID"] + "", false);
                return;
            }
            else
            {
                Session["JobID"] = ((HtmlGenericControl)gvr.FindControl("divJobID")).InnerText;

                if (Session["JobID"] == null)
                    Session["PayID"] = ((HtmlGenericControl)gvr.FindControl("divPayID")).InnerText;

                if (Session["JobID"].ToString() == "")
                    Session["PayID"] = ((HtmlGenericControl)gvr.FindControl("divPayID")).InnerText;
            }


            Session["JobInchargeID"] = lnkJobID.ToolTip;

            if (Session["SectionID"].ToString().Equals("4"))
            {
                Response.Redirect("~/Survey/SurveyDetails.aspx?REQUEST_ID= " + Session["JobInchargeID"] + "", false);
            }
            else
            {
                if ((Session["PayID"] == null))
                {
                    Session["JobCatID"] = ((HtmlGenericControl)gvr.FindControl("divJobCatID")).InnerText;
                    UpdateJobOwner(Convert.ToInt32(lnkJobID.ToolTip));

                    string catID = ((HtmlGenericControl)gvr.FindControl("divJobCatID")).InnerText.Trim();

                    if (catID.Equals("1"))
                        Response.Redirect("~/JobOrder/PSAJobDetails.aspx?JobID= " + Session["JobID"] + "", false);
                    else if (catID.Equals("8"))
                        Response.Redirect("~/DCLog/DCDetails.aspx?JobID= " + Session["JobID"] + "", false);
                    else if (catID.Equals("46"))
                        Response.Redirect("~/ManagerTask/MngrTaskDetails.aspx?JobID= " + Session["JobID"] + "", false);
                    else
                        Response.Redirect("~/JobOrder/DefaultGrid.aspx?JobID= " + Session["JobID"] + "", false);
                }
                else
                {
                    Response.Redirect("~/Payments/PaymentDetails.aspx?PayID= " + Session["PayID"] + "", false);
                }
            }
        }
        catch (Exception ex)
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Error occurred while processing the request')</script>", false);
        }
    } 

    //protected void lnkBtnJobID_Click(object sender, EventArgs e)
    //{
    //    Session["PayID"] = null;
    //    Session["JobID"] = null; 
    //    Session["SRID"] =  null;

    //    string strUpdateJob = Request.Url.AbsoluteUri;
    //    Session["UrlRef"] = strUpdateJob;
    //    try
    //    {
    //        //Get the LinkButton that raised the event
    //        LinkButton lnkJobID = (LinkButton)sender;

    //        //Get the row that contains this dropdown
    //        GridViewRow gvr = (GridViewRow)lnkJobID.NamingContainer;

    //        Session["JobID"] = ((HtmlGenericControl)gvr.FindControl("divJobID")).InnerText;

    //        Session["SRID"] = ((HtmlGenericControl)gvr.FindControl("divSRID")).InnerText;

    //        if ((Session["SRID"] != null) & (Session["SRID"].ToString()!= ""))
    //        {
    //            Response.Redirect("~/Planning/SRDetails.aspx?JobID= " + Session["SRID"] + "", false);
    //            return;
    //        }
    //        else
    //        {
    //            Session["JobID"] = ((HtmlGenericControl)gvr.FindControl("divJobID")).InnerText;

    //            if (Session["JobID"] == null)
    //                Session["PayID"] = ((HtmlGenericControl)gvr.FindControl("divPayID")).InnerText;

    //            if (Session["JobID"].ToString() == "")
    //                Session["PayID"] = ((HtmlGenericControl)gvr.FindControl("divPayID")).InnerText;
    //        }

    //        Session["JobInchargeID"] = lnkJobID.ToolTip;

    //        if (Session["SectionID"].ToString().Equals("4"))
    //        {
    //            Response.Redirect("~/Survey/SurveyDetails.aspx?REQUEST_ID= " + Session["JobInchargeID"] + "", false);
    //        }
    //        else
    //        {
    //            if ((Session["PayID"] == null))
    //            {
    //                Session["JobCatID"] = ((HtmlGenericControl)gvr.FindControl("divJobCatID")).InnerText;

    //                UpdateJobOwner(Convert.ToInt32(lnkJobID.ToolTip));

    //                string catID = ((HtmlGenericControl)gvr.FindControl("divJobCatID")).InnerText.Trim();

    //                if (catID.Equals("1"))
    //                    Response.Redirect("~/JobOrder/PSAJobDetails.aspx?JobID= " + Session["JobID"] + "", false);
    //                else if (catID.Equals("8"))
    //                    Response.Redirect("~/DCLog/DCDetails.aspx?JobID= " + Session["JobID"] + "", false);
    //                else if (catID.Equals("46"))
    //                    Response.Redirect("~/ManagerTask/MngrTaskDetails.aspx?JobID= " + Session["JobID"] + "", false);
    //                else
    //                    Response.Redirect("~/JobOrder/DefaultGrid.aspx?JobID= " + Session["JobID"] + "", false);
    //            }
    //            else
    //            {
    //                Response.Redirect("~/Payments/PaymentDetails.aspx?PayID= " + Session["PayID"] + "", false);
    //            }
    //        }            
    //    }
    //    catch (Exception ex)
    //    {
    //        ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Error occurred while processing the request')</script>", false);        
    //    }
    //}


    protected void lnkBtnStaffStatus_Click(object sender, EventArgs e)
    {
        string strUpdateJob = Request.Url.AbsoluteUri;
        Session["UrlRef"] = strUpdateJob;
        try
        {
            //Get the LinkButton that raised the event
            LinkButton lnkJobID = (LinkButton)sender;
            //Get the row that contains this dropdown
            GridViewRow gvr = (GridViewRow)lnkJobID.NamingContainer;
            Session["JobID"] = ((HtmlGenericControl)gvr.FindControl("divJobID")).InnerText;
            Session["JobInchargeID"] = lnkJobID.ToolTip;

            Session["JobCatID"] = ((HtmlGenericControl)gvr.FindControl("divJobCatID")).InnerText;
            UpdateJobOwner(Convert.ToInt32(lnkJobID.ToolTip));

            string catID = ((HtmlGenericControl)gvr.FindControl("divJobCatID")).InnerText.Trim();

            if (catID.Equals("1"))
            {
                Response.Redirect("~/JobOrder/PSAJobDetails.aspx?JobID= " + Session["JobID"] + "", false);
            }
            else
            {
                Response.Redirect("~/JobOrder/DefaultGrid.aspx?JobID= " + Session["JobID"] + "", false);
            }

            // UpdateJob(Convert.ToInt32(Session["JobID"])); 
        }
        catch (Exception ex)
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Error occurred while processing the request')</script>", false);
        }
    }
    protected void lnkBtnDocReadDate_Click(object sender, EventArgs e)
    {
        string strUpdateJob = Request.Url.AbsoluteUri;
        Session["UrlRef"] = strUpdateJob;
        try
        {
            LinkButton lnkDistributrID = (LinkButton)sender;
            GridViewRow gvr = (GridViewRow)lnkDistributrID.NamingContainer;
            Session["distributeID"] = ((HtmlGenericControl)gvr.FindControl("divDistributeID")).InnerText;
            new JobOrderData().UpdateDistributionDateRead(Convert.ToInt32(((HtmlGenericControl)gvr.FindControl("divDistributeID")).InnerText),_currentUserID);
            int docid = Convert.ToInt32(((HtmlGenericControl)gvr.FindControl("divDocID")).InnerText);
            Response.Redirect("~/Documents/DocumentDetailsWindow.aspx?docRecID=" + docid + "&RecSentCatID=1", false);                       
        }
        catch (Exception ex)
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Error occurred while processing the request')</script>", false);
        }
    }   
    public void UpdateJobOwner(int jobInchargeID)
    {
        try
        {
            using (SqlConnection con = new SqlConnection(connValue))
            {
                using (SqlCommand sqlCmd = new SqlCommand())
                {
                    sqlCmd.Connection = con;
                    sqlCmd.CommandType = CommandType.Text;
                    sqlCmd.CommandText = "UPDATE JobOwner SET dateRead =@jobReadDate where jobOwnerID = @jobOwnerID";
                    sqlCmd.Parameters.AddWithValue("@jobOwnerID", jobInchargeID);
                    sqlCmd.Parameters.AddWithValue("@jobReadDate", System.DateTime.Now.ToString("dd/MMM/yyyy"));

                    con.Open();
                    sqlCmd.ExecuteNonQuery();
                }
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }      
    }
    private void getUnReadInchargeData()
    {       
        string sqlQuery = string.Empty;

        if (Session["SectionID"].ToString().Equals("2")) // Pay
        {
            sqlQuery = "SELECT JobOwner.projectTitle,  JobOwner.jobID, JobOwner.jobNo, JobType_1.jobTypeName, [Document].referenceNo, REPLACE(CONVERT(NVARCHAR, JobOwner.staffIssueDate, 106), ' ', '-')  AS DateOfIssue, JobType_1.CategoryID AS jobCatID, JobOwner.sectionID, JobOwner.jobOwnerID, JobOwner.contactID, JobOwner.jobDocRefID, " +
                   " JobOwner.distributedBy, Contact.firstName + '  ' + Contact.lastName AS IssuedBy, JobOwner.payID, JobOwner.srID FROM   JobOwner INNER JOIN JobType ON JobOwner.JobTypeID = JobType.jobTypeID INNER JOIN  JobType AS JobType_1 ON JobType.CategoryID = JobType_1.jobTypeID INNER JOIN " +
                " [Document] ON JobOwner.jobDocRefID = [Document].documentID INNER JOIN  Contact ON JobOwner.distributedBy = Contact.contactID  WHERE  (JobOwner.jobOwnerStatusID=3) AND (JobOwner.contactID = " + _currentUserID + ") ORDER BY JobOwner.JobownerID DESC";
        }
        else if (Session["SectionID"].ToString().Equals("9")) // BS
        {
          //  sqlQuery = " SELECT JobOwner.projectTitle, JobOwner.srID, JobOwner.jobID, JobOwner.jobNo, '' as referenceNo, JobType_1.jobTypeName, REPLACE(CONVERT(NVARCHAR, JobOwner.staffIssueDate, 106), ' ', '-') AS DateOfIssue, " + 
          //               " JobType_1.CategoryID AS jobCatID, JobOwner.sectionID, JobOwner.jobOwnerID, JobOwner.contactID, JobOwner.jobDocRefID, JobOwner.distributedBy, Contact.firstName + '  ' + Contact.lastName AS IssuedBy, JobOwner.payID " + 
          //" FROM JobOwner INNER JOIN JobType ON JobOwner.JobTypeID = JobType.jobTypeID INNER JOIN JobType AS JobType_1 ON JobType.CategoryID = JobType_1.jobTypeID INNER JOIN Contact ON JobOwner.distributedBy = Contact.contactID " +
          //        " WHERE (JobOwner.jobOwnerStatusID =3) AND (JobOwner.SectionID =9) AND (JobOwner.contactID = " + _currentUserID + ") ORDER BY JobOwner.jobOwnerID DESC";


            sqlQuery = " SELECT JobOwner.projectTitle, JobOwner.srID, JobOwner.jobID, JobOwner.jobNo, '' AS referenceNo, REPLACE(CONVERT(NVARCHAR, JobOwner.staffIssueDate, 106), ' ', '-') " +
                " AS DateOfIssue, JobOwner.sectionID, JobOwner.jobOwnerID, JobOwner.contactID, JobOwner.jobDocRefID, JobOwner.distributedBy, Contact.firstName + '  ' + Contact.lastName AS IssuedBy, JobOwner.payID, ServiceType.serviceTypeDescription as jobTypeName, JobOwner.JobTypeID as jobCatID  " +
           " FROM JobOwner INNER JOIN Contact ON JobOwner.distributedBy = Contact.contactID INNER JOIN ServiceType ON JobOwner.JobTypeID = ServiceType.serviceTypeID " +
           " WHERE        (JobOwner.jobOwnerStatusID = 3) AND (JobOwner.sectionID = 9) AND (JobOwner.contactID = " + _currentUserID + ") ORDER BY JobOwner.jobOwnerID DESC"; 

        }
        else
        {
            sqlQuery = "SELECT   JobOwner.projectTitle, JobOwner.jobID, JobOwner.jobNo,JobOwner.projectTitle, JobType_1.jobTypeName, [Document].referenceNo, REPLACE(CONVERT(NVARCHAR, JobOwner.staffIssueDate, 106), ' ', '-')  AS DateOfIssue, JobType_1.CategoryID AS jobCatID, JobOwner.sectionID, JobOwner.jobOwnerID, JobOwner.contactID, JobOwner.jobDocRefID, " +
                       " JobOwner.distributedBy, Contact.firstName + '  ' + Contact.lastName AS IssuedBy, JobOwner.payID, JobOwner.srID FROM   JobOwner INNER JOIN JobType ON JobOwner.JobTypeID = JobType.jobTypeID INNER JOIN  JobType AS JobType_1 ON JobType.CategoryID = JobType_1.jobTypeID INNER JOIN " +
                    " [Document] ON JobOwner.jobDocRefID = [Document].documentID INNER JOIN  Contact ON JobOwner.distributedBy = Contact.contactID  WHERE  (JobOwner.dateRead IS NULL) AND (JobOwner.contactID = " + _currentUserID + ") ORDER BY JobOwner.JobownerID DESC";
        }


        SqlConnection objCon = new SqlConnection(connValue);
        SqlCommand objCmd = new SqlCommand(sqlQuery, objCon);
        SqlDataAdapter objDA = new SqlDataAdapter(objCmd);

        objDA.SelectCommand.CommandText = objCmd.CommandText.ToString();
        DataTable dt = new DataTable();
        objDA.Fill(dt);

        Session["getPayData"] = dt;

        if (dt.Rows.Count != 0)
            gridTasks.DataSource = dt.DefaultView;
        else
        {
            gridTasks.DataSource = null;
           // gridTasks.Visible = false;
        }
        gridTasks.DataBind();
    }


    private void getUnReadIncharge_LeadData()
    {
        string sqlQuery = string.Empty;

        if (Session["UserProfileID"].Equals("18")) // BS Admin      // View Task by TeamLead
        {
            sqlQuery = "SELECT JobOwner.jobOwnerID, JobOwner.contactID, JobOwner.jobID, JobOwner.payID, JobOwner.jobNo, ServiceType.serviceTypeDescription AS jobTypeName, " +
                           " JobOwner.staffIssueDate AS DateOfIssue, JobOwner.distributedBy AS IssuedByID, JobOwner.jobPurposeID, JobOwner.jobOwnerStatusID, Contact.firstName AS IssuedBy, JobOwner.srID " +
                                      " FROM  Contact INNER JOIN JobOwner ON Contact.contactID = JobOwner.contactID INNER JOIN EBDServiceRequests INNER JOIN ServiceType ON EBDServiceRequests.serviceTypeID = ServiceType.serviceTypeID ON JobOwner.srID = EBDServiceRequests.serviceReqID " +
                        " WHERE (EBDServiceRequests.sectionID = 9) AND (JobOwner.jobOwnerStatusID = 3) AND (JobOwner.srID NOT IN (SELECT srID FROM JobOwner AS JobOwner_1 WHERE (sectionID = 9) AND (jobPurposeID <> 1))) ORDER BY JobOwner.srID";

            //sqlQuery = "SELECT JobOwner.jobOwnerID, JobOwner.contactID, JobOwner.jobID, JobOwner.payID, JobOwner.jobNo, ServiceType.serviceTypeDescription AS jobTypeName, " + 
            //            " JobOwner.staffIssueDate AS DateOfIssue, JobOwner.distributedBy AS IssuedByID, JobOwner.jobPurposeID, JobOwner.jobOwnerStatusID, " +
            //            " Contact.firstName AS IssuedBy, JobOwner.srID FROM  Contact INNER JOIN   JobOwner ON Contact.contactID = JobOwner.contactID INNER JOIN   EBDServiceRequests INNER JOIN   ServiceType ON EBDServiceRequests.serviceTypeID = ServiceType.serviceTypeID ON JobOwner.srID = EBDServiceRequests.serviceReqID " + 
            //            " WHERE   (EBDServiceRequests.sectionID = 9) AND (JobOwner.jobOwnerStatusID = 3) AND (JobOwner.jobID NOT IN  (SELECT   JobOwner_1.jobID FROM  EBDServiceRequests AS EBDServiceRequests_1 INNER JOIN  JobOwner AS JobOwner_1 ON EBDServiceRequests_1.serviceReqID = JobOwner_1.jobID INNER JOIN " +
            //  " ServiceType AS ServiceType_1 ON EBDServiceRequests_1.serviceTypeID = ServiceType_1.serviceTypeID  WHERE  (EBDServiceRequests_1.sectionID = 9) AND (JobOwner_1.jobPurposeID NOT IN (1)) AND (JobOwner_1.jobOwnerStatusID = 3))) ORDER BY JobOwner.jobOwnerID DESC";


            SqlConnection objCon = new SqlConnection(connValue);
            SqlCommand objCmd = new SqlCommand(sqlQuery, objCon);
            SqlDataAdapter objDA = new SqlDataAdapter(objCmd);

            objDA.SelectCommand.CommandText = objCmd.CommandText.ToString();
            DataTable dt = new DataTable();
            objDA.Fill(dt);

            Session["getLeadData"] = dt;

            if (dt.Rows.Count != 0)
                gridTasks_Lead.DataSource = dt.DefaultView;
            else
            {
                gridTasks_Lead.DataSource = null;
                // gridTasks.Visible = false;
            }

            gridTasks_Lead.DataBind();
        }
        else
        {
            trSRLead.Visible = false;
        }

    }


    private void getUnReadInchargeDataOgSurveyOracle()
    {
        string sqlQuery = string.Empty;

        sqlQuery = "select request_id as jobOwnerID, user_id as IssuedBy, state_id as jobTypeName, TO_CHAR(start_date,'DD/Mon/YYYY') as DateOfIssue, '' as referenceNo, manager_comments, '' as jobCatID,'' as payID,'' as JobID  " +
                                   "  from app_resource_allocation Where User_id = '" + Session["systemUserName"].ToString() + "'";
        
        OracleConnection objCon = new OracleConnection(connValueOracle);
        OracleCommand objCmd = new OracleCommand(sqlQuery, objCon);
        OracleDataAdapter objDA = new OracleDataAdapter(objCmd);

        objDA.SelectCommand.CommandText = objCmd.CommandText.ToString();
        DataTable dt = new DataTable();
        objDA.Fill(dt);

        Session["getPayData"] = dt;

        if (dt.Rows.Count != 0)
            gridTasks.DataSource = dt.DefaultView;
        else
        {
            gridTasks.DataSource = null;
            gridTasks.Visible = false;
        }
        gridTasks.DataBind();
    
    }

  
    private void getOnGoingTasksPerStaffChart()   // chart 3
    {
        string sqlQuery = string.Empty; string strStaff = string.Empty; 

        DataSet dsTndr = new DataSet();         
        int sectionID = Convert.ToInt32(Session["SectionID"]);

        if (Session["userProfileID"].ToString().Equals("1"))
        {
            sqlQuery = "SELECT COUNT(*) AS JobCnt, Contact.userShortName FROM JobOwner INNER JOIN Contact ON JobOwner.contactID = Contact.contactID WHERE (JobOwner.jobOwnerStatusID = 3) GROUP BY JobOwner.contactID, Contact.userShortName ORDER BY Contact.userShortName";
            lblOngoingStaff.Text = "On Going Tasks Per Staff In All Sections Of EBSD";
        }
        else if (!userRightsColl.Contains("42") && Session["SectionID"].ToString().Equals("7")) //1 - All Sections
        {
            sqlQuery = "SELECT COUNT(*) AS JobCnt, Contact.userShortName FROM JobOwner INNER JOIN Contact ON JobOwner.contactID = Contact.contactID WHERE (JobOwner.jobOwnerStatusID = 3) GROUP BY JobOwner.contactID, Contact.userShortName ORDER BY Contact.userShortName";
            lblOngoingStaff.Text = "On Going Tasks Per Staff In All Sections Of EBSD";
        }
        else
        {
            lblOngoingStaff.Text = "On Going Tasks Per Staff In EBSD " + Session["SectionName"].ToString(); 

            sqlQuery = "SELECT COUNT(*) AS JobCnt, Contact.userShortName FROM  JobOwner INNER JOIN  Contact ON JobOwner.contactID = Contact.contactID " +
                      " WHERE  (JobOwner.sectionID = " + sectionID + ") AND (JobOwner.jobOwnerStatusID = 3) GROUP BY JobOwner.contactID, Contact.userShortName ORDER BY Contact.userShortName";
        }        
                         
        SqlDataAdapter daTndr = new SqlDataAdapter(sqlQuery, connValue);
        daTndr.Fill(dsTndr);
        if (dsTndr.Tables[0].Rows.Count != 0)
        {
            onGoingTasksPerStaffChart.DataSource = dsTndr.Tables[0].DefaultView;
            onGoingTasksPerStaffChart.Series["Series1"].XValueMember = "userShortName";
            onGoingTasksPerStaffChart.Series["Series1"].YValueMembers = "JobCnt";
            dsTndr.Tables.Clear();

            onGoingTasksPerStaffChart.ChartAreas[0].AxisX.MajorGrid.Enabled = false;
            onGoingTasksPerStaffChart.ChartAreas[0].AxisX.MinorGrid.Enabled = false;
            onGoingTasksPerStaffChart.ChartAreas[0].AxisY.MajorGrid.Enabled = false;
            onGoingTasksPerStaffChart.ChartAreas[0].AxisY.MinorGrid.Enabled = false;

            onGoingTasksPerStaffChart.ChartAreas[0].AxisX.LabelStyle.Angle = 30;
            onGoingTasksPerStaffChart.ChartAreas[0].AxisX.LabelStyle.ForeColor = Color.Maroon;

            onGoingTasksPerStaffChart.ChartAreas[0].AxisX.Interval = 1;
        }
    }
    
    private void getMyDocumentChart()
    {
        DataSet dsDoc = new DataSet();

        string sqlQuery = null;

        if (Convert.ToInt32(Session["UserID"]) == 1)
        {
            sqlQuery = "SELECT COUNT(DocumentDistribution.distributeID) AS DocCount, DocumentStatus.docStatusName " +
                   " FROM DocumentDistribution INNER JOIN  DocumentStatus ON DocumentDistribution.docStatusID = DocumentStatus.docStatusID WHERE (DocumentDistribution.docStatusID not in (4,2)) GROUP BY DocumentStatus.docStatusName";
        }
        else
        {
            sqlQuery = "SELECT COUNT(DocumentDistribution.distributeID) AS DocCount, DocumentStatus.docStatusName " +
                   " FROM DocumentDistribution INNER JOIN  DocumentStatus ON DocumentDistribution.docStatusID = DocumentStatus.docStatusID WHERE (DocumentDistribution.docStatusID not in (4)) AND " +
                   " (DocumentDistribution.contactID = " + Convert.ToInt32(Session["UserID"]) + ") " +
                           " GROUP BY DocumentStatus.docStatusName";
        }
     
        SqlDataAdapter daDoc = new SqlDataAdapter(sqlQuery, connValue);
        daDoc.Fill(dsDoc);
        if (dsDoc.Tables[0].Rows.Count != 0)
        {
            myDocsChart.DataSource = dsDoc.Tables[0].DefaultView;
            myDocsChart.Series["Series1"].XValueMember = "docStatusName";
            myDocsChart.Series["Series1"].YValueMembers = "DocCount";

            dsDoc.Tables.Clear();

            myDocsChart.ChartAreas[0].AxisX.MajorGrid.Enabled = false;
            myDocsChart.ChartAreas[0].AxisX.MinorGrid.Enabled = false;
            myDocsChart.ChartAreas[0].AxisY.MajorGrid.Enabled = false;
            myDocsChart.ChartAreas[0].AxisY.MinorGrid.Enabled = false;

            myDocsChart.ChartAreas[0].AxisX.LabelStyle.Angle = 30;
            myDocsChart.ChartAreas[0].AxisX.LabelStyle.ForeColor = Color.Maroon;

            myDocsChart.ChartAreas[0].AxisX.Interval = 1;
        }
    }
    private void getOnGoingTasksPerSection_New()
    {
        DataSet dsTndr = new DataSet();

        string sqlQuery = null; int secID = Convert.ToInt32(Session["SectionID"]);
        string strSeriesName = string.Empty;

        if (Session["userProfileID"].ToString().Equals("1"))   // For Admin
        {
            sqlQuery = " SELECT  COUNT(Job.jobID) AS JobCnt, Section.sectionName FROM  JobType INNER JOIN  Job ON JobType.jobTypeID = Job.jobTypeID INNER JOIN   Section ON JobType.sectionID = Section.sectionID " +
               " WHERE (Job.jobDueDate < GETDATE()-1) AND (Job.jobStatusID IN (3, 8))  GROUP BY Section.sectionName, JobType.sectionID  UNION " +
                    "SELECT  COUNT(JobOwner.jobOwnerID) AS Expr1, Section.sectionName FROM  JobOwner INNER JOIN  Section ON JobOwner.sectionID = Section.sectionID " +
                          " WHERE  (JobOwner.payID IS NOT NULL) AND (JobOwner.actionDueDate < GETDATE()-1) AND (JobOwner.jobOwnerStatusID <> 7) GROUP BY Section.sectionName";
            strSeriesName = "sectionName";

            lblOngoingJobs.Text = "Over Due Job Order In All Sections";
        }
        else if (!Session["userProfileID"].ToString().Equals("1") && Session["SectionID"].ToString().Equals("7") && !userRightsColl.Contains("1"))    // User Not Admin but he belongs to all section and he contain user rights no  -1   (  7 for all section )
        {
            sqlQuery = " SELECT  COUNT(Job.jobID) AS JobCnt, Section.sectionName FROM  JobType INNER JOIN  Job ON JobType.jobTypeID = Job.jobTypeID INNER JOIN   Section ON JobType.sectionID = Section.sectionID " +
               " WHERE (Job.jobDueDate < GETDATE()-1) AND (Job.jobStatusID IN (3, 8))  GROUP BY Section.sectionName, JobType.sectionID  UNION " +
                    "SELECT  COUNT(JobOwner.jobOwnerID) AS Expr1, Section.sectionName FROM  JobOwner INNER JOIN  Section ON JobOwner.sectionID = Section.sectionID " +
                          " WHERE  (JobOwner.payID IS NOT NULL) AND (JobOwner.actionDueDate < GETDATE()-1) AND (JobOwner.jobOwnerStatusID <> 7) GROUP BY Section.sectionName";

            strSeriesName = "sectionName";

            lblOngoingJobs.Text = "Over Due Job Order In All Sections";
        }
        else if (Session["SectionID"].ToString().Equals("1"))          // Cost Control Section
        {
            if (Session["UserProfileID"].ToString().Contains("2"))        // Admin Section
            {
                sqlQuery = "SELECT COUNT(Job.jobID) AS JobCnt, JobType_1.jobTypeName FROM JobType AS JobType_1 INNER JOIN JobType ON JobType_1.jobTypeID = JobType.CategoryID INNER JOIN  Job ON JobType.jobTypeID = Job.jobTypeID INNER JOIN " +
                   " Section ON JobType.sectionID = Section.sectionID WHERE (JobType.sectionID = " + secID + ") AND (Job.jobDueDate < GETDATE()-1) AND (Job.jobStatusID IN (3,8)) GROUP BY JobType_1.jobTypeName";

                strSeriesName = "jobTypeName";
                lblOngoingJobs.Text = "Over Due Job Order In Cost Control Section";
            }
            else if (Session["UserProfileID"].ToString().Contains("4"))        // Cost Control Admin 
            {
                sqlQuery = "SELECT COUNT(Job.jobID) AS JobCnt, JobType_1.jobTypeName FROM JobType AS JobType_1 INNER JOIN JobType ON JobType_1.jobTypeID = JobType.CategoryID INNER JOIN  Job ON JobType.jobTypeID = Job.jobTypeID INNER JOIN " +
                " Section ON JobType.sectionID = Section.sectionID WHERE (JobType.sectionID = " + secID + ") AND (Job.jobDueDate < GETDATE()-1) AND (Job.jobStatusID IN (3,8)) GROUP BY JobType_1.jobTypeName";

                strSeriesName = "jobTypeName";
                lblOngoingJobs.Text = "Over Due Job Order In Cost Control Section";
            }
            else if (Session["UserProfileID"].ToString().Contains("9"))        // Document Control Admin 
            {
                sqlQuery = "SELECT COUNT(Job.jobID) AS JobCnt, JobType_1.jobTypeName FROM JobType AS JobType_1 INNER JOIN JobType ON JobType_1.jobTypeID = JobType.CategoryID INNER JOIN  Job ON JobType.jobTypeID = Job.jobTypeID INNER JOIN " +
                " Section ON JobType.sectionID = Section.sectionID WHERE (JobType.sectionID = " + secID + ") AND (Job.jobDueDate < GETDATE()-1) AND (Job.jobStatusID IN (3,8)) GROUP BY JobType_1.jobTypeName";

                strSeriesName = "jobTypeName";
                lblOngoingJobs.Text = "Over Due Job Order In Cost Control Section";
            }
            else                                                            // Cost Control User 
            {
                sqlQuery = "SELECT  COUNT(JobOwner.jobOwnerID) AS JobCnt, JobType_1.jobTypeName FROM   JobType INNER JOIN  JobOwner ON JobType.jobTypeID = JobOwner.JobTypeID INNER JOIN " +
                        " Section ON JobOwner.sectionID = Section.sectionID INNER JOIN  JobType AS JobType_1 ON JobType.CategoryID = JobType_1.jobTypeID  WHERE (JobOwner.jobOwnerStatusID = 3) AND (JobOwner.contactID = " + _currentUserID + ") GROUP BY JobType_1.jobTypeName";
                strSeriesName = "jobTypeName";

                lblOngoingJobs.Text = "My On Going Tasks";               
            } 
        }
        else if (Session["SectionID"].ToString().Equals("3"))          // Document Control Section
        {
            if (Session["UserProfileID"].ToString().Contains("2"))        // Admin Section
            {
                sqlQuery = "SELECT COUNT(Job.jobID) AS JobCnt, JobType_1.jobTypeName FROM JobType AS JobType_1 INNER JOIN JobType ON JobType_1.jobTypeID = JobType.CategoryID INNER JOIN  Job ON JobType.jobTypeID = Job.jobTypeID INNER JOIN " +
                   " Section ON JobType.sectionID = Section.sectionID WHERE (JobType.sectionID = " + secID + ") AND (Job.jobDueDate < GETDATE()-1) AND (Job.jobStatusID IN (3,8)) GROUP BY JobType_1.jobTypeName";
                
                strSeriesName = "jobTypeName";
                lblOngoingJobs.Text = "Over Due Job Order In Document Control";
            }
            else if (Session["UserProfileID"].ToString().Contains("9"))        // Document Control Admin 
            {
                sqlQuery = "SELECT    COUNT(JobOwner.jobOwnerID) AS JobCnt, JobType_1.jobTypeName  FROM  JobType INNER JOIN     JobOwner ON JobType.jobTypeID = JobOwner.JobTypeID INNER JOIN   Section ON JobOwner.sectionID = Section.sectionID INNER JOIN " + 
                        " JobType AS JobType_1 ON JobType.CategoryID = JobType_1.jobTypeID WHERE (JobOwner.jobOwnerStatusID = 3) AND (JobType.sectionID = 3) GROUP BY JobType_1.jobTypeName";
               
                strSeriesName = "jobTypeName";
                lblOngoingJobs.Text = "On-going Jobs In Document Control";
            }
            else                                                            // Document Control User 
            {
                sqlQuery = "SELECT  COUNT(JobOwner.jobOwnerID) AS JobCnt, JobType_1.jobTypeName FROM   JobType INNER JOIN  JobOwner ON JobType.jobTypeID = JobOwner.JobTypeID INNER JOIN " +
                        " Section ON JobOwner.sectionID = Section.sectionID INNER JOIN  JobType AS JobType_1 ON JobType.CategoryID = JobType_1.jobTypeID  WHERE (JobOwner.jobOwnerStatusID = 3) AND (JobOwner.contactID = " + _currentUserID + ") GROUP BY JobType_1.jobTypeName";
                
                strSeriesName = "jobTypeName";
                lblOngoingJobs.Text = "My On Going Tasks";
            }
        }
        else if (Session["SectionID"].ToString().Equals("2"))          // Payment Section
        {
            if (Session["UserProfileID"].ToString().Contains("2"))        // Admin Section
            {
                sqlQuery = "SELECT  COUNT(JobOwner.jobOwnerID) AS JobCnt, JobType.jobTypeName FROM  JobOwner INNER JOIN   JobType ON JobOwner.JobTypeID = JobType.jobTypeID " +
                                 " WHERE (JobOwner.payID IS NOT NULL) AND (JobOwner.actionDueDate < GETDATE()-1) AND (JobOwner.jobOwnerStatusID <> 7) GROUP BY JobType.jobTypeName";
                
                strSeriesName = "jobTypeName";
                lblOngoingJobs.Text = "Over Due Job Order In Payment Section";
            }
            else if (Session["UserProfileID"].ToString().Contains("4"))        // Payment Admin 
            {
                sqlQuery = "SELECT  COUNT(JobOwner.jobOwnerID) AS JobCnt, JobType.jobTypeName FROM  JobOwner INNER JOIN   JobType ON JobOwner.JobTypeID = JobType.jobTypeID " +
                                 " WHERE (JobOwner.payID IS NOT NULL) AND (JobOwner.actionDueDate < GETDATE()-1) AND (JobOwner.jobOwnerStatusID <> 7) GROUP BY JobType.jobTypeName";

                strSeriesName = "jobTypeName";
                lblOngoingJobs.Text = "Over Due Job Order In Payment Section";
            }
            else                                                            // Payment User 
            {
                sqlQuery = "SELECT  COUNT(JobOwner.jobOwnerID) AS JobCnt, JobType_1.jobTypeName FROM   JobType INNER JOIN  JobOwner ON JobType.jobTypeID = JobOwner.JobTypeID INNER JOIN " +
                        " Section ON JobOwner.sectionID = Section.sectionID INNER JOIN  JobType AS JobType_1 ON JobType.CategoryID = JobType_1.jobTypeID  WHERE (JobOwner.jobOwnerStatusID = 3) AND (JobOwner.contactID = " + _currentUserID + ") GROUP BY JobType_1.jobTypeName";
                
                strSeriesName = "jobTypeName";
                lblOngoingJobs.Text = "My On Going Tasks";
            }
        }
        else if (Session["SectionID"].ToString().Equals("10"))          // Mngr Control Section
        {
            if (Session["UserProfileID"].ToString().Contains("2"))        // Admin Section
            {
                sqlQuery = " SELECT COUNT(Job.jobID) AS JobCnt, JobType.jobTypeName FROM  JobType INNER JOIN  Job ON JobType.jobTypeID = Job.jobTypeID INNER JOIN " +
                         " Section ON JobType.sectionID = Section.sectionID WHERE (JobType.sectionID = 10) AND (Job.jobDueDate < GETDATE() - 1) AND (Job.jobStatusID IN (3, 8)) GROUP BY JobType.jobTypeName";
               
                strSeriesName = "jobTypeName";
                lblOngoingJobs.Text = "Over Due Task In Manager Request";
            }
            else if (Session["UserProfileID"].ToString().Contains("15"))        // Req Control Admin 
            {
                sqlQuery = " SELECT COUNT(Job.jobID) AS JobCnt, JobType.jobTypeName FROM  JobType INNER JOIN  Job ON JobType.jobTypeID = Job.jobTypeID INNER JOIN " +
                        " Section ON JobType.sectionID = Section.sectionID WHERE (JobType.sectionID = 10) AND (Job.jobDueDate < GETDATE() - 1) AND (Job.jobStatusID IN (3, 8)) GROUP BY JobType.jobTypeName";

                strSeriesName = "jobTypeName";
                lblOngoingJobs.Text = "Over Due Task In Manager Request";
            }
            
            else                                                            // Req Control User 
            {
                sqlQuery = "SELECT  COUNT(JobOwner.jobOwnerID) AS JobCnt, JobType_1.jobTypeName FROM   JobType INNER JOIN  JobOwner ON JobType.jobTypeID = JobOwner.JobTypeID INNER JOIN " +
                        " Section ON JobOwner.sectionID = Section.sectionID INNER JOIN  JobType AS JobType_1 ON JobType.CategoryID = JobType_1.jobTypeID  WHERE (JobOwner.jobOwnerStatusID = 3) AND (JobOwner.contactID = " + _currentUserID + ") GROUP BY JobType_1.jobTypeName";
                
                strSeriesName = "jobTypeName";

                lblOngoingJobs.Text = "My On Going Tasks";
            } 
            
        }
        else if (Session["SectionID"].ToString().Equals("9"))          // BS Control Section
        {
            if (Session["UserProfileID"].ToString().Contains("2"))        // Admin Section
            {
                sqlQuery = " SELECT    COUNT(EBDServiceRequests.serviceReqID) AS JobCnt, ServiceType.serviceTypeDescription as jobTypeName FROM EBDServiceRequests INNER JOIN " +
                         " ServiceType ON EBDServiceRequests.serviceTypeID = ServiceType.serviceTypeID GROUP BY ServiceType.serviceTypeDescription";

                strSeriesName = "jobTypeName";
                lblOngoingJobs.Text = "Over Due Task In BS Request";
            }
            else if (Session["UserProfileID"].ToString().Contains("15"))        // Req Control Admin 
            {
                sqlQuery = " SELECT    COUNT(EBDServiceRequests.serviceReqID) AS JobCnt, ServiceType.serviceTypeDescription as jobTypeName FROM EBDServiceRequests INNER JOIN " +
                         " ServiceType ON EBDServiceRequests.serviceTypeID = ServiceType.serviceTypeID GROUP BY ServiceType.serviceTypeDescription";

                strSeriesName = "jobTypeName";
                lblOngoingJobs.Text = "Over Due Task In BS Request";
            }
            else                                                            // Req Control User 
            {
                sqlQuery = "SELECT  COUNT(JobOwner.jobOwnerID) AS JobCnt, ServiceType.serviceTypeDescription as jobTypeName FROM JobOwner INNER JOIN ServiceType ON JobOwner.JobTypeID = ServiceType.serviceTypeID " +
                                   " WHERE (JobOwner.jobOwnerStatusID = 3) AND (JobOwner.contactID = " + _currentUserID + ") GROUP BY ServiceType.serviceTypeDescription";

                strSeriesName = "jobTypeName";
                lblOngoingJobs.Text = "My On Going Tasks";
            }
        }
        else
        {
            sqlQuery = "SELECT  COUNT(JobOwner.jobOwnerID) AS JobCnt, JobType_1.jobTypeName FROM   JobType INNER JOIN  JobOwner ON JobType.jobTypeID = JobOwner.JobTypeID INNER JOIN " +
                       " Section ON JobOwner.sectionID = Section.sectionID INNER JOIN  JobType AS JobType_1 ON JobType.CategoryID = JobType_1.jobTypeID  WHERE (JobOwner.jobOwnerStatusID = 3) AND (JobOwner.contactID = " + _currentUserID + ") GROUP BY JobType_1.jobTypeName";
           
            strSeriesName = "jobTypeName";
            lblOngoingJobs.Text = "My On Going Tasks";
        } 

        // Chart_OverDueJobs

        SqlDataAdapter daTndr = new SqlDataAdapter(sqlQuery, connValue);
        daTndr.Fill(dsTndr);
        if (dsTndr.Tables[0].Rows.Count != 0)
        {
            onGoingTasksPerSectionChart.DataSource = dsTndr.Tables[0].DefaultView;

            onGoingTasksPerSectionChart.Series["Series1"].XValueMember = strSeriesName;
            onGoingTasksPerSectionChart.Series["Series1"].YValueMembers = "JobCnt";

            dsTndr.Tables.Clear();

            onGoingTasksPerSectionChart.ChartAreas[0].AxisX.MajorGrid.Enabled = false;
            onGoingTasksPerSectionChart.ChartAreas[0].AxisX.MinorGrid.Enabled = false;
            onGoingTasksPerSectionChart.ChartAreas[0].AxisY.MajorGrid.Enabled = false;
            onGoingTasksPerSectionChart.ChartAreas[0].AxisY.MinorGrid.Enabled = false;

            onGoingTasksPerSectionChart.ChartAreas[0].AxisX.LabelStyle.Angle = 30;
            onGoingTasksPerSectionChart.ChartAreas[0].AxisX.LabelStyle.ForeColor = Color.Maroon;

            onGoingTasksPerSectionChart.ChartAreas[0].AxisX.Interval = 1;
        }

    }
    private void getOnGoingTasksPerSection()
    {
        DataSet dsTndr = new DataSet();

        string sqlQuery = null; int secID = Convert.ToInt32(Session["SectionID"]);
      string strSeriesName = string.Empty;


        if (Session["userProfileID"].ToString().Equals("1"))
        { 
            //sqlQuery = "SELECT  COUNT(Job.jobID) AS JobCnt, Section.sectionName, JobType.sectionID FROM     JobType INNER JOIN    Job ON JobType.jobTypeID = Job.jobTypeID INNER JOIN " +
            //             " Section ON JobType.sectionID = Section.sectionID WHERE (Job.jobDueDate < GETDATE()) AND (Job.jobStatusID IN (3, 8)) GROUP BY Section.sectionName, JobType.sectionID ";

            sqlQuery = " SELECT  COUNT(Job.jobID) AS JobCnt, Section.sectionName FROM  JobType INNER JOIN  Job ON JobType.jobTypeID = Job.jobTypeID INNER JOIN   Section ON JobType.sectionID = Section.sectionID " +
               " WHERE (Job.jobDueDate < GETDATE()-1) AND (Job.jobStatusID IN (3, 8))  GROUP BY Section.sectionName, JobType.sectionID  UNION " +
                    "SELECT  COUNT(JobOwner.jobOwnerID) AS Expr1, Section.sectionName FROM  JobOwner INNER JOIN  Section ON JobOwner.sectionID = Section.sectionID " +
                          " WHERE  (JobOwner.payID IS NOT NULL) AND (JobOwner.actionDueDate < GETDATE()-1) AND (JobOwner.jobOwnerStatusID <> 7) GROUP BY Section.sectionName";
            strSeriesName = "sectionName";

            lblOngoingJobs.Text = "Over Due Job Order In All Sections";          
        }
        else if (!Session["userProfileID"].ToString().Equals("1") && Session["SectionID"].ToString().Equals("7") && !userRightsColl.Contains("1"))    // 7 for all section 
        {
            sqlQuery = " SELECT  COUNT(Job.jobID) AS JobCnt, Section.sectionName FROM  JobType INNER JOIN  Job ON JobType.jobTypeID = Job.jobTypeID INNER JOIN   Section ON JobType.sectionID = Section.sectionID " + 
               " WHERE (Job.jobDueDate < GETDATE()-1) AND (Job.jobStatusID IN (3, 8))  GROUP BY Section.sectionName, JobType.sectionID  UNION " +
                    "SELECT  COUNT(JobOwner.jobOwnerID) AS Expr1, Section.sectionName FROM  JobOwner INNER JOIN  Section ON JobOwner.sectionID = Section.sectionID " +
                          " WHERE  (JobOwner.payID IS NOT NULL) AND (JobOwner.actionDueDate < GETDATE()-1) AND (JobOwner.jobOwnerStatusID <> 7) GROUP BY Section.sectionName";

            strSeriesName = "sectionName";

            lblOngoingJobs.Text = "Over Due Job Order In All Sections";  
        }
        else if (!userRightsColl.Contains("1")) // Not All Sections  
        {           
            if (Session["SectionID"].ToString().Equals("1"))
            {
                  sqlQuery = "SELECT COUNT(Job.jobID) AS JobCnt, JobType_1.jobTypeName FROM JobType AS JobType_1 INNER JOIN JobType ON JobType_1.jobTypeID = JobType.CategoryID INNER JOIN  Job ON JobType.jobTypeID = Job.jobTypeID INNER JOIN " +
              " Section ON JobType.sectionID = Section.sectionID WHERE (JobType.sectionID = " + secID + ") AND (Job.jobDueDate < GETDATE()-1) AND (Job.jobStatusID IN (3,8)) GROUP BY JobType_1.jobTypeName";            
            
            }
            else if (Session["SectionID"].ToString().Equals("2"))
            {
                sqlQuery = "SELECT  COUNT(JobOwner.jobOwnerID) AS JobCnt, JobType.jobTypeName FROM  JobOwner INNER JOIN   JobType ON JobOwner.JobTypeID = JobType.jobTypeID " +  
                                 " WHERE (JobOwner.payID IS NOT NULL) AND (JobOwner.actionDueDate < GETDATE()-1) AND (JobOwner.jobOwnerStatusID <> 7) GROUP BY JobType.jobTypeName";
            }
            else if (Session["SectionID"].ToString().Equals("3"))
            {
                //sqlQuery = "SELECT  COUNT(JobOwner.jobOwnerID) AS JobCnt, JobType.jobTypeName FROM  JobOwner INNER JOIN   JobType ON JobOwner.JobTypeID = JobType.jobTypeID " +
                //                 " WHERE (JobOwner.payID IS NULL) AND (JobOwner.actionDueDate < GETDATE()-1) AND (JobOwner.jobOwnerStatusID <> 7) and JobOwner.sectionID =3 GROUP BY JobType.jobTypeName";

                sqlQuery = "SELECT COUNT(Job.jobID) AS JobCnt, JobType_1.jobTypeName FROM JobType AS JobType_1 INNER JOIN JobType ON JobType_1.jobTypeID = JobType.CategoryID INNER JOIN  Job ON JobType.jobTypeID = Job.jobTypeID INNER JOIN " +
            " Section ON JobType.sectionID = Section.sectionID WHERE (JobType.sectionID = " + secID + ") AND (Job.jobDueDate < GETDATE()-1) AND (Job.jobStatusID IN (3,8)) GROUP BY JobType_1.jobTypeName";

                lblOngoingJobs.Text = "My On Going Tasks";
            }
            else       // added newly on jan 28th
            {
                sqlQuery = "SELECT  COUNT(JobOwner.jobOwnerID) AS JobCnt, JobType_1.jobTypeName FROM   JobType INNER JOIN  JobOwner ON JobType.jobTypeID = JobOwner.JobTypeID INNER JOIN " +
                            " Section ON JobOwner.sectionID = Section.sectionID INNER JOIN  JobType AS JobType_1 ON JobType.CategoryID = JobType_1.jobTypeID  WHERE (JobOwner.jobOwnerStatusID = 3) AND (JobOwner.contactID = " + _currentUserID + ") GROUP BY JobType_1.jobTypeName";
                strSeriesName = "jobTypeName";

                lblOngoingJobs.Text = "My On Going Tasks";
            }

            strSeriesName = "jobTypeName";
            lblOngoingJobs.Text = "Over Due Job Order In " + Session["SectionName"].ToString();           
        }
        else if (Session["SectionID"].ToString().Equals("3"))
        {
            //sqlQuery = "SELECT  COUNT(JobOwner.jobOwnerID) AS JobCnt, JobType.jobTypeName FROM  JobOwner INNER JOIN   JobType ON JobOwner.JobTypeID = JobType.jobTypeID " +
            //                 " WHERE (JobOwner.payID IS NULL) AND (JobOwner.actionDueDate < GETDATE()-1) AND (JobOwner.jobOwnerStatusID <> 7) and JobOwner.sectionID =3 GROUP BY JobType.jobTypeName";

            sqlQuery = "SELECT COUNT(Job.jobID) AS JobCnt, JobType_1.jobTypeName FROM JobType AS JobType_1 INNER JOIN JobType ON JobType_1.jobTypeID = JobType.CategoryID INNER JOIN  Job ON JobType.jobTypeID = Job.jobTypeID INNER JOIN " +
        " Section ON JobType.sectionID = Section.sectionID WHERE (JobType.sectionID = " + secID + ") AND (Job.jobDueDate < GETDATE()-1) AND (Job.jobStatusID IN (3,8)) GROUP BY JobType_1.jobTypeName";


            lblOngoingJobs.Text = "My On Going Tasks";
        }
        else
        {
            sqlQuery = "SELECT  COUNT(JobOwner.jobOwnerID) AS JobCnt, JobType_1.jobTypeName FROM   JobType INNER JOIN  JobOwner ON JobType.jobTypeID = JobOwner.JobTypeID INNER JOIN " + 
                        " Section ON JobOwner.sectionID = Section.sectionID INNER JOIN  JobType AS JobType_1 ON JobType.CategoryID = JobType_1.jobTypeID  WHERE (JobOwner.jobOwnerStatusID = 3) AND (JobOwner.contactID = " + _currentUserID + ") GROUP BY JobType_1.jobTypeName";
            strSeriesName = "jobTypeName";

            lblOngoingJobs.Text = "My On Going Tasks";
        }


       // Chart_OverDueJobs

        SqlDataAdapter daTndr = new SqlDataAdapter(sqlQuery, connValue);
        daTndr.Fill(dsTndr);
        if (dsTndr.Tables[0].Rows.Count != 0)
        {
            onGoingTasksPerSectionChart.DataSource = dsTndr.Tables[0].DefaultView;

            onGoingTasksPerSectionChart.Series["Series1"].XValueMember = strSeriesName;
            onGoingTasksPerSectionChart.Series["Series1"].YValueMembers = "JobCnt";           

            dsTndr.Tables.Clear();

            onGoingTasksPerSectionChart.ChartAreas[0].AxisX.MajorGrid.Enabled = false;
            onGoingTasksPerSectionChart.ChartAreas[0].AxisX.MinorGrid.Enabled = false;
            onGoingTasksPerSectionChart.ChartAreas[0].AxisY.MajorGrid.Enabled = false;
            onGoingTasksPerSectionChart.ChartAreas[0].AxisY.MinorGrid.Enabled = false;

            onGoingTasksPerSectionChart.ChartAreas[0].AxisX.LabelStyle.Angle = 30;
            onGoingTasksPerSectionChart.ChartAreas[0].AxisX.LabelStyle.ForeColor = Color.Maroon;

            onGoingTasksPerSectionChart.ChartAreas[0].AxisX.Interval = 1;
        }
       
    }
    private void getSeriesData(DataSet dsTndr, string sqlQuery)
    {
        SqlDataAdapter daTndr = new SqlDataAdapter(sqlQuery, connValue);
        daTndr.Fill(dsTndr);
        if (dsTndr.Tables[0].Rows.Count != 0)
        {
            onGoingTasksPerSectionChart.DataSource = dsTndr.Tables[0].DefaultView;
            onGoingTasksPerSectionChart.Series["Series1"].XValueMember = "jobTypeName";
            onGoingTasksPerSectionChart.Series["Series1"].YValueMembers = "JobCnt";

            dsTndr.Tables.Clear();

            onGoingTasksPerSectionChart.ChartAreas[0].AxisX.MajorGrid.Enabled = false;
            onGoingTasksPerSectionChart.ChartAreas[0].AxisX.MinorGrid.Enabled = false;
            onGoingTasksPerSectionChart.ChartAreas[0].AxisY.MajorGrid.Enabled = false;
            onGoingTasksPerSectionChart.ChartAreas[0].AxisY.MinorGrid.Enabled = false;

            onGoingTasksPerSectionChart.ChartAreas[0].AxisX.LabelStyle.Angle = 30;
            onGoingTasksPerSectionChart.ChartAreas[0].AxisX.LabelStyle.ForeColor = Color.Maroon;

            onGoingTasksPerSectionChart.ChartAreas[0].AxisX.Interval = 1;
        }
    }

    protected void lnkSearchJobOrderLog_Click(object sender, EventArgs e)
    {
        string strUpdateJob = Request.Url.AbsoluteUri;
        Session["UrlRef"] = strUpdateJob;
        if (userRightsColl.Contains("10"))   //Add New Project
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "Popup", "<script>alert('You have no privilege to Search Job Order Log.')</script>", false);             
            return;
        }       
        else
        {
            if (Session["SectionID"].Equals("3"))
               Response.Redirect("~/DCLog/SearchDCLog.aspx", false);   
            else
               Response.Redirect("SearchJobMstr.aspx", false); 
        }
    }   
    protected void lnkPaymentRequest_Click(object sender, EventArgs e)
    {
        string strUpdateJob = Request.Url.AbsoluteUri;
        Session["UrlRef"] = strUpdateJob;
        if (userRightsColl.Contains("19"))
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "Popup", "<script>alert('You have no privilege for Payment Request.')</script>", false);
            return;
        }
        else
        {
            Response.Redirect("~/JobOrder/UnderProcess.aspx", false);
        }
    }
    protected void lnkSearchAddendumLog_Click(object sender, EventArgs e)
    {
        string strUpdateJob = Request.Url.AbsoluteUri;
        Session["UrlRef"] = strUpdateJob;

        if (userRightsColl.Contains("11"))   
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "Popup", "<script>alert('You have no privilege to Search Addendum Log.')</script>", false);
            return;
        }
        else
        {
            Response.Redirect("SearchAdmData.aspx", false);
        }
    }

    protected void lnkNewPaymentNCP_Click(object sender, EventArgs e)
    {
        if (userRightsColl.Contains("18"))
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "Popup", "<script>alert('You have no privilege to Add Payment Request.')</script>", false);
            return;
        }
        else
        { 
          
           // Application["PrjType"] = Session["PrjCP/NCP"];
            Response.Redirect("~/Payments/AddNewNCPpayment.aspx", false);

            //string strJavascript = "<script type='text/javascript'>window.open('~/Payments/AddNewPayment.aspx,'_blank');</script>";
            //Response.Write(strJavascript);
        }
    }


    protected void lnkNewPaymentCP_Click(object sender, EventArgs e)
    {
        if (userRightsColl.Contains("18"))
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "Popup", "<script>alert('You have no privilege to Add Payment Request.')</script>", false);
            return;
        }
        else
        {
            Session["PrjCP/NCP"] = "CP";
            Application["PrjType"] = Session["PrjCP/NCP"];
            Response.Redirect("~/Payments/AddNewPayment.aspx", false);
        }
    }
    protected void lnkNewJobOrder_Click(object sender, EventArgs e)
    {
        
        string strUpdateJob = Request.Url.AbsoluteUri;
        Session["UrlRef"] = strUpdateJob;    

        if (userRightsColl.Contains("2"))   //Add New Project
        {
            Session["lblText"] = "You are not allowed to Add New Job Order.Please contact system Administrator for further inquiry.";
            Session["lblSub"] = "Restricted Access to Add New Job Order.";
            Session["lblBody"] = "This is in reference to Restricted Access to Add New Job Order. I would like to inquire about the restriction.";


            string url = "RestrictedMsgWindow.aspx";
            string s = "window.open('" + url + "', 'popup_window', 'width=500,height=250,left=100,top=100,resizable=yes,scrollbars=yes');";
            ClientScript.RegisterStartupScript(this.GetType(), "script", s, true);
            

            //ClientScript.RegisterClientScriptBlock(this.GetType(), "Popup", "<script>alert('You have no privilege to add this Job,Contact administrator.')</script>", false);
            //return;
        }
        else if (Session["SectionID"].ToString().Equals("2"))
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "Popup", "<script>alert('This is not applicable to all employees from EBSD Payment Section.')</script>", false);
            return;
        }
        else
        {
            if (Session["SectionID"].Equals("3"))
            {
                Response.Redirect("~/DCLog/DCNewJob.aspx");
            }
            else
            {
                string url = "JobEntryForm.aspx";
                string s = "window.open('" + url + "', 'popup_window', 'width=990,height=700,left=100,top=100,resizable=yes,scrollbars=yes');";
                ClientScript.RegisterStartupScript(this.GetType(), "script", s, true);
            }
           
        }
    }
    protected void myDocsChart_Click(object sender, ImageMapEventArgs e)
    {
        string strUpdateJob = Request.Url.AbsoluteUri;
        Session["UrlRef"] = strUpdateJob;

        uCls = new UtilityClass(this.Page);
        uCls.ResetTheSessionVariables();
        Session["MyChartClickDocStatus"] = e.PostBackValue;
        int docStatusID = 1;
        if (e.PostBackValue.Equals("Open"))
            docStatusID = 1;
        else if (e.PostBackValue.Equals("For Follow Up"))
            docStatusID = 2;
        else if (e.PostBackValue.Equals("Pending"))
            docStatusID = 3;

        Response.Redirect("~/Documents/SearchDocument.aspx?docStatID=" + docStatusID, false);
    }
    protected void sectionWiseDoc_Click(object sender, ImageMapEventArgs e)
    {
        uCls = new UtilityClass(this.Page);
        uCls.ResetTheSessionVariables();
        Session["SectionWiseDocStatus"] = e.PostBackValue;
        Session["SectionWiseSearch"] = "1";


        int docStatusID = 1;
        if (e.PostBackValue.Equals("Open"))
            docStatusID = 1;
        else if (e.PostBackValue.Equals("For Follow Up"))
            docStatusID = 2;
        else if (e.PostBackValue.Equals("Pending"))
            docStatusID = 3;

        Response.Redirect("~/Documents/DocumentRegister.aspx?docStatID=" + docStatusID, false);           

    }
    protected void onGoingTasksPerSectionChart_Click(object sender, ImageMapEventArgs e)
    {
       
        Session["JobType"] = e.PostBackValue;
        uCls = new UtilityClass(this.Page);
        uCls.ResetTheSessionVariables();
        Response.Redirect("~/Documents/MyDocuments.aspx", false);

    }
    protected void lnkBtnRefNo_Click(object sender, EventArgs e)
    {
        string strUpdateJob = Request.Url.AbsoluteUri;
        Session["UrlRef"] = strUpdateJob;
        try
        {
            //Get the LinkButton that raised the event
            LinkButton lnkDocRefNo = (LinkButton)sender;
            //Get the row that contains this dropdown
            GridViewRow gvr = (GridViewRow)lnkDocRefNo.NamingContainer;
            Session["DocID"] = ((HtmlGenericControl)gvr.FindControl("divDocID")).InnerText;
            Session["DocCategoryID"] = ((HtmlGenericControl)gvr.FindControl("divDocCatID")).InnerText;
            Session["UrlRef"] = "~/JobOrder/DefaultWindow.aspx";
            Response.Redirect("~/Documents/DocumentDetailsWindow.aspx?docCaiD=1", false);
        }
        catch (Exception ex)
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Error occurred while processing the request')</script>", false);
        }
    }
    protected void gridDocs_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            try
            {
                uCls = new UtilityClass(this.Page);
                Control ctrlSuperseded = e.Row.FindControl("divReceiveSuperseded");

                if (ctrlSuperseded != null)
                {
                    HtmlGenericControl htmlCtrlSuperseded = ctrlSuperseded as HtmlGenericControl;
                    e.Row.Cells[1].BackColor = System.Drawing.Color.WhiteSmoke;
                    e.Row.Cells[1].ForeColor = System.Drawing.Color.Gray;

                    e.Row.Cells[2].BackColor = System.Drawing.Color.WhiteSmoke;
                    e.Row.Cells[2].ForeColor = System.Drawing.Color.Gray;
                }
            }
            catch (Exception ex)
            {
                ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Error occurred while performing database operation')</script>", false);
            }
        }
    }
    private void getAllDocumentDataChart()
    {
        string sqlQuery = string.Empty; string strTitle = string.Empty;

        int secID = Convert.ToInt32(Session["SectionID"]);

        if (Session["userProfileID"].ToString().Equals("1"))
        {
            sqlQuery = "SELECT DocumentStatus.docStatusName, COUNT(DocumentDistribution.documentID) AS docCnt FROM    DocumentDistribution INNER JOIN " + 
                        " DocumentStatus ON DocumentDistribution.docStatusID = DocumentStatus.docStatusID WHERE   (DocumentDistribution.docStatusID <> 4) GROUP BY DocumentStatus.docStatusName";

            lblSection.Text = " All Documents In All Section of EBSD";
        }
        else if (!userRightsColl.Contains("1") && Session["SectionID"].ToString().Equals("7"))
        {          

            sqlQuery = "SELECT DocumentStatus.docStatusName, COUNT(DocumentDistribution.documentID) AS docCnt FROM    DocumentDistribution INNER JOIN " +
                        " DocumentStatus ON DocumentDistribution.docStatusID = DocumentStatus.docStatusID WHERE   (DocumentDistribution.docStatusID <> 4) GROUP BY DocumentStatus.docStatusName";

            lblSection.Text = " All Documents In All Section of EBSD";
        }        
        else 
        {
            sqlQuery = "SELECT DocumentStatus.docStatusName, COUNT(DocumentDistribution.documentID) AS docCnt FROM DocumentDistribution INNER JOIN " + 
              " DocumentStatus ON DocumentDistribution.docStatusID = DocumentStatus.docStatusID INNER JOIN   Contact ON DocumentDistribution.contactID = Contact.contactID AND DocumentDistribution.contactID = Contact.contactID " + 
                          " WHERE (DocumentDistribution.docStatusID <> 4) AND (Contact.sectionID = " + secID + ") GROUP BY DocumentStatus.docStatusName";

            lblSection.Text = " All Documents In " + Session["SectionName"].ToString();
        }

        SqlConnection objCon = new SqlConnection(connValue);
        objCon.Open();
        SqlCommand objCmd = new SqlCommand(sqlQuery, objCon);
        SqlDataAdapter objDA = new SqlDataAdapter(objCmd);        
        DataSet dsTndr123 = new DataSet();
        objDA.Fill(dsTndr123);

        if (dsTndr123.Tables[0].Rows.Count != 0)
        {
            chartSectionWiseDoc.DataSource = dsTndr123.Tables[0].DefaultView;
            chartSectionWiseDoc.Series["Series1"].XValueMember = "docStatusName";
            chartSectionWiseDoc.Series["Series1"].YValueMembers = "DocCnt";
            dsTndr123.Tables.Clear();

            chartSectionWiseDoc.ChartAreas[0].AxisX.MajorGrid.Enabled = false;
            chartSectionWiseDoc.ChartAreas[0].AxisX.MinorGrid.Enabled = false;
            chartSectionWiseDoc.ChartAreas[0].AxisY.MajorGrid.Enabled = false;
            chartSectionWiseDoc.ChartAreas[0].AxisY.MinorGrid.Enabled = false;

            chartSectionWiseDoc.ChartAreas[0].AxisX.LabelStyle.Angle = 30;
            chartSectionWiseDoc.ChartAreas[0].AxisX.LabelStyle.ForeColor = Color.Maroon;

            chartSectionWiseDoc.ChartAreas[0].AxisX.Interval = 1;
        }
        objCon.Close();
       
    }
    private void _getDocumentsUnderIssue()
    {
        string sqlQuery = string.Empty;

        sqlQuery = "SELECT  COUNT(ID) AS IssueCnt, IssueName FROM  IssueInfo GROUP BY IssueName";


        SqlConnection objCon = new SqlConnection(connValue);
        objCon.Open();
        SqlCommand objCmd = new SqlCommand(sqlQuery, objCon);
        SqlDataAdapter objDA = new SqlDataAdapter(objCmd);
        DataSet dsTndr123 = new DataSet();
        objDA.Fill(dsTndr123);

        if (dsTndr123.Tables[0].Rows.Count != 0)
        {
            chartIssues.DataSource = dsTndr123.Tables[0].DefaultView;
            chartIssues.Series["Series1"].XValueMember = "IssueName";
            chartIssues.Series["Series1"].YValueMembers = "IssueCnt";
            dsTndr123.Tables.Clear();

            chartIssues.ChartAreas[0].AxisX.MajorGrid.Enabled = false;
            chartIssues.ChartAreas[0].AxisX.MinorGrid.Enabled = false;
            chartIssues.ChartAreas[0].AxisY.MajorGrid.Enabled = false;
            chartIssues.ChartAreas[0].AxisY.MinorGrid.Enabled = false;

            chartIssues.ChartAreas[0].AxisX.LabelStyle.Angle = 30;
            chartIssues.ChartAreas[0].AxisX.LabelStyle.ForeColor = Color.Maroon;

            chartIssues.ChartAreas[0].AxisX.Interval = 1;
        }
        objCon.Close();

    }
    private void _getRiskTask()
    {
        string sqlQuery = string.Empty;

        sqlQuery = "SELECT COUNT(ID) AS RiskCnt, RiskName FROM  RiskInfo GROUP BY RiskName";


        SqlConnection objCon = new SqlConnection(connValue);
        objCon.Open();
        SqlCommand objCmd = new SqlCommand(sqlQuery, objCon);
        SqlDataAdapter objDA = new SqlDataAdapter(objCmd);
        DataSet dsTndr123 = new DataSet();
        objDA.Fill(dsTndr123);

        if (dsTndr123.Tables[0].Rows.Count != 0)
        {
            chartRiskRegister.DataSource = dsTndr123.Tables[0].DefaultView;
            chartRiskRegister.Series["Series1"].XValueMember = "RiskName";
            chartRiskRegister.Series["Series1"].YValueMembers = "RiskCnt";
            dsTndr123.Tables.Clear();

            chartRiskRegister.ChartAreas[0].AxisX.MajorGrid.Enabled = false;
            chartRiskRegister.ChartAreas[0].AxisX.MinorGrid.Enabled = false;
            chartRiskRegister.ChartAreas[0].AxisY.MajorGrid.Enabled = false;
            chartRiskRegister.ChartAreas[0].AxisY.MinorGrid.Enabled = false;

            chartRiskRegister.ChartAreas[0].AxisX.LabelStyle.Angle = 30;
            chartRiskRegister.ChartAreas[0].AxisX.LabelStyle.ForeColor = Color.Maroon;

            chartRiskRegister.ChartAreas[0].AxisX.Interval = 1;
        }
        objCon.Close();
    }
    protected void lnKShowAll_Click(object sender, EventArgs e)
    {
        string strUpdateJob = Request.Url.AbsoluteUri;
        Session["UrlRef"] = strUpdateJob;

        getAllDocumentDataChart();
        _getDocumentsUnderIssue();
        _getRiskTask();

        if (!userRightsColl.Contains("1"))
        {
            panelShow.Visible = true;
            panelMain.Visible = false;
            PanelAdminReport.Visible = false;
        }      
    }
    protected void lnkHide_Click(object sender, EventArgs e)
    {
        string strUpdateJob = Request.Url.AbsoluteUri;
        Session["UrlRef"] = strUpdateJob;
       
            getMyDocumentChart();          

        if (Session["SectionID"].Equals("4"))
            getUnReadInchargeDataOgSurveyOracle();
        else
            getUnReadInchargeData();

          //  getOnGoingTasksPerSection();

            getOnGoingTasksPerSection_New();

            new JobOrderData().UpdateForFoloowupDocstatus();
            new JobOrderData().UpdateUserAutoReplyStatus();       


            if (!userRightsColl.Contains("42"))
                getOnGoingTasksPerStaffChart();
            else
            {
                trlblStaff.Visible = false;
                trchartStaff.Visible = false;
            }

            if (userRightsColl.Contains("1"))
                lnKShowAll.Visible = false;           

         
        panelShow.Visible = false;
        panelMain.Visible = true;
    }   
   
    
    protected void OngoingJobsClick(object sender, ImageMapEventArgs e)
    {
        // Basic Materials,A_ (PSA Contract),Cost Control Section,Payment Request,
        
        //Comitted Contract,Cost Estimate,Planning Schedule(Baseline),Non Committed Contracts

        Session["ActionBy"] = null; 

        string sectionName = Session["SectionName"].ToString();

        Session["OverDueName"] = e.PostBackValue.ToString();

        Session["OnGoingJobStatus"] = e.PostBackValue;

       // overdueJobs_old(sectionName);   

       // overdueJobs(Session["ShortName"].ToString());

        //Planning Schedule (Baseline)    //Cost Estimate       //A_ (PSA Contract) 


        if (Session["UserProfileID"].Equals("1"))
        {
            if (e.PostBackValue.Equals("Cost Control Section"))
            {
                Response.Redirect("~/DCLog/OverDueJobs.aspx", false);
            }
            else if (e.PostBackValue.Equals("Document Control"))
            {
                Response.Redirect("~/DCLog/OverDueJobs.aspx", false);
            }
            else if (e.PostBackValue.Equals("Payment Section"))
            {
                Response.Redirect("~/Payments/OverDuePayments.aspx", false);
            }
            else if (e.PostBackValue.Equals("Manager Requests"))
            {
                Response.Redirect("~/ManagerTask/OverDueRequests.aspx", false);
            }
            else if (sectionName.Trim().Equals("Business Support Section"))
            {
                Response.Redirect("~/Planning/ViewSRInfo.aspx", false);
            }
            else
            {

            }
        }
        else
        {
            if (lblOngoingJobs.Text.Equals("My On Going Tasks") & Session["SectionID"].Equals("1"))
            {
                Response.Redirect("~/JobOrder/JobOrder.aspx", false);
            }
            else if (e.PostBackValue.Equals("Manager Requests"))
            {
                Response.Redirect("~/ManagerTask/ViewManagerRequests.aspx", false);
            }
            else if (sectionName.Trim().Equals("Business Support Section"))
            {
                Response.Redirect("~/Planning/ViewSRInfo.aspx", false);
            }
            else if ((!Session["userProfileID"].Equals("2")) & Session["SectionID"].Equals("3"))
            {
                Response.Redirect("~/DCLog/ViewDCLog.aspx", false);
            }
            else if (Session["SectionName"].ToString().Equals("Cost Control Section") || Session["SectionName"].ToString().Equals("Planning and Scheduling"))
            {
                Response.Redirect("~/DCLog/OverDueJobs.aspx", false);
            }
            else if (sectionName.Equals("Payment Section") || sectionName.Equals("Payment Request"))
            {
                if (lblOngoingJobs.Text.Equals("My On Going Tasks"))
                    Response.Redirect("~/Payments/ViewPayments.aspx", false);
                else
                    Response.Redirect("~/Payments/OverDuePayments.aspx", false);
            }
            else if (sectionName.Trim().Equals("Document Control") || Session["userProfileID"].Equals("2"))           //Document Request     Document Control Section       // sectionName.Equals("Review Baseline Schedule")
            {
                Response.Redirect("~/DCLog/OverDueJobs.aspx", false);
            }
            else if ((e.PostBackValue.Trim().ToString().Equals("Document Control")) && (Session["userProfileID"].Equals("1")))
            {
                Response.Redirect("~/DCLog/OverDueJobs.aspx", false);
            }
            else if ((e.PostBackValue.ToString().Equals("Cost Control Section")) && (Session["userProfileID"].Equals("1")))
            {
                Response.Redirect("~/DCLog/OverDueJobs.aspx", false);
            }
            else if ((e.PostBackValue.ToString().Equals("Payment Section")) && (Session["userProfileID"].Equals("1")))
            {
                Response.Redirect("~/Payments/OverDuePayments.aspx", false);
            }
            else if (lblOngoingJobs.Text.Contains("Over Due") & Session["SectionID"].Equals("3"))
            {
                Response.Redirect("~/DCLog/OverDueJobs.aspx", false);
            }
            else if (sectionName.Equals("Manager Requests"))
            {
                Response.Redirect("~/ManagerTask/OverDueRequests.aspx", false);
            }            
            else
            {
                ClientScript.RegisterClientScriptBlock(this.GetType(), "Popup", "<script>alert('Restricted Access!')</script>", false);
            }
        }
    }

    private void overdueJobs(string sectionName)
    { 
        if (Session["SectionName"].ToString().Equals("Cost Control Section") || Session["SectionName"].ToString().Equals("Planning and Scheduling"))
        {
            if (!userRightsColl.Contains("5") || !userRightsColl.Contains("42"))
            {
                
                string cmtName = Session["OnGoingJobStatus"].ToString().Trim();

                if ((Session["SectionID"].ToString() == "1") || (Session["SectionID"].ToString() == "6"))       
                {
                    if (cmtName.Equals("Cost Control Section"))
                        Response.Redirect("~/DCLog/OverDueJobs.aspx", false);

                    else if (cmtName.Trim().Equals("Comitted Contract"))
                        Response.Redirect("~/JobOrder/JobOrder.aspx", false);
                    

                    else if (cmtName.Equals("Non Committed Contracts"))
                        Response.Redirect("~/JobOrder/JobOrder.aspx", false);
                   

                    else if (cmtName.Equals("Basic Materials"))
                        Response.Redirect("~/JobOrder/JobOrder.aspx", false);
                 

                    else if (cmtName.Equals("Cost Estimate"))
                        Response.Redirect("~/JobOrder/JobOrder.aspx", false);
                   

                    else if (cmtName.Contains("Planning Schedule"))
                        Response.Redirect("~/JobOrder/JobOrder.aspx", false);
                    

                    else if (cmtName.Equals("A_ (PSA Contract)"))
                        Response.Redirect("~/JobOrder/JobOrder.aspx", false);
                    
                }
            }
        }
        else if (sectionName.Equals("Payment Section") || sectionName.Equals("Payment Request"))
        {
            Response.Redirect("~/Payments/ViewPayments.aspx", false);
        }
        else if (sectionName.Equals("Document Request") || sectionName.Equals("Review Baseline Schedule"))           //Document Request     Document Control Section
        {
            Response.Redirect("~/DCLog/ViewDCLog.aspx", false);
        }
        else
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "Popup", "<script>alert('Restricted Access!')</script>", false);
        }
    }
    //private void overdueJobs_old(string sectionName)
    //{
       
    //    if (Session["SectionName"].ToString().Equals("Cost Control Section") || Session["SectionName"].ToString().Equals("Planning and Scheduling"))
    //    {
    //        if (!userRightsColl.Contains("5") || !userRightsColl.Contains("42"))
    //        {
    //            Session["OnGoingJobStatus"] = e.PostBackValue;
    //            string cmtName = Session["OnGoingJobStatus"].ToString().Trim();

    //            if ((Session["SectionID"].ToString() == "1") || (Session["SectionID"].ToString() == "6"))         // 48 - plannig schedule
    //            {
    //                if (cmtName.Equals("Cost Control Section")) //Payment Request
    //                    Response.Redirect("~/JobOrder/JobOrder.aspx", false);

    //                else if (cmtName.Trim().Equals("Comitted Contract"))
    //                    Response.Redirect("~/JobOrder/JobOrder.aspx", false);
    //                //Response.Redirect("~/JobOrder/SearchJobMstr.aspx", false);

    //                else if (cmtName.Equals("Non Committed Contracts"))
    //                    Response.Redirect("~/JobOrder/JobOrder.aspx", false);
    //                //  Response.Redirect("~/JobOrder/SearchJobMstr.aspx", false);

    //                else if (cmtName.Equals("Basic Materials"))
    //                    Response.Redirect("~/JobOrder/JobOrder.aspx", false);
    //                //Response.Redirect("~/JobOrder/SearchJobMstr.aspx", false);

    //                else if (cmtName.Equals("Cost Estimate"))
    //                    Response.Redirect("~/JobOrder/JobOrder.aspx", false);
    //                //Response.Redirect("~/JobOrder/SearchJobMstr.aspx", false);

    //                else if (cmtName.Contains("Planning Schedule"))
    //                    Response.Redirect("~/JobOrder/JobOrder.aspx", false);
    //                // Response.Redirect("~/JobOrder/SearchJobMstr.aspx", false);

    //                else if (cmtName.Equals("A_ (PSA Contract)"))
    //                    Response.Redirect("~/JobOrder/JobOrder.aspx", false);
    //                //Response.Redirect("~/JobOrder/SearchAdmData.aspx", false); 
    //            }
    //        }
    //    }
    //    else if (sectionName.Equals("Payment Section") || sectionName.Equals("Payment Request"))
    //    {
    //        Response.Redirect("~/Payments/ViewPayments.aspx", false);
    //    }
    //    else if (sectionName.Equals("Document Request") || sectionName.Equals("Review Baseline Schedule"))           //Document Request     Document Control Section
    //    {
    //        Response.Redirect("~/DCLog/ViewDCLog.aspx", false);
    //    }
    //    else
    //    {
    //        ClientScript.RegisterClientScriptBlock(this.GetType(), "Popup", "<script>alert('Restricted Access!')</script>", false);
    //    }
    //}
    protected void onGoingTasksPerStaffChart_Click(object sender, ImageMapEventArgs e)
    {
        //Session["OnGoingJobStatus"] = e.PostBackValue;
       // int cntID = getContactID(e.PostBackValue.ToString());
      
           Session["ShortName"] = e.PostBackValue.ToString();
           Session["ActionBy"] = null; 
           Session["ActionBy"] = e.PostBackValue.ToString();


           if (Session["SectionID"].Equals("9"))
               Response.Redirect("~/Planning/ViewSRInfo.aspx", false);
           else if (!Session["SectionID"].Equals("4"))
              Response.Redirect("~/JobOrder/SearchAllJobs.aspx", false);          
          else
              Response.Redirect("~/Survey/SurveyStaffJobs.aspx", false);

    }
    private int getContactID(string userName)
    {
        int cnctID = 0;
        SqlConnection sqlConn = new SqlConnection(connValue);
        string sqlQuery = "SELECT contactID From Contact Where userShortName = '" + userName + "' ";              

        try
        {
            sqlConn.Open();
            SqlCommand sqlCom = new SqlCommand(sqlQuery, sqlConn);
            SqlDataReader sqlReader = sqlCom.ExecuteReader();
            while (sqlReader.Read())
            {
                cnctID = Convert.ToInt32(sqlReader["contactID"].ToString());
            }
            sqlReader.Close();
        }
        catch (Exception ex)
        {
            Response.Write("Error getting while reading data !" + ex.Message);
        }
        finally
        {
            sqlConn.Close();
        }
        return cnctID;
    }

   // lnkSearchDoc_Click

    protected void lnkSearchDoc_Click(object sender, EventArgs e)
    {
        string strUpdateJob = Request.Url.AbsoluteUri;
        Session["UrlRef"] = strUpdateJob;

        //UtilityClass utils = new UtilityClass(this.Page);
        //string url = Request.Url.AbsoluteUri;
        //if (url.Contains(":"))
        //    url = url.Substring(0, utils.GetNthIndex(url, '/', 4));
        //else
        //    url = url.Substring(0, utils.GetNthIndex(url, '/', 2));

        //uCls = new UtilityClass(this.Page);
        //uCls.ResetTheSessionVariables();


        Session["SearchAllDocs"] = "1";
        Response.Redirect("~/Documents/DocumentRegister.aspx", false);


    }
    protected void onGoingTasksPerStaffChart_Load(object sender, EventArgs e)
    {

    }

    private void UpdateDocumentActionDueDate()
    {
        string actionDate = string.Empty;
        SqlConnection sqlConn = new SqlConnection(connValue);
        string sqlQuery = "SELECT  actionDueDate FROM DocumentDistribution  ";

        try
        {
            sqlConn.Open();
            SqlCommand sqlCom = new SqlCommand(sqlQuery, sqlConn);
            SqlDataReader sqlReader = sqlCom.ExecuteReader();
            while (sqlReader.Read())
            {
                actionDate = sqlReader["actionDueDate"].ToString();
                DateTime date1 = ConvertToDateTime(actionDate);
                DateTime date2 = ConvertToDateTime(System.DateTime.Now.ToString());
                int result123 = DateTime.Compare(date2, date1);
                if (result123 == 1)
                {

                }
            }
            sqlReader.Close();
        }
        catch (Exception ex)
        {
            Response.Write("Error getting while reading data !" + ex.Message);
        }
        finally
        {
            sqlConn.Close();
        }     
    }
    private DateTime ConvertToDateTime(string strDateTime)
    {
        DateTime dtFinaldate; string sDateTime;
        try
        {
            //dtFinaldate = Convert.ToDateTime(strDateTime); 

            string[] sDate = strDateTime.Split('/');
            sDateTime = sDate[1] + '/' + sDate[0] + '/' + sDate[2];
            dtFinaldate = Convert.ToDateTime(sDateTime);
        }
        catch (Exception e)
        {
            string[] sDate = strDateTime.Split('/');
            sDateTime = sDate[0] + '/' + sDate[1] + '/' + sDate[2];
            dtFinaldate = Convert.ToDateTime(sDateTime);
        }
        return dtFinaldate;
    }

   // UpdateDocumentStatusForFollowUp

    
    protected void gvCostEstimate_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        gvCostEstimate.PageIndex = e.NewPageIndex;
        System.Threading.Thread.CurrentThread.CurrentCulture = new System.Globalization.CultureInfo("ar-QA");
        
        
        DataTable dtGrid = fillCostEstimateData();
        gvCostEstimate.DataSource = dtGrid;
        gvCostEstimate.DataBind();


        filterData();

        //if (ddlDept.SelectedIndex == 0)
        //{
        //    gCostEstimateChart();
        //    gCostEstimateJobCountChart();
        //}
        //else
        //{
        //    filterData();
        //}

    }
    protected void ddlYear_SelectedIndexChanged(object sender, EventArgs e)
    {
        filterData();

        gvCostEstimate.DataSource = fillCostEstimateData();
        gvCostEstimate.DataBind();

        TextBox1.Text = fillCostEstimateAboveBudget().Rows[0][0].ToString();
        TextBox2.Text = fillCostEstimateBelowBudget().Rows[0][0].ToString();


        
    }
    private DataTable fillCostEstimateAboveBudget()
    {
        DataSet ds = new DataSet();
        try
        {

            Int32 affairID;
            Int32.TryParse(ddlAffair.SelectedValue, out affairID);

            Int32 deptID;
            Int32.TryParse(ddlDept.SelectedValue, out deptID);

            //string strYear = string.Empty;
            //if (ddlYear.SelectedItem.Text != "")
            //    strYear = ddlYear.SelectedItem.Text;

            Int32 strYear;
            Int32.TryParse(ddlYear.SelectedItem.Text, out strYear);

            string strMinistry = string.Empty;
            if (ddlMinistry.SelectedItem.Text != "")
                strMinistry = ddlMinistry.SelectedItem.Text;

            string strBudgetRef = string.Empty;
            if (ddlBudget.SelectedItem.Text != "")
                strBudgetRef = ddlBudget.SelectedItem.Text;

            string strProvNo = string.Empty;
            if (ddlProv.SelectedItem.Text != "")
                strProvNo = ddlProv.SelectedItem.Text;



            ds = new JobOrderData().GetCostAboveBudget(affairID, deptID, strYear, strMinistry, strBudgetRef, strProvNo);

            DataView dvCommitted = new DataView(ds.Tables[0]);

        }
        catch (Exception ex)
        {

        }
        return ds.Tables[0];
    }

    private DataTable fillCostEstimateBelowBudget()
    {
        DataSet ds = new DataSet();
        try
        {

            Int32 affairID;
            Int32.TryParse(ddlAffair.SelectedValue, out affairID);

            Int32 deptID;
            Int32.TryParse(ddlDept.SelectedValue, out deptID);

            //string strYear = string.Empty;
            //if (ddlYear.SelectedItem.Text != "")
            //    strYear = ddlYear.SelectedItem.Text;

            Int32 strYear;
            Int32.TryParse(ddlYear.SelectedItem.Text, out strYear);

            string strMinistry = string.Empty;
            if (ddlMinistry.SelectedItem.Text != "")
                strMinistry = ddlMinistry.SelectedItem.Text;

            string strBudgetRef = string.Empty;
            if (ddlBudget.SelectedItem.Text != "")
                strBudgetRef = ddlBudget.SelectedItem.Text;

            string strProvNo = string.Empty;
            if (ddlProv.SelectedItem.Text != "")
                strProvNo = ddlProv.SelectedItem.Text;

            ds = new JobOrderData().GetCostBelowBudget(affairID, deptID, strYear, strMinistry, strBudgetRef, strProvNo);

            DataView dvCommitted = new DataView(ds.Tables[0]);
        }
        catch (Exception ex)
        {

        }
        return ds.Tables[0];
    }
    private DataTable fillCostEstimateData()
    {
        DataSet ds = new DataSet();
        try
        {

            Int32 affairID;
            Int32.TryParse(ddlAffair.SelectedValue, out affairID);

            Int32 deptID;
            Int32.TryParse(ddlDept.SelectedValue, out deptID);

            //string strYear = string.Empty;
            //if (ddlYear.SelectedItem.Text != "")
            //    strYear = ddlYear.SelectedItem.Text;

            Int32 strYear;
            Int32.TryParse(ddlYear.SelectedItem.Text, out strYear);

            string strMinistry = string.Empty;
            if (ddlMinistry.SelectedItem.Text != "")
                strMinistry = ddlMinistry.SelectedItem.Text;

            string strBudgetRef = string.Empty;
            if (ddlBudget.SelectedItem.Text != "")
                strBudgetRef = ddlBudget.SelectedItem.Text;

            string strProvNo = string.Empty;
            if (ddlProv.SelectedItem.Text != "")
                strProvNo = ddlProv.SelectedItem.Text;

          

            ds = new JobOrderData().GetCostDataByFilter(affairID, deptID,strYear, strMinistry, strBudgetRef, strProvNo);

            DataView dvCommitted = new DataView(ds.Tables[0]);

        }
        catch (Exception ex)
        {

        }
        return ds.Tables[0];
    }


    private DataTable fillCostEstimateDataForChart()            //   
    {
        DataSet ds = new DataSet();
        try
        {

            Int32 affairID;
            Int32.TryParse(ddlAffair.SelectedValue, out affairID);

            Int32 deptID;
            Int32.TryParse(ddlDept.SelectedValue, out deptID);

            //string strYear = string.Empty;
            //if (ddlYear.SelectedItem.Text != "")
            //    strYear = ddlYear.SelectedItem.Text;

            Int32 strYear;
            Int32.TryParse(ddlYear.SelectedItem.Text, out strYear);

            string strMinistry = string.Empty;
            if (ddlMinistry.SelectedItem.Text != "")
                strMinistry = ddlMinistry.SelectedItem.Text;

            string strBudgetRef = string.Empty;
            if (ddlBudget.SelectedItem.Text != "")
                strBudgetRef = ddlBudget.SelectedItem.Text;

            string strProvNo = string.Empty;
            if (ddlProv.SelectedItem.Text != "")
                strProvNo = ddlProv.SelectedItem.Text;



            ds = new JobOrderData().GetCostDataByFilterForChart(affairID, deptID, strYear, strMinistry, strBudgetRef, strProvNo);

            DataView dvCommitted = new DataView(ds.Tables[0]);

        }
        catch (Exception ex)
        {

        }
        return ds.Tables[0];
    }

    private DataTable fillCostEstimateDataForJobCntChart()
    {
        DataSet ds = new DataSet();
        try
        {

            Int32 affairID;
            Int32.TryParse(ddlAffair.SelectedValue, out affairID);

            Int32 deptID;
            Int32.TryParse(ddlDept.SelectedValue, out deptID);

            //string strYear = string.Empty;
            //if (ddlYear.SelectedItem.Text != "")
            //    strYear = ddlYear.SelectedItem.Text;

            Int32 strYear;
            Int32.TryParse(ddlYear.SelectedItem.Text, out strYear);

            string strMinistry = string.Empty;
            if (ddlMinistry.SelectedItem.Text != "")
                strMinistry = ddlMinistry.SelectedItem.Text;

            string strBudgetRef = string.Empty;
            if (ddlBudget.SelectedItem.Text != "")
                strBudgetRef = ddlBudget.SelectedItem.Text;

            string strProvNo = string.Empty;
            if (ddlProv.SelectedItem.Text != "")
                strProvNo = ddlProv.SelectedItem.Text;



            ds = new JobOrderData().GetCostEstimateJobCntForChart(affairID, deptID, strYear, strMinistry, strBudgetRef, strProvNo);

            DataView dvCommitted = new DataView(ds.Tables[0]);

        }
        catch (Exception ex)
        {

        }
        return ds.Tables[0];
    }
    protected void ddlAffair_SelectedIndexChanged(object sender, EventArgs e)
    {
        filterData();

       gvCostEstimate.DataSource = fillCostEstimateData();
       gvCostEstimate.DataBind();

       TextBox1.Text = fillCostEstimateAboveBudget().Rows[0][0].ToString();
       TextBox2.Text = fillCostEstimateBelowBudget().Rows[0][0].ToString();

      
    }
    protected void ddlDept_SelectedIndexChanged(object sender, EventArgs e)
    {
        filterData();

        gvCostEstimate.DataSource = fillCostEstimateData();
        gvCostEstimate.DataBind();

        TextBox1.Text = fillCostEstimateAboveBudget().Rows[0][0].ToString();
        TextBox2.Text = fillCostEstimateBelowBudget().Rows[0][0].ToString();
    }
    protected void ddlMinistry_SelectedIndexChanged(object sender, EventArgs e)
    {
        filterData();

        gvCostEstimate.DataSource = fillCostEstimateData();
        gvCostEstimate.DataBind();

        TextBox1.Text = fillCostEstimateAboveBudget().Rows[0][0].ToString();
        TextBox2.Text = fillCostEstimateBelowBudget().Rows[0][0].ToString();
      
    }
    private void filterData()
    {
        System.Threading.Thread.CurrentThread.CurrentCulture = new System.Globalization.CultureInfo("ar-QA");
        DataTable dtChart = new DataTable();
        trClearButton.Visible = true;
        chartCostEstimate.DataSource = fillCostEstimateDataForChart();

        dtChart = fillCostEstimateDataForChart();

        if (dtChart.Rows.Count > 0)
        {
            Session["TotalBudget"] = dtChart.Rows[0][1].ToString();
            Session["TotalPMC"] = dtChart.Rows[0][2].ToString();
            Session["TotalEbsd"] = dtChart.Rows[0][3].ToString();
            Session["TotalAward"] = dtChart.Rows[0][4].ToString();
        }

        chartCostEstimate.Series["Series2"].XValueMember = "CategoryID";
        chartCostEstimate.Series["Series2"].YValueMembers = "PMCAmnt";

        chartCostEstimate.Series["Series3"].XValueMember = "CategoryID";
        chartCostEstimate.Series["Series3"].YValueMembers = "EBSDAmnt";

        chartCostEstimate.Series["Series1"].XValueMember = "CategoryID";
        chartCostEstimate.Series["Series1"].YValueMembers = "BudgetAmnt";


        chartCostEstimate.Series["Series4"].XValueMember = "CategoryID";
        chartCostEstimate.Series["Series4"].YValueMembers = "ContractAmnt";

        //dsDoc.Tables.Clear();

        chartCostEstimate.ChartAreas[0].AxisX.MajorGrid.Enabled = false;
        chartCostEstimate.ChartAreas[0].AxisX.MinorGrid.Enabled = false;
        chartCostEstimate.ChartAreas[0].AxisY.MajorGrid.Enabled = false;
        chartCostEstimate.ChartAreas[0].AxisY.MinorGrid.Enabled = false;

        chartCostEstimate.ChartAreas[0].AxisX.LabelStyle.Angle = 30;
        chartCostEstimate.ChartAreas[0].AxisX.LabelStyle.ForeColor = Color.Maroon;

        chartCostEstimate.ChartAreas[0].AxisX.Interval = 1;

        //-------------------------------------------------------------------------------------------------------




        chartCostJobCnt.DataSource = fillCostEstimateDataForJobCntChart();
        chartCostJobCnt.Series["Series1"].XValueMember = "Year";
        chartCostJobCnt.Series["Series1"].YValueMembers = "jobCnt";

        // dsDoc.Tables.Clear();

        chartCostJobCnt.ChartAreas[0].AxisX.MajorGrid.Enabled = false;
        chartCostJobCnt.ChartAreas[0].AxisX.MinorGrid.Enabled = false;
        chartCostJobCnt.ChartAreas[0].AxisY.MajorGrid.Enabled = false;
        chartCostJobCnt.ChartAreas[0].AxisY.MinorGrid.Enabled = false;

        chartCostJobCnt.ChartAreas[0].AxisX.LabelStyle.Angle = 30;
        chartCostJobCnt.ChartAreas[0].AxisX.LabelStyle.ForeColor = Color.Maroon;

        chartCostJobCnt.ChartAreas[0].AxisX.Interval = 1;
    }
    protected void ddlBudget_SelectedIndexChanged(object sender, EventArgs e)
    {
        filterData();

        gvCostEstimate.DataSource = fillCostEstimateData();
        gvCostEstimate.DataBind();

        TextBox1.Text = fillCostEstimateAboveBudget().Rows[0][0].ToString();
        TextBox2.Text = fillCostEstimateBelowBudget().Rows[0][0].ToString();
        
    }
    protected void ddlProv_SelectedIndexChanged(object sender, EventArgs e)
    {
        filterData();

        gvCostEstimate.DataSource = fillCostEstimateData();
        gvCostEstimate.DataBind();

        TextBox1.Text = fillCostEstimateAboveBudget().Rows[0][0].ToString();
        TextBox2.Text = fillCostEstimateBelowBudget().Rows[0][0].ToString();
    }
    protected void btnClear_Click(object sender, EventArgs e)
    {
        ddlAffair.SelectedIndex = -1;
        ddlDept.SelectedIndex = -1;
        ddlYear.SelectedIndex = -1;

        ddlMinistry.SelectedIndex = -1;
        ddlProv.SelectedIndex = -1; 
        ddlBudget.SelectedIndex = -1;

        trClearButton.Visible = false;

        gCostEstimateChart();
        CostEstimateReport();


        gCostEstimateJobCountChart();

        TextBox1.Text = fillCostEstimateAboveBudget().Rows[0][0].ToString();
        TextBox2.Text = fillCostEstimateBelowBudget().Rows[0][0].ToString();

    
    }
    double total = 0;
    double totalBudgetAmount = 0;
    double totalPMCAmount = 0;
    double totalEBSDAmount = 0;
    double totalAwardAmount = 0;
    protected void gvCostEstimate_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {

        }

        
        if (e.Row.RowType == DataControlRowType.Footer)
        {
            e.Row.Cells[2].Text = "Grand Total";
            e.Row.Cells[2].Font.Bold = true;
            e.Row.Cells[2].HorizontalAlign = HorizontalAlign.Center;

           // e.Row.Cells[3].Text = Convert.ToDouble(Session["TotalBudget"]).ToString();
            if (Session["TotalBudget"] != "")
            {
                e.Row.Cells[3].Text = Convert.ToDecimal(Session["TotalBudget"]).ToString("#,##0");
                e.Row.Cells[3].Font.Bold = true;
                e.Row.Cells[3].HorizontalAlign = HorizontalAlign.Center;
            }
            if (Session["TotalPMC"] != "")
            {
                e.Row.Cells[4].Text = Convert.ToDecimal(Session["TotalPMC"]).ToString("#,##0");
                e.Row.Cells[4].Font.Bold = true;
                e.Row.Cells[4].HorizontalAlign = HorizontalAlign.Center;
            }
            if (Session["TotalEbsd"] != "")
            {
                e.Row.Cells[5].Text = Convert.ToDecimal(Session["TotalEbsd"]).ToString("#,##0");
                e.Row.Cells[5].Font.Bold = true;
                e.Row.Cells[5].HorizontalAlign = HorizontalAlign.Center;
            }
            if (Session["TotalAward"] != "")
            {
                e.Row.Cells[6].Text = Convert.ToDecimal(Session["TotalAward"]).ToString("#,##0");
                e.Row.Cells[6].Font.Bold = true;
                e.Row.Cells[6].HorizontalAlign = HorizontalAlign.Center;
            }
            if (Session["TotalAward"] != "")
            {
                e.Row.Cells[6].Text = Convert.ToDecimal(Session["TotalAward"]).ToString("#,##0");
                e.Row.Cells[6].Font.Bold = true;
                e.Row.Cells[6].HorizontalAlign = HorizontalAlign.Center;
            }




            //Session["TotalBudget"] = dsDoc.Tables[0].Rows[0][1].ToString();
            //Session["TotalPMC"] = dsDoc.Tables[0].Rows[0][2].ToString();
            //Session["TotalEbsd"] = dsDoc.Tables[0].Rows[0][3].ToString();
            //Session["TotalAward"] = dsDoc.Tables[0].Rows[0][4].ToString();

            //Label lblTotalqty = (Label)e.Row.FindControl("lblbudgetSum");
            //lblTotalqty.Text = total.ToString();
        }
    }
    protected void btnExport_Click(object sender, EventArgs e)
    {
        //Response.ClearContent();
        //Response.AppendHeader("content-disposition", "attachment; filename=Cost Estimate Report.xls");
        //Response.ContentType = "application/excel";

        //StringWriter stringWriter = new StringWriter();
        //HtmlTextWriter htmlTextWriter = new HtmlTextWriter(stringWriter);



        Response.Clear();
        Response.AddHeader("content-disposition", "attachment;filename=ExportData1.xls");
        Response.Charset = "";
        Response.ContentType = "application/vnd.xls";
        StringWriter StringWriter = new System.IO.StringWriter();
        HtmlTextWriter HtmlTextWriter = new HtmlTextWriter(StringWriter);

        gvCostEstimate.RenderControl(HtmlTextWriter);
        Response.Write(StringWriter.ToString());
        Response.End();  
        
    }
 //   <span style="font-size: 9pt;"> </span>
    public override void VerifyRenderingInServerForm(Control control)
    {
        /* Confirms that an HtmlForm control is rendered for the specified ASP.NET
           server control at run time. */
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        PanelAdminReport.Visible = false;
        TableOngoingTaskChart.Visible = true;

        getMyDocumentChart();        
        getOnGoingTasksPerSection();

        getPayAffairWiseChart();

        if (!userRightsColl.Contains("42"))
            getOnGoingTasksPerStaffChart();
        else
        {
            trlblStaff.Visible = false;
            trchartStaff.Visible = false;
        }
    }
    protected void chartPayAffair_Click(object sender, ImageMapEventArgs e)
    {

    }
    private void getPayAffairWiseChart()
    {
        string sqlQuery = string.Empty;

        //sqlQuery = "SELECT COUNT(Payment.payID) AS PayCnt, Department.deptName  FROM Payment INNER JOIN  Department ON Payment.deptID = Department.departmentID  GROUP BY Department.affairID, Department.deptName";


        // sqlQuery = "SELECT        COUNT(Payment.payID) AS PayCnt, Affair.affairName FROM  Department INNER JOIN  Affair ON Department.affairID = Affair.affairID RIGHT OUTER JOIN   Payment ON Department.departmentID = Payment.deptID GROUP BY Affair.affairName";

        sqlQuery = " SELECT Affair.affairName, COUNT(Affair.affairName) AS PayCnt " +
                           " FROM  Department INNER JOIN Affair ON Department.affairID = Affair.affairID RIGHT OUTER JOIN Payment ON Department.departmentID = Payment.deptID " +
                      " GROUP BY Affair.affairName UNION ALL SELECT 'Total' AS Total, COUNT(Affair_1.affairName) AS Expr1 FROM Department AS Department_1 INNER JOIN Affair AS Affair_1 ON Department_1.affairID = Affair_1.affairID RIGHT OUTER JOIN " +
                        "  Payment AS Payment_1 ON Department_1.departmentID = Payment_1.deptID";        
        
        
        SqlConnection objCon = new SqlConnection(connValue);
        objCon.Open();
        SqlCommand objCmd = new SqlCommand(sqlQuery, objCon);
        SqlDataAdapter objDA = new SqlDataAdapter(objCmd);
        DataSet dsTndr123 = new DataSet();
        objDA.Fill(dsTndr123);

        if (dsTndr123.Tables[0].Rows.Count != 0)
        {
            chartPayAffair.DataSource = dsTndr123.Tables[0].DefaultView;
            chartPayAffair.Series["Series1"].XValueMember = "affairName";
            chartPayAffair.Series["Series1"].YValueMembers = "PayCnt";
           
            dsTndr123.Tables.Clear();

            chartPayAffair.ChartAreas[0].AxisX.MajorGrid.Enabled = false;
            chartPayAffair.ChartAreas[0].AxisX.MinorGrid.Enabled = false;
            chartPayAffair.ChartAreas[0].AxisY.MajorGrid.Enabled = false;
            chartPayAffair.ChartAreas[0].AxisY.MinorGrid.Enabled = false;

            chartPayAffair.ChartAreas[0].AxisX.LabelStyle.Angle = 30;
            chartPayAffair.ChartAreas[0].AxisX.LabelStyle.ForeColor = Color.Maroon;

            chartPayAffair.ChartAreas[0].AxisX.Interval = 1;
        }

        objCon.Close();
    }

    protected void onGoingTasksPerSectionChart_Load(object sender, EventArgs e)
    {

    }
    protected void lnkGenerateReports0_Click(object sender, EventArgs e)
    {
        string strUpdateJob = Request.Url.AbsoluteUri;
        Session["UrlRef"] = strUpdateJob;
        if (userRightsColl.Contains("19"))   //Add New Project
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "Popup", "<script>alert('You have no privilege to Search Job Order Log.')</script>", false);
            return;
        }
        else
        {
            Response.Redirect("~/Payments/SearchPayment.aspx", false);
        }
    }
    protected void gridTasks_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        gridTasks.PageIndex = e.NewPageIndex;
       // bindGridView();

        DataTable dt = new DataTable();
        dt = Session["getPayData"] as DataTable;

      //  lblCnt.Text = "(" + dt.Rows.Count.ToString() + ")";

        gridTasks.DataSource = dt;
        gridTasks.DataBind();

        PageloadData();
    }
    private void bindGridView()
    {
        gridTasks.DataSource = Session["getPayData"];
        gridTasks.DataBind();

    }
   
    protected void UpdateeBookPCMCommittmentNo()
    {
        string strQuery = "SELECT commitment_no,ID FROM PCM_CNMT_TABLE WHERE (commitment_no <> N'')";
        Dictionary<int, string> pcmDataCollMain = new Dictionary<int, string>();

        using (SqlConnection con = new SqlConnection(connValue))
        {
            using (SqlCommand sqlCmd = new SqlCommand())
            {
                sqlCmd.CommandText = strQuery;
                sqlCmd.Connection = con;

                con.Open();
                using (SqlDataReader dr = sqlCmd.ExecuteReader())
                {
                    while (dr.Read())
                    {
                        string strCntr = string.Empty;
                        strCntr = dr["commitment_no"].ToString();

                        string strCntrSlas = string.Empty;
                        string[] strColl = strCntr.Split('/');

                        if (strColl.Length == 3)
                            strCntrSlas = strColl[0] + strColl[1] + strColl[2];
                        else if (strColl.Length == 2)
                            strCntrSlas = strColl[0] + strColl[1];
                        else if (strColl.Length == 1)
                            strCntrSlas = strColl[0];

                        string[] strColl2 = strCntrSlas.Split(' ');

                        if (strColl2.Length == 2)
                            strCntrSlas = strColl2[0] + strColl2[1];

                        pcmDataCollMain.Add(Convert.ToInt32(dr["ID"]), strCntrSlas);
                    }
                }
            }
        }

        UpdatePayment(pcmDataCollMain); 
    }
    private void UpdatePayment(Dictionary<int,string> pcmDataColl)
    {
        int pcmID =0;
        string eBookCntrNo = string.Empty;
       

        foreach (int key in pcmDataColl.Keys)
        {
            pcmID = key;
            eBookCntrNo = pcmDataColl[key];

            try
            {
                using (SqlConnection con = new SqlConnection(connValue))
                {
                    using (SqlCommand sqlCmd = new SqlCommand())
                    {
                        sqlCmd.Connection = con;
                        sqlCmd.CommandType = CommandType.Text;
                        sqlCmd.CommandText = "UPDATE PCM_CNMT_TABLE SET eBook_commitment_no =@eBookcommitment_no where ID = @PCMID";
                        sqlCmd.Parameters.AddWithValue("@PCMID", pcmID);
                        sqlCmd.Parameters.AddWithValue("@eBookcommitment_no", eBookCntrNo);

                        con.Open();
                        sqlCmd.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
    protected void lnkDueJobs_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/DCLog/OverDueJobs.aspx", false);
    }
    protected void Survey(object sender, ImageMapEventArgs e)
    {
        Response.Redirect("~/Survey/SearchSurveyLog.aspx", false);
    }
    protected void onGoingSurveyTasks_Load(object sender, EventArgs e)
    {

    }
    //private void getOnGoingSurveyTasks()   
    //{
    //    string sqlQuery = string.Empty; string strStaff = string.Empty;

    //    DataSet dsTndr = new DataSet();
    //    int sectionID = Convert.ToInt32(Session["SectionID"]);

       
    //        lblOngoingStaff.Text = "On Going Tasks Per Staff In EBSD " + Session["SectionName"].ToString();

    //        //sqlQuery = "SELECT COUNT(*) AS JobCnt, Contact.userShortName FROM  JobOwner INNER JOIN  Contact ON JobOwner.contactID = Contact.contactID " +
    //        //          " WHERE  (JobOwner.sectionID = " + sectionID + ") AND (JobOwner.jobOwnerStatusID = 3) GROUP BY JobOwner.contactID, Contact.userShortName ORDER BY Contact.userShortName";

    //        sqlQuery = "SELECT  COUNT(REQUEST_ID) AS JobCnt, STATUS FROM  SURVEY_INFO GROUP BY STATUS";

    //        //sqlQuery = "SELECT COUNT(Job.jobID) AS JobCnt, JobType_1.jobTypeName FROM JobType AS JobType_1 INNER JOIN JobType ON JobType_1.jobTypeID = JobType.CategoryID INNER JOIN  Job ON JobType.jobTypeID = Job.jobTypeID INNER JOIN " +
    //        //         " Section ON JobType.sectionID = Section.sectionID WHERE (JobType.sectionID = 4) AND (Job.jobDueDate < GETDATE()-1) AND (Job.jobStatusID IN (3,8)) GROUP BY JobType_1.jobTypeName";
          
    //        lblOngoingJobs.Text = "Over Due Job Order In Cost Control Section";       

    //    SqlDataAdapter daTndr = new SqlDataAdapter(sqlQuery, connValue);
    //    daTndr.Fill(dsTndr);
    //    if (dsTndr.Tables[0].Rows.Count != 0)
    //    {
    //        onGoingSurveyTasks.DataSource = dsTndr.Tables[0].DefaultView;
    //        onGoingSurveyTasks.Series["Series1"].XValueMember = "STATUS";
    //        onGoingSurveyTasks.Series["Series1"].YValueMembers = "JobCnt";
    //        dsTndr.Tables.Clear();

    //        onGoingSurveyTasks.ChartAreas[0].AxisX.MajorGrid.Enabled = false;
    //        onGoingSurveyTasks.ChartAreas[0].AxisX.MinorGrid.Enabled = false;
    //        onGoingSurveyTasks.ChartAreas[0].AxisY.MajorGrid.Enabled = false;
    //        onGoingSurveyTasks.ChartAreas[0].AxisY.MinorGrid.Enabled = false;

    //        onGoingSurveyTasks.ChartAreas[0].AxisX.LabelStyle.Angle = 30;
    //        onGoingSurveyTasks.ChartAreas[0].AxisX.LabelStyle.ForeColor = Color.Maroon;

    //        onGoingSurveyTasks.ChartAreas[0].AxisX.Interval = 1;
    //    }
    //}
    protected void onGoingTasksofSurvey_Load(object sender, EventArgs e)
    {

    }
    protected void onGoingTasksofSurvey_Click(object sender, ImageMapEventArgs e)
    {
        string sectionName = Session["SectionName"].ToString();

        Session["OverDueName"] = e.PostBackValue.ToString();

        Session["OnGoingJobStatus"] = e.PostBackValue;   
       
        if (Session["SectionID"].Equals("4"))
        {
            Response.Redirect("~/Survey/SurveyProcessGraphInfo.aspx", false);
        }
        else
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "Popup", "<script>alert('Restricted Access!')</script>", false);
        }
    }

    private void getOnGoingTasksofManager()
    {
        DataSet dsTndr = new DataSet();

        string sqlQuery = null; int secID = Convert.ToInt32(Session["SectionID"]);
        string strSeriesName = string.Empty;

        if (Session["userProfileID"].ToString().Equals("1"))   // For Admin
        {
            sqlQuery = "select Count(status) as JobCnt, status from survey_info where status Not IN ('CLOSED','Old','CANCEL' ) group by status";
            strSeriesName = "sectionName";

            lblOngoingSurvey.Text = "Manager Request Details";
        }
        else
        {
            // sqlQuery = "select COUNT(*) as JobCnt,state_id as status from app_resource_allocation where user_id = 'tsd_osoro' and state_id = 'OPEN'  group by state_id";

            sqlQuery = "select Count(status) as JobCnt, status from survey_info where status Not IN ('CLOSED','Old','CANCEL' ) group by status";
            strSeriesName = "sectionName";
            lblOngoingMngr.Text = "Manager Request Details";
        }

        OracleDataAdapter daTndr = new OracleDataAdapter(sqlQuery, connValueOracle);
        daTndr.Fill(dsTndr);

        if (dsTndr.Tables[0].Rows.Count != 0)
        {
            onGoingTaskMngr.DataSource = dsTndr.Tables[0].DefaultView;

            onGoingTaskMngr.Series["Series1"].XValueMember = "status";
            onGoingTaskMngr.Series["Series1"].YValueMembers = "JobCnt";

            dsTndr.Tables.Clear();

            onGoingTaskMngr.ChartAreas[0].AxisX.MajorGrid.Enabled = false;
            onGoingTaskMngr.ChartAreas[0].AxisX.MinorGrid.Enabled = false;
            onGoingTaskMngr.ChartAreas[0].AxisY.MajorGrid.Enabled = false;
            onGoingTaskMngr.ChartAreas[0].AxisY.MinorGrid.Enabled = false;

            onGoingTaskMngr.ChartAreas[0].AxisX.LabelStyle.Angle = 30;
            onGoingTaskMngr.ChartAreas[0].AxisX.LabelStyle.ForeColor = Color.Maroon;

            onGoingTaskMngr.ChartAreas[0].AxisX.Interval = 1;
        }
    }


    private void getOnGoingTasksofSurveyOracle()
    {
        DataSet dsTndr = new DataSet();

        string sqlQuery = null; int secID = Convert.ToInt32(Session["SectionID"]);
        string strSeriesName = string.Empty;

        if (Session["userProfileID"].ToString().Equals("1"))   // For Admin
        {
            sqlQuery = "select Count(status) as JobCnt, status from survey_info where status Not IN ('CLOSED','Old','CANCEL' ) group by status";
            strSeriesName = "sectionName";

            lblOngoingSurvey.Text = "Survey Process Details";
        }
        else
        {
           // sqlQuery = "select COUNT(*) as JobCnt,state_id as status from app_resource_allocation where user_id = 'tsd_osoro' and state_id = 'OPEN'  group by state_id";

            sqlQuery = "select Count(status) as JobCnt, status from survey_info where status Not IN ('CLOSED','Old','CANCEL' ) group by status";
            strSeriesName = "sectionName";
            lblOngoingSurvey.Text = "Survey Process Details";
        }

        OracleDataAdapter daTndr = new OracleDataAdapter(sqlQuery, connValueOracle);
        daTndr.Fill(dsTndr);

        if (dsTndr.Tables[0].Rows.Count != 0)
        {
            onGoingTasksofSurvey.DataSource = dsTndr.Tables[0].DefaultView;

            onGoingTasksofSurvey.Series["Series1"].XValueMember = "status";
            onGoingTasksofSurvey.Series["Series1"].YValueMembers = "JobCnt";

            dsTndr.Tables.Clear();

            onGoingTasksofSurvey.ChartAreas[0].AxisX.MajorGrid.Enabled = false;
            onGoingTasksofSurvey.ChartAreas[0].AxisX.MinorGrid.Enabled = false;
            onGoingTasksofSurvey.ChartAreas[0].AxisY.MajorGrid.Enabled = false;
            onGoingTasksofSurvey.ChartAreas[0].AxisY.MinorGrid.Enabled = false;

            onGoingTasksofSurvey.ChartAreas[0].AxisX.LabelStyle.Angle = 30;
            onGoingTasksofSurvey.ChartAreas[0].AxisX.LabelStyle.ForeColor = Color.Maroon;

            onGoingTasksofSurvey.ChartAreas[0].AxisX.Interval = 1;
        }
    }
    protected void lnkNewSurvey_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/Survey/AddNewSurvey.aspx", false);
    }
    protected void lnkSearchSurvey_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/Survey/SearchSurveyLog.aspx", false);
    }
    protected void lnkOnGoingSurvey_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/Survey/ViewSurveyInfo.aspx", false);
    }

    private void getOnGoingTasksPerStaffChartForSurvey()   // chart 3
    {
        string sqlQuery = string.Empty; string strStaff = string.Empty;

        DataSet dsTndr = new DataSet();
        int sectionID = Convert.ToInt32(Session["SectionID"]);

        if (Session["userProfileID"].ToString().Equals("1"))
        {
            sqlQuery = "Select COUNT(app_resource_allocation.USER_ID) as JobCnt,APP_SCRTY_USERS.NAME as userShortName from app_resource_allocation INNER JOIN APP_SCRTY_USERS ON app_resource_allocation.USER_ID = APP_SCRTY_USERS.USER_ID where app_resource_allocation.state_id ='OPEN' group by APP_SCRTY_USERS.NAME ";
            lblOngoingStaff.Text = "On Going Tasks Per Staff In All Sections Of EBSD";
        }       
        else
        {
            lblOngoingStaff.Text = "On Going Tasks Per Staff In EBSD " + Session["SectionName"].ToString();

            sqlQuery = "Select COUNT(app_resource_allocation.USER_ID) as JobCnt,APP_SCRTY_USERS.NAME as userShortName from app_resource_allocation INNER JOIN APP_SCRTY_USERS ON app_resource_allocation.USER_ID = APP_SCRTY_USERS.USER_ID where app_resource_allocation.state_id ='OPEN' group by APP_SCRTY_USERS.NAME ";
        }

        OracleDataAdapter daTndr = new OracleDataAdapter(sqlQuery, connValueOracle);
        daTndr.Fill(dsTndr);
        if (dsTndr.Tables[0].Rows.Count != 0)
        {
            onGoingTasksPerStaffChart.DataSource = dsTndr.Tables[0].DefaultView;
            onGoingTasksPerStaffChart.Series["Series1"].XValueMember = "userShortName";
            onGoingTasksPerStaffChart.Series["Series1"].YValueMembers = "JobCnt";
            dsTndr.Tables.Clear();

            onGoingTasksPerStaffChart.ChartAreas[0].AxisX.MajorGrid.Enabled = false;
            onGoingTasksPerStaffChart.ChartAreas[0].AxisX.MinorGrid.Enabled = false;
            onGoingTasksPerStaffChart.ChartAreas[0].AxisY.MajorGrid.Enabled = false;
            onGoingTasksPerStaffChart.ChartAreas[0].AxisY.MinorGrid.Enabled = false;

            onGoingTasksPerStaffChart.ChartAreas[0].AxisX.LabelStyle.Angle = 30;
            onGoingTasksPerStaffChart.ChartAreas[0].AxisX.LabelStyle.ForeColor = Color.Maroon;

            onGoingTasksPerStaffChart.ChartAreas[0].AxisX.Interval = 1;
        }
    }
    protected void gridDocsNonEBD_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        gridDocsNonEBD.PageIndex = e.NewPageIndex;

        DataTable dt = new DataTable();
        dt = Session["getNonEBDData"] as DataTable;

        gridDocsNonEBD.DataSource = dt;
        gridDocsNonEBD.DataBind();

        PageloadData();
    }
    protected void gridDocsNonEBD_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            Label lblDocTypeID = (Label)e.Row.FindControl("lblDocTypeID");

            if (lblDocTypeID.Text.Equals("9"))   // vo 9 adm 11
            {
                e.Row.Cells[1].BackColor = System.Drawing.Color.Red;
                e.Row.Cells[1].ForeColor = System.Drawing.Color.White;
            }
            if (lblDocTypeID.Text.Equals("11"))   //  11 adm
            {
                e.Row.Cells[1].BackColor = System.Drawing.Color.Yellow;
                e.Row.Cells[1].ForeColor = System.Drawing.Color.Black;
            }
        }
    }
    private void getUnreadDocumentDataFromNonEBD()
    {
        string sqlQuery = string.Empty;
       
        sqlQuery = "SELECT [Document].referenceNo, DocumentType.documentType, [Document].superseded, [Document].jobID, Contact.firstName + ' ' + Contact.lastName AS userName, " +
                        " [Document].documentID, Contact.companyID, [Document].docTypeID,Company.cmpName AS deptName FROM [Document] INNER JOIN DocumentType ON [Document].docTypeID = DocumentType.docTypeID INNER JOIN Contact ON [Document].originContactID = Contact.contactID INNER JOIN " +
                       "  Company ON Contact.companyID = Company.companyID WHERE ([Document].docTypeID IN (9, 10, 11)) AND ([Document].jobID IS NULL) AND (Contact.sectionID NOT IN (1, 2, 3)) Order By [Document].documentID desc";

        SqlConnection objCon = new SqlConnection(connValue);
        SqlCommand objCmd = new SqlCommand(sqlQuery, objCon);
        SqlDataAdapter objDA = new SqlDataAdapter(objCmd);
        objDA.SelectCommand.CommandText = objCmd.CommandText.ToString();
        DataTable dtReceiveDocs = new DataTable();

        Session["getNonEBDData"] = dtReceiveDocs;
        objDA.Fill(dtReceiveDocs);
        gridDocsNonEBD.DataSource = dtReceiveDocs;
        gridDocsNonEBD.DataBind();

        if (dtReceiveDocs.Rows.Count> 0)        
            lblDocNonEBD.Text = "Documents Received from Non EBD Department";
        
    }
    protected void lnkBtnDocNonEBD_Click(object sender, EventArgs e)
    {
        string strUpdateJob = Request.Url.AbsoluteUri;
        Session["UrlRef"] = strUpdateJob;
        try
        {
            LinkButton lnkDistributrID = (LinkButton)sender;
            GridViewRow gvr = (GridViewRow)lnkDistributrID.NamingContainer;           
            int docid = Convert.ToInt32(((HtmlGenericControl)gvr.FindControl("divDocID")).InnerText);
            Response.Redirect("~/Documents/DocumentDetailsWindow.aspx?docRecID=" + docid + "&RecSentCatID=1", false);
        }
        catch (Exception ex)
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Error occurred while processing the request')</script>", false);
        }
    }
    protected void lnkSearchFiles_Click(object sender, EventArgs e)
    { 
        Response.Redirect("CostControlHomePage.aspx", false);
    }

    protected void lnkSearchData_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/ManagerTask/SerachTask.aspx", false); //SerachTask.aspx   MngrTaskDetails
    }

    protected void onGoingTaskMngr_Click(object sender, ImageMapEventArgs e)
    {
        string sectionName = Session["SectionName"].ToString();

        Session["ActionBy"] = null; Session["CoordName"] = null;

        Session["ActionBy"] = e.PostBackValue.ToString();

        Session["OnGoingJobStatus"] = e.PostBackValue;

        if (Session["SectionID"].Equals("10") || Session["UserProfileID"].Equals("1"))
        {
            Response.Redirect("~/ManagerTask/ViewManagerRequests.aspx", false);
        }
        else if (Session["SectionID"].Equals("9") || Session["UserProfileID"].Equals("1"))
        {
            Response.Redirect("~/Planning/ViewSRInfo.aspx", false);
        }
        else
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "Popup", "<script>alert('Restricted Access!')</script>", false);
        }
    }


    //private void OngoingManager()
    //{
    //    string sectionName = Session["SectionName"].ToString();

    //    Session["OverDueName"] = e.PostBackValue.ToString();

    //    Session["OnGoingJobStatus"] = e.PostBackValue;

    //    if (Session["SectionID"].Equals("10") || Session["UserProfileID"].Equals("1"))
    //    {
    //        Response.Redirect("~/ManagerTask/ViewManagerRequests.aspx", false);
    //    }
    //    else
    //    {
    //        ClientScript.RegisterClientScriptBlock(this.GetType(), "Popup", "<script>alert('Restricted Access!')</script>", false);
    //    }
    //}



    private void Visible_Tablerows()
    {
        //Payment

        trNCP.Visible = false;
        trCP.Visible = false;
        trPaySrch.Visible = false;

        // Cost Control

        trNewJob.Visible = false;
        trJobSrch.Disabled = false;
        trAdmSrch.Disabled = false;

        // Survey

        trAddSur.Visible = false;
        trSearchSur.Visible = false;

        // Document Module  
    }
    protected void lnkSearchData1_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/ManagerTask/ProjectSummary.aspx", false); //SerachTask.aspx   MngrTaskDetails
    }
    protected void lnkMngrReports_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/Reports/rptManagerReports.aspx", false);       
    }
    protected void onGoingTaskMngrCoord_Click(object sender, ImageMapEventArgs e)
    {
        string sectionName = Session["SectionName"].ToString();

        Session["ActionBy"] = null;  Session["CoordName"] = null;

        Session["CoordName"] = e.PostBackValue.ToString();

        Session["OnGoingJobStatus"] = e.PostBackValue;

        if (Session["SectionID"].Equals("10") || Session["UserProfileID"].Equals("1"))
        {
            Response.Redirect("~/ManagerTask/ViewManagerRequests.aspx", false);
        }
        else
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "Popup", "<script>alert('Restricted Access!')</script>", false);
        }
    }
    protected void onGoingTasksPerLeadChart_Click(object sender, ImageMapEventArgs e)
    {
        Session["ShortName"] = e.PostBackValue.ToString();

        if (!Session["SectionID"].Equals("4"))
            Response.Redirect("~/JobOrder/SearchAllJobsByTeamLead.aspx", false);
        else
            Response.Redirect("~/Survey/SurveyStaffJobs.aspx", false);
    }

    private void getOnGoingJobsByTeamLead()
    {
        string sqlQuery = string.Empty; string strStaff = string.Empty;

        DataSet dsTndr = new DataSet();
        int sectionID = Convert.ToInt32(Session["SectionID"]);

        if (Session["userProfileID"].ToString().Equals("1"))
        {
            sqlQuery = "SELECT COUNT(JobOwner.contactID) AS JobCnt, Contact.userShortName FROM JobOwner INNER JOIN Contact ON JobOwner.contactID = Contact.teamLeaderID WHERE (Contact.sectionID IN (1, 2, 3)) AND (JobOwner.jobOwnerStatusID = 3) " +
            " GROUP BY JobOwner.contactID, Contact.userShortName";

            lblOngoingStaff.Text = "On Going Tasks Per TeamLead In All Sections Of EBSD";
        }
        else
        {
            lblOngoingStaff.Text = "On Going Tasks Per TeamLead In EBSD " + Session["SectionName"].ToString();

            sqlQuery = "SELECT COUNT(JobOwner.contactID) AS JobCnt, Contact.userShortName FROM  JobOwner INNER JOIN Contact ON JobOwner.contactID = Contact.teamLeaderID WHERE (Contact.sectionID = 1) AND (JobOwner.jobOwnerStatusID = 3) " +
            " GROUP BY JobOwner.contactID, Contact.userShortName";

        }

        SqlDataAdapter daTndr = new SqlDataAdapter(sqlQuery, connValue);
        daTndr.Fill(dsTndr);
        if (dsTndr.Tables[0].Rows.Count != 0)
        {
            onGoingTasksPerLeadChart.DataSource = dsTndr.Tables[0].DefaultView;
            onGoingTasksPerLeadChart.Series["Series1"].XValueMember = "userShortName";
            onGoingTasksPerLeadChart.Series["Series1"].YValueMembers = "JobCnt";

            dsTndr.Tables.Clear();

            onGoingTasksPerLeadChart.ChartAreas[0].AxisX.MajorGrid.Enabled = false;
            onGoingTasksPerLeadChart.ChartAreas[0].AxisX.MinorGrid.Enabled = false;
            onGoingTasksPerLeadChart.ChartAreas[0].AxisY.MajorGrid.Enabled = false;
            onGoingTasksPerLeadChart.ChartAreas[0].AxisY.MinorGrid.Enabled = false;

            onGoingTasksPerLeadChart.ChartAreas[0].AxisX.LabelStyle.Angle = 30;
            onGoingTasksPerLeadChart.ChartAreas[0].AxisX.LabelStyle.ForeColor = Color.Maroon;

            onGoingTasksPerLeadChart.ChartAreas[0].AxisX.Interval = 1;
        }
    }

    protected void lnkSRData_Click(object sender, EventArgs e)
    {
        //Response.Redirect("~/Planning/DefaultSRInfo.aspx", false); //SRDetails.aspx

        Response.Redirect("~/Planning/SRDetails.aspx", false); //SRDetails.aspx
    }
    protected void lnkSearchSR_Click(object sender, EventArgs e)
    {
        if (Session["SectionID"].Equals("9")) //Mngr
        {
            Response.Redirect("~/Planning/Search_SRInfo.aspx", false);         //SRDetails.aspx
        }
        else
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "Popup", "<script>alert('You have no privilege for this Request.')</script>", false);
            return;
        }
    }
    protected void lnkNewMngr_Click(object sender, EventArgs e)
    {
        if (userRightsColl.Contains("2"))
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "Popup", "<script>alert('You have no privilege Create Request.')</script>", false);
            return;
        }
        else
        {
            Response.Redirect("~/ManagerTask/CreateTask.aspx", false);
        }
       
    }
    protected void gridTasks_Lead_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        gridTasks_Lead.PageIndex = e.NewPageIndex;
    
        DataTable dt = new DataTable();
        dt = Session["getLeadData"] as DataTable;      

        gridTasks_Lead.DataSource = dt;
        gridTasks_Lead.DataBind();
       
    }
    protected void lnkBtnReqID_Click(object sender, EventArgs e) // IssuedBy
    {
        string strUpdateJob = Request.Url.AbsoluteUri;
        Session["UrlRef"] = strUpdateJob;

        if (userRightsColl.Contains("11"))
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "Popup", "<script>alert('You have no privilege to Search Addendum Log.')</script>", false);
            return;
        }
        else
        {
           // Response.Redirect("SearchAdmData.aspx", false);
        }
    }

    protected void lnkBtnReqIDLead_Click(object sender, EventArgs e) // IssuedBy
    {
        string strUpdateJob = Request.Url.AbsoluteUri;
        Session["UrlRef"] = strUpdateJob;

        //if (userRightsColl.Contains("11"))
        //{
        //    ClientScript.RegisterClientScriptBlock(this.GetType(), "Popup", "<script>alert('You have no privilege to Search Addendum Log.')</script>", false);
        //    return;
        //}
        //else
        {
            LinkButton lnkJobID = (LinkButton)sender;           
            GridViewRow gvr = (GridViewRow)lnkJobID.NamingContainer;

            Session["SrJobID"] = ((HtmlGenericControl)gvr.FindControl("divReqID")).InnerText;
            Response.Redirect("~/Planning/SRDetails.aspx?SrJobID= " + Session["SrJobID"] + "", false); //SrJobID
        }
    }

}