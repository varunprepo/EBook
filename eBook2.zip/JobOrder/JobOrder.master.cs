﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.Data;
using Datalayer;
using System.Configuration;


public partial class JobOrder_JobOrder : System.Web.UI.MasterPage
{
    string connValue = System.Configuration.ConfigurationManager.ConnectionStrings["EBSDEBookConn"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
    {  
        if (!IsPostBack)
        {
            if (Session["UserName"]== null)
            {
                Response.Redirect("~/LoginPage.aspx", false);
                return;
            }
            if (userRightsColl.Contains("25"))
            {
                lnkRecDoc.Visible = false;
                lnkMyDoc.Visible = false;
                lnkSearchDoc.Visible = false;
            }
            AutoReplyActive();

            ddlProfileChange.Visible = false;
        }        
    }
    protected void lnkLogOutBtn_Click(object sender, EventArgs e)
    {
        Session.Abandon();
        loginUpdate();
        Response.Redirect("~/LoginPage.aspx", false);
    }
    IList<string> userRightsColl = new List<string>();
    protected override void OnInit(EventArgs e)
    {
        if (Session["UserName"] != null)
        {
            lblUserName.Text = "Welcome : " + Session["UserDisplayName"].ToString();
            lblprofileName.Text = " : " + Session["ProfileName"].ToString();
            lblDesignation.Text = " : " + Session["ProfileName"].ToString();
            lblSecName.Text = " : " + Session["SectionName"].ToString();

            lbldeptName.Text = " : " + Session["cmpName"].ToString();

            userRightsColl = new JobOrderData().GetUserAccessList(Convert.ToInt32(Session["userID"]));

            if (Session["ProfileName"].ToString() != "Administrator")
            {
                Control MyList = FindControl("menu");

                foreach (Control MyControl in MyList.Controls)
                {
                    if (MyControl is HtmlGenericControl)
                    {
                        HtmlGenericControl li = MyControl as HtmlGenericControl;

                        if (Session["CmpID"].ToString() != "362")
                        {
                            if (li.ID == "liaJobOrder")
                                li.Visible = false;

                            if (li.ID == "liaDirectory")
                                li.Visible = false;

                            if (li.ID == "liaReports")
                                li.Visible = false;
                        }

                        if (userRightsColl.Contains("5"))
                        {
                            if (li.ID == "liaJobOrder")
                            {
                                //HtmlAnchor d = (HtmlAnchor)li.FindControl("liaJobOrder123");
                                //HtmlAnchor d1 = (HtmlAnchor)li.FindControl("A3");
                                //d.Attributes.Clear();
                                //d1.Attributes.Clear();
                                //d.Disabled = true; 
                                //d1.Disabled = true;                               
                            }
                        }

                        if (li.ID == "lnkadmin")
                            li.Visible = false;

                        if (Session["SectionID"].ToString().Equals("22"))
                        {
                            if (li.ID == "liaReports")
                                li.Visible = false;

                            if (li.ID == "liaJobOrder")
                                li.Visible = false;
                        }
                        if (Session["SectionID"].ToString().Equals("11"))
                        {
                            if (li.ID == "liaReports")
                                li.Visible = true;

                            if (li.ID == "liaJobOrder")
                                li.Visible = false;

                            if (li.ID == "liaDirectory")
                                li.Visible = false;
                        }

                        //if (li.ID == "lnkadmin")
                        //{
                        //    li.Visible = false;

                        //    //HtmlAnchor d = (HtmlAnchor)li.FindControl("liaAdmin123");
                        //    //HtmlAnchor d1 = (HtmlAnchor)li.FindControl("admView");
                        //    //HtmlAnchor d2 = (HtmlAnchor)li.FindControl("admAccess");
                        //    //HtmlAnchor d3 = (HtmlAnchor)li.FindControl("admProfile");

                        //    //d.Attributes.Clear(); d1.Attributes.Clear(); d2.Attributes.Clear(); d3.Attributes.Clear();
                        //    //d.Disabled = true; d1.Disabled = true; d2.Disabled = true; d3.Disabled = true;
                        //}


                    }
                }
            }
        }
        else
        {
            Response.Redirect("~/LoginPage.aspx", false);
        }       
      
    }
    private void loginUpdate()
    {
        int userID = 0;

        if (Session["userID"] != null)
            userID = Convert.ToInt32(Session["userID"]);

        SqlConnection _con = new SqlConnection(connValue);

        SqlCommand _cmdInsert = new SqlCommand("Update Contact Set isLogIn =@isLogin where contactID = " + userID + "", _con);
        _cmdInsert.Parameters.AddWithValue("@userID", Convert.ToInt32(Session["userID"]));
        _cmdInsert.Parameters.AddWithValue("@isLogin", 0);

        try
        {
            _con.Open();
            _cmdInsert.ExecuteNonQuery();
        }
        finally
        {
            _con.Close();
        }
    }   

    # region

    UtilityClass uCls = null;
    //protected void lnkSurveySection_Click(object sender, EventArgs e)
    //{
    //    try
    //    {
    //        Response.Redirect("~/Survey/ViewSurveyInfo.aspx", false);
    //    }
    //    catch (Exception ex)
    //    {
    //        Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Error occurred while processing the request')</script>", false);
    //    }
    //}

    protected void lnkHome_Click1(object sender, EventArgs e)
    {       
        try
        {
            //if (Session["UserProfileID"].ToString().Equals("1"))
            //    Response.Redirect("~/JobOrder/AdminHomePage.aspx", false);
           // else

            if (Session["UserProfileID"].Equals("1"))
            {
                //Do nothing Stay on the current page
            }
            else if (Session["UserProfileID"].Equals("20"))
                Response.Redirect("~/JobOrder/CostControlHomePage.aspx", false);
            else if (Session["SectionID"].Equals("12"))
                Response.Redirect("~/Contracts/ClaimsHomePage.aspx", false);
            else if (Session["SectionID"].Equals("13"))
                Response.Redirect("~/TSS/TSSHomePage.aspx", false);
            else if (Session["SectionID"].ToString() == "1" || Session["SectionID"].ToString() == "3" || Session["SectionID"].ToString() == "39" || Session["SectionID"].ToString() == "11")
                Response.Redirect("~/JobOrder/DCLogHomePage.aspx", false);
            else if (Session["SectionID"].Equals("9"))                
                Response.Redirect("~/JobOrder/BSHomePage.aspx", false);
                //Response.Redirect("~/JobOrder/DCLogHomePage.aspx", false);
            else if (Session["SectionID"].Equals("4"))
                Response.Redirect("~/JobOrder/SurveyDefaultWindow.aspx", false);            
            else
            {
               // Response.Redirect("~/JobOrder/NonEBDHomePage.aspx", false);
                Response.Redirect("~/Contracts/ClaimsHomePage.aspx", false);
            }
        }
        catch (Exception ex)
        {
            Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Error occurred while processing the request')</script>", false);
        }
    }
    protected void lnkRecDoc_Click1(object sender, EventArgs e)
    {
        Session["jobID"] = null;
        try
        {
            uCls = new UtilityClass(this.Page);
            uCls.ResetTheSessionVariables();
            Response.Redirect("~/Documents/ReceiveSentDocuments.aspx", false);
        }
        catch (Exception ex)
        {
            Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Error occurred while processing the request')</script>", false);
        }
    }
    protected void lnkMyDoc_Click1(object sender, EventArgs e)
    {
        try
        {
            uCls = new UtilityClass(this.Page);
            uCls.ResetTheSessionVariables();
           
            Response.Redirect("~/Documents/SearchDocument.aspx?directSearch=1", false);
        }
        catch (Exception ex)
        {
            Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Error occurred while processing the request')</script>", false);
        }
    }
    protected void lnkSearchDoc_Click(object sender, EventArgs e)
    {
        try
        {
            uCls = new UtilityClass(this.Page);
            uCls.ResetTheSessionVariables();           
            Response.Redirect("~/Documents/SearchDocument.aspx", false);
        }
        catch (Exception ex)
        {
            Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Error occurred while processing the request')</script>", false);
        }
    }

    protected void lnkSearchDoc_Click1(object sender, EventArgs e)
    {
        try
        {
            uCls = new UtilityClass(this.Page);
            uCls.ResetTheSessionVariables();
            Response.Redirect("~/Documents/SearchDocument.aspx", false);
        }
        catch (Exception ex)
        {
            Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Error occurred while processing the request')</script>", false);
        }
    }
    protected void lnkSearchDocRegister_Click(object sender, EventArgs e)
    {
        try
        {
            if ((Session["SectionID"].ToString().Equals("3")) || (Session["userProfileID"].ToString().Equals("1")))
            {
                uCls = new UtilityClass(this.Page);
                uCls.ResetTheSessionVariables();
                Session["SearchMyDocs"] = "1";
                Response.Redirect("~/Documents/DocumentRegister.aspx?directSearch=1", false);
            }
            else
            {
                this.Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Restricted Access.')</script>", false);
            }
        }
        catch (Exception ex)
        {
            Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Error occurred while processing the request')</script>", false);
        }
    }
    protected void lnkCostControl_Click(object sender, EventArgs e)
    {
        try
        {
            if (((Session["SectionID"].ToString().Equals("1")) & (Session["userProfileID"].ToString().Equals("20"))))        // Administrator View only
            {
                Response.Redirect("../JobOrder/JobOrder.aspx", false);
            }  
            else if (((!Session["SectionID"].ToString().Equals("1")) & (!Session["userProfileID"].ToString().Equals("1"))))         //userRightsColl.Contains("5") &                //Session["ProfileName"].ToString() != "Administrator"
            {
                this.Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Restricted Access.')</script>", false);
                return;
            }           
            else
            {
                Response.Redirect("../JobOrder/JobOrder.aspx", false);
            }
        }
        catch (Exception ex)
        {
            this.Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Error occurred while processing the request')</script>", false);
        }
    }
    protected void lnkPaymentSection_Click(object sender, EventArgs e)
    {
        try
        {
            if (!Session["SectionID"].ToString().Equals("2") & (!Session["userProfileID"].ToString().Equals("1")))          // (userRightsColl.Contains("5"))
            {
                this.Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Restricted Access.')</script>", false);
                return;
            }
            else
            {
                Response.Redirect("../Payments/ViewPayments.aspx", false);
            }
        }
        catch (Exception ex)
        {
            this.Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Error occurred while processing the request')</script>", false);
        }
    }
    protected void lnkDCLogSection_Click(object sender, EventArgs e)
    {
        try
        {
            if (!Session["SectionID"].ToString().Equals("3") & (!Session["userProfileID"].ToString().Equals("1")))          // (userRightsColl.Contains("5"))
            {
                this.Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Restricted Access.')</script>", false);
                return;
            }
            else
            {
                Response.Redirect("../DCLog/ViewDCLog.aspx", false);
            }
        }
        catch (Exception ex)
        {
            this.Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Error occurred while processing the request')</script>", false);
        }
    }    
    protected void lnkSurveySection_Click(object sender, EventArgs e)
    {
        try
        {
            if (!Session["SectionID"].ToString().Equals("4") & (!Session["userProfileID"].ToString().Equals("1")))          // (userRightsColl.Contains("5"))
            {
                this.Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Restricted Access.')</script>", false);
                return;
            }
            else
            {
                Session["ClickedOn"] = "~/Survey/ViewSurveyInfo.aspx";
                Response.Redirect("../Survey/ViewSurveyInfo.aspx", false);
            }
        }
        catch (Exception ex)
        {
            this.Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Error occurred while processing the request')</script>", false);
        }
    }


    protected void lnkMngrRequests_Click(object sender, EventArgs e)
    {
        try
        {
            if (!Session["SectionID"].ToString().Equals("10") & (!Session["userProfileID"].ToString().Equals("1")))          // (userRightsColl.Contains("5"))
            {
                this.Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Restricted Access.')</script>", false);
                return;
            }
            else
            {
                Response.Redirect("../ManagerTask/ViewManagerRequests.aspx", false);
            }
        }
        catch (Exception ex)
        {
            this.Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Error occurred while processing the request')</script>", false);
        }
    }
    protected void lnkMngrRequestsReports_Click(object sender, EventArgs e)
    {
        try
        {
            if ((Session["SectionID"].ToString().Equals("10")) || (Session["userProfileID"].ToString().Equals("1")))
            {
                Response.Redirect("../Reports/rptManagerReports.aspx", false);
            }
            else
            {
                this.Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Restricted Access.')</script>", false);
                return;
            }
        }
        catch (Exception ex)
        {
            this.Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Error occurred while processing the request')</script>", false);
        }
    }

    protected void lnkPayReport_Click(object sender, EventArgs e)
    {
        try
        {
            if ((Session["SectionID"].ToString().Equals("2")) || (Session["userProfileID"].ToString().Equals("1")))
            {
                Response.Redirect("../Reports/rptPaymentReports.aspx", false);
            }
            else
            {
                this.Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Restricted Access.')</script>", false);
                return;
            }
        }
        catch (Exception ex)
        {
            this.Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Error occurred while processing the request')</script>", false);
        }
    }

    protected void lnkCCReport_Click(object sender, EventArgs e)
    {
        try
        {
            if ((Session["SectionID"].ToString().Equals("1")) || (Session["userProfileID"].ToString().Equals("1")))
            {
                Response.Redirect("../Reports/rptNewReports.aspx", false);
            }
            else
            {
                this.Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Restricted Access.')</script>", false);
                return;
            }
        }
        catch (Exception ex)
        {
            this.Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Error occurred while processing the request')</script>", false);
        }
    }

    protected void lnkDCReport_Click(object sender, EventArgs e)
    {
        try
        {
            if ((Session["SectionID"].ToString().Equals("3")) || (Session["userProfileID"].ToString().Equals("1")))
            {
                Response.Redirect("../Reports/rptDocumentReports.aspx", false);
            }
            else
            {
                this.Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Restricted Access.')</script>", false);
                return;
            }
        }
        catch (Exception ex)
        {
            this.Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Error occurred while processing the request')</script>", false);
        }
    }

    protected void lnkStrategyReport_Click(object sender, EventArgs e)
    {       

        try
        {
            //if ((Session["SectionID"].ToString().Equals("11")) || (Session["userProfileID"].ToString().Equals("1")))
            //{
                Response.Redirect("../Reports/StrategyReport.aspx", false);
            //}
            //else
            //{
            //    this.Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Restricted Access.')</script>", false);
            //    return;
            //}
        }
        catch (Exception ex)
        {
            this.Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Error occurred while processing the request')</script>", false);
        }

    }

    

    protected void lnkEISReports_Click(object sender, EventArgs e)
    {       

        try
        {
            if ((Session["SectionID"].ToString().Equals("11")) || (Session["userProfileID"].ToString().Equals("1")))
            {
                Response.Redirect("../Reports/rptEISReport.aspx", false);
            }
            else
            {
                this.Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Restricted Access.')</script>", false);
                return;
            }
        }
        catch (Exception ex)
        {
            this.Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Error occurred while processing the request')</script>", false);
        }

    }


    protected void lnkBDReports_Click(object sender, EventArgs e)
    {
        try
        {
            if ((Session["SectionID"].ToString().Equals("9")) || (Session["userProfileID"].ToString().Equals("1")))
            {
                Response.Redirect("../Reports/rptBDReport.aspx", false);
            }
            else
            {
                this.Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Restricted Access.')</script>", false);
                return;
            }
        }
        catch (Exception ex)
        {
            this.Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Error occurred while processing the request')</script>", false);
        }
    } 
    protected void lnkProfile_Click(object sender, EventArgs e)
    {
        UtilityClass utils = null;
        try
        {
            utils = new UtilityClass(this.Page);
            string url = Request.Url.AbsoluteUri;
            if (url.Contains(":"))
                url = url.Substring(0, utils.GetNthIndex(url, '/', 4));
            else
                url = url.Substring(0, utils.GetNthIndex(url, '/', 2));
           // url = url + "/Directory/AddContactsInfo.aspx?contactID=" + Session["UserID"] + "";

            url = url + "/ChangePassword.aspx?contactID=" + Session["UserID"] + "";

            //OpenPageByUsingJS(url, "800", "421");

            OpenPageByUsingJS(url, "581", "351");              //"781", "651"
        }
        catch (Exception ex)
        {
            this.Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Error occurred while processing the request')</script>", false);
        }
    }

    protected void lnkInActive_Click(object sender, EventArgs e)
    {
        try
        {
           // Response.Redirect("../Admin/InactiveUsers.aspx", false); //FileTaskSurvey.aspx

            Response.Redirect("../Admin/FileTaskSurvey.aspx", false); //FileTaskSurvey.aspx
        }
        catch (Exception ex)
        {
            this.Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Error occurred while processing the request')</script>", false);
        }
    }
    
    protected void lnkCEreport_Click(object sender, EventArgs e)
    {
        try
        {
            if ((Session["SectionID"].ToString().Equals("3")) || (Session["userProfileID"].ToString().Equals("1")))
            {
                Response.Redirect("../Reports/rptDocumentReports.aspx", false);               
            }
            else
            {
                this.Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Restricted Access.')</script>", false);
                return;               
            }
        }
        catch (Exception ex)
        {
            this.Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Error occurred while processing the request')</script>", false);
        }
    }

    protected void lnkBSRequests_Click(object sender, EventArgs e)
    {
        try
        {
            if ((Session["SectionID"].ToString().Equals("9")) || (Session["userProfileID"].ToString().Equals("1")))
            {
                Response.Redirect("../Planning/ViewSRInfo.aspx", false);               
            }
            else
            {
                this.Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Restricted Access.')</script>", false);
                return;               
            }
        }
        catch (Exception ex)
        {
            this.Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Error occurred while processing the request')</script>", false);
        }
    }

    //

    protected void lnkCalendar_Click(object sender, EventArgs e)
    {
        UtilityClass utils = null;
        try
        {
            utils = new UtilityClass(this.Page);
            string url = Request.Url.AbsoluteUri;
            if (url.Contains(":"))
                url = url.Substring(0, utils.GetNthIndex(url, '/', 4));
            else
                url = url.Substring(0, utils.GetNthIndex(url, '/', 2));
            url = url + "/JobOrder/CalenderAlert.aspx";
            OpenPageByUsingJS(url, "960", "800");
        }
        catch (Exception ex)
        {
            this.Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Error occurred while processing the request')</script>", false);
        }
    }
    protected void lnkChangePassword_Click(object sender, EventArgs e)
    {
        UtilityClass utils = null;
        try
        {
            utils = new UtilityClass(this.Page);
            string url = Request.Url.AbsoluteUri;
            if (url.Contains(":"))
                url = url.Substring(0, utils.GetNthIndex(url, '/', 4));
            else
                url = url.Substring(0, utils.GetNthIndex(url, '/', 2));
            url = url + "/ChangePassword.aspx";
            OpenPageByUsingJS(url, "700", "500");
        }
        catch (Exception ex)
        {
            this.Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Error occurred while processing the request')</script>", false);
        }
    }

    protected void lnkAutoReply_Click(object sender, EventArgs e)
    {
        UtilityClass utils = null;
        try
        {
            utils = new UtilityClass(this.Page);
            string url = Request.Url.AbsoluteUri;
            if (url.Contains(":"))
                url = url.Substring(0, utils.GetNthIndex(url, '/', 4));
            else
                url = url.Substring(0, utils.GetNthIndex(url, '/', 2));
            url = url + "/AutoReply.aspx";
            OpenPageByUsingJS(url, "700", "500");
        }
        catch (Exception ex)
        {
            this.Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Error occurred while processing the request')</script>", false);
        }
    }

    private void OpenPageByUsingJS(string url, string width, string height)
    {
        string s = "window.open('" + url + "', 'popup_window', 'width=" + width + ",height=" + height + "left=100,top=100,resizable=yes');";
        Page.ClientScript.RegisterStartupScript(this.GetType(), "script", s, true);
    }

    private void AutoReplyActive()
    {
        if (Session["UserName"] != null)
        {
            if (!Page.IsPostBack)
            {
                DAL dal = new DAL(connValue);
                if (dal.ConnectDB(this.Page) == 'E')
                    return;
                SqlCommand sqlCommand = new SqlCommand("select isAutoReplyActive from Contact where contactID=@contactID", dal.SqlConnection);
                sqlCommand.Parameters.AddWithValue("@contactID", Session["UserID"].ToString());
                SqlDataReader sqlDtReader = sqlCommand.ExecuteReader();

                if (sqlDtReader.Read())
                {
                    if (sqlDtReader[0].ToString() == "True")
                    {
                        //lblAutoReplyMessage.Style.Value = "font-weight: bold; font-size: 16px;background-color:Yellow; color:Black";
                        //lblAutoReplyMessage.Text = "Auto Reply (Out of Office) Message is Active";
                        lnkBtnTurnOff.Text = "Turn Off";

                        divAutoReplyMessage.Visible = true;
                    }
                    else
                    {
                       // lblAutoReplyMessage.Visible = false;
                        lnkBtnTurnOff.Visible = false;

                        divAutoReplyMessage.Visible = false;
                        
                    }
                }
                else
                {
                   // lblAutoReplyMessage.Visible = false;
                    lnkBtnTurnOff.Visible = false;
                }
                sqlDtReader.Close();
            }
        }
        else
            Response.Redirect("~/LoginPage.aspx", false);
    }

    protected void lnkBtnTurnOff_Click(object sender, EventArgs e)
    {
        if (Session["UserName"] != null)
        {
            DAL dal = null;
            try
            {
                dal = new DAL(connValue);
                if (dal.ConnectDB(this.Page) == 'E')
                    return;

                SqlCommand sqlCmd = new SqlCommand("update Contact set startDate=@startDate,endDate=@endDate,userMsg=@userMsg,isAutoReplyActive=@isAutoReplyActive where contactID=@contactID", dal.SqlConnection);
                sqlCmd.Parameters.AddWithValue("@contactID", Session["UserID"].ToString());
                sqlCmd.Parameters.AddWithValue("@startDate", DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@endDate", DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@isAutoReplyActive", 0);
                sqlCmd.Parameters.AddWithValue("@userMsg", DBNull.Value);
                sqlCmd.ExecuteNonQuery();
                 divAutoReplyMessage.Visible = false;

                // lnkBtnTurnOff.Visible = false;
            }
            catch (Exception ex)
            {
                Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('" + ex.Message.Replace("'", "") + "')</script>", false);
            }
            finally
            {
                if (dal != null)
                    dal.DisconnectDB();
            }
        }
        else
            Response.Redirect("~/LoginPage.aspx", false);
    }
   

    

# endregion

    
    #region MyRegion


    protected void lnkChangeProfile_Click(object sender, EventArgs e)
    {
        IList<int> _modIDs = new List<int>();

        _modIDs = GetModuleAccessData();

        if (_modIDs.Count == 0)
            return;

        string ids = string.Empty;
        int iCnt = 0;

        foreach (var item in _modIDs)
        {
            iCnt = iCnt + 1;
            if (iCnt == 1)
            {
                ids = item.ToString();
            }
            else
            {
                ids = ids + "," + item;
            }
        }      

        ddlProfileChange.Visible = true;
        PopulateDropDownBox(ddlProfileChange, "Select sectionID,SectionName from Section Where SectionID in(" + ids + ")", "SectionID", "SectionName");
    }


    protected void lnkProfileInfo_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/Admin/ProfileAccess.aspx", false);
    }
    private IList<int> GetModuleAccessData()    
    {
        IList<int> modID = new List<int>();

        string sqlQuery = "SELECT AccessID, ContactID, IsBSAccess, IsMOAccess, IsDCAccess  FROM ModuleAccess  WHERE (ContactID = " + Convert.ToInt32(Session["userID"]) + ")";

        using (SqlConnection cn = new SqlConnection(connValue))
        {
            cn.Open();
            using (SqlCommand cmd = new SqlCommand(sqlQuery, cn))
            {
                SqlDataReader dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    if (dr["IsDCAccess"].ToString().Equals("True"))
                      modID.Add(Convert.ToInt32(3));

                    if (dr["IsBSAccess"].ToString().Equals("True"))
                      modID.Add(Convert.ToInt32(9));

                     if (dr["IsMOAccess"].ToString().Equals("True"))
                      modID.Add(Convert.ToInt32(10));
                }
            }
        }
        return modID;
    }
    protected void ddlProfileChange_SelectedIndexChanged(object sender, EventArgs e)
    {
       
    }
    private void PopulateDropDownBox(DropDownList ddlBox, string sqlQuery, string valueMember, string displayName)
    {
        DataTable table = new DataTable();
        try
        {
            using (SqlConnection sqlConn = new SqlConnection(connValue))
            {
                using (SqlDataAdapter da = new SqlDataAdapter(sqlQuery, sqlConn))
                {
                    sqlConn.Open();
                    da.Fill(table);
                }
            }
            //cmbBox.Items.Add("Select");

            ddlBox.DataSource = table;
            ddlBox.DataTextField = displayName;
            ddlBox.DataValueField = valueMember;

            ddlBox.SelectedIndex = -1;
            ddlBox.DataBind();
            ddlBox.Items.Insert(0, new ListItem("--Select--"));
        }
        catch (System.Exception ex)
        {
            throw ex;
        }
    }

    #endregion
    
    protected void ddlProfileChange_SelectedIndexChanged1(object sender, EventArgs e)
    {
        Session["SectionID"] = ddlProfileChange.SelectedValue;

        if (ddlProfileChange.SelectedValue.Equals("1"))
            Response.Redirect("~/JobOrder/DefaultWindow.aspx", false);
        else if (ddlProfileChange.SelectedValue.Equals("2"))
            Response.Redirect("~/JobOrder/DefaultWindow.aspx", false);
        else if (ddlProfileChange.SelectedValue.Equals("3"))
            Response.Redirect("~/JobOrder/DefaultWindow.aspx", false);
        else if (ddlProfileChange.SelectedValue.Equals("4"))
            Response.Redirect("~/JobOrder/SurveyDefaultWindow.aspx", false);
        else if (ddlProfileChange.SelectedValue.Equals("9"))
            Response.Redirect("~/JobOrder/DefaultWindow.aspx", false);
        else if (ddlProfileChange.SelectedValue.Equals("10"))
            Response.Redirect("~/JobOrder/DefaultWindow.aspx", false);
        else
            Response.Redirect("~/JobOrder/NonEBDHomePage.aspx", false);
    }
    protected void lnkHome_Click1(object sender, ImageClickEventArgs e)
    {

    }
}
