﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using Oracle.ManagedDataAccess.Client;
using System.Web.UI.HtmlControls;
using Datalayer;

public partial class JobOrder_CostControlHomePage : System.Web.UI.Page
{
    string connValue = System.Configuration.ConfigurationManager.ConnectionStrings["EBSDEBookConn"].ConnectionString;
    string connValueOracle = System.Configuration.ConfigurationManager.ConnectionStrings["SurveyConnOracle"].ToString();


    IList<string> userRightsColl = null;
    string profile_Name = string.Empty;
    UtilityClass uCls = null;

    static int _currentUserID = 0; 
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["UserName"] == null)
        {
            Response.Redirect("~/LoginPage.aspx", false);
            return;
        }     

        _currentUserID = Convert.ToInt32(Session["UserID"]);
        userRightsColl = (IList<string>)Session["UserRightsColl"];

        if (!IsPostBack)
        {
            PageloadData();       
           

            Session["docSender"] = null;      // add sender from document form        

            trNewTask.Visible = false;
        }

        getOnGoingTasksofSurveyOracle();
        getOnGoing_ManagerRequests();       
    }

    #region New


    private void ModuleWiseControls()
    {
       
    }
    private void PageloadData()
    {
        getOnGoingTasksPerSection_New123();      //Ongoing or Over due jobs Chart - first one

        getMyDocumentChart(); // Chart 2 for Documents     
        
        getUnReadInchargeDataOgSurveyOracle(); // Chart for Survey
       
        getUnReadInchargeData(); // Table New task

        getUnreadDocumentDataFromNonEBD();  
   
        getOnGoingTasksPerStaffChart(); 

        documentWithoutLinkwithJob(); 

        //getOnGoingTasksPerStaffChartForSurvey(); 

        if (userRightsColl.Contains("1"))
            lnKShowAll.Visible = false;
    }
    private void PopulateDropDownBox(DropDownList ddlBox, string sqlQuery, string valueMember, string displayName)
    {
        ddlBox.DataBound += new EventHandler(this.ddlBox_DataBound);
        ddlBox.DataSource = new JobOrderData().FillDropdown(sqlQuery);
        ddlBox.DataTextField = displayName;
        ddlBox.DataValueField = valueMember;
        ddlBox.SelectedIndex = -1;
        ddlBox.DataBind();
    }
    protected void ddlBox_DataBound(object sender, EventArgs e)
    {
        DropDownList ddl = (DropDownList)sender;
        ListItem emptyItem = new ListItem("", "");
        ddl.Items.Insert(0, emptyItem);
    }
     
 
   


    private void getAlertJobData()
    {
        if (Session["Opened"].ToString() == "False")        //if (Application["UsersOnline"].ToString() == "0")
        {
            Application["UsersOnline"] = 1;
            Session["Opened"] = "True";


            for (int i = 0; i < 2; i++)
            {
                if (i == 0)
                {
                    if (FillGridView_Details() == true)
                    {
                        string url = "OverDueJobs.aspx";   // OverDueAddendum.aspx               //OverDueJobs
                        string s = "window.open('" + url + "', 'popup_window', 'width=900,height=700,left=100,top=100,resizable=yes,scrollbars=0');";
                        ClientScript.RegisterStartupScript(this.GetType(), "script", s, true);
                    }
                }
                else
                {
                    if (!userRightsColl.Contains("16"))
                    {
                        if (FillOverDueAdmData() == true)
                        {
                            string url123 = "OverDueAddendum.aspx";   // OverDueAddendum.aspx               //OverDueJobs
                            string s123 = "window.open('" + url123 + "', 'popup_window123', 'width=800,height=600,left=100,top=100,resizable=yes,scrollbars=0');";
                            ClientScript.RegisterStartupScript(this.GetType(), "script", s123, true);
                        }
                    }
                }
            }
        }
    }
    private Boolean FillGridView_Details()
    {
        string sqlQuery = "SELECT JobOwner.jobNo, JobType.jobTypeName, JobOwner.staffIssueDate AS DateReceived, JobOwner.actionDueDate, " +
                         " Contact.firstName + ' ' + Contact.lastName AS IssuedBy, JobOwner.contactID, JobOwner.jobOwnerStatusID, JobOwner.JobTypeID " +
                              " FROM  JobOwner INNER JOIN   Contact ON JobOwner.distributedBy = Contact.contactID INNER JOIN  JobType ON JobOwner.JobTypeID = JobType.jobTypeID " +
                                  " WHERE (JobOwner.contactID = " + Convert.ToInt32(Session["userID"]) + ") AND (JobOwner.jobOwnerStatusID = 3) AND (JobOwner.actionDueDate < GETDATE())";

        //string sqlQuery = "SELECT JobOwner.jobNo, JobType.jobTypeName, JobOwner.staffIssueDate AS DateReceived, JobOwner.actionDueDate,   Contact.firstName + ' ' + Contact.lastName AS IssuedBy, JobOwner.contactID, JobOwner.jobOwnerStatusID " +
        //       " FROM  JobOwner INNER JOIN   Contact ON JobOwner.distributedBy = Contact.contactID INNER JOIN  JobType ON JobOwner.jobOwnerCatID = JobType.jobTypeID WHERE  
        //(JobOwner.contactID =" + Convert.ToInt32(Session["userID"]) + ") AND (JobOwner.jobOwnerStatusID = 3)  AND (JobOwner.actionDueDate < GETDATE())";

        SqlConnection objCon = new SqlConnection(connValue);
        SqlCommand objCmd = new SqlCommand(sqlQuery, objCon);
        SqlDataAdapter objDA = new SqlDataAdapter(objCmd);

        objDA.SelectCommand.CommandText = objCmd.CommandText.ToString();
        DataTable dt = new DataTable();
        objDA.Fill(dt);

        if (dt.Rows.Count > 0)
            return true;
        else
            return false;
    }
    private Boolean FillOverDueAdmData()
    {
        //string sqlQuery = "SELECT Job.jobID,Job.jobNo, JobStatus.jobStatusName, Job.contractNo, Job.addendumNO, JobAddendumInfo.AlertReminderMsg FROM JobAddendumInfo INNER JOIN Job ON JobAddendumInfo.jobID = Job.jobID INNER JOIN " +
        //               " JobStatus ON Job.jobStatusID = JobStatus.jobStatusID WHERE (Contact.contactID = " + Convert.ToInt32(Session["userID"]) + ") AND (JobAddendumInfo.AlertDate >= GETDATE())";

        //string sqlQuery = "SELECT JobStatus.jobStatusName, JobAddendumInfo.AlertReminderMsg, JobOwner.contactID FROM  JobAddendumInfo INNER JOIN    JobOwner ON JobAddendumInfo.jobID = JobOwner.jobID INNER JOIN " +
        //  " JobStatus ON JobOwner.jobOwnerStatusID = JobStatus.jobStatusID WHERE (JobAddendumInfo.AlertDate >= GETDATE()) AND (JobOwner.contactID = 58)";

        string sqlQuery = "SELECT Job.jobNo, JobStatus.jobStatusName, Job.contractNo, Job.addendumNO, JobAddendumInfo.AlertReminderMsg FROM jobAddendumInfo INNER JOIN   Job ON JobAddendumInfo.jobID = Job.jobID INNER JOIN " +
                       "  JobStatus ON Job.jobStatusID = JobStatus.jobStatusID WHERE (JobAddendumInfo.AlertDate <= GETDATE() AND JobAddendumInfo.AlertDate IS NOT NULL)";


        SqlConnection objCon = new SqlConnection(connValue);
        SqlCommand objCmd = new SqlCommand(sqlQuery, objCon);
        SqlDataAdapter objDA = new SqlDataAdapter(objCmd);

        objDA.SelectCommand.CommandText = objCmd.CommandText.ToString();
        DataTable dt = new DataTable();
        objDA.Fill(dt);

        if (dt.Rows.Count > 0)
            return true;
        else
            return false;
    }
    private void BindGvData()
    {
        //gvData.DataSource = GetChartData();
        //gvData.DataBind();
    }
    private void FillDocumentsForSections()
    {
        string sqlQuery = string.Empty; string strTitle = string.Empty;

        int secID = Convert.ToInt32(Session["SectionID"]);

        if (Session["userProfileID"].Equals("1")) //&& Session["userProfileID"].ToString() != "1"      //(Session["SectionID"].Equals("50"))
        {
            //sqlQuery = "SELECT COUNT([Document].documentID) AS docCount, DocumentStatus.docStatusName FROM [Document] INNER JOIN DocumentStatus ON [Document].docStatusID = DocumentStatus.docStatusID INNER JOIN " +
            //"Users ON [Document].originContactID = Users.contactID INNER JOIN Contact ON [Document].originContactID = Contact.contactID INNER JOIN Section ON Contact.sectionID = Section.sectionID WHERE (Contact.sectionID = 39) AND ([Document].docStatusID <> 4) " +
            //"GROUP BY DocumentStatus.docStatusName UNION ALL SELECT COUNT(DocumentDistribution.documentID) AS docCount, DocumentStatus_1.docStatusName FROM DocumentDistribution INNER JOIN [Document] AS Document_1 ON Document_1.documentID = DocumentDistribution.documentID AND " +
            //"DocumentDistribution.contactID <> Document_1.originContactID INNER JOIN DocumentStatus AS DocumentStatus_1 ON DocumentDistribution.docStatusID = DocumentStatus_1.docStatusID INNER JOIN Users AS Users_1 ON DocumentDistribution.contactID = Users_1.contactID INNER JOIN " +
            //"Contact AS Contact_1 ON DocumentDistribution.contactID = Contact_1.contactID INNER JOIN Section AS Section_1 ON Contact_1.sectionID = Section_1.sectionID WHERE (DocumentDistribution.docStatusID <> 4) AND (Contact_1.sectionID =" + secID + ") " +
            //"GROUP BY DocumentStatus_1.docStatusName";

            sqlQuery = "SELECT  COUNT(DocumentDistribution.distributeID) AS docCount, DocumentStatus.docStatusName FROM    DocumentDistribution INNER JOIN " +
                       "  Contact ON DocumentDistribution.contactID = Contact.contactID AND DocumentDistribution.contactID = Contact.contactID INNER JOIN " +
                        " DocumentStatus ON DocumentDistribution.docStatusID = DocumentStatus.docStatusID WHERE  (DocumentStatus.docStatusID <> 4) GROUP BY DocumentStatus.docStatusName";


            ///  lblAllDoc.Text = "Documents In All Sections of EBSD";
        }
        else if (Session["SectionID"].Equals("7") & userRightsColl.Contains("1"))
        {
            //sqlQuery = "SELECT COUNT([Document].documentID) AS docCount, DocumentStatus.docStatusName FROM [Document] INNER JOIN DocumentStatus ON [Document].docStatusID = DocumentStatus.docStatusID INNER JOIN " +
            //"Users ON [Document].originContactID = Users.contactID INNER JOIN Contact ON [Document].originContactID = Contact.contactID INNER JOIN Section ON Contact.sectionID = Section.sectionID WHERE (Contact.sectionID = 39) AND ([Document].docStatusID <> 4) " +
            //"GROUP BY DocumentStatus.docStatusName UNION ALL SELECT COUNT(DocumentDistribution.documentID) AS docCount, DocumentStatus_1.docStatusName FROM DocumentDistribution INNER JOIN [Document] AS Document_1 ON Document_1.documentID = DocumentDistribution.documentID AND " +
            //"DocumentDistribution.contactID <> Document_1.originContactID INNER JOIN DocumentStatus AS DocumentStatus_1 ON DocumentDistribution.docStatusID = DocumentStatus_1.docStatusID INNER JOIN Users AS Users_1 ON DocumentDistribution.contactID = Users_1.contactID INNER JOIN " +
            //"Contact AS Contact_1 ON DocumentDistribution.contactID = Contact_1.contactID INNER JOIN Section AS Section_1 ON Contact_1.sectionID = Section_1.sectionID WHERE (DocumentDistribution.docStatusID <> 4) " +
            //"GROUP BY DocumentStatus_1.docStatusName";

            sqlQuery = "SELECT  COUNT(DocumentDistribution.distributeID) AS docCount, DocumentStatus.docStatusName FROM    DocumentDistribution INNER JOIN " +
                      "  Contact ON DocumentDistribution.contactID = Contact.contactID AND DocumentDistribution.contactID = Contact.contactID INNER JOIN " +
                       " DocumentStatus ON DocumentDistribution.docStatusID = DocumentStatus.docStatusID WHERE  (DocumentStatus.docStatusID <> 4) GROUP BY DocumentStatus.docStatusName";


            // lblAllDoc.Text = "Documents In All Sections of EBSD";
        }
        else
        {
            sqlQuery = "SELECT  COUNT(DocumentDistribution.distributeID) AS docCount, DocumentStatus.docStatusName FROM   DocumentDistribution INNER JOIN  Contact ON DocumentDistribution.contactID = Contact.contactID AND DocumentDistribution.contactID = Contact.contactID INNER JOIN " +
                         " DocumentStatus ON DocumentDistribution.docStatusID = DocumentStatus.docStatusID WHERE   (DocumentStatus.docStatusID <> 4) AND (Contact.sectionID = " + secID + ") GROUP BY DocumentStatus.docStatusName";

            //lblAllDoc.Text = "All Documents in " + Session["SectionName"].ToString();
        }


        SqlConnection objCon = new SqlConnection(connValue);
        objCon.Open();
        SqlCommand objCmd = new SqlCommand(sqlQuery, objCon);
        SqlDataAdapter objDA = new SqlDataAdapter(objCmd);
        DataSet dsTndr123 = new DataSet();
        objDA.Fill(dsTndr123);

        if (dsTndr123.Tables[0].Rows.Count != 0)
        {
            
        }
        objCon.Close();
    }
    private DataTable GetChartData()
    {
        DataSet dsData = new DataSet();
        try
        {
            SqlConnection sqlCon = new SqlConnection(connValue);
            SqlDataAdapter sqlCmd = new SqlDataAdapter("SELECT  COUNT(JobOwner.jobID) AS JobCnt, Contact.firstName FROM Contact INNER JOIN " +
            " JobOwner ON Contact.contactID = JobOwner.contactID GROUP BY Contact.firstName", sqlCon);

            sqlCmd.SelectCommand.CommandType = CommandType.Text;

            sqlCon.Open();

            sqlCmd.Fill(dsData);

            sqlCon.Close();
        }
        catch
        {
            throw;
        }
        return dsData.Tables[0];
    }
    private DataTable GetOngoingJobsChartData()
    {
        DataSet dsData = new DataSet();
        try
        {

            string strQuery = "SELECT COUNT(JobOwner.jobOwnerID) AS JobCnt,Contact.firstName  FROM Contact INNER JOIN JobOwner ON Contact.contactID = JobOwner.contactID GROUP BY Contact.firstName";


            SqlConnection sqlCon = new SqlConnection(connValue);
            SqlDataAdapter sqlCmd = new SqlDataAdapter(strQuery, sqlCon);
            sqlCmd.SelectCommand.CommandType = CommandType.Text;
            sqlCon.Open();
            sqlCmd.Fill(dsData);
            sqlCon.Close();
        }
        catch
        {
            throw;
        }
        return dsData.Tables[0];
    }
    protected void lnkSearchMyDocs_Click(object sender, EventArgs e)
    {
        string strUpdateJob = Request.Url.AbsoluteUri;
        Session["UrlRef"] = strUpdateJob;
        //uCls = new UtilityClass(this.Page);
        //uCls.ResetTheSessionVariables();
        Session["SearchMyDocs"] = "1";
        Response.Redirect("~/Documents/SearchDocument.aspx", false);

    }
    protected void lnkGenerateReports_Click(object sender, EventArgs e)
    {
        string strUpdateJob = Request.Url.AbsoluteUri;
        Session["UrlRef"] = strUpdateJob;
        Response.Redirect("UnderProcess.aspx", false);
    }

    protected void lnkBtnJobID_Click(object sender, EventArgs e)
    {
        Session["PayID"] = null;
        Session["JobID"] = null;

        string strUpdateJob = Request.Url.AbsoluteUri;
        Session["UrlRef"] = strUpdateJob;
        try
        {
            //Get the LinkButton that raised the event
            LinkButton lnkJobID = (LinkButton)sender;
            //Get the row that contains this dropdown
            GridViewRow gvr = (GridViewRow)lnkJobID.NamingContainer;

            Session["JobID"] = ((HtmlGenericControl)gvr.FindControl("divJobID")).InnerText;

            if (Session["JobID"] == null)
                Session["PayID"] = ((HtmlGenericControl)gvr.FindControl("divPayID")).InnerText;

            if (Session["JobID"].ToString() == "")
                Session["PayID"] = ((HtmlGenericControl)gvr.FindControl("divPayID")).InnerText;

            Session["JobInchargeID"] = lnkJobID.ToolTip;

            if (Session["SectionID"].ToString().Equals("4"))
            {
                Response.Redirect("~/Survey/SurveyDetails.aspx?REQUEST_ID= " + Session["JobInchargeID"] + "", false);
            }
            else
            {
                if ((Session["PayID"] == null))
                {
                    Session["JobCatID"] = ((HtmlGenericControl)gvr.FindControl("divJobCatID")).InnerText;
                    UpdateJobOwner(Convert.ToInt32(lnkJobID.ToolTip));

                    string catID = ((HtmlGenericControl)gvr.FindControl("divJobCatID")).InnerText.Trim();

                    if (catID.Equals("1"))
                        Response.Redirect("~/JobOrder/PSAJobDetails.aspx?JobID= " + Session["JobID"] + "", false);
                    else if (catID.Equals("8"))
                        Response.Redirect("~/DCLog/DCDetails.aspx?JobID= " + Session["JobID"] + "", false);
                    else
                        Response.Redirect("~/JobOrder/DefaultGrid.aspx?JobID= " + Session["JobID"] + "", false);
                }
                else
                {
                    Response.Redirect("~/Payments/PaymentDetails.aspx?PayID= " + Session["PayID"] + "", false);
                }
            }
        }
        catch (Exception ex)
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Error occurred while processing the request')</script>", false);
        }
    }
    protected void lnkBtnStaffStatus_Click(object sender, EventArgs e)
    {
        string strUpdateJob = Request.Url.AbsoluteUri;
        Session["UrlRef"] = strUpdateJob;
        try
        {
            //Get the LinkButton that raised the event
            LinkButton lnkJobID = (LinkButton)sender;
            //Get the row that contains this dropdown
            GridViewRow gvr = (GridViewRow)lnkJobID.NamingContainer;
            Session["JobID"] = ((HtmlGenericControl)gvr.FindControl("divJobID")).InnerText;
            Session["JobInchargeID"] = lnkJobID.ToolTip;

            Session["JobCatID"] = ((HtmlGenericControl)gvr.FindControl("divJobCatID")).InnerText;
            UpdateJobOwner(Convert.ToInt32(lnkJobID.ToolTip));

            string catID = ((HtmlGenericControl)gvr.FindControl("divJobCatID")).InnerText.Trim();

            if (catID.Equals("1"))
            {
                Response.Redirect("~/JobOrder/PSAJobDetails.aspx?JobID= " + Session["JobID"] + "", false);
            }
            else
            {
                Response.Redirect("~/JobOrder/DefaultGrid.aspx?JobID= " + Session["JobID"] + "", false);
            }

            // UpdateJob(Convert.ToInt32(Session["JobID"])); 
        }
        catch (Exception ex)
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Error occurred while processing the request')</script>", false);
        }
    }
    protected void lnkBtnDocReadDate_Click(object sender, EventArgs e)
    {
        string strUpdateJob = Request.Url.AbsoluteUri;
        Session["UrlRef"] = strUpdateJob;
        try
        {
            LinkButton lnkDistributrID = (LinkButton)sender;
            GridViewRow gvr = (GridViewRow)lnkDistributrID.NamingContainer;
            Session["distributeID"] = ((HtmlGenericControl)gvr.FindControl("divDistributeID")).InnerText;
            new JobOrderData().UpdateDistributionDateRead(Convert.ToInt32(((HtmlGenericControl)gvr.FindControl("divDistributeID")).InnerText), _currentUserID);
            int docid = Convert.ToInt32(((HtmlGenericControl)gvr.FindControl("divDocID")).InnerText);
            Response.Redirect("~/Documents/DocumentDetailsWindow.aspx?docRecID=" + docid + "&RecSentCatID=1", false);
        }
        catch (Exception ex)
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Error occurred while processing the request')</script>", false);
        }
    }
    public void UpdateJobOwner(int jobInchargeID)
    {
        try
        {
            using (SqlConnection con = new SqlConnection(connValue))
            {
                using (SqlCommand sqlCmd = new SqlCommand())
                {
                    sqlCmd.Connection = con;
                    sqlCmd.CommandType = CommandType.Text;
                    sqlCmd.CommandText = "UPDATE JobOwner SET dateRead =@jobReadDate where jobOwnerID = @jobOwnerID";
                    sqlCmd.Parameters.AddWithValue("@jobOwnerID", jobInchargeID);
                    sqlCmd.Parameters.AddWithValue("@jobReadDate", System.DateTime.Now.ToString("dd/MMM/yyyy"));

                    con.Open();
                    sqlCmd.ExecuteNonQuery();
                }
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    private void getUnReadInchargeData()
    {
        string sqlQuery = string.Empty;
       
            sqlQuery = "SELECT    JobOwner.jobID, JobOwner.jobNo, JobType_1.jobTypeName, [Document].referenceNo, REPLACE(CONVERT(NVARCHAR, JobOwner.staffIssueDate, 106), ' ', '-')  AS DateOfIssue, JobType_1.CategoryID AS jobCatID, JobOwner.sectionID, JobOwner.jobOwnerID, JobOwner.contactID, JobOwner.jobDocRefID, " +
                       " JobOwner.distributedBy, Contact.firstName + '  ' + Contact.lastName AS IssuedBy, JobOwner.payID FROM   JobOwner INNER JOIN JobType ON JobOwner.JobTypeID = JobType.jobTypeID INNER JOIN  JobType AS JobType_1 ON JobType.CategoryID = JobType_1.jobTypeID INNER JOIN " +
                    " [Document] ON JobOwner.jobDocRefID = [Document].documentID INNER JOIN  Contact ON JobOwner.distributedBy = Contact.contactID  WHERE  (JobOwner.dateRead IS NULL)  ORDER BY JobOwner.JobownerID DESC";
       
        SqlConnection objCon = new SqlConnection(connValue);
        SqlCommand objCmd = new SqlCommand(sqlQuery, objCon);
        SqlDataAdapter objDA = new SqlDataAdapter(objCmd);

        objDA.SelectCommand.CommandText = objCmd.CommandText.ToString();
        DataTable dt = new DataTable();
        objDA.Fill(dt);

        Session["getPayData"] = dt;

        if (dt.Rows.Count != 0)
            gridTasks.DataSource = dt.DefaultView;
        else
        {
            gridTasks.DataSource = null;
            // gridTasks.Visible = false;
        }
        gridTasks.DataBind();
    }
    private void documentWithoutLinkwithJob()
    {
        string sqlQuery = string.Empty;
       
        sqlQuery = "SELECT [Document].referenceNo, [Document].createDate, Contact.firstName + ' ' + Contact.lastName AS UserName, Section.sectionName, " + 
           "[Document].documentID, [Document].jobID FROM  [Document] INNER JOIN   Contact ON [Document].docCreatedByID = Contact.contactID INNER JOIN  Section ON Contact.sectionID = Section.sectionID " +
         " WHERE  (([Document].jobID IS NULL) and ([Document].paymentID IS NULL)) AND (YEAR([Document].createDate) = 2017) ";
       
        SqlConnection objCon = new SqlConnection(connValue);
        SqlCommand objCmd = new SqlCommand(sqlQuery, objCon);
        SqlDataAdapter objDA = new SqlDataAdapter(objCmd);

        objDA.SelectCommand.CommandText = objCmd.CommandText.ToString();
        DataTable dt = new DataTable();
        objDA.Fill(dt);

        

        if (dt.Rows.Count != 0)
            gridDocsJobs.DataSource = dt.DefaultView;
        else
        {
            gridDocsJobs.DataSource = null;
            // gridTasks.Visible = false;
        }
        gridDocsJobs.DataBind();
    }
    

    private void getUnReadInchargeDataOgSurveyOracle()
    {
        string sqlQuery = string.Empty;

        sqlQuery = "select request_id as jobOwnerID, user_id as IssuedBy, state_id as jobTypeName, TO_CHAR(start_date,'DD/Mon/YYYY') as DateOfIssue, '' as referenceNo, manager_comments, '' as jobCatID,'' as payID,'' as JobID  " +
                                   "  from app_resource_allocation Where User_id = '" + Session["systemUserName"].ToString() + "'";

        OracleConnection objCon = new OracleConnection(connValueOracle);
        OracleCommand objCmd = new OracleCommand(sqlQuery, objCon);
        OracleDataAdapter objDA = new OracleDataAdapter(objCmd);

        objDA.SelectCommand.CommandText = objCmd.CommandText.ToString();
        DataTable dt = new DataTable();
        objDA.Fill(dt);

        Session["getPayData"] = dt;

        if (dt.Rows.Count != 0)
            gridTasks.DataSource = dt.DefaultView;
        else
        {
            gridTasks.DataSource = null;
            gridTasks.Visible = false;
        }
        gridTasks.DataBind();
    }
    private void getOnGoingTasksPerStaffChart()   // chart 3
    {
        string sqlQuery = string.Empty; string strStaff = string.Empty;

        DataSet dsTndr = new DataSet();
        int sectionID = Convert.ToInt32(Session["SectionID"]);

        if (Session["userProfileID"].ToString().Equals("1"))
        {
            sqlQuery = "SELECT COUNT(*) AS JobCnt, Contact.userShortName FROM JobOwner INNER JOIN Contact ON JobOwner.contactID = Contact.contactID WHERE (JobOwner.jobOwnerStatusID = 3) GROUP BY JobOwner.contactID, Contact.userShortName HAVING (COUNT(*) > 5) ORDER BY Contact.userShortName";
            lblOngoingStaff.Text = "On Going Tasks Per Staff In All Sections Of EBSD";
        }
        else if (!userRightsColl.Contains("42") && Session["SectionID"].ToString().Equals("7")) //1 - All Sections
        {
            sqlQuery = "SELECT COUNT(*) AS JobCnt, Contact.userShortName FROM JobOwner INNER JOIN Contact ON JobOwner.contactID = Contact.contactID WHERE (JobOwner.jobOwnerStatusID = 3) GROUP BY JobOwner.contactID, Contact.userShortName HAVING (COUNT(*) > 5) ORDER BY Contact.userShortName";
            lblOngoingStaff.Text = "On Going Tasks Per Staff In All Sections Of EBSD";
        }
        else
        {
            lblOngoingStaff.Text = "On Going Tasks Per Staff In EBSD " + Session["SectionName"].ToString();

            sqlQuery = "SELECT COUNT(*) AS JobCnt, Contact.userShortName FROM  JobOwner INNER JOIN  Contact ON JobOwner.contactID = Contact.contactID " +
                      " WHERE  (JobOwner.sectionID = " + sectionID + ") AND (JobOwner.jobOwnerStatusID = 3) GROUP BY JobOwner.contactID, Contact.userShortName ORDER BY Contact.userShortName";
        }

        SqlDataAdapter daTndr = new SqlDataAdapter(sqlQuery, connValue);
        daTndr.Fill(dsTndr);
        if (dsTndr.Tables[0].Rows.Count != 0)
        {
            onGoingTasksPerStaffChart.DataSource = dsTndr.Tables[0].DefaultView;
            onGoingTasksPerStaffChart.Series["Series1"].XValueMember = "userShortName";
            onGoingTasksPerStaffChart.Series["Series1"].YValueMembers = "JobCnt";
            dsTndr.Tables.Clear();

            onGoingTasksPerStaffChart.ChartAreas[0].AxisX.MajorGrid.Enabled = false;
            onGoingTasksPerStaffChart.ChartAreas[0].AxisX.MinorGrid.Enabled = false;
            onGoingTasksPerStaffChart.ChartAreas[0].AxisY.MajorGrid.Enabled = false;
            onGoingTasksPerStaffChart.ChartAreas[0].AxisY.MinorGrid.Enabled = false;

            onGoingTasksPerStaffChart.ChartAreas[0].AxisX.LabelStyle.Angle = 30;
            onGoingTasksPerStaffChart.ChartAreas[0].AxisX.LabelStyle.ForeColor = Color.Maroon;

            onGoingTasksPerStaffChart.ChartAreas[0].AxisX.Interval = 1;
        }
    }

    private void getMyDocumentChart()
    {
        DataSet dsDoc = new DataSet();

        string sqlQuery = null;

        if (Convert.ToInt32(Session["UserID"]) == 1)
        {
            sqlQuery = "SELECT COUNT(DocumentDistribution.distributeID) AS DocCount, DocumentStatus.docStatusName " +
                   " FROM DocumentDistribution INNER JOIN  DocumentStatus ON DocumentDistribution.docStatusID = DocumentStatus.docStatusID WHERE (DocumentDistribution.docStatusID not in (4,2)) GROUP BY DocumentStatus.docStatusName";
        }
        else
        {
            sqlQuery = "SELECT COUNT(DocumentDistribution.distributeID) AS DocCount, DocumentStatus.docStatusName " +
                   " FROM DocumentDistribution INNER JOIN  DocumentStatus ON DocumentDistribution.docStatusID = DocumentStatus.docStatusID WHERE (DocumentDistribution.docStatusID not in (4)) AND " +
                   " (DocumentDistribution.contactID = " + Convert.ToInt32(Session["UserID"]) + ") " +
                           " GROUP BY DocumentStatus.docStatusName";
        }

        SqlDataAdapter daDoc = new SqlDataAdapter(sqlQuery, connValue);
        daDoc.Fill(dsDoc);
        if (dsDoc.Tables[0].Rows.Count != 0)
        {
            myDocsChart.DataSource = dsDoc.Tables[0].DefaultView;
            myDocsChart.Series["Series1"].XValueMember = "docStatusName";
            myDocsChart.Series["Series1"].YValueMembers = "DocCount";

            dsDoc.Tables.Clear();

            myDocsChart.ChartAreas[0].AxisX.MajorGrid.Enabled = false;
            myDocsChart.ChartAreas[0].AxisX.MinorGrid.Enabled = false;
            myDocsChart.ChartAreas[0].AxisY.MajorGrid.Enabled = false;
            myDocsChart.ChartAreas[0].AxisY.MinorGrid.Enabled = false;

            myDocsChart.ChartAreas[0].AxisX.LabelStyle.Angle = 30;
            myDocsChart.ChartAreas[0].AxisX.LabelStyle.ForeColor = Color.Maroon;

            myDocsChart.ChartAreas[0].AxisX.Interval = 1;
        }
    }
   
   
   

    protected void lnkSearchJobOrderLog_Click(object sender, EventArgs e)
    {
        string strUpdateJob = Request.Url.AbsoluteUri;
        Session["UrlRef"] = strUpdateJob;
        if (userRightsColl.Contains("10"))   //Add New Project
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "Popup", "<script>alert('You have no privilege to Search Job Order Log.')</script>", false);
            return;
        }
        else
        {
            if (Session["SectionID"].Equals("3"))
                Response.Redirect("~/DCLog/SearchDCLog.aspx", false);
            else
                Response.Redirect("SearchJobMstr.aspx", false);
        }
    }
    protected void lnkPaymentRequest_Click(object sender, EventArgs e)
    {
        string strUpdateJob = Request.Url.AbsoluteUri;
        Session["UrlRef"] = strUpdateJob;
        if (userRightsColl.Contains("19"))
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "Popup", "<script>alert('You have no privilege for Payment Request.')</script>", false);
            return;
        }
        else
        {
            Response.Redirect("~/JobOrder/UnderProcess.aspx", false);
        }
    }
    protected void lnkSearchAddendumLog_Click(object sender, EventArgs e)
    {
        string strUpdateJob = Request.Url.AbsoluteUri;
        Session["UrlRef"] = strUpdateJob;

        if (userRightsColl.Contains("11"))
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "Popup", "<script>alert('You have no privilege to Search Addendum Log.')</script>", false);
            return;
        }
        else
        {
            Response.Redirect("SearchAdmData.aspx", false);
        }
    }

    protected void lnkNewPaymentNCP_Click(object sender, EventArgs e)
    {
        if (userRightsColl.Contains("18"))
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "Popup", "<script>alert('You have no privilege to Add Payment Request.')</script>", false);
            return;
        }
        else
        {

            // Application["PrjType"] = Session["PrjCP/NCP"];
            Response.Redirect("~/Payments/AddNewNCPpayment.aspx", false);

            //string strJavascript = "<script type='text/javascript'>window.open('~/Payments/AddNewPayment.aspx,'_blank');</script>";
            //Response.Write(strJavascript);
        }
    }


    protected void lnkNewPaymentCP_Click(object sender, EventArgs e)
    {
        if (userRightsColl.Contains("18"))
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "Popup", "<script>alert('You have no privilege to Add Payment Request.')</script>", false);
            return;
        }
        else
        {
            Session["PrjCP/NCP"] = "CP";
            Application["PrjType"] = Session["PrjCP/NCP"];
            Response.Redirect("~/Payments/AddNewPayment.aspx", false);
        }
    }
    protected void lnkNewJobOrder_Click(object sender, EventArgs e)
    {

        string strUpdateJob = Request.Url.AbsoluteUri;
        Session["UrlRef"] = strUpdateJob;

        if (userRightsColl.Contains("2"))   //Add New Project
        {
            Session["lblText"] = "You are not allowed to Add New Job Order.Please contact system Administrator for further inquiry.";
            Session["lblSub"] = "Restricted Access to Add New Job Order.";
            Session["lblBody"] = "This is in reference to Restricted Access to Add New Job Order. I would like to inquire about the restriction.";


            string url = "RestrictedMsgWindow.aspx";
            string s = "window.open('" + url + "', 'popup_window', 'width=500,height=250,left=100,top=100,resizable=yes,scrollbars=yes');";
            ClientScript.RegisterStartupScript(this.GetType(), "script", s, true);


            //ClientScript.RegisterClientScriptBlock(this.GetType(), "Popup", "<script>alert('You have no privilege to add this Job,Contact administrator.')</script>", false);
            //return;
        }
        else if (Session["SectionID"].ToString().Equals("2"))
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "Popup", "<script>alert('This is not applicable to all employees from EBSD Payment Section.')</script>", false);
            return;
        }
        else
        {
            if (Session["SectionID"].Equals("3"))
            {
                Response.Redirect("~/DCLog/DCNewJob.aspx");
            }
            else
            {
                string url = "JobEntryForm.aspx";
                string s = "window.open('" + url + "', 'popup_window', 'width=990,height=700,left=100,top=100,resizable=yes,scrollbars=yes');";
                ClientScript.RegisterStartupScript(this.GetType(), "script", s, true);
            }

        }
    }
    protected void myDocsChart_Click(object sender, ImageMapEventArgs e)
    {
        string strUpdateJob = Request.Url.AbsoluteUri;
        Session["UrlRef"] = strUpdateJob;

        uCls = new UtilityClass(this.Page);
        uCls.ResetTheSessionVariables();
        Session["MyChartClickDocStatus"] = e.PostBackValue;
        int docStatusID = 1;
        if (e.PostBackValue.Equals("Open"))
            docStatusID = 1;
        else if (e.PostBackValue.Equals("For Follow Up"))
            docStatusID = 2;
        else if (e.PostBackValue.Equals("Pending"))
            docStatusID = 3;

        Response.Redirect("~/Documents/SearchDocument.aspx?docStatID=" + docStatusID, false);
    }
    protected void sectionWiseDoc_Click(object sender, ImageMapEventArgs e)
    {
        uCls = new UtilityClass(this.Page);
        uCls.ResetTheSessionVariables();
        Session["SectionWiseDocStatus"] = e.PostBackValue;
        Session["SectionWiseSearch"] = "1";


        int docStatusID = 1;
        if (e.PostBackValue.Equals("Open"))
            docStatusID = 1;
        else if (e.PostBackValue.Equals("For Follow Up"))
            docStatusID = 2;
        else if (e.PostBackValue.Equals("Pending"))
            docStatusID = 3;

        Response.Redirect("~/Documents/DocumentRegister.aspx?docStatID=" + docStatusID, false);

    }
    protected void onGoingTasksPerSectionChart_Click(object sender, ImageMapEventArgs e)
    {

        Session["JobType"] = e.PostBackValue;
        uCls = new UtilityClass(this.Page);
        uCls.ResetTheSessionVariables();
        Response.Redirect("~/Documents/MyDocuments.aspx", false);

    }
    protected void lnkBtnRefNo_Click(object sender, EventArgs e)
    {
        string strUpdateJob = Request.Url.AbsoluteUri;
        Session["UrlRef"] = strUpdateJob;
        try
        {
            //Get the LinkButton that raised the event
            LinkButton lnkDocRefNo = (LinkButton)sender;
            //Get the row that contains this dropdown
            GridViewRow gvr = (GridViewRow)lnkDocRefNo.NamingContainer;
            Session["DocID"] = ((HtmlGenericControl)gvr.FindControl("divDocID")).InnerText;
            Session["DocCategoryID"] = ((HtmlGenericControl)gvr.FindControl("divDocCatID")).InnerText;
            Session["UrlRef"] = "~/JobOrder/DefaultWindow.aspx";
            Response.Redirect("~/Documents/DocumentDetailsWindow.aspx?docCaiD=1", false);
        }
        catch (Exception ex)
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Error occurred while processing the request')</script>", false);
        }
    }
    protected void gridDocs_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            try
            {
                uCls = new UtilityClass(this.Page);
                Control ctrlSuperseded = e.Row.FindControl("divReceiveSuperseded");

                if (ctrlSuperseded != null)
                {
                    HtmlGenericControl htmlCtrlSuperseded = ctrlSuperseded as HtmlGenericControl;
                    e.Row.Cells[1].BackColor = System.Drawing.Color.WhiteSmoke;
                    e.Row.Cells[1].ForeColor = System.Drawing.Color.Gray;

                    e.Row.Cells[2].BackColor = System.Drawing.Color.WhiteSmoke;
                    e.Row.Cells[2].ForeColor = System.Drawing.Color.Gray;
                }
            }
            catch (Exception ex)
            {
                ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Error occurred while performing database operation')</script>", false);
            }
        }
    }
   
   
 
    protected void lnKShowAll_Click(object sender, EventArgs e)
    {
        string strUpdateJob = Request.Url.AbsoluteUri;
        Session["UrlRef"] = strUpdateJob;

     

       
    }
    protected void lnkHide_Click(object sender, EventArgs e)
    {
        string strUpdateJob = Request.Url.AbsoluteUri;
        Session["UrlRef"] = strUpdateJob;

        getMyDocumentChart();

        if (Session["SectionID"].Equals("4"))
            getUnReadInchargeDataOgSurveyOracle();
        else
            getUnReadInchargeData();

        //  getOnGoingTasksPerSection();

        getOnGoingTasksPerSection_New123();
        getUnReadInchargeData();
        new JobOrderData().UpdateForFoloowupDocstatus();
        new JobOrderData().UpdateUserAutoReplyStatus();


        if (!userRightsColl.Contains("42"))
            getOnGoingTasksPerStaffChart();
        

        if (userRightsColl.Contains("1"))
            lnKShowAll.Visible = false;


       
    }
    protected void OngoingJobsClick(object sender, ImageMapEventArgs e)
    {
        // Basic Materials,A_ (PSA Contract),Cost Control Section,Payment Request,
        //Comitted Contract,Cost Estimate,Planning Schedule(Baseline),Non Committed Contracts

        string sectionName = Session["SectionName"].ToString();

        Session["OverDueName"] = e.PostBackValue.ToString();

        Session["OnGoingJobStatus"] = e.PostBackValue;

        // overdueJobs_old(sectionName);   

        // overdueJobs(Session["ShortName"].ToString());

        //Planning Schedule (Baseline)    //Cost Estimate       //A_ (PSA Contract) 

        if (lblOngoingJobs.Text.Equals("My On Going Tasks") & Session["SectionID"].Equals("1"))
        {
            Response.Redirect("~/JobOrder/JobOrder.aspx", false);
        }
        else if ((!Session["userProfileID"].Equals("2")) & Session["SectionID"].Equals("3"))
        {
            Response.Redirect("~/DCLog/ViewDCLog.aspx", false);
        }
        else if (Session["SectionName"].ToString().Equals("Cost Control Section") || Session["SectionName"].ToString().Equals("Planning and Scheduling"))
        {
            Response.Redirect("~/DCLog/OverDueJobs.aspx", false);
        }
        else if (sectionName.Equals("Payment Section") || sectionName.Equals("Payment Request"))
        {
            if (lblOngoingJobs.Text.Equals("My On Going Tasks"))
                Response.Redirect("~/Payments/ViewPayments.aspx", false);
            else
                Response.Redirect("~/Payments/OverDuePayments.aspx", false);
        }
        else if (sectionName.Trim().Equals("Document Control") || Session["userProfileID"].Equals("2"))           //Document Request     Document Control Section       // sectionName.Equals("Review Baseline Schedule")
        {
            Response.Redirect("~/DCLog/OverDueJobs.aspx", false);
        }
        else if ((e.PostBackValue.Trim().ToString().Equals("Document Control")) && (Session["userProfileID"].Equals("1")))
        {
            Response.Redirect("~/DCLog/OverDueJobs.aspx", false);
        }
        else if ((e.PostBackValue.ToString().Equals("Cost Control Section")) && (Session["userProfileID"].Equals("1")))
        {
            Response.Redirect("~/DCLog/OverDueJobs.aspx", false);
        }
        else if ((e.PostBackValue.ToString().Equals("Payment Section")) && (Session["userProfileID"].Equals("1")))
        {
            Response.Redirect("~/Payments/OverDuePayments.aspx", false);
        }
        else if (lblOngoingJobs.Text.Contains("Over Due") & Session["SectionID"].Equals("3"))
        {
            Response.Redirect("~/DCLog/OverDueJobs.aspx", false);
        }
        else
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "Popup", "<script>alert('Restricted Access!')</script>", false);
        }



    }
    private void overdueJobs(string sectionName)
    {
        if (Session["SectionName"].ToString().Equals("Cost Control Section") || Session["SectionName"].ToString().Equals("Planning and Scheduling"))
        {
            if (!userRightsColl.Contains("5") || !userRightsColl.Contains("42"))
            {

                string cmtName = Session["OnGoingJobStatus"].ToString().Trim();

                if ((Session["SectionID"].ToString() == "1") || (Session["SectionID"].ToString() == "6"))
                {
                    if (cmtName.Equals("Cost Control Section"))
                        Response.Redirect("~/DCLog/OverDueJobs.aspx", false);

                    else if (cmtName.Trim().Equals("Comitted Contract"))
                        Response.Redirect("~/JobOrder/JobOrder.aspx", false);


                    else if (cmtName.Equals("Non Committed Contracts"))
                        Response.Redirect("~/JobOrder/JobOrder.aspx", false);


                    else if (cmtName.Equals("Basic Materials"))
                        Response.Redirect("~/JobOrder/JobOrder.aspx", false);


                    else if (cmtName.Equals("Cost Estimate"))
                        Response.Redirect("~/JobOrder/JobOrder.aspx", false);


                    else if (cmtName.Contains("Planning Schedule"))
                        Response.Redirect("~/JobOrder/JobOrder.aspx", false);


                    else if (cmtName.Equals("A_ (PSA Contract)"))
                        Response.Redirect("~/JobOrder/JobOrder.aspx", false);

                }
            }
        }
        else if (sectionName.Equals("Payment Section") || sectionName.Equals("Payment Request"))
        {
            Response.Redirect("~/Payments/ViewPayments.aspx", false);
        }
        else if (sectionName.Equals("Document Request") || sectionName.Equals("Review Baseline Schedule"))           //Document Request     Document Control Section
        {
            Response.Redirect("~/DCLog/ViewDCLog.aspx", false);
        }
        else
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "Popup", "<script>alert('Restricted Access!')</script>", false);
        }
    }
    
    protected void onGoingTasksPerStaffChart_Click(object sender, ImageMapEventArgs e)
    {
        //Session["OnGoingJobStatus"] = e.PostBackValue;
        // int cntID = getContactID(e.PostBackValue.ToString());

        Session["ShortName"] = e.PostBackValue.ToString();

        if (!Session["SectionID"].Equals("4"))
            Response.Redirect("~/JobOrder/SearchAllJobs.aspx", false);
        else
            Response.Redirect("~/Survey/SurveyStaffJobs.aspx", false);

    }
    private int getContactID(string userName)
    {
        int cnctID = 0;
        SqlConnection sqlConn = new SqlConnection(connValue);
        string sqlQuery = "SELECT contactID From Contact Where userShortName = '" + userName + "' ";

        try
        {
            sqlConn.Open();
            SqlCommand sqlCom = new SqlCommand(sqlQuery, sqlConn);
            SqlDataReader sqlReader = sqlCom.ExecuteReader();
            while (sqlReader.Read())
            {
                cnctID = Convert.ToInt32(sqlReader["contactID"].ToString());
            }
            sqlReader.Close();
        }
        catch (Exception ex)
        {
            Response.Write("Error getting while reading data !" + ex.Message);
        }
        finally
        {
            sqlConn.Close();
        }
        return cnctID;
    }

    // lnkSearchDoc_Click

    protected void lnkSearchDoc_Click(object sender, EventArgs e)
    {
        string strUpdateJob = Request.Url.AbsoluteUri;
        Session["UrlRef"] = strUpdateJob;

        //UtilityClass utils = new UtilityClass(this.Page);
        //string url = Request.Url.AbsoluteUri;
        //if (url.Contains(":"))
        //    url = url.Substring(0, utils.GetNthIndex(url, '/', 4));
        //else
        //    url = url.Substring(0, utils.GetNthIndex(url, '/', 2));

        //uCls = new UtilityClass(this.Page);
        //uCls.ResetTheSessionVariables();


        Session["SearchAllDocs"] = "1";
        Response.Redirect("~/Documents/DocumentRegister.aspx", false);


    }
    protected void onGoingTasksPerStaffChart_Load(object sender, EventArgs e)
    {

    }

    private void UpdateDocumentActionDueDate()
    {
        string actionDate = string.Empty;
        SqlConnection sqlConn = new SqlConnection(connValue);
        string sqlQuery = "SELECT  actionDueDate FROM DocumentDistribution  ";

        try
        {
            sqlConn.Open();
            SqlCommand sqlCom = new SqlCommand(sqlQuery, sqlConn);
            SqlDataReader sqlReader = sqlCom.ExecuteReader();
            while (sqlReader.Read())
            {
                actionDate = sqlReader["actionDueDate"].ToString();
                DateTime date1 = ConvertToDateTime(actionDate);
                DateTime date2 = ConvertToDateTime(System.DateTime.Now.ToString());
                int result123 = DateTime.Compare(date2, date1);
                if (result123 == 1)
                {

                }
            }
            sqlReader.Close();
        }
        catch (Exception ex)
        {
            Response.Write("Error getting while reading data !" + ex.Message);
        }
        finally
        {
            sqlConn.Close();
        }
    }
    private DateTime ConvertToDateTime(string strDateTime)
    {
        DateTime dtFinaldate; string sDateTime;
        try
        {
            //dtFinaldate = Convert.ToDateTime(strDateTime); 

            string[] sDate = strDateTime.Split('/');
            sDateTime = sDate[1] + '/' + sDate[0] + '/' + sDate[2];
            dtFinaldate = Convert.ToDateTime(sDateTime);
        }
        catch (Exception e)
        {
            string[] sDate = strDateTime.Split('/');
            sDateTime = sDate[0] + '/' + sDate[1] + '/' + sDate[2];
            dtFinaldate = Convert.ToDateTime(sDateTime);
        }
        return dtFinaldate;
    }

    // UpdateDocumentStatusForFollowUp


   
    
   
    double total = 0;
    double totalBudgetAmount = 0;
    double totalPMCAmount = 0;
    double totalEBSDAmount = 0;
    double totalAwardAmount = 0;
    protected void gvCostEstimate_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {

        }


        if (e.Row.RowType == DataControlRowType.Footer)
        {
            e.Row.Cells[2].Text = "Grand Total";
            e.Row.Cells[2].Font.Bold = true;
            e.Row.Cells[2].HorizontalAlign = HorizontalAlign.Center;

            // e.Row.Cells[3].Text = Convert.ToDouble(Session["TotalBudget"]).ToString();
            if (Session["TotalBudget"] != "")
            {
                e.Row.Cells[3].Text = Convert.ToDecimal(Session["TotalBudget"]).ToString("#,##0");
                e.Row.Cells[3].Font.Bold = true;
                e.Row.Cells[3].HorizontalAlign = HorizontalAlign.Center;
            }
            if (Session["TotalPMC"] != "")
            {
                e.Row.Cells[4].Text = Convert.ToDecimal(Session["TotalPMC"]).ToString("#,##0");
                e.Row.Cells[4].Font.Bold = true;
                e.Row.Cells[4].HorizontalAlign = HorizontalAlign.Center;
            }
            if (Session["TotalEbsd"] != "")
            {
                e.Row.Cells[5].Text = Convert.ToDecimal(Session["TotalEbsd"]).ToString("#,##0");
                e.Row.Cells[5].Font.Bold = true;
                e.Row.Cells[5].HorizontalAlign = HorizontalAlign.Center;
            }
            if (Session["TotalAward"] != "")
            {
                e.Row.Cells[6].Text = Convert.ToDecimal(Session["TotalAward"]).ToString("#,##0");
                e.Row.Cells[6].Font.Bold = true;
                e.Row.Cells[6].HorizontalAlign = HorizontalAlign.Center;
            }
            if (Session["TotalAward"] != "")
            {
                e.Row.Cells[6].Text = Convert.ToDecimal(Session["TotalAward"]).ToString("#,##0");
                e.Row.Cells[6].Font.Bold = true;
                e.Row.Cells[6].HorizontalAlign = HorizontalAlign.Center;
            }




            //Session["TotalBudget"] = dsDoc.Tables[0].Rows[0][1].ToString();
            //Session["TotalPMC"] = dsDoc.Tables[0].Rows[0][2].ToString();
            //Session["TotalEbsd"] = dsDoc.Tables[0].Rows[0][3].ToString();
            //Session["TotalAward"] = dsDoc.Tables[0].Rows[0][4].ToString();

            //Label lblTotalqty = (Label)e.Row.FindControl("lblbudgetSum");
            //lblTotalqty.Text = total.ToString();
        }
    }
    protected void btnExport_Click(object sender, EventArgs e)
    {
        

    }
    //   <span style="font-size: 9pt;"> </span>
    public override void VerifyRenderingInServerForm(Control control)
    {
        /* Confirms that an HtmlForm control is rendered for the specified ASP.NET
           server control at run time. */


    }
    protected void Button1_Click(object sender, EventArgs e)
    {
      
    }
    protected void chartPayAffair_Click(object sender, ImageMapEventArgs e)
    {

    }
   

    protected void onGoingTasksPerSectionChart_Load(object sender, EventArgs e)
    {

    }
    protected void lnkGenerateReports0_Click(object sender, EventArgs e)
    {
        string strUpdateJob = Request.Url.AbsoluteUri;
        Session["UrlRef"] = strUpdateJob;
        if (userRightsColl.Contains("19"))   //Add New Project
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "Popup", "<script>alert('You have no privilege to Search Job Order Log.')</script>", false);
            return;
        }
        else
        {
            Response.Redirect("~/Payments/SearchPayment.aspx", false);
        }
    }
    protected void gridTasks_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        gridTasks.PageIndex = e.NewPageIndex;
        // bindGridView();

        DataTable dt = new DataTable();
        dt = Session["getPayData"] as DataTable;

       // lblCnt.Text = "(" + dt.Rows.Count.ToString() + ")";

        gridTasks.DataSource = dt;
        gridTasks.DataBind();

        PageloadData();
    }
    private void bindGridView()
    {
        gridTasks.DataSource = Session["getPayData"];
        gridTasks.DataBind();

    }

    protected void UpdateeBookPCMCommittmentNo()
    {
        string strQuery = "SELECT commitment_no,ID FROM PCM_CNMT_TABLE WHERE (commitment_no <> N'')";
        Dictionary<int, string> pcmDataCollMain = new Dictionary<int, string>();

        using (SqlConnection con = new SqlConnection(connValue))
        {
            using (SqlCommand sqlCmd = new SqlCommand())
            {
                sqlCmd.CommandText = strQuery;
                sqlCmd.Connection = con;

                con.Open();
                using (SqlDataReader dr = sqlCmd.ExecuteReader())
                {
                    while (dr.Read())
                    {
                        string strCntr = string.Empty;
                        strCntr = dr["commitment_no"].ToString();

                        string strCntrSlas = string.Empty;
                        string[] strColl = strCntr.Split('/');

                        if (strColl.Length == 3)
                            strCntrSlas = strColl[0] + strColl[1] + strColl[2];
                        else if (strColl.Length == 2)
                            strCntrSlas = strColl[0] + strColl[1];
                        else if (strColl.Length == 1)
                            strCntrSlas = strColl[0];

                        string[] strColl2 = strCntrSlas.Split(' ');

                        if (strColl2.Length == 2)
                            strCntrSlas = strColl2[0] + strColl2[1];

                        pcmDataCollMain.Add(Convert.ToInt32(dr["ID"]), strCntrSlas);
                    }
                }
            }
        }

        UpdatePayment(pcmDataCollMain);
    }
    private void UpdatePayment(Dictionary<int, string> pcmDataColl)
    {
        int pcmID = 0;
        string eBookCntrNo = string.Empty;


        foreach (int key in pcmDataColl.Keys)
        {
            pcmID = key;
            eBookCntrNo = pcmDataColl[key];

            try
            {
                using (SqlConnection con = new SqlConnection(connValue))
                {
                    using (SqlCommand sqlCmd = new SqlCommand())
                    {
                        sqlCmd.Connection = con;
                        sqlCmd.CommandType = CommandType.Text;
                        sqlCmd.CommandText = "UPDATE PCM_CNMT_TABLE SET eBook_commitment_no =@eBookcommitment_no where ID = @PCMID";
                        sqlCmd.Parameters.AddWithValue("@PCMID", pcmID);
                        sqlCmd.Parameters.AddWithValue("@eBookcommitment_no", eBookCntrNo);

                        con.Open();
                        sqlCmd.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
    protected void lnkDueJobs_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/DCLog/OverDueJobs.aspx", false);
    }
    protected void Survey(object sender, ImageMapEventArgs e)
    {
        Response.Redirect("~/Survey/SearchSurveyLog.aspx", false);
    }
    protected void onGoingSurveyTasks_Load(object sender, EventArgs e)
    {

    }
   
    protected void onGoingTasksofSurvey_Load(object sender, EventArgs e)
    {

    }
    protected void onGoingTasksofSurvey_Click(object sender, ImageMapEventArgs e)
    {
        string sectionName = Session["SectionName"].ToString();

        Session["OverDueName"] = e.PostBackValue.ToString();

        Session["OnGoingJobStatus"] = e.PostBackValue;

        if (Session["SectionID"].Equals("4"))
        {
            Response.Redirect("~/Survey/SurveyProcessGraphInfo.aspx", false);
        }
        else
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "Popup", "<script>alert('Restricted Access!')</script>", false);
        }
    }
    private void getOnGoingTasksofSurveyOracle()
    {
        DataSet dsTndr = new DataSet();

        string sqlQuery = null; int secID = Convert.ToInt32(Session["SectionID"]);
        string strSeriesName = string.Empty;

        if (Session["userProfileID"].ToString().Equals("1"))   // For Admin
        {
            sqlQuery = "select Count(status) as JobCnt, status from survey_info where status Not IN ('CLOSED','Old','CANCEL' ) group by status";
            strSeriesName = "sectionName";

            lblOngoingSurvey.Text = "Survey Process Details";
        }
        else
        {
            // sqlQuery = "select COUNT(*) as JobCnt,state_id as status from app_resource_allocation where user_id = 'tsd_osoro' and state_id = 'OPEN'  group by state_id";

            sqlQuery = "select Count(status) as JobCnt, status from survey_info where status Not IN ('CLOSED','Old','CANCEL' ) group by status";
            strSeriesName = "sectionName";
            lblOngoingSurvey.Text = "Survey Process Details";
        }

        OracleDataAdapter daTndr = new OracleDataAdapter(sqlQuery, connValueOracle);
        daTndr.Fill(dsTndr);

        if (dsTndr.Tables[0].Rows.Count != 0)
        {
            onGoingTasksofSurvey.DataSource = dsTndr.Tables[0].DefaultView;

            onGoingTasksofSurvey.Series["Series1"].XValueMember = "status";
            onGoingTasksofSurvey.Series["Series1"].YValueMembers = "JobCnt";

            dsTndr.Tables.Clear();

            onGoingTasksofSurvey.ChartAreas[0].AxisX.MajorGrid.Enabled = false;
            onGoingTasksofSurvey.ChartAreas[0].AxisX.MinorGrid.Enabled = false;
            onGoingTasksofSurvey.ChartAreas[0].AxisY.MajorGrid.Enabled = false;
            onGoingTasksofSurvey.ChartAreas[0].AxisY.MinorGrid.Enabled = false;

            onGoingTasksofSurvey.ChartAreas[0].AxisX.LabelStyle.Angle = 30;
            onGoingTasksofSurvey.ChartAreas[0].AxisX.LabelStyle.ForeColor = Color.Maroon;

            onGoingTasksofSurvey.ChartAreas[0].AxisX.Interval = 1;
        }
    }
    protected void lnkNewSurvey_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/Survey/AddNewSurvey.aspx", false);
    }
    protected void lnkSearchSurvey_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/Survey/SearchSurveyLog.aspx", false);
    }
    protected void lnkOnGoingSurvey_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/Survey/ViewSurveyInfo.aspx", false);
    }

    private void getOnGoingTasksPerStaffChartForSurvey()   // chart 3
    {
        string sqlQuery = string.Empty; string strStaff = string.Empty;

        DataSet dsTndr = new DataSet();
        int sectionID = Convert.ToInt32(Session["SectionID"]);

        if (Session["userProfileID"].ToString().Equals("1"))
        {
            sqlQuery = "Select COUNT(app_resource_allocation.USER_ID) as JobCnt,APP_SCRTY_USERS.NAME as userShortName from app_resource_allocation INNER JOIN APP_SCRTY_USERS ON app_resource_allocation.USER_ID = APP_SCRTY_USERS.USER_ID where app_resource_allocation.state_id ='OPEN' group by APP_SCRTY_USERS.NAME ";
            lblOngoingStaff.Text = "On Going Tasks Per Staff In All Sections Of EBSD";
        }
        else
        {
            lblOngoingStaff.Text = "On Going Tasks Per Staff In EBSD " + Session["SectionName"].ToString();

            sqlQuery = "Select COUNT(app_resource_allocation.USER_ID) as JobCnt,APP_SCRTY_USERS.NAME as userShortName from app_resource_allocation INNER JOIN APP_SCRTY_USERS ON app_resource_allocation.USER_ID = APP_SCRTY_USERS.USER_ID where app_resource_allocation.state_id ='OPEN' group by APP_SCRTY_USERS.NAME ";
        }

        OracleDataAdapter daTndr = new OracleDataAdapter(sqlQuery, connValueOracle);
        daTndr.Fill(dsTndr);
        if (dsTndr.Tables[0].Rows.Count != 0)
        {
            onGoingTasksPerStaffChart.DataSource = dsTndr.Tables[0].DefaultView;
            onGoingTasksPerStaffChart.Series["Series1"].XValueMember = "userShortName";
            onGoingTasksPerStaffChart.Series["Series1"].YValueMembers = "JobCnt";
            dsTndr.Tables.Clear();

            onGoingTasksPerStaffChart.ChartAreas[0].AxisX.MajorGrid.Enabled = false;
            onGoingTasksPerStaffChart.ChartAreas[0].AxisX.MinorGrid.Enabled = false;
            onGoingTasksPerStaffChart.ChartAreas[0].AxisY.MajorGrid.Enabled = false;
            onGoingTasksPerStaffChart.ChartAreas[0].AxisY.MinorGrid.Enabled = false;

            onGoingTasksPerStaffChart.ChartAreas[0].AxisX.LabelStyle.Angle = 30;
            onGoingTasksPerStaffChart.ChartAreas[0].AxisX.LabelStyle.ForeColor = Color.Maroon;

            onGoingTasksPerStaffChart.ChartAreas[0].AxisX.Interval = 1;
        }
    }
    protected void gridDocsNonEBD_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {

    }
    protected void gridDocsNonEBD_RowDataBound(object sender, GridViewRowEventArgs e)
    {

    }

    private void getUnreadDocumentDataFromNonEBD()
    {
        string sqlQuery = string.Empty;

        sqlQuery = "SELECT [Document].referenceNo, DocumentType.documentType, [Document].superseded, [Document].jobID, Contact.firstName + ' ' + Contact.lastName AS userName, " +
                        " [Document].documentID, Contact.companyID, Company.cmpName AS deptName FROM [Document] INNER JOIN DocumentType ON [Document].docTypeID = DocumentType.docTypeID INNER JOIN Contact ON [Document].originContactID = Contact.contactID INNER JOIN " +
                       "  Company ON Contact.companyID = Company.companyID WHERE ([Document].docTypeID IN (9, 10, 11)) AND ([Document].jobID IS NULL) AND (Contact.sectionID NOT IN (1, 2, 3))";

        SqlConnection objCon = new SqlConnection(connValue);
        SqlCommand objCmd = new SqlCommand(sqlQuery, objCon);
        SqlDataAdapter objDA = new SqlDataAdapter(objCmd);
        objDA.SelectCommand.CommandText = objCmd.CommandText.ToString();
        DataTable dtReceiveDocs = new DataTable();

        Session["getNonEBDDocs"] = dtReceiveDocs;
        objDA.Fill(dtReceiveDocs);
        gridDocsNonEBD.DataSource = dtReceiveDocs;
        gridDocsNonEBD.DataBind();

        if (dtReceiveDocs.Rows.Count > 0)
            lblDocNonEBD.Text = "Documents Received from Non EBD Department";

    }

    protected void lnkBtnDocNonEBD_Click(object sender, EventArgs e)
    {
        string strUpdateJob = Request.Url.AbsoluteUri;
        Session["UrlRef"] = strUpdateJob;
        try
        {
            LinkButton lnkDistributrID = (LinkButton)sender;
            GridViewRow gvr = (GridViewRow)lnkDistributrID.NamingContainer;
            int docid = Convert.ToInt32(((HtmlGenericControl)gvr.FindControl("divDocID")).InnerText);
            Response.Redirect("~/Documents/DocumentDetailsWindow.aspx?docRecID=" + docid + "&RecSentCatID=1", false);
        }
        catch (Exception ex)
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Error occurred while processing the request')</script>", false);
        }
    }


    protected void lnkSearchFiles_Click(object sender, EventArgs e)
    {
        //Response.Redirect("JobsWithDocuments.aspx", false);

        Response.Redirect("CostControlHomePage.aspx", false);
    }



    private void filterData()
    {
      
    }

    #endregion









    //#region MyRegion
    //private DataTable CostEstimateReport()
    //{
    //    //JobVOSI.contractorAmt,(JobVOSI.ebsdAmt + JobVOSI.contractorAmt)

    //    System.Threading.Thread.CurrentThread.CurrentCulture = new System.Globalization.CultureInfo("ar-QA");

    //    //string sqlQuery = "SELECT Job.contractNo, Job.projectTitle, JobVOSI.budgetAmnt, JobVOSI.pmcAmt, JobVOSI.ebsdAmt , JobVOSI.contractorAmt, (JobVOSI.contractorAmt-JobVOSI.ebsdAmt)/JobVOSI.contractorAmt as EBSD_ratio, " +
    //    //            "(JobVOSI.contractorAmt-JobVOSI.budgetAmnt)/JobVOSI.contractorAmt as Budget_ratio" + 
    //    //            " FROM JobVOSI INNER JOIN Job ON JobVOSI.jobID = Job.jobID INNER JOIN  JobType ON Job.jobTypeID = JobType.jobTypeID WHERE (JobType.CategoryID IN (4, 7))";

    //    DataTable dt = new DataTable();
    //    using (SqlConnection objCon = new SqlConnection(connValue))
    //    {
    //        using (SqlCommand objCmd = new SqlCommand())
    //        {
    //            objCmd.CommandType = CommandType.StoredProcedure;
    //            objCmd.Connection = objCon;
    //            objCmd.CommandText = "CostEstimateReport";

    //            SqlDataAdapter objDA = new SqlDataAdapter(objCmd);

    //            objDA.SelectCommand.CommandText = objCmd.CommandText.ToString();

    //            objDA.Fill(dt);

    //            gvCostEstimate.DataSource = dt;
    //            gvCostEstimate.DataBind();


    //        }
    //    }

    //    return dt;
    //}
    //private void getUnreadDocumentDataFromNonEBD()
    //{
    //    string sqlQuery = string.Empty;

    //    sqlQuery = "SELECT [Document].referenceNo, DocumentType.documentType, [Document].superseded, [Document].jobID, Contact.firstName + ' ' + Contact.lastName AS userName, " +
    //                    " [Document].documentID, Contact.companyID, Company.cmpName AS deptName FROM [Document] INNER JOIN DocumentType ON [Document].docTypeID = DocumentType.docTypeID INNER JOIN Contact ON [Document].originContactID = Contact.contactID INNER JOIN " +
    //                   "  Company ON Contact.companyID = Company.companyID WHERE ([Document].docTypeID IN (9, 10, 11)) AND ([Document].jobID IS NULL) AND (Contact.sectionID NOT IN (1, 2, 3))";

    //    SqlConnection objCon = new SqlConnection(connValue);
    //    SqlCommand objCmd = new SqlCommand(sqlQuery, objCon);
    //    SqlDataAdapter objDA = new SqlDataAdapter(objCmd);
    //    objDA.SelectCommand.CommandText = objCmd.CommandText.ToString();
    //    DataTable dtReceiveDocs = new DataTable();

    //    Session["getNonEBDDocs"] = dtReceiveDocs;
    //    objDA.Fill(dtReceiveDocs);
    //    gridDocsNonEBD.DataSource = dtReceiveDocs;
    //    gridDocsNonEBD.DataBind();

    //    // if (dtReceiveDocs.Rows.Count > 0)
    //    //lblDocNonEBD.Text = "Documents Received from Non EBD Department";

    //}
    //private void getOnGoingTasksPerStaffChartForSurvey()   // chart 3
    //{
    //    string sqlQuery = string.Empty; string strStaff = string.Empty;

    //    DataSet dsTndr = new DataSet();
    //    int sectionID = Convert.ToInt32(Session["SectionID"]);

    //    if (Session["userProfileID"].ToString().Equals("1"))
    //    {
    //        sqlQuery = "Select COUNT(app_resource_allocation.USER_ID) as JobCnt,APP_SCRTY_USERS.NAME as userShortName from app_resource_allocation INNER JOIN APP_SCRTY_USERS ON app_resource_allocation.USER_ID = APP_SCRTY_USERS.USER_ID where app_resource_allocation.state_id ='OPEN' group by APP_SCRTY_USERS.NAME ";
    //        // lblOngoingStaff.Text = "On Going Tasks Per Staff In All Sections Of EBSD";
    //    }
    //    else
    //    {
    //        // lblOngoingStaff.Text = "On Going Tasks Per Staff In EBSD " + Session["SectionName"].ToString();

    //        sqlQuery = "Select COUNT(app_resource_allocation.USER_ID) as JobCnt,APP_SCRTY_USERS.NAME as userShortName from app_resource_allocation INNER JOIN APP_SCRTY_USERS ON app_resource_allocation.USER_ID = APP_SCRTY_USERS.USER_ID where app_resource_allocation.state_id ='OPEN' group by APP_SCRTY_USERS.NAME ";
    //    }

    //    OracleDataAdapter daTndr = new OracleDataAdapter(sqlQuery, connValueOracle);
    //    daTndr.Fill(dsTndr);
    //    if (dsTndr.Tables[0].Rows.Count != 0)
    //    {
    //        onGoingTasksofSurvey.DataSource = dsTndr.Tables[0].DefaultView;
    //        onGoingTasksofSurvey.Series["Series1"].XValueMember = "userShortName";
    //        onGoingTasksofSurvey.Series["Series1"].YValueMembers = "JobCnt";
    //        dsTndr.Tables.Clear();

    //        onGoingTasksofSurvey.ChartAreas[0].AxisX.MajorGrid.Enabled = false;
    //        onGoingTasksofSurvey.ChartAreas[0].AxisX.MinorGrid.Enabled = false;
    //        onGoingTasksofSurvey.ChartAreas[0].AxisY.MajorGrid.Enabled = false;
    //        onGoingTasksofSurvey.ChartAreas[0].AxisY.MinorGrid.Enabled = false;

    //        onGoingTasksofSurvey.ChartAreas[0].AxisX.LabelStyle.Angle = 30;
    //        onGoingTasksofSurvey.ChartAreas[0].AxisX.LabelStyle.ForeColor = Color.Maroon;

    //        onGoingTasksofSurvey.ChartAreas[0].AxisX.Interval = 1;
    //    }
    //}
    //private void getOnGoingTasksPerStaffChart()   // chart 3
    //{
    //    string sqlQuery = string.Empty; string strStaff = string.Empty;

    //    DataSet dsTndr = new DataSet();
    //    int sectionID = Convert.ToInt32(Session["SectionID"]);

    //    if (Session["userProfileID"].ToString().Equals("1"))
    //    {
    //        sqlQuery = "SELECT COUNT(*) AS JobCnt, Contact.userShortName FROM JobOwner INNER JOIN Contact ON JobOwner.contactID = Contact.contactID WHERE (JobOwner.jobOwnerStatusID = 3) GROUP BY JobOwner.contactID, Contact.userShortName ORDER BY Contact.userShortName";
    //        // lblOngoingStaff.Text = "On Going Tasks Per Staff In All Sections Of EBSD";
    //    }
    //    else if (!userRightsColl.Contains("42") && Session["SectionID"].ToString().Equals("7")) //1 - All Sections
    //    {
    //        sqlQuery = "SELECT COUNT(*) AS JobCnt, Contact.userShortName FROM JobOwner INNER JOIN Contact ON JobOwner.contactID = Contact.contactID WHERE (JobOwner.jobOwnerStatusID = 3) GROUP BY JobOwner.contactID, Contact.userShortName ORDER BY Contact.userShortName";
    //        // lblOngoingStaff.Text = "On Going Tasks Per Staff In All Sections Of EBSD";
    //    }
    //    else
    //    {
    //        // lblOngoingStaff.Text = "On Going Tasks Per Staff In EBSD " + Session["SectionName"].ToString();

    //        sqlQuery = "SELECT COUNT(*) AS JobCnt, Contact.userShortName FROM  JobOwner INNER JOIN  Contact ON JobOwner.contactID = Contact.contactID " +
    //                  " WHERE  (JobOwner.sectionID = " + sectionID + ") AND (JobOwner.jobOwnerStatusID = 3) GROUP BY JobOwner.contactID, Contact.userShortName ORDER BY Contact.userShortName";
    //    }

    //    SqlDataAdapter daTndr = new SqlDataAdapter(sqlQuery, connValue);
    //    daTndr.Fill(dsTndr);
    //    if (dsTndr.Tables[0].Rows.Count != 0)
    //    {
    //        onGoingTasksPerStaffChart.DataSource = dsTndr.Tables[0].DefaultView;
    //        onGoingTasksPerStaffChart.Series["Series1"].XValueMember = "userShortName";
    //        onGoingTasksPerStaffChart.Series["Series1"].YValueMembers = "JobCnt";
    //        dsTndr.Tables.Clear();

    //        onGoingTasksPerStaffChart.ChartAreas[0].AxisX.MajorGrid.Enabled = false;
    //        onGoingTasksPerStaffChart.ChartAreas[0].AxisX.MinorGrid.Enabled = false;
    //        onGoingTasksPerStaffChart.ChartAreas[0].AxisY.MajorGrid.Enabled = false;
    //        onGoingTasksPerStaffChart.ChartAreas[0].AxisY.MinorGrid.Enabled = false;

    //        onGoingTasksPerStaffChart.ChartAreas[0].AxisX.LabelStyle.Angle = 30;
    //        onGoingTasksPerStaffChart.ChartAreas[0].AxisX.LabelStyle.ForeColor = Color.Maroon;

    //        onGoingTasksPerStaffChart.ChartAreas[0].AxisX.Interval = 1;
    //    }
    //}

    //private void getMyDocumentChart()
    //{
    //    DataSet dsDoc = new DataSet();

    //    string sqlQuery = null;

    //    if (Convert.ToInt32(Session["UserID"]) == 1)
    //    {
    //        sqlQuery = "SELECT COUNT(DocumentDistribution.distributeID) AS DocCount, DocumentStatus.docStatusName " +
    //               " FROM DocumentDistribution INNER JOIN  DocumentStatus ON DocumentDistribution.docStatusID = DocumentStatus.docStatusID WHERE (DocumentDistribution.docStatusID not in (4,2)) GROUP BY DocumentStatus.docStatusName";
    //    }
    //    else
    //    {
    //        sqlQuery = "SELECT COUNT(DocumentDistribution.distributeID) AS DocCount, DocumentStatus.docStatusName " +
    //               " FROM DocumentDistribution INNER JOIN  DocumentStatus ON DocumentDistribution.docStatusID = DocumentStatus.docStatusID WHERE (DocumentDistribution.docStatusID not in (4)) AND " +
    //               " (DocumentDistribution.contactID = " + Convert.ToInt32(Session["UserID"]) + ") " +
    //                       " GROUP BY DocumentStatus.docStatusName";
    //    }

    //    SqlDataAdapter daDoc = new SqlDataAdapter(sqlQuery, connValue);
    //    daDoc.Fill(dsDoc);
    //    if (dsDoc.Tables[0].Rows.Count != 0)
    //    {
    //        myDocsChart.DataSource = dsDoc.Tables[0].DefaultView;
    //        myDocsChart.Series["Series1"].XValueMember = "docStatusName";
    //        myDocsChart.Series["Series1"].YValueMembers = "DocCount";

    //        dsDoc.Tables.Clear();

    //        myDocsChart.ChartAreas[0].AxisX.MajorGrid.Enabled = false;
    //        myDocsChart.ChartAreas[0].AxisX.MinorGrid.Enabled = false;
    //        myDocsChart.ChartAreas[0].AxisY.MajorGrid.Enabled = false;
    //        myDocsChart.ChartAreas[0].AxisY.MinorGrid.Enabled = false;

    //        myDocsChart.ChartAreas[0].AxisX.LabelStyle.Angle = 30;
    //        myDocsChart.ChartAreas[0].AxisX.LabelStyle.ForeColor = Color.Maroon;

    //        myDocsChart.ChartAreas[0].AxisX.Interval = 1;
    //    }
    //}
    //private void getOnGoingTasksPerSection_New()
    //{
    //    DataSet dsTndr = new DataSet();

    //    string sqlQuery = null; int secID = Convert.ToInt32(Session["SectionID"]);
    //    string strSeriesName = string.Empty;

    //    sqlQuery = " SELECT  COUNT(Job.jobID) AS JobCnt, Section.sectionName FROM  JobType INNER JOIN  Job ON JobType.jobTypeID = Job.jobTypeID INNER JOIN   Section ON JobType.sectionID = Section.sectionID " +
    //          " WHERE (Job.jobDueDate < GETDATE()-1) AND (Job.jobStatusID IN (3, 8))  GROUP BY Section.sectionName, JobType.sectionID  UNION " +
    //               "SELECT  COUNT(JobOwner.jobOwnerID) AS Expr1, Section.sectionName FROM  JobOwner INNER JOIN  Section ON JobOwner.sectionID = Section.sectionID " +
    //                     " WHERE  (JobOwner.payID IS NOT NULL) AND (JobOwner.actionDueDate < GETDATE()-1) AND (JobOwner.jobOwnerStatusID <> 7) GROUP BY Section.sectionName";
    //    strSeriesName = "sectionName";





    //    // Chart_OverDueJobs

    //    SqlDataAdapter daTndr = new SqlDataAdapter(sqlQuery, connValue);
    //    daTndr.Fill(dsTndr);
    //    if (dsTndr.Tables[0].Rows.Count != 0)
    //    {
    //        onGoingTasksPerSectionChart.DataSource = dsTndr.Tables[0].DefaultView;

    //        onGoingTasksPerSectionChart.Series["Series1"].XValueMember = strSeriesName;
    //        onGoingTasksPerSectionChart.Series["Series1"].YValueMembers = "JobCnt";

    //        dsTndr.Tables.Clear();

    //        onGoingTasksPerSectionChart.ChartAreas[0].AxisX.MajorGrid.Enabled = false;
    //        onGoingTasksPerSectionChart.ChartAreas[0].AxisX.MinorGrid.Enabled = false;
    //        onGoingTasksPerSectionChart.ChartAreas[0].AxisY.MajorGrid.Enabled = false;
    //        onGoingTasksPerSectionChart.ChartAreas[0].AxisY.MinorGrid.Enabled = false;

    //        onGoingTasksPerSectionChart.ChartAreas[0].AxisX.LabelStyle.Angle = 30;
    //        onGoingTasksPerSectionChart.ChartAreas[0].AxisX.LabelStyle.ForeColor = Color.Maroon;

    //        onGoingTasksPerSectionChart.ChartAreas[0].AxisX.Interval = 1;
    //    }

    //}
    //private void getUnReadInchargeData()
    //{
    //    string sqlQuery = string.Empty;

    //    sqlQuery = "SELECT    JobOwner.jobID, JobOwner.jobNo, JobType_1.jobTypeName, [Document].referenceNo, REPLACE(CONVERT(NVARCHAR, JobOwner.staffIssueDate, 106), ' ', '-')  AS DateOfIssue, JobType_1.CategoryID AS jobCatID, JobOwner.sectionID, JobOwner.jobOwnerID, JobOwner.contactID, JobOwner.jobDocRefID, " +
    //               " JobOwner.distributedBy, Contact.firstName + '  ' + Contact.lastName AS IssuedBy, JobOwner.payID FROM   JobOwner INNER JOIN JobType ON JobOwner.JobTypeID = JobType.jobTypeID INNER JOIN  JobType AS JobType_1 ON JobType.CategoryID = JobType_1.jobTypeID INNER JOIN " +
    //            " [Document] ON JobOwner.jobDocRefID = [Document].documentID INNER JOIN  Contact ON JobOwner.distributedBy = Contact.contactID  WHERE  (JobOwner.dateRead IS NULL) AND (JobOwner.contactID = " + 1 + ") ORDER BY JobOwner.JobownerID DESC";

    //    SqlConnection objCon = new SqlConnection(connValue);
    //    SqlCommand objCmd = new SqlCommand(sqlQuery, objCon);
    //    SqlDataAdapter objDA = new SqlDataAdapter(objCmd);

    //    objDA.SelectCommand.CommandText = objCmd.CommandText.ToString();
    //    DataTable dt = new DataTable();
    //    objDA.Fill(dt);

    //    Session["getPayData"] = dt;

    //    if (dt.Rows.Count != 0)
    //        gridTasks.DataSource = dt.DefaultView;
    //    else
    //    {
    //        gridTasks.DataSource = null;
    //        // gridTasks.Visible = false;
    //    }
    //    gridTasks.DataBind();
    //}
    //private void getOnGoingTasksPerSection()
    //{
    //    DataSet dsTndr = new DataSet();

    //    string sqlQuery = null; int secID = Convert.ToInt32(Session["SectionID"]);
    //    string strSeriesName = string.Empty;



    //    sqlQuery = " SELECT  COUNT(Job.jobID) AS JobCnt, Section.sectionName FROM  JobType INNER JOIN  Job ON JobType.jobTypeID = Job.jobTypeID INNER JOIN   Section ON JobType.sectionID = Section.sectionID " +
    //       " WHERE (Job.jobDueDate < GETDATE()-1) AND (Job.jobStatusID IN (3, 8))  GROUP BY Section.sectionName, JobType.sectionID  UNION " +
    //            "SELECT  COUNT(JobOwner.jobOwnerID) AS Expr1, Section.sectionName FROM  JobOwner INNER JOIN  Section ON JobOwner.sectionID = Section.sectionID " +
    //                  " WHERE  (JobOwner.payID IS NOT NULL) AND (JobOwner.actionDueDate < GETDATE()-1) AND (JobOwner.jobOwnerStatusID <> 7) GROUP BY Section.sectionName";
    //    strSeriesName = "sectionName";



    //    SqlDataAdapter daTndr = new SqlDataAdapter(sqlQuery, connValue);
    //    daTndr.Fill(dsTndr);
    //    if (dsTndr.Tables[0].Rows.Count != 0)
    //    {
    //        onGoingTasksPerSectionChart.DataSource = dsTndr.Tables[0].DefaultView;

    //        onGoingTasksPerSectionChart.Series["Series1"].XValueMember = strSeriesName;
    //        onGoingTasksPerSectionChart.Series["Series1"].YValueMembers = "JobCnt";

    //        dsTndr.Tables.Clear();

    //        onGoingTasksPerSectionChart.ChartAreas[0].AxisX.MajorGrid.Enabled = false;
    //        onGoingTasksPerSectionChart.ChartAreas[0].AxisX.MinorGrid.Enabled = false;
    //        onGoingTasksPerSectionChart.ChartAreas[0].AxisY.MajorGrid.Enabled = false;
    //        onGoingTasksPerSectionChart.ChartAreas[0].AxisY.MinorGrid.Enabled = false;

    //        onGoingTasksPerSectionChart.ChartAreas[0].AxisX.LabelStyle.Angle = 30;
    //        onGoingTasksPerSectionChart.ChartAreas[0].AxisX.LabelStyle.ForeColor = Color.Maroon;

    //        onGoingTasksPerSectionChart.ChartAreas[0].AxisX.Interval = 1;
    //    }

    //}
    
    //#endregion



    private void getOnGoingTasksPerSection_New123()
    {
        DataSet dsTndr = new DataSet();

        string sqlQuery = null; int secID = Convert.ToInt32(Session["SectionID"]);
        string strSeriesName = string.Empty;

        if (Session["userProfileID"].ToString().Equals("1"))   // For Admin
        {
            sqlQuery = " SELECT  COUNT(Job.jobID) AS JobCnt, Section.sectionName FROM  JobType INNER JOIN  Job ON JobType.jobTypeID = Job.jobTypeID INNER JOIN   Section ON JobType.sectionID = Section.sectionID " +
               " WHERE (Job.jobDueDate < GETDATE()-1) AND (Job.jobStatusID IN (3, 8))  GROUP BY Section.sectionName, JobType.sectionID  UNION " +
                    "SELECT  COUNT(JobOwner.jobOwnerID) AS Expr1, Section.sectionName FROM  JobOwner INNER JOIN  Section ON JobOwner.sectionID = Section.sectionID " +
                          " WHERE  (JobOwner.payID IS NOT NULL) AND (JobOwner.actionDueDate < GETDATE()-1) AND (JobOwner.jobOwnerStatusID <> 7) GROUP BY Section.sectionName";
            strSeriesName = "sectionName";

            lblOngoingJobs.Text = "Over Due Job Order In All Sections";
        }
        else if (!Session["userProfileID"].ToString().Equals("1") && Session["SectionID"].ToString().Equals("7") && !userRightsColl.Contains("1"))    // User Not Admin but he belongs to all section and he contain user rights no  -1   (  7 for all section )
        {
            sqlQuery = " SELECT  COUNT(Job.jobID) AS JobCnt, Section.sectionName FROM  JobType INNER JOIN  Job ON JobType.jobTypeID = Job.jobTypeID INNER JOIN   Section ON JobType.sectionID = Section.sectionID " +
               " WHERE (Job.jobDueDate < GETDATE()-1) AND (Job.jobStatusID IN (3, 8))  GROUP BY Section.sectionName, JobType.sectionID  UNION " +
                    "SELECT  COUNT(JobOwner.jobOwnerID) AS Expr1, Section.sectionName FROM  JobOwner INNER JOIN  Section ON JobOwner.sectionID = Section.sectionID " +
                          " WHERE  (JobOwner.payID IS NOT NULL) AND (JobOwner.actionDueDate < GETDATE()-1) AND (JobOwner.jobOwnerStatusID <> 7) GROUP BY Section.sectionName";

            strSeriesName = "sectionName";

            lblOngoingJobs.Text = "Over Due Job Order In All Sections";
        }
        else if (Session["SectionID"].ToString().Equals("1"))          // Cost Control Section
        {
            if (Session["UserProfileID"].ToString().Contains("2"))        // Admin Section
            {
                sqlQuery = "SELECT COUNT(Job.jobID) AS JobCnt, JobType_1.jobTypeName FROM JobType AS JobType_1 INNER JOIN JobType ON JobType_1.jobTypeID = JobType.CategoryID INNER JOIN  Job ON JobType.jobTypeID = Job.jobTypeID INNER JOIN " +
                   " Section ON JobType.sectionID = Section.sectionID WHERE (JobType.sectionID = " + secID + ") AND (Job.jobDueDate < GETDATE()-1) AND (Job.jobStatusID IN (3,8)) GROUP BY JobType_1.jobTypeName";

                strSeriesName = "jobTypeName";
                lblOngoingJobs.Text = "Over Due Job Order In Cost Control Section";
            }
            else if (Session["UserProfileID"].ToString().Contains("4"))        // Cost Control Admin 
            {
                sqlQuery = "SELECT COUNT(Job.jobID) AS JobCnt, JobType_1.jobTypeName FROM JobType AS JobType_1 INNER JOIN JobType ON JobType_1.jobTypeID = JobType.CategoryID INNER JOIN  Job ON JobType.jobTypeID = Job.jobTypeID INNER JOIN " +
                " Section ON JobType.sectionID = Section.sectionID WHERE (JobType.sectionID = " + secID + ") AND (Job.jobDueDate < GETDATE()-1) AND (Job.jobStatusID IN (3,8)) GROUP BY JobType_1.jobTypeName";

                strSeriesName = "jobTypeName";
                lblOngoingJobs.Text = "Over Due Job Order In Cost Control Section";
            }
            else if (Session["UserProfileID"].ToString().Contains("9"))        // Document Control Admin 
            {
                sqlQuery = "SELECT COUNT(Job.jobID) AS JobCnt, JobType_1.jobTypeName FROM JobType AS JobType_1 INNER JOIN JobType ON JobType_1.jobTypeID = JobType.CategoryID INNER JOIN  Job ON JobType.jobTypeID = Job.jobTypeID INNER JOIN " +
                " Section ON JobType.sectionID = Section.sectionID WHERE (JobType.sectionID = " + secID + ") AND (Job.jobDueDate < GETDATE()-1) AND (Job.jobStatusID IN (3,8)) GROUP BY JobType_1.jobTypeName";

                strSeriesName = "jobTypeName";
                lblOngoingJobs.Text = "Over Due Job Order In Cost Control Section";
            }
            else                                                            // Cost Control User 
            {
                sqlQuery = "SELECT  COUNT(JobOwner.jobOwnerID) AS JobCnt, JobType_1.jobTypeName FROM   JobType INNER JOIN  JobOwner ON JobType.jobTypeID = JobOwner.JobTypeID INNER JOIN " +
                        " Section ON JobOwner.sectionID = Section.sectionID INNER JOIN  JobType AS JobType_1 ON JobType.CategoryID = JobType_1.jobTypeID  WHERE (JobOwner.jobOwnerStatusID = 3) AND (JobOwner.contactID = " + _currentUserID + ") GROUP BY JobType_1.jobTypeName";
                strSeriesName = "jobTypeName";

                lblOngoingJobs.Text = "My On Going Tasks";
            }
        }
        else if (Session["SectionID"].ToString().Equals("3"))          // Document Control Section
        {
            if (Session["UserProfileID"].ToString().Contains("2"))        // Admin Section
            {
                sqlQuery = "SELECT COUNT(Job.jobID) AS JobCnt, JobType_1.jobTypeName FROM JobType AS JobType_1 INNER JOIN JobType ON JobType_1.jobTypeID = JobType.CategoryID INNER JOIN  Job ON JobType.jobTypeID = Job.jobTypeID INNER JOIN " +
                   " Section ON JobType.sectionID = Section.sectionID WHERE (JobType.sectionID = " + secID + ") AND (Job.jobDueDate < GETDATE()-1) AND (Job.jobStatusID IN (3,8)) GROUP BY JobType_1.jobTypeName";

                strSeriesName = "jobTypeName";
                lblOngoingJobs.Text = "Over Due Job Order In Document Control";
            }
            else if (Session["UserProfileID"].ToString().Contains("9"))        // Document Control Admin 
            {
                sqlQuery = "SELECT    COUNT(JobOwner.jobOwnerID) AS JobCnt, JobType_1.jobTypeName  FROM  JobType INNER JOIN     JobOwner ON JobType.jobTypeID = JobOwner.JobTypeID INNER JOIN   Section ON JobOwner.sectionID = Section.sectionID INNER JOIN " +
                        " JobType AS JobType_1 ON JobType.CategoryID = JobType_1.jobTypeID WHERE (JobOwner.jobOwnerStatusID = 3) AND (JobType.sectionID = 3) GROUP BY JobType_1.jobTypeName";

                strSeriesName = "jobTypeName";
                lblOngoingJobs.Text = "On-going Jobs In Document Control";
            }
            else                                                            // Document Control User 
            {
                sqlQuery = "SELECT  COUNT(JobOwner.jobOwnerID) AS JobCnt, JobType_1.jobTypeName FROM   JobType INNER JOIN  JobOwner ON JobType.jobTypeID = JobOwner.JobTypeID INNER JOIN " +
                        " Section ON JobOwner.sectionID = Section.sectionID INNER JOIN  JobType AS JobType_1 ON JobType.CategoryID = JobType_1.jobTypeID  WHERE (JobOwner.jobOwnerStatusID = 3) AND (JobOwner.contactID = " + _currentUserID + ") GROUP BY JobType_1.jobTypeName";

                strSeriesName = "jobTypeName";
                lblOngoingJobs.Text = "My On Going Tasks";
            }
        }
        else if (Session["SectionID"].ToString().Equals("2"))          // Payment Section
        {
            if (Session["UserProfileID"].ToString().Contains("2"))        // Admin Section
            {
                sqlQuery = "SELECT  COUNT(JobOwner.jobOwnerID) AS JobCnt, JobType.jobTypeName FROM  JobOwner INNER JOIN   JobType ON JobOwner.JobTypeID = JobType.jobTypeID " +
                                 " WHERE (JobOwner.payID IS NOT NULL) AND (JobOwner.actionDueDate < GETDATE()-1) AND (JobOwner.jobOwnerStatusID <> 7) GROUP BY JobType.jobTypeName";

                strSeriesName = "jobTypeName";
                lblOngoingJobs.Text = "Over Due Job Order In Payment Section";
            }
            else if (Session["UserProfileID"].ToString().Contains("4"))        // Payment Admin 
            {
                sqlQuery = "SELECT  COUNT(JobOwner.jobOwnerID) AS JobCnt, JobType.jobTypeName FROM  JobOwner INNER JOIN   JobType ON JobOwner.JobTypeID = JobType.jobTypeID " +
                                 " WHERE (JobOwner.payID IS NOT NULL) AND (JobOwner.actionDueDate < GETDATE()-1) AND (JobOwner.jobOwnerStatusID <> 7) GROUP BY JobType.jobTypeName";

                strSeriesName = "jobTypeName";
                lblOngoingJobs.Text = "Over Due Job Order In Payment Section";
            }
            else                                                            // Payment User 
            {
                sqlQuery = "SELECT  COUNT(JobOwner.jobOwnerID) AS JobCnt, JobType_1.jobTypeName FROM   JobType INNER JOIN  JobOwner ON JobType.jobTypeID = JobOwner.JobTypeID INNER JOIN " +
                        " Section ON JobOwner.sectionID = Section.sectionID INNER JOIN  JobType AS JobType_1 ON JobType.CategoryID = JobType_1.jobTypeID  WHERE (JobOwner.jobOwnerStatusID = 3) AND (JobOwner.contactID = " + _currentUserID + ") GROUP BY JobType_1.jobTypeName";

                strSeriesName = "jobTypeName";
                lblOngoingJobs.Text = "My On Going Tasks";
            }
        }
        else if (Session["SectionID"].ToString().Equals("24"))          // Document Control Section
        {

        }
        else
        {
            sqlQuery = "SELECT  COUNT(JobOwner.jobOwnerID) AS JobCnt, JobType_1.jobTypeName FROM   JobType INNER JOIN  JobOwner ON JobType.jobTypeID = JobOwner.JobTypeID INNER JOIN " +
                       " Section ON JobOwner.sectionID = Section.sectionID INNER JOIN  JobType AS JobType_1 ON JobType.CategoryID = JobType_1.jobTypeID  WHERE (JobOwner.jobOwnerStatusID = 3) AND (JobOwner.contactID = " + _currentUserID + ") GROUP BY JobType_1.jobTypeName";

            strSeriesName = "jobTypeName";
            lblOngoingJobs.Text = "My On Going Tasks";
        }

        // Chart_OverDueJobs

        SqlDataAdapter daTndr = new SqlDataAdapter(sqlQuery, connValue);
        daTndr.Fill(dsTndr);
        if (dsTndr.Tables[0].Rows.Count != 0)
        {
            OverDueJobsChart.DataSource = dsTndr.Tables[0].DefaultView;

            OverDueJobsChart.Series["Series1"].XValueMember = strSeriesName;
            OverDueJobsChart.Series["Series1"].YValueMembers = "JobCnt";

            dsTndr.Tables.Clear();

            OverDueJobsChart.ChartAreas[0].AxisX.MajorGrid.Enabled = false;
            OverDueJobsChart.ChartAreas[0].AxisX.MinorGrid.Enabled = false;
            OverDueJobsChart.ChartAreas[0].AxisY.MajorGrid.Enabled = false;
            OverDueJobsChart.ChartAreas[0].AxisY.MinorGrid.Enabled = false;

            OverDueJobsChart.ChartAreas[0].AxisX.LabelStyle.Angle = 30;
            OverDueJobsChart.ChartAreas[0].AxisX.LabelStyle.ForeColor = Color.Maroon;

            OverDueJobsChart.ChartAreas[0].AxisX.Interval = 1;
        }

    }


    protected void OverDueJobsChart_Click(object sender, ImageMapEventArgs e)
    {

    }
    protected void onGoingTasksPerSectionChart_Load1(object sender, EventArgs e)
    {

    }
    protected void lnkPcc_Click(object sender, EventArgs e)
    {

    }
    protected void lnkPaymentRpt_Click(object sender, EventArgs e)
    {

    }
    protected void lnkPccRpt_Click(object sender, EventArgs e)
    {

    }
    protected void lnkDCrpt_Click(object sender, EventArgs e)
    {

    }


    protected void onGoingTasksofManager_Click(object sender, ImageMapEventArgs e)
    {

    }
    private void getOnGoing_ManagerRequests()
    {
        DataSet dsTndr = new DataSet();

        string sqlQuery = null; int secID = Convert.ToInt32(Session["SectionID"]);
        string strSeriesName = string.Empty;


        secID = 10;

        if ((Session["SectionID"].ToString().Equals("10")) || (Session["UserProfileID"].ToString().Contains("1")))    
        {
            if ((Session["UserProfileID"].ToString().Contains("2"))  || (Session["UserProfileID"].ToString().Contains("1")))     
            {
                //sqlQuery = "SELECT COUNT(Job.jobID) AS JobCnt, JobType_1.jobTypeName FROM JobType AS JobType_1 INNER JOIN JobType ON JobType_1.jobTypeID = JobType.CategoryID INNER JOIN  Job ON JobType.jobTypeID = Job.jobTypeID INNER JOIN " +
                //   " Section ON JobType.sectionID = Section.sectionID WHERE (JobType.sectionID = " + secID + ") AND (Job.jobDueDate < GETDATE()-1) AND (Job.jobStatusID IN (3,8)) GROUP BY JobType_1.jobTypeName";

                sqlQuery = "SELECT   COUNT(Job.jobID) AS JobCnt, JobType.jobTypeName FROM   JobType INNER JOIN  Job ON JobType.jobTypeID = Job.jobTypeID INNER JOIN " + 
                " Section ON JobType.sectionID = Section.sectionID WHERE  (JobType.sectionID = 10) AND (Job.jobStatusID IN (3, 8)) GROUP BY JobType.jobTypeName";

                strSeriesName = "jobTypeName";
                lblmngr.Text = "On-going Manager Requests Details";
            }
            else if (Session["UserProfileID"].ToString().Contains("4"))        // Cost Control Admin 
            {
                sqlQuery = "SELECT COUNT(Job.jobID) AS JobCnt, JobType_1.jobTypeName FROM JobType AS JobType_1 INNER JOIN JobType ON JobType_1.jobTypeID = JobType.CategoryID INNER JOIN  Job ON JobType.jobTypeID = Job.jobTypeID INNER JOIN " +
                " Section ON JobType.sectionID = Section.sectionID WHERE (JobType.sectionID = " + secID + ") AND (Job.jobDueDate < GETDATE()-1) AND (Job.jobStatusID IN (3,8)) GROUP BY JobType_1.jobTypeName";

                strSeriesName = "jobTypeName";
                lblmngr.Text = "Manager Requests Details";
            }
            else if (Session["UserProfileID"].ToString().Contains("9"))        // Document Control Admin 
            {
                sqlQuery = "SELECT COUNT(Job.jobID) AS JobCnt, JobType_1.jobTypeName FROM JobType AS JobType_1 INNER JOIN JobType ON JobType_1.jobTypeID = JobType.CategoryID INNER JOIN  Job ON JobType.jobTypeID = Job.jobTypeID INNER JOIN " +
                " Section ON JobType.sectionID = Section.sectionID WHERE (JobType.sectionID = " + secID + ") AND (Job.jobDueDate < GETDATE()-1) AND (Job.jobStatusID IN (3,8)) GROUP BY JobType_1.jobTypeName";

                strSeriesName = "jobTypeName";
                lblmngr.Text = "Over Due Job Order In Manager Requests";
            }
            else                                                            // Cost Control User 
            {
                sqlQuery = "SELECT  COUNT(JobOwner.jobOwnerID) AS JobCnt, JobType_1.jobTypeName FROM   JobType INNER JOIN  JobOwner ON JobType.jobTypeID = JobOwner.JobTypeID INNER JOIN " +
                        " Section ON JobOwner.sectionID = Section.sectionID INNER JOIN  JobType AS JobType_1 ON JobType.CategoryID = JobType_1.jobTypeID  WHERE (JobOwner.jobOwnerStatusID = 3) AND (JobOwner.contactID = " + _currentUserID + ") GROUP BY JobType_1.jobTypeName";
                strSeriesName = "jobTypeName";

                lblmngr.Text = "My On Going Tasks";
            }
        }
        else                                                            // Cost Control User 
        {
            sqlQuery = "SELECT  COUNT(JobOwner.jobOwnerID) AS JobCnt, JobType_1.jobTypeName FROM   JobType INNER JOIN  JobOwner ON JobType.jobTypeID = JobOwner.JobTypeID INNER JOIN " +
                    " Section ON JobOwner.sectionID = Section.sectionID INNER JOIN  JobType AS JobType_1 ON JobType.CategoryID = JobType_1.jobTypeID  WHERE (JobOwner.jobOwnerStatusID = 3) AND (JobOwner.contactID = " + _currentUserID + ") GROUP BY JobType_1.jobTypeName";
            strSeriesName = "jobTypeName";

            lblmngr.Text = "My On Going Tasks";
        }

        SqlDataAdapter daTndr = new SqlDataAdapter(sqlQuery, connValue);
        daTndr.Fill(dsTndr);
        if (dsTndr.Tables[0].Rows.Count != 0)
        {
            onGoingTasksofManager.DataSource = dsTndr.Tables[0].DefaultView;

            onGoingTasksofManager.Series["Series1"].XValueMember = strSeriesName;
            onGoingTasksofManager.Series["Series1"].YValueMembers = "JobCnt";

            dsTndr.Tables.Clear();

            onGoingTasksofManager.ChartAreas[0].AxisX.MajorGrid.Enabled = false;
            onGoingTasksofManager.ChartAreas[0].AxisX.MinorGrid.Enabled = false;
            onGoingTasksofManager.ChartAreas[0].AxisY.MajorGrid.Enabled = false;
            onGoingTasksofManager.ChartAreas[0].AxisY.MinorGrid.Enabled = false;

            onGoingTasksofManager.ChartAreas[0].AxisX.LabelStyle.Angle = 30;
            onGoingTasksofManager.ChartAreas[0].AxisX.LabelStyle.ForeColor = Color.Maroon;

            onGoingTasksofManager.ChartAreas[0].AxisX.Interval = 1;
        }

    }
    protected void lnkSearchMngr_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/ManagerTask/SerachTask.aspx", false);
    }   
    protected void lnkNewTask_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/ManagerTask/CreateTask.aspx", false);
    }
    protected void lnkSearchProject_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/Guest/ViewProjects.aspx", false);
    }
   
    protected void lnkSRData_Click1(object sender, EventArgs e)
    {
        //Response.Redirect("~/Planning/DefaultSRInfo.aspx", false); //SRDetails.aspx

        Response.Redirect("~/Planning/Search_SRInfo.aspx", false); //SRDetails.aspx
    }
    protected void lnkCEData_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/JobOrder/CostEstimate.aspx", false);
    }
}