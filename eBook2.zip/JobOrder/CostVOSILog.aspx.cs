﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using Datalayer;
using System.Data.SqlClient;

public partial class JobOrder_CostVOSILog : System.Web.UI.Page
{
    int _jobID = 0;
    string connValue = System.Configuration.ConfigurationManager.ConnectionStrings["EBSDEBookConn"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
    {
        _jobID = Convert.ToInt32(Request.QueryString["JobID"]);
        lblJobNo.Text = Request.QueryString["PSAJobNo"];


        Session["JobNo"] = Request.QueryString["PSAJobNo"];
        Session["PrjCode"] = Request.QueryString["PSAprjCode"];

        lblPrjCode.Text = Request.QueryString["PSAprjCode"];



        //if (lblAbmNo.Text != "")
        //    _admno = Convert.ToInt32(lblAbmNo.Text);
        if (!IsPostBack)
        {
            Panel1.Visible = false;
            FillTab2(_jobID);
            getMinistryData(_jobID);
        }
    }
    public void getMinistryData(int jobID)
    {
        string qry = " SELECT ministryCode,budgetRefNo,provisionNo From Job where JobID =  " + jobID;
        using (SqlConnection cn = new SqlConnection(connValue))
        {
            using (SqlCommand cmd = new SqlCommand())
            {

                cmd.Connection = cn;
                cmd.CommandText = qry;
                cmd.CommandType = CommandType.Text;

                cn.Open();

                using (SqlDataReader dr = cmd.ExecuteReader())
                {
                    while (dr.Read())
                    {
                        txtMinCode.Text = dr["ministryCode"].ToString();
                        txtBudgetRef.Text = dr["budgetRefNo"].ToString();
                        txtProvNo.Text = dr["provisionNo"].ToString();
                    }
                }
            }
        }
    }
    protected void btnSave_Click(object sender, EventArgs e)
    {
        int _voID = 0;

        if (lblVOSIID.Text != "")
            _voID = Convert.ToInt32(lblVOSIID.Text);
        else
            _voID = 0;

        int voCatID = 0; int voTimeCatID = 0;        
        Boolean chkVOActive = true;

  //      new JobOrderData().AddUpade_JOBVOandSI(_voID, _jobID, txtContractAmnt.Text, "", txtPmcAmnt.Text, "", txtEbsdAmnt.Text, "", txtCnsltAmnt.Text, "", "", "", "", "", txtRemarks.Text, Session["UserName"].ToString(), txtBudgetAmnt.Text, voCatID, chkVOActive, voTimeCatID,"");        
        
        ClearData();
        FillTab2(_jobID);

        Panel1.Visible = false;
    }

    private void ClearData()
    {
        txtPmcAmnt.Text = "";
        txtContractAmnt.Text = "";
        txtEbsdAmnt.Text = "";
        txtBudgetAmnt.Text = "";
      
        txtRemarks.Text = "";
        lblVOSIID.Text = "";
    }
    private void FillTab2(int _jobID)
    {
        try
        {
            DataSet ds = new DataSet();
            ds = (new JobOrderData().GetDDlDetails_JOBVOSI(_jobID));

            //   Convert.ToInt32(txtjobid.Text), txtJobNo.Text, Convert.ToInt32(txtaffair.Text), Convert.ToInt32(txtdept.Text), txtprojcode.Text, txtprojtitle.Text, Convert.ToInt32(txtconsult.Text)));

            if (ds.Tables[0].Rows.Count == 0)
            {
                ds.Tables[0].Rows.Add(ds.Tables[0].NewRow());
            }

            grvPSALog.DataSource = ds;
            grvPSALog.DataBind();
        }
        catch (Exception ex)
        {

        }
    }
    private void getVOData(int _void)
    {
        string qry = " SELECT jobVOID, jobID, contractorAmt, contractorEOT, pmcAmt, pmcEOT, consultantAmt, consultantEOT, ebsdAmt, ebsdEOT, invSH,voNumber,siNumber,REPLACE(CONVERT(NVARCHAR, issueDate, 106), ' ', '-') as issueDate, " +
        " budgetAmnt, REPLACE(CONVERT(NVARCHAR, prjCompleteDate, 106), ' ', '-') as prjCompleteDate,  " +
                     " remarks FROM JobVOSI WHERE (jobVOID = " + _void + ") ";
        using (SqlConnection cn = new SqlConnection(connValue))
        {
            using (SqlCommand cmd = new SqlCommand())
            {

                cmd.Connection = cn;
                cmd.CommandText = qry;
                cmd.CommandType = CommandType.Text;

                cn.Open();

                using (SqlDataReader dr = cmd.ExecuteReader())
                {
                    while (dr.Read())
                    {
                        txtPmcAmnt.Text = dr["pmcAmt"].ToString();
                        txtContractAmnt.Text = dr["contractorAmt"].ToString();
                        txtEbsdAmnt.Text = dr["ebsdAmt"].ToString();
                        txtBudgetAmnt.Text = dr["budgetAmnt"].ToString();
                        
                        txtRemarks.Text = dr["remarks"].ToString();

                        lblVOSIID.Text = dr["jobVOID"].ToString();
                        

                    }
                }
            }
        }
    }
    protected void btnAdd_Click(object sender, EventArgs e)
    {
        Panel1.Visible = true;
        ClearData();
    }
    protected void LinkButton_Click(Object sender, EventArgs e)
    {
        if (lblVOSIID.Text != "")
        {
            LinkButton txtBox = (sender as LinkButton);
            Session["txtName"] = txtBox.ClientID;
            Session["JobAdmID"] = lblVOSIID.Text;

            string url = "StakeHolder.aspx?jobVOID = <%#Eval(jobVOID)%>";  //subject=<%#Eval("Address") %>"
            string s = "window.open('" + url + "', 'popup_window', 'width=600,height=600,left=100,top=100,resizable=yes');";
            ClientScript.RegisterStartupScript(this.GetType(), "script", s, true);
        }
    }
    protected void grvPSALog_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "ViewEdit")
        {
            string arguments = e.CommandArgument.ToString();
            string[] args = arguments.Split(';');
            if (args[0] != "")
            {
                int _void = Convert.ToInt32(args[0]);
                getVOData(_void);
                Panel1.Visible = true;
            }
        }      
    }
    protected void grvPSALog_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        GridViewRow gr = (GridViewRow)grvPSALog.Rows[e.RowIndex];
        Label txtid = (Label)gr.FindControl("lbljobVOID");
        if (txtid.Text != "")
        {
            new JobOrderData().Delete_PSALog(Convert.ToInt32(txtid.Text));
            FillTab2(_jobID);
        }
    }
    protected void grvPSALog_RowEditing(object sender, GridViewEditEventArgs e)
    {
        grvPSALog.EditIndex = e.NewEditIndex;
        FillTab2(_jobID);
    }
    protected void grvPSALog_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        double _pmcAmt = 0; double _ebsdAmt = 0; double _consultAmt = 0; double _budgetAmt = 0; 
        int _pmcTime = 0; int _ebsdTime = 0; int _consultTime = 0;
        int _cntrAdmNo = 0; string _remarks = string.Empty;

        GridViewRow gr = (GridViewRow)grvPSALog.Rows[e.RowIndex];

        Label cntrAdmNo = (Label)gr.FindControl("lblCnsltAmt");
        if (cntrAdmNo.Text != "")
            txtPmcAmnt.Text = cntrAdmNo.Text;

        TextBox pmcAmt = (TextBox)gr.FindControl("txtPmcAmt");
        if (pmcAmt.Text != "")
            _pmcAmt = Convert.ToDouble(pmcAmt.Text);

        TextBox pmcTime = (TextBox)gr.FindControl("txtPmcEOT");
        if (pmcTime.Text != "")
            _pmcTime = Convert.ToInt32(pmcTime.Text);

        TextBox ebsdAmt = (TextBox)gr.FindControl("txtEbsdAmt");
        if (ebsdAmt.Text != "")
            _ebsdAmt = Convert.ToDouble(ebsdAmt.Text);

        TextBox ebsdTime = (TextBox)gr.FindControl("txtEbsdEOT");
        if (ebsdTime.Text != "")
            _ebsdTime = Convert.ToInt32(ebsdTime.Text);

        TextBox consultAmt = (TextBox)gr.FindControl("txtConsultAmt");
        if (consultAmt.Text != "")
            _consultAmt = Convert.ToDouble(consultAmt.Text);

        TextBox consultTime = (TextBox)gr.FindControl("txtConsultEOT");
        if (consultTime.Text != "")
            _consultTime = Convert.ToInt32(consultTime.Text);

        TextBox remarks = (TextBox)gr.FindControl("txtRemarks");
        if (remarks.Text != "")
            _remarks = remarks.Text;

        Label id = (Label)gr.FindControl("JobVOID");
        int _admno = 0;

        Label budgetAmt = (Label)gr.FindControl("lblBudgetAmt");
        if (budgetAmt.Text != "")
            _budgetAmt = Convert.ToDouble(budgetAmt.Text);

        new JobOrderData().update_PSALog(Convert.ToInt32(id.Text), _pmcAmt, _pmcTime, _ebsdAmt, _ebsdTime, _consultAmt, _consultTime, _admno, _remarks);

        grvPSALog.EditIndex = -1;
        FillTab2(_jobID);
    }

    
    protected void txtMinCode_TextChanged(object sender, EventArgs e)
    {
       new JobOrderData().UpdateMinistryDataForJob(0, txtMinCode.Text, txtBudgetRef.Text, txtProvNo.Text, lblPrjCode.Text);
    }
    protected void txtBudgetRef_TextChanged(object sender, EventArgs e)
    {
        new JobOrderData().UpdateMinistryDataForJob(0, txtMinCode.Text, txtBudgetRef.Text, txtProvNo.Text, lblPrjCode.Text);
    }
    protected void txtProvNo_TextChanged(object sender, EventArgs e)
    {
        new JobOrderData().UpdateMinistryDataForJob(0, txtMinCode.Text, txtBudgetRef.Text, txtProvNo.Text, lblPrjCode.Text);
    }
    protected void txtBudgetAmnt_TextChanged(object sender, EventArgs e)
    {

    }
    protected void txtEbsdAmnt_TextChanged(object sender, EventArgs e)
    {

    }
    protected void txtPmcAmnt_TextChanged(object sender, EventArgs e)
    {

    }
    protected void txtCnsltAmnt_TextChanged(object sender, EventArgs e)
    {

    }
    protected void txtContractAmnt_TextChanged(object sender, EventArgs e)
    {

    }
}