﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Datalayer;
using System.Data;
using System.Data.SqlClient;
using System.Globalization;



public partial class JobOrder_RestrictedAccessWindow : System.Web.UI.Page
{
    string connValue = System.Configuration.ConfigurationManager.ConnectionStrings["EBSDEBookConn"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
    {
       
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
       // new JobOrderData().UpdateDocumentStatusForActionDate(Convert.ToInt32(Session["statusdocID"].ToString()), 4, Convert.ToInt32(Session["contactID"].ToString()));

        new JobOrderData().UpdateDocumentStatusForInchargeStatusCompleted(4, Convert.ToInt32(Session["_InchargeID"]));        

        //new JobOrderData().UpdateJobStatus(Convert.ToInt32(Session["_InchargeID"]), Convert.ToInt32(Session["StatusValCurrent"].ToString()));

        Session["contactID"] = null; Session["statusdocID"] = null; Session["_InchargeID"] = null;
      

        string script = "this.window.opener.location=this.window.opener.location;this.window.close();";
        if (!ClientScript.IsClientScriptBlockRegistered("REFRESH_PARENT"))
            ClientScript.RegisterClientScriptBlock(typeof(string), "REFRESH_PARENT", script, true);
    }
    protected void btnNo_Click(object sender, EventArgs e)
    {
       // new JobOrderData().UpdateJobStatus(Convert.ToInt32(Session["_InchargeID"]), Convert.ToInt32(Session["StatusValCurrent"]));

        Session["StatusValCurrent"] = null; Session["_InchargeID"] = null;
        string script = "this.window.opener.location=this.window.opener.location;this.window.close();";
        if (!ClientScript.IsClientScriptBlockRegistered("REFRESH_PARENT"))
            ClientScript.RegisterClientScriptBlock(typeof(string), "REFRESH_PARENT", script, true);
    }  

}