﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using Datalayer;

public partial class JobOrder_StakeHolder : System.Web.UI.Page
{
    string connValue = System.Configuration.ConfigurationManager.ConnectionStrings["EBSDEBookConn"].ConnectionString;
    int _jobID = 0;
    UtilityClass uCls = null;
    int _voID = 0;
    protected void Page_Load(object sender, EventArgs e)
    {
        lbljobNo.Text = Session["JobNo"].ToString();
        lblProjectCode.Text = Session["PrjCode"].ToString();
    }
    protected override void OnInit(EventArgs e)
    {
       // _jobID = Convert.ToInt32(Session["Upd_jobID"]);
       // _voID = Convert.ToInt32(Session["jobVOID"]);

        if (Session["JobAdmID"] == null)
            return;

        _voID = Convert.ToInt32(Session["JobAdmID"]);
        //_jobID = Convert.ToInt32(Request.QueryString["jobID"]);
        _jobID = Convert.ToInt32(Session["StakjobID"]);

        if (!IsPostBack)
        {
            PopulateDropDownBox(DropDownList1, "SELECT stakeID, stakeHolderName FROM StakeHolder; ", "stakeID", "stakeHolderName");
            gridload();
        }
    }
    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {
         if (DropDownList1.SelectedIndex != 0)
               new JobOrderData().Add_ddlStakeInfo_StakeHolder(1, _voID, Convert.ToInt32(DropDownList1.SelectedValue), _jobID,Session["UserName"].ToString());

         DropDownList1.SelectedIndex = 0;

        gridload();

       
    }
    private void InsertStakeHolderData(string StakeHolder)
    {
        SqlConnection con = new SqlConnection(connValue);
        SqlCommand sqlCmd = new SqlCommand();
        sqlCmd.CommandType = CommandType.Text;
        sqlCmd.Connection = con;

        sqlCmd.CommandText = "Insert into StakeHolder(stakeHolderName,createuser,createDate) VALUES (@stakeHolder,@createuser,@createDate) ";

        sqlCmd.Parameters.AddWithValue("@stakeHolder", StakeHolder);
        sqlCmd.Parameters.AddWithValue("@createuser", Session["UserName"].ToString());
        sqlCmd.Parameters.AddWithValue("@createDate", System.DateTime.Now.ToString("dd/MMM/yyyy"));
             //docIssuedDate

        //sqlCmd.Parameters.AddWithValue("@docIssuedDate", System.DateTime.Now.ToString("dd/MMM/yyyy"));
        //sqlCmd.Parameters.AddWithValue("@docIssueDate", DateTime.ParseExact(DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss"), "dd/MM/yyyy HH:mm:ss", CultureInfo.InvariantCulture));            

        try
        {
            con.Open();
            sqlCmd.ExecuteNonQuery();
        }
        catch (System.Exception ex)
        {
            throw ex;
        }
        finally
        {
            con.Close();
        }
    }
    public void gridload()
    {
        DataSet ds = new DataSet();
        ds = (new JobOrderData().GetDDlDetails_StakeHolder(_voID));
        GridView1.DataSource = ds;
        GridView1.DataBind();
    }
    private void PopulateDropDownBox(DropDownList ddlBox, string sqlQuery, string valueMember, string displayName)
    {
        DataTable table = new DataTable();
        try
        {
            using (SqlConnection sqlConn = new SqlConnection(connValue))
            {
                using (SqlDataAdapter da = new SqlDataAdapter(sqlQuery, sqlConn))
                {
                    sqlConn.Open();
                    da.Fill(table);
                }
            }
            //cmbBox.Items.Add("Select");
            ddlBox.DataSource = table;

            ddlBox.DataTextField = displayName;
            ddlBox.DataValueField = valueMember;

            //ddlBox.SelectedIndex = -1;

            ddlBox.DataBind();
            ddlBox.Items.Insert(0, new ListItem("--Select--"));
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "delete")
        {
            string arguments = e.CommandArgument.ToString();
            string[] args = arguments.Split(';');

            string detID = args[0];
            //string jobid = args[1];
            //jobid = "1";

            new JobOrderData().Delete_ddlStakeInfo_StakeHolder(Convert.ToInt32(detID));
        }
    }
    protected void GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        gridload();
    }
protected void  btnAdd_Click(object sender, EventArgs e)
{
    if(txtStakeHolder.Text !="")
    {
    InsertStakeHolderData(txtStakeHolder.Text);
    PopulateDropDownBox(DropDownList1, "SELECT stakeID, stakeHolderName FROM StakeHolder; ", "stakeID", "stakeHolderName");
    txtStakeHolder.Text = "";
    }
}
}