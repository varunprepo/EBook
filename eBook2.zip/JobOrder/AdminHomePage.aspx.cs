﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.DataVisualization.Charting;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using Datalayer;

using Oracle.ManagedDataAccess.Client;
using System.Data.SqlClient;
using System.Data;
using System.Drawing;

public partial class JobOrder_AdminHomePage : System.Web.UI.Page
{
    string connValue = System.Configuration.ConfigurationManager.ConnectionStrings["EBSDEBookConn"].ConnectionString;
    string connValueOracle = System.Configuration.ConfigurationManager.ConnectionStrings["SurveyConnOracle"].ToString();


    IList<string> userRightsColl = null;
    string profile_Name = string.Empty;
    UtilityClass uCls = null;

    static int _currentUserID = 0; 
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["UserName"] == null)
        {
            Response.Redirect("~/LoginPage.aspx", false);
            return;
        }     

        _currentUserID = Convert.ToInt32(Session["UserID"]);
        userRightsColl = (IList<string>)Session["UserRightsColl"];

        if (!IsPostBack)
        {
            PageloadData();   

            string sqlQueryYear = "SELECT COUNT(Job.jobID) AS jobCnt, YEAR(Job.jobReceivedDate) AS Year FROM   JobVOSI INNER JOIN    Job ON JobVOSI.jobID = Job.jobID INNER JOIN " +
                           " JobType ON Job.jobTypeID = JobType.jobTypeID WHERE  (JobType.CategoryID IN (4)) GROUP BY YEAR(Job.jobReceivedDate)";
            PopulateDropDownBox(ddlYear, sqlQueryYear, "Year", "Year");

            string sqlQueryDept = "SELECT COUNT(Job.jobID) AS jobCnt, Job.deptID, Department.deptName FROM     JobVOSI INNER JOIN    Job ON JobVOSI.jobID = Job.jobID INNER JOIN " +
                         " JobType ON Job.jobTypeID = JobType.jobTypeID INNER JOIN Department ON Job.deptID = Department.departmentID  WHERE  (JobType.CategoryID IN (4)) GROUP BY Job.deptID, Department.deptName ORDER BY Department.deptName";

            PopulateDropDownBox(ddlDept, sqlQueryDept, "deptID", "deptName");

            string strAffair = "SELECT COUNT(Job.jobID) AS jobCnt, Department_1.deptName AS AffairName, Department_1.departmentID AS AffairID FROM  JobVOSI INNER JOIN  Job ON JobVOSI.jobID = Job.jobID INNER JOIN " +
                   " JobType ON Job.jobTypeID = JobType.jobTypeID INNER JOIN   Department ON Job.deptID = Department.departmentID INNER JOIN   Department AS Department_1 ON Department.affairID = Department_1.departmentID " +
                    " WHERE   (JobType.CategoryID IN (4)) GROUP BY Department_1.deptName, Department_1.departmentID ORDER BY AffairName";

            PopulateDropDownBox(ddlAffair, strAffair, "AffairID", "AffairName");

            string strMinistry = "SELECT Job.ministryCode FROM  JobVOSI INNER JOIN   Job ON JobVOSI.jobID = Job.jobID INNER JOIN JobType ON Job.jobTypeID = JobType.jobTypeID WHERE  (JobType.CategoryID IN (4))  GROUP BY Job.ministryCode HAVING   (Job.ministryCode IS NOT NULL)";
            PopulateDropDownBox(ddlMinistry, strMinistry, "ministryCode", "ministryCode");

            string strBudRef = "SELECT Job.budgetRefNo  FROM  JobVOSI INNER JOIN   Job ON JobVOSI.jobID = Job.jobID INNER JOIN JobType ON Job.jobTypeID = JobType.jobTypeID WHERE  (JobType.CategoryID IN (4))  GROUP BY Job.budgetRefNo  HAVING   (Job.budgetRefNo  IS NOT NULL)";
            PopulateDropDownBox(ddlBudget, strBudRef, "budgetRefNo", "budgetRefNo");

            string strProvision = "SELECT Job.provisionNo  FROM  JobVOSI INNER JOIN   Job ON JobVOSI.jobID = Job.jobID INNER JOIN JobType ON Job.jobTypeID = JobType.jobTypeID WHERE  (JobType.CategoryID IN (4))  GROUP BY Job.provisionNo  HAVING   (Job.provisionNo  IS NOT NULL)";
            PopulateDropDownBox(ddlProv, strProvision, "provisionNo", "provisionNo");

            gCostEstimateChart();
            CostEstimateReport();
            gCostEstimateJobCountChart();

            fillCostEstimateDataForJobCntChart();

            TextBox1.Text = fillCostEstimateAboveBudget().Rows[0][0].ToString();
            TextBox2.Text = fillCostEstimateBelowBudget().Rows[0][0].ToString();
        }
    }
    private DataTable CostEstimateReport123()
    {
        //JobVOSI.contractorAmt,(JobVOSI.ebsdAmt + JobVOSI.contractorAmt)

        System.Threading.Thread.CurrentThread.CurrentCulture = new System.Globalization.CultureInfo("ar-QA");

        //string sqlQuery = "SELECT Job.contractNo, Job.projectTitle, JobVOSI.budgetAmnt, JobVOSI.pmcAmt, JobVOSI.ebsdAmt , JobVOSI.contractorAmt, (JobVOSI.contractorAmt-JobVOSI.ebsdAmt)/JobVOSI.contractorAmt as EBSD_ratio, " +
        //            "(JobVOSI.contractorAmt-JobVOSI.budgetAmnt)/JobVOSI.contractorAmt as Budget_ratio" + 
        //            " FROM JobVOSI INNER JOIN Job ON JobVOSI.jobID = Job.jobID INNER JOIN  JobType ON Job.jobTypeID = JobType.jobTypeID WHERE (JobType.CategoryID IN (4, 7))";

        DataTable dt = new DataTable();
        using (SqlConnection objCon = new SqlConnection(connValue))
        {
            using (SqlCommand objCmd = new SqlCommand())
            {
                objCmd.CommandType = CommandType.StoredProcedure;
                objCmd.Connection = objCon;
                objCmd.CommandText = "CostEstimateReport";

                SqlDataAdapter objDA = new SqlDataAdapter(objCmd);

                objDA.SelectCommand.CommandText = objCmd.CommandText.ToString();

                objDA.Fill(dt);

                gvCostEstimate.DataSource = dt;
                gvCostEstimate.DataBind();


            }
        }

        return dt;
    }
    private void getOnGoingTasksPerSection_New()
    {
        DataSet dsTndr = new DataSet();

        string sqlQuery = null; int secID = Convert.ToInt32(Session["SectionID"]);
        string strSeriesName = string.Empty;

        if (Session["userProfileID"].ToString().Equals("1"))   // For Admin
        {
            sqlQuery = " SELECT  COUNT(Job.jobID) AS JobCnt, Section.sectionName FROM  JobType INNER JOIN  Job ON JobType.jobTypeID = Job.jobTypeID INNER JOIN   Section ON JobType.sectionID = Section.sectionID " +
               " WHERE (Job.jobDueDate < GETDATE()-1) AND (Job.jobStatusID IN (3, 8))  GROUP BY Section.sectionName, JobType.sectionID  UNION " +
                    "SELECT  COUNT(JobOwner.jobOwnerID) AS Expr1, Section.sectionName FROM  JobOwner INNER JOIN  Section ON JobOwner.sectionID = Section.sectionID " +
                          " WHERE  (JobOwner.payID IS NOT NULL) AND (JobOwner.actionDueDate < GETDATE()-1) AND (JobOwner.jobOwnerStatusID <> 7) GROUP BY Section.sectionName";
            strSeriesName = "sectionName";

            lblOngoingJobs.Text = "Over Due Job Order In All Sections";
        }
        else if (!Session["userProfileID"].ToString().Equals("1") && Session["SectionID"].ToString().Equals("7") && !userRightsColl.Contains("1"))    // User Not Admin but he belongs to all section and he contain user rights no  -1   (  7 for all section )
        {
            sqlQuery = " SELECT  COUNT(Job.jobID) AS JobCnt, Section.sectionName FROM  JobType INNER JOIN  Job ON JobType.jobTypeID = Job.jobTypeID INNER JOIN   Section ON JobType.sectionID = Section.sectionID " +
               " WHERE (Job.jobDueDate < GETDATE()-1) AND (Job.jobStatusID IN (3, 8))  GROUP BY Section.sectionName, JobType.sectionID  UNION " +
                    "SELECT  COUNT(JobOwner.jobOwnerID) AS Expr1, Section.sectionName FROM  JobOwner INNER JOIN  Section ON JobOwner.sectionID = Section.sectionID " +
                          " WHERE  (JobOwner.payID IS NOT NULL) AND (JobOwner.actionDueDate < GETDATE()-1) AND (JobOwner.jobOwnerStatusID <> 7) GROUP BY Section.sectionName";

            strSeriesName = "sectionName";

            lblOngoingJobs.Text = "Over Due Job Order In All Sections";
        }
        else if (Session["SectionID"].ToString().Equals("1"))          // Cost Control Section
        {
            if (Session["UserProfileID"].ToString().Contains("2"))        // Admin Section
            {
                sqlQuery = "SELECT COUNT(Job.jobID) AS JobCnt, JobType_1.jobTypeName FROM JobType AS JobType_1 INNER JOIN JobType ON JobType_1.jobTypeID = JobType.CategoryID INNER JOIN  Job ON JobType.jobTypeID = Job.jobTypeID INNER JOIN " +
                   " Section ON JobType.sectionID = Section.sectionID WHERE (JobType.sectionID = " + secID + ") AND (Job.jobDueDate < GETDATE()-1) AND (Job.jobStatusID IN (3,8)) GROUP BY JobType_1.jobTypeName";

                strSeriesName = "jobTypeName";
                lblOngoingJobs.Text = "Over Due Job Order In Cost Control Section";
            }
            else if (Session["UserProfileID"].ToString().Contains("4"))        // Cost Control Admin 
            {
                sqlQuery = "SELECT COUNT(Job.jobID) AS JobCnt, JobType_1.jobTypeName FROM JobType AS JobType_1 INNER JOIN JobType ON JobType_1.jobTypeID = JobType.CategoryID INNER JOIN  Job ON JobType.jobTypeID = Job.jobTypeID INNER JOIN " +
                " Section ON JobType.sectionID = Section.sectionID WHERE (JobType.sectionID = " + secID + ") AND (Job.jobDueDate < GETDATE()-1) AND (Job.jobStatusID IN (3,8)) GROUP BY JobType_1.jobTypeName";

                strSeriesName = "jobTypeName";
                lblOngoingJobs.Text = "Over Due Job Order In Cost Control Section";
            }
            else if (Session["UserProfileID"].ToString().Contains("9"))        // Document Control Admin 
            {
                sqlQuery = "SELECT COUNT(Job.jobID) AS JobCnt, JobType_1.jobTypeName FROM JobType AS JobType_1 INNER JOIN JobType ON JobType_1.jobTypeID = JobType.CategoryID INNER JOIN  Job ON JobType.jobTypeID = Job.jobTypeID INNER JOIN " +
                " Section ON JobType.sectionID = Section.sectionID WHERE (JobType.sectionID = " + secID + ") AND (Job.jobDueDate < GETDATE()-1) AND (Job.jobStatusID IN (3,8)) GROUP BY JobType_1.jobTypeName";

                strSeriesName = "jobTypeName";
                lblOngoingJobs.Text = "Over Due Job Order In Cost Control Section";
            }
            else                                                            // Cost Control User 
            {
                sqlQuery = "SELECT  COUNT(JobOwner.jobOwnerID) AS JobCnt, JobType_1.jobTypeName FROM   JobType INNER JOIN  JobOwner ON JobType.jobTypeID = JobOwner.JobTypeID INNER JOIN " +
                        " Section ON JobOwner.sectionID = Section.sectionID INNER JOIN  JobType AS JobType_1 ON JobType.CategoryID = JobType_1.jobTypeID  WHERE (JobOwner.jobOwnerStatusID = 3) AND (JobOwner.contactID = " + _currentUserID + ") GROUP BY JobType_1.jobTypeName";
                strSeriesName = "jobTypeName";

                lblOngoingJobs.Text = "My On Going Tasks";
            }
        }
        else if (Session["SectionID"].ToString().Equals("3"))          // Document Control Section
        {
            if (Session["UserProfileID"].ToString().Contains("2"))        // Admin Section
            {
                sqlQuery = "SELECT COUNT(Job.jobID) AS JobCnt, JobType_1.jobTypeName FROM JobType AS JobType_1 INNER JOIN JobType ON JobType_1.jobTypeID = JobType.CategoryID INNER JOIN  Job ON JobType.jobTypeID = Job.jobTypeID INNER JOIN " +
                   " Section ON JobType.sectionID = Section.sectionID WHERE (JobType.sectionID = " + secID + ") AND (Job.jobDueDate < GETDATE()-1) AND (Job.jobStatusID IN (3,8)) GROUP BY JobType_1.jobTypeName";

                strSeriesName = "jobTypeName";
                lblOngoingJobs.Text = "Over Due Job Order In Document Control";
            }
            else if (Session["UserProfileID"].ToString().Contains("9"))        // Document Control Admin 
            {
                sqlQuery = "SELECT    COUNT(JobOwner.jobOwnerID) AS JobCnt, JobType_1.jobTypeName  FROM  JobType INNER JOIN     JobOwner ON JobType.jobTypeID = JobOwner.JobTypeID INNER JOIN   Section ON JobOwner.sectionID = Section.sectionID INNER JOIN " +
                        " JobType AS JobType_1 ON JobType.CategoryID = JobType_1.jobTypeID WHERE (JobOwner.jobOwnerStatusID = 3) AND (JobType.sectionID = 3) GROUP BY JobType_1.jobTypeName";

                strSeriesName = "jobTypeName";
                lblOngoingJobs.Text = "On-going Jobs In Document Control";
            }
            else                                                            // Document Control User 
            {
                sqlQuery = "SELECT  COUNT(JobOwner.jobOwnerID) AS JobCnt, JobType_1.jobTypeName FROM   JobType INNER JOIN  JobOwner ON JobType.jobTypeID = JobOwner.JobTypeID INNER JOIN " +
                        " Section ON JobOwner.sectionID = Section.sectionID INNER JOIN  JobType AS JobType_1 ON JobType.CategoryID = JobType_1.jobTypeID  WHERE (JobOwner.jobOwnerStatusID = 3) AND (JobOwner.contactID = " + _currentUserID + ") GROUP BY JobType_1.jobTypeName";

                strSeriesName = "jobTypeName";
                lblOngoingJobs.Text = "My On Going Tasks";
            }
        }
        else if (Session["SectionID"].ToString().Equals("2"))          // Payment Section
        {
            if (Session["UserProfileID"].ToString().Contains("2"))        // Admin Section
            {
                sqlQuery = "SELECT  COUNT(JobOwner.jobOwnerID) AS JobCnt, JobType.jobTypeName FROM  JobOwner INNER JOIN   JobType ON JobOwner.JobTypeID = JobType.jobTypeID " +
                                 " WHERE (JobOwner.payID IS NOT NULL) AND (JobOwner.actionDueDate < GETDATE()-1) AND (JobOwner.jobOwnerStatusID <> 7) GROUP BY JobType.jobTypeName";

                strSeriesName = "jobTypeName";
                lblOngoingJobs.Text = "Over Due Job Order In Payment Section";
            }
            else if (Session["UserProfileID"].ToString().Contains("4"))        // Payment Admin 
            {
                sqlQuery = "SELECT  COUNT(JobOwner.jobOwnerID) AS JobCnt, JobType.jobTypeName FROM  JobOwner INNER JOIN   JobType ON JobOwner.JobTypeID = JobType.jobTypeID " +
                                 " WHERE (JobOwner.payID IS NOT NULL) AND (JobOwner.actionDueDate < GETDATE()-1) AND (JobOwner.jobOwnerStatusID <> 7) GROUP BY JobType.jobTypeName";

                strSeriesName = "jobTypeName";
                lblOngoingJobs.Text = "Over Due Job Order In Payment Section";
            }
            else                                                            // Payment User 
            {
                sqlQuery = "SELECT  COUNT(JobOwner.jobOwnerID) AS JobCnt, JobType_1.jobTypeName FROM   JobType INNER JOIN  JobOwner ON JobType.jobTypeID = JobOwner.JobTypeID INNER JOIN " +
                        " Section ON JobOwner.sectionID = Section.sectionID INNER JOIN  JobType AS JobType_1 ON JobType.CategoryID = JobType_1.jobTypeID  WHERE (JobOwner.jobOwnerStatusID = 3) AND (JobOwner.contactID = " + _currentUserID + ") GROUP BY JobType_1.jobTypeName";

                strSeriesName = "jobTypeName";
                lblOngoingJobs.Text = "My On Going Tasks";
            }
        }
        else if (Session["SectionID"].ToString().Equals("24"))          // Document Control Section
        {

        }
        else
        {
            sqlQuery = "SELECT  COUNT(JobOwner.jobOwnerID) AS JobCnt, JobType_1.jobTypeName FROM   JobType INNER JOIN  JobOwner ON JobType.jobTypeID = JobOwner.JobTypeID INNER JOIN " +
                       " Section ON JobOwner.sectionID = Section.sectionID INNER JOIN  JobType AS JobType_1 ON JobType.CategoryID = JobType_1.jobTypeID  WHERE (JobOwner.jobOwnerStatusID = 3) AND (JobOwner.contactID = " + _currentUserID + ") GROUP BY JobType_1.jobTypeName";

            strSeriesName = "jobTypeName";
            lblOngoingJobs.Text = "My On Going Tasks";
        }

        // Chart_OverDueJobs

        SqlDataAdapter daTndr = new SqlDataAdapter(sqlQuery, connValue);
        daTndr.Fill(dsTndr);
        if (dsTndr.Tables[0].Rows.Count != 0)
        {
            onGoingTasksPerSectionChart.DataSource = dsTndr.Tables[0].DefaultView;

            onGoingTasksPerSectionChart.Series["Series1"].XValueMember = strSeriesName;
            onGoingTasksPerSectionChart.Series["Series1"].YValueMembers = "JobCnt";

            dsTndr.Tables.Clear();

            onGoingTasksPerSectionChart.ChartAreas[0].AxisX.MajorGrid.Enabled = false;
            onGoingTasksPerSectionChart.ChartAreas[0].AxisX.MinorGrid.Enabled = false;
            onGoingTasksPerSectionChart.ChartAreas[0].AxisY.MajorGrid.Enabled = false;
            onGoingTasksPerSectionChart.ChartAreas[0].AxisY.MinorGrid.Enabled = false;

            onGoingTasksPerSectionChart.ChartAreas[0].AxisX.LabelStyle.Angle = 30;
            onGoingTasksPerSectionChart.ChartAreas[0].AxisX.LabelStyle.ForeColor = Color.Maroon;

            onGoingTasksPerSectionChart.ChartAreas[0].AxisX.Interval = 1;
        }

    }
    private void fillBudgetData()
    {
        if (Session["userProfileID"].Equals("1"))
        {
           

            string sqlQueryYear = "SELECT COUNT(Job.jobID) AS jobCnt, YEAR(Job.jobReceivedDate) AS Year FROM   JobVOSI INNER JOIN    Job ON JobVOSI.jobID = Job.jobID INNER JOIN " +
                        " JobType ON Job.jobTypeID = JobType.jobTypeID WHERE  (JobType.CategoryID IN (4)) GROUP BY YEAR(Job.jobReceivedDate)";
            PopulateDropDownBox(ddlYear, sqlQueryYear, "Year", "Year");

            string sqlQueryDept = "SELECT COUNT(Job.jobID) AS jobCnt, Job.deptID, Department.deptName FROM     JobVOSI INNER JOIN    Job ON JobVOSI.jobID = Job.jobID INNER JOIN " +
                         " JobType ON Job.jobTypeID = JobType.jobTypeID INNER JOIN Department ON Job.deptID = Department.departmentID  WHERE  (JobType.CategoryID IN (4)) GROUP BY Job.deptID, Department.deptName ORDER BY Department.deptName";

            PopulateDropDownBox(ddlDept, sqlQueryDept, "deptID", "deptName");

            string strAffair = "SELECT COUNT(Job.jobID) AS jobCnt, Department_1.deptName AS AffairName, Department_1.departmentID AS AffairID FROM  JobVOSI INNER JOIN  Job ON JobVOSI.jobID = Job.jobID INNER JOIN " +
                   " JobType ON Job.jobTypeID = JobType.jobTypeID INNER JOIN   Department ON Job.deptID = Department.departmentID INNER JOIN   Department AS Department_1 ON Department.affairID = Department_1.departmentID " +
                    " WHERE   (JobType.CategoryID IN (4)) GROUP BY Department_1.deptName, Department_1.departmentID ORDER BY AffairName";

            PopulateDropDownBox(ddlAffair, strAffair, "AffairID", "AffairName");

            string strMinistry = "SELECT Job.ministryCode FROM  JobVOSI INNER JOIN   Job ON JobVOSI.jobID = Job.jobID INNER JOIN JobType ON Job.jobTypeID = JobType.jobTypeID WHERE  (JobType.CategoryID IN (4))  GROUP BY Job.ministryCode HAVING   (Job.ministryCode IS NOT NULL)";
            PopulateDropDownBox(ddlMinistry, strMinistry, "ministryCode", "ministryCode");

            string strBudRef = "SELECT Job.budgetRefNo  FROM  JobVOSI INNER JOIN   Job ON JobVOSI.jobID = Job.jobID INNER JOIN JobType ON Job.jobTypeID = JobType.jobTypeID WHERE  (JobType.CategoryID IN (4))  GROUP BY Job.budgetRefNo  HAVING   (Job.budgetRefNo  IS NOT NULL)";
            PopulateDropDownBox(ddlBudget, strBudRef, "budgetRefNo", "budgetRefNo");

            string strProvision = "SELECT Job.provisionNo  FROM  JobVOSI INNER JOIN   Job ON JobVOSI.jobID = Job.jobID INNER JOIN JobType ON Job.jobTypeID = JobType.jobTypeID WHERE  (JobType.CategoryID IN (4))  GROUP BY Job.provisionNo  HAVING   (Job.provisionNo  IS NOT NULL)";
            PopulateDropDownBox(ddlProv, strProvision, "provisionNo", "provisionNo");

            gCostEstimateChart();

         

            gCostEstimateJobCountChart();

            TextBox1.Text = fillCostEstimateAboveBudget().Rows[0][0].ToString();
            TextBox2.Text = fillCostEstimateBelowBudget().Rows[0][0].ToString();
        }
    }

    private void PageloadData()
    {
        getMyDocumentChart();

        getOnGoingTasksPerSection_New();

        getOnGoingTasksofSurveyOracle();

        //fillBudgetData();
    }
    private DataTable CostEstimateReport() //Sree
    {
        //JobVOSI.contractorAmt,(JobVOSI.ebsdAmt + JobVOSI.contractorAmt)

        System.Threading.Thread.CurrentThread.CurrentCulture = new System.Globalization.CultureInfo("ar-QA");

        //string sqlQuery = "SELECT Job.contractNo, Job.projectTitle, JobVOSI.budgetAmnt, JobVOSI.pmcAmt, JobVOSI.ebsdAmt , JobVOSI.contractorAmt, (JobVOSI.contractorAmt-JobVOSI.ebsdAmt)/JobVOSI.contractorAmt as EBSD_ratio, " +
        //            "(JobVOSI.contractorAmt-JobVOSI.budgetAmnt)/JobVOSI.contractorAmt as Budget_ratio" + 
        //            " FROM JobVOSI INNER JOIN Job ON JobVOSI.jobID = Job.jobID INNER JOIN  JobType ON Job.jobTypeID = JobType.jobTypeID WHERE (JobType.CategoryID IN (4, 7))";

        DataTable dt = new DataTable();
        using (SqlConnection objCon = new SqlConnection(connValue))
        {
            using (SqlCommand objCmd = new SqlCommand())
            {
                objCmd.CommandType = CommandType.StoredProcedure;
                objCmd.Connection = objCon;
                objCmd.CommandText = "CostEstimateReport";

                SqlDataAdapter objDA = new SqlDataAdapter(objCmd);

                objDA.SelectCommand.CommandText = objCmd.CommandText.ToString();

                objDA.Fill(dt);

                gvCostEstimate.DataSource = dt;
                gvCostEstimate.DataBind();


            }
        }

        return dt;
    }
    private void getOnGoingTasksofSurveyOracle()
    {
        DataSet dsTndr = new DataSet();

        string sqlQuery = null; int secID = Convert.ToInt32(Session["SectionID"]);
        string strSeriesName = string.Empty;

        if (Session["userProfileID"].ToString().Equals("1"))   // For Admin
        {
            sqlQuery = "select Count(status) as JobCnt, status from survey_info where status Not IN ('CLOSED','Old','CANCEL' ) group by status";
            strSeriesName = "sectionName";

            lblOngoingSurvey.Text = "Survey Process Details";
        }
        else
        {
            // sqlQuery = "select COUNT(*) as JobCnt,state_id as status from app_resource_allocation where user_id = 'tsd_osoro' and state_id = 'OPEN'  group by state_id";

            sqlQuery = "select Count(status) as JobCnt, status from survey_info where status Not IN ('CLOSED','Old','CANCEL' ) group by status";
            strSeriesName = "sectionName";
            lblOngoingSurvey.Text = "Survey Process Details";
        }

        OracleDataAdapter daTndr = new OracleDataAdapter(sqlQuery, connValueOracle);
        daTndr.Fill(dsTndr);

        if (dsTndr.Tables[0].Rows.Count != 0)
        {
            onGoingTasksofSurvey.DataSource = dsTndr.Tables[0].DefaultView;

            onGoingTasksofSurvey.Series["Series1"].XValueMember = "status";
            onGoingTasksofSurvey.Series["Series1"].YValueMembers = "JobCnt";

            dsTndr.Tables.Clear();

            onGoingTasksofSurvey.ChartAreas[0].AxisX.MajorGrid.Enabled = false;
            onGoingTasksofSurvey.ChartAreas[0].AxisX.MinorGrid.Enabled = false;
            onGoingTasksofSurvey.ChartAreas[0].AxisY.MajorGrid.Enabled = false;
            onGoingTasksofSurvey.ChartAreas[0].AxisY.MinorGrid.Enabled = false;

            onGoingTasksofSurvey.ChartAreas[0].AxisX.LabelStyle.Angle = 30;
            onGoingTasksofSurvey.ChartAreas[0].AxisX.LabelStyle.ForeColor = Color.Maroon;

            onGoingTasksofSurvey.ChartAreas[0].AxisX.Interval = 1;
        }
    }
    private void getOnGoingTasksPerSection()
    {
        DataSet dsTndr = new DataSet();

        string sqlQuery = null; int secID = Convert.ToInt32(Session["SectionID"]);
        string strSeriesName = string.Empty;


        if (Session["userProfileID"].ToString().Equals("1"))
        {
            //sqlQuery = "SELECT  COUNT(Job.jobID) AS JobCnt, Section.sectionName, JobType.sectionID FROM     JobType INNER JOIN    Job ON JobType.jobTypeID = Job.jobTypeID INNER JOIN " +
            //             " Section ON JobType.sectionID = Section.sectionID WHERE (Job.jobDueDate < GETDATE()) AND (Job.jobStatusID IN (3, 8)) GROUP BY Section.sectionName, JobType.sectionID ";

            sqlQuery = " SELECT  COUNT(Job.jobID) AS JobCnt, Section.sectionName FROM  JobType INNER JOIN  Job ON JobType.jobTypeID = Job.jobTypeID INNER JOIN   Section ON JobType.sectionID = Section.sectionID " +
               " WHERE (Job.jobDueDate < GETDATE()-1) AND (Job.jobStatusID IN (3, 8))  GROUP BY Section.sectionName, JobType.sectionID  UNION " +
                    "SELECT  COUNT(JobOwner.jobOwnerID) AS Expr1, Section.sectionName FROM  JobOwner INNER JOIN  Section ON JobOwner.sectionID = Section.sectionID " +
                          " WHERE  (JobOwner.payID IS NOT NULL) AND (JobOwner.actionDueDate < GETDATE()-1) AND (JobOwner.jobOwnerStatusID <> 7) GROUP BY Section.sectionName";
            strSeriesName = "sectionName";

            lblOngoingJobs.Text = "Over Due Job Order In All Sections";
        }
        else if (!Session["userProfileID"].ToString().Equals("1") && Session["SectionID"].ToString().Equals("7") && !userRightsColl.Contains("1"))    // 7 for all section 
        {
            sqlQuery = " SELECT  COUNT(Job.jobID) AS JobCnt, Section.sectionName FROM  JobType INNER JOIN  Job ON JobType.jobTypeID = Job.jobTypeID INNER JOIN   Section ON JobType.sectionID = Section.sectionID " +
               " WHERE (Job.jobDueDate < GETDATE()-1) AND (Job.jobStatusID IN (3, 8))  GROUP BY Section.sectionName, JobType.sectionID  UNION " +
                    "SELECT  COUNT(JobOwner.jobOwnerID) AS Expr1, Section.sectionName FROM  JobOwner INNER JOIN  Section ON JobOwner.sectionID = Section.sectionID " +
                          " WHERE  (JobOwner.payID IS NOT NULL) AND (JobOwner.actionDueDate < GETDATE()-1) AND (JobOwner.jobOwnerStatusID <> 7) GROUP BY Section.sectionName";

            strSeriesName = "sectionName";

            lblOngoingJobs.Text = "Over Due Job Order In All Sections";
        }
        else if (!userRightsColl.Contains("1")) // Not All Sections  
        {
            if (Session["SectionID"].ToString().Equals("1"))
            {
                sqlQuery = "SELECT COUNT(Job.jobID) AS JobCnt, JobType_1.jobTypeName FROM JobType AS JobType_1 INNER JOIN JobType ON JobType_1.jobTypeID = JobType.CategoryID INNER JOIN  Job ON JobType.jobTypeID = Job.jobTypeID INNER JOIN " +
            " Section ON JobType.sectionID = Section.sectionID WHERE (JobType.sectionID = " + secID + ") AND (Job.jobDueDate < GETDATE()-1) AND (Job.jobStatusID IN (3,8)) GROUP BY JobType_1.jobTypeName";

            }
            else if (Session["SectionID"].ToString().Equals("2"))
            {
                sqlQuery = "SELECT  COUNT(JobOwner.jobOwnerID) AS JobCnt, JobType.jobTypeName FROM  JobOwner INNER JOIN   JobType ON JobOwner.JobTypeID = JobType.jobTypeID " +
                                 " WHERE (JobOwner.payID IS NOT NULL) AND (JobOwner.actionDueDate < GETDATE()-1) AND (JobOwner.jobOwnerStatusID <> 7) GROUP BY JobType.jobTypeName";
            }
            else if (Session["SectionID"].ToString().Equals("3"))
            {
                //sqlQuery = "SELECT  COUNT(JobOwner.jobOwnerID) AS JobCnt, JobType.jobTypeName FROM  JobOwner INNER JOIN   JobType ON JobOwner.JobTypeID = JobType.jobTypeID " +
                //                 " WHERE (JobOwner.payID IS NULL) AND (JobOwner.actionDueDate < GETDATE()-1) AND (JobOwner.jobOwnerStatusID <> 7) and JobOwner.sectionID =3 GROUP BY JobType.jobTypeName";

                sqlQuery = "SELECT COUNT(Job.jobID) AS JobCnt, JobType_1.jobTypeName FROM JobType AS JobType_1 INNER JOIN JobType ON JobType_1.jobTypeID = JobType.CategoryID INNER JOIN  Job ON JobType.jobTypeID = Job.jobTypeID INNER JOIN " +
            " Section ON JobType.sectionID = Section.sectionID WHERE (JobType.sectionID = " + secID + ") AND (Job.jobDueDate < GETDATE()-1) AND (Job.jobStatusID IN (3,8)) GROUP BY JobType_1.jobTypeName";

                lblOngoingJobs.Text = "My On Going Tasks";
            }
            else       // added newly on jan 28th
            {
                sqlQuery = "SELECT  COUNT(JobOwner.jobOwnerID) AS JobCnt, JobType_1.jobTypeName FROM   JobType INNER JOIN  JobOwner ON JobType.jobTypeID = JobOwner.JobTypeID INNER JOIN " +
                            " Section ON JobOwner.sectionID = Section.sectionID INNER JOIN  JobType AS JobType_1 ON JobType.CategoryID = JobType_1.jobTypeID  WHERE (JobOwner.jobOwnerStatusID = 3) AND (JobOwner.contactID = " + _currentUserID + ") GROUP BY JobType_1.jobTypeName";
                strSeriesName = "jobTypeName";

                lblOngoingJobs.Text = "My On Going Tasks";
            }

            strSeriesName = "jobTypeName";
            lblOngoingJobs.Text = "Over Due Job Order In " + Session["SectionName"].ToString();
        }
        else if (Session["SectionID"].ToString().Equals("3"))
        {
            //sqlQuery = "SELECT  COUNT(JobOwner.jobOwnerID) AS JobCnt, JobType.jobTypeName FROM  JobOwner INNER JOIN   JobType ON JobOwner.JobTypeID = JobType.jobTypeID " +
            //                 " WHERE (JobOwner.payID IS NULL) AND (JobOwner.actionDueDate < GETDATE()-1) AND (JobOwner.jobOwnerStatusID <> 7) and JobOwner.sectionID =3 GROUP BY JobType.jobTypeName";

            sqlQuery = "SELECT COUNT(Job.jobID) AS JobCnt, JobType_1.jobTypeName FROM JobType AS JobType_1 INNER JOIN JobType ON JobType_1.jobTypeID = JobType.CategoryID INNER JOIN  Job ON JobType.jobTypeID = Job.jobTypeID INNER JOIN " +
        " Section ON JobType.sectionID = Section.sectionID WHERE (JobType.sectionID = " + secID + ") AND (Job.jobDueDate < GETDATE()-1) AND (Job.jobStatusID IN (3,8)) GROUP BY JobType_1.jobTypeName";


            lblOngoingJobs.Text = "My On Going Tasks";
        }
        else
        {
            sqlQuery = "SELECT  COUNT(JobOwner.jobOwnerID) AS JobCnt, JobType_1.jobTypeName FROM   JobType INNER JOIN  JobOwner ON JobType.jobTypeID = JobOwner.JobTypeID INNER JOIN " +
                        " Section ON JobOwner.sectionID = Section.sectionID INNER JOIN  JobType AS JobType_1 ON JobType.CategoryID = JobType_1.jobTypeID  WHERE (JobOwner.jobOwnerStatusID = 3) AND (JobOwner.contactID = " + _currentUserID + ") GROUP BY JobType_1.jobTypeName";
            strSeriesName = "jobTypeName";

            lblOngoingJobs.Text = "My On Going Tasks";
        }


        // Chart_OverDueJobs

        SqlDataAdapter daTndr = new SqlDataAdapter(sqlQuery, connValue);
        daTndr.Fill(dsTndr);
        if (dsTndr.Tables[0].Rows.Count != 0)
        {
            onGoingTasksPerSectionChart.DataSource = dsTndr.Tables[0].DefaultView;

            onGoingTasksPerSectionChart.Series["Series1"].XValueMember = strSeriesName;
            onGoingTasksPerSectionChart.Series["Series1"].YValueMembers = "JobCnt";

            dsTndr.Tables.Clear();

            onGoingTasksPerSectionChart.ChartAreas[0].AxisX.MajorGrid.Enabled = false;
            onGoingTasksPerSectionChart.ChartAreas[0].AxisX.MinorGrid.Enabled = false;
            onGoingTasksPerSectionChart.ChartAreas[0].AxisY.MajorGrid.Enabled = false;
            onGoingTasksPerSectionChart.ChartAreas[0].AxisY.MinorGrid.Enabled = false;

            onGoingTasksPerSectionChart.ChartAreas[0].AxisX.LabelStyle.Angle = 30;
            onGoingTasksPerSectionChart.ChartAreas[0].AxisX.LabelStyle.ForeColor = Color.Maroon;

            onGoingTasksPerSectionChart.ChartAreas[0].AxisX.Interval = 1;
        }

    }
   
    private void getMyDocumentChart()
    {
        DataSet dsDoc = new DataSet();

        string sqlQuery = null;

        if (Convert.ToInt32(Session["UserID"]) == 1)
        {
            sqlQuery = "SELECT COUNT(DocumentDistribution.distributeID) AS DocCount, DocumentStatus.docStatusName " +
                   " FROM DocumentDistribution INNER JOIN  DocumentStatus ON DocumentDistribution.docStatusID = DocumentStatus.docStatusID WHERE (DocumentDistribution.docStatusID not in (4,2)) GROUP BY DocumentStatus.docStatusName";
        }
        else
        {
            sqlQuery = "SELECT COUNT(DocumentDistribution.distributeID) AS DocCount, DocumentStatus.docStatusName " +
                   " FROM DocumentDistribution INNER JOIN  DocumentStatus ON DocumentDistribution.docStatusID = DocumentStatus.docStatusID WHERE (DocumentDistribution.docStatusID not in (4)) AND " +
                   " (DocumentDistribution.contactID = " + Convert.ToInt32(Session["UserID"]) + ") " +
                           " GROUP BY DocumentStatus.docStatusName";
        }

        SqlDataAdapter daDoc = new SqlDataAdapter(sqlQuery, connValue);
        daDoc.Fill(dsDoc);
        if (dsDoc.Tables[0].Rows.Count != 0)
        {
            myDocsChart.DataSource = dsDoc.Tables[0].DefaultView;
            myDocsChart.Series["Series1"].XValueMember = "docStatusName";
            myDocsChart.Series["Series1"].YValueMembers = "DocCount";

            dsDoc.Tables.Clear();

            myDocsChart.ChartAreas[0].AxisX.MajorGrid.Enabled = false;
            myDocsChart.ChartAreas[0].AxisX.MinorGrid.Enabled = false;
            myDocsChart.ChartAreas[0].AxisY.MajorGrid.Enabled = false;
            myDocsChart.ChartAreas[0].AxisY.MinorGrid.Enabled = false;

            myDocsChart.ChartAreas[0].AxisX.LabelStyle.Angle = 30;
            myDocsChart.ChartAreas[0].AxisX.LabelStyle.ForeColor = Color.Maroon;

            myDocsChart.ChartAreas[0].AxisX.Interval = 1;
        }
    }  

    private void PopulateDropDownBox(DropDownList ddlBox, string sqlQuery, string valueMember, string displayName)
    {
        ddlBox.DataBound += new EventHandler(this.ddlBox_DataBound);
        ddlBox.DataSource = new JobOrderData().FillDropdown(sqlQuery);
        ddlBox.DataTextField = displayName;
        ddlBox.DataValueField = valueMember;
        ddlBox.SelectedIndex = -1;
        ddlBox.DataBind();
    }
    protected void ddlBox_DataBound(object sender, EventArgs e)
    {
        DropDownList ddl = (DropDownList)sender;
        ListItem emptyItem = new ListItem("", "");
        ddl.Items.Insert(0, emptyItem);
    } 
    
    private void gCostEstimateJobCountChart()
    {
        DataSet dsDoc = new DataSet();

        string sqlQuery = null;

        sqlQuery = "SELECT COUNT(Job.jobID) AS jobCnt, YEAR(Job.jobReceivedDate) AS Year FROM   JobVOSI INNER JOIN    Job ON JobVOSI.jobID = Job.jobID INNER JOIN " +
                        " JobType ON Job.jobTypeID = JobType.jobTypeID WHERE  (JobType.CategoryID IN (4)) GROUP BY YEAR(Job.jobReceivedDate)";

        SqlDataAdapter daDoc = new SqlDataAdapter(sqlQuery, connValue);
        daDoc.Fill(dsDoc);
        if (dsDoc.Tables[0].Rows.Count != 0)
        {
            chartCostJobCnt.DataSource = dsDoc.Tables[0].DefaultView;
            chartCostJobCnt.Series["Series1"].XValueMember = "Year";
            chartCostJobCnt.Series["Series1"].YValueMembers = "jobCnt";

            dsDoc.Tables.Clear();

            chartCostJobCnt.ChartAreas[0].AxisX.MajorGrid.Enabled = false;
            chartCostJobCnt.ChartAreas[0].AxisX.MinorGrid.Enabled = false;
            chartCostJobCnt.ChartAreas[0].AxisY.MajorGrid.Enabled = false;
            chartCostJobCnt.ChartAreas[0].AxisY.MinorGrid.Enabled = false;

            chartCostJobCnt.ChartAreas[0].AxisX.LabelStyle.Angle = 30;
            chartCostJobCnt.ChartAreas[0].AxisX.LabelStyle.ForeColor = Color.Maroon;

            chartCostJobCnt.ChartAreas[0].AxisX.Interval = 1;
        }
    }


    private void gCostEstimateChart()
    {
        DataSet dsDoc = new DataSet();

        string sqlQuery = null;

        sqlQuery = "SELECT JobType.CategoryID, SUM(JobVOSI.budgetAmnt) AS BudgetAmnt, SUM(JobVOSI.pmcAmt) AS PMCAmnt, SUM(JobVOSI.ebsdAmt) AS EBSDAmnt, SUM(JobVOSI.contractorAmt) " +
                        " AS ContractAmnt FROM JobVOSI INNER JOIN   Job ON JobVOSI.jobID = Job.jobID INNER JOIN    JobType ON Job.jobTypeID = JobType.jobTypeID WHERE (JobType.CategoryID IN (4)) GROUP BY JobType.CategoryID";

        SqlDataAdapter daDoc = new SqlDataAdapter(sqlQuery, connValue);
        daDoc.Fill(dsDoc);

        if (dsDoc.Tables[0].Rows.Count > 0)
        {
            Session["TotalBudget"] = dsDoc.Tables[0].Rows[0][1].ToString();
            Session["TotalPMC"] = dsDoc.Tables[0].Rows[0][2].ToString();
            Session["TotalEbsd"] = dsDoc.Tables[0].Rows[0][3].ToString();
            Session["TotalAward"] = dsDoc.Tables[0].Rows[0][4].ToString();
        }

        if (dsDoc.Tables[0].Rows.Count != 0)
        {
            chartCostEstimate.DataSource = dsDoc.Tables[0].DefaultView;

            chartCostEstimate.Series["Series2"].XValueMember = "CategoryID";
            chartCostEstimate.Series["Series2"].YValueMembers = "PMCAmnt";

            chartCostEstimate.Series["Series3"].XValueMember = "CategoryID";
            chartCostEstimate.Series["Series3"].YValueMembers = "EBSDAmnt";

            chartCostEstimate.Series["Series1"].XValueMember = "CategoryID";
            chartCostEstimate.Series["Series1"].YValueMembers = "BudgetAmnt";


            chartCostEstimate.Series["Series4"].XValueMember = "CategoryID";
            chartCostEstimate.Series["Series4"].YValueMembers = "ContractAmnt";

            dsDoc.Tables.Clear();

            chartCostEstimate.ChartAreas[0].AxisX.MajorGrid.Enabled = false;
            chartCostEstimate.ChartAreas[0].AxisX.MinorGrid.Enabled = false;
            chartCostEstimate.ChartAreas[0].AxisY.MajorGrid.Enabled = false;
            chartCostEstimate.ChartAreas[0].AxisY.MinorGrid.Enabled = false;

            chartCostEstimate.ChartAreas[0].AxisX.LabelStyle.Angle = 30;
            chartCostEstimate.ChartAreas[0].AxisX.LabelStyle.ForeColor = Color.Maroon;

            chartCostEstimate.ChartAreas[0].AxisX.Interval = 1;
        }
    }

    private DataTable fillCostEstimateAboveBudget()
    {
        DataSet ds = new DataSet();
        try
        {

            Int32 affairID;
            Int32.TryParse(ddlAffair.SelectedValue, out affairID);

            Int32 deptID;
            Int32.TryParse(ddlDept.SelectedValue, out deptID);

            //string strYear = string.Empty;
            //if (ddlYear.SelectedItem.Text != "")
            //    strYear = ddlYear.SelectedItem.Text;

            Int32 strYear;
            Int32.TryParse(ddlYear.SelectedItem.Text, out strYear);

            string strMinistry = string.Empty;
            if (ddlMinistry.SelectedItem.Text != "")
                strMinistry = ddlMinistry.SelectedItem.Text;

            string strBudgetRef = string.Empty;
            if (ddlBudget.SelectedItem.Text != "")
                strBudgetRef = ddlBudget.SelectedItem.Text;

            string strProvNo = string.Empty;
            if (ddlProv.SelectedItem.Text != "")
                strProvNo = ddlProv.SelectedItem.Text;



            ds = new JobOrderData().GetCostAboveBudget(affairID, deptID, strYear, strMinistry, strBudgetRef, strProvNo);

            DataView dvCommitted = new DataView(ds.Tables[0]);

        }
        catch (Exception ex)
        {

        }
        return ds.Tables[0];
    }

    private DataTable fillCostEstimateBelowBudget()
    {
        DataSet ds = new DataSet();
        try
        {

            Int32 affairID;
            Int32.TryParse(ddlAffair.SelectedValue, out affairID);

            Int32 deptID;
            Int32.TryParse(ddlDept.SelectedValue, out deptID);

            //string strYear = string.Empty;
            //if (ddlYear.SelectedItem.Text != "")
            //    strYear = ddlYear.SelectedItem.Text;

            Int32 strYear;
            Int32.TryParse(ddlYear.SelectedItem.Text, out strYear);

            string strMinistry = string.Empty;
            if (ddlMinistry.SelectedItem.Text != "")
                strMinistry = ddlMinistry.SelectedItem.Text;

            string strBudgetRef = string.Empty;
            if (ddlBudget.SelectedItem.Text != "")
                strBudgetRef = ddlBudget.SelectedItem.Text;

            string strProvNo = string.Empty;
            if (ddlProv.SelectedItem.Text != "")
                strProvNo = ddlProv.SelectedItem.Text;

            ds = new JobOrderData().GetCostBelowBudget(affairID, deptID, strYear, strMinistry, strBudgetRef, strProvNo);

            DataView dvCommitted = new DataView(ds.Tables[0]);
        }
        catch (Exception ex)
        {

        }
        return ds.Tables[0];
    }
    private DataTable fillCostEstimateData()
    {
        DataSet ds = new DataSet();
        try
        {

            Int32 affairID;
            Int32.TryParse(ddlAffair.SelectedValue, out affairID);

            Int32 deptID;
            Int32.TryParse(ddlDept.SelectedValue, out deptID);

            //string strYear = string.Empty;
            //if (ddlYear.SelectedItem.Text != "")
            //    strYear = ddlYear.SelectedItem.Text;

            Int32 strYear;
            Int32.TryParse(ddlYear.SelectedItem.Text, out strYear);

            string strMinistry = string.Empty;
            if (ddlMinistry.SelectedItem.Text != "")
                strMinistry = ddlMinistry.SelectedItem.Text;

            string strBudgetRef = string.Empty;
            if (ddlBudget.SelectedItem.Text != "")
                strBudgetRef = ddlBudget.SelectedItem.Text;

            string strProvNo = string.Empty;
            if (ddlProv.SelectedItem.Text != "")
                strProvNo = ddlProv.SelectedItem.Text;



            ds = new JobOrderData().GetCostDataByFilter(affairID, deptID, strYear, strMinistry, strBudgetRef, strProvNo);

            DataView dvCommitted = new DataView(ds.Tables[0]);

        }
        catch (Exception ex)
        {

        }
        return ds.Tables[0];
    }


    private DataTable fillCostEstimateDataForChart()            //   
    {
        DataSet ds = new DataSet();
        try
        {

            Int32 affairID;
            Int32.TryParse(ddlAffair.SelectedValue, out affairID);

            Int32 deptID;
            Int32.TryParse(ddlDept.SelectedValue, out deptID);

            //string strYear = string.Empty;
            //if (ddlYear.SelectedItem.Text != "")
            //    strYear = ddlYear.SelectedItem.Text;

            Int32 strYear;
            Int32.TryParse(ddlYear.SelectedItem.Text, out strYear);

            string strMinistry = string.Empty;
            if (ddlMinistry.SelectedItem.Text != "")
                strMinistry = ddlMinistry.SelectedItem.Text;

            string strBudgetRef = string.Empty;
            if (ddlBudget.SelectedItem.Text != "")
                strBudgetRef = ddlBudget.SelectedItem.Text;

            string strProvNo = string.Empty;
            if (ddlProv.SelectedItem.Text != "")
                strProvNo = ddlProv.SelectedItem.Text;



            ds = new JobOrderData().GetCostDataByFilterForChart(affairID, deptID, strYear, strMinistry, strBudgetRef, strProvNo);

            DataView dvCommitted = new DataView(ds.Tables[0]);

        }
        catch (Exception ex)
        {

        }
        return ds.Tables[0];
    }

    private DataTable fillCostEstimateDataForJobCntChart()
    {
        DataSet ds = new DataSet();
        try
        {

            Int32 affairID;
            Int32.TryParse(ddlAffair.SelectedValue, out affairID);

            Int32 deptID;
            Int32.TryParse(ddlDept.SelectedValue, out deptID);

            //string strYear = string.Empty;
            //if (ddlYear.SelectedItem.Text != "")
            //    strYear = ddlYear.SelectedItem.Text;

            Int32 strYear;
            Int32.TryParse(ddlYear.SelectedItem.Text, out strYear);

            string strMinistry = string.Empty;
            if (ddlMinistry.SelectedItem.Text != "")
                strMinistry = ddlMinistry.SelectedItem.Text;

            string strBudgetRef = string.Empty;
            if (ddlBudget.SelectedItem.Text != "")
                strBudgetRef = ddlBudget.SelectedItem.Text;

            string strProvNo = string.Empty;
            if (ddlProv.SelectedItem.Text != "")
                strProvNo = ddlProv.SelectedItem.Text;



            ds = new JobOrderData().GetCostEstimateJobCntForChart(affairID, deptID, strYear, strMinistry, strBudgetRef, strProvNo);

            DataView dvCommitted = new DataView(ds.Tables[0]);

        }
        catch (Exception ex)
        {

        }
        return ds.Tables[0];
    }
    private void filterData()
    {
        System.Threading.Thread.CurrentThread.CurrentCulture = new System.Globalization.CultureInfo("ar-QA");
        DataTable dtChart = new DataTable();
        trClearButton.Visible = true;
        chartCostEstimate.DataSource = fillCostEstimateDataForChart();

        dtChart = fillCostEstimateDataForChart();

        if (dtChart.Rows.Count > 0)
        {
            Session["TotalBudget"] = dtChart.Rows[0][1].ToString();
            Session["TotalPMC"] = dtChart.Rows[0][2].ToString();
            Session["TotalEbsd"] = dtChart.Rows[0][3].ToString();
            Session["TotalAward"] = dtChart.Rows[0][4].ToString();
        }

        chartCostEstimate.Series["Series2"].XValueMember = "CategoryID";
        chartCostEstimate.Series["Series2"].YValueMembers = "PMCAmnt";

        chartCostEstimate.Series["Series3"].XValueMember = "CategoryID";
        chartCostEstimate.Series["Series3"].YValueMembers = "EBSDAmnt";

        chartCostEstimate.Series["Series1"].XValueMember = "CategoryID";
        chartCostEstimate.Series["Series1"].YValueMembers = "BudgetAmnt";


        chartCostEstimate.Series["Series4"].XValueMember = "CategoryID";
        chartCostEstimate.Series["Series4"].YValueMembers = "ContractAmnt";

        //dsDoc.Tables.Clear();

        chartCostEstimate.ChartAreas[0].AxisX.MajorGrid.Enabled = false;
        chartCostEstimate.ChartAreas[0].AxisX.MinorGrid.Enabled = false;
        chartCostEstimate.ChartAreas[0].AxisY.MajorGrid.Enabled = false;
        chartCostEstimate.ChartAreas[0].AxisY.MinorGrid.Enabled = false;

        chartCostEstimate.ChartAreas[0].AxisX.LabelStyle.Angle = 30;
        chartCostEstimate.ChartAreas[0].AxisX.LabelStyle.ForeColor = Color.Maroon;

        chartCostEstimate.ChartAreas[0].AxisX.Interval = 1;

        //-------------------------------------------------------------------------------------------------------




        chartCostJobCnt.DataSource = fillCostEstimateDataForJobCntChart();
        chartCostJobCnt.Series["Series1"].XValueMember = "Year";
        chartCostJobCnt.Series["Series1"].YValueMembers = "jobCnt";

        // dsDoc.Tables.Clear();

        chartCostJobCnt.ChartAreas[0].AxisX.MajorGrid.Enabled = false;
        chartCostJobCnt.ChartAreas[0].AxisX.MinorGrid.Enabled = false;
        chartCostJobCnt.ChartAreas[0].AxisY.MajorGrid.Enabled = false;
        chartCostJobCnt.ChartAreas[0].AxisY.MinorGrid.Enabled = false;

        chartCostJobCnt.ChartAreas[0].AxisX.LabelStyle.Angle = 30;
        chartCostJobCnt.ChartAreas[0].AxisX.LabelStyle.ForeColor = Color.Maroon;

        chartCostJobCnt.ChartAreas[0].AxisX.Interval = 1;
    }
    private void fillEstimateData()
    {
        filterData();

        gvCostEstimate.DataSource = fillCostEstimateData();
        gvCostEstimate.DataBind();

        TextBox1.Text = fillCostEstimateAboveBudget().Rows[0][0].ToString();
        TextBox2.Text = fillCostEstimateBelowBudget().Rows[0][0].ToString();
    }
    protected void ddlYear_SelectedIndexChanged(object sender, EventArgs e)
    {
        fillEstimateData();
    }
    protected void ddlAffair_SelectedIndexChanged(object sender, EventArgs e)
    {
        fillEstimateData();
    }
    protected void ddlDept_SelectedIndexChanged(object sender, EventArgs e)
    {
        fillEstimateData();
    }
    protected void ddlMinistry_SelectedIndexChanged(object sender, EventArgs e)
    {
        fillEstimateData();
    }
    protected void ddlBudget_SelectedIndexChanged(object sender, EventArgs e)
    {
        fillEstimateData();
    }
    protected void ddlProv_SelectedIndexChanged(object sender, EventArgs e)
    {
        fillEstimateData();
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        fillEstimateData();
    }
    protected void btnClear_Click(object sender, EventArgs e)
    {
        ddlAffair.SelectedIndex = -1;
        ddlDept.SelectedIndex = -1;
        ddlYear.SelectedIndex = -1;

        ddlMinistry.SelectedIndex = -1;
        ddlProv.SelectedIndex = -1;
        ddlBudget.SelectedIndex = -1;

        trClearButton.Visible = false;

        gCostEstimateChart();
        CostEstimateReport();


        gCostEstimateJobCountChart();

        TextBox1.Text = fillCostEstimateAboveBudget().Rows[0][0].ToString();
        TextBox2.Text = fillCostEstimateBelowBudget().Rows[0][0].ToString();
    }
    protected void gvCostEstimate_PageIndexChanging(object sender, System.Web.UI.WebControls.GridViewPageEventArgs e)
    {

    }
    protected void gvCostEstimate_RowDataBound(object sender, System.Web.UI.WebControls.GridViewRowEventArgs e)
    {

    }
    protected void OngoingJobsClick(object sender, System.Web.UI.WebControls.ImageMapEventArgs e)
    {
        // Basic Materials,A_ (PSA Contract),Cost Control Section,Payment Request,
        //Comitted Contract,Cost Estimate,Planning Schedule(Baseline),Non Committed Contracts

       // string sectionName = Session["SectionName"].ToString();

        Session["OverDueName"] = e.PostBackValue.ToString();

        Session["OnGoingJobStatus"] = e.PostBackValue;

        // overdueJobs_old(sectionName);   

        // overdueJobs(Session["ShortName"].ToString());

        //Planning Schedule (Baseline)    //Cost Estimate       //A_ (PSA Contract) 

        if (Session["SectionName"].ToString().Equals("Cost Control Section") || Session["SectionName"].ToString().Equals("Planning and Scheduling"))
        {
            Response.Redirect("~/DCLog/OverDueJobs.aspx", false);
        }              
        else if ((e.PostBackValue.Trim().ToString().Equals("Document Control")))
        {
            Response.Redirect("~/DCLog/OverDueJobs.aspx", false);
        }
        else if ((e.PostBackValue.ToString().Equals("Cost Control Section")))
        {
            Response.Redirect("~/DCLog/OverDueJobs.aspx", false);
        }
        else if ((e.PostBackValue.ToString().Equals("Payment Section")))
        {
            Response.Redirect("~/Payments/OverDuePayments.aspx", false);
        }
        else if (lblOngoingJobs.Text.Contains("Over Due") & Session["SectionID"].Equals("3"))
        {
            Response.Redirect("~/DCLog/OverDueJobs.aspx", false);
        }
        else
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "Popup", "<script>alert('Restricted Access!')</script>", false);
        }
    }
    protected void onGoingTasksPerSectionChart_Load(object sender, EventArgs e)
    {

    }
    protected void myDocsChart_Click(object sender, System.Web.UI.WebControls.ImageMapEventArgs e)
    {
        string strUpdateJob = Request.Url.AbsoluteUri;
        Session["UrlRef"] = strUpdateJob;

        uCls = new UtilityClass(this.Page);
        uCls.ResetTheSessionVariables();
        Session["MyChartClickDocStatus"] = e.PostBackValue;
        int docStatusID = 1;
        if (e.PostBackValue.Equals("Open"))
            docStatusID = 1;
        else if (e.PostBackValue.Equals("For Follow Up"))
            docStatusID = 2;
        else if (e.PostBackValue.Equals("Pending"))
            docStatusID = 3;

        Response.Redirect("~/Documents/SearchDocument.aspx?docStatID=" + docStatusID, false);
    }
    protected void onGoingTasksofSurvey_Click(object sender, System.Web.UI.WebControls.ImageMapEventArgs e)
    {
        string sectionName = Session["SectionName"].ToString();

        Session["OverDueName"] = e.PostBackValue.ToString();

        Session["OnGoingJobStatus"] = e.PostBackValue;

        if (Session["SectionID"].Equals("4"))
        {
            Response.Redirect("~/Survey/SurveyProcessGraphInfo.aspx", false);
        }
        else
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "Popup", "<script>alert('Restricted Access!')</script>", false);
        }
    }
    protected void onGoingTasksofSurvey_Load(object sender, EventArgs e)
    {

    }
    protected void sectionWiseDoc_Click(object sender, System.Web.UI.WebControls.ImageMapEventArgs e)
    {

    }
    protected void lnkSearchMyDocs_Click(object sender, EventArgs e)
    {
        string strUpdateJob = Request.Url.AbsoluteUri;
        Session["UrlRef"] = strUpdateJob;
        //uCls = new UtilityClass(this.Page);
        //uCls.ResetTheSessionVariables();
        Session["SearchMyDocs"] = "1";
        Response.Redirect("~/Documents/SearchDocument.aspx", false);
    }
    protected void lnkSearchJobOrderLog_Click(object sender, EventArgs e)
    {
        string strUpdateJob = Request.Url.AbsoluteUri;
        Session["UrlRef"] = strUpdateJob;
        if (userRightsColl.Contains("10"))   //Add New Project
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "Popup", "<script>alert('You have no privilege to Search Job Order Log.')</script>", false);
            return;
        }
        else
        {
            if (Session["SectionID"].Equals("3"))
                Response.Redirect("~/DCLog/SearchDCLog.aspx", false);
            else
                Response.Redirect("SearchJobMstr.aspx", false);
        }
    }
    protected void lnkSearchAddendumLog_Click(object sender, EventArgs e)
    {
        string strUpdateJob = Request.Url.AbsoluteUri;
        Session["UrlRef"] = strUpdateJob;

        if (userRightsColl.Contains("11"))
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "Popup", "<script>alert('You have no privilege to Search Addendum Log.')</script>", false);
            return;
        }
        else
        {
            Response.Redirect("SearchAdmData.aspx", false);
        }
    }
    protected void lnkGenerateReports0_Click(object sender, EventArgs e)
    {
        string strUpdateJob = Request.Url.AbsoluteUri;
        Session["UrlRef"] = strUpdateJob;
        if (userRightsColl.Contains("19"))   //Add New Project
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "Popup", "<script>alert('You have no privilege to Search Job Order Log.')</script>", false);
            return;
        }
        else
        {
            Response.Redirect("~/Payments/SearchPayment.aspx", false);
        }
    }
    protected void lnkSearchSurvey_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/Survey/SearchSurveyLog.aspx", false);
    }
}