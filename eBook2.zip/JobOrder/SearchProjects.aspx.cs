﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Data.SqlClient;
using System.Data;
using Datalayer;
using System.Globalization;
using System.Web.UI.HtmlControls;
using System.IO;
using System.Drawing;

public partial class JobOrder_SearchProjects : System.Web.UI.Page
{
    string connValue = System.Configuration.ConfigurationManager.ConnectionStrings["TCMSConn"].ConnectionString;
    string _prjCode = string.Empty; string flag = string.Empty;
    int jobType = 0;
    string _userName = string.Empty; int cntID = 0;
    static IList<string> userRightsColl = null;

    protected void lnkProjectCodeCmted_Click(object sender, EventArgs e)     //ForCommitted
    {
        try
        {
            LinkButton lnkJobID = (LinkButton)sender;
            GridViewRow gvr = (GridViewRow)lnkJobID.NamingContainer;
            Session["ProjectCode"] = ((HtmlGenericControl)gvr.FindControl("divProjectCodeCmted")).InnerText;

            Session["UrlRef"] = Request.Url.AbsoluteUri;
            Response.Redirect("~/JobOrder/SearchJobMstr.aspx?Project_Code = " + Session["ProjectCode"] + "", false);

        }
        catch
        {

        }
    }

    protected void lnkCostVOSILog_Click(object sender, EventArgs e)
    {
        try
        {
            LinkButton lnkcostVoLog = (LinkButton)sender;
            GridViewRow gvr = (GridViewRow)lnkcostVoLog.NamingContainer;
            Session["divCatID"] = ((HtmlGenericControl)gvr.FindControl("divCatID")).InnerText;
            Session["divProjectCodeCmted"] = ((HtmlGenericControl)gvr.FindControl("divProjectCodeCmted")).InnerText;
            Session["divJobID"] = ((HtmlGenericControl)gvr.FindControl("divJobID")).InnerText;
            Session["divJobNo"] = ((HtmlGenericControl)gvr.FindControl("divJobNo")).InnerText;

            Session["UrlRef"] = Request.Url.AbsoluteUri;
            if (Session["divCatID"].ToString().Equals("4") || Session["divCatID"].ToString().Equals("7"))
            {
                if (!userRightsColl.Contains("41"))
                {
                    UtilityClass utils = null;
                    try
                    {
                        utils = new UtilityClass(this.Page);
                        string url = Request.Url.AbsoluteUri;
                        Session["Url"] = Request.Url.AbsoluteUri;
                        if (url.Contains(":"))
                            url = url.Substring(0, utils.GetNthIndex(url, '/', 4));
                        else
                            url = url.Substring(0, utils.GetNthIndex(url, '/', 2));
                        url = url + "/JobOrder/CostVOSILog.aspx?PSAprjCode=" + Session["divProjectCodeCmted"] + "&JobID= " + Session["divJobID"] + "&PSAJobNo= " + Session["divJobNo"] + "";
                        OpenPageByUsingJS(url, "1024", "850");
                    }
                    catch (Exception ex)
                    {
                        this.Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Error occurred while processing the request')</script>", false);
                    }
                }
            }
            else
            {
                UtilityClass utils = null;
                try
                {
                    utils = new UtilityClass(this.Page);
                    string url = Request.Url.AbsoluteUri;
                    Session["Url"] = Request.Url.AbsoluteUri;
                    if (url.Contains(":"))
                        url = url.Substring(0, utils.GetNthIndex(url, '/', 4));
                    else
                        url = url.Substring(0, utils.GetNthIndex(url, '/', 2));
                    url = url + "/JobOrder/JobOrderVOSILog.aspx?PSAprjCode=" + Session["divProjectCodeCmted"] + "&JobID= " + Session["divJobID"] + "&PSAJobNo= " + Session["divJobNo"] + "";
                    OpenPageByUsingJS(url, "970", "650");
                }
                catch (Exception ex)
                {
                    this.Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Error occurred while processing the request')</script>", false);
                }
            }

        }
        catch
        {

        }
    }

    private void OpenPageByUsingJS(string url, string width, string height)
    {
        string s = "window.open('" + url + "', 'popup_window', 'width=" + width + ",height=" + height + "left=100,top=100,resizable=yes');";
        Page.ClientScript.RegisterStartupScript(this.GetType(), "script", s, true);
    }

    protected void lnkJobOrderJobNo_Click(object sender, EventArgs e)     //ForCommitted
    {
        try
        {
            LinkButton lnkJobID = (LinkButton)sender;
            GridViewRow gvr = (GridViewRow)lnkJobID.NamingContainer;

            Session["JobID"] = ((HtmlGenericControl)gvr.FindControl("divJobID")).InnerText;

            Session["UrlRef"] = Request.Url.AbsoluteUri;
            Response.Redirect("~/DCLog/DCDetails.aspx?JobID= " + Session["JobID"] + "", false);

            //  Response.Redirect("~/DCLog/DcLogDetails.aspx?JobID= " + Session["JobID"] + "", false);


        }
        catch
        {

        }
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["UserName"] == null)
        {
            Response.Redirect("~/LoginPage.aspx", false);
            return;
        }

        string chartStatus = string.Empty;

        userRightsColl = (IList<string>)Session["UserRightsColl"];

        if (Session["ProjectCode"] != null)
            _prjCode = Session["ProjectCode"].ToString(); // Request.QueryString["ProjCode"];      

        if (Session["Flag"] != null)
            flag = Session["Flag"].ToString();

        cntID = new JobOrderData().getUserID(_userName);

        if (!IsPostBack)
        {
            loadData();

           
        }
    }

    private void loadData()
    {
        DataTable dt = new DataTable();

        int sectionID = Convert.ToInt16(Session["SectionID"]);
        FillDropBox(sectionID);

        DataView dvCommitted = new DataView();
        if (_prjCode == null)
        {
            dt = FillTab2(0, "");     //  SearchJob


            Session["ChartJobs"] = dt;
            gvJoborder.DataSource = dt;
            gvJoborder.DataBind();

            //   FillTabByJobNo(0, "");

            lblCnt.Text = dt.Rows.Count.ToString();
        }
        else
        {
            dt = FillTab2(0, _prjCode);

            Session["ChartJobs"] = dt;
            gvJoborder.DataSource = dt;
            gvJoborder.DataBind();

            lblCnt.Text = dt.Rows.Count.ToString();
        }
    }
    public void FillDropBox(int _sectionID)
    {
        PopulateDropDownBox(ddlJobType, "SELECT DISTINCT JobType.jobTypeID, JobType.jobTypeName FROM JobType INNER JOIN Job ON JobType.jobTypeID = Job.jobTypeID WHERE (JobType.CategoryID IN (8)) ORDER BY JobType.jobTypeName", "jobTypeID", "jobTypeName");

        PopulateDropDownBox(ddlJobStatus_, "SELECT jobStatusID, jobStatusName FROM JobStatus where jobStatusID in(1,2,3,4,5,6,7) ORDER BY jobStatusName", "jobStatusID", "jobStatusName");

        PopulateDropDownBox(ddlAffair, "SELECT  departmentID, deptName FROM  Department WHERE (affairID IS NULL) ORDER BY deptName", "departmentID", "deptName");

        PopulateDropDownBox(ddlDept, "SELECT departmentID, deptName FROM  Department WHERE (affairID IS NOT NULL) ORDER BY deptName", "departmentID", "deptName");

        PopulateDropDownBox(ddlVendor, "SELECT DISTINCT Company.companyID, Company.cmpName FROM Job INNER JOIN Company ON Job.consultantID = Company.companyID INNER JOIN JobType ON Job.jobTypeID = JobType.jobTypeID WHERE  (JobType.CategoryID IN (8)) ORDER BY Company.cmpName", "companyID", "cmpName");

        string strCntr = "SELECT DISTINCT Company.companyID, Company.cmpName FROM   Job INNER JOIN Company ON Job.contractorID = Company.companyID INNER JOIN JobType ON Job.jobTypeID = JobType.jobTypeID WHERE  (JobType.CategoryID IN (8)) ORDER BY Company.cmpName";
        PopulateDropDownBox(ddlContractor, strCntr, "companyID", "cmpName");

        PopulateDropDownBoxQS(ddlQS, "SELECT DISTINCT Contact.contactID, Contact.userShortName FROM JobOwner INNER JOIN    Contact ON JobOwner.contactID = Contact.contactID WHERE (JobOwner.sectionID = 3)", "ContactID", "userShortName");

        //PopulateDropDownBox(ddlPrjCode, "SELECT DISTINCT Job.contractNo, Job.contractNo  FROM job INNER JOIN JobType ON Job.jobTypeID = JobType.jobTypeID WHERE    (JobType.CategoryID IN (8)) ORDER BY Job.contractNo", "contractNo", "contractNo");

        PopulateDropDownBox(ddlPrjCode, "SELECT DISTINCT projectCode  FROM   Job WHERE  (sectionID = 3) AND (projectCode IS NOT NULL) AND (projectCode <> '') ORDER BY projectCode", "projectCode", "projectCode");

        PopulateDropDownBox(ddlReqType, "SELECT reqStatusID, reqStatusName FROM DCRequestStatus  ORDER BY reqStatusName", "reqStatusID", "reqStatusName");
    }
    private IList<string> getProjectCodeList()
    {
        IList<string> prjCodeColl = new List<string>();

        return prjCodeColl;
    }
    private DataTable FillTab2(int searchType, string _prjCode)
    {
        DataSet ds = new DataSet();
        try
        {

            Int16 afrID;
            Int16.TryParse(ddlAffair.SelectedValue, out afrID);

            Int16 dptID;
            Int16.TryParse(ddlDept.SelectedValue, out dptID);

            Int16 consID;
            Int16.TryParse(ddlVendor.SelectedValue, out consID);

            Int16 jobType;
            Int16.TryParse(ddlJobType.SelectedValue, out jobType);

            Int16 jobStatus;
            Int16.TryParse(ddlJobStatus_.SelectedValue, out jobStatus);

            Int16 docRefID;
            Int16.TryParse(txtDocRefNo.Text, out docRefID);


            Int16 qsID;
            if (ddlQS.SelectedValue != "ALL")
                Int16.TryParse(ddlQS.SelectedValue, out qsID);
            else
            {
                qsID = -1;
                Int16.TryParse(qsID.ToString(), out qsID);
            }

            string prjTitle = string.Empty;
            if (txtTitle.Text != "")
                prjTitle = "%" + txtTitle.Text + "%";

            Int16 cntrID;
            Int16.TryParse(ddlContractor.SelectedValue, out cntrID);

            Int16 consultID;
            Int16.TryParse(ddlVendor.SelectedValue, out consultID);

            string prjCode = string.Empty;
            if (_prjCode != "")
            {
                ddlPrjCode.SelectedItem.Text = _prjCode;
                prjCode = _prjCode;
            }
            else
                prjCode = ddlPrjCode.SelectedItem.Text;

            if (ddlPrjCode.SelectedItem.Text != "")
                prjCode = ddlPrjCode.SelectedItem.Text;

            string txtfrom = string.Empty;
            if (txtdept.Text != "")
                txtfrom = txtdept.Text;


            string txtTo = string.Empty;
            if (txtToDate.Text != "")
                txtTo = txtToDate.Text;

            Int16 dcReqID;
            Int16.TryParse(ddlReqType.SelectedValue, out dcReqID);     //dcu_SearchJobLog

            int selectionType = 1;

          //  ds = (new JobOrderData().GetProjectsLog(afrID, dptID,jobType, jobStatus, cntrID, consultID ,dcReqID,selectionType, prjTitle));          // sp_GetProjectData

           // int? AffairID, int? departmentID, int? jobTypeID, int? jobStatusID, int? cntrTypeID, int? FiscalYear, int? CommitteeType, int? selectionType,string prjTitle

        }
        catch (Exception ex)
        {

        }
        return ds.Tables[0];
    }
    protected void btnSearch_Click(object sender, EventArgs e)
    {
        Session["ChartJobs"] = null;
        DataTable dt = new DataTable();

        dt = FillTab2(0, "");
        Session["ChartJobs"] = dt;

        gvJoborder.DataSource = dt;
        gvJoborder.DataBind();

        lblCnt.Text = dt.Rows.Count.ToString();
    }


    private void PopulateDropDownBox(DropDownList ddlBox, string sqlQuery, string valueMember, string displayName)
    {
        ddlBox.DataBound += new EventHandler(this.ddlBox_DataBound);
        ddlBox.DataSource = new JobOrderData().FillDropdown(sqlQuery);
        ddlBox.DataTextField = displayName;
        ddlBox.DataValueField = valueMember;
        ddlBox.SelectedIndex = -1;
        ddlBox.DataBind();
    }
    private void PopulateDropDownBoxQS(DropDownList ddlBox, string sqlQuery, string valueMember, string displayName)
    {

        ddlBox.DataSource = new JobOrderData().FillDropdown(sqlQuery);
        ddlBox.DataTextField = displayName;
        ddlBox.DataValueField = valueMember;
        ddlBox.SelectedIndex = -1;
        ddlBox.DataBind();


        ListItem emptyItem123 = new ListItem("ALL", "ALL");
        ddlBox.Items.Insert(0, emptyItem123);

        ListItem emptyItem = new ListItem("", "");
        ddlBox.Items.Insert(0, emptyItem);

    }
    protected void ddlBox_DataBound(object sender, EventArgs e)
    {
        DropDownList ddl = (DropDownList)sender;
        ListItem emptyItem = new ListItem("", "");
        ddl.Items.Insert(0, emptyItem);
    }


    protected void ddlBoxQS_DataBound(object sender, EventArgs e)
    {
        DropDownList ddl = (DropDownList)sender;
        ListItem emptyItem = new ListItem("ALL", "ALL");
        ddl.Items.Insert(0, emptyItem);
    }
    private void PopulateDropDownBox_TCMS(DropDownList ddlBox, string sqlQuery, string valueMember, string displayName)
    {
        ddlBox.DataSource = new JobOrderData().FillDropdown_TCMS(sqlQuery);
        ddlBox.DataTextField = displayName;
        ddlBox.DataValueField = valueMember;
        ddlBox.SelectedIndex = -1;
        ddlBox.DataBind();
    }


    protected void gvJoborder_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        gvJoborder.PageIndex = e.NewPageIndex;
        bindGridView();

        DataTable dt = new DataTable();
        dt = FillTab2(0, "");

        Session["ChartJobs"] = dt;

        gvJoborder.DataSource = dt;
        gvJoborder.DataBind();
    }
    private string getDaysByGivenEndDate(string strDate, string endDate)
    {
        strDate = Convert.ToDateTime(strDate).ToString("MM/dd/yyyy", CultureInfo.InvariantCulture);
        endDate = Convert.ToDateTime(endDate).ToString("MM/dd/yyyy", CultureInfo.InvariantCulture);

        DateTime strDt = DateTime.ParseExact(strDate, "MM/dd/yyyy", CultureInfo.InvariantCulture);
        DateTime endDt = DateTime.ParseExact(endDate, "MM/dd/yyyy", CultureInfo.InvariantCulture);

        SqlConnection con = new SqlConnection(connValue);
        SqlCommand cmd = new SqlCommand();

        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Connection = con;

        cmd.CommandText = "testSP";

        SqlParameter prm = cmd.Parameters.Add("@ad_startDate", SqlDbType.DateTime);
        prm.Value = strDt;

        prm = cmd.Parameters.Add("@ad_endDate", SqlDbType.DateTime);
        prm.Value = endDt;

        prm = cmd.Parameters.Add("@ai_workDays", SqlDbType.Int);
        prm.Direction = ParameterDirection.Output;

        //prm = cmd.Parameters.Add("@as_errMsg", SqlDbType.VarChar);
        //prm.Direction = ParameterDirection.Output;

        con.Open();
        SqlDataReader dr = cmd.ExecuteReader();
        while (dr.Read())
            Console.WriteLine(dr.GetString(0));
        con.Dispose();
        con.Close();

        return cmd.Parameters[2].Value.ToString();
    }
    protected void gvJoborder_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            Label qs = (Label)e.Row.FindControl("lblQS");

            Label dc = (Label)e.Row.FindControl("lblDC");

            Label jobNo = (Label)e.Row.FindControl("lblJobNo"); //

            Label lblJobRecDate = (Label)e.Row.FindControl("lblCmtRecDate");

            Label lblJobStatus = (Label)e.Row.FindControl("lblJobStatus");

            Label _lblPriority = (Label)e.Row.FindControl("lblPriority");


            // string jobOrderStat = Convert.ToInt16(lblJobStatus.Text);

            string jobOrderStat = lblJobStatus.Text;    //On-going

            if ((lblJobRecDate.Text != ""))       //& (lblJobStatus.Text.Equals("Under Process with EBSD"))
            {
                string elapsedDays = getDaysByGivenEndDate(lblJobRecDate.Text, System.DateTime.Now.ToString());
                Label WorkDays = (Label)e.Row.FindControl("lblDays");
                int extraDays = Convert.ToInt16(WorkDays.Text);
                extraDays = (extraDays / 2);

                int totalDays = Convert.ToInt16(WorkDays.Text) + extraDays;

                if ((jobOrderStat.Equals("On-going")) || (jobOrderStat.Equals("Pending")) || (jobOrderStat.Equals("On Hold")))
                {
                    if (totalDays < Convert.ToInt16(elapsedDays))
                    {
                        e.Row.BackColor = System.Drawing.Color.LightPink;
                        e.Row.ForeColor = System.Drawing.Color.Red;

                        e.Row.Font.Bold = true;

                        jobNo.BackColor = System.Drawing.Color.Yellow;
                        e.Row.Cells[1].BackColor = System.Drawing.Color.White;
                    }
                    else if (Convert.ToInt16(WorkDays.Text) < Convert.ToInt16(elapsedDays))
                    {
                        e.Row.BackColor = System.Drawing.Color.MistyRose;


                        jobNo.BackColor = System.Drawing.Color.Yellow;
                        e.Row.Cells[1].BackColor = System.Drawing.Color.White;
                    }
                }
            }

            string strQS = qs.Text; string strDC = dc.Text;
            string JobOrderstatus = lblJobStatus.Text;

            if ((JobOrderstatus == "Closed") || (JobOrderstatus == "Cancelled") || (JobOrderstatus == "Completed") || (JobOrderstatus == "Rejected"))
            {

            }
            else
            {
                if ((strQS == "") & (strDC == ""))
                {
                    jobNo.BackColor = System.Drawing.Color.Red;
                    e.Row.Cells[1].BackColor = System.Drawing.Color.Red;
                }
            }


            if (_lblPriority.Text.Equals("1"))
            {
                jobNo.BackColor = System.Drawing.Color.Gray;
                e.Row.Cells[1].BackColor = System.Drawing.Color.DarkGoldenrod;
                e.Row.BackColor = System.Drawing.Color.DarkGoldenrod;
                e.Row.ForeColor = System.Drawing.Color.Black;

            }

            LinkButton l = (LinkButton)e.Row.FindControl("btnDelete");
            l.Attributes.Add("onclick", "javascript:return " + "confirm('Are you sure you want to delete this Job')");
            l.CssClass = "btndelete";

        }
    }
    private void bindGridView()
    {
        gvJoborder.DataSource = Session["ChartJobs"];
        gvJoborder.DataBind();

    }
    protected void btnClear_Click(object sender, EventArgs e)
    {
        Session["ProjectCode"] = null;

        ClearData();

        DataTable dt = new DataTable();

        dt = FillTab2(0, "");     //  SearchJob

        // Session["ChartJobs"] = dt;     

        gvJoborder.DataSource = dt;
        gvJoborder.DataBind();

        lblCnt.Text = dt.Rows.Count.ToString();
    }
    private void ClearData()
    {

        ddlJobType.SelectedIndex = 0;
        ddlJobStatus_.SelectedIndex = 0;

        ddlAffair.SelectedIndex = 0;
        ddlDept.SelectedIndex = 0;
        ddlPrjCode.SelectedIndex = 0;
        ddlPrjCode.SelectedIndex = 0;
        ddlVendor.SelectedIndex = 0;
        ddlContractor.SelectedIndex = 0;
        ddlQS.SelectedIndex = 0;


        ddlPrjCode.SelectedItem.Text = "";

        ddlReqType.SelectedIndex = 0;

        txtTitle.Text = "";
        txtdept.Text = "";

        txtJobNo.Text = "";
        txtDocRefNo.Text = "";
        txtPrjNo.Text = "";
        txtToDate.Text = "";
        txtClsDocRefNo.Text = "";

    }
    protected void gvJoborder_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandArgument != "")
        {
            int jobid = Convert.ToInt16(e.CommandArgument);
            switch (e.CommandName)
            {
                case "EditJobid":

                    ReplytoCloseCommittedJobs(jobid);

                    // Response.Redirect("DefaultGrid.aspx");

                    break;

                case "DeleteJobid":

                    AccessRightsForDelete();

                    if (!userRightsColl.Contains("3"))
                    {
                        int flag2 = (new JobOrderData().InsertDeletedJobOrder(jobid, Session["UserDisplayName"].ToString(), "", 0)); // insert in to temp JobOrder table

                        int flag = (new JobOrderData().DeleteJobOrder(jobid));

                        new JobOrderData().DeactivateDocumentForJobDelete(jobid);

                        new JobOrderData().UpdateIsConfirmFalseOnJobDelete(jobid);

                        if (flag > 0)
                            loadData();
                    }

                    break;
            }
        }
    }
    private void AccessRightsForDelete()
    {
        if (userRightsColl.Contains("3"))   //Add New Project
        {
            Session["lblText"] = "You are not allowed to delete a Job Order.Please contact system Administrator for further inquiry.";
            Session["lblSub"] = "Restricted Access to delete a Job Order.";
            Session["lblBody"] = "This is in reference to Restricted Access to delete a Job Order. I would like to inquire about the restriction.";


            string url = "RestrictedMsgWindow.aspx";
            string s = "window.open('" + url + "', 'popup_window', 'width=500,height=250,left=100,top=100,resizable=yes,scrollbars=yes');";
            ClientScript.RegisterStartupScript(this.GetType(), "script", s, true);
        }
    }

    private void ReplytoCloseCommittedJobs(int jobid)
    {
        if (userRightsColl.Contains("9"))   //Add New Document
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('You have no privilege to this action,Contact administrator')</script>", false);
            return;
        }
        else
        {
            Session["ReplyToClose"] = "1";
            Session["DocCategoryID"] = "2";
            Session["DocID"] = null;
            Session["UrlRef"] = "~/JobOrder/JobOrder.aspx";
            Session["JobID"] = jobid;
            Response.Redirect("~/Documents/DocumentDetails.aspx", false);
        }
    }
    protected void OpenWindow(object sender, EventArgs e)
    {
        if (userRightsColl.Contains("2"))   //Add New Project
        {
            Session["lblText"] = "You are not allowed to Add New Job Order.Please contact system Administrator for further inquiry.";
            Session["lblSub"] = "Restricted Access to Add New Job Order.";
            Session["lblBody"] = "This is in reference to Restricted Access to Add New Job Order. I would like to inquire about the restriction.";


            string url = "RestrictedMsgWindow.aspx";
            string s = "window.open('" + url + "', 'popup_window', 'width=500,height=250,left=100,top=100,resizable=yes,scrollbars=yes');";
            ClientScript.RegisterStartupScript(this.GetType(), "script", s, true);

        }
        else if (Session["SectionID"].ToString().Equals("41"))
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "Popup", "<script>alert('This is not applicable to all employees from EBSD Payment Section.')</script>", false);
            return;
        }
        else
        {
            Response.Redirect("~/DCLog/DCNewJob.aspx", false);
        }
    }
    protected void btnBack_Click(object sender, EventArgs e)
    {
        if (Session["UrlRef"] != null)
            Response.Redirect(Session["UrlRef"].ToString(), false);
        else
            Response.Redirect("~/JobOrder/Default.aspx", false);
    }
    protected void lnkBtnNonCmtJobID_Click(object sender, EventArgs e)
    {
        try
        {
            LinkButton lnkJobID = (LinkButton)sender;
            GridViewRow gvr = (GridViewRow)lnkJobID.NamingContainer;
            Session["ProjectCode"] = ((HtmlGenericControl)gvr.FindControl("divProjectCode")).InnerText;

            Session["UrlRef"] = Request.Url.AbsoluteUri;
            Response.Redirect("~/JobOrder/SearchJobMstr.aspx?Project_Code = " + Session["ProjectCode"] + "", false);

        }
        catch
        {

        }
    }
    protected void txtJobNo_TextChanged(object sender, EventArgs e)
    {
        Session["OnGoingJobStatus"] = null;

        DataTable dt = new DataTable();
        dt = PartialSearchDCULogJobNo();

        gvJoborder.DataSource = dt;
        gvJoborder.DataBind();

        lblCnt.Text = dt.Rows.Count.ToString();
    }
    private DataTable PartialSearchDCULogJobNo()
    {
        DataSet ds = new DataSet();
        try
        {
            string _jobNo = string.Empty;
            if (txtJobNo.Text != "")
                _jobNo = "%" + txtJobNo.Text + "%";

            string _refNo = string.Empty;
            if (txtDocRefNo.Text != "")
                _refNo = "%" + txtDocRefNo.Text + "%";

            string _contractNo = string.Empty;
            if (txtPrjNo.Text != "")
                _contractNo = "%" + txtPrjNo.Text + "%";

            string _clsrefNo = string.Empty;
            if (txtClsDocRefNo.Text != "")
                _clsrefNo = "%" + txtClsDocRefNo.Text + "%";


            ds = (new JobOrderData().PartialSearchDCLog(_jobNo, _refNo, _contractNo, _clsrefNo));       //

        }
        catch (Exception ex)
        {

        }

        return ds.Tables[0];
    }
    protected void btnGraph_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/JobOrder/TeamWiseJobsChart.aspx", false);
    }
    protected void btnPrint_Click(object sender, EventArgs e)
    {
        if ((userRightsColl.Count == 0) || (!userRightsColl.Contains("2")))
        {
            try
            {
                ScriptManager.RegisterStartupScript(this, typeof(Page), "printGrid", "printGrid();", true);
            }
            catch { }
        }
    }
    protected void ddlVendor_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void ddlQS_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    
    protected void btnExcel_Click(object sender, EventArgs e)
    {
        ExportToExcel_Sree();

        //btnExportToExcel();
    }
    //public override void VerifyRenderingInServerForm(Control control)
    //{
    //    /* Verifies that the control is rendered */
    //}
    private void btnExportToExcel()
    {
        try
        {
            Response.Clear();
            Response.Buffer = true;
            Response.AddHeader("content-disposition", "attachment;filename=GridViewExport.xls");
            Response.Charset = "";
            Response.ContentType = "application/vnd.ms-excel";
            using (StringWriter sw = new StringWriter())
            {
                HtmlTextWriter hw = new HtmlTextWriter(sw);

                //To Export all pages
                gvJoborder.AllowPaging = false;

                gvJoborder.DataSource = Session["ChartJobs"];
                gvJoborder.DataBind();

                //gvJoborder.HeaderRow.BackColor = Color.White;
                foreach (TableCell cell in gvJoborder.HeaderRow.Cells)
                {
                    cell.BackColor = gvJoborder.HeaderStyle.BackColor;
                }
                //DataTable dtSearchDCLog = (DataTable)Session["ChartJobs"];
                foreach (GridViewRow row in gvJoborder.Rows)
                {
                    row.BackColor = Color.White;
                    foreach (TableCell cell in row.Cells)
                    {
                        if (row.RowIndex % 2 == 0)
                        {
                            cell.BackColor = gvJoborder.AlternatingRowStyle.BackColor;
                        }
                        else
                        {
                            cell.BackColor = gvJoborder.RowStyle.BackColor;
                        }
                        cell.CssClass = "textmode";
                    }
                }
                gvJoborder.RenderControl(hw);

                //style to format numbers to string
                string style = @"<style> .textmode { } </style>";
                Response.Write(style);
                Response.Output.Write(sw.ToString());
                Response.Flush();
                Response.End();
            }
            gvJoborder.AllowPaging = true;

        }
        catch (Exception ex)
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "Popup", "<script>alert('Error ocurred while exporting the data to excel file')</script>", false);
            //MessageBox.Show("Error occurred while creating the excel file", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

    }


    #region MyRegion

    private void ExportToExcel_Sree()
    {
        Response.Clear();
        Response.Buffer = true;
        Response.AddHeader("content-disposition", "attachment;filename=GridViewExport.xls");
        Response.Charset = "";
        Response.ContentType = "application/vnd.ms-excel";
        using (StringWriter sw = new StringWriter())
        {
            HtmlTextWriter hw = new HtmlTextWriter(sw);

            //To Export all pages
            gvJoborder.AllowPaging = false;

            gvJoborder.DataSource = Session["ChartJobs"];
            gvJoborder.DataBind();

            gvJoborder.HeaderRow.BackColor = Color.White;
            foreach (TableCell cell in gvJoborder.HeaderRow.Cells)
            {
                cell.BackColor = gvJoborder.HeaderStyle.BackColor;
            }
            foreach (GridViewRow row in gvJoborder.Rows)
            {
                row.BackColor = Color.White;
                foreach (TableCell cell in row.Cells)
                {
                    if (row.RowIndex % 2 == 0)
                    {
                        cell.BackColor = gvJoborder.AlternatingRowStyle.BackColor;
                    }
                    else
                    {
                        cell.BackColor = gvJoborder.RowStyle.BackColor;
                    }
                    cell.CssClass = "textmode";
                }
            }

            gvJoborder.RenderControl(hw);

            //style to format numbers to string
            string style = @"<style> .textmode { } </style>";
            Response.Write(style);
            Response.Output.Write(sw.ToString());
            Response.Flush();
            Response.End();
        }
    }
    public override void VerifyRenderingInServerForm(Control control)
    {
        /* Verifies that the control is rendered */
    }

    #endregion



    protected void ddlAffair_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
}