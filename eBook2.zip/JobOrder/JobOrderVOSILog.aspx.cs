﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Datalayer;
using System.Data;
using System.Data.SqlClient;


public partial class JobOrder_JobOrderVOSILog : System.Web.UI.Page
{
    int _jobID = 0; int _jobVOID = 0;
    string connValue = System.Configuration.ConfigurationManager.ConnectionStrings["EBSDEBookConn"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Page_Init(object sender, EventArgs e)
    {
        _jobID = Convert.ToInt32(Request.QueryString["JobID"]);
        _jobVOID = Convert.ToInt32(Request.QueryString["jobVOID"]);

        Session["StakjobID"] = Convert.ToInt32(Request.QueryString["JobID"]);
        // txtJobNo.Text = Request.QueryString["PSAJobNo"];

        //PSAprjCode
        Session["JobNo"] = Request.QueryString["PSAJobNo"];
        lblJobNo.Text = Session["JobNo"].ToString();
        Session["PrjCode"] = Request.QueryString["PSAprjCode"];

        lblPrjCode.Text = Session["PrjCode"].ToString();

        if (Session["VoSIID"] != null)
            lblVOSIID.Text = Session["VoSIID"].ToString();

        if (!IsPostBack)
        {
            PopulateDropDownBox(drpVODesc, "SELECT voID, voDesc FROM VoCategory ORDER BY voDesc", "voID", "voDesc");

            PopulateDropDownBox(drpVODescTime, "SELECT voID, voDesc FROM VoCategory ORDER BY voDesc", "voID", "voDesc");

            PopulateDropDownBox(drpSH, "SELECT  stakeID, stakeholderName FROM  StakeHolder ORDER BY stakeholderName", "stakeID", "stakeholderName");

            FillTab2(_jobID);

            getMinistryData(_jobID);

            //gridload_SH();

            //  trVOCat.Visible = false;

            if (Request.QueryString["PSAJobNo"].ToString().Contains("A_"))
            {
                lblVOPSA.Text = "Addendum No.";

                trCnsult.Visible = false;
             
                lblCntr.Text = "Consultant/Dept. Amount";
                lblCntrTime.Text = "Consultant/Dept. Time";

                lblVOPSARev.Text = "Addendum Rev No.";

               // trRev.Visible = false;
            }
            else
            {
                lblVOPSA.Text = "VO No.";
                trCnsult.Visible = true;

                lblCntr.Text = "Contractor Amount";
                lblCntrTime.Text = "Contractor Time";

               // lblVOPSARev.Text = "Vo Rev NO.";
            }
        }
        gridload_SH();

        getPSA_CostSavingData(_jobID);

        // getProjectIssueDate();
      

    }

    private void getPSA_CostSavingData(int _void)
    {
        //string qry = " SELECT TOP(1) (contractorAmt-ebsdAmt) as costSaving, (contractorEOT-ebsdEOT) as TimeSaving FROM JobVOSI WHERE (jobID = " + _jobID + ") ";

        string qry = "SELECT ISNULL(SUM(contractorAmt), 0) - ISNULL(SUM(ebsdAmt), 0) AS 'Result',ISNULL(SUM(contractorEOT), 0) - ISNULL(SUM(ebsdEOT), 0) AS 'TimeSaving' FROM JobVOSI WHERE (jobID = " + _jobID + ") ";


        using (SqlConnection cn = new SqlConnection(connValue))
        {
            using (SqlCommand cmd = new SqlCommand())
            {

                cmd.Connection = cn;
                cmd.CommandText = qry;
                cmd.CommandType = CommandType.Text;

                cn.Open();

                using (SqlDataReader dr = cmd.ExecuteReader())
                {
                    while (dr.Read())
                    {
                        txtCostTotal.Text = dr["Result"].ToString();
                        txtTimeTotal.Text = dr["TimeSaving"].ToString();
                    }
                }
            }
        }
    }
    private void PopulateDropDownBox(DropDownList ddlBox, string sqlQuery, string valueMember, string displayName)
    {
        DataTable table = new DataTable();
        try
        {
            using (SqlConnection sqlConn = new SqlConnection(connValue))
            {
                using (SqlDataAdapter da = new SqlDataAdapter(sqlQuery, sqlConn))
                {
                    sqlConn.Open();
                    da.Fill(table);
                }
            }
            //cmbBox.Items.Add("Select");

            ddlBox.DataSource = table;
            ddlBox.DataTextField = displayName;
            ddlBox.DataValueField = valueMember;

            ddlBox.SelectedIndex = -1;
            ddlBox.DataBind();

            ddlBox.Items.Insert(0, new ListItem("--Select--"));
        }
        catch (System.Exception ex)
        {
            throw ex;
        }
    }

    public void getMinistryData(int jobID)
    {
        string qry = " SELECT ministryCode,budgetRefNo,provisionNo,addendumNO,jobRevNo From Job where JobID =  " + jobID;
        using (SqlConnection cn = new SqlConnection(connValue))
        {
            using (SqlCommand cmd = new SqlCommand())
            {
                cmd.Connection = cn;
                cmd.CommandText = qry;
                cmd.CommandType = CommandType.Text;

                cn.Open();

                using (SqlDataReader dr = cmd.ExecuteReader())
                {
                    while (dr.Read())
                    {
                        txtMinCode.Text = dr["ministryCode"].ToString();
                        txtBudgetRef.Text = dr["budgetRefNo"].ToString();
                        txtProvNo.Text = dr["provisionNo"].ToString();

                        if (dr["addendumNO"].ToString() != "")
                             txtVO.Text = dr["addendumNO"].ToString();                          
                        else
                            txtVO.Text = "N/A";

                        txtVORev.Text = dr["jobRevNo"].ToString();
                    }
                }
            }
        }
    }
     public void getProjectIssueDate()
    {
        string qry = "SELECT  description, commitment_no, provision_no, to_company, start_date, revisd_cmpl_date, completion_date, unit_cost  FROM   PCM_CNMT_TABLE WHERE  (commitment_no = '" + lblPrjCode.Text + "')";
        using (SqlConnection cn = new SqlConnection(connValue))
        {
            using (SqlCommand cmd = new SqlCommand())
            {
                cmd.Connection = cn;
                cmd.CommandText = qry;
                cmd.CommandType = CommandType.Text;

                cn.Open();

                using (SqlDataReader dr = cmd.ExecuteReader())
                {
                    while (dr.Read())
                    {
                        txtPrjIssueDate.Text = dr["completion_date"].ToString();
                        
                    }
                }
            }
        }
    }
    
    private void FillTab2(int _jobID)
    {
        try
        {
            DataSet ds = new DataSet();
            ds = (new JobOrderData().GetDDlDetails_JOBVOSI_Time(_jobID));

            //   Convert.ToInt32(txtjobid.Text), txtJobNo.Text, Convert.ToInt32(txtaffair.Text), Convert.ToInt32(txtdept.Text), txtprojcode.Text, txtprojtitle.Text, Convert.ToInt32(txtconsult.Text)));

            if (ds.Tables[0].Rows.Count == 0)
            {
                ds.Tables[0].Rows.Add(ds.Tables[0].NewRow());
            }
            else
            {
                grvJObLog.DataSource = ds;
                grvJObLog.DataBind();

                decimal total_CntrAmnt = ds.Tables[0].AsEnumerable().Sum(row => row.Field<decimal?>("contractorAmt") ?? 00);
                decimal total_consultantAmt = ds.Tables[0].AsEnumerable().Sum(row => row.Field<decimal?>("consultantAmt") ?? 00);
                decimal total_pmcAmt = ds.Tables[0].AsEnumerable().Sum(row => row.Field<decimal?>("pmcAmt") ?? 00);
                decimal total_EbdAmnt = ds.Tables[0].AsEnumerable().Sum(row => row.Field<decimal?>("ebsdAmt") ?? 00);

                // grvPSALog.FooterRow.Cells[1].Text = "Total";

                grvJObLog.FooterRow.Cells[4].HorizontalAlign = HorizontalAlign.Right;
                grvJObLog.FooterRow.Cells[4].Text = total_CntrAmnt.ToString("N1");

                grvJObLog.FooterRow.Cells[5].HorizontalAlign = HorizontalAlign.Right;
                grvJObLog.FooterRow.Cells[5].Text = total_consultantAmt.ToString("N1");

                grvJObLog.FooterRow.Cells[6].HorizontalAlign = HorizontalAlign.Right;
                grvJObLog.FooterRow.Cells[6].Text = total_pmcAmt.ToString("N1");

                grvJObLog.FooterRow.Cells[7].HorizontalAlign = HorizontalAlign.Right;
                grvJObLog.FooterRow.Cells[7].Text = total_EbdAmnt.ToString("N1");

                int total_CntrEot = ds.Tables[0].AsEnumerable().Sum(row => row.Field<int?>("contractorEOT") ?? 0);
                int total_consultantEOT = ds.Tables[0].AsEnumerable().Sum(row => row.Field<int?>("consultantEOT") ?? 0);
                int total_pmcEOT = ds.Tables[0].AsEnumerable().Sum(row => row.Field<int?>("pmcEOT") ?? 0);

                int total_EbdEot = ds.Tables[0].AsEnumerable().Sum(row => row.Field<int?>("ebsdEOT") ?? 0);

                grvJObLog.FooterRow.Cells[10].HorizontalAlign = HorizontalAlign.Right;
                grvJObLog.FooterRow.Cells[10].Text = total_CntrEot.ToString("N1");

                grvJObLog.FooterRow.Cells[11].HorizontalAlign = HorizontalAlign.Right;
                grvJObLog.FooterRow.Cells[11].Text = total_consultantEOT.ToString("N1");

                grvJObLog.FooterRow.Cells[12].HorizontalAlign = HorizontalAlign.Right;
                grvJObLog.FooterRow.Cells[12].Text = total_pmcEOT.ToString("N1");

                grvJObLog.FooterRow.Cells[13].HorizontalAlign = HorizontalAlign.Right;
                grvJObLog.FooterRow.Cells[13].Text = total_EbdEot.ToString("N1");   
            }
        }
        catch (Exception ex)
        {

        }
    }
    protected void btnSave_Click(object sender, EventArgs e)
    {
        int _voID = 0;

        if (lblVOSIID.Text != "")
            _voID = Convert.ToInt32(lblVOSIID.Text);
        else
            _voID = 0;

        int voCatID = 0; int voTimeCatID = 0;

        if (drpVODesc.SelectedIndex != 0)
            voCatID = Convert.ToInt32(drpVODesc.SelectedValue);

        if (drpVODescTime.SelectedIndex != 0)
            voTimeCatID = Convert.ToInt32(drpVODescTime.SelectedValue);

        Boolean chkVOActive = true;
        chkVOActive = chkActive.Checked;

        // We have to pass contract amount whre name as consultamount : dont change

       // InsertUpdateJobVOSI

        new JobOrderData().AddUpade_JOBVOandSI(_voID, _jobID, txtCntrAmnt.Text, txtContractTime.Text, txtPmcAmnt.Text, txtPmcTime.Text, txtEbsdAmnt.Text, txtEbsdTime.Text, txtCnsltAmnt.Text, txtCnsltTime.Text, txtVO.Text, txtSI.Text, txtIssueDate.Text, txtPrjIssueDate.Text, txtRemarks.Text, Session["UserDisplayName"].ToString(), "", voCatID, chkVOActive, voTimeCatID, txtRemarksTime.Text, Convert.ToInt32(Session["UserID"]), txtClaimNO.Text, txtSIRevNo.Text, txtSIRevDate.Text);

        ClearData();
        FillTab2(_jobID);

        getPSA_CostSavingData(_jobID);

    }
    private void ClearData()
    {
        txtCntrAmnt.Text = "";
        txtCnsltAmnt.Text = "";
        txtPmcAmnt.Text = "";
        txtEbsdAmnt.Text = "";

        txtContractTime.Text = "";
        txtCnsltTime.Text = "";
        txtPmcTime.Text = "";
        txtEbsdTime.Text = "";
        txtRemarks.Text = "";

        txtRemarksTime.Text = "";

        lblVOSIID.Text = "";

       // txtVO.Text = "";
        txtSI.Text = "";

        txtIssueDate.Text = "";
        txtPrjIssueDate.Text = "";

        drpVODesc.SelectedIndex = -1;
        drpVODescTime.SelectedIndex = -1;


        txtSIRevDate.Text = "";

        txtClaimNO.Text = "";

        txtSIRevNo.Text = "";


    }
    protected void btnAdd_Click(object sender, EventArgs e)
    {
        Panel1.Visible = true;
        trstake.Visible = false;

      


        txtClaimNO.Visible = false;
        lblClaim.Visible = false;

        txtSI.Visible = true;
        lblSI.Visible = true;

        trRev.Visible = true;

        ClearData();

        txtSIRevNo.Text = "0";

        // By deafault vo active true while create new vosi
          chkActive.Checked = true;

          getProjectIssueDate();
    }
    protected void grvJObLog_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "ViewEdit")
        {
            string arguments = e.CommandArgument.ToString();
            string[] args = arguments.Split(';');
            if (args[0] != "")
            {
                Panel1.Visible = true;

                int _void = Convert.ToInt32(args[0]);
                
                getVOData(_void);

                Session["VoSIID"] = _void.ToString();

                gridload_SH();

                trstake.Visible = true;
            }
        }
    }
    
    protected void grvJObLog_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        GridViewRow gr = (GridViewRow)grvJObLog.Rows[e.RowIndex];
        Label txtid = (Label)gr.FindControl("lbljobVOID");
        if (txtid.Text != "")
        {
            new JobOrderData().Delete_PSALog(Convert.ToInt32(txtid.Text));
            FillTab2(_jobID);
        }
    }

    protected void grvJObLog_RowEditing(object sender, GridViewEditEventArgs e)
    {

    }
    protected void grvJObLog_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {

    }
    protected void LinkButton_Click(Object sender, EventArgs e)
    {
        if (lblVOSIID.Text != "")
        {
            LinkButton txtBox = (sender as LinkButton);
            Session["txtName"] = txtBox.ClientID;
            Session["JobAdmID"] = lblVOSIID.Text;

            string url = "StakeHolder.aspx?jobVOID = <%#Eval(jobVOID)%>";  //subject=<%#Eval("Address") %>"
            string s = "window.open('" + url + "', 'popup_window', 'width=600,height=600,left=100,top=100,resizable=yes');";
            ClientScript.RegisterStartupScript(this.GetType(), "script", s, true);
        }
    }

    private void getVOData(int _void) // Job Order
    {
        txtClaimNO.Visible = true;
        txtSI.Visible = true;

    
        lblSI.Visible = true;    
        lblClaim.Visible = true;

        string qry = " SELECT jobVOID, jobID, contractorAmt, contractorEOT, pmcAmt, pmcEOT, consultantAmt, consultantEOT, ebsdAmt, ebsdEOT, invSH,voNumber,siNumber, " +
        " REPLACE(CONVERT(NVARCHAR, issueDate, 106), ' ', '/') as issueDate,REPLACE(CONVERT(NVARCHAR, prjCompleteDate, 106), ' ', '/') as prjCompleteDate,  " +
                     " remarks, RemarksForTime,voCatID,VoIssuedate,isVOActive,voTimeCatID,claimNo,siRevNo, REPLACE(CONVERT(NVARCHAR, siRevDate, 106), ' ', '/') as siRevDate FROM JobVOSI WHERE (jobVOID = " + _void + ") ";

        using (SqlConnection cn = new SqlConnection(connValue))
        {
            using (SqlCommand cmd = new SqlCommand())
            {

                cmd.Connection = cn;
                cmd.CommandText = qry;
                cmd.CommandType = CommandType.Text;

                cn.Open();

                using (SqlDataReader dr = cmd.ExecuteReader())
                {
                    while (dr.Read())
                    {
                       // txtVO.Text = dr["voNumber"].ToString();
                        txtSI.Text = dr["siNumber"].ToString();



                        txtIssueDate.Text = dr["issueDate"].ToString();
                        txtPrjIssueDate.Text = dr["prjCompleteDate"].ToString();

                        txtCntrAmnt.Text = dr["contractorAmt"].ToString();
                        txtCnsltAmnt.Text = dr["consultantAmt"].ToString();
                        txtPmcAmnt.Text = dr["pmcAmt"].ToString();
                        txtEbsdAmnt.Text = dr["ebsdAmt"].ToString();

                        txtContractTime.Text = dr["contractorEOT"].ToString();
                        txtCnsltTime.Text = dr["consultantEOT"].ToString();
                        txtPmcTime.Text = dr["pmcEOT"].ToString();
                        txtEbsdTime.Text = dr["ebsdEOT"].ToString();

                        txtRemarks.Text = dr["remarks"].ToString();

                        txtRemarksTime.Text = dr["RemarksForTime"].ToString();                        

                        lblVOSIID.Text = dr["jobVOID"].ToString();

                        if (dr["voCatID"].ToString() != "")
                            drpVODesc.SelectedValue = dr["voCatID"].ToString();

                        if (dr["voTimeCatID"].ToString() != "")
                            drpVODescTime.SelectedValue = dr["voTimeCatID"].ToString();

                        if (dr["isVOActive"].ToString().Equals("True"))
                            chkActive.Checked = true;
                        else
                            chkActive.Checked = false;


                        txtClaimNO.Text = dr["claimNo"].ToString();

                        if (txtSIRevNo.Text == "")
                            txtSIRevNo.Text = "0";
                        else
                            txtSIRevNo.Text = dr["siRevNo"].ToString();

                        txtSIRevDate.Text = dr["siRevDate"].ToString();

                        
                    }
                }
            }
        }
    }
    protected void txtMinCode_TextChanged(object sender, EventArgs e)
    {
        new JobOrderData().UpdateMinistryDataForJob(0, txtMinCode.Text, txtBudgetRef.Text, txtProvNo.Text, lblPrjCode.Text);
    }
    protected void txtBudgetRef_TextChanged(object sender, EventArgs e)
    {
        new JobOrderData().UpdateMinistryDataForJob(0, txtMinCode.Text, txtBudgetRef.Text, txtProvNo.Text, lblPrjCode.Text);
    }
    protected void txtProvNo_TextChanged(object sender, EventArgs e)
    {
        new JobOrderData().UpdateMinistryDataForJob(0, txtMinCode.Text, txtBudgetRef.Text, txtProvNo.Text, lblPrjCode.Text);
    }

    protected void txtIssueDate_TextChanged(object sender, EventArgs e)
    {

    }
    protected void txtPrjIssueDate_TextChanged(object sender, EventArgs e)
    {

    }
    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (lblVOSIID.Text != "")
        {
            Session["JobAdmID"] = lblVOSIID.Text;
            if (drpSH.SelectedIndex != 0)
                new JobOrderData().Add_ddlStakeInfo_StakeHolder(1, Convert.ToInt32(lblVOSIID.Text), Convert.ToInt32(drpSH.SelectedValue), _jobID, Session["UserName"].ToString());

            drpSH.SelectedIndex = 0;
            gridload_SH();
        }
    }
    public void gridload_SH()
    {
        if (lblVOSIID.Text != "")
        {
            DataSet ds = new DataSet();
            ds = (new JobOrderData().GetDDlDetails_StakeHolder(Convert.ToInt32(lblVOSIID.Text)));
            GridView1.DataSource = ds;
            GridView1.DataBind();
        }
    }
    protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "delete")
        {
            string arguments = e.CommandArgument.ToString();
            string[] args = arguments.Split(';');

            string detID = args[0];
            //string jobid = args[1];
            //jobid = "1";

            new JobOrderData().Delete_ddlStakeInfo_StakeHolder(Convert.ToInt32(detID));
            gridload_SH();
        }
    }
    protected void GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        gridload_SH();
    }
    protected void btnBack_Click(object sender, EventArgs e)
    {

    }
    protected void GridView1_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            //DropDownList l = (DropDownList)e.Row.FindControl("ddljobtype");

            //PopulateDropDownBox(l, "SELECT voID,voDesc FROM  VODetails  Order By voDesc ", "voID", "voDesc");  // where JobStatusid in(5,6,7,8)

            //TextBox lm = (TextBox)e.Row.FindControl("jobid");
            //TextBox afr = (TextBox)e.Row.FindControl("TextBox1");
            //TextBox InchargeID = (TextBox)e.Row.FindControl("txtInchargeID");

            //Session["InchargeID"] = InchargeID.Text;

            //string lk = lm.Text;
            //l.ToolTip = InchargeID.Text;

            //l.SelectedValue = afr.Text;

            //Session["StatusVal"] = l.SelectedValue;

            //l.SelectedIndexChanged += new EventHandler(SelectedIndexChanged);      

        }
    }

    protected void SelectedIndexChanged(object sender, EventArgs e)
    {
        DropDownList ddl = (DropDownList)sender;
        if (ddl.SelectedIndex != 0)
        {
            string ID = ddl.ID;
            string g = ddl.SelectedValue;
            string inchargeID = ddl.ToolTip;

            UpdateStakeData(Convert.ToInt32(ddl.SelectedValue), Convert.ToInt32(inchargeID));

            //new JobOrderData().UpdateJobStatus(Convert.ToInt32(inchargeID), Convert.ToInt32(ddl.SelectedValue), Session["UserName"].ToString());           
        }
    }

    private void UpdateStakeData(int catID, int stakID)
    {
        string qry = "Update StakeHolderInfo Set voCatID =@voCatID where infoID = @infoID";
        using (SqlConnection cn = new SqlConnection(connValue))
        {
            using (SqlCommand cmd = new SqlCommand())
            {

                cmd.Connection = cn;
                cmd.CommandText = qry;
                cmd.CommandType = CommandType.Text;

                cn.Open();

                cmd.Parameters.AddWithValue("@voCatID", catID);
                cmd.Parameters.AddWithValue("@infoID", stakID);

                cmd.ExecuteNonQuery();

            }
        }
    }
    protected void btnSearch_Click(object sender, EventArgs e)
    {
        if (lblJobNo.Text.Contains("A_"))
            Response.Redirect("~/JobOrder/SearchAdmData.aspx", false);
        else
            Response.Redirect("~/JobOrder/SearchJobMstr.aspx",false);
    }
   

    protected void grvJObLog_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            //e.Row.Cells[5].Visible = false;       //but the problem is i want to show only if i search by last name           
            if (lblJobNo.Text.Contains("A_"))
            {
                grvJObLog.Columns[5].Visible = false;

                grvJObLog.Columns[4].HeaderText = "Consultant Amount";

               // grvJObLog.Columns[5].Visible = false;


                
            }
        }


        //if (e.Row.RowType == DataControlRowType.DataRow)
        //{
        //   int iCnt = iCnt + 1;

        //    if (iCnt == 1)
        //    {
        //        Label lblAdmID = (Label)e.Row.FindControl("lblAdmID");
        //       int topAdmID = Convert.ToInt32(lblAdmID.Text);
        //    }

        //}
    }
    protected void btnAddClaim_Click(object sender, EventArgs e)
    {
        Panel1.Visible = true;
        trstake.Visible = false;      

        txtSI.Visible = false;
        lblSI.Visible = false;

        txtClaimNO.Visible = true;
        lblClaim.Visible = true;

        trRev.Visible = false;

        ClearData();

        // By deafault vo active true while create new vosi
        chkActive.Checked = true;

        getProjectIssueDate();

    }
}