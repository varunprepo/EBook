﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Web.UI.HtmlControls;
using Datalayer;
using System.Text;
using System.IO;

public partial class JobOrder_DCLogHomePage : System.Web.UI.Page, ICallbackEventHandler
{
    string connValue = System.Configuration.ConfigurationManager.ConnectionStrings["EBSDEBookConn"].ConnectionString;
    string connValueOracle = System.Configuration.ConfigurationManager.ConnectionStrings["SurveyConnOracle"].ToString();
    
    IList<string> userRightsColl = null;
    string profile_Name = string.Empty;
    UtilityClass uCls = null;
    static int _currentUserID = 0;

    protected void WireUpJSFunctions()
    {
        ClientScriptManager csm = Page.ClientScript;
        string callbackRef = csm.GetCallbackEventReference(this, "arg", "displayTasksData", "context");
        string callbackScript = "function retrieveTasks(arg, context) {" + callbackRef + "}";
        csm.RegisterClientScriptBlock(this.GetType(), "retrieveTasks", callbackScript, true);

        //callbackRef = csm.GetCallbackEventReference(this, "arg", "setDaysToAct", "context");
        //callbackScript = "function countWorkDays(arg, context) {" + callbackRef + "}";
        //csm.RegisterClientScriptBlock(this.GetType(), "countWorkDays", callbackScript, true);
    }

    string opMsg = null;
    public string GetCallbackResult()
    {         
        return opMsg;
    }

    public void RaiseCallbackEvent(string eventArgument)
    {
        if (eventArgument != "")
        {
            //if (uCls == null)
            //    uCls = new UtilityClass(this.Page);
            //if (eventArgument.Split(',')[1].ToString().Contains("txtDaysToAct"))
            //{
            try
            {
                Session["TabClicked"] = eventArgument;
                //if (Session["TabClicked"] == null)
                //{
                //    DisplayTasks("");
                //}
                //else
                //{
                //    DisplayTasks(Session["TabClicked"].ToString());
                //}
                opMsg = "";                       
            }
            catch (Exception ex)
            {
                opMsg = "Error Occurred while retrieving the data";
            }

        }
        //throw new NotImplementedException();
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["UserName"] == null)
        {
            Response.Redirect("~/LoginPage.aspx", false);
            return;
        }

        if(Session["SectionID"].ToString()!="11")
        {
            grayrow1.Visible = false;             
            grayrow2.Visible = false;
            searchPlanningTeamRow.Visible = false;
        }

        _currentUserID = Convert.ToInt32(Session["UserID"]);
        userRightsColl = (IList<string>)Session["UserRightsColl"];
        WireUpJSFunctions();

        try
        {
            DisplayTasks("");                
            OnPageLoad();
            //if (!IsPostBack)
            //{
            //    if (Session["TabClicked"] == null)
            //    {
            //        DisplayTasks("");
            //    }
            //    OnPageLoad();
            //    //else
            //    //{
            //    //    DisplayTasks(Session["TabClicked"].ToString());
            //    //}
            //    //DirectoryInfo rootInfo = new DirectoryInfo(ConfigurationManager.AppSettings["SurveyFolderPath"].ToString() + "\\YEAR_" + _jobID.Substring(0, 4)); //+"\\"+_jobID);
            //    //PopulateTreeView(rootInfo, null);
            //    //if (fileUpload.PostedFile == null)
            //    //{                   
            //    //DisplayUploadedFiles(CreateFolder(false));
            //    //}
            //    //InsertOrUpdateSurveyInfoSQLServer();                               
            
                
            //}
        }
        catch (Exception ex)
        {
            ClientScript.RegisterClientScriptBlock(Page.GetType(), "Message", "alert(" + ex.Message.Replace("'", "") + ");", true);
            //'Error Occurred while retrieving the files inside the directory. Please contact system Administrator for further inquiry.'
        }             
    }

    private void OnPageLoad()
    {
        getMyDocumentChart();

        //getUnReadInchargeData();

        getOnGoingTasksPerSection_New();

        //getTasksWaitingForCompletion();

        // Impotant Function : Which used to change docStatus as Forfollowup, if actionduedate is lessthan current date globally

        new JobOrderData().UpdateForFoloowupDocstatus();
        new JobOrderData().UpdateUserAutoReplyStatus();

        if (Session["userProfileID"].Equals("8")) // DC Control
        {
            trOnGo.Visible = false;             // Forsly Commented Chk
            onGoingTasksPerStaffChart.Visible = false;

            // trAllDoc.Visible = false;

            btnSearchEot.Visible = false;
        }
        else if (Session["userProfileID"].Equals("5")) // Cost Control Staff
        {
            trOnGo.Visible = false;
            onGoingTasksPerStaffChart.Visible = false;
            // trAllDoc.Visible = false;
        }
        else
        {
            getOnGoingTasksPerStaffChart();
            // trAllDoc.Visible = true;
        }

        if (Session["SectionID"].Equals("2"))
        {
            btnCPProject.Visible = true;
            btnNCPProject.Visible = true;
            btnSearchDcLog.Text = "Search Payment";

            btnSearchAdmLog.Text = "Search Addendum JobOrder Log";
        }
        else if (Session["SectionID"].Equals("9"))
        {
            btnCPProject.Visible = false;
            btnNCPProject.Visible = false;
            btnSearchDcLog.Text = "Search SR Request";

            btnSearchAdmLog.Text = "View Ongoing Request";

            getUnReadIncharge_LeadData();

            btnMyChart.Visible = false;

            btnSearchEot.Visible = false;
        }
        else if (Session["SectionID"].Equals("22"))
        {
            btnCPProject.Visible = false;
            btnNCPProject.Visible = false;

            //btnSearchDcLog.Text = "Search SR Request";
            //btnSearchAdmLog.Text = "View Ongoing Request";

            //getUnReadIncharge_LeadData();

            btnNewJob.Text = "Add New Task";
            btnSearchDcLog.Text = "Search GS Request";
            btnSearchAdmLog.Text = "View Ongoing Request";

            btnSearchEot.Visible = false;
        }
        else if (Session["SectionID"].Equals("11"))
        {
            btnSearchAdmLog.Text = "Pending Request From DC";

            btnCPProject.Visible = false;
            btnNCPProject.Visible = false;
        }
        else
        {
            btnCPProject.Visible = false;
            btnNCPProject.Visible = false;
            btnSearchDcLog.Text = "Search Job Order";

            btnSearchAdmLog.Text = "Search Addendum JobOrder Log";
            btnSearchEot.Visible = true;
        }

        if (!Session["SectionID"].Equals("9"))
            trSRLead.Visible = false;

        if (Session["SectionID"].Equals("10"))
        {
            btnNewJobBSReview.Visible = true;
            btnSearchBLReviewLog.Visible = true;
        }
        else
        {
            btnNewJobBSReview.Visible = false;
            btnSearchBLReviewLog.Visible = false;
        }
    }
     
    private void DisplayTasks(string tabName)
    {
        //string selectedNode = null;

        //if (TreeView1.SelectedNode.Text != "")
        //{
        //    Session["SelectedNode"] = TreeView1.SelectedNode.Text;
        //    selectedNode = Session["SelectedNode"].ToString();
        //}
        //else
        //{
        //    selectedNode = Session["SelectedNode"].ToString();
        //}         

        if (tabName == "")
        {
            getUnReadInchargeData();
            if (Session["isTeamLeader"] != null)
            {
                if (Session["isTeamLeader"].Equals("1"))
                {
                    getTasksWaitingForCompletion();
                }
                else
                {
                    //tasksWaitingForComp.Visible = false;
                    liTasksToBeCompleted.Visible = false;
                }
            }
        }
        else
        {
            //tab1.InnerHtml = "";
            //tab2.InnerHtml = "";    
            //var sb = new StringBuilder();
            if (Session["TabClicked"].ToString().Equals("My New Task"))
            {
                getUnReadInchargeData();                 
                //tab1.RenderControl(new HtmlTextWriter(new StringWriter(sb)));
                //divText = sb.ToString(); //.Replace("\r\n\t\t\t \r\n\t\t", "").Replace("<div id=\"ctl00_ContentPlaceHolder1_tab1\" class=\"tab\">", "").Replace("</div>", ""); //.Replace("<span id=''","").Replace("</span>","");
            }
            else
            {
                if (Session["isTeamLeader"] != null)
                {
                    if (Session["isTeamLeader"].Equals("1"))
                    {
                        getTasksWaitingForCompletion();
                    }
                    else
                    {
                        tasksWaitingForComp.Visible = false;
                    }
                }
                //tab2.RenderControl(new HtmlTextWriter(new StringWriter(sb)));
                //divText = sb.ToString(); //.Replace("\r\n\t\t\t \r\n\t\t", "").Replace("<div id=\"ctl00_ContentPlaceHolder1_tab2\" class=\"tab\">", "").Replace("</div>", ""); //.Replace("<span id=''","").Replace("</span>","");
            }                

            //}
            //else
            //{
            //    //tab2.Visible = false;

            //    divText = "";
            //    //ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('No File(s) found.')</script>", false);
            //}

        }

    }

   
    protected void btnSearchDcLog_Click(object sender, EventArgs e)
    {
        if (Session["SectionID"].Equals("3"))
        {
            string strUpdateJob = Request.Url.AbsoluteUri;
            Session["UrlRef"] = strUpdateJob;        
            Session["SearchMyDocs"] = "1";
            Response.Redirect("~/DCLog/SearchDCLog.aspx", false);
        }
        else if (Session["SectionID"].Equals("2"))
        {
            string strUpdateJob = Request.Url.AbsoluteUri;
            Session["UrlRef"] = strUpdateJob;
            if (userRightsColl.Contains("19"))   //Add New Project
            {
                ClientScript.RegisterClientScriptBlock(this.GetType(), "Popup", "<script>alert('You have no privilege to Search Job Order Log.')</script>", false);
                return;
            }
            else
            {
                Response.Redirect("~/Payments/SearchPayment.aspx", false);
            }
        }
        else if (Session["SectionID"].Equals("6")) //Plannig n schedule
        {
           Response.Redirect("~/Planning/SearchPSLog.aspx", false);     

           // Response.Redirect("SearchJobMstr.aspx",false);
        }
        else if (Session["SectionID"].Equals("9"))
        {
            Response.Redirect("~/Planning/Search_SRInfo.aspx", false);       
        }
        else if (Session["SectionID"].Equals("10"))
        {
            Response.Redirect("~/ManagerTask/SerachTask.aspx", false);    
        }
        else if (Session["SectionID"].Equals("11"))
        {
            Response.Redirect("~/GIS/SearchGISData.aspx", false);
        }
        else if (Session["SectionID"].Equals("22"))
        {
            Response.Redirect("~/GenaralService/SearchGSRequest.aspx", false);
        }
        else 
        {
            string strUpdateJob = Request.Url.AbsoluteUri;
            Session["UrlRef"] = strUpdateJob;

            if (userRightsColl.Contains("11"))
            {
                ClientScript.RegisterClientScriptBlock(this.GetType(), "Popup", "<script>alert('You have no privilege to Search Addendum Log.')</script>", false);
                return;
            }
            else
            {
                Response.Redirect("SearchJobMstr.aspx", false);
            }
        }        
    }      
    protected void btnNewJob_Click(object sender, EventArgs e)
    {
        string strUpdateJob = Request.Url.AbsoluteUri;
        Session["UrlRef"] = strUpdateJob;

        if (Session["SectionID"].ToString().Equals("9"))
        {
            if (Session["UserID"].Equals("105")) // temporary
            {
                Response.Redirect("~/Planning/CreateSRRequest.aspx");
            }
        }
        else if (userRightsColl.Contains("2"))   //Add New Project
        {
            Session["lblText"] = "You are not allowed to Add New Job Order.Please contact system Administrator for further inquiry.";
            Session["lblSub"] = "Restricted Access to Add New Job Order.";
            Session["lblBody"] = "This is in reference to Restricted Access to Add New Job Order. I would like to inquire about the restriction.";

            string url = "RestrictedMsgWindow.aspx";
            string s = "window.open('" + url + "', 'popup_window', 'width=500,height=250,left=100,top=100,resizable=yes,scrollbars=yes');";
            ClientScript.RegisterStartupScript(this.GetType(), "script", s, true);
        }
        else if (Session["SectionID"].ToString().Equals("2"))
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "Popup", "<script>alert('This is not applicable to all employees from EBSD Payment Section.')</script>", false);
            return;
        }
        else if (Session["SectionID"].ToString().Equals("10"))
        {
            if (Session["UserProfileID"].Equals("21"))
                Response.Redirect("~/JobOrder/JobEntryForm.aspx", false);      
            else
               Response.Redirect("~/ManagerTask/CreateTask.aspx", false);    //   GenaralService       
        }
        else if (Session["SectionID"].ToString().Equals("11") && !userRightsColl.Contains("2")) //2-->Create Job
        {
            Response.Redirect("~/GIS/GISServiceReq.aspx", false);    //    

            //Response.Redirect("~/GIS/GISPortal.aspx", false);    
          
        }
        else if (Session["SectionID"].ToString().Equals("22"))
        {
            Response.Redirect("~/GenaralService/CreateGSRequest.aspx", false);    //          
        }
        else
        {
            if (Session["SectionID"].Equals("3"))
            {
                Response.Redirect("~/DCLog/DCNewJob.aspx");
            }
            else if (Session["SectionID"].Equals("1"))
            {
                string url = "JobEntryForm.aspx";
                string s = "window.open('" + url + "', 'popup_window', 'width=990,height=700,left=100,top=100,resizable=yes,scrollbars=yes');";
                ClientScript.RegisterStartupScript(this.GetType(), "script", s, true);
            }
            else if (Session["SectionID"].Equals("6"))
            {
                string url = "JobEntryForm.aspx";
                string s = "window.open('" + url + "', 'popup_window', 'width=990,height=700,left=100,top=100,resizable=yes,scrollbars=yes');";
                ClientScript.RegisterStartupScript(this.GetType(), "script", s, true);
            }
            else
            {
                ClientScript.RegisterClientScriptBlock(this.GetType(), "Popup", "<script>alert('You have no privilege to Add New Request.')</script>", false);
            }
        }

       // ==============================================================================================================

        //if (userRightsColl.Contains("2"))
        //{
        //    ClientScript.RegisterClientScriptBlock(this.GetType(), "Popup", "<script>alert('You have no privilege Create Request.')</script>", false);
        //    return;
        //}
        //else
        //{
        //    Response.Redirect("~/ManagerTask/CreateTask.aspx", false);
        //}




        //if (userRightsColl.Contains("18"))
        //{
        //    ClientScript.RegisterClientScriptBlock(this.GetType(), "Popup", "<script>alert('You have no privilege to Add Payment Request.')</script>", false);
        //    return;
        //}
        //else
        //{
        //    Session["PrjCP/NCP"] = "CP";
        //    Application["PrjType"] = Session["PrjCP/NCP"];
        //    Response.Redirect("~/Payments/AddNewPayment.aspx", false);
        //}






     //   =========================================================================================================



    }

    protected void btnSearchMyDoc_Click(object sender, EventArgs e)
    {
        //string strUpdateJob = Request.Url.AbsoluteUri;
        //Session["UrlRef"] = strUpdateJob;
        //Session["SearchAllDocs"] = "1";
        //Response.Redirect("~/Documents/DocumentRegister.aspx", false);

        string strUpdateJob = Request.Url.AbsoluteUri;
        Session["UrlRef"] = strUpdateJob;       
        Session["SearchMyDocs"] = "1";
        Response.Redirect("~/Documents/SearchDocument.aspx", false);
    }

    protected void onGoingTasksPerStaffChart_Click(object sender, ImageMapEventArgs e)
    {
        Session["ShortName"] = e.PostBackValue.ToString();
        Session["ActionBy"] = null;
        Session["ActionBy"] = e.PostBackValue.ToString();

        if (Session["SectionID"].Equals("9"))
            Response.Redirect("~/Planning/ViewSRInfo.aspx", false);
        else if (!Session["SectionID"].Equals("4"))
            Response.Redirect("~/JobOrder/SearchAllJobs.aspx", false);
        else
            Response.Redirect("~/Survey/SurveyStaffJobs.aspx", false);
    }

    private void IsUserTLAndFillGV()
    {
        if (Session["isTeamLeader"] != null)
        {
            if (Session["isTeamLeader"].ToString().Equals("1"))
            {
                getUnReadIncharge_LeadData();
            }
        }
    }
    protected void gridTasks_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        if (Session["getUnreadInChargeData"] != null)
        {
            gridTasks.PageIndex = e.NewPageIndex;
            gridTasks.DataSource = (DataTable)Session["getUnreadInChargeData"];
            gridTasks.DataBind();
            //getUnReadInchargeData(); 
            IsUserTLAndFillGV();
            OnPageLoad();            
        }
        else
        {
            Response.Redirect("~/LoginPage.aspx", false);
        }
    }
    protected void tasksWaitingForComp_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        if (Session["getTasksWaitingForComp"] != null)
        {
            tasksWaitingForComp.PageIndex = e.NewPageIndex;
            tasksWaitingForComp.DataSource = (DataTable)Session["getTasksWaitingForComp"];
            tasksWaitingForComp.DataBind();
            IsUserTLAndFillGV();
            OnPageLoad();            
        }
        else
        {
            Response.Redirect("~/LoginPage.aspx", false);
        }
    }
    protected void myDocsChart_Click(object sender, ImageMapEventArgs e)
    {   
        string strUpdateJob = Request.Url.AbsoluteUri;
        Session["UrlRef"] = strUpdateJob;

        uCls = new UtilityClass(this.Page);
        uCls.ResetTheSessionVariables();
        Session["MyChartClickDocStatus"] = e.PostBackValue;
        int docStatusID = 1;
        if (e.PostBackValue.Equals("Open"))
            docStatusID = 1;
        else if (e.PostBackValue.Equals("For Follow Up"))
            docStatusID = 2;
        else if (e.PostBackValue.Equals("Pending"))
            docStatusID = 3;

        Response.Redirect("~/Documents/SearchDocument.aspx?docStatID=" + docStatusID, false);
    }
    protected void OngoingJobsClick(object sender, ImageMapEventArgs e)
    {
        // Basic Materials,A_ (PSA Contract),Cost Control Section,Payment Request,

        //Comitted Contract,Cost Estimate,Planning Schedule(Baseline),Non Committed Contracts

        Session["ActionBy"] = null;

        string sectionName = Session["SectionName"].ToString();

        Session["OverDueName"] = e.PostBackValue.ToString();

        Session["OverDue"] = "Yes";        

        Session["OnGoingJobStatus"] = e.PostBackValue;

        // overdueJobs_old(sectionName);   

        // overdueJobs(Session["ShortName"].ToString());

        //Planning Schedule (Baseline)    //Cost Estimate       //A_ (PSA Contract) 


        if (Session["UserProfileID"].Equals("1"))
        {
            if (e.PostBackValue.Equals("Cost Control Section"))
            {
                Response.Redirect("~/DCLog/OverDueJobs.aspx", false);
            }
            else if (e.PostBackValue.Equals("Document Control"))
            {
                Response.Redirect("~/DCLog/OverDueJobs.aspx", false);
            }
            else if (e.PostBackValue.Equals("Payment Section"))
            {
                Response.Redirect("~/Payments/OverDuePayments.aspx", false);
            }
            else if (e.PostBackValue.Equals("Manager Requests"))
            {
                Response.Redirect("~/ManagerTask/OverDueRequests.aspx", false);
            }
            else if (sectionName.Trim().Equals("Engineering Business Support Section"))
            {
                Response.Redirect("~/Planning/ViewSRInfo.aspx", false);
            }
            else
            {

            }
        }
        else
        {
            if (lblOngoingJobs.Text.Equals("My On Going Tasks") & Session["SectionID"].Equals("1"))
            {
                Response.Redirect("~/JobOrder/JobOrder.aspx", false);
            }
            else if (e.PostBackValue.Equals("Manager Requests"))
            {
                Response.Redirect("~/ManagerTask/ViewManagerRequests.aspx", false);
            }
            else if (sectionName.Trim().Equals("Engineering Business Support Section"))
            {
                Response.Redirect("~/Planning/ViewSRInfo.aspx", false);
            }
            else if ((!Session["userProfileID"].Equals("2")) & Session["SectionID"].Equals("3"))
            {
                Response.Redirect("~/DCLog/ViewDCLog.aspx", false);
            }
            else if (Session["SectionName"].ToString().Equals("Cost Control Section") || Session["SectionName"].ToString().Equals("Planning and Scheduling"))
            {
                Response.Redirect("~/DCLog/OverDueJobs.aspx", false);
            }
            else if (sectionName.Equals("Payment Section") || sectionName.Equals("Payment Request"))
            {
                if (lblOngoingJobs.Text.Equals("My On Going Tasks"))
                    Response.Redirect("~/Payments/ViewPayments.aspx", false);
                else
                    Response.Redirect("~/Payments/OverDuePayments.aspx", false);
            }
            else if (sectionName.Trim().Equals("Document Control") || Session["userProfileID"].Equals("2"))           //Document Request     Document Control Section       // sectionName.Equals("Review Baseline Schedule")
            {
                Response.Redirect("~/DCLog/OverDueJobs.aspx", false);
            }
            else if ((e.PostBackValue.Trim().ToString().Equals("Document Control")) && (Session["userProfileID"].Equals("1")))
            {
                Response.Redirect("~/DCLog/OverDueJobs.aspx", false);
            }
            else if ((e.PostBackValue.ToString().Equals("Cost Control Section")) && (Session["userProfileID"].Equals("1")))
            {
                Response.Redirect("~/DCLog/OverDueJobs.aspx", false);
            }
            else if ((e.PostBackValue.ToString().Equals("Payment Section")) && (Session["userProfileID"].Equals("1")))
            {
                Response.Redirect("~/Payments/OverDuePayments.aspx", false);
            }
            else if (lblOngoingJobs.Text.Contains("Over Due") & Session["SectionID"].Equals("3"))
            {
                Response.Redirect("~/DCLog/OverDueJobs.aspx", false);
            }
            else if (lblOngoingJobs.Text.Contains("Over Due") & Session["SectionID"].Equals("22"))
            {
                Session["OverDue"] = "Yes";
                Response.Redirect("~/GenaralService/ViewGSRequests.aspx", false);
            }
            else if (sectionName.Equals("Manager Requests"))
            {
                Response.Redirect("~/ManagerTask/OverDueRequests.aspx", false);
            }
            else if ((!Session["userProfileID"].Equals("11")))
            {
                Session["CategoryID"] = null;
                Session["OverDue"] = "No";
                Response.Redirect("~/GIS/ViewGISRequests.aspx", false); // ViewGISRequests.aspx  //SearchGISData
            }
            else if ((!Session["userProfileID"].Equals("22")))
            {
                Session["OverDue"] = "No";
                Response.Redirect("~/GenaralService/ViewGSRequests.aspx", false);
            }
            else
            {
                ClientScript.RegisterClientScriptBlock(this.GetType(), "Popup", "<script>alert('Restricted Access!')</script>", false);
            }
        }
    }

    private void getOnGoingTasksPerSection_New()
    {
        DataSet dsTndr = new DataSet();

        string sqlQuery = null; int secID = Convert.ToInt32(Session["SectionID"]);
        string strSeriesName = string.Empty;

        if (Session["userProfileID"].ToString().Equals("1"))   // For Admin
        {
            sqlQuery = " SELECT  COUNT(Job.jobID) AS JobCnt, Section.sectionName FROM  JobType INNER JOIN  Job ON JobType.jobTypeID = Job.jobTypeID INNER JOIN Section ON JobType.sectionID = Section.sectionID " +
               " WHERE (Job.jobDueDate < GETDATE()-1) AND (Job.jobStatusID IN (3, 8))  GROUP BY Section.sectionName, JobType.sectionID  UNION " +
                    "SELECT  COUNT(JobOwner.jobOwnerID) AS Expr1, Section.sectionName FROM  JobOwner INNER JOIN  Section ON JobOwner.sectionID = Section.sectionID " +
                          " WHERE  (JobOwner.payID IS NOT NULL) AND (JobOwner.actionDueDate < GETDATE()-1) AND (JobOwner.jobOwnerStatusID <> 7) GROUP BY Section.sectionName";
            strSeriesName = "sectionName";

            lblOngoingJobs.Text = "Over Due Job Order In All Sections";
        }
        else if (!Session["userProfileID"].ToString().Equals("1") && Session["SectionID"].ToString().Equals("7") && !userRightsColl.Contains("1"))    // User Not Admin but he belongs to all section and he contain user rights no  -1   (  7 for all section )
        {
            sqlQuery = " SELECT  COUNT(Job.jobID) AS JobCnt, Section.sectionName FROM  JobType INNER JOIN  Job ON JobType.jobTypeID = Job.jobTypeID INNER JOIN   Section ON JobType.sectionID = Section.sectionID " +
               " WHERE (Job.jobDueDate < GETDATE()-1) AND (Job.jobStatusID IN (3, 8))  GROUP BY Section.sectionName, JobType.sectionID  UNION " +
                    "SELECT  COUNT(JobOwner.jobOwnerID) AS Expr1, Section.sectionName FROM  JobOwner INNER JOIN  Section ON JobOwner.sectionID = Section.sectionID " +
                          " WHERE  (JobOwner.payID IS NOT NULL) AND (JobOwner.actionDueDate < GETDATE()-1) AND (JobOwner.jobOwnerStatusID <> 7) GROUP BY Section.sectionName";

            strSeriesName = "sectionName";

            lblOngoingJobs.Text = "Over Due Job Order In All Sections";
        }
        else if (Session["SectionID"].ToString().Equals("1"))          // Cost Control Section
        {
            if (Session["UserProfileID"].ToString().Contains("2"))        // Admin Section
            {
                sqlQuery = "SELECT COUNT(Job.jobID) AS JobCnt, JobType_1.jobTypeName FROM JobType AS JobType_1 INNER JOIN JobType ON JobType_1.jobTypeID = JobType.CategoryID INNER JOIN  Job ON JobType.jobTypeID = Job.jobTypeID INNER JOIN " +
                   " Section ON JobType.sectionID = Section.sectionID WHERE (JobType.sectionID = " + secID + ") AND (Job.jobDueDate < GETDATE()-1) AND (Job.jobStatusID IN (3,8)) GROUP BY JobType_1.jobTypeName";

                strSeriesName = "jobTypeName";
                lblOngoingJobs.Text = "Over Due Job Order In Cost Control Section";
            }
            else if (Session["UserProfileID"].ToString().Contains("4"))        // Cost Control Admin 
            {
                sqlQuery = "SELECT COUNT(Job.jobID) AS JobCnt, JobType_1.jobTypeName FROM JobType AS JobType_1 INNER JOIN JobType ON JobType_1.jobTypeID = JobType.CategoryID INNER JOIN  Job ON JobType.jobTypeID = Job.jobTypeID INNER JOIN " +
                " Section ON JobType.sectionID = Section.sectionID WHERE (JobType.sectionID = " + secID + ") AND (Job.jobDueDate < GETDATE()-1) AND (Job.jobStatusID IN (3,8)) GROUP BY JobType_1.jobTypeName";

                strSeriesName = "jobTypeName";
                lblOngoingJobs.Text = "Over Due Job Order In Cost Control Section";
            }
            else if (Session["UserProfileID"].ToString().Contains("9"))        // Document Control Admin 
            {
                sqlQuery = "SELECT COUNT(Job.jobID) AS JobCnt, JobType_1.jobTypeName FROM JobType AS JobType_1 INNER JOIN JobType ON JobType_1.jobTypeID = JobType.CategoryID INNER JOIN  Job ON JobType.jobTypeID = Job.jobTypeID INNER JOIN " +
                " Section ON JobType.sectionID = Section.sectionID WHERE (JobType.sectionID = " + secID + ") AND (Job.jobDueDate < GETDATE()-1) AND (Job.jobStatusID IN (3,8)) GROUP BY JobType_1.jobTypeName";

                strSeriesName = "jobTypeName";
                lblOngoingJobs.Text = "Over Due Job Order In Cost Control Section";
            }
            else                                                            // Cost Control User 
            {
                sqlQuery = "SELECT  COUNT(JobOwner.jobOwnerID) AS JobCnt, JobType_1.jobTypeName FROM   JobType INNER JOIN  JobOwner ON JobType.jobTypeID = JobOwner.JobTypeID INNER JOIN " +
                        " Section ON JobOwner.sectionID = Section.sectionID INNER JOIN  JobType AS JobType_1 ON JobType.CategoryID = JobType_1.jobTypeID  WHERE (JobOwner.jobOwnerStatusID = 3) AND (JobOwner.contactID = " + _currentUserID + ") GROUP BY JobType_1.jobTypeName";
                strSeriesName = "jobTypeName";

                lblOngoingJobs.Text = "My On Going Tasks";
            }
        }
        else if (Session["SectionID"].ToString().Equals("6"))          // Cost Control Section
        {
            if (Session["UserProfileID"].ToString().Contains("2"))        // Admin Section
            {
                sqlQuery = "SELECT COUNT(Job.jobID) AS JobCnt, JobType_1.jobTypeName FROM JobType AS JobType_1 INNER JOIN JobType ON JobType_1.jobTypeID = JobType.CategoryID INNER JOIN  Job ON JobType.jobTypeID = Job.jobTypeID INNER JOIN " +
                   " Section ON JobType.sectionID = Section.sectionID WHERE (Job.sectionID = " + secID + ") AND (Job.jobDueDate < GETDATE()-1) AND (Job.jobStatusID IN (3,8)) GROUP BY JobType_1.jobTypeName";

                strSeriesName = "jobTypeName";
                lblOngoingJobs.Text = "Over Due Job Order In Cost Control Section";    // Planning and Schedule
            }
            else if (Session["UserProfileID"].ToString().Contains("4"))        // Cost Control Admin 
            {
                sqlQuery = "SELECT COUNT(Job.jobID) AS JobCnt, JobType_1.jobTypeName FROM JobType AS JobType_1 INNER JOIN JobType ON JobType_1.jobTypeID = JobType.CategoryID INNER JOIN  Job ON JobType.jobTypeID = Job.jobTypeID INNER JOIN " +
                " Section ON JobType.sectionID = Section.sectionID WHERE (Job.sectionID = " + secID + ") AND (Job.jobDueDate < GETDATE()-1) AND (Job.jobStatusID IN (3,8)) GROUP BY JobType_1.jobTypeName";

                strSeriesName = "jobTypeName";
                lblOngoingJobs.Text = "Over Due Job Order In Cost Control Section";       // Planning and Schedule
            }
            else if (Session["UserProfileID"].ToString().Contains("9"))        // Document Control Admin 
            {
                sqlQuery = "SELECT COUNT(Job.jobID) AS JobCnt, JobType_1.jobTypeName FROM JobType AS JobType_1 INNER JOIN JobType ON JobType_1.jobTypeID = JobType.CategoryID INNER JOIN  Job ON JobType.jobTypeID = Job.jobTypeID INNER JOIN " +
                " Section ON JobType.sectionID = Section.sectionID WHERE (Job.sectionID = " + secID + ") AND (Job.jobDueDate < GETDATE()-1) AND (Job.jobStatusID IN (3,8)) GROUP BY JobType_1.jobTypeName";

                strSeriesName = "jobTypeName";
                lblOngoingJobs.Text = "Over Due Job Order In Cost Control Section";
            }
            else                                                            // Cost Control User 
            {
                sqlQuery = "SELECT  COUNT(JobOwner.jobOwnerID) AS JobCnt, JobType_1.jobTypeName FROM   JobType INNER JOIN  JobOwner ON JobType.jobTypeID = JobOwner.JobTypeID INNER JOIN " +
                        " Section ON JobOwner.sectionID = Section.sectionID INNER JOIN  JobType AS JobType_1 ON JobType.CategoryID = JobType_1.jobTypeID  WHERE (JobOwner.jobOwnerStatusID = 3) AND (JobOwner.contactID = " + _currentUserID + ") GROUP BY JobType_1.jobTypeName";
                strSeriesName = "jobTypeName";

                lblOngoingJobs.Text = "My On Going Tasks";
            }
        }
        else if (Session["SectionID"].ToString().Equals("3"))          // Document Control Section
        {
            if (Session["UserProfileID"].ToString().Contains("2"))        // Admin Section
            {
                sqlQuery = "SELECT COUNT(Job.jobID) AS JobCnt, JobType_1.jobTypeName FROM JobType AS JobType_1 INNER JOIN JobType ON JobType_1.jobTypeID = JobType.CategoryID INNER JOIN  Job ON JobType.jobTypeID = Job.jobTypeID INNER JOIN " +
                   " Section ON JobType.sectionID = Section.sectionID WHERE (JobType.sectionID = " + secID + ") AND (Job.jobDueDate < GETDATE()-1) AND (Job.jobStatusID IN (3,8)) GROUP BY JobType_1.jobTypeName";

                strSeriesName = "jobTypeName";
                lblOngoingJobs.Text = "Over Due Job Order In Document Control";
            }
            else if (Session["UserProfileID"].ToString().Contains("9"))        // Document Control Admin 
            {
                sqlQuery = "SELECT    COUNT(JobOwner.jobOwnerID) AS JobCnt, JobType_1.jobTypeName  FROM  JobType INNER JOIN     JobOwner ON JobType.jobTypeID = JobOwner.JobTypeID INNER JOIN   Section ON JobOwner.sectionID = Section.sectionID INNER JOIN " +
                        " JobType AS JobType_1 ON JobType.CategoryID = JobType_1.jobTypeID WHERE (JobOwner.jobOwnerStatusID = 3) AND (JobType.sectionID = 3) GROUP BY JobType_1.jobTypeName";

                strSeriesName = "jobTypeName";
                lblOngoingJobs.Text = "On-going Jobs In Document Control";
            }
            else                                                            // Document Control User 
            {
                sqlQuery = "SELECT  COUNT(JobOwner.jobOwnerID) AS JobCnt, JobType_1.jobTypeName FROM   JobType INNER JOIN  JobOwner ON JobType.jobTypeID = JobOwner.JobTypeID INNER JOIN " +
                        " Section ON JobOwner.sectionID = Section.sectionID INNER JOIN  JobType AS JobType_1 ON JobType.CategoryID = JobType_1.jobTypeID  WHERE (JobOwner.jobOwnerStatusID = 3) AND (JobOwner.contactID = " + _currentUserID + ") GROUP BY JobType_1.jobTypeName";

                strSeriesName = "jobTypeName";
                lblOngoingJobs.Text = "My On Going Tasks";
            }
        }
        else if (Session["SectionID"].ToString().Equals("2"))          // Payment Section
        {
            if (Session["UserProfileID"].ToString().Contains("2"))        // Admin Section
            {
                sqlQuery = "SELECT  COUNT(JobOwner.jobOwnerID) AS JobCnt, JobType.jobTypeName FROM  JobOwner INNER JOIN   JobType ON JobOwner.JobTypeID = JobType.jobTypeID " +
                                 " WHERE (JobOwner.payID IS NOT NULL) AND (JobOwner.actionDueDate < GETDATE()-1) AND (JobOwner.jobOwnerStatusID <> 7) GROUP BY JobType.jobTypeName";

                strSeriesName = "jobTypeName";
                lblOngoingJobs.Text = "Over Due Job Order In Payment Section";
            }
            else if (Session["UserProfileID"].ToString().Contains("4"))        // Payment Admin 
            {
                sqlQuery = "SELECT  COUNT(JobOwner.jobOwnerID) AS JobCnt, JobType.jobTypeName FROM  JobOwner INNER JOIN   JobType ON JobOwner.JobTypeID = JobType.jobTypeID " +
                                 " WHERE (JobOwner.payID IS NOT NULL) AND (JobOwner.actionDueDate < GETDATE()-1) AND (JobOwner.jobOwnerStatusID <> 7) GROUP BY JobType.jobTypeName";

                strSeriesName = "jobTypeName";
                lblOngoingJobs.Text = "Over Due Job Order In Payment Section";
            }
            else                                                            // Payment User 
            {
                sqlQuery = "SELECT  COUNT(JobOwner.jobOwnerID) AS JobCnt, JobType_1.jobTypeName FROM   JobType INNER JOIN  JobOwner ON JobType.jobTypeID = JobOwner.JobTypeID INNER JOIN " +
                        " Section ON JobOwner.sectionID = Section.sectionID INNER JOIN  JobType AS JobType_1 ON JobType.CategoryID = JobType_1.jobTypeID  WHERE (JobOwner.jobOwnerStatusID = 3) AND (JobOwner.contactID = " + _currentUserID + ") GROUP BY JobType_1.jobTypeName";

                strSeriesName = "jobTypeName";
                lblOngoingJobs.Text = "My On Going Tasks";
            }
        }        
        else if (Session["SectionID"].ToString().Equals("10"))          // Mngr Control Section
        {
            if (Session["UserProfileID"].ToString().Contains("2"))        // Admin Section
            {
                sqlQuery = " SELECT COUNT(Job.jobID) AS JobCnt, JobType.jobTypeName FROM  JobType INNER JOIN  Job ON JobType.jobTypeID = Job.jobTypeID INNER JOIN " +
                         " Section ON JobType.sectionID = Section.sectionID WHERE (JobType.sectionID = 10) AND (Job.jobDueDate < GETDATE() - 1) AND (Job.jobStatusID IN (3, 8)) GROUP BY JobType.jobTypeName";

                strSeriesName = "jobTypeName";
                lblOngoingJobs.Text = "Over Due Task In Manager Request";
            }
            else if (Session["UserProfileID"].ToString().Contains("15"))        // Req Control Admin 
            {
                sqlQuery = " SELECT COUNT(Job.jobID) AS JobCnt, JobType.jobTypeName FROM  JobType INNER JOIN  Job ON JobType.jobTypeID = Job.jobTypeID INNER JOIN " +
                        " Section ON JobType.sectionID = Section.sectionID WHERE (JobType.sectionID = 10) AND (Job.jobDueDate < GETDATE() - 1) AND (Job.jobStatusID IN (3, 8)) GROUP BY JobType.jobTypeName";

                strSeriesName = "jobTypeName";
                lblOngoingJobs.Text = "Over Due Task In Manager Request";
            }

            else                                                            // Req Control User 
            {
                sqlQuery = "SELECT  COUNT(JobOwner.jobOwnerID) AS JobCnt, JobType_1.jobTypeName FROM   JobType INNER JOIN  JobOwner ON JobType.jobTypeID = JobOwner.JobTypeID INNER JOIN " +
                        " Section ON JobOwner.sectionID = Section.sectionID INNER JOIN  JobType AS JobType_1 ON JobType.CategoryID = JobType_1.jobTypeID  WHERE (JobOwner.jobOwnerStatusID = 3) AND (JobOwner.contactID = " + _currentUserID + ") GROUP BY JobType_1.jobTypeName";

                strSeriesName = "jobTypeName";

                lblOngoingJobs.Text = "My On Going Tasks";
            }

        }
        else if (Session["SectionID"].ToString().Equals("22"))          // Mngr Control Section
        {
            if (Session["UserProfileID"].ToString().Contains("2"))        // Admin Section
            {
                sqlQuery = " SELECT COUNT(Job.jobID) AS JobCnt, JobType.jobTypeName FROM  JobType INNER JOIN  Job ON JobType.jobTypeID = Job.jobTypeID INNER JOIN " +
                         " Section ON JobType.sectionID = Section.sectionID WHERE (JobType.sectionID = 22) AND (Job.jobDueDate < GETDATE() - 1) AND (Job.jobStatusID IN (3, 8)) GROUP BY JobType.jobTypeName";

                strSeriesName = "jobTypeName";
                lblOngoingJobs.Text = "Over Due Task In General Service Section";
            }
            else if (Session["UserProfileID"].ToString().Contains("15"))        // Req Control Admin 
            {
                sqlQuery = " SELECT COUNT(Job.jobID) AS JobCnt, JobType.jobTypeName FROM  JobType INNER JOIN  Job ON JobType.jobTypeID = Job.jobTypeID INNER JOIN " +
                        " Section ON JobType.sectionID = Section.sectionID WHERE (JobType.sectionID = 22) AND (Job.jobDueDate < GETDATE() - 1) AND (Job.jobStatusID IN (3, 8)) GROUP BY JobType.jobTypeName";

                strSeriesName = "jobTypeName";
                lblOngoingJobs.Text = "Over Due Task In General Service Section";
            }

            else                                                            // Req Control User 
            {
                sqlQuery = "SELECT  COUNT(JobOwner.jobOwnerID) AS JobCnt, JobType_1.jobTypeName FROM   JobType INNER JOIN  JobOwner ON JobType.jobTypeID = JobOwner.JobTypeID INNER JOIN " +
                        " Section ON JobOwner.sectionID = Section.sectionID INNER JOIN  JobType AS JobType_1 ON JobType.CategoryID = JobType_1.jobTypeID  WHERE (JobOwner.jobOwnerStatusID = 3) AND (JobOwner.contactID = " + _currentUserID + ") GROUP BY JobType_1.jobTypeName";

                strSeriesName = "jobTypeName";

                lblOngoingJobs.Text = "My On Going Tasks";
            }

        }
        else if (Session["SectionID"].ToString().Equals("9"))          // BS Control Section
        {
            if (Session["UserProfileID"].ToString().Contains("2"))        // Admin Section
            {
                sqlQuery = " SELECT    COUNT(EBDServiceRequests.serviceReqID) AS JobCnt, ServiceType.serviceTypeDescription as jobTypeName FROM EBDServiceRequests INNER JOIN " +
                         " ServiceType ON EBDServiceRequests.serviceTypeID = ServiceType.serviceTypeID GROUP BY ServiceType.serviceTypeDescription";

                strSeriesName = "jobTypeName";
                lblOngoingJobs.Text = "Over Due Task In BS Request";
            }
            else if (Session["UserProfileID"].ToString().Contains("15"))        // Req Control Admin 
            {
                sqlQuery = " SELECT    COUNT(EBDServiceRequests.serviceReqID) AS JobCnt, ServiceType.serviceTypeDescription as jobTypeName FROM EBDServiceRequests INNER JOIN " +
                         " ServiceType ON EBDServiceRequests.serviceTypeID = ServiceType.serviceTypeID GROUP BY ServiceType.serviceTypeDescription";

                strSeriesName = "jobTypeName";
                lblOngoingJobs.Text = "Over Due Task In BS Request";
            }
            else                                                            // Req Control User 
            {
                sqlQuery = "SELECT  COUNT(JobOwner.jobOwnerID) AS JobCnt, ServiceType.serviceTypeDescription as jobTypeName FROM JobOwner INNER JOIN ServiceType ON JobOwner.JobTypeID = ServiceType.serviceTypeID " +
                                   " WHERE (JobOwner.jobOwnerStatusID = 3) AND (JobOwner.contactID = " + _currentUserID + ") GROUP BY ServiceType.serviceTypeDescription";

                strSeriesName = "jobTypeName";
                lblOngoingJobs.Text = "My On Going Tasks";
            }
        }
        else
        {
            sqlQuery = "SELECT  COUNT(JobOwner.jobOwnerID) AS JobCnt, JobType_1.jobTypeName FROM   JobType INNER JOIN  JobOwner ON JobType.jobTypeID = JobOwner.JobTypeID INNER JOIN " +
                       " Section ON JobOwner.sectionID = Section.sectionID INNER JOIN  JobType AS JobType_1 ON JobType.CategoryID = JobType_1.jobTypeID  WHERE (JobOwner.jobOwnerStatusID = 3) AND (JobOwner.contactID = " + _currentUserID + ") GROUP BY JobType_1.jobTypeName";

            strSeriesName = "jobTypeName";
            lblOngoingJobs.Text = "My On Going Tasks";
        }

        // Chart_OverDueJobs

        SqlDataAdapter daTndr = new SqlDataAdapter(sqlQuery, connValue);
        daTndr.Fill(dsTndr);
        if (dsTndr.Tables[0].Rows.Count != 0)
        {
            onGoingTasksPerSectionChart.DataSource = dsTndr.Tables[0].DefaultView;

            onGoingTasksPerSectionChart.Series["Series1"].XValueMember = strSeriesName;
            onGoingTasksPerSectionChart.Series["Series1"].YValueMembers = "JobCnt";

            dsTndr.Tables.Clear();

            onGoingTasksPerSectionChart.ChartAreas[0].AxisX.MajorGrid.Enabled = false;
            onGoingTasksPerSectionChart.ChartAreas[0].AxisX.MinorGrid.Enabled = false;
            onGoingTasksPerSectionChart.ChartAreas[0].AxisY.MajorGrid.Enabled = false;
            onGoingTasksPerSectionChart.ChartAreas[0].AxisY.MinorGrid.Enabled = false;

            onGoingTasksPerSectionChart.ChartAreas[0].AxisX.LabelStyle.Angle = 30;
            onGoingTasksPerSectionChart.ChartAreas[0].AxisX.LabelStyle.ForeColor = Color.Maroon;

            onGoingTasksPerSectionChart.ChartAreas[0].AxisX.Interval = 1;
        }

    }

    private void getTasksWaitingForCompletion()
    {
        string sqlQuery = null;
        if (Session["SectionID"].ToString().Equals("9")) // BS
        {
            sqlQuery = " SELECT distinct CONVERT(nvarchar,JobOwner.projectTitle) As projectTitle, JobOwner.srID, JobOwner.jobNo  " + //, ServiceType.serviceTypeDescription as jobTypeName
            " FROM JobOwner INNER JOIN EBDServiceRequests ON JobOwner.srID=EBDServiceRequests.serviceReqID " + //INNER JOIN ServiceType ON JobOwner.JobTypeID = ServiceType.serviceTypeID 
            " WHERE EBDServiceRequests.statusID!=7 and (JobOwner.srID IN (SELECT distinct srID FROM JobOwner AS JobOwner_1  join Contact on JobOwner_1.contactID=Contact.contactID WHERE (JobOwner_1.sectionID = 9) AND (JobOwner_1.jobOwnerStatusID = 7) and Contact.contactID=105)) ORDER BY JobOwner.srID Desc"; //and (Contact.isTeamLeader=0 or Contact.isTeamLeader is Null)

            SqlConnection objCon = new SqlConnection(connValue);
            SqlCommand objCmd = new SqlCommand(sqlQuery, objCon);
            SqlDataAdapter objDA = new SqlDataAdapter(objCmd);

            objDA.SelectCommand.CommandText = objCmd.CommandText.ToString();
            DataTable dt = new DataTable();
            objDA.Fill(dt);

            Session["getTasksWaitingForComp"] = dt;
            int rowsCount = dt.Rows.Count;
            if ( rowsCount!= 0)
            {
                tasksWaitingForComp.DataSource = dt.DefaultView;
                //rowsCount = dt.DefaultView.ToTable(true, "JobNo").Rows.Count;
                lnkTasksToBeCompleted.Text = "Tasks Waiting For Completion("+rowsCount+")";
            }
            else
            {
                tasksWaitingForComp.DataSource = dt;
                // gridTasks.Visible = false;
            }
            tasksWaitingForComp.DataBind();
            tab2.Controls.Add(tasksWaitingForComp);                        
        }
    }

    private void getUnReadInchargeData()
    {
        string sqlQuery = string.Empty;

        if (Session["SectionID"].ToString().Equals("2")) // Pay
        {
            sqlQuery = "SELECT JobOwner.projectTitle,  JobOwner.jobID, JobOwner.jobNo, JobType_1.jobTypeName, [Document].referenceNo, REPLACE(CONVERT(NVARCHAR, JobOwner.staffIssueDate, 106), ' ', '-')  AS DateOfIssue, JobType_1.CategoryID AS jobCatID, JobOwner.sectionID, JobOwner.jobOwnerID, JobOwner.contactID, JobOwner.jobDocRefID, " +
                   " JobOwner.distributedBy, Contact.firstName + '  ' + Contact.lastName AS IssuedBy, JobOwner.payID, JobOwner.srID FROM   JobOwner INNER JOIN JobType ON JobOwner.JobTypeID = JobType.jobTypeID INNER JOIN  JobType AS JobType_1 ON JobType.CategoryID = JobType_1.jobTypeID INNER JOIN " +
                " [Document] ON JobOwner.jobDocRefID = [Document].documentID INNER JOIN  Contact ON JobOwner.distributedBy = Contact.contactID  WHERE  (JobOwner.jobOwnerStatusID=3) AND (JobOwner.contactID = " + _currentUserID + ") ORDER BY JobOwner.JobownerID DESC";
        }
        else if (Session["SectionID"].ToString().Equals("9")) // BS
        {
          
            sqlQuery = " SELECT JobOwner.projectTitle, JobOwner.srID, JobOwner.jobID, JobOwner.jobNo, '' AS referenceNo, REPLACE(CONVERT(NVARCHAR, JobOwner.staffIssueDate, 106), ' ', '-') " +
            " AS DateOfIssue, JobOwner.sectionID, JobOwner.jobOwnerID, JobOwner.contactID, JobOwner.jobDocRefID, JobOwner.distributedBy, Contact.firstName + '  ' + Contact.lastName AS IssuedBy, JobOwner.payID, ServiceType.serviceTypeDescription as jobTypeName, JobOwner.JobTypeID as jobCatID  " +
            " FROM JobOwner INNER JOIN Contact ON JobOwner.distributedBy = Contact.contactID INNER JOIN ServiceType ON JobOwner.JobTypeID = ServiceType.serviceTypeID " +
            " WHERE (JobOwner.dateRead IS NULL) AND (JobOwner.jobOwnerStatusID = 3) AND (JobOwner.sectionID = 9) AND (JobOwner.contactID = " + _currentUserID + ") ORDER BY JobOwner.srID DESC";

        }
        else
        {
            sqlQuery = "SELECT   JobOwner.projectTitle, JobOwner.jobID, JobOwner.jobNo,JobOwner.projectTitle, JobType_1.jobTypeName, [Document].referenceNo, REPLACE(CONVERT(NVARCHAR, JobOwner.staffIssueDate, 106), ' ', '-')  AS DateOfIssue, JobType_1.CategoryID AS jobCatID, JobOwner.sectionID, JobOwner.jobOwnerID, JobOwner.contactID, JobOwner.jobDocRefID, " +
                       " JobOwner.distributedBy, Contact.firstName + '  ' + Contact.lastName AS IssuedBy, JobOwner.payID, JobOwner.srID FROM   JobOwner INNER JOIN JobType ON JobOwner.JobTypeID = JobType.jobTypeID INNER JOIN  JobType AS JobType_1 ON JobType.CategoryID = JobType_1.jobTypeID INNER JOIN " +
                    " [Document] ON JobOwner.jobDocRefID = [Document].documentID INNER JOIN  Contact ON JobOwner.distributedBy = Contact.contactID  WHERE  (JobOwner.dateRead IS NULL) AND (JobOwner.contactID = " + _currentUserID + ") ORDER BY JobOwner.JobownerID DESC";
        }


        SqlConnection objCon = new SqlConnection(connValue);
        SqlCommand objCmd = new SqlCommand(sqlQuery, objCon);
        SqlDataAdapter objDA = new SqlDataAdapter(objCmd);

        objDA.SelectCommand.CommandText = objCmd.CommandText.ToString();
        DataTable dt = new DataTable();
        objDA.Fill(dt);

        Session["getUnreadInChargeData"] = dt;

        if (dt.Rows.Count != 0)
        {
            gridTasks.DataSource = dt.DefaultView;            
        }
        else
        {
            gridTasks.DataSource = dt;            
        }        
        gridTasks.DataBind();
        tab1.Controls.Add(gridTasks);
    }


    private void getMyDocumentChart()
    {
        DataSet dsDoc = new DataSet();

        string sqlQuery = null;

        if (Convert.ToInt32(Session["UserID"]) == 1)
        {
            sqlQuery = "SELECT COUNT(DocumentDistribution.distributeID) AS DocCount, DocumentStatus.docStatusName " +
                   " FROM DocumentDistribution INNER JOIN  DocumentStatus ON DocumentDistribution.docStatusID = DocumentStatus.docStatusID WHERE (DocumentDistribution.docStatusID not in (4,2)) GROUP BY DocumentStatus.docStatusName";
        }
        else
        {
            sqlQuery = "SELECT COUNT(DocumentDistribution.distributeID) AS DocCount, DocumentStatus.docStatusName " +
                   " FROM DocumentDistribution INNER JOIN  DocumentStatus ON DocumentDistribution.docStatusID = DocumentStatus.docStatusID WHERE (DocumentDistribution.docStatusID not in (4)) AND " +
                   " (DocumentDistribution.contactID = " + Convert.ToInt32(Session["UserID"]) + ") " +
                           " GROUP BY DocumentStatus.docStatusName";
        }

        SqlDataAdapter daDoc = new SqlDataAdapter(sqlQuery, connValue);
        daDoc.Fill(dsDoc);
        if (dsDoc.Tables[0].Rows.Count != 0)
        {
            myDocsChart.DataSource = dsDoc.Tables[0].DefaultView;
            myDocsChart.Series["Series1"].XValueMember = "docStatusName";
            myDocsChart.Series["Series1"].YValueMembers = "DocCount";

            dsDoc.Tables.Clear();

            myDocsChart.ChartAreas[0].AxisX.MajorGrid.Enabled = false;
            myDocsChart.ChartAreas[0].AxisX.MinorGrid.Enabled = false;
            myDocsChart.ChartAreas[0].AxisY.MajorGrid.Enabled = false;
            myDocsChart.ChartAreas[0].AxisY.MinorGrid.Enabled = false;

            myDocsChart.ChartAreas[0].AxisX.LabelStyle.Angle = 30;
            myDocsChart.ChartAreas[0].AxisX.LabelStyle.ForeColor = Color.Maroon;

            myDocsChart.ChartAreas[0].AxisX.Interval = 1;
        }
    }

    protected void lnkBtnJobID_Click(object sender, EventArgs e)
    {
        Session["PayID"] = null;
        Session["JobID"] = null;
        Session["SRID"] = null;

        string strUpdateJob = Request.Url.AbsoluteUri;
        Session["UrlRef"] = strUpdateJob;
        try
        {
            //Get the LinkButton that raised the event
            LinkButton lnkJobID = (LinkButton)sender;
            //Get the row that contains this dropdown
            GridViewRow gvr = (GridViewRow)lnkJobID.NamingContainer;

            //Session["JobID"] = ((HtmlGenericControl)gvr.FindControl("divJobID")).InnerText;

            Session["SRID"] = ((HtmlGenericControl)gvr.FindControl("divSRID")).InnerText;

            if ((Session["SRID"] != null) & (Session["SRID"] != ""))
            {
                bool isWaiting = false;
                if(Session["TabClicked"]!=null)
                {                    
                    if(Session["TabClicked"].ToString().Contains("Tasks Waiting"))
                    {
                        isWaiting = true;
                    }
                }
                if (!isWaiting)
                {
                    UpdateJobOwner(Convert.ToInt32(lnkJobID.ToolTip));
                }
                Response.Redirect("~/Planning/BSDetails.aspx?SrJobID= " + Session["SRID"] + "", false);
                return;
            }
            else
            {
                Session["JobID"] = ((HtmlGenericControl)gvr.FindControl("divJobID")).InnerText;

                if (Session["JobID"] == null)
                    Session["PayID"] = ((HtmlGenericControl)gvr.FindControl("divPayID")).InnerText;

                if (Session["JobID"].ToString() == "")
                    Session["PayID"] = ((HtmlGenericControl)gvr.FindControl("divPayID")).InnerText;
            }

            Session["JobInchargeID"] = lnkJobID.ToolTip;

            if (Session["SectionID"].ToString().Equals("4"))
            {
                Response.Redirect("~/Survey/SurveyDetails.aspx?REQUEST_ID= " + Session["JobInchargeID"] + "", false);
            }
            else
            {
                if ((Session["PayID"] == null))
                {
                    Session["JobCatID"] = ((HtmlGenericControl)gvr.FindControl("divJobCatID")).InnerText;
                    UpdateJobOwner(Convert.ToInt32(lnkJobID.ToolTip));

                    string catID = ((HtmlGenericControl)gvr.FindControl("divJobCatID")).InnerText.Trim();

                    if (catID.Equals("1"))
                        Response.Redirect("~/JobOrder/PSAJobDetails.aspx?JobID= " + Session["JobID"] + "", false);
                    else if (catID.Equals("8"))
                        Response.Redirect("~/DCLog/DCDetails.aspx?JobID= " + Session["JobID"] + "", false);
                    else if (catID.Equals("46"))
                        Response.Redirect("~/ManagerTask/MngrTaskDetails.aspx?JobID= " + Session["JobID"] + "", false);
                    else if (catID.Equals("67"))           // else if ((catID.Equals("67")) || (catID.Equals("68")) || (catID.Equals("69")))
                        Response.Redirect("~/GenaralService/GSDetails.aspx?JobID= " + Session["JobID"] + "", false);
                    else if (catID.Equals("76") || catID.Equals("77") || (catID.Equals("78")) || catID.Equals("130") || catID.Equals("131") || catID.Equals("132") || catID.Equals("133") || catID.Equals("134")) //76==CAD Services,77==GIS Services,78==EIS Services,130==Data and operation team
                        Response.Redirect("~/GIS/GISDetails.aspx?JobID= " + Session["JobID"] + "", false);
                    else
                        Response.Redirect("~/JobOrder/DefaultGrid.aspx?JobID= " + Session["JobID"] + "", false);
                }
                else
                {
                    Response.Redirect("~/Payments/PaymentDetails.aspx?PayID= " + Session["PayID"] + "", false);
                }
            }
        }
        catch (Exception ex)
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Error occurred while processing the request')</script>", false);
        }
    }

    private void getOnGoingTasksPerStaffChart()   // chart 3
    {
        string sqlQuery = string.Empty; string strStaff = string.Empty;

        DataSet dsTndr = new DataSet();
        int sectionID = Convert.ToInt32(Session["SectionID"]);

        if (Session["userProfileID"].ToString().Equals("1"))
        {
            sqlQuery = "SELECT  TOP (20) COUNT(*) AS JobCnt, Contact.userShortName FROM  JobOwner INNER JOIN   Contact ON JobOwner.contactID = Contact.contactID  WHERE  (JobOwner.jobOwnerStatusID = 3) GROUP BY JobOwner.contactID, Contact.userShortName ORDER BY JobCnt DESC";

            lblOngoingStaff.Text = "(Top 20) On Going Tasks Per Staff In All Sections Of EBSD";
        }
        else if (!userRightsColl.Contains("42") && Session["SectionID"].ToString().Equals("7")) //1 - All Sections
        {
            sqlQuery = "SELECT  COUNT(*) AS JobCnt, Contact.userShortName FROM JobOwner INNER JOIN Contact ON JobOwner.contactID = Contact.contactID WHERE (JobOwner.jobOwnerStatusID = 3) GROUP BY JobOwner.contactID, " + 
            " Contact.userShortName ORDER BY Contact.userShortName";

            lblOngoingStaff.Text = "On Going Tasks Per Staff In All Sections Of EBSD ";
        }
        else
        {
            lblOngoingStaff.Text = "On Going Tasks Per Staff In  " + Session["SectionName"].ToString();

            sqlQuery = "SELECT COUNT(*) AS JobCnt, Contact.userShortName FROM  JobOwner INNER JOIN  Contact ON JobOwner.contactID = Contact.contactID " +
                      " WHERE  (JobOwner.sectionID = " + sectionID + ") AND (JobOwner.jobOwnerStatusID = 3) GROUP BY JobOwner.contactID, Contact.userShortName ORDER BY Contact.userShortName";
        }

        SqlDataAdapter daTndr = new SqlDataAdapter(sqlQuery, connValue);
        daTndr.Fill(dsTndr);
        if (dsTndr.Tables[0].Rows.Count != 0)
        {
            onGoingTasksPerStaffChart.DataSource = dsTndr.Tables[0].DefaultView;
            onGoingTasksPerStaffChart.Series["Series1"].XValueMember = "userShortName";
            onGoingTasksPerStaffChart.Series["Series1"].YValueMembers = "JobCnt";
            dsTndr.Tables.Clear();

            onGoingTasksPerStaffChart.ChartAreas[0].AxisX.MajorGrid.Enabled = false;
            onGoingTasksPerStaffChart.ChartAreas[0].AxisX.MinorGrid.Enabled = false;
            onGoingTasksPerStaffChart.ChartAreas[0].AxisY.MajorGrid.Enabled = false;
            onGoingTasksPerStaffChart.ChartAreas[0].AxisY.MinorGrid.Enabled = false;

            onGoingTasksPerStaffChart.ChartAreas[0].AxisX.LabelStyle.Angle = 30;
            onGoingTasksPerStaffChart.ChartAreas[0].AxisX.LabelStyle.ForeColor = Color.Maroon;

            onGoingTasksPerStaffChart.ChartAreas[0].AxisX.Interval = 1;
        }
    }
    protected void onGoingTasksPerSectionChart_Load(object sender, EventArgs e)
    {

    }
    protected void btnSearchAdmLog_Click(object sender, EventArgs e)
    {
        string strUpdateJob = Request.Url.AbsoluteUri;
        Session["UrlRef"] = strUpdateJob;

        if (Session["SectionID"].Equals("1"))
        {
            if (userRightsColl.Contains("11"))
            {
                ClientScript.RegisterClientScriptBlock(this.GetType(), "Popup", "<script>alert('You have no privilege to Search Addendum Log.')</script>", false);
                return;
            }
            else
            {
                Response.Redirect("SearchAdmData.aspx", false);
            }
        }
        else if (Session["SectionID"].Equals("9"))
        {
            Response.Redirect("~/Planning/ViewSRInfo.aspx", false);
        }
        else if (Session["SectionID"].Equals("11"))
        {
            Response.Redirect("~/GIS/GISData.aspx", false);
        }
        else if (Session["SectionID"].Equals("22"))
        {
            Session["OverDue"] = "No";    
            Response.Redirect("~/GenaralService/ViewGSRequests.aspx", false);
        }
        else
        {

        }
    }
    protected void btnPCCReports_Click(object sender, EventArgs e)
    {
        if (Session["SectionID"].Equals("1"))
            Response.Redirect("~/Reports/rptNewReports.aspx", false);
        else if (Session["SectionID"].Equals("2"))
            Response.Redirect("~/Reports/rptPaymentReports.aspx", false);
        else if (Session["SectionID"].Equals("3"))
            Response.Redirect("~/Reports/rptDocumentReports.aspx", false);
        else if (Session["SectionID"].Equals("9"))
            Response.Redirect("~/Reports/rptBDReport.aspx", false);
        else if (Session["SectionID"].Equals("10"))
            Response.Redirect("~/Reports/rptManagerReports.aspx", false);
        else if (Session["SectionID"].Equals("11"))
            Response.Redirect("~/Reports/rptEISReport.aspx", false);
        else if (Session["SectionID"].Equals("22"))
        {
            if (Session["UserID"].Equals("95"))
              Response.Redirect("~/GenaralService/GSDynamicReport.aspx", false); // GSReports.aspx         GSExportData       GSDynamicReport.aspx
        }
        else
        {

        }
    }

    protected void btnSearchByTeam_Click(object sender, EventArgs e)
    {
        //if (Session["SectionID"].Equals("1"))
        //    Response.Redirect("~/Reports/rptNewReports.aspx", false);
        //else if (Session["SectionID"].Equals("2"))
        //    Response.Redirect("~/Reports/rptPaymentReports.aspx", false);
        //else if (Session["SectionID"].Equals("3"))
        //    Response.Redirect("~/Reports/rptDocumentReports.aspx", false);
        //else if (Session["SectionID"].Equals("9"))
        //    Response.Redirect("~/Reports/rptBDReport.aspx", false);
        //else if (Session["SectionID"].Equals("10"))
        //    Response.Redirect("~/Reports/rptManagerReports.aspx", false);
        //else
        if (Session["SectionID"].Equals("11"))
        {
            //Session["CategoryID"] = "132"; //132==BIMTeam category
            Session["OverDue"] = "No";
            Response.Redirect("~/GIS/SearchByTeam.aspx", false);
        }

        //else if (Session["SectionID"].Equals("22"))
        //{
        //    if (Session["UserID"].Equals("95"))
        //        Response.Redirect("~/GenaralService/GSDynamicReport.aspx", false); // GSReports.aspx         GSExportData       GSDynamicReport.aspx
        //}
        //else
        //{

        //}
    }

    protected void btnSearchBIMTeam_Click(object sender, EventArgs e)
    {
        //if (Session["SectionID"].Equals("1"))
        //    Response.Redirect("~/Reports/rptNewReports.aspx", false);
        //else if (Session["SectionID"].Equals("2"))
        //    Response.Redirect("~/Reports/rptPaymentReports.aspx", false);
        //else if (Session["SectionID"].Equals("3"))
        //    Response.Redirect("~/Reports/rptDocumentReports.aspx", false);
        //else if (Session["SectionID"].Equals("9"))
        //    Response.Redirect("~/Reports/rptBDReport.aspx", false);
        //else if (Session["SectionID"].Equals("10"))
        //    Response.Redirect("~/Reports/rptManagerReports.aspx", false);
        //else
        if (Session["SectionID"].Equals("11"))
        {
            Session["CategoryID"] = "132"; //132==BIMTeam category
            Session["OverDue"] = "No";
            Response.Redirect("~/GIS/ViewGISRequests.aspx", false);              
        }
        
        //else if (Session["SectionID"].Equals("22"))
        //{
        //    if (Session["UserID"].Equals("95"))
        //        Response.Redirect("~/GenaralService/GSDynamicReport.aspx", false); // GSReports.aspx         GSExportData       GSDynamicReport.aspx
        //}
        //else
        //{

        //}
    }
    protected void btnSearchPlanningTeam_Click(object sender, EventArgs e)
    {
        if (Session["SectionID"].Equals("11"))
        {
            Session["CategoryID"] = "133"; //133==PlanningTeam category
            Session["OverDue"] = "No";
            Response.Redirect("~/GIS/ViewGISRequests.aspx", false); 
        }         
    }
    protected void btnNewNCp_Click(object sender, EventArgs e)
    {
        if (userRightsColl.Contains("18"))
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "Popup", "<script>alert('You have no privilege to Add Payment Request.')</script>", false);
            return;
        }
        else
        {
            Response.Redirect("~/Payments/AddNewNCPpayment.aspx", false);
        }
    }
    protected void btnCPProject_Click(object sender, EventArgs e)
    {
        if (userRightsColl.Contains("18"))
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "Popup", "<script>alert('You have no privilege to Add Payment Request.')</script>", false);
            return;
        }
        else
        {
            Session["PrjCP/NCP"] = "CP";
            Application["PrjType"] = Session["PrjCP/NCP"];
            Response.Redirect("~/Payments/AddNewPayment.aspx", false);
        }
    }
    protected void btnNCPProject_Click(object sender, EventArgs e)
    {
        if (userRightsColl.Contains("18"))
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "Popup", "<script>alert('You have no privilege to Add Payment Request.')</script>", false);
            return;
        }
        else
        {

            // Application["PrjType"] = Session["PrjCP/NCP"];
            Response.Redirect("~/Payments/AddNewNCPpayment.aspx", false);

            //string strJavascript = "<script type='text/javascript'>window.open('~/Payments/AddNewPayment.aspx,'_blank');</script>";
            //Response.Write(strJavascript);
        }
    }
    protected void gridTasks_Lead_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        gridTasks_Lead.PageIndex = e.NewPageIndex;

        DataTable dt = new DataTable();
        dt = Session["getLeadData"] as DataTable;

        gridTasks_Lead.DataSource = dt;
        gridTasks_Lead.DataBind();
        getUnReadInchargeData();
        getTasksWaitingForCompletion();
        OnPageLoad();
        //PageloadData();

    }
    private void PageloadData()
    {
        getMyDocumentChart();

       // getUnreadDocumentDataFromNonEBD();

        if (Session["SectionID"].Equals("4"))
        {
            //getUnReadInchargeDataOgSurveyOracle();
        }
        else if (Session["UserProfileID"].Equals("1"))
        {

        }
        else
            getUnReadInchargeData();

        getOnGoingTasksPerSection_New();      //Ongoing or Over due jobs Chart - first one

        if (!userRightsColl.Contains("42") && !Session["SectionID"].Equals("4"))
        {
            getOnGoingTasksPerStaffChart();
          //  getOnGoingJobsByTeamLead();
        }
        else if (!userRightsColl.Contains("42") && Session["SectionID"].Equals("4"))
        {
            //getOnGoingTasksPerStaffChartForSurvey();
        }
        else
        {
            //trlblStaff.Visible = false;
            //trchartStaff.Visible = false;
        }

        //if (userRightsColl.Contains("1"))
        //    lnKShowAll.Visible = false;

        trSRLead.Visible = true;
        surChartBS.Visible = true;

    }

    protected void lnkBtnReqIDLead_Click(object sender, EventArgs e) // IssuedBy
    {
        string strUpdateJob = Request.Url.AbsoluteUri;
        Session["UrlRef"] = strUpdateJob;
      
        LinkButton lnkJobID = (LinkButton)sender;
        GridViewRow gvr = (GridViewRow)lnkJobID.NamingContainer;

        Session["SrJobID"] = ((HtmlGenericControl)gvr.FindControl("divReqID")).InnerText;
        Response.Redirect("~/Planning/BSDetails.aspx?SrJobID= " + Session["SrJobID"] + "", false); //SrJobID
       
    }
    private void getUnReadIncharge_LeadData()
    {
        string sqlQuery = string.Empty;

        if (Session["UserProfileID"].Equals("18")) // BS Admin      // View Task by TeamLead
        {
            //sqlQuery = "SELECT JobOwner.jobOwnerID, JobOwner.contactID, JobOwner.jobID, JobOwner.payID, JobOwner.jobNo, ServiceType.serviceTypeDescription AS jobTypeName, " +
            //           " REPLACE(CONVERT(NVARCHAR, JobOwner.staffIssueDate, 106), ' ', '-')  AS DateOfIssue, JobOwner.distributedBy AS IssuedByID, JobOwner.jobPurposeID, JobOwner.jobOwnerStatusID, Contact.firstName AS IssuedBy, JobOwner.srID " +
            //           " FROM  Contact INNER JOIN JobOwner ON Contact.contactID = JobOwner.contactID INNER JOIN EBDServiceRequests INNER JOIN ServiceType ON EBDServiceRequests.serviceTypeID = ServiceType.serviceTypeID ON JobOwner.srID = EBDServiceRequests.serviceReqID " +
            //           " WHERE (JobOwner.jobOwnerStatusID = 3) AND (JobOwner.srID IN (SELECT srID FROM JobOwner AS JobOwner_1 WHERE (sectionID = 9) AND (jobPurposeID <> 1))) ORDER BY JobOwner.jobOwnerID desc";

            //sqlQuery = "SELECT JobOwner.jobOwnerID, JobOwner.contactID, JobOwner.jobID, JobOwner.payID, JobOwner.jobNo, ServiceType.serviceTypeDescription AS jobTypeName, " +
            //           " REPLACE(CONVERT(NVARCHAR, JobOwner.staffIssueDate, 106), ' ', '-')  AS DateOfIssue, JobOwner.distributedBy AS IssuedByID, JobOwner.jobPurposeID, JobOwner.jobOwnerStatusID, Contact.firstName AS IssuedBy, JobOwner.srID " +
            //           " FROM  Contact INNER JOIN JobOwner ON Contact.contactID = JobOwner.contactID INNER JOIN EBDServiceRequests INNER JOIN ServiceType ON EBDServiceRequests.serviceTypeID = ServiceType.serviceTypeID ON JobOwner.srID = EBDServiceRequests.serviceReqID " +
            //           " WHERE (JobOwner.jobOwnerStatusID = 3) AND (JobOwner.srID IN (SELECT srID FROM JobOwner AS JobOwner_1 WHERE (sectionID = 9) AND (jobPurposeID <> 1))) ORDER BY JobOwner.jobOwnerID desc";

            sqlQuery = "SELECT JobOwner.jobOwnerID, JobOwner.contactID, JobOwner.jobID, JobOwner.payID, JobOwner.jobNo, ServiceType.serviceTypeDescription AS jobTypeName, REPLACE(CONVERT(NVARCHAR, JobOwner.staffIssueDate, 106), ' ', '-')  AS DateOfIssue, JobOwner.distributedBy AS IssuedByID, JobOwner.jobPurposeID, JobOwner.jobOwnerStatusID, Contact.firstName AS IssuedBy, JobOwner.srID " +
            "FROM JobOwner join Contact on JobOwner.contactID=Contact.contactID INNER JOIN EBDServiceRequests on JobOwner.srID=EBDServiceRequests.serviceReqID INNER JOIN ServiceType ON EBDServiceRequests.serviceTypeID = ServiceType.serviceTypeID where JobOwner.srID in(SELECT JobOwner_1.srID FROM JobOwner AS JobOwner_1 join EBDServiceRequests on JobOwner_1.srID=EBDServiceRequests.serviceReqID WHERE (JobOwner_1.sectionID = 9) GROUP BY JobOwner_1.srID HAVING COUNT(JobOwner_1.srID) = 1) order by JobOwner.srID Desc"; //and Contact.isTeamLeader=1
         
            SqlConnection objCon = new SqlConnection(connValue);
            SqlCommand objCmd = new SqlCommand(sqlQuery, objCon);
            SqlDataAdapter objDA = new SqlDataAdapter(objCmd);

            objDA.SelectCommand.CommandText = objCmd.CommandText.ToString();
            DataTable dt = new DataTable();
            objDA.Fill(dt);

            Session["getLeadData"] = dt;

            if (dt.Rows.Count != 0)
                gridTasks_Lead.DataSource = dt.DefaultView;
            else
            {
                gridTasks_Lead.DataSource = null;
                // gridTasks.Visible = false;
            }

            gridTasks_Lead.DataBind();
            trSRLead.Visible = true;
        }
        else
        {
            trSRLead.Visible = false;
        }
    }
    public void UpdateJobOwner(int jobInchargeID)
    {
        try
        {
            using (SqlConnection con = new SqlConnection(connValue))
            {
                using (SqlCommand sqlCmd = new SqlCommand())
                {
                    sqlCmd.Connection = con;
                    sqlCmd.CommandType = CommandType.Text;
                    sqlCmd.CommandText = "UPDATE JobOwner SET dateRead =@jobReadDate where jobOwnerID = @jobOwnerID";
                    sqlCmd.Parameters.AddWithValue("@jobOwnerID", jobInchargeID);
                    sqlCmd.Parameters.AddWithValue("@jobReadDate", System.DateTime.Now.ToString("dd/MMM/yyyy"));

                    con.Open();
                    sqlCmd.ExecuteNonQuery();
                }
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    protected void btnSearchMyDoc0_Click(object sender, EventArgs e)
    {
        string strUpdateJob = Request.Url.AbsoluteUri;
        Session["UrlRef"] = strUpdateJob;
        Session["SearchMyDocs"] = "1";
        Response.Redirect("~/Documents/DocumentRegister.aspx", false);
    }
    protected void btnMyChart_Click(object sender, EventArgs e)
    {
        string url = "/eBook/UserChart.aspx"; //string url = "/eBook/FileUpload.aspx";
        string s = "window.open('" + url + "', 'popup_window', 'width=900,height=350,left=100,top=100,resizable=yes,scrollbars=yes');";
        ClientScript.RegisterStartupScript(this.GetType(), "script", s, true);  
        

    }
    private void Cost(int UserID)
    {
        string sqlQuery = "SELECT Contact.firstName as UserName, JobOwner.jobNo, { fn MONTHNAME(JobOwner.createDate) } AS Month, YEAR(JobOwner.createDate) AS Year, '' AS NOCOSTEOT " +
                   " FROM JobOwner INNER JOIN Contact ON JobOwner.contactID = Contact.contactID INNER JOIN JobPurpose ON JobOwner.jobPurposeID = JobPurpose.jobPurposeID LEFT OUTER JOIN " + 
                         " JobVOSI ON JobOwner.jobID = JobVOSI.jobID WHERE (JobVOSI.jobID IS NULL) AND (JobOwner.sectionID = 1) AND (YEAR(JobOwner.createDate) = 2018) AND (JobPurpose.jobPurposeID NOT IN (1)) AND " + 
                         " (MONTH(JobOwner.createDate) > 8) AND (Contact.contactID = " + UserID + ") ORDER BY Month";       // Convert.ToInt32(Session["UserID"])
    }
    protected void btnNewJobBSReview_Click(object sender, EventArgs e)
    {
        if (Session["SectionID"].ToString().Equals("10"))
        {
            string url = "JobEntryForm.aspx";
            string s = "window.open('" + url + "', 'popup_window', 'width=990,height=700,left=100,top=100,resizable=yes,scrollbars=yes');";
            ClientScript.RegisterStartupScript(this.GetType(), "script", s, true);
        }
    }
    protected void btnSearchBLReviewLog_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/Planning/SearchPSLog.aspx", false);
    }
    protected void btnCostEOT_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/JobOrder/SearchCOSTEOT.aspx", false);
    }
    protected void btnSearchEot_Click(object sender, EventArgs e)
    {
        if (Session["SectionID"].ToString().Equals("1"))
        {
            Response.Redirect("~/JobOrder/CostEstimate.aspx", false);
        }
    }
    protected void btnProjects_Click(object sender, EventArgs e)
    {
        if (Session["SectionID"].ToString().Equals("11"))
        {
            Response.Redirect("~/GIS/GISPortal.aspx", false);
        }
        else
        {
           // btnProjects.Visible = false;
        }
    }

    

    protected void gridTasks_Lead_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (Session["isTeamLeader"] != null)
        {
            if (Session["isTeamLeader"].ToString().Equals("1"))
            {
                if (e.Row.RowType == DataControlRowType.DataRow)
                {
                    System.Web.UI.HtmlControls.HtmlGenericControl srvID = (System.Web.UI.HtmlControls.HtmlGenericControl)e.Row.FindControl("divReqID");
                    if (srvID.InnerText != "")
                    {
                        uCls = new UtilityClass(this.Page);
                        if (uCls.getStaffStatus(srvID.InnerText))
                        {
                            e.Row.BackColor = System.Drawing.Color.Yellow;
                        }
                    }
                }
            }
        }
    }
}