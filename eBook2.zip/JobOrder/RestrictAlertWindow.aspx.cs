﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

public partial class JobOrder_RestrictAlertWindow : System.Web.UI.Page
{
    string connValue = System.Configuration.ConfigurationManager.ConnectionStrings["EBSDEBookConn"].ConnectionString;
    string slecetedDate = string.Empty;
    protected void Page_Load(object sender, EventArgs e)
    {
        lblProcess.Text = ""; 
    }
    private string getEndDateByGivenDays(string workDays, string startDate)
    {
        SqlConnection con = new SqlConnection(connValue);
        SqlCommand cmd = new SqlCommand();
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Connection = con;

        cmd.CommandText = "AddWorkdays";
        SqlParameter prm = cmd.Parameters.Add("@ad_startDate", SqlDbType.DateTime);
        prm.Value = Convert.ToDateTime(startDate);
        prm = cmd.Parameters.Add("@actual_workDays", SqlDbType.Int);
        prm.Value = Convert.ToInt32(workDays);
        prm = cmd.Parameters.Add("@endDate", SqlDbType.DateTime);
        prm.Direction = ParameterDirection.Output;
        if (con.State != ConnectionState.Open)
            con.Open();
        SqlDataReader dr = cmd.ExecuteReader();
        while (dr.Read())
            Console.WriteLine(dr.GetString(0));
        con.Dispose();
        dr.Close();
        if (con.State != ConnectionState.Closed)
            con.Close();

        return cmd.Parameters[2].Value.ToString();
    } 
    protected void btnYes_Click(object sender, EventArgs e)
    {
        getJobActionDueDate(Session["SelDate"].ToString());

        getInchargeActionDueDate(Session["SelDate"].ToString());

        getAddendumActionDueDate(Session["SelDate"].ToString());

        getDistributionDataActionDueDate(Session["SelDate"].ToString());
        
       // lblProcess.Text = "Process Done";

        string script = "this.window.opener.location=this.window.opener.location;this.window.close();";
        if (!ClientScript.IsClientScriptBlockRegistered("REFRESH_PARENT"))
            ClientScript.RegisterClientScriptBlock(typeof(string), "REFRESH_PARENT", script, true);
    }
    public void updateHolidayInCalander(string dueDate)
    {
        SqlConnection con = new SqlConnection(connValue);
        SqlCommand cmd = new SqlCommand();
        cmd.Connection = con;

        // Select * From PWACalendar WHERE (CalendarDate = '12/18/2014')
        cmd.CommandText = "UPDATE PWACalendar Set Holiday = 1, Workday = 0 WHERE CalendarDate = @SelectdDate ";

        cmd.Parameters.AddWithValue("@SelectdDate", Convert.ToDateTime(dueDate).ToString("dd/MMM/yyyy"));

        try
        {
            if (con.State != ConnectionState.Open)
                con.Open();

            cmd.ExecuteNonQuery();
            con.Dispose();
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (con.State != ConnectionState.Closed)
                con.Close();
        }
    }
    

                #region JobOrder
    private void getJobActionDueDate(string selectDate)
    {
        IList<string> dueDateDataColl = new List<string>();
        string sqlQuery = "SELECT workDays,jobDueDate,jobID,jobReceivedDate FROM Job  WHERE (jobReceivedDate <= CONVERT(DATETIME, '" + Convert.ToDateTime(selectDate).ToString("MM/dd/yyyy") + "', 102)) AND (jobDueDate >= CONVERT(DATETIME, '" + Convert.ToDateTime(selectDate).ToString("MM/dd/yyyy") + "', 102))";   
        SqlConnection sqlCon = new SqlConnection(connValue);
        SqlCommand cmd = new SqlCommand();
        cmd.CommandText = sqlQuery;
        cmd.Connection = sqlCon;

        try
        {
            if (sqlCon.State != ConnectionState.Open)
                sqlCon.Open();
            SqlDataReader sqlDtReader = cmd.ExecuteReader();
            if (sqlDtReader.HasRows)
            {
                while (sqlDtReader.Read())
                {
                    dueDateDataColl.Add(sqlDtReader[0].ToString());

                    string endDate = getEndDateByGivenDays(sqlDtReader[0].ToString(), sqlDtReader[3].ToString());
                    endDate = Convert.ToDateTime(endDate).ToString("dd/MMM/yyyy");

                    updateJOBActionDueDate(sqlDtReader[2].ToString(), endDate);
                }
            }
            sqlDtReader.Close();

        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (sqlCon.State != ConnectionState.Closed)
                sqlCon.Close();
        }
    }

    public void updateJOBActionDueDate(string jobID, string dueDate)
    {
        SqlConnection con = new SqlConnection(connValue);
        SqlCommand cmd = new SqlCommand();
        cmd.Connection = con;

        cmd.CommandText = "Update Job Set jobDueDate =@jobDueDate where JobID = @jobID";

        cmd.Parameters.AddWithValue("@jobDueDate", Convert.ToDateTime(dueDate).ToString("dd/MMM/yyyy"));
        cmd.Parameters.AddWithValue("@jobID", jobID);

        try
        {
            if (con.State != ConnectionState.Open)
                con.Open();

            cmd.ExecuteNonQuery();
            con.Dispose();
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (con.State != ConnectionState.Closed)
                con.Close();
        }
    }

                #endregion

                #region JobIncharge

    private void getInchargeActionDueDate(string selectDate)
    {
        IList<string> dueDateDataColl = new List<string>();

        string sqlQuery = "SELECT staffIssueDate, daysToAct, actionDueDate, jobOwnerID FROM JobOwner " +
        "  WHERE (staffIssueDate <= CONVERT(DATETIME, '" + Convert.ToDateTime(selectDate).ToString("MM/dd/yyyy") + "', 102)) AND (actionDueDate >= CONVERT(DATETIME, '" + Convert.ToDateTime(selectDate).ToString("MM/dd/yyyy") + "', 102))";

        // staffIssueDate

        SqlConnection sqlCon = new SqlConnection(connValue);
        SqlCommand cmd = new SqlCommand();
        cmd.CommandText = sqlQuery;
        cmd.Connection = sqlCon;

        try
        {
            if (sqlCon.State != ConnectionState.Open)
                sqlCon.Open();
            SqlDataReader sqlDtReader = cmd.ExecuteReader();
            if (sqlDtReader.HasRows)
            {
                while (sqlDtReader.Read())
                {
                    string endDate = getEndDateByGivenDays(sqlDtReader["daysToAct"].ToString(), sqlDtReader["staffIssueDate"].ToString());
                    endDate = Convert.ToDateTime(endDate).ToString("dd/MMM/yyyy");

                    updateInchargeActionDueDate(sqlDtReader["jobOwnerID"].ToString(), endDate);
                }
            }
            sqlDtReader.Close();

        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (sqlCon.State != ConnectionState.Closed)
                sqlCon.Close();
        }
    }

    public void updateInchargeActionDueDate(string jobInchargeID, string dueDate)
    {
        SqlConnection con = new SqlConnection(connValue);
        SqlCommand cmd = new SqlCommand();
        cmd.Connection = con;

        cmd.CommandText = "Update JobOwner Set ActionDueDate =@jobDueDate where JobOwnerID = @JobOwnerID";

        cmd.Parameters.AddWithValue("@jobDueDate", Convert.ToDateTime(dueDate).ToString("dd/MMM/yyyy"));
        cmd.Parameters.AddWithValue("@JobOwnerID", jobInchargeID);

        try
        {
            if (con.State != ConnectionState.Open)
                con.Open();

            cmd.ExecuteNonQuery();
            con.Dispose();
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (con.State != ConnectionState.Closed)
                con.Close();
        }
    }

               #endregion

                #region AddnedumData

    private void getAddendumActionDueDate(string selectDate)
    {
        IList<string> dueDateDataColl = new List<string>();

        string sqlQuery = "SELECT workDays,AlertDate,adID,admReceivedDate FROM JobAddendumInfo " +
        " WHERE (admReceivedDate <= CONVERT(DATETIME, '" + Convert.ToDateTime(selectDate).ToString("MM/dd/yyyy") + "', 102)) AND (AlertDate >= CONVERT(DATETIME, '" + Convert.ToDateTime(selectDate).ToString("MM/dd/yyyy") + "', 102))"; 
       
        SqlConnection sqlCon = new SqlConnection(connValue);
        SqlCommand cmd = new SqlCommand();
        cmd.CommandText = sqlQuery;
        cmd.Connection = sqlCon;

        try
        {
            if (sqlCon.State != ConnectionState.Open)
                sqlCon.Open();
            SqlDataReader sqlDtReader = cmd.ExecuteReader();
            if (sqlDtReader.HasRows)
            {
                while (sqlDtReader.Read())
                {
                    string endDate = getEndDateByGivenDays(sqlDtReader["workDays"].ToString(), sqlDtReader["admReceivedDate"].ToString());
                    endDate = Convert.ToDateTime(endDate).ToString("dd/MMM/yyyy");

                    updateAddendumActionDueDate(sqlDtReader["adID"].ToString(), endDate);
                }
            }
            sqlDtReader.Close();

        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (sqlCon.State != ConnectionState.Closed)
                sqlCon.Close();
        }
    }

    public void updateAddendumActionDueDate(string jobID, string dueDate)
    {
        SqlConnection con = new SqlConnection(connValue);
        SqlCommand cmd = new SqlCommand();
        cmd.Connection = con;

        cmd.CommandText = "Update JobAddendumInfo Set AlertDate =@jobDueDate where adID = @jobID";

        cmd.Parameters.AddWithValue("@jobDueDate", Convert.ToDateTime(dueDate).ToString("dd/MMM/yyyy"));
        cmd.Parameters.AddWithValue("@jobID", jobID);

        try
        {
            if (con.State != ConnectionState.Open)
                con.Open();

            cmd.ExecuteNonQuery();
            con.Dispose();
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (con.State != ConnectionState.Closed)
                con.Close();
        }
    }

       #endregion

                

    #region DocumentData

    private void getDistributionDataActionDueDate(string selectDate)
    {
        IList<string> dueDateDataColl = new List<string>();

        string sqlQuery = "SELECT docIssuedDate, daysToReply, actionDueDate, distributeID FROM  DocumentDistribution " +
        " WHERE (docIssuedDate <= CONVERT(DATETIME, '" + Convert.ToDateTime(selectDate).ToString("MM/dd/yyyy") + "', 102)) AND (actionDueDate >= CONVERT(DATETIME, '" + Convert.ToDateTime(selectDate).ToString("MM/dd/yyyy") + "', 102))"; 
        SqlConnection sqlCon = new SqlConnection(connValue);
        SqlCommand cmd = new SqlCommand();
        cmd.CommandText = sqlQuery;
        cmd.Connection = sqlCon;

        try
        {
            if (sqlCon.State != ConnectionState.Open)
                sqlCon.Open();
            SqlDataReader sqlDtReader = cmd.ExecuteReader();
            if (sqlDtReader.HasRows)
            {
                while (sqlDtReader.Read())
                {
                    string endDate = getEndDateByGivenDays(sqlDtReader["daysToReply"].ToString(), sqlDtReader["docIssuedDate"].ToString());
                    endDate = Convert.ToDateTime(endDate).ToString("dd/MMM/yyyy");

                    updateDistributionDataActionDueDate(sqlDtReader["distributeID"].ToString(), endDate);
                }
            }
            sqlDtReader.Close();

        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (sqlCon.State != ConnectionState.Closed)
                sqlCon.Close();
        }
    }

    public void updateDistributionDataActionDueDate(string _distributeID, string dueDate)
    {
        SqlConnection con = new SqlConnection(connValue);
        SqlCommand cmd = new SqlCommand();
        cmd.Connection = con;

        cmd.CommandText = "Update DocumentDistribution Set actionDueDate =@jobDueDate where distributeID = @distributeID";

        cmd.Parameters.AddWithValue("@jobDueDate", Convert.ToDateTime(dueDate).ToString("dd/MMM/yyyy"));
        cmd.Parameters.AddWithValue("@distributeID", _distributeID);

        try
        {
            if (con.State != ConnectionState.Open)
                con.Open();

            cmd.ExecuteNonQuery();
            con.Dispose();
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (con.State != ConnectionState.Closed)
                con.Close();
        }
    }

    #endregion



    protected void btnNo_Click(object sender, EventArgs e)
    {
        this.ClientScript.RegisterClientScriptBlock(this.GetType(), "Close", "window.close()", true);
    }
}