﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Data;
using System.Data.SqlClient;

using Datalayer;
public partial class JobOrder_JobDesTimeWindow : System.Web.UI.Page
{
    string connValue = System.Configuration.ConfigurationManager.ConnectionStrings["EBSDEBookConn"].ConnectionString;
    int _jobID = 0;
    protected override void OnInit(EventArgs e)
    {
        lbljobNo.Text = Request.QueryString["JobNo"];
        lblProjectCode.Text = Request.QueryString["prjCode"];
        lblAdmNo.Text = Request.QueryString["AdndmNO"];

        _jobID = Convert.ToInt32(Request.QueryString["JobID"]);


        if (!IsPostBack)
        {
            PopulateDropDownBox(DropDownList1, "SELECT jobTimeID, jobTimeDesc FROM PSAjobTime; ", "jobTimeID", "jobTimeDesc");
            gridload();
        }
    }
    protected void Page_Load(object sender, EventArgs e)
    {
       
    }
    public void gridload()
    {
        DataSet ds = new DataSet();
        ds = (new JobOrderData().GetDDlDetails_JobTime(_jobID));
        GridView1.DataSource = ds;
        GridView1.DataBind();
    }
    private void PopulateDropDownBox(DropDownList ddlBox, string sqlQuery, string valueMember, string displayName)
    {
        DataTable table = new DataTable();
        try
        {
            using (SqlConnection sqlConn = new SqlConnection(connValue))
            {
                using (SqlDataAdapter da = new SqlDataAdapter(sqlQuery, sqlConn))
                {
                    sqlConn.Open();
                    da.Fill(table);
                }
            }
            //cmbBox.Items.Add("Select");
            ddlBox.DataSource = table;

            ddlBox.DataTextField = displayName;
            ddlBox.DataValueField = valueMember;

            //ddlBox.SelectedIndex = -1;

            ddlBox.DataBind();
            ddlBox.Items.Insert(0, new ListItem("--Select--"));
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "delete")
        {
            string arguments = e.CommandArgument.ToString();
            string[] args = arguments.Split(';');
            string detID = args[0];
            //string jobid = args[1];
            //jobid = "1";
            new JobOrderData().Delete_ddljobvalues_JobTime(Convert.ToInt32(detID));
        }
    }
    protected void GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        gridload();
    }  
    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (DropDownList1.SelectedIndex != 0)
             new JobOrderData().Add_ddljobvalues_JobTime(1, _jobID, Convert.ToInt32(DropDownList1.SelectedValue));

        DropDownList1.SelectedIndex = 0;

        gridload();
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
       // ClientScript.RegisterStartupScript(typeof(Page), "alert", "<script type=\"text/javascript\">alert('Request cancelled !');</script>", true);

       // ClientScript.RegisterStartupScript(typeof(Page), "closePage", "<script type=\"text/javascript\">window.close();</script>", true);
    }
}