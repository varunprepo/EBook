﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Datalayer;
using Outlook = Microsoft.Office.Interop.Outlook;
using System.Runtime.InteropServices;

public partial class JobOrder_SetTaskReminder : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        btnOutLook.Enabled = false;

        Calendar1.Visible = false;

        DropDownList1.SelectedIndex = 2;

       // btnOutLook.Enabled = false;
    }
    //private void CreateToDoItemExample()
    //{
    //    // Date operations
    //    DateTime today = DateTime.Parse("10:00 AM");
    //    TimeSpan duration = TimeSpan.FromDays(1);
    //    DateTime tomorrow = today.Add(duration);
    //    Microsoft.Office.Interop.Outlook.MailItem mail = Outlook.Application.Session.GetDefaultFolder(
    //        Microsoft.Office.Interop.Outlook.OlDefaultFolders.olFolderInbox).Items.Find(
    //        "[MessageClass]='IPM.Note'") as Microsoft.Office.Interop.Outlook.MailItem;
    //    mail.MarkAsTask(Microsoft.Office.Interop.Outlook.OlMarkInterval.olMarkTomorrow);
    //    mail.TaskStartDate = today;
    //    mail.ReminderSet = true;
    //    mail.ReminderTime = tomorrow;
    //    mail.Save();
    //}

    private void CreateRecurrentTaskItem(Outlook._Application OutlookApp)
    {
        Outlook.RecurrencePattern pattern = null;
        Outlook.TaskItem task = null;
        try
        {
            task = OutlookApp.CreateItem(Outlook.OlItemType.olTaskItem) as Outlook.TaskItem;
            pattern = task.GetRecurrencePattern();
            pattern.RecurrenceType = Outlook.OlRecurrenceType.olRecursDaily;
            pattern.PatternStartDate = DateTime.Parse("11/02/2012");
            pattern.PatternEndDate = DateTime.Parse("11/03/2012");
            task.ReminderSet = true;
            task.ReminderTime = DateTime.Parse("8:30:00 PM");
            task.Subject = "Don't forget to buy milk! ;-)";
            task.Save();
            task.Display(false);
        }
        catch (Exception ex)
        {
           // System.Windows.Forms.MessageBox.Show(ex.Message);
        }
        finally
        {
            if (pattern != null) Marshal.ReleaseComObject(pattern);
            if (task != null) Marshal.ReleaseComObject(task);
        }
    }

    //private void AssignTaskExample()
    //{
    //    //Outlook.Application 

    //    Outlook.TaskItem task = Outlook.Application.CreateItem(
    //        Outlook.OlItemType.olTaskItem) as Outlook.TaskItem;
    //    task.Subject = "Tax Preparation";
    //    task.StartDate = DateTime.Parse("4/1/2007 8:00 AM");
    //    task.DueDate = DateTime.Parse("4/15/2007 8:00 AM");
    //    Outlook.RecurrencePattern pattern =
    //        task.GetRecurrencePattern();
    //    pattern.RecurrenceType = Outlook.OlRecurrenceType.olRecursYearly;
    //    pattern.PatternStartDate = DateTime.Parse("4/1/2007");
    //    pattern.NoEndDate = true;
    //    task.ReminderSet = true;
    //    task.ReminderTime = DateTime.Parse("4/1/2007 8:00 AM");
    //    task.Assign();
    //    task.Recipients.Add("accountant@example.com");
    //    task.Recipients.ResolveAll();
    //    task.Send();
    //}

    protected void Button1_Click(object sender, EventArgs e)
    {
        string emailFrom = Session["emailAdr"].ToString();

        DateTime startDate = Convert.ToDateTime(txtDueDate.Text);
        DateTime endDate = Convert.ToDateTime(startDate).AddDays(5);

        string RemindDate = Convert.ToDateTime(txtDueDate.Text).ToString("dd/MM/yyyy HH:mm:ss");


        String[] token = RemindDate.Split(' ');

        String[] datetime = token[1].Split(':');

        String timeText = datetime[0]; // The String array contans 21:31:00

        timeText = DropDownList1.SelectedItem.Text;

       // timeText = "08:00:00";

        string fnlDateTime = txtDueDate.Text + " " + timeText;

        DateTime time = Convert.ToDateTime(fnlDateTime); // Converts only the time
       

        //28/01/2015 00:00:00

        string strTime = DropDownList1.SelectedItem.Text;
        Outlook._Application OutlookApp = new Outlook.Application();

        Outlook.RecurrencePattern pattern = null;
        Outlook.TaskItem task = null;
        try
        {
            task = OutlookApp.CreateItem(Outlook.OlItemType.olTaskItem) as Outlook.TaskItem;
            pattern = task.GetRecurrencePattern();
            pattern.RecurrenceType = Outlook.OlRecurrenceType.olRecursDaily;

            pattern.PatternStartDate = DateTime.Parse(RemindDate.ToString());
            pattern.PatternEndDate = DateTime.Parse(RemindDate.ToString());
            task.ReminderSet = true;

            task.ReminderTime = time;

           // task.ReminderTime = DateTime.Parse("7:58:00 AM");
            task.Subject = "Reminder for Job No. " + Session["jobNo"].ToString() + "";
            task.Body = "This is a reminder from EBSD eBook regarding Job No. " + Session["jobNo"].ToString() + " is due on " + Session["ActionDate"] + "";
            task.Save();
            task.Display(false);
        }
        catch (Exception ex)
        {
            //System.Windows.Forms.MessageBox.Show(ex.Message);
        }
        finally
        {
            if (pattern != null) Marshal.ReleaseComObject(pattern);
            if (task != null) Marshal.ReleaseComObject(task);
        }

        ClientScript.RegisterClientScriptBlock(this.GetType(), "Popup", "<script>alert('Task has been set to Outlook')</script>", false);




       // new JobOrderData().OutlookReminder(emailFrom, emailFrom, "Reminder for Job No. " + Session["jobNo"].ToString() + " and  reminder date " + startDate + " ", " This is a reminder from EBSD eBook regarding Job No. " + Session["jobNo"].ToString() + " is due on " + endDate + "", startDate, endDate);
    
        

        
    //   "This is a reminder from EBSD eBook regarding Job No. 140023 is due on 12-Jun-14 (* What ever Action Due date of the user).
    
    }
    protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
    {
        if (Calendar1.Visible)
            Calendar1.Visible = false;
        else
            Calendar1.Visible = true;  
    }
    protected void Calendar1_SelectionChanged(object sender, EventArgs e)
    {
        txtDueDate.Text = Convert.ToDateTime(Calendar1.SelectedDate).ToString("dd/MMM/yyyy");
        Calendar1.Visible = false;
       
        
        btnOutLook.Enabled = true;
    }
    protected void txtDueDate_TextChanged(object sender, EventArgs e)
    {
        btnOutLook.Enabled = true;
    }
}