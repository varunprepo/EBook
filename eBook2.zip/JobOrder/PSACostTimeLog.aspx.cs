﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Data;
using Datalayer;
using System.Drawing;
using System.Data.SqlClient;

public partial class JobOrder_PSACostTimeLog : System.Web.UI.Page
{
    int _jobID = 0;
    int _admno = 0;
    string connValue = System.Configuration.ConfigurationManager.ConnectionStrings["EBSDEBookConn"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
    {
        _jobID = Convert.ToInt32(Request.QueryString["JobID"]);

        lblJobNo.Text = Request.QueryString["JobNo"];
        lblAbmNo.Text = Request.QueryString["AdndmNO"];

        Session["JobNo"] = Request.QueryString["JobNo"];
        Session["PrjCode"] = Request.QueryString["prjCode"];


        if (lblAbmNo.Text!="")
           _admno = Convert.ToInt32(lblAbmNo.Text);
        if (!IsPostBack)
        {
            FillTab2();
        }
    }
    private void FillTab2()
    {
        try
        {
            DataSet ds = new DataSet();
            ds = (new JobOrderData().GetDDlDetails_PSALog(_jobID));

            //   Convert.ToInt32(txtjobid.Text), txtJobNo.Text, Convert.ToInt32(txtaffair.Text), Convert.ToInt32(txtdept.Text), txtprojcode.Text, txtprojtitle.Text, Convert.ToInt32(txtconsult.Text)));

            if (ds.Tables[0].Rows.Count == 0)
            {
                ds.Tables[0].Rows.Add(ds.Tables[0].NewRow());
            }

            gvDetails.DataSource = ds;
            gvDetails.DataBind();
        }
        catch (Exception ex)
        {
        }
    }
    protected void LinkButton_Click(Object sender, EventArgs e)
    {
        LinkButton txtBox = (sender as LinkButton);
        Session["txtName"] = txtBox.ClientID;
        // Session["txtValue"] = (sender as TextBox).Text;
        Session["JobAdmID"] = txtBox.ToolTip;

        //string url = "~/JobOrder/StakeHolder.aspx";
        string url = "StakeHolder.aspx?jobVOID = <%#Eval(jobVOID)%>";  //subject=<%#Eval("Address") %>"
        string s = "window.open('" + url + "', 'popup_window', 'width=600,height=600,left=100,top=100,resizable=yes');";
        ClientScript.RegisterStartupScript(this.GetType(), "script", s, true);

        // <a href='PSALog.aspx?JobID=<%#Eval("jobID")%>' onclick="openwindowPSALOG(this.href); return false;" style="color: #0000FF"> View Details </a>
    }
    protected void gvDetails_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
    {
    }
    protected void gvDetails_RowCommand(object sender, GridViewCommandEventArgs e)
    {
         double _pmcAmt = 0; double _ebsdAmt = 0; double _consultAmt = 0; ;
         int _pmcTime = 0; int _ebsdTime = 0; int _consultTime = 0;

        int _cntrAdmNo = 0;  string _remarks = string.Empty;
        if (e.CommandName.Equals("AddNew"))
        {
            TextBox cntrAdmNo = (TextBox)gvDetails.FooterRow.FindControl("txtAdmNO_");
            if (cntrAdmNo.Text != "")
                _cntrAdmNo = Convert.ToInt32(cntrAdmNo.Text);

            TextBox consultAmt = (TextBox)gvDetails.FooterRow.FindControl("txtConsultAmt_");
            if (consultAmt.Text != "")
                _consultAmt = Convert.ToDouble(consultAmt.Text);         

            TextBox pmcAmt = (TextBox)gvDetails.FooterRow.FindControl("txtPmcAmt_");
            if (pmcAmt.Text != "")
                _pmcAmt = Convert.ToDouble(pmcAmt.Text);

            TextBox ebsdAmt = (TextBox)gvDetails.FooterRow.FindControl("txtEbsdAmt_");
            if (ebsdAmt.Text != "")
                _ebsdAmt = Convert.ToDouble(ebsdAmt.Text);

            TextBox consultTime = (TextBox)gvDetails.FooterRow.FindControl("txtConsultEOT_");
            if (consultTime.Text != "")
                _consultTime = Convert.ToInt32(consultTime.Text);

            TextBox pmcTime = (TextBox)gvDetails.FooterRow.FindControl("txtPmcEOT_");
            if (pmcTime.Text != "")
                _pmcTime = Convert.ToInt32(pmcTime.Text);          

            TextBox ebsdTime = (TextBox)gvDetails.FooterRow.FindControl("txtEbsdEOT_");
            if (ebsdTime.Text != "")
                _ebsdTime = Convert.ToInt32(ebsdTime.Text);

            TextBox remarks = (TextBox)gvDetails.FooterRow.FindControl("txtRemarks_");
            if (remarks.Text != "")
                _remarks = remarks.Text;

            new JobOrderData().Add_PSALog(_jobID, _pmcAmt, _pmcTime, _ebsdAmt, _ebsdTime, _consultAmt, _consultTime, _admno, _remarks);

            FillTab2();
            lblresult.ForeColor = Color.Green;
        }
    }
    protected void gvDetails_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        GridViewRow gr = (GridViewRow)gvDetails.Rows[e.RowIndex];

        Label txtid = (Label)gr.FindControl("JobVOID");
        // TextBox txtcr = (TextBox)gr.FindControl("lbldate");

        new JobOrderData().Delete_PSALog(Convert.ToInt32(txtid.Text));

        //if (result == 1)
        //{
        //    BindEmployeeDetails();
        lblresult.ForeColor = Color.Red;
        lblresult.Text = " details deleted successfully";
        FillTab2();
        //}

    }
    protected void gvDetails_RowEditing(object sender, GridViewEditEventArgs e)
    {
        gvDetails.EditIndex = e.NewEditIndex;
        FillTab2();
    }
    protected void gvDetails_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
         double _pmcAmt = 0; double _ebsdAmt = 0; double _consultAmt = 0; ;
         int _pmcTime = 0; int _ebsdTime = 0; int _consultTime = 0;
         int _cntrAdmNo = 0; string _remarks = string.Empty;

        GridViewRow gr = (GridViewRow)gvDetails.Rows[e.RowIndex];

        TextBox cntrAdmNo = (TextBox)gr.FindControl("txtAdmNO");
        if (cntrAdmNo.Text != "")
            _cntrAdmNo = Convert.ToInt32(cntrAdmNo.Text);
    
        TextBox pmcAmt = (TextBox)gr.FindControl("txtPmcAmt");
        if (pmcAmt.Text != "")
            _pmcAmt = Convert.ToDouble(pmcAmt.Text);

        TextBox pmcTime = (TextBox)gr.FindControl("txtPmcEOT");
        if (pmcTime.Text != "")
            _pmcTime = Convert.ToInt32(pmcTime.Text);

        TextBox ebsdAmt = (TextBox)gr.FindControl("txtEbsdAmt");
        if (ebsdAmt.Text != "")
            _ebsdAmt = Convert.ToDouble(ebsdAmt.Text);

        TextBox ebsdTime = (TextBox)gr.FindControl("txtEbsdEOT");
        if (ebsdTime.Text != "")
            _ebsdTime = Convert.ToInt32(ebsdTime.Text);

        TextBox consultAmt = (TextBox)gr.FindControl("txtConsultAmt");
        if (consultAmt.Text != "")
            _consultAmt = Convert.ToDouble(consultAmt.Text);

        TextBox consultTime = (TextBox)gr.FindControl("txtConsultEOT");
        if (consultTime.Text != "")
            _consultTime = Convert.ToInt32(consultTime.Text);

        TextBox remarks = (TextBox)gr.FindControl("txtRemarks");
        if (remarks.Text != "")
            _remarks = remarks.Text;

        Label id = (Label)gr.FindControl("JobVOID");

        new JobOrderData().update_PSALog(Convert.ToInt32(id.Text), _pmcAmt, _pmcTime, _ebsdAmt, _ebsdTime, _consultAmt, _consultTime, _admno, _remarks);
        lblresult.ForeColor = Color.Green;

        lblresult.Text = " Details Updated successfully";
        gvDetails.EditIndex = -1;
        FillTab2();

    }
    protected void gvDetails_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            Label lblID = (Label)e.Row.FindControl("jobVOID");
            if (lblID.Text == "")
            {
                e.Row.Visible = false;
            }
        }
    }
    protected void txtMinCode_TextChanged(object sender, EventArgs e)
    {

    }
    protected void txtBudgetRef_TextChanged(object sender, EventArgs e)
    {

    }
    protected void txtProvNo_TextChanged(object sender, EventArgs e)
    {

    }
    public void UpdateMinistryDataForJob(int jobID, string minCode, string budgetRef, string proNo, string cntrNo)
    {
        SqlConnection con = new SqlConnection(connValue);
        SqlCommand cmd = new SqlCommand();
        cmd.CommandType = CommandType.Text;
        cmd.Connection = con;

        cmd.CommandText = "Update BudgetCodes Set ministryCode = @ministryCode,budgetRefNo= @budgetRefNo,provisionNo = @provisionNo Where contractNo=@contractNo";

        if (minCode == "")
            cmd.Parameters.AddWithValue("@ministryCode", System.DBNull.Value);
        else
            cmd.Parameters.AddWithValue("@ministryCode", minCode);

        if (budgetRef == "")
            cmd.Parameters.AddWithValue("@budgetRefNo", System.DBNull.Value);
        else
            cmd.Parameters.AddWithValue("@ministryCode", budgetRef);

        if (proNo == "")
            cmd.Parameters.AddWithValue("@provisionNo", System.DBNull.Value);
        else
            cmd.Parameters.AddWithValue("@ministryCode", proNo);


        cmd.Parameters.AddWithValue("@contractNo", cntrNo);

        try
        {
            con.Open();
            cmd.ExecuteNonQuery();
            con.Dispose();
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            con.Close();
        }

    }
}