﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using Datalayer;
using System.Globalization;
using System.Web.UI.HtmlControls;
using System.IO;
using System.Drawing;

public partial class JobOrder_SearchJobMstr : System.Web.UI.Page
{
    string connValue = System.Configuration.ConfigurationManager.ConnectionStrings["EBSDEBookConn"].ConnectionString;
    string _prjCode = string.Empty; string flag = string.Empty;
    int jobType = 0;
    string _userName = string.Empty; int cntID = 0;
    static IList<string> userRightsColl = null;

    //protected void btn_Click(object sender, EventArgs e)
    //{
    //    MultiSelectionDropDown();
    //}
    //private void MultiSelectionDropDown()
    //{
    //    DropDownList ddl = new DropDownList();
    //    ddl.ID = "ddlChkList";
    //    ListItem lstItem = new ListItem();
    //    ddl.Items.Insert(0, lstItem);
    //    ddl.Width = new Unit(155);
    //    ddl.Attributes.Add("onmousedown", "showdivonClick()");
    //    CheckBoxList chkBxLst = new CheckBoxList();
    //    chkBxLst.ID = "chkLstItem";
    //    chkBxLst.Attributes.Add("onmouseover", "showdiv()");
    //    DataTable dtListItem = GetListItem();
    //    int rowNo = dtListItem.Rows.Count;
    //    string lstValue = string.Empty;
    //    string lstID = string.Empty;

    //    for (int i = 0; i < rowNo - 1; i++)
    //    {
    //        lstValue = dtListItem.Rows[i]["CmpName"].ToString();
    //        lstID = dtListItem.Rows[i]["companyID"].ToString();

    //        Response.Write(lstValue + lstValue);


    //        lstItem = new ListItem("<a href=\"javascript:void(0)\" id=\"alst\" style=\"text-decoration:none;color:Black; \" onclick=\"getSelectedItem(' " + lstValue + "','" + i + "','" + lstID + "','anchor');\">" + lstValue + "</a>", dtListItem.Rows[i]["companyID"].ToString());
    //        lstItem.Attributes.Add("onclick", "getSelectedItem('" + lstValue + "','" + i + "','" + lstID + "','listItem');");
            
    //        chkBxLst.Items.Add(lstItem);
    //    }

    //    System.Web.UI.HtmlControls.HtmlGenericControl div = new System.Web.UI.HtmlControls.HtmlGenericControl("div");
    //    div.ID = "divChkList";
    //    div.Controls.Add(chkBxLst);
    //    div.Style.Add("border", "black 1px solid");
    //    div.Style.Add("width", "160px");
    //    div.Style.Add("height", "180px");
    //    div.Style.Add("overflow", "AUTO");
    //    div.Style.Add("display", "none");
    //    phDDLCHK.Controls.Add(ddl);
    //    phDDLCHK.Controls.Add(div);
    //}

    //private DataTable GetListItem()
    //{
    //    DataTable dt = new DataTable();
    //    using (SqlConnection con = new SqlConnection(connValue))
    //    {
    //        using (SqlCommand cmd = new SqlCommand())
    //        {
    //            cmd.CommandText = "SELECT Top 9 companyID,CmpName FROM Company";
    //            cmd.Connection = con;
    //            using (SqlDataAdapter sda = new SqlDataAdapter(cmd))
    //            {
                    
    //                sda.Fill(dt);
                    
    //            }
    //        }
    //    }

    //    return dt;
    //}
    
    protected void lnkProjectCodeCmted_Click(object sender, EventArgs e)     //ForCommitted
    {
        try
        {
            LinkButton lnkJobID = (LinkButton)sender;
            GridViewRow gvr = (GridViewRow)lnkJobID.NamingContainer;
            Session["ProjectCode"] = ((HtmlGenericControl)gvr.FindControl("divProjectCodeCmted")).InnerText;

            Session["UrlRef"] = Request.Url.AbsoluteUri;
            Response.Redirect("~/JobOrder/SearchJobMstr.aspx?Project_Code = " + Session["ProjectCode"] + "", false);

        }
        catch
        {

        }
    }
    protected void lnkCostVOSILog_Click(object sender, EventArgs e)     
    {
        try
        {
            LinkButton lnkcostVoLog = (LinkButton)sender;
            GridViewRow gvr = (GridViewRow)lnkcostVoLog.NamingContainer;
            Session["divCatID"] = ((HtmlGenericControl)gvr.FindControl("divCatID")).InnerText;
            Session["divProjectCodeCmted"] = ((HtmlGenericControl)gvr.FindControl("divProjectCodeCmted")).InnerText;
            Session["divJobID"] = ((HtmlGenericControl)gvr.FindControl("divJobID")).InnerText;
            Session["divJobNo"] = ((HtmlGenericControl)gvr.FindControl("divJobNo")).InnerText;

            Session["UrlRef"] = Request.Url.AbsoluteUri;
            if (Session["divCatID"].ToString().Equals("4") || Session["divCatID"].ToString().Equals("7"))
            {
                if (!userRightsColl.Contains("41"))
                {
                    UtilityClass utils = null;
                    try
                    {
                        utils = new UtilityClass(this.Page);
                        string url = Request.Url.AbsoluteUri;
                        Session["Url"] = Request.Url.AbsoluteUri;
                        if (url.Contains(":"))
                            url = url.Substring(0, utils.GetNthIndex(url, '/', 4));
                        else
                            url = url.Substring(0, utils.GetNthIndex(url, '/', 2));
                        url = url + "/JobOrder/CostVOSILog.aspx?PSAprjCode=" + Session["divProjectCodeCmted"] + "&JobID= " + Session["divJobID"] + "&PSAJobNo= " + Session["divJobNo"] + "";
                        OpenPageByUsingJS(url, "850", "850");
                    }
                    catch (Exception ex)
                    {
                        this.Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Error occurred while processing the request')</script>", false);
                    }
                }

                // Response.Redirect("~/JobOrder/JobOrderVOLog.aspx?PSAprjCode=" + Session["divProjectCodeCmted"] + "&JobID= " + Session["divJobID"] + "&PSAJobNo= " + Session["divJobNo"] + "", false);

                // Response.Redirect("~/Documents/DocumentDetailsWindow.aspx?docRecID=" + docid + "&RecSentCatID= " + docCatid + "", false);
            }
            else
            {
                UtilityClass utils = null;
                try
                {
                    utils = new UtilityClass(this.Page);
                    string url = Request.Url.AbsoluteUri;
                    Session["Url"] = Request.Url.AbsoluteUri;
                    if (url.Contains(":"))
                        url = url.Substring(0, utils.GetNthIndex(url, '/', 4));
                    else
                        url = url.Substring(0, utils.GetNthIndex(url, '/', 2));
                    url = url + "/JobOrder/JobOrderVOLog.aspx?PSAprjCode=" + Session["divProjectCodeCmted"] + "&JobID= " + Session["divJobID"] + "&PSAJobNo= " + Session["divJobNo"] + "";
                    OpenPageByUsingJS(url, "970", "650");
                }
                catch (Exception ex)
                {
                    this.Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Error occurred while processing the request')</script>", false);
                }
            }

        }
        catch
        {

        }
    }


    private void OpenPageByUsingJS(string url, string width, string height)
    {
        string s = "window.open('" + url + "', 'popup_window', 'width=" + width + ",height=" + height + "left=100,top=100,resizable=yes');";
        Page.ClientScript.RegisterStartupScript(this.GetType(), "script", s, true);
    }


    protected void lnkJobOrderJobNo_Click(object sender, EventArgs e)     //ForCommitted
    {
        try
        {
            LinkButton lnkJobID = (LinkButton)sender;
            GridViewRow gvr = (GridViewRow)lnkJobID.NamingContainer;

            Session["JobID"] = ((HtmlGenericControl)gvr.FindControl("divJobID")).InnerText;

            Session["UrlRef"] = Request.Url.AbsoluteUri;
            Response.Redirect("~/JobOrder/DefaultGrid.aspx?JobID= " + Session["JobID"] + "", false);

        }
        catch
        {

        }
    }    
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["UserName"] == null)
        {
            Response.Redirect("~/LoginPage.aspx", false);
            return;
        }

        string chartStatus = string.Empty;

        userRightsColl = (IList<string>)Session["UserRightsColl"];

        if (Session["ProjectCode"]!=null)
         _prjCode = Session["ProjectCode"].ToString(); // Request.QueryString["ProjCode"];      
        
        if (Session["Flag"] != null)
            flag = Session["Flag"].ToString();

          cntID = new JobOrderData().getUserID(_userName);

          DataTable dt = new DataTable();

        if (!IsPostBack)
        {
            int sectionID = Convert.ToInt16(Session["SectionID"]);
            FillDropBox(sectionID);
            DataView dvCommitted = new DataView();
            if (_prjCode == null)
            {
                dt = FillTab2(0, "");     //  SearchJob
               Session["ChartJobs"] = dt;
               gvJoborder.DataSource = dt;
               gvJoborder.DataBind();

                FillTabByJobNo(0, "");

                lblCnt.Text = dt.Rows.Count.ToString();
            }
            else
            {
                 dt = FillTab2(0, _prjCode);
                Session["ChartJobs"] = dt;
                gvJoborder.DataSource = dt;
                gvJoborder.DataBind();

                lblCnt.Text = dt.Rows.Count.ToString();
            }
        }

        //if (Session["OnGoingJobStatus"] != null)
        //{
        //    chartStatus = Session["OnGoingJobStatus"].ToString();           
        //    DataView dvChartCommited = new DataView();
        //    dvChartCommited = Session["ChartJobs"] as DataView;
        //         //dvChartCommited = Session["CommittedInfo"] as DataView;

        //   // dvChartCommited.RowFilter = "JobTypeName = '" + Session["OnGoingJobStatus"].ToString() + "'";
        //    dvChartCommited = dt.DefaultView;
        //    if (dvChartCommited.Count >0)
        //    {                
        //        dvChartCommited.RowFilter = "Job_Type = '" + Session["OnGoingJobStatus"].ToString() + "'";
        //    }          

        //    gvJoborder.DataSource = dvChartCommited;              
        //    gvJoborder.DataBind();
        //}
        //else
        //{

        //}
        //if (Session["cntID"] != null)
        //{
        //    string cnctID = Session["cntID"].ToString();

        //    DataView dvChartCommited = new DataView();
        //    dvChartCommited = Session["ChartJobs"] as DataView;

        //    dvChartCommited.RowFilter = "QSNAME = '" + Session["cntID"].ToString() + "' or CENAME = '" + Session["cntID"].ToString() + "' ";
        //    gvJoborder.DataSource = dvChartCommited;
        //    gvJoborder.DataBind();
        //}

        
        
    }   
    
    
    public void FillDropBox(int _sectionID)
    {

        PopulateDropDownBox(ddlJobNo, "SELECT Job.jobID, Job.jobNo FROM Job INNER JOIN JobType ON Job.jobTypeID = JobType.jobTypeID WHERE (JobType.CategoryID IN (3, 4, 5, 6, 7)) ORDER BY Job.jobNo", "jobID", "jobNo");

        // PopulateDropDownBox(ddlJobType, "SELECT jobTypeID, jobTypeName FROM JobType where sectionID = " + _sectionID + "  ORDER BY jobTypeName", "jobTypeID", "jobTypeName");
       
        PopulateDropDownBox(ddlJobType, "SELECT DISTINCT JobType.jobTypeID, JobType.jobTypeName FROM JobType INNER JOIN Job ON JobType.jobTypeID = Job.jobTypeID WHERE (JobType.CategoryID IN (3, 4, 5, 6, 7)) ORDER BY JobType.jobTypeName", "jobTypeID", "jobTypeName");


        PopulateDropDownBox(ddlJobStatus_, "SELECT jobStatusID, jobStatusName FROM JobStatus where jobStatusID in(1,2,3,4,5,6,7) ORDER BY jobStatusName", "jobStatusID", "jobStatusName");

        PopulateDropDownBox(ddlTeamLead, "SELECT teamLeaderID, teamLeaderName FROM EBSDTeamLeaders  ORDER BY teamLeaderName", "teamLeaderID", "teamLeaderName");

        //string strDocQuery = "SELECT [Document].documentID, [Document].referenceNo, Job.jobCreatedByID,  Job.docRefID, Job.jobNo, Job.jobID " + 
        //                " FROM Job INNER JOIN [Document] ON Job.docRefID = [Document].documentID WHERE (Job.jobCatID IN (3, 4, 5, 6, 7))";


        string strDocQuery = "SELECT  [Document].documentID, [Document].referenceNo FROM  Job INNER JOIN  [Document] ON Job.docRefID = [Document].documentID INNER JOIN JobType ON Job.jobTypeID = JobType.jobTypeID  WHERE  (JobType.CategoryID IN (3, 4, 5, 6, 7)) ORDER BY [Document].referenceNo";
        PopulateDropDownBox(ddlDocRef, strDocQuery, "documentID", "referenceNo");

        PopulateDropDownBox(ddlAffair, "SELECT  departmentID, deptName FROM  Department WHERE (affairID IS NULL) ORDER BY deptName", "departmentID", "deptName");
        PopulateDropDownBox(ddlDept, "SELECT departmentID, deptName FROM  Department WHERE (affairID IS NOT NULL) ORDER BY deptName", "departmentID", "deptName");

        PopulateDropDownBox(ddlVendor, "SELECT DISTINCT Company.companyID, Company.cmpName FROM   Job INNER JOIN Company ON Job.consultantID = Company.companyID INNER JOIN JobType ON Job.jobTypeID = JobType.jobTypeID WHERE  (JobType.CategoryID IN (3, 4, 5, 6, 7)) ORDER BY Company.cmpName", "companyID", "cmpName");

        string strCntr = "SELECT DISTINCT Company.companyID, Company.cmpName FROM   Job INNER JOIN Company ON Job.contractorID = Company.companyID INNER JOIN JobType ON Job.jobTypeID = JobType.jobTypeID WHERE  (JobType.CategoryID IN (3, 4, 5, 6, 7)) ORDER BY Company.cmpName";
        PopulateDropDownBox(ddlContractor, strCntr, "companyID", "cmpName");

        PopulateDropDownBoxQS(ddlQS, "SELECT DISTINCT Contact.contactID, Contact.userShortName FROM  Contact INNER JOIN Job ON Contact.contactID = Job.qsID INNER JOIN JobType ON  Job.jobTypeID = JobType.jobTypeID WHERE (JobType.CategoryID in(3,4,5,6,7))  ORDER BY Contact.userShortName", "ContactID", "userShortName");
        PopulateDropDownBoxQS(ddlPE, "SELECT DISTINCT Contact.contactID, Contact.userShortName FROM  Contact INNER JOIN Job ON Contact.contactID = Job.peID INNER JOIN JobType ON  Job.jobTypeID = JobType.jobTypeID WHERE (JobType.CategoryID in(3,4,5,6,7))  ORDER BY Contact.userShortName", "ContactID", "userShortName");
        PopulateDropDownBoxQS(ddlCE, "SELECT DISTINCT Contact.contactID, Contact.userShortName FROM  Contact INNER JOIN Job ON Contact.contactID = Job.ceID INNER JOIN JobType ON  Job.jobTypeID = JobType.jobTypeID WHERE (JobType.CategoryID in(3,4,5,6,7))  ORDER BY Contact.userShortName", "ContactID", "userShortName");


        PopulateDropDownBox(ddlPrjCode, "SELECT DISTINCT Job.contractNo, Job.contractNo  FROM job INNER JOIN JobType ON Job.jobTypeID = JobType.jobTypeID WHERE    (JobType.CategoryID IN (3, 4, 5, 6, 7)) ORDER BY Job.contractNo", "contractNo", "contractNo");

        PopulateDropDownBox(ddlVODetails, "select voID,voDesc FROM dbo.VODetails  where voID in (select voID from JobVODetails)", "voID", "voDesc");
        PopulateDropDownBox(ddlEOTDetails, "select eotID,eotDesc FROM dbo.EOTDetails  where eotID in (select eotID from JobEOTDetails)", "eotID", "eotDesc");

        string strDocClose = "SELECT [Document].documentID, [Document].referenceNo FROM Job INNER JOIN  [Document] ON Job.closedDocRefID = [Document].documentID INNER JOIN JobType ON Job.jobTypeID = JobType.jobTypeID WHERE  (JobType.CategoryID IN (3, 4, 5, 6, 7))";
        PopulateDropDownBox(ddlClsDoc, strDocClose, "documentID", "referenceNo");
        
    }
    private IList<string> getProjectCodeList()
    {
        IList<string> prjCodeColl = new List<string>();

        return prjCodeColl;
    } 
    protected void btnSearch_Click(object sender, EventArgs e)
    {
        Session["OnGoingJobStatus"] = null;

        DataTable dt = new DataTable();
       
        dt = FillTab2(0, "");

        Session["OnGoingJobStatus"] = dt;

        gvJoborder.DataSource = dt;
        gvJoborder.DataBind();

       lblCnt.Text = dt.Rows.Count.ToString();
    }
    private void PopulateDropDownBox(DropDownList ddlBox, string sqlQuery, string valueMember, string displayName)
    {
        ddlBox.DataBound += new EventHandler(this.ddlBox_DataBound);
        ddlBox.DataSource = new JobOrderData().FillDropdown(sqlQuery);
        ddlBox.DataTextField = displayName;
        ddlBox.DataValueField = valueMember;
        ddlBox.SelectedIndex = -1;
        ddlBox.DataBind();
    }
    private void PopulateDropDownBoxQS(DropDownList ddlBox, string sqlQuery, string valueMember, string displayName)
    {
        
        ddlBox.DataSource = new JobOrderData().FillDropdown(sqlQuery);
        ddlBox.DataTextField = displayName;
        ddlBox.DataValueField = valueMember;
        ddlBox.SelectedIndex = -1;
        ddlBox.DataBind();
      
        ListItem emptyItem123 = new ListItem("ALL", "ALL");
        ddlBox.Items.Insert(0, emptyItem123);

        ListItem emptyItem = new ListItem("", "");
        ddlBox.Items.Insert(0, emptyItem);
    }
    protected void ddlBox_DataBound(object sender, EventArgs e)
    {
        DropDownList ddl = (DropDownList)sender;
        ListItem emptyItem = new ListItem("", "");
        ddl.Items.Insert(0, emptyItem);
    }
    protected void ddlBoxQS_DataBound(object sender, EventArgs e)
    {
        DropDownList ddl = (DropDownList)sender;
        ListItem emptyItem = new ListItem("ALL", "ALL");
        ddl.Items.Insert(0, emptyItem);
    }
    private void PopulateDropDownBox_TCMS(DropDownList ddlBox, string sqlQuery, string valueMember, string displayName)
    {
        ddlBox.DataSource = new JobOrderData().FillDropdown_TCMS(sqlQuery);
        ddlBox.DataTextField = displayName;
        ddlBox.DataValueField = valueMember;
        ddlBox.SelectedIndex = -1;
        ddlBox.DataBind();
    }
    private DataTable FillTabByJobNo(int searchType, string _prjCode)
    {
        DataSet ds = new DataSet();
        try
        {
            Int16 jobid;
            Int16.TryParse(ddlJobNo.SelectedValue, out jobid);

            Int16 afrID;
            Int16.TryParse(ddlAffair.SelectedValue, out afrID);

            Int16 dptID;
            Int16.TryParse(ddlDept.SelectedValue, out dptID);

            Int16 consID;
            Int16.TryParse(ddlVendor.SelectedValue, out consID);

            Int16 jobType;
            Int16.TryParse(ddlJobType.SelectedValue, out jobType);

            Int16 jobStatus;
            Int16.TryParse(ddlJobStatus_.SelectedValue, out jobStatus);

            Int16 docRefID;
            Int16.TryParse(ddlDocRef.SelectedValue, out docRefID);

            Int16 docClsRefID;
            Int16.TryParse(ddlClsDoc.SelectedValue, out docClsRefID);

            Int16 qsID;
            Int16.TryParse(ddlQS.SelectedValue, out qsID);

            Int16 ceID;
            Int16.TryParse(ddlCE.SelectedValue, out ceID);

            Int16 peID;
            Int16.TryParse(ddlPE.SelectedValue, out peID);

            string prjTitle = string.Empty;
            if (txtTitle.Text != "")
                prjTitle = "%" + txtTitle.Text + "%";

            string docSubject = string.Empty;
            if (txtSubject.Text != "")
                docSubject = "%" + txtSubject.Text + "%";


            Int16 cntrID;
            Int16.TryParse(ddlContractor.SelectedValue, out cntrID);

            Int16 consultID;
            Int16.TryParse(ddlVendor.SelectedValue, out consultID);

            string prjCode = string.Empty;
            if (_prjCode != "")
            {
                ddlPrjCode.SelectedItem.Text = _prjCode;
                prjCode = _prjCode;
            }
            else
                prjCode = ddlPrjCode.SelectedItem.Text;

            if (ddlPrjCode.SelectedItem.Text != "")
                prjCode = ddlPrjCode.SelectedItem.Text;


            string txtfrom = string.Empty;
            if (txtdept.Text != "")
                txtfrom = txtdept.Text;

            Int16 VOID;
            Int16.TryParse(ddlVODetails.SelectedValue, out VOID);

            Int16 EOTID;
            Int16.TryParse(ddlEOTDetails.SelectedValue, out EOTID);


            string _jobNo = string.Empty;
            if (txtJobNo.Text != "")
                _jobNo = "%" + txtJobNo.Text + "%";

            string _refNo = string.Empty;
            if (txtDocRefNo.Text != "")
                _refNo = "%" + txtDocRefNo.Text + "%";

            string _ClsrefNo = string.Empty;
            if (txtClsDocRefNo.Text != "")
                _ClsrefNo = "%" + txtClsDocRefNo.Text.Trim() + "%";

            string _contractNo = string.Empty;
            if (txtPrjNo.Text != "")
                _contractNo = "%" + txtPrjNo.Text + "%";


            //ds = (new JobOrderData().GetJobOrderDetailsByJobNo(searchType,jobid,jobTypeID,jobStatusID,AffairID,dptID,docRefID,qsID,ceID,peID,prjTitle,cntrID,consultID,prjCode,txtfrom,docSub,

            ds = (new JobOrderData().GetJobOrderDetailsByJobNo(searchType, jobid, jobType, jobStatus, afrID, dptID, docRefID, qsID, ceID, peID, prjTitle, cntrID, consultID, prjCode, txtfrom, docSubject, docClsRefID, _jobNo, _refNo, _contractNo, _ClsrefNo));   //sp_SearchJobByJobNO

           // ds = (new JobOrderData().GetJobOrderDetailsByJobNo (searchType, jobid, jobType, jobStatus, afrID, dptID, docRefID, qsID, ceID, peID, prjTitle, cntrID, consultID, prjCode, txtfrom, VOID, EOTID, docSubject, docClsRefID, _jobNo));
          
        }
        catch (Exception ex)
        {

        }
        return ds.Tables[0];
    }   
    private DataTable FillTab2(int searchType, string _prjCode)
    {
        DataSet ds = new DataSet();
        try
        {     
            Int16 jobid;
            Int16.TryParse(ddlJobNo.SelectedValue, out jobid);

            Int16 afrID;
            Int16.TryParse(ddlAffair.SelectedValue, out afrID);

            Int16 dptID;
            Int16.TryParse(ddlDept.SelectedValue, out dptID);

            Int16 consID;
            Int16.TryParse(ddlVendor.SelectedValue, out consID);

            Int16 jobType;
            Int16.TryParse(ddlJobType.SelectedValue, out jobType);

            Int16 jobStatus;
            Int16.TryParse(ddlJobStatus_.SelectedValue, out jobStatus);

            Int16 docRefID;
            Int16.TryParse(ddlDocRef.SelectedValue, out docRefID);

            Int16 docClsRefID;
            Int16.TryParse(ddlClsDoc.SelectedValue, out docClsRefID);
            
            Int16 qsID;
            if (ddlQS.SelectedValue != "ALL")                  
                Int16.TryParse(ddlQS.SelectedValue, out qsID);        
            else
            {
                qsID = -1;             
                Int16.TryParse(qsID.ToString(), out qsID);
            }

            Int16 ceID;
            if (ddlCE.SelectedValue != "ALL")    
              Int16.TryParse(ddlCE.SelectedValue, out ceID);
            else
            {
                ceID = -1;
                Int16.TryParse(ceID.ToString(), out ceID);
            }

            Int16 peID;
            if (ddlPE.SelectedValue != "ALL")    
              Int16.TryParse(ddlPE.SelectedValue, out peID);
            else
            {
                peID = -1;
                Int16.TryParse(peID.ToString(), out peID);
            }

            string prjTitle = string.Empty; 
            if (txtTitle.Text != "")
                prjTitle = "%" + txtTitle.Text + "%";

            string docSubject = string.Empty;
            if (txtSubject.Text != "")
                docSubject = "%" + txtSubject.Text + "%";


            Int16 cntrID;
            Int16.TryParse(ddlContractor.SelectedValue, out cntrID);

            Int16 consultID;
            Int16.TryParse(ddlVendor.SelectedValue, out consultID);

            string prjCode = string.Empty;
            if (_prjCode != "")
            {
                ddlPrjCode.SelectedItem.Text = _prjCode;
                prjCode = _prjCode;
            }
            else
                prjCode = ddlPrjCode.SelectedItem.Text;   

            if (ddlPrjCode.SelectedItem.Text != "")
                prjCode = ddlPrjCode.SelectedItem.Text;



            string txtfrom = string.Empty;
            if (txtdept.Text != "")
                txtfrom = txtdept.Text;


            string txtTo = string.Empty;
            if (txtToDate.Text != "")
                txtTo = txtToDate.Text;

            Int16 VOID;
            Int16.TryParse(ddlVODetails.SelectedValue, out VOID);

            Int16 EOTID;
            Int16.TryParse(ddlEOTDetails.SelectedValue, out EOTID);


            Int16 leadID;
            Int16.TryParse(ddlTeamLead.SelectedValue, out leadID);


            Int16 teamMemID;
            Int16.TryParse(ddlTeamMember.SelectedValue, out teamMemID);

            string str = searchType + "," + jobid + "," + jobType + "," + jobStatus + "," + afrID + "," + dptID + "," + docRefID + "," + qsID + "," + ceID + "," + peID + "," + prjTitle + "," + cntrID + "," + consultID + "," + prjCode + "," + txtfrom + "," + VOID + "," + EOTID + "," + docSubject + "," + docClsRefID + "," + txtTo + "," + leadID + "," + teamMemID;
            ds = (new JobOrderData().GetJobOrderDetails(searchType, jobid, jobType, jobStatus, afrID, dptID, docRefID, qsID, ceID, peID, prjTitle, cntrID, consultID, prjCode, txtfrom, VOID, EOTID, docSubject, docClsRefID, txtTo, leadID, teamMemID));
         
        }
        catch (Exception ex)
        {
            
        }
        return ds.Tables[0];
    }   
    protected void gvJoborder_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        gvJoborder.PageIndex = e.NewPageIndex;
        bindGridView();

        DataTable dt = new DataTable();
        dt = FillTab2(0, "");
        
        Session["ChartJobs"] = dt;

        gvJoborder.DataSource = dt;
        gvJoborder.DataBind();
    }
    private string getDaysByGivenEndDate(string strDate, string endDate)
    {
        strDate = Convert.ToDateTime(strDate).ToString("MM/dd/yyyy", CultureInfo.InvariantCulture);
        endDate = Convert.ToDateTime(endDate).ToString("MM/dd/yyyy", CultureInfo.InvariantCulture);

        DateTime strDt = DateTime.ParseExact(strDate, "MM/dd/yyyy", CultureInfo.InvariantCulture);
        DateTime endDt = DateTime.ParseExact(endDate, "MM/dd/yyyy", CultureInfo.InvariantCulture);

        SqlConnection con = new SqlConnection(connValue);
        SqlCommand cmd = new SqlCommand();

        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Connection = con;

        cmd.CommandText = "testSP";

        SqlParameter prm = cmd.Parameters.Add("@ad_startDate", SqlDbType.DateTime);
        prm.Value = strDt;

        prm = cmd.Parameters.Add("@ad_endDate", SqlDbType.DateTime);
        prm.Value = endDt;

        prm = cmd.Parameters.Add("@ai_workDays", SqlDbType.Int);
        prm.Direction = ParameterDirection.Output;

        //prm = cmd.Parameters.Add("@as_errMsg", SqlDbType.VarChar);
        //prm.Direction = ParameterDirection.Output;

        con.Open();
        SqlDataReader dr = cmd.ExecuteReader();
        while (dr.Read())
            Console.WriteLine(dr.GetString(0));
        con.Dispose();
        con.Close();

        return cmd.Parameters[2].Value.ToString();
    }
    protected void gvJoborder_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            Label qs = (Label)e.Row.FindControl("lblQS");
            Label ce = (Label)e.Row.FindControl("lblCE");
            Label pe = (Label)e.Row.FindControl("lblPE");
            Label dc = (Label)e.Row.FindControl("lblDC");

            Label jobNo = (Label)e.Row.FindControl("lblJobNo"); //
           // Label ancrJobNo = (Label)e.Row.FindControl("ancrJobNo");

           

            Label lblJobRecDate = (Label)e.Row.FindControl("lblCmtRecDate");
            Label lblJobStatus = (Label)e.Row.FindControl("lblJobStatus");

           // string jobOrderStat = Convert.ToInt16(lblJobStatus.Text);

            string jobOrderStat = lblJobStatus.Text;    //On-going

            if ((lblJobRecDate.Text != ""))       //& (lblJobStatus.Text.Equals("Under Process with EBSD"))
            {
                string elapsedDays = getDaysByGivenEndDate(lblJobRecDate.Text, System.DateTime.Now.ToString());
                Label WorkDays = (Label)e.Row.FindControl("lblDays");
                int extraDays = Convert.ToInt16(WorkDays.Text);
                extraDays = (extraDays / 2);

                int totalDays = Convert.ToInt16(WorkDays.Text) + extraDays;

                if ((jobOrderStat.Equals("On-going")) || (jobOrderStat.Equals("Pending")) || (jobOrderStat.Equals("On Hold")))
                {
                    if (totalDays < Convert.ToInt16(elapsedDays))
                    {
                        e.Row.BackColor = System.Drawing.Color. LightPink;
                        e.Row.ForeColor = System.Drawing.Color.Red;

                        e.Row.Font.Bold = true;

                        jobNo.BackColor = System.Drawing.Color.Yellow;
                        e.Row.Cells[1].BackColor = System.Drawing.Color.White;
                    }
                    else if (Convert.ToInt16(WorkDays.Text) < Convert.ToInt16(elapsedDays))
                    {
                        e.Row.BackColor = System.Drawing.Color.MistyRose;


                        jobNo.BackColor = System.Drawing.Color.Yellow;
                        e.Row.Cells[1].BackColor = System.Drawing.Color.White;
                    }
                }
            }

            string strQS = qs.Text; string strCE = ce.Text; string strPE = pe.Text; string strDC = dc.Text;
                string JobOrderstatus = lblJobStatus.Text;

                if ((JobOrderstatus == "Closed") || (JobOrderstatus == "Cancelled") || (JobOrderstatus == "Completed") || (JobOrderstatus == "Rejected"))
                {

                }
                else
                {
                    if ((strQS == "") & (strPE == "") & (strCE == "") & (strDC == ""))
                    {
                        jobNo.BackColor = System.Drawing.Color.Red;
                        e.Row.Cells[1].BackColor = System.Drawing.Color.Red;
                       
                    }
                
                }

                //if (userRightsColl.Contains("3"))
                //{
                //    LinkButton l = (LinkButton)e.Row.FindControl("btnDelete");
                //    l.Attributes.Add("onclick", "javascript:return " + "confirm('Are you sure you want to delete this Job')");
                //    l.CssClass = "btndelete";
                //    //l.Attributes.Add("CssClass", "btnSearch");  
                //}


                LinkButton l = (LinkButton)e.Row.FindControl("btnDelete");
                l.Attributes.Add("onclick", "javascript:return " + "confirm('Are you sure you want to delete this Job')");
                l.CssClass = "btndelete";
           
        }
    }
    private void bindGridView()
    {
        gvJoborder.DataSource = Session["ChartJobs"];
        gvJoborder.DataBind();
        
    }
    protected void btnClear_Click(object sender, EventArgs e)
    {
        Session["ProjectCode"] = null;

        ClearData();

        DataTable dt = new DataTable();

        
        dt = FillTab2(0, "");
        gvJoborder.DataSource = dt;      
        gvJoborder.DataBind();

        lblCnt.Text = dt.Rows.Count.ToString();
    }
    private void ClearData()
    {
        ddlJobNo.SelectedIndex = 0;
        ddlJobType.SelectedIndex = 0;
        ddlJobStatus_.SelectedIndex = 0;
        ddlDocRef.SelectedIndex = 0;     
        ddlAffair.SelectedIndex = 0;
        ddlDept.SelectedIndex = 0;
        ddlPrjCode.SelectedIndex = 0;       
        ddlPrjCode.SelectedIndex = 0;
        ddlVendor.SelectedIndex = 0;
        ddlContractor.SelectedIndex = 0;
        ddlQS.SelectedIndex = 0;
        ddlPE.SelectedIndex = 0;
        ddlCE.SelectedIndex = 0;
        ddlVODetails.SelectedIndex = 0;
        ddlEOTDetails.SelectedIndex = 0;
        ddlPrjCode.SelectedItem.Text = "";
        ddlClsDoc.SelectedIndex = 0;
        ddlTeamLead.SelectedIndex = 0;
        ddlTeamMember.SelectedIndex = 0;

        txtTitle.Text = "";
        txtdept.Text = "";
        txtSubject.Text = "";
        txtJobNo.Text = "";
        txtDocRefNo.Text = "";
        txtPrjNo.Text = ""; 
        txtToDate.Text = "";
        txtClsDocRefNo.Text = "";
        
    }
    protected void gvJoborder_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandArgument != "")
        {
            int jobid = Convert.ToInt16(e.CommandArgument);
            switch (e.CommandName)
            {
                case "EditJobid":

                    ReplytoCloseCommittedJobs(jobid);

                    // Response.Redirect("DefaultGrid.aspx");

                    break;

                case "DeleteJobid":

                    AccessRightsForDelete();

                    if (!userRightsColl.Contains("3"))
                    {
                        int flag = (new JobOrderData().DeleteJobOrder(jobid));
                        new JobOrderData().DeactivateDocumentForJobDelete(jobid);

                        new JobOrderData().UpdateIsConfirmFalseOnJobDelete(jobid);

                        if (flag > 0)
                        {
                            // Response.Write("deleted");
                        }
                    }

                    break;
            }
        }
    }
    private void AccessRightsForDelete()
    {
        if (userRightsColl.Contains("3"))   //Add New Project
        {
            Session["lblText"] = "You are not allowed to delete a Job Order.Please contact system Administrator for further inquiry.";
            Session["lblSub"] = "Restricted Access to delete a Job Order.";
            Session["lblBody"] = "This is in reference to Restricted Access to delete a Job Order. I would like to inquire about the restriction.";


            string url = "RestrictedMsgWindow.aspx";
            string s = "window.open('" + url + "', 'popup_window', 'width=500,height=250,left=100,top=100,resizable=yes,scrollbars=yes');";
            ClientScript.RegisterStartupScript(this.GetType(), "script", s, true);
        }
    }

    private void ReplytoCloseCommittedJobs(int jobid)
    {
        if (userRightsColl.Contains("9"))   //Add New Document
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('You have no privilege to this action,Contact administrator')</script>", false);
            return;
        }
        else
        {
            Session["ReplyToClose"] = "1";
            Session["DocCategoryID"] = "2";
            Session["DocID"] = null;
            Session["UrlRef"] = "~/JobOrder/JobOrder.aspx";
            Session["JobID"] = jobid;
            Response.Redirect("~/Documents/DocumentDetails.aspx", false);
         }        
    }
    protected void OpenWindow(object sender, EventArgs e)
    {
        if (userRightsColl.Contains("2"))   //Add New Project
        {
            Session["lblText"] = "You are not allowed to Add New Job Order.Please contact system Administrator for further inquiry.";
            Session["lblSub"] = "Restricted Access to Add New Job Order.";
            Session["lblBody"] = "This is in reference to Restricted Access to Add New Job Order. I would like to inquire about the restriction.";


            string url = "RestrictedMsgWindow.aspx";
            string s = "window.open('" + url + "', 'popup_window', 'width=500,height=250,left=100,top=100,resizable=yes,scrollbars=yes');";
            ClientScript.RegisterStartupScript(this.GetType(), "script", s, true);



            //ClientScript.RegisterClientScriptBlock(this.GetType(), "Popup", "<script>alert('You have no privilege to add this Job,Contact administrator.')</script>", false);
            //return;
        }
        else if (Session["SectionID"].ToString().Equals("41"))
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "Popup", "<script>alert('This is not applicable to all employees from EBSD Payment Section.')</script>", false);
            return;
        }
        else
        {
            string url = "JobEntryForm.aspx";
            string s = "window.open('" + url + "', 'popup_window', 'width=990,height=700,left=100,top=100,resizable=yes,scrollbars=yes');";
            ClientScript.RegisterStartupScript(this.GetType(), "script", s, true);
        }

    }
    protected void btnBack_Click(object sender, EventArgs e)
    {
        if (Session["UrlRef"] != null)        
          Response.Redirect(Session["UrlRef"].ToString(), false); 
        else
            Response.Redirect("~/JobOrder/JobOrder.aspx", false);
    }
    
    protected void lnkBtnNonCmtJobID_Click(object sender, EventArgs e)
    {

        //try
        //{
        //    LinkButton lnkSearchAdm = (LinkButton)sender;
        //    GridViewRow gvr = (GridViewRow)lnkSearchAdm.NamingContainer;

        //    DataTable dt = Session["AdmData"] as DataTable;

        //    if (_prjCode != null)
        //    {
        //        DataRow[] rows = dt.Select("contractNo = " + _prjCode);
        //        if (rows.Length > 0)
        //            dt = rows.CopyToDataTable();
        //    }

        //    gvJoborder.DataSource = dt;
        //    gvJoborder.DataBind();
        //}
        //catch (Exception ex)
        //{
        //    ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Error occurred while processing the request')</script>", false);
        //}


        try
        {
            LinkButton lnkJobID = (LinkButton)sender;
            GridViewRow gvr = (GridViewRow)lnkJobID.NamingContainer;
            Session["ProjectCode"] = ((HtmlGenericControl)gvr.FindControl("divProjectCode")).InnerText;

            Session["UrlRef"] = Request.Url.AbsoluteUri;
            Response.Redirect("~/JobOrder/SearchJobMstr.aspx?Project_Code = " + Session["ProjectCode"] + "", false);

        }
        catch
        {

        }
    }
    protected void txtJobNo_TextChanged(object sender, EventArgs e)
    {
        Session["OnGoingJobStatus"] = null;

        DataTable dt = new DataTable();
        dt = FillTabByJobNo(0, "");
        gvJoborder.DataSource = dt;
        gvJoborder.DataBind();

        lblCnt.Text = dt.Rows.Count.ToString();
    }
    protected void ddlTeamLead_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlTeamLead.SelectedIndex != 0)
        {
            ddlTeamMember.DataSource = null;

            PopulateDropDownBox(ddlTeamMember, "SELECT contactID, userShortName FROM contact where teamLeaderID = " + ddlTeamLead.SelectedValue + " ORDER BY userShortName", "contactID", "userShortName");
        }
    }
    protected void btnGraph_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/JobOrder/TeamWiseJobsChart.aspx",false);
    }
    protected void btnPrint_Click(object sender, EventArgs e)
    {
        if ((userRightsColl.Count == 0) || (!userRightsColl.Contains("2")))
        {
            try
            {
                ScriptManager.RegisterStartupScript(this, typeof(Page), "printGrid", "printGrid();", true);
            }
            catch { }
        }
    }
    protected void ddlJobNo_SelectedIndexChanged(object sender, EventArgs e)
    {

    }




    protected void Button1_Click(object sender, EventArgs e)
    {
        ExportToExcel_Sree();
    }
   
    //private void ExportToExcel()
    //{
    //    Response.Clear();
    //    Response.Buffer = true;
    //    Response.AddHeader("content-disposition", "attachment;filename=GridViewExport.xls");
    //    Response.Charset = "";
    //    Response.ContentType = "application/vnd.ms-excel";
    //    using (StringWriter sw = new StringWriter())
    //    {
    //        HtmlTextWriter hw = new HtmlTextWriter(sw);

    //        //To Export all pages
    //        gvJoborder.AllowPaging = false;

    //        gvJoborder.DataSource = Session["OnGoingJobStatus"];
    //        gvJoborder.DataBind();

    //        gvJoborder.HeaderRow.BackColor = Color.White;
    //        foreach (TableCell cell in gvJoborder.HeaderRow.Cells)
    //        {
    //            cell.BackColor = gvJoborder.HeaderStyle.BackColor;
    //        }
    //        foreach (GridViewRow row in gvJoborder.Rows)
    //        {
    //            row.BackColor = Color.White;
    //            foreach (TableCell cell in row.Cells)
    //            {
    //                if (row.RowIndex % 2 == 0)
    //                {
    //                    cell.BackColor = gvJoborder.AlternatingRowStyle.BackColor;
    //                }
    //                else
    //                {
    //                    cell.BackColor = gvJoborder.RowStyle.BackColor;
    //                }
    //                cell.CssClass = "textmode";
    //            }
    //        }

    //        gvJoborder.RenderControl(hw);

    //        //style to format numbers to string
    //        string style = @"<style> .textmode { } </style>";
    //        Response.Write(style);
    //        Response.Output.Write(sw.ToString());
    //        Response.Flush();
    //        Response.End();
    //    }
    //}
   
    //public override void VerifyRenderingInServerForm(Control control)
    //{
    //    /* Verifies that the control is rendered */
    //}




    protected void txtTitle_TextChanged(object sender, EventArgs e)
    {

    }




    protected void ddlAffair_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlAffair.SelectedIndex != 0)
        {
            string sqlQueryDept = "SELECT  departmentID,deptName From Department where affairID = " + ddlAffair.SelectedValue + "";
            ddlDept.DataSource = null;
            PopulateDropDownBox(ddlDept, sqlQueryDept, "departmentID", "deptName");
            ddlDept.Enabled = true;

            PopulateDropDownBox(ddlPrjCode, "SELECT DISTINCT Job.contractNo, Job.contractNo  FROM job INNER JOIN JobType ON Job.jobTypeID = JobType.jobTypeID WHERE (JobType.CategoryID IN (3, 4, 5, 6, 7)) and job.affairID = " + ddlAffair.SelectedValue + " ORDER BY Job.contractNo", "contractNo", "contractNo");
        }
    }
    protected void ddlDept_SelectedIndexChanged(object sender, EventArgs e)
    {
        if ((ddlAffair.SelectedIndex != 0) & (ddlDept.SelectedIndex != 0))
          PopulateDropDownBox(ddlPrjCode, "SELECT DISTINCT Job.contractNo, Job.contractNo  FROM job INNER JOIN JobType ON Job.jobTypeID = JobType.jobTypeID WHERE (JobType.CategoryID IN (3, 4, 5, 6, 7)) and job.affairID = " + ddlAffair.SelectedValue + " and job.deptID = " + ddlDept.SelectedValue + " ORDER BY Job.contractNo", "contractNo", "contractNo");
        else if ((ddlAffair.SelectedIndex == 0) & (ddlDept.SelectedIndex != 0))
            PopulateDropDownBox(ddlPrjCode, "SELECT DISTINCT Job.contractNo, Job.contractNo  FROM job INNER JOIN JobType ON Job.jobTypeID = JobType.jobTypeID WHERE (JobType.CategoryID IN (3, 4, 5, 6, 7)) and job.deptID = " + ddlDept.SelectedValue + " ORDER BY Job.contractNo", "contractNo", "contractNo");

    }




    #region MyRegion

    private void ExportToExcel_Sree()
    {
        Response.Clear();
        Response.Buffer = true;
        Response.AddHeader("content-disposition", "attachment;filename=GridViewExport.xls");
        Response.Charset = "";
        Response.ContentType = "application/vnd.ms-excel";
        using (StringWriter sw = new StringWriter())
        {
            HtmlTextWriter hw = new HtmlTextWriter(sw);

            //To Export all pages
            gvJoborder.AllowPaging = false;

            gvJoborder.DataSource = Session["OnGoingJobStatus"];
            gvJoborder.DataBind();

            gvJoborder.HeaderRow.BackColor = Color.White;
            foreach (TableCell cell in gvJoborder.HeaderRow.Cells)
            {
                cell.BackColor = gvJoborder.HeaderStyle.BackColor;
            }
            foreach (GridViewRow row in gvJoborder.Rows)
            {
                row.BackColor = Color.White;
                foreach (TableCell cell in row.Cells)
                {
                    if (row.RowIndex % 2 == 0)
                    {
                        cell.BackColor = gvJoborder.AlternatingRowStyle.BackColor;
                    }
                    else
                    {
                        cell.BackColor = gvJoborder.RowStyle.BackColor;
                    }
                    cell.CssClass = "textmode";
                }
            }

            gvJoborder.RenderControl(hw);

            //style to format numbers to string
            string style = @"<style> .textmode { } </style>";
            Response.Write(style);
            Response.Output.Write(sw.ToString());
            Response.Flush();
            Response.End();
        }
    }
    public override void VerifyRenderingInServerForm(Control control)
    {
        /* Verifies that the control is rendered */
    }

    #endregion





    protected void ddlContractor_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlContractor.SelectedIndex != 0)
        {
            ddlPrjCode.DataSource = null;
            PopulateDropDownBox(ddlPrjCode, "SELECT DISTINCT Job.contractNo,  Company.companyID  FROM  Job INNER JOIN   JobType ON Job.jobTypeID = JobType.jobTypeID INNER JOIN Company ON Job.contractorID = Company.companyID WHERE (JobType.CategoryID IN (3, 4, 5, 6, 7)) AND (Company.companyID = " + ddlContractor.SelectedValue + ") ORDER BY Job.contractNo", "contractNo", "contractNo");
        }
    }
    protected void ddlVendor_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlVendor.SelectedIndex != 0)
        {
            ddlPrjCode.DataSource = null;
            PopulateDropDownBox(ddlPrjCode, "SELECT DISTINCT Job.contractNo, Company.companyID FROM Job INNER JOIN JobType ON Job.jobTypeID = JobType.jobTypeID INNER JOIN Company ON Job.consultantID = Company.companyID  WHERE (JobType.CategoryID IN (3, 4, 5, 6, 7)) AND (Company.companyID = " + ddlVendor.SelectedValue + ") ORDER BY Job.contractNo", "contractNo", "contractNo");
        }
    }
   
}