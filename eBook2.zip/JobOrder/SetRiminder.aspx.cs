﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using Datalayer;
using System.Globalization;

public partial class JobOrder_SetRiminder : System.Web.UI.Page
{
    string connValue = System.Configuration.ConfigurationManager.ConnectionStrings["EBSDEBookConn"].ConnectionString;
    int _jobID = 0;
    protected void Page_Load(object sender, EventArgs e)
    {
        _jobID = Convert.ToInt32(Session["Upd_jobID"]);

        if (!IsPostBack)
        {
            Calendar1.Visible = false;

           PopulateDropDownBox(ddlSentTo, "Select contactID,firstName From Contact order by firstName", "contactID", "firstName");
           // PopulateDropDownBox(ddlTask, "SELECT jobPurposeID, jobPurposeName FROM JobPurpose ", "jobPurposeID", "jobPurposeName");
        }
    }
    private void PopulateDropDownBox(DropDownList ddlBox, string sqlQuery, string valueMember, string displayName)
    {
        DataTable table = new DataTable();
        try
        {
            using (SqlConnection sqlConn = new SqlConnection(connValue))
            {
                using (SqlDataAdapter da = new SqlDataAdapter(sqlQuery, sqlConn))
                {
                    sqlConn.Open();
                    da.Fill(table);
                }
            }
            //cmbBox.Items.Add("Select");

            ddlBox.DataSource = table;
            ddlBox.DataTextField = displayName;
            ddlBox.DataValueField = valueMember;

            ddlBox.SelectedIndex = -1;
            ddlBox.DataBind();
            ddlBox.Items.Insert(0, new ListItem("--Select--"));
        }
        catch (System.Exception ex)
        {
            throw ex;
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        DateTime strDate = System.DateTime.Now;
        DateTime endDate = System.DateTime.Now.AddDays(5);
        new JobOrderData().OutlookReminder(Session["IssuedByEmailAddress"].ToString(), Session["IssuedByEmailAddress"].ToString(), Session["IssuedByEmailAddress"].ToString(), Session["IssuedByEmailAddress"].ToString(), strDate, endDate);
    }
    protected void Calendar1_SelectionChanged(object sender, EventArgs e)
    {
        txtWorkDays.Text = getDaysByGivenEndDate(System.DateTime.Now.ToString(), Calendar1.SelectedDate.ToString());
        txtDueDate.Text = Convert.ToDateTime(Calendar1.SelectedDate).ToString("dd/MMM/yyyy");
        Calendar1.Visible = false;
    }
    protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
    {
        if (Calendar1.Visible)
            Calendar1.Visible = false;
        else
            Calendar1.Visible = true;  
    }
    private string getDaysByGivenEndDate(string strDate, string endDate)
    {
        strDate = Convert.ToDateTime(strDate).ToString("MM/dd/yyyy", CultureInfo.InvariantCulture);
        endDate = Convert.ToDateTime(endDate).ToString("MM/dd/yyyy", CultureInfo.InvariantCulture);

        DateTime strDt = DateTime.ParseExact(strDate, "MM/dd/yyyy", CultureInfo.InvariantCulture);
        DateTime endDt = DateTime.ParseExact(endDate, "MM/dd/yyyy", CultureInfo.InvariantCulture);

        SqlConnection con = new SqlConnection(connValue);
        SqlCommand cmd = new SqlCommand();

        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Connection = con;

        cmd.CommandText = "testSP";

        SqlParameter prm = cmd.Parameters.Add("@ad_startDate", SqlDbType.DateTime);
        prm.Value = strDt;

        prm = cmd.Parameters.Add("@ad_endDate", SqlDbType.DateTime);
        prm.Value = endDt;

        prm = cmd.Parameters.Add("@ai_workDays", SqlDbType.Int);
        prm.Direction = ParameterDirection.Output;

        //prm = cmd.Parameters.Add("@as_errMsg", SqlDbType.VarChar);
        //prm.Direction = ParameterDirection.Output;

        con.Open();
        SqlDataReader dr = cmd.ExecuteReader();
        while (dr.Read())
            Console.WriteLine(dr.GetString(0));
        con.Dispose();
        con.Close();

        return cmd.Parameters[2].Value.ToString();
    }
    protected void txtDueDate_TextChanged(object sender, EventArgs e)
    {
        txtWorkDays.Text = getDaysByGivenEndDate(System.DateTime.Now.ToString(), txtDueDate.Text);  
    }
    protected void txtWorkDays_TextChanged(object sender, EventArgs e)
    {
        string endDate = getEndDateByGivenDays();
        txtDueDate.Text = Convert.ToDateTime(endDate).ToString("dd/MMM/yyyy");
    }
    private string getEndDateByGivenDays()
    {
        SqlConnection con = new SqlConnection(connValue);
        SqlCommand cmd = new SqlCommand();
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Connection = con;

        cmd.CommandText = "AddWorkdays";
        SqlParameter prm = cmd.Parameters.Add("@ad_startDate", SqlDbType.DateTime);
        prm.Value = System.DateTime.Now;
        prm = cmd.Parameters.Add("@actual_workDays", SqlDbType.Int);
        prm.Value = Convert.ToInt32(txtWorkDays.Text);
        prm = cmd.Parameters.Add("@endDate", SqlDbType.DateTime);
        prm.Direction = ParameterDirection.Output;
        con.Open();
        SqlDataReader dr = cmd.ExecuteReader();
        while (dr.Read())
            Console.WriteLine(dr.GetString(0));
        con.Dispose();
        con.Close();
        return cmd.Parameters[2].Value.ToString();
    }
}