﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using Datalayer;

public partial class JobOrder_CostEstimate : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            PopulateDropDownBox(ddlJobType, "SELECT DISTINCT JobType.jobTypeID, JobType.jobTypeName FROM JobType INNER JOIN Job ON JobType.jobTypeID = Job.jobTypeID WHERE (JobType.CategoryID IN (1,2,3)) ORDER BY JobType.jobTypeName", "jobTypeID", "jobTypeName");

            FillTab2(0, 0, true);
        }

    }
    private void PopulateDropDownBox(DropDownList ddlBox, string sqlQuery, string valueMember, string displayName)
    {
        ddlBox.DataBound += new EventHandler(this.ddlBox_DataBound);
        ddlBox.DataSource = new JobOrderData().FillDropdown(sqlQuery);
        ddlBox.DataTextField = displayName;
        ddlBox.DataValueField = valueMember;
        ddlBox.SelectedIndex = -1;
        ddlBox.DataBind();
    }
    protected void ddlBox_DataBound(object sender, EventArgs e)
    {
        DropDownList ddl = (DropDownList)sender;
        ListItem emptyItem = new ListItem("", "");
        ddl.Items.Insert(0, emptyItem);
    }
    private void FillTab2(int _jobID,int jobtypeID,Boolean chkActive)
    {
        try
        {
            DataSet ds = new DataSet();

            

            Int32 _jobtypeID;
            Int32.TryParse(ddlJobType.SelectedValue, out _jobtypeID);

            Boolean _chkActive;
            Boolean.TryParse(chkConsider.Checked.ToString(), out _chkActive);

            ds = (new JobOrderData().GetDetails_JOBVOSI_Stake(_jobtypeID, _chkActive));

            //   Convert.ToInt32(txtjobid.Text), txtJobNo.Text, Convert.ToInt32(txtaffair.Text), Convert.ToInt32(txtdept.Text), txtprojcode.Text, txtprojtitle.Text, Convert.ToInt32(txtconsult.Text)));

            if (ds.Tables[0].Rows.Count == 0)
            {
                ds.Tables[0].Rows.Add(ds.Tables[0].NewRow());
            }


            grvJObLog.DataSource = ds;
            grvJObLog.DataBind();

        }
        catch (Exception ex)
        {

        }
    }
    protected void ddlJobType_SelectedIndexChanged(object sender, EventArgs e)
    {
        int jobtypeID = 0; Boolean chkActive = true;

        if (ddlJobType.SelectedIndex !=0)
            FillTab2(0, jobtypeID, chkActive);
    }
    protected void chkConsider_CheckedChanged(object sender, EventArgs e)
    {
        int jobtypeID = 0; Boolean chkActive = true;

        if (ddlJobType.SelectedIndex != 0)
            FillTab2(0, Convert.ToInt32(ddlJobType.SelectedValue), chkConsider.Checked);
        else
          FillTab2(0, jobtypeID, chkConsider.Checked);
    }
}