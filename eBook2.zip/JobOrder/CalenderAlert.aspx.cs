﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Globalization;

public partial class JobOrder_CalenderAlert : System.Web.UI.Page
{
    string connValue = System.Configuration.ConfigurationManager.ConnectionStrings["EBSDEBookConn"].ConnectionString;
    static IList<string> jobColl = new List<string>();
    static DataTable dtCur = new DataTable();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        { 
            int monthID =   System.DateTime.Now.Month;
            int yearID = System.DateTime.Now.Year;

            Response.Write(monthID);

            ddlMonth.SelectedValue = monthID.ToString();
            ddlYear.SelectedValue = yearID.ToString();

            calColl = getCalanderDates(ddlYear.SelectedItem.Text, monthID);

            //dicjobNoColl = getJobNO(ddlYear.SelectedItem.Text, monthID);
            dtCur = getDtJobNO(ddlYear.SelectedItem.Text, monthID);
        }
    }
  
    private void getPaymentData_ActionDueDate()
    {
        IList<string> dueDateDataColl = new List<string>();
        string sqlQuery = "SELECT issuedByEBSDOn,payID FROM Payment WHERE payID >60 AND (issuedByEBSDOn IS NOT NULL)";
        SqlConnection sqlCon = new SqlConnection(connValue);
        SqlCommand cmd = new SqlCommand();
        cmd.CommandText = sqlQuery;
        cmd.Connection = sqlCon;

        try
        {
            if (sqlCon.State != ConnectionState.Open)
                sqlCon.Open();
            SqlDataReader sqlDtReader = cmd.ExecuteReader();
            if (sqlDtReader.HasRows)
            {
                while (sqlDtReader.Read())
                {
                    //dueDateDataColl.Add(sqlDtReader[0].ToString());

                    //string endDate = getEndDateByGivenDays(sqlDtReader[0].ToString(), sqlDtReader[1].ToString());
                    string dueDate = Convert.ToDateTime(sqlDtReader[0].ToString()).ToString("dd/MMM/yyyy");

                    updatePayData(sqlDtReader[1].ToString(), dueDate);
                }
            }
            sqlDtReader.Close();

        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (sqlCon.State != ConnectionState.Closed)
                sqlCon.Close();
        }
    }
    public void updatePayData(string payID, string dueDate)
    {      

        SqlConnection con = new SqlConnection(connValue);
        SqlCommand cmd = new SqlCommand();
        cmd.Connection = con;

       // cmd.CommandText = "Update Payment Set jobDueDate =@jobDueDate where payID = @payID";

        cmd.CommandText = "Update Payment Set completionDate =@jobDueDate where payID = @payID";


        
        cmd.Parameters.AddWithValue("@jobDueDate", Convert.ToDateTime(dueDate).ToString("dd/MMM/yyyy"));
        cmd.Parameters.AddWithValue("@payID", payID);

        try
        {
            if (con.State != ConnectionState.Open)
                con.Open();

            cmd.ExecuteNonQuery();
            con.Dispose();
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (con.State != ConnectionState.Closed)
                con.Close();
        }
    }
    private void pageLoadData()
    {
        //int monthID = System.DateTime.Now.Month;
        //int yearID = System.DateTime.Now.Year;

        //Response.Write(monthID);

        //ddlMonth.SelectedValue = monthID.ToString();
        //ddlYear.SelectedValue = yearID.ToString();

        calColl = getCalanderDates(ddlYear.SelectedItem.Text, Convert.ToInt32(ddlMonth.SelectedValue));

        //dicjobNoColl = getJobNO(ddlYear.SelectedItem.Text, monthID);
        dtCur = getDtJobNO(ddlYear.SelectedItem.Text, Convert.ToInt32(ddlMonth.SelectedValue));
    }
    protected void Page_Init(object sender, EventArgs e)
    {
       
    }
    protected void Calendar1_SelectionChanged(object sender, EventArgs e)
    {
      if (Session["UserProfileID"].Equals("1"))
      {
        if (!getCalanderDates(Calendar1.SelectedDate.ToString()))
        {
            updateHolidayInCalander(Calendar1.SelectedDate.ToString());

            Session["SelDate"] = Calendar1.SelectedDate.ToString();
            Session["UrlRef"] = Request.Url.AbsoluteUri;

            sayYes();

            pageLoadData();
        }
        else
        {
            updateHolidayInCalanderFalse(Calendar1.SelectedDate.ToString());

            Session["SelDate"] = Calendar1.SelectedDate.ToString();
            Session["UrlRef"] = Request.Url.AbsoluteUri;


            sayYes();

            pageLoadData();

            //string url = "RestrictAlertWindow.aspx";
            //string s = "window.open('" + url + "', 'popup_window', 'width=250,height=150,left=100,top=100,resizable=yes');";
            //Page.ClientScript.RegisterStartupScript(this.GetType(), "script", s, true);

            //ddlMonth.SelectedIndex = 11;
            //ddlYear.SelectedIndex = 3;
            //calColl = getCalanderDates("2014", 12);
            //dicjobNoColl = getJobNO("2014", 12);
        }

        // getJobActionDueDate(Calendar1.SelectedDate.ToString());    
      }

    }
    private void sayYes()
    {
        getJobActionDueDate(Session["SelDate"].ToString());

        getInchargeActionDueDate(Session["SelDate"].ToString());

        getAddendumActionDueDate(Session["SelDate"].ToString());

        getDistributionDataActionDueDate(Session["SelDate"].ToString());

        // lblProcess.Text = "Process Done";

        //string script = "this.window.opener.location=this.window.opener.location;this.window.close();";
        //if (!ClientScript.IsClientScriptBlockRegistered("REFRESH_PARENT"))
        //    ClientScript.RegisterClientScriptBlock(typeof(string), "REFRESH_PARENT", script, true);
    }

    public void updateHolidayInCalanderFalse(string dueDate)
    {
        SqlConnection con = new SqlConnection(connValue);
        SqlCommand cmd = new SqlCommand();
        cmd.Connection = con;

        // Select * From PWACalendar WHERE (CalendarDate = '12/18/2014')
        cmd.CommandText = "UPDATE PWACalendar Set Holiday = 0, Workday = 0 WHERE CalendarDate = @SelectdDate ";
        cmd.Parameters.AddWithValue("@SelectdDate", Convert.ToDateTime(dueDate).ToString("dd/MMM/yyyy"));

        try
        {
            if (con.State != ConnectionState.Open)
                con.Open();

            cmd.ExecuteNonQuery();
            con.Dispose();
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (con.State != ConnectionState.Closed)
                con.Close();
        }
    }

    private Boolean getCalanderDates(string selectedDate)
    {
        Boolean chkHoliday = false;

        string sqlQuery = "SELECT Dateid,CONVERT(DATETIME, CalendarDate, 102) as CalendarDate, Holiday, Workday, EOMProcessdate, EOWProcessdate, SpecialProcessdate, Datestamp FROM PWACalendar " +
        "WHERE (CalendarDate = CONVERT(DATETIME, '" + Convert.ToDateTime(selectedDate).ToString("MM/dd/yyyy") + "', 102))";

        SqlConnection sqlCon = new SqlConnection(connValue);
        SqlCommand cmd = new SqlCommand();
        cmd.CommandText = sqlQuery;
        cmd.Connection = sqlCon;

        try
        {
            if (sqlCon.State != ConnectionState.Open)
                sqlCon.Open();
            SqlDataReader sqlDtReader = cmd.ExecuteReader();
            if (sqlDtReader.HasRows)
            {
                while (sqlDtReader.Read())
                {
                    chkHoliday = Convert.ToBoolean(sqlDtReader["Holiday"].ToString());
                }
            }
            sqlDtReader.Close();
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (sqlCon.State != ConnectionState.Closed)
                sqlCon.Close();
        }

        return chkHoliday;
    }
    //UPDATE PWACalendar Set Holiday = 1, Workday = 0 WHERE CalendarDate = @SelectdDate

    private IList<string> getCalanderDates(string strMonth_Year,int monthNo)
    { 
        IList<string> holidayColl = new List<string>();
        string sqlQuery = "SELECT Dateid,CONVERT(DATETIME, CalendarDate, 102) as CalendarDate, Holiday, Workday, EOMProcessdate, EOWProcessdate, SpecialProcessdate, Datestamp FROM PWACalendar WHERE (Holiday = 1) AND (YEAR(CalendarDate) = " + strMonth_Year + ") AND (MONTH(CalendarDate) = " + monthNo + ")";

        SqlConnection sqlCon = new SqlConnection(connValue);
        SqlCommand cmd = new SqlCommand();
        cmd.CommandText = sqlQuery;
        cmd.Connection = sqlCon;

        try
        {
            if (sqlCon.State != ConnectionState.Open)
                sqlCon.Open();
            SqlDataReader sqlDtReader = cmd.ExecuteReader();
            if (sqlDtReader.HasRows)
            {
                while (sqlDtReader.Read())
                {
                    holidayColl.Add(sqlDtReader["CalendarDate"].ToString());
                }
            }
            sqlDtReader.Close();
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (sqlCon.State != ConnectionState.Closed)
                sqlCon.Close();
        }

        return holidayColl;
    }
   
    
    private string getEndDateByGivenDays(string workDays,string startDate)
    {
        SqlConnection con = new SqlConnection(connValue);
        SqlCommand cmd = new SqlCommand();
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Connection = con;        
       
            cmd.CommandText = "AddWorkdays";
            SqlParameter prm = cmd.Parameters.Add("@ad_startDate", SqlDbType.DateTime);
            prm.Value = Convert.ToDateTime(startDate);
            prm = cmd.Parameters.Add("@actual_workDays", SqlDbType.Int);
            prm.Value = Convert.ToInt32(workDays);
            prm = cmd.Parameters.Add("@endDate", SqlDbType.DateTime);
            prm.Direction = ParameterDirection.Output;
            if (con.State != ConnectionState.Open)
              con.Open();
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
                Console.WriteLine(dr.GetString(0));
            con.Dispose();
            dr.Close();
            if (con.State != ConnectionState.Closed)
                 con.Close();
       
        return cmd.Parameters[2].Value.ToString();
    }    
   
    public void updateHolidayInCalander(string dueDate)
    {
        SqlConnection con = new SqlConnection(connValue);
        SqlCommand cmd = new SqlCommand();
        cmd.Connection = con;

        // Select * From PWACalendar WHERE (CalendarDate = '12/18/2014')
        cmd.CommandText = "UPDATE PWACalendar Set Holiday = 1, Workday = 0 WHERE CalendarDate = @SelectdDate ";

        cmd.Parameters.AddWithValue("@SelectdDate", Convert.ToDateTime(dueDate).ToString("dd/MMM/yyyy"));
       
        try
        {
            if (con.State != ConnectionState.Open)
                con.Open();

            cmd.ExecuteNonQuery();
            con.Dispose();
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (con.State != ConnectionState.Closed)
                con.Close();
        }
    }

   static IList<string> calColl = new List<string>();

    protected void Calendar1_DayRender(object sender, DayRenderEventArgs e)
    {
        if (calColl.Contains(e.Day.Date.ToString()) || e.Day.Date.DayOfWeek.ToString().Equals("Friday") || e.Day.Date.DayOfWeek.ToString().Equals("Saturday"))
        {
            Style vacationStyle = new Style();
            vacationStyle.BackColor = System.Drawing.Color.Silver;
            vacationStyle.ForeColor = System.Drawing.Color.Red;
            vacationStyle.BorderColor = System.Drawing.Color.Purple;
            vacationStyle.BorderWidth = 1;
            e.Cell.ApplyStyle(vacationStyle);           
        }

        if (!e.Cell.BackColor.Name.Equals("Silver"))
        {
            if (dtCur.Rows.Count != 0)
            {
                short jobCnt = 0;
                while (jobCnt < dtCur.Rows.Count)
                {
                    string strVal = Convert.ToDateTime(dtCur.Rows[jobCnt]["jobReceivedDate"]).ToString("dd/MM/yyyy");
                    string strVal2 = dtCur.Rows[jobCnt]["JobNo"].ToString();
                    string strVal3 = Convert.ToDateTime(dtCur.Rows[jobCnt]["actionDueDate"]).ToString("dd/MM/yyyy");
                    string strVal4 = dtCur.Rows[jobCnt]["jobID"].ToString();
                    string strVal5 = Convert.ToDateTime(e.Day.Date).ToString("dd/MM/yyyy");

                    //DateTime strDate = Convert.ToDateTime(strVal);
                    //DateTime endDate = Convert.ToDateTime(strVal3);
                    //DateTime btwnDate = Convert.ToDateTime(strVal5);


                    DateTime strDate = DateTime.ParseExact(strVal, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                    DateTime endDate = DateTime.ParseExact(strVal3, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                    DateTime btwnDate = DateTime.ParseExact(strVal5, "dd/MM/yyyy", CultureInfo.InvariantCulture);

                    if ((btwnDate > strDate) && (btwnDate <= endDate))
                    {
                        if (e.Day.Date.DayOfWeek.ToString().Equals("Friday") == false) //  if (!e.Day.Date.DayOfWeek.Equals("Friday") || !e.Day.Date.DayOfWeek.Equals("Saturday"))
                        {
                            if (e.Day.Date.DayOfWeek.ToString().Equals("Saturday") == false)
                            {
                                LinkButton lnkBtn = new LinkButton();
                                lnkBtn.Text = "<br /> " + strVal2;
                                lnkBtn.Attributes.Add("href", "javascript:__doPostBack('lnkJobNo','" + strVal2 + "')");
                                e.Cell.Controls.Add(lnkBtn);
                            }
                            else
                            {

                                Style vacationStyle = new Style();
                                vacationStyle.BackColor = System.Drawing.Color.Silver;
                                vacationStyle.ForeColor = System.Drawing.Color.Red;
                                vacationStyle.BorderColor = System.Drawing.Color.Purple;
                                vacationStyle.BorderWidth = 1;
                                e.Cell.ApplyStyle(vacationStyle);     
                            }
                        }
                    }
                  
                    jobCnt++;
                }

               
            }
        }        
    }
    protected void lnkBtn_Click(object sender, EventArgs e)
    {
        string clickedJobNo = Request.Form["__EVENTARGUMENT"];
        Session["lnkJobNo"] = clickedJobNo;
        Session["UrlRef"] = Request.Url.AbsoluteUri;

        string url = "TasksfromCalender.aspx";
        string s = "window.open('" + url + "', 'popup_window', 'width=700,height=500,left=100,top=100,resizable=yes');";
        Page.ClientScript.RegisterStartupScript(this.GetType(), "script", s, true);
    }
    
    static Dictionary<string, string> dicjobNoColl = new Dictionary<string, string>();

   
    public DataTable getDtJobNO(string yearName, int monthNo)
    {
        DataTable dt = new DataTable();
        try
        {
            SqlConnection sqlConn = new SqlConnection(connValue);
            sqlConn.Open();

            string sqlQuery = "SELECT  JobOwner.jobNo, JobOwner.actionDueDate, JobOwner.createDate, JobOwner.jobID, Job.jobReceivedDate " +
                     "FROM  JobOwner INNER JOIN   Job ON JobOwner.jobID = Job.jobID INNER JOIN      Contact ON JobOwner.contactID = Contact.contactID " +
                       " WHERE (YEAR(Job.jobReceivedDate) = " + yearName + ") AND (MONTH(Job.jobReceivedDate) = " + monthNo + ") AND (Contact.contactID = " + Convert.ToInt32(Session["UserID"]) + ") ORDER BY Job.jobReceivedDate";

            SqlCommand objCmd = new SqlCommand(sqlQuery, sqlConn);
            SqlDataAdapter objDA = new SqlDataAdapter(objCmd);

            objDA.SelectCommand.CommandText = objCmd.CommandText.ToString();
            
            objDA.Fill(dt);
            sqlConn.Close();
        }
        catch (System.Exception ex)
        {
            throw ex;
        }
        return dt;
    }
    protected void drpMonth_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void SetCalendarVisibleDate(object sender, EventArgs e)
    {
        Calendar1.VisibleDate = new DateTime(int.Parse(ddlYear.SelectedValue),
                                        int.Parse(ddlMonth.SelectedValue),
                                        1);

        calColl = getCalanderDates(ddlYear.SelectedItem.Text, Convert.ToInt32(ddlMonth.SelectedValue));
    }



    #region MyRegion


    #region JobOrder
    private void getJobActionDueDate(string selectDate)
    {
        IList<string> dueDateDataColl = new List<string>();
        string sqlQuery = "SELECT workDays,jobDueDate,jobID,jobReceivedDate FROM Job  WHERE (jobReceivedDate <= CONVERT(DATETIME, '" + Convert.ToDateTime(selectDate).ToString("MM/dd/yyyy") + "', 102)) AND (jobDueDate >= CONVERT(DATETIME, '" + Convert.ToDateTime(selectDate).ToString("MM/dd/yyyy") + "', 102))";
        SqlConnection sqlCon = new SqlConnection(connValue);
        SqlCommand cmd = new SqlCommand();
        cmd.CommandText = sqlQuery;
        cmd.Connection = sqlCon;

        try
        {
            if (sqlCon.State != ConnectionState.Open)
                sqlCon.Open();
            SqlDataReader sqlDtReader = cmd.ExecuteReader();
            if (sqlDtReader.HasRows)
            {
                while (sqlDtReader.Read())
                {
                    dueDateDataColl.Add(sqlDtReader[0].ToString());

                    string endDate = getEndDateByGivenDays(sqlDtReader[0].ToString(), sqlDtReader[3].ToString());
                    endDate = Convert.ToDateTime(endDate).ToString("dd/MMM/yyyy");

                    updateJOBActionDueDate(sqlDtReader[2].ToString(), endDate);
                }
            }
            sqlDtReader.Close();

        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (sqlCon.State != ConnectionState.Closed)
                sqlCon.Close();
        }
    }

    public void updateJOBActionDueDate(string jobID, string dueDate)
    {
        SqlConnection con = new SqlConnection(connValue);
        SqlCommand cmd = new SqlCommand();
        cmd.Connection = con;

        cmd.CommandText = "Update Job Set jobDueDate =@jobDueDate where JobID = @jobID";

        cmd.Parameters.AddWithValue("@jobDueDate", Convert.ToDateTime(dueDate).ToString("dd/MMM/yyyy"));
        cmd.Parameters.AddWithValue("@jobID", jobID);

        try
        {
            if (con.State != ConnectionState.Open)
                con.Open();

            cmd.ExecuteNonQuery();
            con.Dispose();
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (con.State != ConnectionState.Closed)
                con.Close();
        }
    }

    #endregion

    #region JobIncharge

    private void getInchargeActionDueDate(string selectDate)
    {
        IList<string> dueDateDataColl = new List<string>();

        string sqlQuery = "SELECT staffIssueDate, daysToAct, actionDueDate, jobOwnerID FROM JobOwner " +
        "  WHERE (staffIssueDate <= CONVERT(DATETIME, '" + Convert.ToDateTime(selectDate).ToString("MM/dd/yyyy") + "', 102)) AND (actionDueDate >= CONVERT(DATETIME, '" + Convert.ToDateTime(selectDate).ToString("MM/dd/yyyy") + "', 102))";

        // staffIssueDate

        SqlConnection sqlCon = new SqlConnection(connValue);
        SqlCommand cmd = new SqlCommand();
        cmd.CommandText = sqlQuery;
        cmd.Connection = sqlCon;

        try
        {
            if (sqlCon.State != ConnectionState.Open)
                sqlCon.Open();
            SqlDataReader sqlDtReader = cmd.ExecuteReader();
            if (sqlDtReader.HasRows)
            {
                while (sqlDtReader.Read())
                {
                    string endDate = getEndDateByGivenDays(sqlDtReader["daysToAct"].ToString(), sqlDtReader["staffIssueDate"].ToString());
                    endDate = Convert.ToDateTime(endDate).ToString("dd/MMM/yyyy");

                    updateInchargeActionDueDate(sqlDtReader["jobOwnerID"].ToString(), endDate);
                }
            }
            sqlDtReader.Close();

        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (sqlCon.State != ConnectionState.Closed)
                sqlCon.Close();
        }
    }

    public void updateInchargeActionDueDate(string jobInchargeID, string dueDate)
    {
        SqlConnection con = new SqlConnection(connValue);
        SqlCommand cmd = new SqlCommand();
        cmd.Connection = con;

        cmd.CommandText = "Update JobOwner Set ActionDueDate =@jobDueDate where JobOwnerID = @JobOwnerID";

        cmd.Parameters.AddWithValue("@jobDueDate", Convert.ToDateTime(dueDate).ToString("dd/MMM/yyyy"));
        cmd.Parameters.AddWithValue("@JobOwnerID", jobInchargeID);

        try
        {
            if (con.State != ConnectionState.Open)
                con.Open();

            cmd.ExecuteNonQuery();
            con.Dispose();
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (con.State != ConnectionState.Closed)
                con.Close();
        }
    }

    #endregion

    #region AddnedumData

    private void getAddendumActionDueDate(string selectDate)
    {
        IList<string> dueDateDataColl = new List<string>();

        string sqlQuery = "SELECT workDays,AlertDate,adID,admReceivedDate FROM JobAddendumInfo " +
        " WHERE (admReceivedDate <= CONVERT(DATETIME, '" + Convert.ToDateTime(selectDate).ToString("MM/dd/yyyy") + "', 102)) AND (AlertDate >= CONVERT(DATETIME, '" + Convert.ToDateTime(selectDate).ToString("MM/dd/yyyy") + "', 102))";

        SqlConnection sqlCon = new SqlConnection(connValue);
        SqlCommand cmd = new SqlCommand();
        cmd.CommandText = sqlQuery;
        cmd.Connection = sqlCon;

        try
        {
            if (sqlCon.State != ConnectionState.Open)
                sqlCon.Open();
            SqlDataReader sqlDtReader = cmd.ExecuteReader();
            if (sqlDtReader.HasRows)
            {
                while (sqlDtReader.Read())
                {
                    string endDate = getEndDateByGivenDays(sqlDtReader["workDays"].ToString(), sqlDtReader["admReceivedDate"].ToString());
                    endDate = Convert.ToDateTime(endDate).ToString("dd/MMM/yyyy");

                    updateAddendumActionDueDate(sqlDtReader["adID"].ToString(), endDate);
                }
            }
            sqlDtReader.Close();

        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (sqlCon.State != ConnectionState.Closed)
                sqlCon.Close();
        }
    }

    public void updateAddendumActionDueDate(string jobID, string dueDate)
    {
        SqlConnection con = new SqlConnection(connValue);
        SqlCommand cmd = new SqlCommand();
        cmd.Connection = con;

        cmd.CommandText = "Update JobAddendumInfo Set AlertDate =@jobDueDate where adID = @jobID";

        cmd.Parameters.AddWithValue("@jobDueDate", Convert.ToDateTime(dueDate).ToString("dd/MMM/yyyy"));
        cmd.Parameters.AddWithValue("@jobID", jobID);

        try
        {
            if (con.State != ConnectionState.Open)
                con.Open();

            cmd.ExecuteNonQuery();
            con.Dispose();
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (con.State != ConnectionState.Closed)
                con.Close();
        }
    }

    #endregion


    #region DocumentData

    private void getDistributionDataActionDueDate(string selectDate)
    {
        IList<string> dueDateDataColl = new List<string>();

        string sqlQuery = "SELECT docIssuedDate, daysToReply, actionDueDate, distributeID FROM  DocumentDistribution " +
        " WHERE (docIssuedDate <= CONVERT(DATETIME, '" + Convert.ToDateTime(selectDate).ToString("MM/dd/yyyy") + "', 102)) AND (actionDueDate >= CONVERT(DATETIME, '" + Convert.ToDateTime(selectDate).ToString("MM/dd/yyyy") + "', 102))";
        SqlConnection sqlCon = new SqlConnection(connValue);
        SqlCommand cmd = new SqlCommand();
        cmd.CommandText = sqlQuery;
        cmd.Connection = sqlCon;

        try
        {
            if (sqlCon.State != ConnectionState.Open)
                sqlCon.Open();
            SqlDataReader sqlDtReader = cmd.ExecuteReader();
            if (sqlDtReader.HasRows)
            {
                while (sqlDtReader.Read())
                {
                    string endDate = getEndDateByGivenDays(sqlDtReader["daysToReply"].ToString(), sqlDtReader["docIssuedDate"].ToString());
                    endDate = Convert.ToDateTime(endDate).ToString("dd/MMM/yyyy");

                    updateDistributionDataActionDueDate(sqlDtReader["distributeID"].ToString(), endDate);
                }
            }
            sqlDtReader.Close();

        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (sqlCon.State != ConnectionState.Closed)
                sqlCon.Close();
        }
    }

    public void updateDistributionDataActionDueDate(string _distributeID, string dueDate)
    {
        SqlConnection con = new SqlConnection(connValue);
        SqlCommand cmd = new SqlCommand();
        cmd.Connection = con;

        cmd.CommandText = "Update DocumentDistribution Set actionDueDate =@jobDueDate where distributeID = @distributeID";

        cmd.Parameters.AddWithValue("@jobDueDate", Convert.ToDateTime(dueDate).ToString("dd/MMM/yyyy"));
        cmd.Parameters.AddWithValue("@distributeID", _distributeID);

        try
        {
            if (con.State != ConnectionState.Open)
                con.Open();

            cmd.ExecuteNonQuery();
            con.Dispose();
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (con.State != ConnectionState.Closed)
                con.Close();
        }
    }
    //private string getEndDateByGivenDays(string workDays, string startDate)
    //{
    //    SqlConnection con = new SqlConnection(connValue);
    //    SqlCommand cmd = new SqlCommand();
    //    cmd.CommandType = CommandType.StoredProcedure;
    //    cmd.Connection = con;

    //    cmd.CommandText = "AddWorkdays";
    //    SqlParameter prm = cmd.Parameters.Add("@ad_startDate", SqlDbType.DateTime);
    //    prm.Value = Convert.ToDateTime(startDate);
    //    prm = cmd.Parameters.Add("@actual_workDays", SqlDbType.Int);
    //    prm.Value = Convert.ToInt32(workDays);
    //    prm = cmd.Parameters.Add("@endDate", SqlDbType.DateTime);
    //    prm.Direction = ParameterDirection.Output;
    //    if (con.State != ConnectionState.Open)
    //        con.Open();
    //    SqlDataReader dr = cmd.ExecuteReader();
    //    while (dr.Read())
    //        Console.WriteLine(dr.GetString(0));
    //    con.Dispose();
    //    dr.Close();
    //    if (con.State != ConnectionState.Closed)
    //        con.Close();

    //    return cmd.Parameters[2].Value.ToString();
    //} 
    #endregion


    #endregion

}