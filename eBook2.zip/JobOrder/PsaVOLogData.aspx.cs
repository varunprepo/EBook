﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using Datalayer;
using System.Drawing;
using System.Data.SqlClient;
public partial class JobOrder_PsaVOLogData : System.Web.UI.Page
{
    int _jobID = 0;
    string connValue = System.Configuration.ConfigurationManager.ConnectionStrings["EBSDEBookConn"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
    {
        _jobID = Convert.ToInt32(Request.QueryString["JobID"]);
        lblJobNo.Text = Request.QueryString["JobNo"];
        lblAbmNo.Text = Request.QueryString["AdndmNO"];

        Session["JobNo"] = Request.QueryString["JobNo"];
        Session["PrjCode"] = Request.QueryString["prjCode"];

      lblPrjCode.Text =  Request.QueryString["prjCode"];

      

        //if (lblAbmNo.Text != "")
        //    _admno = Convert.ToInt32(lblAbmNo.Text);
        if (!IsPostBack)
        {

            PopulateDropDownBox(drpVODesc, "SELECT jobCostID, jobCostDesc FROM   PSACostDesc", "jobCostID", "jobCostDesc");
            PopulateDropDownBox(drpVODescTime, "SELECT jobTimeID, jobTimeDesc FROM PSAJobTime ORDER BY jobTimeID", "jobTimeID", "jobTimeDesc");

            Panel1.Visible = false;

            FillTab2(_jobID);
            getPSA_CostSavingData(_jobID);
            getMinistryData(_jobID);
        }
    }
    private void PopulateDropDownBox(DropDownList ddlBox, string sqlQuery, string valueMember, string displayName)
    {
        DataTable table = new DataTable();
        try
        {
            using (SqlConnection sqlConn = new SqlConnection(connValue))
            {
                using (SqlDataAdapter da = new SqlDataAdapter(sqlQuery, sqlConn))
                {
                    sqlConn.Open();
                    da.Fill(table);
                }
            }
            //cmbBox.Items.Add("Select");

            ddlBox.DataSource = table;
            ddlBox.DataTextField = displayName;
            ddlBox.DataValueField = valueMember;

            ddlBox.SelectedIndex = -1;
            ddlBox.DataBind();

            ddlBox.Items.Insert(0, new ListItem("--Select--"));
        }
        catch (System.Exception ex)
        {
            throw ex;
        }
    }

    public void getMinistryData(int jobID)
    {
        string qry = " SELECT ministryCode,budgetRefNo,provisionNo From Job where JobID =  " + jobID;
        using (SqlConnection cn = new SqlConnection(connValue))
        {
            using (SqlCommand cmd = new SqlCommand())
            {

                cmd.Connection = cn;
                cmd.CommandText = qry;
                cmd.CommandType = CommandType.Text;

                cn.Open();

                using (SqlDataReader dr = cmd.ExecuteReader())
                {
                    while (dr.Read())
                    {
                        txtMinCode.Text = dr["ministryCode"].ToString();
                        txtBudgetRef.Text = dr["budgetRefNo"].ToString();
                        txtProvNo.Text = dr["provisionNo"].ToString();
                    }
                }
            }
        }
    }
    private void FillTab2(int _jobID)
    {
        try
        {
            DataSet ds = new DataSet();
            ds = (new JobOrderData().GetDDlDetails_JOBVOSI(_jobID));

            //   Convert.ToInt32(txtjobid.Text), txtJobNo.Text, Convert.ToInt32(txtaffair.Text), Convert.ToInt32(txtdept.Text), txtprojcode.Text, txtprojtitle.Text, Convert.ToInt32(txtconsult.Text)));

            if (ds.Tables[0].Rows.Count == 0)
            {
                ds.Tables[0].Rows.Add(ds.Tables[0].NewRow());
            }

            grvPSALog.DataSource = ds;
            grvPSALog.DataBind();


            decimal total_CntrAmnt = ds.Tables[0].AsEnumerable().Sum(row => row.Field<decimal?>("contractorAmt") ?? 0);
            decimal total_EbdAmnt = ds.Tables[0].AsEnumerable().Sum(row => row.Field<decimal?>("ebsdAmt") ?? 0);

           // grvPSALog.FooterRow.Cells[1].Text = "Total";

            grvPSALog.FooterRow.Cells[0].HorizontalAlign = HorizontalAlign.Right;
            grvPSALog.FooterRow.Cells[0].Text = total_CntrAmnt.ToString("N1");

            grvPSALog.FooterRow.Cells[1].HorizontalAlign = HorizontalAlign.Right;
            grvPSALog.FooterRow.Cells[1].Text = total_EbdAmnt.ToString("N1");

            int total_CntrEot = ds.Tables[0].AsEnumerable().Sum(row => row.Field<int?>("contractorEOT") ?? 0);
            int total_EbdEot = ds.Tables[0].AsEnumerable().Sum(row => row.Field<int?>("ebsdEOT") ?? 0);

            grvPSALog.FooterRow.Cells[5].HorizontalAlign = HorizontalAlign.Right;
            grvPSALog.FooterRow.Cells[5].Text = total_CntrEot.ToString("N1");

            grvPSALog.FooterRow.Cells[6].HorizontalAlign = HorizontalAlign.Right;
            grvPSALog.FooterRow.Cells[6].Text = total_EbdEot.ToString("N1");            
            
            //grvPSALog.FooterRow.Cells[3].HorizontalAlign = HorizontalAlign.Right;
            //grvPSALog.FooterRow.Cells[3].Text = total.ToString("N2");
        }
        catch (Exception ex)
        {

        }
    }
    private void FillTab2_Time(int _jobID)
    {
        try
        {
            DataSet ds2 = new DataSet();
            ds2 = (new JobOrderData().GetDDlDetails_JOBVOSI(_jobID));

            //   Convert.ToInt32(txtjobid.Text), txtJobNo.Text, Convert.ToInt32(txtaffair.Text), Convert.ToInt32(txtdept.Text), txtprojcode.Text, txtprojtitle.Text, Convert.ToInt32(txtconsult.Text)));

            if (ds2.Tables[0].Rows.Count == 0)
            {
                ds2.Tables[0].Rows.Add(ds2.Tables[0].NewRow());
            }

            //grvPSALogTime.DataSource = ds2;
            //grvPSALogTime.DataBind();

            //decimal total = ds2.Tables[0].AsEnumerable().Sum(row => row.Field<int>("contractorEOT"));

            //grvPSALogTime.FooterRow.Cells[1].Text = "Total";
            //grvPSALogTime.FooterRow.Cells[1].HorizontalAlign = HorizontalAlign.Right;
            //grvPSALogTime.FooterRow.Cells[2].Text = total.ToString("N2");


        }
        catch (Exception ex)
        {

        }
    }
    protected void grvPSALog_RowEditing(object sender, GridViewEditEventArgs e)
    {
        grvPSALog.EditIndex = e.NewEditIndex;
        FillTab2(_jobID);
        FillTab2_Time(_jobID);
    }
    protected void grvPSALog_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        double _pmcAmt = 0; double _ebsdAmt = 0; double _consultAmt = 0; ;
        int _pmcTime = 0; int _ebsdTime = 0; int _consultTime = 0;
        int _cntrAdmNo = 0; string _remarks = string.Empty;

        GridViewRow gr = (GridViewRow)grvPSALog.Rows[e.RowIndex];

        Label cntrAdmNo = (Label)gr.FindControl("lblCnsltAmt");
        if (cntrAdmNo.Text != "")
            txtCnsltAmnt.Text = cntrAdmNo.Text;

        TextBox pmcAmt = (TextBox)gr.FindControl("txtPmcAmt");
        if (pmcAmt.Text != "")
            _pmcAmt = Convert.ToDouble(pmcAmt.Text);

        TextBox pmcTime = (TextBox)gr.FindControl("txtPmcEOT");
        if (pmcTime.Text != "")
            _pmcTime = Convert.ToInt32(pmcTime.Text);

        TextBox ebsdAmt = (TextBox)gr.FindControl("txtEbsdAmt");
        if (ebsdAmt.Text != "")
            _ebsdAmt = Convert.ToDouble(ebsdAmt.Text);

        TextBox ebsdTime = (TextBox)gr.FindControl("txtEbsdEOT");
        if (ebsdTime.Text != "")
            _ebsdTime = Convert.ToInt32(ebsdTime.Text);

        TextBox consultAmt = (TextBox)gr.FindControl("txtConsultAmt");
        if (consultAmt.Text != "")
            _consultAmt = Convert.ToDouble(consultAmt.Text);

        TextBox consultTime = (TextBox)gr.FindControl("txtConsultEOT");
        if (consultTime.Text != "")
            _consultTime = Convert.ToInt32(consultTime.Text);

        TextBox remarks = (TextBox)gr.FindControl("txtRemarks");
        if (remarks.Text != "")
            _remarks = remarks.Text;

        Label id = (Label)gr.FindControl("JobVOID");
        int _admno = 0;

        new JobOrderData().update_PSALog(Convert.ToInt32(id.Text), _pmcAmt, _pmcTime, _ebsdAmt, _ebsdTime, _consultAmt, _consultTime, _admno, _remarks);
       
        grvPSALog.EditIndex = -1;
        FillTab2(_jobID);
    }
    protected void grvPSALog_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "ViewEdit")
        {
            string arguments = e.CommandArgument.ToString();
            string[] args = arguments.Split(';');
            if (args[0] != "")
            {
                int _void = Convert.ToInt32(args[0]);
                getVOData(_void);
                Panel1.Visible = true;
            }
        }         
    }

    private void getPSA_CostSavingData(int _void)
    {
        //string qry = " SELECT TOP(1) (contractorAmt-ebsdAmt) as costSaving, (contractorEOT-ebsdEOT) as TimeSaving FROM JobVOSI WHERE (jobID = " + _jobID + ") ";

        string qry = "SELECT ISNULL(SUM(contractorAmt), 0) - ISNULL(SUM(ebsdAmt), 0) AS 'Result',ISNULL(SUM(contractorEOT), 0) - ISNULL(SUM(ebsdEOT), 0) AS 'TimeSaving' FROM JobVOSI WHERE (jobID = " + _jobID + ") ";


        using (SqlConnection cn = new SqlConnection(connValue))
        {
            using (SqlCommand cmd = new SqlCommand())
            {

                cmd.Connection = cn;
                cmd.CommandText = qry;
                cmd.CommandType = CommandType.Text;

                cn.Open();

                using (SqlDataReader dr = cmd.ExecuteReader())
                {
                    while (dr.Read())
                    {
                        txtCostTotal.Text = dr["Result"].ToString();
                        txtTimeTotal.Text = dr["TimeSaving"].ToString();                        
                    }
                }
            }
        }
    }
    private void getVOData(int _void)
    {
      string  qry = " SELECT jobVOID, jobID, contractorAmt, contractorEOT, pmcAmt, pmcEOT, consultantAmt, consultantEOT, ebsdAmt, ebsdEOT, invSH,voNumber,siNumber,REPLACE(CONVERT(NVARCHAR, issueDate, 106), ' ', '-') as issueDate,REPLACE(CONVERT(NVARCHAR, prjCompleteDate, 106), ' ', '-') as prjCompleteDate,  " +
                   " remarks,voCatID ,voTimeCatID FROM JobVOSI WHERE (jobVOID = " + _void + ") ";
        using (SqlConnection cn = new SqlConnection(connValue))
        {
            using (SqlCommand cmd = new SqlCommand())
            {

                cmd.Connection = cn;
                cmd.CommandText = qry;
                cmd.CommandType = CommandType.Text;

                cn.Open();

                using (SqlDataReader dr = cmd.ExecuteReader())
                {
                    while (dr.Read())
                    {
                        txtCnsltAmnt.Text = dr["contractorAmt"].ToString();
                        txtPmcAmnt.Text = dr["pmcAmt"].ToString();
                        txtEbsdAmnt.Text = dr["ebsdAmt"].ToString();

                        txtCnsltTime.Text = dr["contractorEOT"].ToString();
                        txtPmcTime.Text = dr["pmcEOT"].ToString();
                        txtEbsdTime.Text = dr["ebsdEOT"].ToString();
                        txtRemarks.Text = dr["remarks"].ToString();

                        lblVOSIID.Text = dr["jobVOID"].ToString();

                        if ((txtEbsdAmnt.Text != "") & (txtCnsltAmnt.Text != ""))
                        {
                            txtAmntDiff.Text = (Convert.ToDouble(txtCnsltAmnt.Text) - Convert.ToDouble(txtEbsdAmnt.Text)).ToString();
                        }

                        if ((txtCnsltTime.Text != "") & (txtEbsdTime.Text != ""))
                        {
                            txtTimeSave.Text = (Convert.ToDouble(txtCnsltTime.Text) - Convert.ToDouble(txtEbsdTime.Text)).ToString();
                        }

                        if (dr["voCatID"].ToString() != "")
                            drpVODesc.SelectedValue = dr["voCatID"].ToString();

                        if (dr["voTimeCatID"].ToString() != "")
                            drpVODescTime.SelectedValue = dr["voTimeCatID"].ToString();

                    }
                }
            }
        }        
    }
    protected void btnSave_Click(object sender, EventArgs e)
    {
        //if (txtPmcAmnt.Text == "")
        //    txtPmcAmnt.Text = "0";

        //if (txtPmcTime.Text == "")
        //    txtPmcTime.Text = "0";

        //if (txtEbsdAmnt.Text == "")
        //    txtEbsdAmnt.Text = "0";

        //if (txtEbsdTime.Text == "")
        //    txtEbsdTime.Text = "0";

        //if (txtCnsltAmnt.Text == "")
        //    txtCnsltAmnt.Text = "0";

        //if (txtCnsltTime.Text == "")
        //    txtCnsltTime.Text = "0";

        //if (lblVOSIID.Text != "")
        //{
        //    new JobOrderData().update_PSALog(Convert.ToInt32(lblVOSIID.Text), Convert.ToDouble(txtPmcAmnt.Text), Convert.ToInt32(txtPmcTime.Text), Convert.ToDouble(txtEbsdAmnt.Text), Convert.ToInt32(txtEbsdTime.Text), Convert.ToDouble(txtCnsltAmnt.Text), Convert.ToInt32(txtCnsltTime.Text), 1, txtRemarks.Text);
        //}
        //else
        //{
        //    new JobOrderData().Add_PSALog(_jobID, Convert.ToDouble(txtPmcAmnt.Text), Convert.ToInt32(txtPmcTime.Text), Convert.ToDouble(txtEbsdAmnt.Text), Convert.ToInt32(txtEbsdTime.Text), Convert.ToDouble(txtCnsltAmnt.Text), Convert.ToInt32(txtCnsltTime.Text), 1, txtRemarks.Text);
        //}

        
        int _voID = 0;

        if (lblVOSIID.Text != "")
            _voID = Convert.ToInt32(lblVOSIID.Text);
        else
            _voID = 0;


        int voCatID = 0; int voTimeCatID = 0;
        Boolean chkVOActive = true;

        if (drpVODesc.SelectedIndex != 0)
            voCatID = Convert.ToInt32(drpVODesc.SelectedValue);

        if (drpVODescTime.SelectedIndex != 0)
            voTimeCatID = Convert.ToInt32(drpVODescTime.SelectedValue);

//       new JobOrderData().AddUpade_JOBVOandSI(_voID, _jobID, txtCnsltAmnt.Text, txtCnsltTime.Text, txtPmcAmnt.Text, txtPmcTime.Text, txtEbsdAmnt.Text, txtEbsdTime.Text, "", "", "", "", "", "", txtRemarks.Text, Session["UserName"].ToString(), "", voCatID, chkVOActive, voTimeCatID,txtRemarks0.Text);            
               
        ClearData();
        FillTab2(_jobID);
      //  FillTab2_Time(_jobID);

        getPSA_CostSavingData(_jobID);

    }
    private void ClearData()
    {
        txtCnsltAmnt.Text = "";
        txtPmcAmnt.Text = "";
        txtEbsdAmnt.Text = "";

        txtCnsltTime.Text = "";
        txtPmcTime.Text = "";
        txtEbsdTime.Text = "";
        txtRemarks.Text = "";        

        lblVOSIID.Text = "";

        drpVODesc.SelectedIndex = -1;
        drpVODescTime.SelectedIndex = -1;

        txtAmntDiff.Text = "";
        txtTimeSave.Text = "";

    }
    protected void grvPSALog_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        GridViewRow gr = (GridViewRow)grvPSALog.Rows[e.RowIndex];
        Label txtid = (Label)gr.FindControl("lbljobVOID");
        if (txtid.Text!="")
        {
            new JobOrderData().Delete_PSALog(Convert.ToInt32(txtid.Text));        
            FillTab2(_jobID);
        }
    }
    protected void LinkButton_Click(Object sender, EventArgs e)
    {
        if (lblVOSIID.Text != "")
        {
            LinkButton txtBox = (sender as LinkButton);
            Session["txtName"] = txtBox.ClientID;
            Session["JobAdmID"] = lblVOSIID.Text;
        
            string url = "StakeHolder.aspx?jobVOID = <%#Eval(jobVOID)%>";  //subject=<%#Eval("Address") %>"
            string s = "window.open('" + url + "', 'popup_window', 'width=600,height=600,left=100,top=100,resizable=yes');";
            ClientScript.RegisterStartupScript(this.GetType(), "script", s, true);
        }       
    }
    protected void btnAdd_Click(object sender, EventArgs e)
    {
        Panel1.Visible = true;
        ClearData();
    }
    protected void txtEbsdAmnt_TextChanged(object sender, EventArgs e)
    {
        if ((txtEbsdAmnt.Text!="") &  (txtCnsltAmnt.Text!=""))
        {
            txtAmntDiff.Text = (Convert.ToDouble(txtCnsltAmnt.Text) - Convert.ToDouble(txtEbsdAmnt.Text)).ToString();
        }
    }
    protected void txtCnsltAmnt_TextChanged(object sender, EventArgs e)
    {
        if ((txtEbsdAmnt.Text != "") & (txtCnsltAmnt.Text != ""))
        {
            txtAmntDiff.Text = (Convert.ToDouble(txtCnsltAmnt.Text) - Convert.ToDouble(txtEbsdAmnt.Text)).ToString();
        }
    }
    protected void txtCnsltTime_TextChanged(object sender, EventArgs e)
    {
        if ((txtEbsdAmnt.Text != "") & (txtCnsltAmnt.Text != ""))
        {
            txtAmntDiff.Text = (Convert.ToDouble(txtCnsltAmnt.Text) - Convert.ToDouble(txtEbsdAmnt.Text)).ToString();
        }
    }
    protected void txtEbsdTime_TextChanged(object sender, EventArgs e)
    {
        if ((txtCnsltTime.Text != "") & (txtEbsdTime.Text != ""))
        {
            txtTimeSave.Text = (Convert.ToDouble(txtCnsltTime.Text) - Convert.ToDouble(txtEbsdTime.Text)).ToString();
        }
    }
    protected void txtTimeSave_TextChanged(object sender, EventArgs e)
    {

    }
    protected void txtMinCode_TextChanged(object sender, EventArgs e)
    {
        new JobOrderData().UpdateMinistryDataForJob(0, txtMinCode.Text, txtBudgetRef.Text, txtProvNo.Text, lblPrjCode.Text);
    }
    protected void txtBudgetRef_TextChanged(object sender, EventArgs e)
    {
        new JobOrderData().UpdateMinistryDataForJob(0, txtMinCode.Text, txtBudgetRef.Text, txtProvNo.Text, lblPrjCode.Text);
    }
    protected void txtProvNo_TextChanged(object sender, EventArgs e)
    {
        new JobOrderData().UpdateMinistryDataForJob(0, txtMinCode.Text, txtBudgetRef.Text, txtProvNo.Text, lblPrjCode.Text);
    }
    
}