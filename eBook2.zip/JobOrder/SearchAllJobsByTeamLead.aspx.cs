﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using Datalayer;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.Drawing;
using System.Globalization;
public partial class JobOrder_SearchAllJobsByTeamLead : System.Web.UI.Page
{
    string connValue = System.Configuration.ConfigurationManager.ConnectionStrings["EBSDEBookConn"].ConnectionString;
    static IList<string> userRightsColl = null;
    string profile_Name = string.Empty;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["UserName"] == null)
        {
            Response.Redirect("~/LoginPage.aspx", false);
            return;
        }

        userRightsColl = (IList<string>)Session["UserRightsColl"];

        if (!IsPostBack)
        {
            PopulateDropDownBox(ddlSection, "SELECT SectionID, SectionName FROM  Section Where departmentID = 7 ORDER BY SectionName  ", "SectionID", "SectionName");

            PopulateDropDownBox(ddlRole, "SELECT jobOwnerCatID, jobOwnerCategory FROM  JobOwnerCategory ORDER BY jobOwnerCategory ", "jobOwnerCatID", "jobOwnerCategory");

            PopulateDropDownBox(ddlTeam, "SELECT teamLeaderID, teamLeaderName FROM EBSDTeamLeaders ORDER BY teamLeaderName", "teamLeaderID", "teamLeaderName");

            PopulateDropDownBox(drpTeamLead, "SELECT teamLeaderID, teamLeaderName FROM EBSDTeamLeaders ORDER BY teamLeaderName", "teamLeaderID", "teamLeaderName");

             // onGoingTasksPerSectionChart

            getOnGoingTasksPerSection_New();

            if (userRightsColl.Count != 0)
            {              
                string sqlQuery = string.Empty;              

                //PopulateDropDownBox(ddlQS, sqlQuery, "ContactID", "userShortName");

              

                string sqlJobno = string.Empty;     

                //PopulateDropDownBox(ddlJobNo, sqlJobno, "jobID", "jobNo");
            }
            else
            {
                PopulateDropDownBox(ddlQS, "SELECT DISTINCT JobOwner.contactID, Contact.userShortName FROM JobOwner INNER JOIN Contact ON JobOwner.contactID = Contact.contactID Where JobOwner.jobOwnerStatusID = 3 and Contact.userShortName IS NOT NULL Order By Contact.userShortName", "ContactID", "userShortName");
               // PopulateDropDownBox(ddlTeam, "SELECT teamLeaderID, teamLeaderName FROM EBSDTeamLeaders Where SectionID = " + Convert.ToInt16(Session["SectionID"]) + " ORDER BY teamLeaderName", "teamLeaderID", "teamLeaderName");
                PopulateDropDownBox(ddlJobNo, "SELECT Distinct jobID, jobNo FROM  JobOwner where jobOwnerStatusID = 3  ORDER BY jobNo ", "jobID", "jobNo");
               
            }

            DataSet ds = new JobOrderData().FillGridView_Details_TeamLead(0, 0, 0, 0);  // SpName - SearchAllJobs
            lblStaffCnt.Text = ds.Tables[0].Rows.Count.ToString();
            DataView dvCommitted = new DataView(ds.Tables[0]);

            if (userRightsColl.Count == 0)
                Session["CommittedInfo"] = dvCommitted;
            else
            {
                dvCommitted.RowFilter = "SectionID = '" + Session["SectionID"].ToString() + "'";
                Session["CommittedInfo"] = dvCommitted;
            }

            gvJoborder.DataSource = Session["CommittedInfo"] as DataView;
            gvJoborder.DataBind();


            getOverdueData();
            
        }
    }
    private void getOnGoingTasksPerSection_New()
    {
        DataSet dsTndr = new DataSet();

        string sqlQuery = null; int secID = Convert.ToInt32(Session["SectionID"]);
        string strSeriesName = string.Empty;

        if (Session["userProfileID"].ToString().Equals("1"))   // For Admin
        {
            sqlQuery = " SELECT  COUNT(Job.jobID) AS JobCnt, Section.sectionName FROM  JobType INNER JOIN  Job ON JobType.jobTypeID = Job.jobTypeID INNER JOIN   Section ON JobType.sectionID = Section.sectionID " +
               " WHERE (Job.jobDueDate < GETDATE()-1) AND (Job.jobStatusID IN (3, 8))  GROUP BY Section.sectionName, JobType.sectionID  UNION " +
                    "SELECT  COUNT(JobOwner.jobOwnerID) AS Expr1, Section.sectionName FROM  JobOwner INNER JOIN  Section ON JobOwner.sectionID = Section.sectionID " +
                          " WHERE  (JobOwner.payID IS NOT NULL) AND (JobOwner.actionDueDate < GETDATE()-1) AND (JobOwner.jobOwnerStatusID <> 7) GROUP BY Section.sectionName";
           
            strSeriesName = "sectionName";
            
        }
        else if (!Session["userProfileID"].ToString().Equals("1") && Session["SectionID"].ToString().Equals("7") && !userRightsColl.Contains("1"))    // User Not Admin but he belongs to all section and he contain user rights no  -1   (  7 for all section )
        {
            sqlQuery = " SELECT  COUNT(Job.jobID) AS JobCnt, Section.sectionName FROM  JobType INNER JOIN  Job ON JobType.jobTypeID = Job.jobTypeID INNER JOIN   Section ON JobType.sectionID = Section.sectionID " +
               " WHERE (Job.jobDueDate < GETDATE()-1) AND (Job.jobStatusID IN (3, 8))  GROUP BY Section.sectionName, JobType.sectionID  UNION " +
                    "SELECT  COUNT(JobOwner.jobOwnerID) AS Expr1, Section.sectionName FROM  JobOwner INNER JOIN  Section ON JobOwner.sectionID = Section.sectionID " +
                          " WHERE  (JobOwner.payID IS NOT NULL) AND (JobOwner.actionDueDate < GETDATE()-1) AND (JobOwner.jobOwnerStatusID <> 7) GROUP BY Section.sectionName";

            strSeriesName = "sectionName";

           
        }
        else if (Session["SectionID"].ToString().Equals("1"))          // Cost Control Section
        {
            if (Session["UserProfileID"].ToString().Contains("2"))        // Admin Section
            {
                sqlQuery = "SELECT COUNT(Job.jobID) AS JobCnt, JobType_1.jobTypeName FROM JobType AS JobType_1 INNER JOIN JobType ON JobType_1.jobTypeID = JobType.CategoryID INNER JOIN  Job ON JobType.jobTypeID = Job.jobTypeID INNER JOIN " +
                   " Section ON JobType.sectionID = Section.sectionID WHERE (JobType.sectionID = " + secID + ") AND (Job.jobDueDate < GETDATE()-1) AND (Job.jobStatusID IN (3,8)) GROUP BY JobType_1.jobTypeName";

                strSeriesName = "jobTypeName";
                
            }
            else 
            {
                sqlQuery = "SELECT COUNT(Job.jobID) AS JobCnt, JobType_1.jobTypeName FROM JobType AS JobType_1 INNER JOIN JobType ON JobType_1.jobTypeID = JobType.CategoryID INNER JOIN  Job ON JobType.jobTypeID = Job.jobTypeID INNER JOIN " +
                " Section ON JobType.sectionID = Section.sectionID WHERE (JobType.sectionID = " + secID + ") AND (Job.jobDueDate < GETDATE()-1) AND (Job.jobStatusID IN (3,8)) GROUP BY JobType_1.jobTypeName";

                strSeriesName = "jobTypeName";
                
            } 
        }     

        // Chart_OverDueJobs

        SqlDataAdapter daTndr = new SqlDataAdapter(sqlQuery, connValue);
        daTndr.Fill(dsTndr);
        if (dsTndr.Tables[0].Rows.Count != 0)
        {
            onGoingTasksPerSectionChart.DataSource = dsTndr.Tables[0].DefaultView;

            onGoingTasksPerSectionChart.Series["Series1"].XValueMember = strSeriesName;
            onGoingTasksPerSectionChart.Series["Series1"].YValueMembers = "JobCnt";

            dsTndr.Tables.Clear();

            onGoingTasksPerSectionChart.ChartAreas[0].AxisX.MajorGrid.Enabled = false;
            onGoingTasksPerSectionChart.ChartAreas[0].AxisX.MinorGrid.Enabled = false;
            onGoingTasksPerSectionChart.ChartAreas[0].AxisY.MajorGrid.Enabled = false;
            onGoingTasksPerSectionChart.ChartAreas[0].AxisY.MinorGrid.Enabled = false;

            onGoingTasksPerSectionChart.ChartAreas[0].AxisX.LabelStyle.Angle = 30;
            onGoingTasksPerSectionChart.ChartAreas[0].AxisX.LabelStyle.ForeColor = Color.Maroon;

            onGoingTasksPerSectionChart.ChartAreas[0].AxisX.Interval = 1;
        }

    }
    private void LoadDataByQS()
    {
        DataTable dtGrid = FillstaffDataForGrid();      // Sp-Name FillStaffData
        gvJoborder.DataSource = dtGrid;
        gvJoborder.DataBind();

        lblStaffCnt.Text = dtGrid.Rows.Count.ToString();
    }

    private void PopulateDropDownBox(DropDownList ddlBox, string sqlQuery, string valueMember, string displayName)
    {
        ddlBox.DataBound += new EventHandler(this.ddlBox_DataBound);
        ddlBox.DataSource = new JobOrderData().FillDropdown(sqlQuery);
        ddlBox.DataTextField = displayName;
        ddlBox.DataValueField = valueMember;
        ddlBox.SelectedIndex = -1;
        ddlBox.DataBind();
    }
    protected void ddlBox_DataBound(object sender, EventArgs e)
    {
        DropDownList ddl = (DropDownList)sender;
        ListItem emptyItem = new ListItem("", "");
        ddl.Items.Insert(0, emptyItem);
    }
    protected void gvJoborder_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        gvJoborder.PageIndex = e.NewPageIndex;       
        DataTable dtGrid = FillstaffDataForGrid();
        gvJoborder.DataSource = dtGrid;
        gvJoborder.DataBind();

        //FillOnGoingTasksPerStaffChart();
    }
    protected void gvJoborder_RowCommand(object sender, GridViewCommandEventArgs e)
    {

    }
    protected void gvJoborder_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            Label jobNo = (Label)e.Row.FindControl("lblJobNo");

            // Label lblJobRecDate = (Label)e.Row.FindControl("lblCmtRecDate");
            Label lblActionDueDate = (Label)e.Row.FindControl("lblActionDueDate");


            if ((lblActionDueDate.Text != ""))
            {
                

                if (Convert.ToDateTime(lblActionDueDate.Text) < System.DateTime.Today)
                {
                    e.Row.BackColor = System.Drawing.Color.LightPink;
                    e.Row.ForeColor = System.Drawing.Color.Red;

                    e.Row.Font.Bold = true;

                    jobNo.BackColor = System.Drawing.Color.Yellow;
                    e.Row.Cells[1].BackColor = System.Drawing.Color.White;
                }
            }
        }
    }
    private string getDaysByGivenEndDate(string strDate, string endDate)
    {
        strDate = Convert.ToDateTime(strDate).ToString("MM/dd/yyyy", CultureInfo.InvariantCulture);
        endDate = Convert.ToDateTime(endDate).ToString("MM/dd/yyyy", CultureInfo.InvariantCulture);

        DateTime strDt = DateTime.ParseExact(strDate, "MM/dd/yyyy", CultureInfo.InvariantCulture);
        DateTime endDt = DateTime.ParseExact(endDate, "MM/dd/yyyy", CultureInfo.InvariantCulture);

        SqlConnection con = new SqlConnection(connValue);
        SqlCommand cmd = new SqlCommand();

        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Connection = con;

        cmd.CommandText = "testSP";

        SqlParameter prm = cmd.Parameters.Add("@ad_startDate", SqlDbType.DateTime);
        prm.Value = strDt;

        prm = cmd.Parameters.Add("@ad_endDate", SqlDbType.DateTime);
        prm.Value = endDt;

        prm = cmd.Parameters.Add("@ai_workDays", SqlDbType.Int);
        prm.Direction = ParameterDirection.Output;

        //prm = cmd.Parameters.Add("@as_errMsg", SqlDbType.VarChar);
        //prm.Direction = ParameterDirection.Output;

        con.Open();
        SqlDataReader dr = cmd.ExecuteReader();
        while (dr.Read())
            Console.WriteLine(dr.GetString(0));
        con.Dispose();
        con.Close();

        return cmd.Parameters[2].Value.ToString();
    }
   
    protected void ddlJobNo_SelectedIndexChanged(object sender, EventArgs e)
    {
        DataView dvJobNo = new DataView();
        dvJobNo = Session["CommittedInfo"] as DataView;

        if ((ddlJobNo.SelectedItem.Text != "") & (ddlQS.SelectedItem.Text != ""))
            dvJobNo.RowFilter = "JOBNO = '" + ddlJobNo.SelectedItem.Text + "' and QSNAME = '" + ddlQS.SelectedItem.Text + "'";
        else if (ddlJobNo.SelectedItem.Text != "")
            dvJobNo.RowFilter = "JOBNO = '" + ddlJobNo.SelectedItem.Text + "'";
        else if (ddlQS.SelectedItem.Text != "")
            dvJobNo.RowFilter = "QSNAME = '" + ddlQS.SelectedItem.Text + "'";

        gvJoborder.DataSource = dvJobNo;
        gvJoborder.DataBind();


    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        ddlQS.SelectedIndex = -1;
        ddlJobNo.SelectedIndex = -1;

     

        DataTable dt = new JobOrderData().FillGridView_Details();      // SpName - SearchAllJobs
        DataView dvCommitted = new DataView();

        dvCommitted = Session["CommittedInfo"] as DataView;
        //dvCommitted.RowFilter = "project_code = '" + lnkBtn.Text + "'";       

        lblStaffCnt.Text = dt.Rows.Count.ToString();

        gvJoborder.DataSource = dvCommitted;
        gvJoborder.DataBind();

     
        if (userRightsColl.Count != 0)
        {
            PopulateDropDownBox(ddlQS, "SELECT DISTINCT JobOwner.contactID, Contact.userShortName FROM JobOwner INNER JOIN Contact ON JobOwner.contactID = Contact.contactID WHERE JobOwner.sectionID = " + Convert.ToInt32(Session["SectionID"]) + " and JobOwner.jobOwnerStatusID = 3 Order By Contact.userShortName ", "ContactID", "userShortName");
        }
        else
        {
            PopulateDropDownBox(ddlQS, "SELECT DISTINCT JobOwner.contactID, Contact.userShortName FROM JobOwner INNER JOIN Contact ON JobOwner.contactID = Contact.contactID Where JobOwner.jobOwnerStatusID = 3 Order By Contact.userShortName", "ContactID", "userShortName");
        }

        string sqlJobno = string.Empty;

       

        PopulateDropDownBox(ddlJobNo, sqlJobno, "jobID", "jobNo");
    }
    protected void lnkBtnJobID_Click(object sender, EventArgs e)
    {
        string strUpdateJob = Request.Url.AbsoluteUri;
        try
        {
            LinkButton lnkJobID = (LinkButton)sender;
            GridViewRow gvr = (GridViewRow)lnkJobID.NamingContainer;
            Session["JobID"] = ((HtmlGenericControl)gvr.FindControl("divJobID")).InnerText;

            Session["PayID"] = ((HtmlGenericControl)gvr.FindControl("divPayID")).InnerText;

            Session["JobInchargeID"] = lnkJobID.ToolTip;

            Session["JobCatID"] = ((HtmlGenericControl)gvr.FindControl("divJoCatbID")).InnerText;

            if (((HtmlGenericControl)gvr.FindControl("divJoCatbID")).InnerText == "2")     //payment
            {
                Session["UrlRef"] = strUpdateJob;
                Response.Redirect("~/Payments/PaymentDetails.aspx?PayID= " + Session["PayID"] + "", false);
            }
            else if (((HtmlGenericControl)gvr.FindControl("divJoCatbID")).InnerText == "8")
            {
                Session["UrlRef"] = strUpdateJob;
                Response.Redirect("~/DCLog/DCDetails.aspx?JobID= " + Session["JobID"] + "", false);
            }
            else if (((HtmlGenericControl)gvr.FindControl("divJoCatbID")).InnerText != "1")
            {
                Session["UrlRef"] = strUpdateJob;
                Response.Redirect("~/JobOrder/DefaultGrid.aspx?JobID= " + Session["JobID"] + "", false);
            }
            else
            {
                // Session["UrlRef"] = "~/JobOrder/PSAJobDetails.aspx";
                Session["UrlRef"] = strUpdateJob;
                Response.Redirect("~/JobOrder/PSAJobDetails.aspx?JobID= " + Session["JobID"] + "", false);
            }
        }
        catch (Exception ex)
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Error occurred while processing the request')</script>", false);
        }
    }

    private DataTable FillstaffDataForGrid()
    {
        DataSet ds = new DataSet();
        try
        {
            Int32 sectionID;
            Int32.TryParse(ddlSection.SelectedValue, out sectionID);

            Int32 teamLeadID;
            Int32.TryParse(ddlTeam.SelectedValue, out teamLeadID);

            Int32 roleID;
            Int32.TryParse(ddlRole.SelectedValue, out roleID);

            Int32 jobID;
            Int32.TryParse(ddlJobNo.SelectedValue, out jobID);

            Int32 staffID;
            Int32.TryParse(ddlQS.SelectedValue, out staffID);

            ds = new JobOrderData().GetStaffDetailsForGrid(sectionID, teamLeadID, roleID, jobID, staffID);          // SpName FillStaffData

            DataView dvCommitted = new DataView(ds.Tables[0]);
        }
        catch (Exception ex)
        {

        }
        return ds.Tables[0];
    }

    protected void changedEventForStaff_team(object sender, EventArgs e)
    {
        //ddlQS.SelectedIndex = 0;

        int _teamID = 0;
        if (drpTeamLead.SelectedIndex != 0)
            _teamID = Convert.ToInt32(drpTeamLead.SelectedValue);
        
        int _qsID = 0;
        //if (ddlQS.SelectedIndex != 0)
        //    _qsID = Convert.ToInt32(ddlQS.SelectedValue);


        DataSet ds = new JobOrderData().FillGridView_Details_TeamLead(0, 0, _teamID, 0);
        lblStaffCnt.Text = ds.Tables[0].Rows.Count.ToString();

        DataTable dt = FillstaffData();
        DataTable dtGrid = FillstaffDataForGrid();         // Sp-Name FillStaffData

        lblStaffCnt.Text = dtGrid.Rows.Count.ToString();
       
        gvJoborder.DataSource = dtGrid;
        gvJoborder.DataBind();

        ddlQS.Items.Clear();

        if (ddlQS.SelectedIndex != 0)
        {
            if (ddlTeam.SelectedIndex != 0)
                PopulateDropDownBox(ddlQS, "SELECT DISTINCT JobOwner.contactID, Contact.userShortName FROM JobOwner INNER JOIN Contact ON JobOwner.contactID = Contact.contactID where Contact.teamleaderID = " + ddlTeam.SelectedValue + " and JobOwner.jobOwnerStatusID = 3 Order By Contact.userShortName", "ContactID", "userShortName");
            else
                PopulateDropDownBox(ddlQS, "SELECT DISTINCT JobOwner.contactID, Contact.userShortName FROM JobOwner INNER JOIN Contact ON JobOwner.contactID = Contact.contactID Where JobOwner.jobOwnerStatusID = 3 Order By Contact.userShortName", "ContactID", "userShortName");
        }
        else
            PopulateDropDownBox(ddlQS, "SELECT DISTINCT JobOwner.contactID, Contact.userShortName FROM JobOwner INNER JOIN Contact ON JobOwner.contactID = Contact.contactID Where JobOwner.jobOwnerStatusID = 3  Order By Contact.userShortName", "ContactID", "userShortName");


        if (ddlTeam.SelectedIndex != 0)
        {
            ddlJobNo.Items.Clear();
            PopulateDropDownBox(ddlJobNo, "SELECT DISTINCT JobOwner.jobID, JobOwner.jobNo, Contact.teamLeaderID, JobOwner.jobOwnerStatusID FROM JobOwner INNER JOIN Contact ON JobOwner.contactID = Contact.contactID WHERE (Contact.teamLeaderID = " + ddlTeam.SelectedValue + ") AND (JobOwner.jobOwnerStatusID = 3) ORDER BY JobOwner.jobNo", "jobID", "jobNo");

        }
        else
        {
            ddlJobNo.Items.Clear();
            PopulateDropDownBox(ddlJobNo, "SELECT DISTINCT JobOwner.jobID, JobOwner.jobNo, JobOwner.jobOwnerStatusID FROM  JobOwner INNER JOIN   Contact ON JobOwner.contactID = Contact.contactID WHERE   (JobOwner.jobOwnerStatusID = 3)  ORDER BY JobOwner.jobNo", "jobID", "jobNo");
        }
    }
    private DataTable FillstaffData()
    {
        DataSet ds = new DataSet();
        try
        {

            Int32 sectionID;
            Int32.TryParse(ddlSection.SelectedValue, out sectionID);

            Int32 teamLeadID;
            Int32.TryParse(ddlTeam.SelectedValue, out teamLeadID);

            Int32 roleID;
            Int32.TryParse(ddlRole.SelectedValue, out roleID);

            ds = (new JobOrderData().GetStaffDetailsForChart(sectionID, teamLeadID, roleID));            // SpName SearchStaff

            DataView dvCommitted = new DataView(ds.Tables[0]);

        }
        catch (Exception ex)
        {

        }
        return ds.Tables[0];
    }

    protected void changedEventForStaff(object sender, EventArgs e)
    {
        DataTable dt = FillstaffData();
        DataTable dtGrid = FillstaffDataForGrid();            // Sp-Name FillStaffData

        lblStaffCnt.Text = dtGrid.Rows.Count.ToString();

        

        gvJoborder.DataSource = dtGrid;
        gvJoborder.DataBind();

        ddlQS.Items.Clear();

        if (ddlQS.SelectedIndex != 0)
        {
            if (ddlTeam.SelectedIndex != 0)
                PopulateDropDownBox(ddlQS, "SELECT DISTINCT JobOwner.contactID, Contact.userShortName FROM JobOwner INNER JOIN Contact ON JobOwner.contactID = Contact.contactID where Contact.teamleaderID = " + ddlTeam.SelectedValue + " and JobOwner.jobOwnerStatusID = 3 Order By Contact.userShortName", "ContactID", "userShortName");
            else
                PopulateDropDownBox(ddlQS, "SELECT DISTINCT JobOwner.contactID, Contact.userShortName FROM JobOwner INNER JOIN Contact ON JobOwner.contactID = Contact.contactID Where JobOwner.jobOwnerStatusID = 3 Order By Contact.userShortName", "ContactID", "userShortName");
        }
        else
            PopulateDropDownBox(ddlQS, "SELECT DISTINCT JobOwner.contactID, Contact.userShortName FROM JobOwner INNER JOIN Contact ON JobOwner.contactID = Contact.contactID Where JobOwner.jobOwnerStatusID = 3 and sectionID = " + ddlSection.SelectedValue + " Order By Contact.userShortName", "ContactID", "userShortName");


        if (ddlSection.SelectedIndex != 0)
        {
            ddlJobNo.Items.Clear();
            PopulateDropDownBox(ddlJobNo, "SELECT DISTINCT jobID, jobNo FROM   JobOwner WHERE JobOwner.sectionID =  " + ddlSection.SelectedValue + " and JobOwner.jobOwnerStatusID = 3 Order By jobNo", "jobID", "jobNo");
        }
        else
        {
            ddlJobNo.Items.Clear();
            PopulateDropDownBox(ddlJobNo, "SELECT DISTINCT JobOwner.jobID, JobOwner.jobNo, JobOwner.jobOwnerStatusID FROM  JobOwner INNER JOIN   Contact ON JobOwner.contactID = Contact.contactID WHERE   (JobOwner.jobOwnerStatusID = 3)  ORDER BY JobOwner.jobNo", "jobID", "jobNo");
        }
    }
    protected void SetTeamLead(object sender, EventArgs e)
    {
        FillstaffData();        
    }
    protected void SetStaffRoleLead(object sender, EventArgs e)
    {

    }
    protected void changedEventForStaffJobNo(object sender, EventArgs e)
    {
        DataTable dtGrid = FillstaffDataForGrid();       // Sp-Name FillStaffData
        gvJoborder.DataSource = dtGrid;
        gvJoborder.DataBind();
    }
    protected void changedEventForStaffQS(object sender, EventArgs e)
    {
        LoadDataByQS();
    }
    protected void ddlRole_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void ddlSection_SelectedIndexChanged(object sender, EventArgs e)
    {

    }


    protected void drpTeamLead_SelectedIndexChanged(object sender, EventArgs e)
    {
        int _teamID = 0;
        if (drpTeamLead.SelectedIndex != 0)
            _teamID= Convert.ToInt32(drpTeamLead.SelectedValue);    
     



        DataSet ds = new JobOrderData().FillGridView_Details_TeamLead(0, 0, _teamID, 0);  // SpName - SearchAllJobs
        lblStaffCnt.Text = ds.Tables[0].Rows.Count.ToString();
        DataView dvCommitted = new DataView(ds.Tables[0]);

        if (userRightsColl.Count == 0)
            Session["CommittedInfo"] = dvCommitted;
        else
        {
            dvCommitted.RowFilter = "SectionID = '" + Session["SectionID"].ToString() + "'";
            Session["CommittedInfo"] = dvCommitted;
        }

        gvJoborder.DataSource = Session["CommittedInfo"] as DataView;
        gvJoborder.DataBind();
    }
    protected void ddlQS_SelectedIndexChanged(object sender, EventArgs e)
    {
        int _teamID = 0;
        if (drpTeamLead.SelectedIndex != 0)
            _teamID = Convert.ToInt32(drpTeamLead.SelectedValue);

        int _qsID = 0;
        if (ddlQS.SelectedIndex != 0)
            _qsID = Convert.ToInt32(ddlQS.SelectedValue);



        DataSet ds = new JobOrderData().FillGridView_Details_TeamLead(0, 0, _teamID, _qsID);  // SpName - SearchAllJobs
        lblStaffCnt.Text = ds.Tables[0].Rows.Count.ToString();
        DataView dvCommitted = new DataView(ds.Tables[0]);

        if (userRightsColl.Count == 0)
            Session["CommittedInfo"] = dvCommitted;
        else
        {
            dvCommitted.RowFilter = "SectionID = '" + Session["SectionID"].ToString() + "'";
            Session["CommittedInfo"] = dvCommitted;
        }

        gvJoborder.DataSource = Session["CommittedInfo"] as DataView;
        gvJoborder.DataBind();
    }
    protected void OngoingJobsClick(object sender, ImageMapEventArgs e)
    {
        string sectionName = Session["SectionName"].ToString();
        Session["OverDueName"] = e.PostBackValue.ToString();
        Session["OnGoingJobStatus"] = e.PostBackValue;           
        Response.Redirect("~/DCLog/OverDueJobs.aspx", false);   

    }
    private void getOverdueData()
    {
        if (Session["UserName"] == null)
        {
            Response.Redirect("~/LoginPage.aspx", false);
            return;
        }

        DataTable dt = new DataTable();
        string prjType = string.Empty;


        if (Session["OverDueName"] == null)
            prjType = "0";
        else
        {
            prjType = Session["OverDueName"].ToString();
        }

        if (!IsPostBack)
        {
            string strQuery = string.Empty;

            if (!Session["UserProfileID"].Equals("1"))
            {
                if (Convert.ToInt16((Session["SectionID"])) == 3)
                    strQuery = "SELECT DISTINCT JobType.jobTypeID, JobType.jobTypeName FROM  JobType INNER JOIN    Job ON JobType.jobTypeID = Job.jobCatID " +
                          " WHERE (JobType.jobTypeID IN (8)) AND (Job.jobStatusID IN (3, 8)) AND (Job.jobDueDate < GETDATE()-1) ORDER BY JobType.jobTypeName";
                else if (Convert.ToInt16((Session["SectionID"])) == 1)
                    strQuery = "SELECT DISTINCT JobType.jobTypeID, JobType.jobTypeName FROM  JobType INNER JOIN    Job ON JobType.jobTypeID = Job.jobCatID " +
                          " WHERE (JobType.jobTypeID IN (1, 3, 4, 5, 6, 7, 8)) AND (Job.jobStatusID IN (3, 8)) AND (Job.jobDueDate < GETDATE()-1) ORDER BY JobType.jobTypeName";
                else
                    strQuery = "SELECT DISTINCT JobType.jobTypeID, JobType.jobTypeName FROM  JobType INNER JOIN    Job ON JobType.jobTypeID = Job.jobCatID " +
                       " WHERE (JobType.jobTypeID IN (46)) AND (Job.jobStatusID IN (3, 8)) AND (Job.jobDueDate < GETDATE()-1) ORDER BY JobType.jobTypeName";
            }
            else
            {
                if (prjType.Equals("Document Control"))
                    strQuery = "SELECT DISTINCT JobType.jobTypeID, JobType.jobTypeName FROM  JobType INNER JOIN    Job ON JobType.jobTypeID = Job.jobCatID " +
                          " WHERE (JobType.jobTypeID IN (8)) AND (Job.jobStatusID IN (3, 8)) AND (Job.jobDueDate < GETDATE()-1) ORDER BY JobType.jobTypeName";
                else if (prjType.Equals("Cost Control Section"))
                    strQuery = "SELECT DISTINCT JobType.jobTypeID, JobType.jobTypeName FROM  JobType INNER JOIN    Job ON JobType.jobTypeID = Job.jobCatID " +
                          " WHERE (JobType.jobTypeID IN (1, 3, 4, 5, 6, 7, 8)) AND (Job.jobStatusID IN (3, 8)) AND (Job.jobDueDate < GETDATE()-1) ORDER BY JobType.jobTypeName";
                else
                    strQuery = "SELECT DISTINCT JobType.jobTypeID, JobType.jobTypeName FROM  JobType INNER JOIN    Job ON JobType.jobTypeID = Job.jobCatID " +
                       " WHERE (JobType.jobTypeID IN (46)) AND (Job.jobStatusID IN (3, 8)) AND (Job.jobDueDate < GETDATE()-1) ORDER BY JobType.jobTypeName";
            }


            // SELECT jobTypeID, jobTypeName FROM JobType WHERE (jobTypeID IN (1,2,3,4,5,6,7,8)) ORDER BY JobType.jobTypeName

            PopulateDropDownBox(drpJobType, strQuery, "jobTypeID", "jobTypeName");

         
            int secID = 0;
            if (prjType.Equals("0"))
            {
                if (Convert.ToInt16((Session["SectionID"])) == 7)
                    secID = 1;
                else
                    secID = Convert.ToInt16((Session["SectionID"]));

                dt = FillTab2(0, "", secID);

                Session["getOverDueJobs"] = dt;
                gvOverDueJobs.DataSource = dt;
                gvOverDueJobs.DataBind();
            }
            else if (prjType.Equals("Cost Control Section"))
            {
                if (Session["UserProfileID"].Equals("1"))
                    secID = 1;
                else if (Convert.ToInt16((Session["SectionID"])) == 7)
                    secID = 1;
                else
                    secID = Convert.ToInt16((Session["SectionID"]));

                dt = FillTab2(0, "", secID);

                Session["getOverDueJobs"] = dt;
                gvOverDueJobs.DataSource = dt;
                gvOverDueJobs.DataBind();
            }
            else if (prjType.Contains("Data") || prjType.Contains("DC"))
            {
                drpJobType.SelectedValue = "8";  // DCU LOg    
                if (Session["UserProfileID"].Equals("1"))
                    secID = 3;
                else if (Convert.ToInt16((Session["SectionID"])) == 7)
                    secID = 3;
                else
                    secID = Convert.ToInt16((Session["SectionID"]));

                dt = LoadDataByJobType(secID);
            }
            else if (prjType.Equals("Payment Section"))
            {

            }
            else if (prjType.Trim().Equals("Document Control"))
            {
                if (Session["UserProfileID"].Equals("1"))
                    secID = 3;
                else if (Convert.ToInt16((Session["SectionID"])) == 7)
                    secID = 3;
                else
                    secID = Convert.ToInt16((Session["SectionID"]));

                drpJobType.SelectedValue = "8";  // DCU LOg
                dt = LoadDataByJobType(secID);
            }
            else if (Session["SectionID"].Equals("10"))
            {
                if (Session["UserProfileID"].Equals("1"))
                    secID = 10;
                else if (Convert.ToInt16((Session["SectionID"])) == 7)
                    secID = 10;
                else
                    secID = Convert.ToInt16((Session["SectionID"]));

                drpJobType.SelectedValue = "46";  // DCU LOg
                dt = LoadDataByJobType(secID);
            }
            else
            {
                string QSID = drpJobType.Items.FindByText(prjType).Value;
                drpJobType.SelectedValue = QSID;
                dt = LoadDataByJobType(Convert.ToInt16((Session["SectionID"])));
            }

           // lblCnt.Text = " Over Due Jobs Count : " + dt.Rows.Count.ToString();

        }
    }
    private DataTable LoadDataByJobType(int userSecID)
    {
        DataTable dtGrid = FillByJobType(userSecID);      // Sp-Name FillStaffData
        Session["getOverDueJobs"] = dtGrid;
        gvOverDueJobs.DataSource = dtGrid;
        gvOverDueJobs.DataBind();

        return dtGrid;

        // lblStaffCnt.Text = dtGrid.Rows.Count.ToString();
    }
    private DataTable FillByJobType(int secID)
    {
        int catID = 0;

        if (drpJobType.SelectedIndex != 0)
            catID = Convert.ToInt16(drpJobType.SelectedValue);

        DataSet ds = new DataSet();
        try
        {
            ds = (new JobOrderData().GetOverDueDCULogDetails(secID, catID));
        }
        catch (Exception ex)
        {

        }
        return ds.Tables[0];
    }
    private DataTable FillTab2(int searchType, string _prjCode, int userSecID)
    {
        int catID = 0;

        if (drpJobType.SelectedIndex != 0)
            catID = Convert.ToInt16(drpJobType.SelectedValue);

        DataSet ds = new DataSet();
        try
        {
            ds = (new JobOrderData().GetOverDueDCULogDetails(userSecID, catID));
        }
        catch (Exception ex)
        {

        }
        return ds.Tables[0];
    }

    protected void gvOverDueJobs_RowDataBound(object sender, GridViewRowEventArgs e)
    {

    }
    protected void gvOverDueJobs_RowCommand(object sender, GridViewCommandEventArgs e)
    {

    }
    protected void gvOverDueJobs_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {

    }
    protected void lnkJobOrderJobNo_Click(object sender, EventArgs e)
    {
        Session["PayID"] = null;
        Session["JobID"] = null;

        string strUpdateJob = Request.Url.AbsoluteUri;
        Session["UrlRef"] = strUpdateJob;
        try
        {
            LinkButton lnkJobID = (LinkButton)sender;
            GridViewRow gvr = (GridViewRow)lnkJobID.NamingContainer;
            Session["JobID"] = ((HtmlGenericControl)gvr.FindControl("divJobID")).InnerText;

            if (Session["JobID"] == null)
                Session["PayID"] = ((HtmlGenericControl)gvr.FindControl("divPayID")).InnerText;

            if (Session["JobID"].ToString() == "")
                Session["PayID"] = ((HtmlGenericControl)gvr.FindControl("divPayID")).InnerText;

            Session["JobInchargeID"] = lnkJobID.ToolTip;

            if ((Session["PayID"] == null))
            {
                Session["JobCatID"] = ((HtmlGenericControl)gvr.FindControl("divJobCatID")).InnerText;

                string catID = ((HtmlGenericControl)gvr.FindControl("divJobCatID")).InnerText.Trim();

                if (catID.Equals("1"))
                    Response.Redirect("~/JobOrder/PSAJobDetails.aspx?JobID= " + Session["JobID"] + "", false);
                else if (catID.Equals("8"))
                    Response.Redirect("~/DCLog/DCDetails.aspx?JobID= " + Session["JobID"] + "", false);
                else if (catID.Equals("46"))
                    Response.Redirect("~/ManagerTask/MngrTaskDetails.aspx?JobID= " + Session["JobID"] + "", false);
                else
                    Response.Redirect("~/JobOrder/DefaultGrid.aspx?JobID= " + Session["JobID"] + "", false);
            }
            else
            {
                Response.Redirect("~/Payments/PaymentDetails.aspx?PayID= " + Session["PayID"] + "", false);
            }


        }
        catch (Exception ex)
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Error occurred while processing the request')</script>", false);
        }
    }

    protected void drpJobType_SelectedIndexChanged(object sender, EventArgs e)
    {
        DataTable dt = FillTab2(0, "", Convert.ToInt16(Session["SectionID"]));

        Session["getOverDueJobs"] = dt;

        gvOverDueJobs.DataSource = dt;
        gvOverDueJobs.DataBind();

        getOnGoingTasksPerSection_New();
    }
} 