﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using Datalayer;
using System.Threading;
using System.Globalization;
using System.Configuration;
using System.Web.UI.HtmlControls;

public partial class JobOrder_Default : System.Web.UI.Page
{
    string connValue = System.Configuration.ConfigurationManager.ConnectionStrings["EBSDEBookConn"].ConnectionString;

    string _jobNo = string.Empty;
    int _jobID = 0;
     IList<string> userRightsColl = new List<string>();
    string profile_Name = string.Empty;
    int _tabType = 0;
    protected void Page_Init(object sender, EventArgs e)
    {
        if (Session["UserName"] == null)
        {
            Response.Redirect("~/LoginPage.aspx", false);
            return;
        }

        if (_jobID==0)
           _jobID = Convert.ToInt32(Request.QueryString["JobID"]);

        Session["StaffJobID"] = Convert.ToInt32(Request.QueryString["JobID"]);

        _tabType = Convert.ToInt32(Request.QueryString["tabType"]);
        
        gvJoborder.DataSource = new JobOrderData().GetJobOwnerDetails(_jobID);
        gvJoborder.DataBind();

        Session["DocRecDate"] = getDocReceivedDate(_jobID);

       // tblRowVO.Visible = false;       
    }
    protected void Page_Load(object sender, EventArgs e)
    {
        userRightsColl = (IList<string>)Session["UserRightsColl"];
        Label2.Text = "UserColl Count " + userRightsColl.Count.ToString();

        Session["PayID"] = null;          //  killing session becuease of link document button when user action on updatepay[PaymentDetails.aspx]/ updatejob[DefaultGrid.aspx] 

        if (IsPostBack == false)
        {
            Session["Upd_jobID"] = _jobID;

            PopulateDropDownBox(ddlDept, "SELECT departmentID, deptName FROM  Department  where affairID is not null ORDER BY deptName ", "departmentID", "deptName");
            PopulateDropDownBox(ddlJobType, "SELECT jobTypeID, jobTypeName FROM JobType ORDER BY jobTypeName", "jobTypeID", "jobTypeName");            //Where jobTypeID not in(1,2,3,4,5,6,7,8)

            PopulateDropDownBox(ddlJobCat, "SELECT jobTypeID, jobTypeName FROM JobType Where jobTypeID in(1,2,3,4,5,6,7,8) ORDER BY jobTypeName", "jobTypeID", "jobTypeName");         

            PopulateDropDownBox_TCMS(ddlVendor, "SELECT co_id, co_name FROM Company ORDER BY co_name", "co_id", "co_name");
            PopulateDropDownBox_TCMS(ddlConsultantNo, "SELECT co_id, co_name FROM Company ORDER BY co_name", "co_id", "co_name");
          
            PopulateDropDownBox(ddlJobStatus, "SELECT JobStatusID, JobStatusName FROM JobStatus Where JobStatusID in(1,2,3,4,5,6,7) ORDER BY JobStatusName", "JobStatusID", "JobStatusName");
            PopulateDropDownBox(ddlQS, "Select contactID,UserShortName From Contact order by firstName", "contactID", "UserShortName");
            PopulateDropDownBox(ddlCE, "Select contactID,UserShortName From Contact order by firstName", "contactID", "UserShortName");
            PopulateDropDownBox(ddlPE, "Select contactID,UserShortName From Contact order by firstName", "contactID", "UserShortName");

           // PopulateDropDownBox(ddlCntrType, "SELECT contractTypeID, contractTypeName FROM  ContractType Order by contractTypeName ", "contractTypeID", "contractTypeName");

            PopulateDropDownBox(ddlCntrType, "SELECT contractTypeID, tcms_CntrName FROM  ContractType Order by tcms_CntrName ", "contractTypeID", "tcms_CntrName");   

            // userRightsColl = new JobOrderData().GetUserAccessList(Convert.ToInt32(Session["userID"]));

            PopulateDropDownBox(ddlSectionName, "Select sectionID,sectionName From Section order by sectionName", "sectionID", "sectionName");

            //  fillDocumentStatus(_jobID);

            // If access No 6 of the current user is False then Disable the Grade and Job Status

            if (!userRightsColl.Contains("6"))
            {
                ddlGrade.Enabled = true;
                txtDueDate.Enabled = true;
                txtWorkDays.Enabled = true;

                ddlJobStatus.Enabled = true;
            }
            else
            {
                ddlGrade.Enabled = false;
                txtDueDate.Enabled = false;
                txtWorkDays.Enabled = false;

                ddlJobStatus.Enabled = false;
            }
            if (_tabType == 3)
            {
                ddlVendor.Enabled = false;
            }
            else
            {
                // txtAddendum.Enabled = false;                
            }

            Fill_JobOrder_Information(_jobID);           
            

            gridReceived.DataSource = new JobOrderData().getJobDocumetReceivedDate(_jobID);
            gridReceived.DataBind();

            gridSent.DataSource = new JobOrderData().getJobDocumetSentDate(_jobID);
            gridSent.DataBind();

            int catID = Convert.ToInt32(Session["jobCatID"]);
            string typeID = Session["jobTypeID"].ToString();

            PopulateDropDownBox_JobType(ddlJobType, "SELECT jobTypeID, jobTypeName FROM JobType Where CategoryID = " + catID + " and jobTypeID<>CategoryID ORDER BY jobTypeName", "jobTypeID", "jobTypeName");         //and jobTypeID<>CategoryID

            if ((typeID != "") & (catID.ToString() != ddlJobType.SelectedItem.Value))
                ddlJobType.SelectedItem.Value = typeID;
            else
                ddlJobType.SelectedIndex = 0;

            Session["prjCode"] = txtPrjCode.Text;
            Session["JobNo"] = txtJobNo.Text;
        }       
    }
    private string getDocReceivedDate(int JobID)
    {
        string docRecDate = string.Empty;
        SqlConnection sqlConn = new SqlConnection(connValue);
        string sqlQuery = "SELECT JobReceivedDate from Job where JobID =" + JobID + "";

        try
        {
            sqlConn.Open();
            SqlCommand sqlCom = new SqlCommand(sqlQuery, sqlConn);
            SqlDataReader sqlReader = sqlCom.ExecuteReader();
            while (sqlReader.Read())
            {
                docRecDate = sqlReader[0].ToString();
            }
            sqlReader.Close();
        }
        catch (Exception ex)
        {
            // Response.Write("Error getting while reading data !" + ex.Message);
        }
        finally
        {
            sqlConn.Close();
        }
        return docRecDate;
    }
    private void WorkingDaysCaluclationByGrade(string gradeValue, string endDate)
    {
        //string endDate = string.Empty;
        switch (gradeValue)
        {
            case "1":
                txtWorkDays.Text = "5"; // Working Days
                endDate = getEndDateByGivenDays(5);
                txtDueDate.Text = Convert.ToDateTime(endDate).ToString("dd/MMM/yyyy");

                //txtDueDate.Text = System.DateTime.Now.AddDays(5).ToString("dd/MMM/yyyy");
                break;
            case "2":
                endDate = getEndDateByGivenDays(8);
                txtDueDate.Text = Convert.ToDateTime(endDate).ToString("dd/MMM/yyyy");
                txtWorkDays.Text = "7";
                break;

            case "3":
                endDate = getEndDateByGivenDays(10);
                txtDueDate.Text = Convert.ToDateTime(endDate).ToString("dd/MMM/yyyy");
                txtWorkDays.Text = "10";
                break;

            case "4":
                endDate = getEndDateByGivenDays(15);
                txtDueDate.Text = Convert.ToDateTime(endDate).ToString("dd/MMM/yyyy");
                txtWorkDays.Text = "15";
                break;

            //case "":
            //    txtDueDate.Text = "";
            //    txtWorkDays.Text = "";
            //    break;

            default:
                break;
        }
    }
    private string getEndDateByGivenDays(int _days)
    {
        SqlConnection con = new SqlConnection(connValue);
        SqlCommand cmd = new SqlCommand();
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Connection = con;

        cmd.CommandText = "AddWorkdays";
        SqlParameter prm = cmd.Parameters.Add("@ad_startDate", SqlDbType.DateTime);
        prm.Value = System.DateTime.Now;


        prm = cmd.Parameters.Add("@actual_workDays", SqlDbType.Int);
        prm.Value = Convert.ToInt32(_days);

        prm = cmd.Parameters.Add("@endDate", SqlDbType.DateTime);
        prm.Direction = ParameterDirection.Output;
        con.Open();
        SqlDataReader dr = cmd.ExecuteReader();
        while (dr.Read())
            Console.WriteLine(dr.GetString(0));
        con.Dispose();
        con.Close();

        return cmd.Parameters[2].Value.ToString();

    }
  
    # region


    protected void QSlnkAddStaff_Click(object sender, EventArgs e)
    {  
        if (Convert.ToInt32(ddlQS.SelectedIndex) != 0 && (!userRightsColl.Contains("4"))) // Access Right is 4 
        {
            Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Don't have the permission to Add QS')</script>", false);
            return;
        }
        else
        {
            string url = "AddStaff.aspx";
            string s = "window.open('" + url + "', 'popup_window', 'width=900,height=700,left=100,top=100,resizable=yes');";
            Page.ClientScript.RegisterStartupScript(this.GetType(), "script", s, true);
        } 
    }
    protected void PElnkAddStaff_Click(object sender, EventArgs e)
    {
        if (Convert.ToInt32(ddlPE.SelectedIndex) != 0 && (!userRightsColl.Contains("4"))) // Access Right is 4 
        {
            Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Don't have the permission to Add PE ')</script>", false);  
            return;
        }
        else
        {
            string url = "AddStaff.aspx";
            string s = "window.open('" + url + "', 'popup_window', 'width=900,height=700,left=100,top=100,resizable=yes');";
            ClientScript.RegisterStartupScript(this.GetType(), "script", s, true);
        }
    }
    protected void CElnkAddStaff_Click(object sender, EventArgs e)
    {
        if (Convert.ToInt32(ddlCE.SelectedIndex) != 0 && (!userRightsColl.Contains("4"))) // Access Right is 4 
        {
            Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Don't have the permission to Add CE ')</script>", false);  
            return;
        }
        else
        {
            string url = "AddStaff.aspx";
            string s = "window.open('" + url + "', 'popup_window', 'width=900,height=700,left=100,top=100,resizable=yes');";
            ClientScript.RegisterStartupScript(this.GetType(), "script", s, true);
        }
    }
    protected void popup452_Click(object sender, EventArgs e)
    {
         if (Convert.ToInt32(ddlQS.SelectedIndex) == 0 && (Convert.ToInt32(Session["userID"]) == 1)) // Access Right is 4 
          Response.Write("<script language='javascript'> window.open('AddStaff.aspx','','width=846,Height=400,fullscreen=1,location=0,scrollbars=0,menubar=1,toolbar=1, align=center,top=100,left=500'); </script>");       
    }    
   
    private void PopulateDropDownBox_TCMS(DropDownList ddlBox, string sqlQuery, string valueMember, string displayName)
    {
        ddlBox.DataSource = new JobOrderData().FillDropdown_TCMS(sqlQuery);
        ddlBox.DataTextField = displayName;
        ddlBox.DataValueField = valueMember;
        ddlBox.SelectedIndex = -1;
        ddlBox.DataBind();
        ddlBox.Items.Insert(0, new ListItem("--Select--"));
    }
    public void Fill_JobOrder_Information(int _jobID)
    {
        try
        {
            SqlConnection sqlConn = new SqlConnection(connValue);
            sqlConn.Open();

            //string strValue = "SELECT  jobNo, jobTypeID, jobPriorityID,  jobStatusID, remarks AS Instruction, deptID,  contractNo, qsID, " +
            //            " ceID, peID, contractTypeID AS Contract_Type_id, projectTitle, remarks, contractorID, consultantID, jobID,addendumNO,jobCatID,jobTypeID,jobDesc,docRefID,workDays, " +
            //" jobDueDate,jobReceivedDate,jobStatusClosedDate,jobClosedDate,docRefID  FROM  Job WHERE  (Jobid = " + _jobID + ")";

            string strValue = "SELECT  Job.jobNo, Job.jobTypeID, Job.jobPriorityID, Job.jobStatusID, Job.remarks AS Instruction, Job.deptID, Job.contractNo, Job.qsID, Job.ceID, Job.peID, " +
                         " Job.contractTypeID AS Contract_Type_id, Job.projectTitle, Job.remarks, Job.contractorID, Job.consultantID, Job.jobID, Job.addendumNO, " +
                         " Job.jobTypeID AS Expr1, Job.jobDesc, Job.docRefID, Job.workDays, Job.jobDueDate, Job.jobReceivedDate, Job.jobStatusClosedDate, Job.jobClosedDate,  " +
                        " Job.docRefID AS Expr2, JobType.CategoryID as JobCatID,job.deptSectionID FROM  Job INNER JOIN  JobType ON Job.jobTypeID = JobType.jobTypeID WHERE   (Job.jobID =  " + _jobID + ")";



            SqlCommand sqlCom = new SqlCommand(strValue, sqlConn);       
            SqlDataReader sqlReader = sqlCom.ExecuteReader();

            while (sqlReader.Read())
            {
                txtJobNo.Text = sqlReader["JobNo"].ToString();
                ddlJobCat.SelectedValue = sqlReader["jobCatID"].ToString();

                if (!sqlReader["jobCatID"].ToString().Equals(sqlReader["jobTypeID"].ToString()))
                {
                    //if (!sqlReader["jobTypeID"].ToString().Equals(4) || !sqlReader["jobTypeID"].ToString().Equals(5) || !sqlReader["jobTypeID"].ToString().Equals(6))
                    {
                        ddlJobType.SelectedValue = sqlReader["jobTypeID"].ToString();
                        Session["jobTypeID"] = sqlReader["jobTypeID"].ToString();
                    }
                }
                else
                {
                    Session["jobTypeID"] = "";
                }

                ddlJobStatus.SelectedValue = sqlReader["jobStatusID"].ToString();
                if (ddlJobStatus.SelectedValue.Equals("1"))
                    ddlJobStatus.Enabled = false;

                Session["jobCatID"] = sqlReader["jobCatID"].ToString();
                Session["jobTypeID"] = sqlReader["jobTypeID"].ToString();
                Session["JobStatusID"] = sqlReader["jobStatusID"].ToString();
                Session["opendocRefID"] = sqlReader["docRefID"].ToString();

                if (sqlReader["deptID"].ToString()!="")
                      ddlDept.SelectedValue = sqlReader["deptID"].ToString();

                if (sqlReader["qsID"].ToString() != "")
                ddlQS.SelectedValue = sqlReader["qsID"].ToString();

                if (sqlReader["peID"].ToString() != "")
                ddlPE.SelectedValue = sqlReader["peID"].ToString();

                if (sqlReader["ceID"].ToString() != "")
                ddlCE.SelectedValue = sqlReader["ceID"].ToString();

                txtPrjCode.Text = sqlReader["contractNo"].ToString();

                Session["contractNo"] = sqlReader["contractNo"].ToString();

                txtPrjTitle.Text = sqlReader["projectTitle"].ToString();

                txtRemarks.Text = sqlReader["remarks"].ToString();
                txtJobDesc.Text = sqlReader["jobDesc"].ToString();

                if (sqlReader["consultantID"].ToString() != "")
                ddlConsultantNo.SelectedValue = sqlReader["consultantID"].ToString();
                if (sqlReader["Contract_Type_id"].ToString() != "")
                ddlCntrType.SelectedValue = sqlReader["Contract_Type_id"].ToString();

                if (sqlReader["contractorID"].ToString() != "")
                ddlVendor.SelectedValue = sqlReader["contractorID"].ToString();

                if (sqlReader["jobPriorityID"].ToString() != "")
                ddlGrade.SelectedValue = sqlReader["jobPriorityID"].ToString();

                Session["GradeVal"] = sqlReader["jobPriorityID"].ToString();

               // txtAddendum.Text = sqlReader["addendumNO"].ToString();

                Session["subdocID"] = sqlReader["docRefID"].ToString();

                txtWorkDays.Text = sqlReader["workDays"].ToString();
                txtDueDate.Text = Convert.ToDateTime(sqlReader["jobDueDate"]).ToString("dd/MMM/yyyy");

                if (sqlReader["jobReceivedDate"].ToString() != "")
                    TextBox2.Text = Convert.ToDateTime(sqlReader["jobReceivedDate"]).ToString("dd/MMM/yyyy");
                else
                    TextBox2.Text = "";

                if (sqlReader["jobStatusClosedDate"].ToString() != "")
                      txtStatusClose.Text = Convert.ToDateTime(sqlReader["jobStatusClosedDate"]).ToString("dd/MMM/yyyy");
                else
                    txtStatusClose.Text = "";

                if (sqlReader["jobClosedDate"].ToString() != "")
                   TextBox4.Text = Convert.ToDateTime(sqlReader["jobClosedDate"]).ToString("dd/MMM/yyyy");
                else
                    TextBox4.Text = "";

                if (sqlReader["deptSectionID"].ToString() != "")
                    ddlSectionName.SelectedValue = sqlReader["deptSectionID"].ToString();

            }
            sqlReader.Close();
            sqlConn.Close();
        }
        catch (Exception ex)
        {
            throw ex;
        }

      //  WorkingDaysCaluclationByGrade(Session["GradeVal"].ToString());
       txtSubject.Text = getDocuemnetSubject(Convert.ToInt32(Session["subdocID"]));

       

    }
    public string getDocuemnetSubject(int docID)
    {
        string strSubject = string.Empty;
        SqlConnection sqlConn = new SqlConnection(connValue);
        string sqlQuery = "SELECT docSubject,referenceNo from document where documentID =" + docID + "";

        try
        {
            sqlConn.Open();
            SqlCommand sqlCom = new SqlCommand(sqlQuery, sqlConn);
            SqlDataReader sqlReader = sqlCom.ExecuteReader();
            while (sqlReader.Read())
            {
                strSubject = sqlReader[0].ToString();

                Session["referenceNo"] = sqlReader["referenceNo"].ToString(); 
            }
            sqlReader.Close();
        }
        catch (Exception ex)
        {
            // Response.Write("Error getting while reading data !" + ex.Message);
        }
        finally
        {
            sqlConn.Close();
        }
        return strSubject;
    }

    private void PopulateDropDownBox(DropDownList ddlBox, string sqlQuery, string valueMember, string displayName)
    {
        DataTable table = new DataTable();

        try
        {
            using (SqlConnection sqlConn = new SqlConnection(connValue))
            {
                using (SqlDataAdapter da = new SqlDataAdapter(sqlQuery, sqlConn))
                {
                    sqlConn.Open();
                    da.Fill(table);
                }
            }
            //cmbBox.Items.Add("Select");
            ddlBox.DataSource = table;
            ddlBox.DataTextField = displayName;
            ddlBox.DataValueField = valueMember;
            ddlBox.SelectedIndex = -1;

            ddlBox.DataBind();
            ddlBox.Items.Insert(0, new ListItem("--Select--"));
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    private void PopulateDropDownBox_JobType(DropDownList ddlBox, string sqlQuery, string valueMember, string displayName)
    {
        DataTable table = new DataTable();
        try
        {
            using (SqlConnection sqlConn = new SqlConnection(connValue))
            {
                using (SqlDataAdapter da = new SqlDataAdapter(sqlQuery, sqlConn))
                {
                    sqlConn.Open();
                    da.Fill(table);
                }
            }
            //cmbBox.Items.Add("Select");
            ddlBox.DataSource = table;
            ddlBox.DataTextField = displayName;
            ddlBox.DataValueField = valueMember;

            // ddlBox.SelectedIndex = -1;

            ddlBox.DataBind();
            ddlBox.Items.Insert(0, new ListItem("--Select--"));
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }   

    public void UpdateJobOrder(int upd_JobID)
    {
        SqlConnection sqlCon = new SqlConnection(connValue);
        SqlCommand cmd = new SqlCommand();
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.CommandText = "UpdatePSA";
        cmd.Connection = sqlCon;
        
        cmd.Parameters.AddWithValue("@Job_id", upd_JobID);

        if (ddlJobType.SelectedIndex != 0)
            cmd.Parameters.AddWithValue("@Job_Type_id", ddlJobType.SelectedValue);
        else
            cmd.Parameters.AddWithValue("@Job_Type_id", ddlJobCat.SelectedValue);

        if (ddlJobStatus.SelectedIndex != 0)
            cmd.Parameters.AddWithValue("@Job_Status_id", ddlJobStatus.SelectedValue);
        else
            cmd.Parameters.AddWithValue("@Job_Status_id", System.DBNull.Value);

          cmd.Parameters.AddWithValue("@Project_Code", txtPrjCode.Text);

          cmd.Parameters.AddWithValue("@jobDesc", txtJobDesc.Text);
          cmd.Parameters.AddWithValue("@Project_Title", txtPrjTitle.Text);
                
        if (ddlVendor.SelectedIndex != 0)
            cmd.Parameters.AddWithValue("@ContractorID", ddlVendor.SelectedValue);
        else
            cmd.Parameters.AddWithValue("@ContractorID", System.DBNull.Value);

        if (ddlConsultantNo.SelectedIndex != 0)
            cmd.Parameters.AddWithValue("@ConsultantID", ddlConsultantNo.SelectedValue);
        else
            cmd.Parameters.AddWithValue("@ConsultantID", System.DBNull.Value);

        if (ddlDept.SelectedIndex != 0)
            cmd.Parameters.AddWithValue("@DepartmentID", ddlDept.SelectedValue);
        else
            cmd.Parameters.AddWithValue("@DepartmentID", System.DBNull.Value);

      //  cmd.Parameters.AddWithValue("@AffairID", Convert.ToInt32(Session["AffairID"]));

        if (ddlQS.SelectedIndex != 0)
            cmd.Parameters.AddWithValue("@QSID", ddlQS.SelectedValue);
        else
            cmd.Parameters.AddWithValue("@QSID", System.DBNull.Value);

        if (ddlPE.SelectedIndex != 0)
            cmd.Parameters.AddWithValue("@PEID", ddlPE.SelectedValue);
        else
            cmd.Parameters.AddWithValue("@PEID", System.DBNull.Value);

        if (ddlCE.SelectedIndex != 0)
            cmd.Parameters.AddWithValue("@CEID", ddlCE.SelectedValue);
        else
            cmd.Parameters.AddWithValue("@CEID", System.DBNull.Value);

        if (ddlGrade.SelectedIndex != 0)
            cmd.Parameters.AddWithValue("@gradeID", ddlGrade.SelectedValue);
        else
            cmd.Parameters.AddWithValue("@gradeID", System.DBNull.Value);

            cmd.Parameters.AddWithValue("@remarks", txtRemarks.Text);

            cmd.Parameters.AddWithValue("@addendumNO", System.DBNull.Value);

            if (ddlCntrType.SelectedIndex != 0)
                cmd.Parameters.AddWithValue("@contractTypeID", ddlCntrType.SelectedValue);
            else
                cmd.Parameters.AddWithValue("@contractTypeID", System.DBNull.Value);

            cmd.Parameters.AddWithValue("@workDays", txtWorkDays.Text);
            cmd.Parameters.AddWithValue("@dueDate", Convert.ToDateTime(txtDueDate.Text).ToString("dd/MMM/yyyy"));

            cmd.Parameters.AddWithValue("@updateUser", Session["UserName"]);

            if (ddlSectionName.SelectedIndex != 0)
                cmd.Parameters.AddWithValue("@deptSectionID", ddlSectionName.SelectedValue);
            else
                cmd.Parameters.AddWithValue("@deptSectionID", System.DBNull.Value);


        try
        {
            sqlCon.Open();
            cmd.ExecuteNonQuery();
            sqlCon.Close();
        }
        catch (Exception ex)
        {
            throw ex;
        }
        //lblResult.Text = "Data Updated Successfully";
       // Response.Write();
    }  
    protected void btnUpdate_Click(object sender, EventArgs e)
    {
        if (userRightsColl.Contains("7"))
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "Popup", "<script>alert('You have no privilege to Update this Job')</script>", false);
            return;
        }
        else
        {
            if (!checkIsProjectCodeChange(Convert.ToInt32(Session["Upd_jobID"])))
            {
                string chageDesc = "Project Code of Job No.  " + txtJobNo.Text + " was changed From " + Session["contractNo"] + " in to " + txtPrjCode.Text;
                string windowName = "Job Order Details";
                string oldPrjCode = Session["contractNo"].ToString();
                PrjCodeChangeLog(chageDesc, windowName, txtPrjCode.Text, oldPrjCode);
            }

            UpdateJobOrder(Convert.ToInt32(Session["Upd_jobID"]));

        }
    }
    private Boolean checkIsProjectCodeChange(int _jobid)
    {
        using (SqlConnection cnn = new SqlConnection(connValue))
        {
            cnn.Open();
            using (SqlCommand cmm = new SqlCommand())
            {
                cmm.Connection = cnn;
                cmm.CommandText = "SELECT contractNo  FROM Job WHERE JobID = " + _jobid + " and contractNo = '" + txtPrjCode.Text.Trim() + "'"; 
                using (SqlDataReader sqlDtReader = cmm.ExecuteReader())
                {
                    if (sqlDtReader.HasRows)
                    {
                        return true;
                    }
                }
            }
        }
        return false;
    }
    protected void btnAddStaff_Click(object sender, EventArgs e)
    {
        if (userRightsColl.Contains("4")) // Access Right is 4 
        {
            Session["lblText"] = "You are not allowed to Add New Job Incharge.Please contact system Administrator for further inquiry.";
            Session["lblSub"] = "Restricted Access to Add New Job Order.";
            Session["lblBody"] = "This is in reference to Restricted Access to Add New Job Order. I would like to inquire about the restriction.";

            string url = "RestrictedMsgWindow.aspx";
            string s = "window.open('" + url + "', 'popup_window', 'width=500,height=250,left=100,top=100,resizable=yes,scrollbars=yes');";
            ClientScript.RegisterStartupScript(this.GetType(), "script", s, true);

            //ClientScript.RegisterClientScriptBlock(this.GetType(), "Popup", "<script>alert('You have no privilege to add this Staff')</script>", false);
            //return;
        }
        else
        {
            Session["jobNo"] = txtJobNo.Text;   
            string url = "AddStaff.aspx";
            string s = "window.open('" + url + "', 'popup_window', 'width=700,height=500,left=100,top=100,resizable=yes');";
            Page.ClientScript.RegisterStartupScript(this.GetType(), "script", s, true);
        } 
    }
   



    // ------------------------------------------------- Job Incharge GridView Code ----------------------------------------------------------------------------------------------------



    protected void gvJoborder_RowDataBound(object sender, GridViewRowEventArgs e)
    { 
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            DropDownList l = (DropDownList)e.Row.FindControl("ddljobtype");

            PopulateDropDownBox(l, "SELECT JobStatusid,JobStatusName as JobStatus FROM jobStatus where JobStatusid in(2,3,6,7) ", "JobStatusid", "JobStatus");  // where JobStatusid in(5,6,7,8)

            TextBox lm = (TextBox)e.Row.FindControl("jobid");
            TextBox afr = (TextBox)e.Row.FindControl("TextBox1");
            TextBox InchargeID = (TextBox)e.Row.FindControl("txtInchargeID");

            Session["InchargeID"] = InchargeID.Text;

            string lk = lm.Text;
            l.ToolTip = InchargeID.Text;

            l.SelectedValue = afr.Text;
         
            Session["StatusVal"] = l.SelectedValue;

            l.SelectedIndexChanged += new EventHandler(SelectedIndexChanged);

            TextBox txtdate = (TextBox)e.Row.FindControl("lblJoindate");            // ActionDueDate 
            txtdate.ToolTip = InchargeID.Text;
            txtdate.TextChanged += new EventHandler(txtdate_TextChanged);
            Session["JobActionDueDate"] = txtdate.Text;

            CheckBox chkstate = (CheckBox)e.Row.FindControl("ad");
            chkstate.ToolTip = InchargeID.Text;
            chkstate.CheckedChanged += new EventHandler(chkstate_CheckedChanged);

            //CheckBox chkstateTL = (CheckBox)e.Row.FindControl("chkTL");
            //chkstateTL.ToolTip = InchargeID.Text;
            //chkstateTL.CheckedChanged += new EventHandler(chkstateTL_CheckedChanged);

            Label lblStaff = (Label)e.Row.FindControl("txtStaff");
            Label lblDistributedBy = (Label)e.Row.FindControl("txtDistrubed");          

            Label lblConactID = (Label)e.Row.FindControl("txtCnctID");
            TextBox _txtDocID = (TextBox)e.Row.FindControl("txtDocID");
            Session["statusdocID"] = _txtDocID.Text;
            Session["contactID"] = lblConactID.Text;
  
            Label lblDistribID = (Label)e.Row.FindControl("txtDistributedBy");

            Label lblTeamLeadID = (Label)e.Row.FindControl("lblTeamLead");
            

            //Label lblRoleID = (Label)e.Row.FindControl("txtRoleID");
           // chkDelete.CheckedChanged += new EventHandler(chkstate_CheckedChanged);                        

            if ((!lblConactID.Text.Equals(Session["userID"])) & (!lblTeamLeadID.Text.Equals(Session["userID"])))
            {
                l.Enabled = false;
                chkstate.Enabled = false;
                // txtdate.Enabled = false;
            }
            if (lblConactID.Text.Equals(Session["userID"]))
            {
                btnOutlook.Enabled = true;
                Session["ActionDate"] = txtdate.Text;
            }
            if (!lblDistribID.Text.Equals(Session["userID"]))
            {
                txtdate.Enabled = false;
            }
            Label lblIsActive = (Label)e.Row.FindControl("txtisActive");    //txtDistisActive
            if (lblIsActive.Text.Equals("False"))
            {
                HyperLink _lnkStaff = (HyperLink)e.Row.FindControl("lnkStaff"); //
                HyperLink _lnkDistribStaff = (HyperLink)e.Row.FindControl("DistibActive"); 
                _lnkStaff.Enabled = false;
                //_lnkDistribStaff.Enabled = false;
            }
            Label lblDistIsActive = (Label)e.Row.FindControl("txtDistisActive");
            if (lblDistIsActive.Text.Equals("False"))
            {
                HyperLink _lnkDistribStaff = (HyperLink)e.Row.FindControl("lnkDistirbStaff");
                _lnkDistribStaff.Enabled = false;                
            }

            if (txtdate.Text != "")
            {
                if ((Convert.ToDateTime(txtdate.Text) < System.DateTime.Today) & (l.SelectedValue!="7"))
                {
                    e.Row.Cells[3].BackColor = System.Drawing.Color.Red;
                    e.Row.Cells[3].ForeColor = System.Drawing.Color.White;

                    txtdate.ForeColor = System.Drawing.Color.White;
                    txtdate.BackColor = System.Drawing.Color.Red;
                }
            }

            //if (Session["userIsActive"].Equals("True"))
            //{
            //    lblStaff.Enabled = false;
            //}     

            //LinkButton lnkDelete = (LinkButton)e.Row.FindControl("btnDeleteInCharge");
            //lnkDelete.Attributes.Add("onclick", "javascript:return " + "confirm('Are you sure you want to delete this Staff?')");
            //lnkDelete.CssClass = "btndelete";
        }
    }
    //
    protected void chkstate_CheckedChanged(object sender, EventArgs e)
    {
        CheckBox chk = (CheckBox)sender;

        int inchargeID = Convert.ToInt32(chk.ToolTip);

        Session["_InchargeID"] = inchargeID;

        new JobOrderData().UpdateStatus(inchargeID, Convert.ToBoolean(chk.Checked));
        new JobOrderData().UpdateCompletionDate(inchargeID, Convert.ToBoolean(chk.Checked));

        IList<int> docIDColl = new List<int>();        

        if (chk.Checked) // true
        {
            // ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('You are not an Authenticated User')</script>", false);

            //docIDColl = getDocIDCollection();
            //IList<int> ststColl = Session["docStatusColl"] as IList<int>;

            //if (ststColl.Contains(1) || ststColl.Contains(2))    // open and Forfollup   1-2 - [4 -close]
            //{
            //    foreach (var docID in docIDColl)
            //    {
            //        new JobOrderData().UpdateDocumentStatusAndDateOfAction(Convert.ToInt32(docID), 4, inchargeID);
            //    }
            //}

            Boolean chkDoc = checkDocExist(inchargeID);
            if (chkDoc == true)
            {
                new JobOrderData().UpdateDocumentStatusForInchargeStatusCompleted(4, inchargeID);     

                //string url = "RestrictedAccessWindow.aspx";
                //string s = "window.open('" + url + "', 'popup_window', 'width=520,height=200,left=100,top=100,resizable=no');";
                //Page.ClientScript.RegisterStartupScript(this.GetType(), "script", s, true);
            }
        }
        else
        {
            //docIDColl = getDocIDCollection();
            //IList<int> ststColl = Session["docStatusColl"] as IList<int>;
            //if (ststColl.Contains(4))    // open and Forfollup   1-2 - [4 -close]
            //{
            //    foreach (var docID in docIDColl)
            //    {
            //        new JobOrderData().UpdateDocumentStatusAndDateOfAction(Convert.ToInt32(docID), 1, inchargeID);
            //    }
            //}

            Boolean chkDoc = checkDocExist(inchargeID);
            if (chkDoc == false)
            {
                string url = "Restricted.aspx";
                string s = "window.open('" + url + "', 'popup_window', 'width=520,height=200,left=100,top=100,resizable=no');";
                Page.ClientScript.RegisterStartupScript(this.GetType(), "script", s, true);
            } 
        }      

        gvJoborder.DataSource = new JobOrderData().GetJobOwnerDetails(_jobID);
        gvJoborder.DataBind();
    }


    protected void chkstateTL_CheckedChanged(object sender, EventArgs e)
    {
        CheckBox chk = (CheckBox)sender;
        int inchargeID = Convert.ToInt32(chk.ToolTip);       
        if (chk.Checked) // true
        {
            new JobOrderData().UpdateTLApproveStatus(Convert.ToInt32(inchargeID), Convert.ToBoolean(chk.Checked));
        }
        else
        {
            new JobOrderData().UpdateTLApproveStatus(Convert.ToInt32(inchargeID), Convert.ToBoolean(chk.Checked));
        }

        gvJoborder.DataSource = new JobOrderData().GetJobOwnerDetails(_jobID);
        gvJoborder.DataBind();
    }
    public IList<int> getDocIDCollection()
    {
        IList<int> docIDColl = new List<int>();
        IList<int> docStatusColl = new List<int>();       
        
        try
        {
            SqlConnection sqlConn = new SqlConnection(connValue);
            sqlConn.Open();

            string strQuery = "SELECT DISTINCT DocumentDistribution.documentID,DocumentDistribution.docStatusID, [Document].jobID FROM  [Document] INNER JOIN DocumentDistribution ON [Document].documentID = DocumentDistribution.documentID  WHERE  ([Document].jobID = " + _jobID + ")";

            SqlCommand sqlCom = new SqlCommand(strQuery, sqlConn); 
            SqlDataReader sqlReader = sqlCom.ExecuteReader();
            while (sqlReader.Read())
            {
                docIDColl.Add(Convert.ToInt32(sqlReader["DocumentID"]));
                docStatusColl.Add(Convert.ToInt32(sqlReader["docStatusID"]));
            }
            Session["docStatusColl"] = docStatusColl;
           
            sqlReader.Close();
            sqlConn.Close();
        }
        catch (System.Exception ex)
        {
            throw ex;
        }
        return docIDColl;
    }
    protected void SelectedIndexChanged(object sender, EventArgs e)
    {
        //1	Closed	 ,        2	Rejected	,        3	On-going	,        4	Pending	PEN	
        //5	Cancelled	,        6	On Hold	,        7	Completed	COM	,        8	Under Process with EBSD	UPE	
        //9	Waiting Consultant Signature	WCS	,        10	Pending with the Committee	PWC	,        11	Waiting Dept. Manager Signature	WMS,  
        // 12	Waiting PB From Consultant	WPB	,        13	Waiting President Signature	WPS	

      
        DropDownList ddl = (DropDownList)sender;
        if (ddl.SelectedIndex != 0)
        {
            string ID = ddl.ID;
            string g = ddl.SelectedValue;
            string inchargeID = ddl.ToolTip;
            Session["_InchargeID"] = inchargeID;
            Session["StatusValCurrent"] = ddl.SelectedValue;

            if (ddl.SelectedValue == "3" || ddl.SelectedValue == "7")
                new JobOrderData().UpdateJobDoneCheckBox(Convert.ToInt32(inchargeID), Convert.ToInt32(ddl.SelectedValue));

            if (ddl.SelectedValue != "7")
            {
                new JobOrderData().UpdateCompletionDate(Convert.ToInt32(inchargeID));
            }

            new JobOrderData().UpdateJobStatus(Convert.ToInt32(inchargeID), Convert.ToInt32(ddl.SelectedValue), Session["UserName"].ToString());

            if (ddl.SelectedValue == "7")
            {
                Boolean chkDoc = checkDocExist(Convert.ToInt32(inchargeID));
                if (chkDoc == true)
                {
                    new JobOrderData().UpdateDocumentStatusForInchargeStatusCompleted(4, Convert.ToInt32(inchargeID));        

                    //string url = "RestrictedAccessWindow.aspx";
                    //string s = "window.open('" + url + "', 'popup_window', 'width=520,height=200,left=100,top=100,resizable=no');";
                    //Page.ClientScript.RegisterStartupScript(this.GetType(), "script", s, true);
                }
            }
            else if (ddl.SelectedValue == "3")
            {
                Boolean chkDoc = checkDocExist(Convert.ToInt32(inchargeID));
                if (chkDoc == false)
                {
                    string url = "Restricted.aspx";
                    string s = "window.open('" + url + "', 'popup_window', 'width=520,height=200,left=100,top=100,resizable=no');";
                    Page.ClientScript.RegisterStartupScript(this.GetType(), "script", s, true);
                }
            }

            gvJoborder.DataSource = new JobOrderData().GetJobOwnerDetails(_jobID);
            gvJoborder.DataBind();
        }
    }
    private Boolean checkDocExist(int inChargeID)
    {
        Boolean chkDocExist = false;
        string prjTitle = string.Empty;
        SqlConnection cnn = new SqlConnection(connValue);
        cnn.Open();
        SqlCommand cmm = new SqlCommand();
        cmm.Connection = cnn;
        cmm.CommandText = "SELECT *  FROM DocumentDistribution WHERE JobOwnerID = " + inChargeID + " and docStatusID in(1,2)"; //open n Follwup
        SqlDataReader sqlDtReader = cmm.ExecuteReader();
        if (sqlDtReader.HasRows)
        {
           chkDocExist = true;            
        }
        else
        {
            prjTitle = "NA";
        }
        sqlDtReader.Close();
        cnn.Close();

        return chkDocExist;
    }
    protected void txtdate_TextChanged(object sender, EventArgs e)
    {
        TextBox tdate = (TextBox)sender;
        //string format = "dd/mm/yyyy";

        string dfs = tdate.Text;


        DateTime dd = new DateTime();
        Thread.CurrentThread.CurrentCulture = new CultureInfo("en-GB");
        CultureInfo ci = System.Threading.Thread.CurrentThread.CurrentCulture;
        DateTime dt;

        //dt = DateTime.Parse(tdate.Text, ci); 
        // DateTime dt = DateTime.Parse(tdate.Text, CultureInfo.GetCultureInfo("en-gb"));
       // new JobOrderData().UpdateJobDate(Convert.ToInt32(tdate.ToolTip), dd.ToString());

        new JobOrderData().UpdateJobDate(Convert.ToInt32(tdate.ToolTip), dfs);

        gvJoborder.DataSource = new JobOrderData().GetJobOwnerDetails(_jobID);
        gvJoborder.DataBind();
    }

    private void FillTab2()
    {
        try
        {
            DataSet ds = new DataSet();

            int x;
            x = 0;

            ds = (new JobOrderData().GetJobOrderDetails(0, "", 0, 0, "", "", 0));
            gvJoborder.DataSource = ds;
            gvJoborder.DataBind();

            //   Convert.ToInt32(txtjobid.Text), txtJobNo.Text, Convert.ToInt32(txtaffair.Text), Convert.ToInt32(txtdept.Text), txtprojcode.Text, txtprojtitle.Text, Convert.ToInt32(txtconsult.Text)));
        }
        catch (Exception ex)
        {

        }
    }
     
    protected void Button1_Click(object sender, EventArgs e)
    {
        Response.Write("<script language='javascript'> window.open('VODemo.aspx','','width=846,Height=400,fullscreen=1,location=0,scrollbars=0,menubar=1,toolbar=1, align=center,top=100,left=500'); </script>");

        // Response.Write("<script language='javascript'> window.open('EOTDetailsWindow.aspx','','width=846,Height=400,fullscreen=1,location=0,scrollbars=0,menubar=1,toolbar=1, align=center,top=100,left=500'); </script>");       
    }
    protected void btnReceive_Click(object sender, EventArgs e)
    {
        string strUpdateJob = Request.Url.AbsoluteUri;
        try
        {
            if (userRightsColl.Contains("8")) // Access Right is 4 
            {
                ClientScript.RegisterClientScriptBlock(this.GetType(), "Popup", "<script>alert('You have no privilege to add this Document')</script>", false);
                return;
            }
            else
            {
                Session["UrlRef"] = strUpdateJob;
                Session["jobID"] = _jobID;

                 Session["referenceNo"] = ""; 
                Response.Redirect("~/Documents/DocumentDetailsWindow.aspx?RecSentCatID=1&Reply=0", false);
            }
        }
        catch (Exception ex)
        {

        }       
    }   
    protected void ddlGrade_SelectedIndexChanged(object sender, EventArgs e)
    {
       // WorkingDaysCaluclationByGrade(ddlGrade.SelectedItem.ToString(), Session["DocRecDate"].ToString());

        WorkingDaysCaluclationByGrade(TextBox2.Text);
    }
    private void WorkingDaysCaluclationByGrade(string strDate)
    {
        string endDate = string.Empty;
        switch (ddlGrade.SelectedItem.ToString())
        {
            case "1":
                txtWorkDays.Text = "5"; // Working Days
                endDate = getEndDateByGivenDays(5, strDate);
                txtDueDate.Text = Convert.ToDateTime(endDate).ToString("dd/MMM/yyyy");

                //txtDueDate.Text = System.DateTime.Now.AddDays(5).ToString("dd/MMM/yyyy");
                break;
            case "2":
                endDate = getEndDateByGivenDays(8, strDate);
                txtDueDate.Text = Convert.ToDateTime(endDate).ToString("dd/MMM/yyyy");
                txtWorkDays.Text = "7";
                break;

            case "3":
                endDate = getEndDateByGivenDays(10, strDate);
                txtDueDate.Text = Convert.ToDateTime(endDate).ToString("dd/MMM/yyyy");
                txtWorkDays.Text = "10";
                break;

            case "4":
                endDate = getEndDateByGivenDays(15, strDate);
                txtDueDate.Text = Convert.ToDateTime(endDate).ToString("dd/MMM/yyyy");
                txtWorkDays.Text = "15";
                break;

            case "":
                txtDueDate.Text = "";
                txtWorkDays.Text = "";
                break;

            default:
                break;
        }
    }
    private string getEndDateByGivenDays(int _days, string strDate)
    {
        SqlConnection con = new SqlConnection(connValue);
        SqlCommand cmd = new SqlCommand();
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Connection = con;

        cmd.CommandText = "AddWorkdays";
        SqlParameter prm = cmd.Parameters.Add("@ad_startDate", SqlDbType.DateTime);
        prm.Value = strDate;
        prm = cmd.Parameters.Add("@actual_workDays", SqlDbType.Int);
        prm.Value = Convert.ToInt32(_days);
        prm = cmd.Parameters.Add("@endDate", SqlDbType.DateTime);
        prm.Direction = ParameterDirection.Output;
        con.Open();
        SqlDataReader dr = cmd.ExecuteReader();
        while (dr.Read())
            Console.WriteLine(dr.GetString(0));
        con.Dispose();
        con.Close();

        return cmd.Parameters[2].Value.ToString();
    }
    protected void btnSent_Click(object sender, EventArgs e)
    {
        string strUpdateJob = Request.Url.AbsoluteUri;  
        try
        {
            if (userRightsColl.Contains("8")) // Access Right is 4 
            {
                ClientScript.RegisterClientScriptBlock(this.GetType(), "Popup", "<script>alert('You have no privilege to add Document')</script>", false);
                return;
            }
            else
            {
                Session["DocCategoryID"] = "2";    // It should be 2
                Session["DocID"] = null;
                Session["UrlRef"] = strUpdateJob;
                Session["JobID"] = _jobID;

                Session["referenceNo"] = "";  // This is for reply to document
                Response.Redirect("~/Documents/DocumentDetailsWindow.aspx?RecSentCatID=2&Reply=0", false);
            }
        }
        catch (Exception ex)
        {

        }   
    }
    protected void ddlDept_SelectedIndexChanged(object sender, EventArgs e)
    {
        Session["AffairID"] = new JobOrderData().getAffairID(Convert.ToInt32(ddlDept.SelectedValue));

        if (ddlDept.SelectedIndex != 0)
            PopulateDropDownBox(ddlSectionName, "Select sectionID,sectionName From Section Where departmentID = " + Convert.ToInt32(ddlDept.SelectedValue) + "", "sectionID", "sectionName");        

    }
    protected void ddlJobCat_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlJobCat.SelectedIndex > 0)
        {
            FillCombo(ddlJobType, "JobTypeID", "JobTypeName", ExecuteQuery("SELECT JobTypeID,JobTypeName FROM JobType WHERE CategoryID= " + ddlJobCat.SelectedValue + " and jobTypeID<>CategoryID"), false);
            ddlJobType.Items.Insert(0, new ListItem("--Select--"));
        }
        else
            ddlJobType.Items.Clear();
    }
    public static void FillCombo(DropDownList dropDownList, string dataValueField, string dataTextField, DataTable dataTbl, bool bHasBlank)
    {
        dropDownList.DataTextField = dataTextField;
        dropDownList.DataValueField = dataValueField;
        dropDownList.DataSource = dataTbl;
        dropDownList.DataBind();


        if (bHasBlank)
            dropDownList.Items.Insert(0, new ListItem());
    }
    public static DataTable ExecuteQuery(string SQLstring)
    {
        string sConstr = ConfigurationManager.ConnectionStrings["EBSDEBookConn"].ConnectionString;
        SqlConnection Conn = new SqlConnection(sConstr);
        DataTable dt = new DataTable("tbl");

        using (Conn)
        {
            Conn.Open();
            SqlCommand comm = new SqlCommand(SQLstring, Conn);
            comm.CommandTimeout = 0;
            SqlDataAdapter da = new SqlDataAdapter(comm);
            da.Fill(dt);
        }

        return dt;
    }
    protected void nLinkRec_Click(object sender, EventArgs e)
    {
        Session["CatID"] = "1";
        Session["lnkJobID"] = _jobID;
        Session["referenceNo"] = ""; 
        if (userRightsColl.Contains("4")) // Access Right is 4 
        {
            Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Don't have the permission to Add Staff ')</script>", false);
            return;
        }
        else
        {
            string url = "uploadDoc.aspx";
            string s = "window.open('" + url + "', 'popup_window', 'width=600,height=400,left=100,top=100,resizable=yes');";
            Page.ClientScript.RegisterStartupScript(this.GetType(), "script", s, true);
        } 
    }
    protected void btnLinkSent_Click(object sender, EventArgs e)
    {
        Session["CatID"] = "2";
        Session["lnkJobID"] = _jobID;
         Session["referenceNo"] = ""; 
        if (userRightsColl.Contains("4")) // Access Right is 4 
        {
            Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Don't have the permission to Add Staff ')</script>", false);
            return;
        }
        else
        {
            string url = "uploadDoc.aspx";
            string s = "window.open('" + url + "', 'popup_window', 'width=600,height=400,left=100,top=100,resizable=yes');";
            Page.ClientScript.RegisterStartupScript(this.GetType(), "script", s, true);
        } 
    }
    protected void DocSent_Click(Object sender, EventArgs e) 
    {
        try
        {
            Session["DocCategoryID"] = "2";          

            Session["DocID"] = sentDocID;  
            //Session["UrlRef"] = "~/Documents/ReceiveUploadDocuments.aspx";
            Session["JobID"] = _jobID;
            Response.Redirect("~/Documents/DocumentDetailsWindow.aspx", false);
        }
        catch (Exception ex)
        {

        }   
    }
    protected void gridSent_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            LinkButton lnkRef = (LinkButton)e.Row.FindControl("lnkSent");

            Label txtDocType = (Label)e.Row.FindControl("SenttxtDocType");
            Label txtDate = (Label)e.Row.FindControl("SenttxtDate");
            TextBox txtDocID = (TextBox)e.Row.FindControl("SenttxtDocID");
            Label lblOpenRef = (Label)e.Row.FindControl("SentlblOpenDocRef");
            Label lblCloseRef = (Label)e.Row.FindControl("SentlblClosedDocRef");
            Control ctrlReceiveCreateUser = e.Row.FindControl("divSentCreateUserID");
            Control ctrlReceiveOriginContactID = e.Row.FindControl("divSentOriginContactID");
            Control ctrlSuperseded = e.Row.FindControl("divSentSuperseded");
            HtmlGenericControl htmlCtrlSuperseded = ctrlSuperseded as HtmlGenericControl;
            HtmlGenericControl htmlCtrlctrlReceiveOriginContactID = ctrlReceiveOriginContactID as HtmlGenericControl;
            HtmlGenericControl htmlCtrlReceiveCreateUser = ctrlReceiveCreateUser as HtmlGenericControl;                     

            string strDocID = txtDocID.Text;
            string strOpenRef = lblOpenRef.Text;
            string strCloesdRef = lblCloseRef.Text;

            LinkButton lnkView = (LinkButton)e.Row.FindControl("SentbtnDelete");
            if (htmlCtrlSuperseded.InnerText.Equals("True"))
            {
                e.Row.Cells[3].BackColor = System.Drawing.Color.WhiteSmoke;
                e.Row.Cells[3].ForeColor = System.Drawing.Color.Gray;

                e.Row.Cells[4].BackColor = System.Drawing.Color.WhiteSmoke;
                e.Row.Cells[4].ForeColor = System.Drawing.Color.Gray;


                   if (htmlCtrlReceiveCreateUser.InnerText.Equals(Session["UserID"].ToString()) || htmlCtrlctrlReceiveOriginContactID.InnerText.Equals(Session["UserID"].ToString()) || Session["UserProfileID"].ToString().Equals("1"))
                   {
                       if (lnkRef != null)
                       {
                           lnkRef.Enabled = true;
                           lnkRef.Font.Underline = true;
                       }                   
                   } 
                   else
                   {
                        lnkRef.Enabled = false;
                        lnkRef.Font.Underline = false;
                        lnkRef.ForeColor = System.Drawing.Color.Gray;

                        e.Row.Cells[2].BackColor = System.Drawing.Color.WhiteSmoke;
                        e.Row.Cells[2].ForeColor = System.Drawing.Color.Black;
                   }
             }           

             if (strDocID.Equals(strOpenRef) || (strDocID.Equals(strCloesdRef)))
             {
                lnkView.ForeColor = System.Drawing.Color.White;
             }
             else
             {               
                lnkView.Attributes.Add("onclick", "javascript:return " + "confirm('This will delete this document from this Job Order.')");
                lnkView.CssClass = "SentbtnDelete";
             }

             Session["DocDelete"] = "1";
        }
    }   
    string recDocID = string.Empty;
    protected void gridReceived_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        string str = Request.Url.AbsoluteUri;
        if (e.CommandName == "VIEWREC")
        {
            LinkButton lnkView = (LinkButton)e.CommandSource;
            recDocID = lnkView.CommandArgument;
            try
            {
                Session["UrlRef"] = str;
                Session["JobID"] = _jobID;
                Response.Redirect("~/Documents/DocumentDetailsWindow.aspx?docRecID=" + recDocID + "&RecSentCatID=1", false);
            }
            catch (Exception ex)
            {

            }            
        }
        if (e.CommandArgument != "")
        {
            int docID = Convert.ToInt32(e.CommandArgument);
            IList<string> docLetterIDs = new List<string>();
            docLetterIDs = (new JobOrderData().chkDocumentRefWithDCJob(_jobID));
            switch (e.CommandName)
            {
                case "RecDeleteDocid":

                    foreach (var item in docLetterIDs)
                    {
                        if (!docID.ToString().Equals(item))
                        {
                            new JobOrderData().DeactivateDocumentForJob(docID);
                            DeleteDistributionForJobIncharge(docID);
                        }
                        else
                            ClientScript.RegisterStartupScript(this.GetType(), "alert", "alert('You can't delete, This document reference with Job');", true);
                    }

                    //if (!docID.ToString().Equals(docLetterIDs[0]))
                    //{
                    //    if (!docID.ToString().Equals(docLetterIDs[1]))
                    //    {
                    //        new JobOrderData().DeactivateDocumentForJob(docID);
                    //        DeleteDistributionForJobIncharge(docID);
                    //    }

                    //    gridReceived.DataSource = new JobOrderData().getJobDocumetReceivedDate(_jobID);
                    //    gridReceived.DataBind();
                    //}
                    //else
                    //{
                    //    ClientScript.RegisterStartupScript(this.GetType(), "alert", "alert('You can't delete, This document reference with Job');", true);
                    //}                    

                    if (flag > 0)
                    {
                      //  Response.Write("Link Deactivated with Job");
                    }
                    break;
            }
        }
    }
    string sentDocID = string.Empty;
    int flag = 0;
    protected void gridSent_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        string str = Request.Url.AbsoluteUri;
        if (e.CommandName == "VIEW")
        {
            LinkButton lnkView = (LinkButton)e.CommandSource;
            sentDocID = lnkView.CommandArgument;
            try
            {
                Session["UrlRef"] = str;
                Session["JobID"] = _jobID;
                Response.Redirect("~/Documents/DocumentDetailsWindow.aspx?docRecID=" + sentDocID + "&RecSentCatID=2", false);
            }
            catch (Exception ex)
            {

            }   
        }
        if (e.CommandArgument != "")
        {
           // LinkButton lnkView = (LinkButton)e.CommandSource;
           //// LinkButton l = (LinkButton)e.Row.FindControl("btnDelete");
           // lnkView.Attributes.Add("onclick", "javascript:return " + "confirm('Are you sure you want to delete this Document')");
           // lnkView.CssClass = "btndelete";

            int docID = Convert.ToInt32(e.CommandArgument);
            IList<string> docLetterIDs = new List<string>();
            docLetterIDs = (new JobOrderData().chkDocumentRefWithJob(_jobID));
            switch (e.CommandName)
            {
                case "SentDeleteDocid":

                    foreach (var item in docLetterIDs)
                    {
                        if (!docID.ToString().Equals(item))
                        {
                            new JobOrderData().DeactivateDocumentForJob(docID);
                            DeleteDistributionForJobIncharge(docID);
                        }
                        else
                            ClientScript.RegisterStartupScript(this.GetType(), "alert", "alert('You can't delete, This document reference with Job');", true);
                    }
                    
                    if (flag > 0)
                    {
                        //Response.Write("Link Deactivated with Job");
                    }
                    break;
            }
        }
    }   
    protected void ddlJobStatus_SelectedIndexChanged(object sender, EventArgs e)
    {
        //Session["JobStatusID"]
        if (ddlJobStatus.SelectedIndex !=0)
        {
            //Session["DocID"] = "";
            Session["lnkJobID"] = _jobID;
            if (userRightsColl.Contains("6")) // Access Right is 4 
            {
                Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Don't have the permission to edit this field')</script>", false);
                return;
            }

            if ((ddlJobStatus.SelectedValue == "2") || (ddlJobStatus.SelectedValue == "5"))     //Rej or Cancelleted 2 n 5
            {
                UpdateJobStatusDate(_jobID, Convert.ToInt32(ddlJobStatus.SelectedValue));
            }
            else if ((ddlJobStatus.SelectedValue == "3"))  // ongoing
            {
                UpdateJobStatusDate(_jobID, Convert.ToInt32(ddlJobStatus.SelectedValue));
            }
            else if (ddlJobStatus.SelectedValue == "7") // Close n Completed 7
            {
                UpdateJobStatusDate(_jobID, Convert.ToInt32(ddlJobStatus.SelectedValue));
            }
            else if (ddlJobStatus.SelectedValue == "1")
            {
                CloseJob(); 
            }
            else
            {
                UpdateJobStatusDate(_jobID, Convert.ToInt32(ddlJobStatus.SelectedValue));
            }

            Fill_JobOrder_Information(_jobID);

            //else if (ddlJobStatus.SelectedValue == "1")     //|| (ddlJobStatus.SelectedValue == "3")              
            //{
            //    Session["JobStatus"] = ddlJobStatus.SelectedValue;
            //    string url = "UploadStatusDoc.aspx";
            //    string s = "window.open('" + url + "', 'popup_window', 'width=400,height=400,left=100,top=100,resizable=yes');";
            //    Page.ClientScript.RegisterStartupScript(this.GetType(), "script", s, true);
            //}
            //else if (Session["JobStatusID"].ToString().Equals("1") && Convert.ToInt32(ddlJobStatus.SelectedValue) != 1)
            //{
            //    int clsRefID = Convert.ToInt32(getDocuemnetCloseRef(_jobID));
            //    UpdateJobCloseRefID(_jobID, clsRefID);
            //    UpdateJobCloseDate(_jobID, Convert.ToInt32(ddlJobStatus.SelectedValue));
            //}
        }
    }
    public void UpdateJobStatusDate(int _jobID, int statusID)
    {
        string upDateQuery = string.Empty;

        if (statusID == 3)     // ongoing       
              upDateQuery = "UPDATE Job SET jobClosedDate =@jobClosedDate,jobStatusID =@jobStatusID,jobStatusClosedDate=@jobStatusClosedDate,closedDocRefID=@closedDocRefID WHERE JobID = @JobID";       
        else
            upDateQuery = "UPDATE Job SET jobClosedDate =@jobClosedDate,jobStatusID =@jobStatusID,jobStatusClosedDate=@jobStatusClosedDate WHERE JobID = @JobID";


        SqlConnection sqlCon = new SqlConnection(connValue);
        SqlCommand cmd = new SqlCommand();
        cmd.CommandText = upDateQuery;
        cmd.Connection = sqlCon;

        cmd.Parameters.AddWithValue("@JobID", _jobID);

        if (statusID == 3)
            cmd.Parameters.AddWithValue("@jobClosedDate", System.DBNull.Value);
        else if ((statusID == 2) || (statusID == 5))
            cmd.Parameters.AddWithValue("@jobClosedDate", System.DateTime.Now.ToString("dd/MMM/yyyy"));        
        else
            cmd.Parameters.AddWithValue("@jobClosedDate", System.DBNull.Value);


        if (statusID == 3) // On going
            cmd.Parameters.AddWithValue("@jobStatusClosedDate", System.DBNull.Value);
        else if ((statusID == 2) || (statusID == 5))
            cmd.Parameters.AddWithValue("@jobStatusClosedDate", System.DBNull.Value);      
        else if (statusID == 7)  // complted
            cmd.Parameters.AddWithValue("@jobStatusClosedDate", System.DateTime.Now.ToString("dd/MMM/yyyy"));        
        else
            cmd.Parameters.AddWithValue("@jobStatusClosedDate", System.DBNull.Value);

        if (statusID == 3)
            cmd.Parameters.AddWithValue("@closedDocRefID", System.DBNull.Value);

        cmd.Parameters.AddWithValue("@jobStatusID", statusID);

        try
        {
            sqlCon.Open();
            cmd.ExecuteNonQuery();
            sqlCon.Close();
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    public string getDocuemnetCloseRef(int _jobID)
    {
        string strJobRefID = string.Empty;
        SqlConnection sqlConn = new SqlConnection(connValue);
        string sqlQuery = "SELECT closedDocRefID from Job where jobID =" + _jobID + "";

        try
        {
            sqlConn.Open();
            SqlCommand sqlCom = new SqlCommand(sqlQuery, sqlConn);
            SqlDataReader sqlReader = sqlCom.ExecuteReader();
            while (sqlReader.Read())
            {
                strJobRefID = sqlReader[0].ToString();
            }
            sqlReader.Close();
        }
        catch (Exception ex)
        {
            // Response.Write("Error getting while reading data !" + ex.Message);
        }
        finally
        {
            sqlConn.Close();
        }
        return strJobRefID;
    }
    public void UpdateJobCloseRefID(int _jobID,int docClsID)
    {
        string upDateQuery = "UPDATE Document SET jobID =@Job_id WHERE DocumentID = @docClsID";
        SqlConnection sqlCon = new SqlConnection(connValue);
        SqlCommand cmd = new SqlCommand();
        cmd.CommandText = upDateQuery;
        cmd.Connection = sqlCon;

        cmd.Parameters.AddWithValue("@Job_id", System.DBNull.Value);
        cmd.Parameters.AddWithValue("@docClsID", docClsID);       

        try
        {
            sqlCon.Open();
            cmd.ExecuteNonQuery();
            sqlCon.Close();
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    public void UpdateJobStatus(int _jobID)
    {
        string upDateQuery = "UPDATE Job SET jobStatusID =@Job_Status_id WHERE Jobid = @Job_id";
        SqlConnection sqlCon = new SqlConnection(connValue);
        SqlCommand cmd = new SqlCommand();
        cmd.CommandText = upDateQuery;
        cmd.Connection = sqlCon;

        cmd.Parameters.AddWithValue("@Job_id", _jobID);
        cmd.Parameters.AddWithValue("@Job_Status_id", 1);        //2- Closed   

        try
        {
            sqlCon.Open();
            cmd.ExecuteNonQuery();
            sqlCon.Close();
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    public void UpdateJobCloseDate(int _jobID,int statID)
    {
        string updateSql = "UPDATE Job SET closedDate = @CompleteDate,closedDocRefID =@closeDocID,jobStatusID=@jobStatusID Where JobID = @jobID";
        SqlConnection sqlCon = new SqlConnection(connValue);
        SqlCommand cmd = new SqlCommand();
        cmd.CommandText = updateSql;
        cmd.Connection = sqlCon;
        try
        {
            sqlCon.Open();
            cmd.Parameters.AddWithValue("@jobID", _jobID);    //Convert.ToInt32(Session["lnkJobID"])            
            cmd.Parameters.AddWithValue("@CompleteDate", System.DBNull.Value);
            cmd.Parameters.AddWithValue("@closeDocID", System.DBNull.Value);         
            cmd.Parameters.AddWithValue("@jobStatusID", statID);

            cmd.ExecuteNonQuery();

            sqlCon.Close();
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    public void UpdateJobClosedReference(int _jobID)
    {
        string upDateQuery = "UPDATE Job SET jobStatusID =@Job_Status_id WHERE Jobid = @Job_id";
        SqlConnection sqlCon = new SqlConnection(connValue);
        SqlCommand cmd = new SqlCommand();
        cmd.CommandText = upDateQuery;
        cmd.Connection = sqlCon;

        cmd.Parameters.AddWithValue("@Job_id", _jobID);
        cmd.Parameters.AddWithValue("@Job_Status_id", 1);        //2- Closed   

        try
        {
            sqlCon.Open();
            cmd.ExecuteNonQuery();
            sqlCon.Close();
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    
    private IList<string> getStaffID(int _jobID, int staffRoleID,int inchargeID)
    {
        IList<string> staffDataColl = new List<string>();  
        SqlConnection sqlConn = new SqlConnection(connValue);
        string sqlQuery = "SELECT StaffRoleID,contactID from JobOwner where jobID = " + _jobID + " and StaffRoleID = " + staffRoleID + " and jobOwnerID <> " + inchargeID + " ORDER BY jobOwnerID Desc ";

       // "SELECT  StaffRoleID, jobID FROM   JobOwner  WHERE  (StaffRoleID = 1) ORDER BY jobOwnerID"

        try
        {
            sqlConn.Open();
            SqlCommand sqlCom = new SqlCommand(sqlQuery, sqlConn);
            SqlDataReader sqlReader = sqlCom.ExecuteReader();
            while (sqlReader.Read())
            {
                staffDataColl.Add(sqlReader[0].ToString());
                staffDataColl.Add(sqlReader[1].ToString());
            }
            sqlReader.Close();
        }
        catch (Exception ex)
        {
            // Response.Write("Error getting while reading data !" + ex.Message);
        }
        finally
        {
            sqlConn.Close();
        }

        return staffDataColl;
    }

    protected void ddlConsultantNo_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void ddlVendor_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void ddlJobCat_DataBound(object sender, EventArgs e)
    {
        
    }   
    protected void btnOutlook_Click(object sender, EventArgs e)
    {
        Session["jobNo"] = txtJobNo.Text;
       // Session["emailAdr"] = contactID.Text;
        Session["emailAdr"] = Session["IssuedByEmailAddress"];
        string url = "SetTaskReminder.aspx";
        string s = "window.open('" + url + "', 'popup_window', 'width=700,height=500,left=100,top=100,resizable=yes');";
        Page.ClientScript.RegisterStartupScript(this.GetType(), "script", s, true);

    }
    //private void a()
    //{
    //    int jobOwnerID = 0;
    //    GridView gridTemp = sender as GridView;
    //    {
    //        int z = 0;
    //        foreach (GridViewRow x in gvJoborder.Rows)
    //        {
    //            CheckBox chk = (CheckBox)x.FindControl("deleteRow");
    //            if (chk.Checked == true)
    //            {
    //                z = z + 1;
    //            }
    //        }
    //        if (z == 1)
    //        {
    //            foreach (GridViewRow x in gvJoborder.Rows)
    //            {
    //                CheckBox chk = (CheckBox)x.FindControl("deleteRow");
    //                //Label _lbljobID = (Label)x.FindControl("lblJobID");
    //                TextBox InchargeID = (TextBox)x.FindControl("txtInchargeID");
    //                jobOwnerID = Convert.ToInt32(InchargeID.Text);
    //                Label staffID = (Label)x.FindControl("txtRoleID");
    //                Label contactID = (Label)x.FindControl("lblEmail");

    //                if (chk.Checked == true)
    //                {
    //                    Session["jobNo"] = txtJobNo.Text;
    //                    Session["emailAdr"] = contactID.Text;
    //                    string url = "SetTaskReminder.aspx";
    //                    string s = "window.open('" + url + "', 'popup_window', 'width=700,height=500,left=100,top=100,resizable=yes');";
    //                    Page.ClientScript.RegisterStartupScript(this.GetType(), "script", s, true);
    //                }
    //            }
    //        }
    //        else
    //        {
    //            ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Please select checkBox for Delete Staff')</script>", false);
    //        }
    //    }

    //}

    # endregion
    protected void txtWorkDays_TextChanged(object sender, EventArgs e)
    {
        //if (txtWorkDays.Text != "0")
        //{
        //    string endDate = getEndDateByGivenDays(TextBox2.Text);
        //    txtDueDate.Text = Convert.ToDateTime(endDate).ToString("dd/MMM/yyyy");
        //}
        //else
        //{
        //    txtWorkDays.Text = "1";
        //}      

        //if (txtWorkDays.Text.Equals("5"))
        //    ddlGrade.SelectedIndex = 1;
        //else if (txtWorkDays.Text.Equals("7"))
        //    ddlGrade.SelectedIndex = 2;
        //else if (txtWorkDays.Text.Equals("10"))
        //    ddlGrade.SelectedIndex = 3;
        //else if (txtWorkDays.Text.Equals("15"))
        //    ddlGrade.SelectedIndex = 4;
        //else
        //    ddlGrade.SelectedIndex = 0;
    }
    private string getEndDateByGivenDays(string strDate)
    {
        SqlConnection con = new SqlConnection(connValue);
        SqlCommand cmd = new SqlCommand();
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Connection = con;

        cmd.CommandText = "AddWorkdays";
        SqlParameter prm = cmd.Parameters.Add("@ad_startDate", SqlDbType.DateTime);
        prm.Value = strDate;
        prm = cmd.Parameters.Add("@actual_workDays", SqlDbType.Int);
        prm.Value = Convert.ToInt32(txtWorkDays.Text);
        prm = cmd.Parameters.Add("@endDate", SqlDbType.DateTime);
        prm.Direction = ParameterDirection.Output;
        con.Open();
        SqlDataReader dr = cmd.ExecuteReader();
        while (dr.Read())
            Console.WriteLine(dr.GetString(0));
        con.Dispose();
        con.Close();

        return cmd.Parameters[2].Value.ToString();
    }
    private string getEndDateByGivenDays()
    {
        SqlConnection con = new SqlConnection(connValue);
        SqlCommand cmd = new SqlCommand();
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Connection = con;
        if (txtWorkDays.Text != "")
        {
            cmd.CommandText = "AddWorkdays";
            SqlParameter prm = cmd.Parameters.Add("@ad_startDate", SqlDbType.DateTime);
            prm.Value = System.DateTime.Now;
            prm = cmd.Parameters.Add("@actual_workDays", SqlDbType.Int);
            prm.Value = Convert.ToInt32(txtWorkDays.Text);
            prm = cmd.Parameters.Add("@endDate", SqlDbType.DateTime);
            prm.Direction = ParameterDirection.Output;
            con.Open();
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
                Console.WriteLine(dr.GetString(0));
            con.Dispose();
            con.Close();
        }
        return cmd.Parameters[2].Value.ToString();
    }
    private string getDaysByGivenEndDate(string endDate)
    {
        SqlConnection con = new SqlConnection(connValue);
        SqlCommand cmd = new SqlCommand();
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Connection = con;
        cmd.CommandText = "testSP";
        SqlParameter prm = cmd.Parameters.Add("@ad_startDate", SqlDbType.DateTime);
        prm.Value = System.DateTime.Now;
        prm = cmd.Parameters.Add("@ad_endDate", SqlDbType.DateTime);
        prm.Value = Convert.ToDateTime(endDate);

        prm = cmd.Parameters.Add("@ai_workDays", SqlDbType.Int);
        prm.Direction = ParameterDirection.Output;
        con.Open();
        SqlDataReader dr = cmd.ExecuteReader();
        while (dr.Read())
            Console.WriteLine(dr.GetString(0));
        con.Dispose();
        con.Close();

        return cmd.Parameters[2].Value.ToString();
    }
    protected void txtDueDate_TextChanged(object sender, EventArgs e)
    {
        //DateTime dateEnd = System.DateTime.Now;
        //dateEnd = ConvertToDateTime(txtDueDate.Text);

        //DateTime dateEnd = Convert.ToDateTime(TextBox2.Text).ToString("dd/MMM/yyyy");

        DateTime dateEnd = ConvertToDateTime(txtDueDate.Text);
        DateTime strDate = ConvertToDateTime(TextBox2.Text);

        string _strDate = strDate.ToString();

        txtWorkDays.Text = getDaysByGivenEndDate(_strDate, dateEnd);
        //txtDueDate.Text = dateEnd.ToString("dd/MMM/yyyy");

        if (txtWorkDays.Text.Equals("5"))
            ddlGrade.SelectedIndex = 1;
        else if (txtWorkDays.Text.Equals("7"))
            ddlGrade.SelectedIndex = 2;
        else if (txtWorkDays.Text.Equals("10"))
            ddlGrade.SelectedIndex = 3;
        else if (txtWorkDays.Text.Equals("15"))
            ddlGrade.SelectedIndex = 4;
        else
            ddlGrade.SelectedIndex = 0;
    }
    private DateTime ConvertToDateTime(string strDateTime)
    {
        DateTime dtFinaldate; string sDateTime;
        try
        {
            //dtFinaldate = Convert.ToDateTime(strDateTime); 

            string[] sDate = strDateTime.Split('/');
            sDateTime = sDate[1] + '/' + sDate[0] + '/' + sDate[2];
            dtFinaldate = Convert.ToDateTime(sDateTime);
        }
        catch (Exception e)
        {
            string[] sDate = strDateTime.Split('/');
            sDateTime = sDate[0] + '/' + sDate[1] + '/' + sDate[2];
            dtFinaldate = Convert.ToDateTime(sDateTime);
        }
        return dtFinaldate;
    }
    private string getDaysByGivenEndDate(string strDate, DateTime endDate)
    {
        strDate = Convert.ToDateTime(strDate).ToString("MM/dd/yyyy", CultureInfo.InvariantCulture);
        //endDate = Convert.ToDateTime(endDate).ToString("MM/dd/yyyy", CultureInfo.InvariantCulture);

        //DateTime dt = DateTime.ParseExact(endDate, "d/M/yyyy", null);
        //endDate = dt.ToString("dd/MM/yyyy");

        DateTime strDt = DateTime.ParseExact(strDate, "MM/dd/yyyy", CultureInfo.InvariantCulture);
        //DateTime endDt = DateTime.ParseExact(endDate, "MM/dd/yyyy", CultureInfo.InvariantCulture);

        SqlConnection con = new SqlConnection(connValue);
        SqlCommand cmd = new SqlCommand();

        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Connection = con;

        cmd.CommandText = "testSP";

        SqlParameter prm = cmd.Parameters.Add("@ad_startDate", SqlDbType.DateTime);
        prm.Value = strDt;

        prm = cmd.Parameters.Add("@ad_endDate", SqlDbType.DateTime);
        prm.Value = endDate;

        prm = cmd.Parameters.Add("@ai_workDays", SqlDbType.Int);
        prm.Direction = ParameterDirection.Output;

        //prm = cmd.Parameters.Add("@as_errMsg", SqlDbType.VarChar);
        //prm.Direction = ParameterDirection.Output;

        con.Open();
        SqlDataReader dr = cmd.ExecuteReader();
        while (dr.Read())
            Console.WriteLine(dr.GetString(0));
        con.Dispose();
        con.Close();

        return cmd.Parameters[2].Value.ToString();
    }
    static Boolean isprjCodeChanged = false;
    protected void txtPrjCode_TextChanged(object sender, EventArgs e)
    {
        isprjCodeChanged = true;

       // string chageDesc = txtPrjCode.Text + " Changed as " + txtPrjCode.Text;
       // PrjCodeChangeLog(chageDesc, "JobOrder", txtPrjCode.Text, txtPrjCode.Text);
    }
    public void PrjCodeChangeLog(string changeDesc,string windowName, string NewprjCode,string oldPrjCode)
    {
        if (txtPrjCode.Text != "")
        {
            string upDateQuery = "INSERT INTO CHANGELOG(ChangeData,windowName,newData,oldData,updateUser) VALUES('" + changeDesc + "','" + windowName + "','" + NewprjCode + "','" + oldPrjCode + "', '" + Session["UserDisplayName"].ToString() + "')";
            SqlConnection sqlCon = new SqlConnection(connValue);
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = upDateQuery;
            cmd.Connection = sqlCon;
            try
            {
                sqlCon.Open();
                cmd.ExecuteNonQuery();
                sqlCon.Close();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }

    public void DeleteDistributionForJobIncharge(int docID)
    {
        string upDateQuery = "DELETE FROM DOCUMENTDISTRIBUTION WHERE documentID = @docID and JobOwnerID is not null";

        SqlConnection sqlCon = new SqlConnection(connValue);
        SqlCommand cmd = new SqlCommand();
        cmd.CommandText = upDateQuery;
        cmd.Connection = sqlCon;

        cmd.Parameters.AddWithValue("@docID", docID); 

        try
        {
            sqlCon.Open();
            cmd.ExecuteNonQuery();
            sqlCon.Close();
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    protected void btnBack_Click(object sender, EventArgs e)
    {
        if (Session["UrlRef"] != null)
            Response.Redirect(Session["UrlRef"].ToString(), false);
        else
            Response.Redirect("~/JobOrder/JobOrder.aspx", false);
    }
    protected void gridReceived_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            LinkButton lnkRef = (LinkButton)e.Row.FindControl("lnkRec");
            Label txtDocType = (Label)e.Row.FindControl("RectxtDocType");
            Label txtDate = (Label)e.Row.FindControl("RectxtDate");
            TextBox txtDocID = (TextBox)e.Row.FindControl("RectxtDocID");
            Label lblOpenRef = (Label)e.Row.FindControl("ReclblOpenDocRef");
            Label lblCloseRef = (Label)e.Row.FindControl("ReclblClosedDocRef");
            Control ctrlReceiveCreateUser = e.Row.FindControl("divRecCreateUserID");
            Control ctrlReceiveOriginContactID = e.Row.FindControl("divRecOriginContactID");
           
            Control ctrlSuperseded = e.Row.FindControl("divRecSuperseded");

            Label lblSuperseded = (Label)e.Row.FindControl("lblSuperseded");
            HtmlGenericControl htmlCtrlSuperseded = ctrlSuperseded as HtmlGenericControl;
            HtmlGenericControl htmlCtrlctrlReceiveOriginContactID = ctrlReceiveOriginContactID as HtmlGenericControl;
            HtmlGenericControl htmlCtrlReceiveCreateUser = ctrlReceiveCreateUser as HtmlGenericControl;

            string strDocID = txtDocID.Text;
            string strOpenRef = lblOpenRef.Text;
            string strCloesdRef = lblCloseRef.Text;

            LinkButton lnkView = (LinkButton)e.Row.FindControl("RecbtnDelete");
            if (lblSuperseded.Text.Equals("True"))
            {
               
                e.Row.Cells[3].BackColor = System.Drawing.Color.WhiteSmoke;
                e.Row.Cells[3].ForeColor = System.Drawing.Color.Gray;

                e.Row.Cells[4].BackColor = System.Drawing.Color.WhiteSmoke;
                e.Row.Cells[4].ForeColor = System.Drawing.Color.Gray;

                // for superseeded
                if (htmlCtrlReceiveCreateUser.InnerText.Equals(Session["UserID"].ToString()) || htmlCtrlctrlReceiveOriginContactID.InnerText.Equals(Session["UserID"].ToString()) || Session["UserProfileID"].ToString().Equals("1"))
                {
                    if (lnkRef != null)
                    {
                        lnkRef.Enabled = true;
                        lnkRef.Font.Underline = true;
                    }
                }
                else
                {
                    lnkRef.Enabled = false;
                    lnkRef.Font.Underline = false;
                    lnkRef.ForeColor = System.Drawing.Color.Gray;

                    e.Row.Cells[2].BackColor = System.Drawing.Color.WhiteSmoke;
                    e.Row.Cells[2].ForeColor = System.Drawing.Color.Black;
                }
            }

            if (strDocID.Equals(strOpenRef) || (strDocID.Equals(strCloesdRef)))
            {
                lnkView.ForeColor = System.Drawing.Color.White;
            }
            else
            {
                lnkView.Attributes.Add("onclick", "javascript:return " + "confirm('This will delete this document from this Job Order.')");
                lnkView.CssClass = "RecbtnDelete";
            }

            Session["DocDelete"] = "1";
        }        
    }
    protected void btnReply_Click(object sender, EventArgs e)
    {
        //string strUpdateJob = Request.Url.AbsoluteUri;
        //Session["UrlRef"] = strUpdateJob;
        CloseJob();
    }
    private void CloseJob()
    {
        AccessRightsForReply();
        if ((checkJobStatusCompleteDate(_jobID) == "") & (!userRightsColl.Contains("9")))
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('The Job Order not yet completed. Please update the Job Status before closing the Job.')</script>", false);
            return;
        }
        ReplytoCloseCommittedJobs(_jobID);
    }
    private string checkJobStatusCompleteDate(int _jobID)
    {
        string jobStatusClosedDate = string.Empty;
        SqlConnection sqlConn = new SqlConnection(connValue);
        string sqlQuery = "SELECT jobStatusClosedDate From Job Where jobID = '" + _jobID + "' ";

        try
        {
            sqlConn.Open();
            SqlCommand sqlCom = new SqlCommand(sqlQuery, sqlConn);
            SqlDataReader sqlReader = sqlCom.ExecuteReader();
            while (sqlReader.Read())
            {
                jobStatusClosedDate = sqlReader["jobStatusClosedDate"].ToString();
            }
            sqlReader.Close();
        }
        catch (Exception ex)
        {
            Response.Write("Error getting while reading data !" + ex.Message);
        }
        finally
        {
            sqlConn.Close();
        }
        return jobStatusClosedDate;
    }
    private void ReplytoCloseCommittedJobs(int jobid)
    {
        if (userRightsColl.Contains("9"))   //Add New Document
        {
            Session["lblText"] = "You are not allowed to directly Reply and Close a Job Order.Please contact system Administrator for further inquiry.";
            Session["lblSub"] = "Restricted Access to Reply and Close a Job Order.";
            Session["lblBody"] = "This is in reference to Restricted Access to Reply and Close a Job Order. I would like to inquire about the restriction.";

            string url = "RestrictedMsgWindow.aspx";
            string s = "window.open('" + url + "', 'popup_window', 'width=500,height=250,left=100,top=100,resizable=yes,scrollbars=yes');";
            ClientScript.RegisterStartupScript(this.GetType(), "script", s, true);
        }
        else
        {
            if (getJobStatusClosingDate())      //if (Convert.ToBoolean(getJobStatusClosingDate)==true)
            {
                Session["UrlRef"] = "~/JobOrder/JobOrder.aspx";
                Session["JobID"] = jobid;
                Response.Redirect("~/Documents/DocumentDetailsWindow.aspx?RecSentCatID=2&Reply=1", false);
            }
            else
            {
                ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('The job order is not yet completed. Please update the Job Order Status before closing the job.')</script>", false);
            }
        }
    }
    private Boolean getJobStatusClosingDate()
    {
        //jobStatusClosedDate

        return true;
    }
    
    private void AccessRightsForReply()
    {
        if (userRightsColl.Contains("9"))   //Add New Project
        {
            Session["lblText"] = "You are not allowed to directly Reply and Close a Job Order.Please contact system Administrator for further inquiry.";
            Session["lblSub"] = "Restricted Access to Reply and Close a Job Order.";
            Session["lblBody"] = "This is in reference to Restricted Access to Reply and Close a Job Order. I would like to inquire about the restriction.";


            string url = "RestrictedMsgWindow.aspx";
            string s = "window.open('" + url + "', 'popup_window', 'width=500,height=250,left=100,top=100,resizable=yes,scrollbars=yes');";
            ClientScript.RegisterStartupScript(this.GetType(), "script", s, true);
        }

        return;
    }
    protected void gvDistribution_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            DropDownList l = (DropDownList)e.Row.FindControl("ddljobtype0");

            PopulateDropDownBox(l, "SELECT JobStatusid,JobStatusName as JobStatus FROM jobStatus where JobStatusid in(1,2,3,4) ", "JobStatusid", "JobStatus");  // where JobStatusid in(5,6,7,8)

            TextBox lm = (TextBox)e.Row.FindControl("jobid");
            TextBox afr = (TextBox)e.Row.FindControl("TextBox1");
            TextBox InchargeID = (TextBox)e.Row.FindControl("txtInchargeID");

            Session["InchargeID"] = InchargeID.Text;

            string lk = lm.Text;
            l.ToolTip = InchargeID.Text;

            l.SelectedValue = afr.Text;

            Session["StatusVal"] = l.SelectedValue;

            l.SelectedIndexChanged += new EventHandler(SelectedIndexChanged);

            TextBox txtdate = (TextBox)e.Row.FindControl("lblJoindate");            // ActionDueDate 
            txtdate.ToolTip = InchargeID.Text;
            txtdate.TextChanged += new EventHandler(txtdate_TextChanged);
            Session["JobActionDueDate"] = txtdate.Text;

            CheckBox chkstate = (CheckBox)e.Row.FindControl("ad");
            chkstate.ToolTip = InchargeID.Text;
            chkstate.CheckedChanged += new EventHandler(chkstate_CheckedChanged);

            Label lblStaff = (Label)e.Row.FindControl("txtStaff");
            Label lblDistributedBy = (Label)e.Row.FindControl("txtDistrubed");

            CheckBox chkDelete = (CheckBox)e.Row.FindControl("deleteRow");
            chkDelete.ToolTip = InchargeID.Text;

            Label lblConactID = (Label)e.Row.FindControl("txtCnctID");
            TextBox _txtDocID = (TextBox)e.Row.FindControl("txtDocID");
            Session["statusdocID"] = _txtDocID.Text;
            Session["contactID"] = lblConactID.Text;

            Label lblDistribID = (Label)e.Row.FindControl("txtDistributedBy");

            //Label lblRoleID = (Label)e.Row.FindControl("txtRoleID");
            // chkDelete.CheckedChanged += new EventHandler(chkstate_CheckedChanged);                        

            if (!lblConactID.Text.Equals(Session["userID"]))
            {
                l.Enabled = false;
                chkstate.Enabled = false;
                // txtdate.Enabled = false;
            }
            if (lblConactID.Text.Equals(Session["userID"]))
            {
                btnOutlook.Enabled = true;
                Session["ActionDate"] = txtdate.Text;
            }
            if (!lblDistribID.Text.Equals(Session["userID"]))
            {
                txtdate.Enabled = false;
            }
            Label lblIsActive = (Label)e.Row.FindControl("txtisActive");    //txtDistisActive
            if (lblIsActive.Text.Equals("False"))
            {
                HyperLink _lnkStaff = (HyperLink)e.Row.FindControl("lnkStaff"); //
                HyperLink _lnkDistribStaff = (HyperLink)e.Row.FindControl("DistibActive");
                _lnkStaff.Enabled = false;
                //_lnkDistribStaff.Enabled = false;
            }
            Label lblDistIsActive = (Label)e.Row.FindControl("txtDistisActive");
            if (lblDistIsActive.Text.Equals("False"))
            {
                HyperLink _lnkDistribStaff = (HyperLink)e.Row.FindControl("lnkDistirbStaff");
                _lnkDistribStaff.Enabled = false;
            }


            //if (Session["userIsActive"].Equals("True"))
            //{
            //    lblStaff.Enabled = false;
            //}           
        }
    }
    protected void gvDistribution_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandArgument != "")
        {
            int distributeID = Convert.ToInt32(e.CommandArgument);
            switch (e.CommandName)
            {
                case "DeleteDocid":

                    //DeleteDistributionInfo(distributeID);
                    if (flag > 0)
                    {
                        //Response.Write("Link Deactivated with Job");
                    }
                    break;
            }
        }
    }
    protected void gvJoborder_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        //if (e.CommandName == "DeleteJobOwner")
        //{
        //     if (userRightsColl.Contains("4"))   
        //     {
        //         ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('You have no access rights to delete staff incharge.')</script>", false);
        //         return;
        //     }

        //    string arguments = e.CommandArgument.ToString();
        //    string[] args = arguments.Split(';');

        //    IList<string> staffData = new List<string>();
        //    int roleID = gertRoleID(Convert.ToInt32(args[0]));
        //    int inchargeID = Convert.ToInt32(args[0]);
        //    staffData = getStaffID(_jobID, roleID, inchargeID);

        //    new JobOrderData().DeleteIncharge(inchargeID);

        //    gvJoborder.DataSource = new JobOrderData().GetJobOwnerDetails(_jobID);
        //    gvJoborder.DataBind();

                     

        //    if (staffData.Count() > 0)
        //        new JobOrderData().UpdateQSIDStatus(Convert.ToInt32(staffData[0]), _jobID, Convert.ToInt32(staffData[1]));
        //    else
        //        new JobOrderData().UpdateQSIDStatusNull(roleID, _jobID, inchargeID);

        //    //else
        //    //    new JobOrderData().UpdateQSIDStatus(gertRoleID(Convert.ToInt32(args[0])), _jobID);   // In Job With RoleID like QS      


        //    Fill_JobOrder_Information(_jobID);

        //}
        if (e.CommandName.Equals("SelectStaff"))
        {
            //if (userRightsColl.Contains("4"))
            //{
            //    ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('You have no access rights to delete staff incharge.')</script>", false);
            //    return;
            //}

            string arguments = e.CommandArgument.ToString();
            string[] args = arguments.Split(';');

            IList<string> staffData = new List<string>();
            int roleID = gertRoleID(Convert.ToInt32(args[0]));
            int inchargeID = Convert.ToInt32(args[0]);

            //if (userRightsColl.Contains("4")) // Access Right is 4 
            //{
            //    Session["lblText"] = "You are not allowed to Update Job Incharge.Please contact system Administrator for further inquiry.";
            //    Session["lblSub"] = "Restricted Access to Update Job Incharge Job Order.";
            //    Session["lblBody"] = "This is in reference to Restricted Access to Add New Job Order. I would like to inquire about the restriction.";

            //    string url = "RestrictedMsgWindow.aspx";
            //    string s = "window.open('" + url + "', 'popup_window', 'width=500,height=250,left=100,top=100,resizable=yes,scrollbars=yes');";
            //    ClientScript.RegisterStartupScript(this.GetType(), "script", s, true);

            //    //ClientScript.RegisterClientScriptBlock(this.GetType(), "Popup", "<script>alert('You have no privilege to add this Staff')</script>", false);
            //    //return;
            //}
            //else
            {
                Session["jobNo"] = txtJobNo.Text;
                string url = "AddStaff.aspx?InchargeID=" + inchargeID;
                string s = "window.open('" + url + "', 'popup_window', 'width=700,height=500,left=100,top=100,resizable=yes');";
                Page.ClientScript.RegisterStartupScript(this.GetType(), "script", s, true);
            }
        }
    }
    private int gertRoleID(int inchargeID)
    {
        int roleID = 0;
        using (SqlConnection cn = new SqlConnection(connValue))
        {
            using (SqlCommand cmd = new SqlCommand())
            {
                cmd.Connection = cn;
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "Select StaffRoleID from JobOwner where jobOwnerID =" + inchargeID;

                cn.Open();
               //int roleID = (int)cmd.ExecuteScalar();
                using (SqlDataReader dr = cmd.ExecuteReader())
                {
                    if (dr.HasRows)
                    {
                        while (dr.Read())
                        {
                            roleID = Convert.ToInt32(dr["StaffRoleID"]);
                        }
                    }
                    else
                    {
                        roleID = 0;
                    }
                }
            }
        }
        return roleID;
    }

    protected void btnDelete_Click1(object sender, EventArgs e)
    {

    }
    //private void deleteJobOwner()
    //{
    //    int jobOwnerID = 0;
    //    GridView gridTemp = sender as GridView;
    //    if (userRightsColl.Contains("4"))   //Add New Project
    //    {
    //        ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('You have no access rights to delete staff incharge.')</script>", false);
    //        return;
    //    }
    //    else
    //    {
    //        int z = 0;
    //        foreach (GridViewRow x in gvJoborder.Rows)
    //        {
    //            CheckBox chk = (CheckBox)x.FindControl("deleteRow");
    //            if (chk.Checked == true)
    //            {
    //                z = z + 1;
    //            }
    //        }
    //        if (z == 1)
    //        {
    //            foreach (GridViewRow x in gvJoborder.Rows)
    //            {
    //                CheckBox chk = (CheckBox)x.FindControl("deleteRow");
    //                //Label _lbljobID = (Label)x.FindControl("lblJobID");
    //                TextBox InchargeID = (TextBox)x.FindControl("txtInchargeID");
    //                jobOwnerID = Convert.ToInt32(InchargeID.Text);
    //                Label roleID = (Label)x.FindControl("txtRoleID");

    //                if (chk.Checked == true)
    //                {
    //                    new JobOrderData().DeleteIncharge(jobOwnerID);
    //                    new JobOrderData().DeleteInchargeFromDistribution(jobOwnerID);

    //                    // Need roleID from Incharge    ex : 1 or 2 or 3

    //                    // Check Some StaffID with Same Role in Incharge Table 

    //                    // If get --------- Update RoleID and StaffID In Job Table 



    //                    int _roleID = Convert.ToInt32(roleID.Text);

    //                    //new JobOrderData().UpdateQSIDStatus(_staffID, _jobID);   // In Job With RoleID like QS
    //                    IList<string> staffData = new List<string>();

    //                    //if (staffID.Text)
    //                    staffData = getStaffID(_jobID, _roleID);

    //                    if (staffData.Count() > 0)
    //                        new JobOrderData().UpdateQSIDStatus(Convert.ToInt32(staffData[0]), _jobID, Convert.ToInt32(staffData[1]));
    //                    else
    //                        new JobOrderData().UpdateQSIDStatus(_roleID, _jobID);   // In Job With RoleID like QS

    //                    Fill_JobOrder_Information(_jobID);

    //                }
    //            }
    //            fillData(_jobID);
    //        }
    //        else
    //        {
    //            ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Please select checkBox for Delete Staff')</script>", false);
    //        }
    //    }
    //}

    //public void DeleteDistributionForJobIncharge(int docID)
    //{
    //    string upDateQuery = "UPDATE JOB SET QSID";

    //    SqlConnection sqlCon = new SqlConnection(connValue);
    //    SqlCommand cmd = new SqlCommand();
    //    cmd.CommandText = upDateQuery;
    //    cmd.Connection = sqlCon;

    //    cmd.Parameters.AddWithValue("@docID", docID);

    //    try
    //    {
    //        sqlCon.Open();
    //        cmd.ExecuteNonQuery();
    //        sqlCon.Close();
    //    }
    //    catch (Exception ex)
    //    {
    //        throw ex;
    //    }
    //}
    protected void lnkVodata_Click(object sender, EventArgs e)
    {
        //Session["voJobID"] = _jobID;

        //string url = "PSALog.aspx";
        //string s = "window.open('" + url + "', 'popup_window', 'width=1100,height=450,left=100,top=100,resizable=yes,scrollbars=yes');";
        //ClientScript.RegisterStartupScript(this.GetType(), "script", s, true);   

    }

    protected void btnSearchJob_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/JobOrder/SearchJobMstr.aspx", false);
    }



}