﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Text.RegularExpressions;
using System.IO;
using Microsoft.Office.Interop.Word;
using System.Runtime.InteropServices;
using System.Reflection;
using System.Drawing;




public partial class CreateTable : System.Web.UI.Page
{
    string connValue = System.Configuration.ConfigurationManager.ConnectionStrings["EBSDEBookConn"].ConnectionString;
  
    protected void Page_Load(object sender, EventArgs e)
    {
        //if (!Page.IsPostBack)
        //{
        //    fillData();
        //    fillCheckedData();
        //    numOfRows = lsttxtColl.Count();
        //    GenerateTable(numOfRows);
        //}

       // Session["AddPayID"];
    }
    int chkListType = 0;
    protected void Page_Init(object sender, EventArgs e)
    {
        if (Session["ChkListPayID"] != null)
            _payID = Convert.ToInt32(Session["ChkListPayID"]);
        else
            return;

           if (Session["PayTypeChk"].ToString().Equals("1") && Session["PayForChk"].ToString().Equals("3"))
                chkListType = 1;

            else if (Session["PayTypeChk"].ToString().Equals("2") && Session["PayForChk"].ToString().Equals("4"))
                chkListType = 2;

            else if (Session["PayTypeChk"].ToString().Equals("1") && Session["PayForChk"].ToString().Equals("2"))
                chkListType = 3;

            else if (Session["PayTypeChk"].ToString().Equals("1") && Session["PayForChk"].ToString().Equals("1"))
                chkListType = 4;

            else if (Session["PayTypeChk"].ToString().Equals("2") && Session["PayForChk"].ToString().Equals("1"))
                chkListType = 5;

            else if (Session["PayTypeChk"].ToString().Equals("4") && Session["PayForChk"].ToString().Equals("1"))
                chkListType = 6;

            else if (Session["PayTypeChk"].ToString().Equals("5") && Session["PayForChk"].ToString().Equals("1"))
                chkListType = 7;

            else if (Session["PayTypeChk"].ToString().Equals("2") && Session["PayForChk"].ToString().Equals("3"))
                chkListType = 8;

            else if (Session["PayTypeChk"].ToString().Equals("2") && Session["PayForChk"].ToString().Equals("4"))
                chkListType = 9;

            else if (Session["PayTypeChk"].ToString().Equals("5") && Session["PayForChk"].ToString().Equals("3"))
                chkListType = 10;

            else if (Session["PayTypeChk"].ToString().Equals("5") && Session["PayForChk"].ToString().Equals("4"))
                chkListType = 11;

            lblPayType.Text = chkListType.ToString();

            fillData(chkListType);
            fillCheckedData();
            numOfRows = lsttxtColl.Count();
            GenerateTable(numOfRows);
            getPaySummaryData();

    }
    IList<string> lsttxtColl = new List<string>();
    IList<Boolean> lstChkBoxColl = new List<Boolean>();
    private int numOfRows = 0;
    private int _payID = 0;
    private IList<Boolean> fillCheckedData()
    {

        string sqlQuery = " SELECT check1, check2, check3, check4, check5, check6, check7, check8, check9, check10, check11, check12, check13, check14, check15, check16, check17, check18  from payCheckList where payID =" + _payID + "";

        using (SqlConnection objCon = new SqlConnection(connValue))
        {
            objCon.Open();
            SqlCommand objCmd = new SqlCommand(sqlQuery, objCon);
            using (SqlDataReader dr = objCmd.ExecuteReader())
            {
                while (dr.Read())
                {
                    lstChkBoxColl.Add(Convert.ToBoolean(dr["check1"].ToString()));
                    lstChkBoxColl.Add(Convert.ToBoolean(dr["check2"].ToString()));
                    lstChkBoxColl.Add(Convert.ToBoolean(dr["check3"].ToString()));
                    lstChkBoxColl.Add(Convert.ToBoolean(dr["check4"].ToString()));
                    lstChkBoxColl.Add(Convert.ToBoolean(dr["check5"].ToString()));
                    lstChkBoxColl.Add(Convert.ToBoolean(dr["check6"].ToString()));
                    lstChkBoxColl.Add(Convert.ToBoolean(dr["check7"].ToString()));
                    lstChkBoxColl.Add(Convert.ToBoolean(dr["check8"].ToString()));
                    lstChkBoxColl.Add(Convert.ToBoolean(dr["check9"].ToString()));
                    lstChkBoxColl.Add(Convert.ToBoolean(dr["check10"].ToString()));
                    lstChkBoxColl.Add(Convert.ToBoolean(dr["check11"].ToString()));
                    lstChkBoxColl.Add(Convert.ToBoolean(dr["check12"].ToString()));
                    lstChkBoxColl.Add(Convert.ToBoolean(dr["check13"].ToString()));
                    lstChkBoxColl.Add(Convert.ToBoolean(dr["check14"].ToString()));
                    lstChkBoxColl.Add(Convert.ToBoolean(dr["check15"].ToString()));
                    lstChkBoxColl.Add(Convert.ToBoolean(dr["check16"].ToString()));
                    lstChkBoxColl.Add(Convert.ToBoolean(dr["check17"].ToString()));
                    lstChkBoxColl.Add(Convert.ToBoolean(dr["check18"].ToString()));
                }
            }
        }

        return lstChkBoxColl;
    }
    private void getPaySummaryData()
    {
        string sqlQuery = " SELECT  Payment.commitmentNo, Payment.contractor, Payment.deptID, Payment.applicationNo, Payment.projectManager, Department.deptName " + 
                      " FROM   Payment INNER JOIN  Department ON Payment.deptID = Department.departmentID WHERE  Payment.payID  = " + _payID + "";
        using (SqlConnection objCon = new SqlConnection(connValue))
        {
            try
            {
                objCon.Open();
                using (SqlCommand objCmd = new SqlCommand(sqlQuery, objCon))
                {
                    using (SqlDataReader dr = objCmd.ExecuteReader())
                    {
                        while (dr.Read())
                        {
                            lblCommtment.Text = dr["commitmentNo"].ToString();
                            lblCntr.Text = dr["contractor"].ToString();
                            lblDept.Text = dr["deptName"].ToString();
                            lblRPno.Text = dr["applicationNo"].ToString();
                            txtPrjMngr.Text = dr["projectManager"].ToString();
                        }
                    }
                }
            }
            catch (Exception ex)
            {                
                throw ex;
            }            
        }
    }
    private IList<string> fillData(int chkListTypeID)
    {

        string sqlQuery = " SELECT CheckNo, CheckList  from payCheckListData where listTypID = " + chkListTypeID + "";

        using (SqlConnection objCon = new SqlConnection(connValue))
        {
            objCon.Open();
            SqlCommand objCmd = new SqlCommand(sqlQuery, objCon);
            using (SqlDataReader dr = objCmd.ExecuteReader())
            {
                while (dr.Read())
                {
                    lsttxtColl.Add(dr["CheckList"].ToString());
                }
            }
        }

        return lsttxtColl;
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        if (ViewState["RowsCount"] != null)
        {
            numOfRows = Convert.ToInt32(ViewState["RowsCount"].ToString());
            GenerateTable(numOfRows);
        }
    }

    private void SetPreviousData(int rowsCount, int colsCount)
    {
        System.Web.UI.WebControls.Table table = (System.Web.UI.WebControls.Table)Page.FindControl("Table1");
        if (table != null)
        {
            for (int i = 0; i < rowsCount; i++)
            {
                for (int j = 0; j < colsCount; j++)
                {
                    if (j==0)
                    {
                        TextBox tb = (TextBox)table.Rows[i].Cells[j].FindControl("TextBoxRow_" + i + "Col_" + j);
                         tb.Text = Request.Form["TextBoxRow_" + i + "Col_" + j];
                    }
                    else if (j == 1)
                    {
                        System.Web.UI.WebControls.CheckBox chk = (System.Web.UI.WebControls.CheckBox)table.Rows[i].Cells[j].FindControl("CheckBoxRow_" + i + "Col_2" + j);                        
                        chk.Text = Request.Form["CheckBoxRow_" + i + "Col_2" + j];
                    }                 
                   
                }
            }
        }
    }

    private void GenerateTable(int rowsCount)
    {

        //Creat the Table and Add it to the Page
        System.Web.UI.WebControls.Table table = new System.Web.UI.WebControls.Table();
        table.ID = "Table1";
        Page.Form.Controls.Add(table);

        TableRow rowHeader = new TableRow();
        TableCell cellHeader = new TableCell();
        cellHeader.Text = "Terms of Reference for Check";
        // cellHeader.Font =  Font.Bold;
        rowHeader.Cells.Add(cellHeader);
        table.Rows.Add(rowHeader);

        //The number of Columns to be generated
        const int colsCount = 2;//You can changed the value of 3 based on you requirements

        // Now iterate through the table and add your controls

        for (int i = 0; i < numOfRows; i++)
        {
            TableRow row = new TableRow();
            for (int j = 0; j < colsCount; j++)
            {
                if (j == 0)
                {
                    TableCell cell = new TableCell();
                    TextBox tb = new TextBox();
                    tb.Text = lsttxtColl[i].ToString();

                    tb.ID = "TextBoxRow_" + i + "Col_" + j;
                    tb.Width = 800;
                    // Add the control to the TableCell
                    cell.Controls.Add(tb);
                    // Add the TableCell to the TableRow
                    row.Cells.Add(cell);                    
                }
                else if (j == 1)
                {
                    TableCell cell2 = new TableCell();
                    System.Web.UI.WebControls.CheckBox chk = new System.Web.UI.WebControls.CheckBox();
                    chk.AutoPostBack = true;
                    chk.CheckedChanged += new EventHandler(chk_CheckedChanged);

                    //this.Labeldiv.Controls.Add(new LiteralControl("<span class='h1size'>"));
                    //this.Labeldiv.Controls.Add(NewLabel);
                    //this.Labeldiv.Controls.Add(new LiteralControl("</span>"));
                    //this.Labeldiv.Controls.Add(new LiteralControl("<div class='make-switch pull-right' data-on='info'>"));
                    //this.Labeldiv.Controls.Add(newcheck);
                    //this.Labeldiv.Controls.Add(new LiteralControl("</div>"));
                    //this.Labeldiv.Controls.Add(new LiteralControl("<br/>"));

                    chk.Checked = lstChkBoxColl[i];

                    //if (lstChkBoxColl[i].Equals("0"))
                    //   chk.Checked = false;
                    //else
                    //    chk.Checked = true;

                    chk.ID = "check" + (i + 1);
                    // Add the control to the TableCell
                    cell2.Controls.Add(chk);
                    // Add the TableCell to the TableRow

                   // CheckBox1_CheckedChanged
                    
                    row.Cells.Add(cell2);
                }

                // And finally, add the TableRow to the Table
                table.Rows.Add(row);
            }


            //Set Previous Data on PostBacks
          //  SetPreviousData(rowsCount, colsCount);

            //Sore the current Rows Count in ViewState
            rowsCount++;
            ViewState["RowsCount"] = rowsCount;
        }
    }
    protected void chk_CheckedChanged(object sender, EventArgs e)
    {
        
        System.Web.UI.WebControls.CheckBox currentCheckbox = sender as System.Web.UI.WebControls.CheckBox;
        string clmName = currentCheckbox.ID;
        updateWordData(clmName, currentCheckbox.Checked);
        string extractInteger = Regex.Match(currentCheckbox.ID, @"\d+").Value;
        //Label currentlabel = (Label)Labeldiv.FindControl("Label" + extractInteger);
    }
    private void updateWordData(string clmName, Boolean chkStat)
    {
        //string UpdateQuery = "Update payCheckList Set isChk ='" + chkStat + "' Where transID = " + privID + " ";

        string UpdateQuery = "Update payCheckList Set " + clmName + "  ='" + chkStat + "' Where payID = " + _payID + " ";
        SqlConnection con = new SqlConnection(connValue);
        con.Open();
        SqlCommand com = new SqlCommand(UpdateQuery, con);
        com.ExecuteNonQuery();
        con.Close();

        fillCheckedData();
    }
  
    //private void UpdatePaymentCheckList()
    //{
    //    foreach (CheckBox gridRow in gridChkList.Rows)
    //    {

    //        Boolean grvcheck1 = true;
    //        Boolean grvcheck2 = true;
    //        Boolean grvcheck3 = true;
    //        Boolean grvcheck4 = true;
    //        Boolean grvcheck5 = true;
    //        Boolean grvcheck6 = true;
    //        Boolean grvcheck7 = true;
    //        Boolean grvcheck8 = true;
    //        Boolean grvcheck9 = true;
    //        Boolean grvcheck10 = true;
    //        Boolean grvcheck11 = true;
    //        Boolean grvcheck12 = true;
    //        Boolean grvcheck13 = true;
    //        Boolean grvcheck14 = true;
    //        Boolean grvcheck15 = true;
    //        Boolean grvcheck16 = true;
    //        Boolean grvcheck17 = true;
    //        Boolean grvcheck18 = true;


    //        SqlConnection con = new SqlConnection(connValue);
    //        SqlCommand cmd = new SqlCommand();
    //        cmd.CommandType = CommandType.StoredProcedure;
    //        cmd.Connection = con;
    //        cmd.CommandText = "UpdatePayChkList";
    //        try
    //        {
    //            cmd.Parameters.AddWithValue("@payID", _payID);
    //            cmd.Parameters.AddWithValue("@check1", grvcheck1);
    //            cmd.Parameters.AddWithValue("@check2", grvcheck2);
    //            cmd.Parameters.AddWithValue("@check3", grvcheck3);
    //            cmd.Parameters.AddWithValue("@check4", grvcheck4);
    //            cmd.Parameters.AddWithValue("@check5", grvcheck5);
    //            cmd.Parameters.AddWithValue("@check6", grvcheck6);
    //            cmd.Parameters.AddWithValue("@check7", grvcheck7);
    //            cmd.Parameters.AddWithValue("@check8", grvcheck8);
    //            cmd.Parameters.AddWithValue("@check9", grvcheck9);
    //            cmd.Parameters.AddWithValue("@check10", grvcheck10);
    //            cmd.Parameters.AddWithValue("@check11", grvcheck11);
    //            cmd.Parameters.AddWithValue("@check12", grvcheck12);
    //            cmd.Parameters.AddWithValue("@check13", grvcheck13);
    //            cmd.Parameters.AddWithValue("@check14", grvcheck14);
    //            cmd.Parameters.AddWithValue("@check15", grvcheck15);
    //            cmd.Parameters.AddWithValue("@check16", grvcheck16);
    //            cmd.Parameters.AddWithValue("@check17", grvcheck17);
    //            cmd.Parameters.AddWithValue("@check18", grvcheck18);
    //        }
    //        catch (Exception ex)
    //        {

    //            throw ex;
    //        }

    //        try
    //        {
    //            con.Open();
    //            cmd.ExecuteNonQuery();
    //            con.Dispose();
    //        }
    //        catch (Exception ex)
    //        {

    //            throw ex;
    //        }
    //        finally
    //        {
    //            con.Close();
    //        }
    //    }
    //}
    protected void CheckBox1_CheckedChanged(object sender, EventArgs e)
    {

    }
  
    private void createDoc()
    {
        // Logo

        // Engineering Business Support Department 

        // Payment Control Check

        // INTERIM RP FOR CONTRACTOR


        // Commitment No  Department

        // Contractor Name      Project Manager


        // RP NO.
        
        // Terms of Reference for Check : -     checked

        object oMissing = System.Reflection.Missing.Value;
        object oEndOfDoc = "\\endofdoc"; /* \endofdoc is a predefined bookmark */

        //Start Word and create a new document.
        Microsoft.Office.Interop.Word._Application oWord;
        Microsoft.Office.Interop.Word._Document oDoc;
        oWord = new Microsoft.Office.Interop.Word.Application();
        oWord.Visible = true;

        oDoc = oWord.Documents.Add(ref oMissing, ref oMissing,
            ref oMissing, ref oMissing);

        //Insert a paragraph at the beginning of the document.

      //  selection.InlineShapes.AddPicture(@"C:\Desert.jpg");

        Microsoft.Office.Interop.Word.InlineShape oShape;
       // oShape = oDoc.Application.Selection.InlineShapes.AddPicture(@"C:\Desert.jpg");

       // oShape = oWord.Selection.InlineShapes.AddPicture(@"C:\Desert.jpg");
        
        

        Microsoft.Office.Interop.Word.Paragraph oPara1;
        oPara1 = oDoc.Content.Paragraphs.Add(ref oMissing);
        oPara1.Range.Text = "Commitment No : -";
        oPara1.Range.Font.Bold = 1;
        oPara1.Format.SpaceAfter = 24;    //24 pt spacing after paragraph.
        oPara1.Range.InsertParagraphAfter();

        //Insert a paragraph at the end of the document.
        Microsoft.Office.Interop.Word.Paragraph oPara2;
        object oRng = oDoc.Bookmarks.get_Item(ref oEndOfDoc).Range;
        oPara2 = oDoc.Content.Paragraphs.Add(ref oRng);
        oPara2.Range.Text = "Contractor Name : -";
        oPara2.Format.SpaceAfter = 6;
        oPara2.Range.InsertParagraphAfter();

      
        Microsoft.Office.Interop.Word.Table oTable;
        Microsoft.Office.Interop.Word.Range wrdRng = oDoc.Bookmarks.get_Item(ref oEndOfDoc).Range;
       // oTable = oDoc.Tables.Add(wrdRng, 30, 5, ref oMissing, ref oMissing);

        
        int r, c;
        string strText; string strChk;  


        //Add some text after the table.
        Microsoft.Office.Interop.Word.Paragraph oPara4;
        oRng = oDoc.Bookmarks.get_Item(ref oEndOfDoc).Range;
        oPara4 = oDoc.Content.Paragraphs.Add(ref oRng);
        oPara4.Range.InsertParagraphBefore();
        oPara4.Range.Text = "Terms of Reference for Check : - ";
        oPara4.Format.SpaceAfter = 4;
        oPara4.Range.InsertParagraphAfter();

        //Insert a 5 x 2 table, fill it with data, and change the column widths.
        wrdRng = oDoc.Bookmarks.get_Item(ref oEndOfDoc).Range;
        oTable = oDoc.Tables.Add (wrdRng, 10, 6, ref oMissing, ref oMissing);
        oTable.Range.ParagraphFormat.SpaceAfter =10;
        for (r = 1; r <= 10; r++)
            for (c = 1; c <= 2; c++)
            {
                if (c == 1)
                {
                    strText = lsttxtColl[r];
                    oTable.Cell(r, c).Range.Text = strText;
                }
                else
                {
                    Boolean chkVal = lstChkBoxColl[r] ;
                    oTable.Cell(r, c).Range.Text = "[ " + chkVal.ToString() + " ]";
                   
                    //else
                    //{
                    //    //object Font = "Wingdings";
                    //    //object Unicode = Type.Missing;
                    //    //object Bias = Type.Missing;
                    //    //wrdRng.InsertSymbol(253, ref Font, ref Unicode, ref Bias);
                    //    if ()
                    //    strText = "[ True ]";
                    //    oTable.Cell(r, c).Range.Text = strText;
                    //}
                }
            }

        oTable.Columns[1].Width = oWord.InchesToPoints(6); //Change width of columns 1 & 2
        oTable.Columns[2].Width = oWord.InchesToPoints(1);


        //Microsoft.Office.Interop.Word.Application WordApp = null;
        //Microsoft.Office.Interop.Word.Document doc = null;
        //Microsoft.Office.Interop.Word.Bookmarks bookmarks = null;
        //Microsoft.Office.Interop.Word.Bookmark myBookmark = null;
       // Microsoft.Office.Interop.Word.Range bookmarkRange = null;

        object LinkToFile = true;
        object SaveWithDocument = false;
        object bookmarkRange = null;

         object Left = 10; 
         object Top =20; 
         object Width = 30; 
         object Height = 40;
         object Anchor =null;


        Microsoft.Office.Interop.Word.Selection selection = null;
        selection = oWord.Selection;

        float leftPosition = (float)selection.Information[WdInformation.wdHorizontalPositionRelativeToPage];
        float topPosition = (float)selection.Information[WdInformation.wdVerticalPositionRelativeToPage];
        
       // selection.InlineShapes.AddPicture(@"C:\Desert.jpg", ref LinkToFile, ref SaveWithDocument, oMissing);   

        // oWord.ActiveDocument.Shapes.AddPicture ( (Microsoft.Office.MsoPresetTextEffect.msoTextEffect29, "SampleText", "Arial Black", 24, Office.MsoTriState.msoFalse, Office.MsoTriState.msoFalse, leftPosition, topPosition);

         // this.Application.ActiveDocument.Shapes.AddTextEffect(Office.MsoPresetTextEffect.msoTextEffect29, "SampleText", "Arial Black", 24, Office.MsoTriState.msoFalse, Office.MsoTriState.msoFalse, leftPosition, topPosition);       


        //Close this form.
         
        //this.Close();
    }


    private void createDocTemp()
    {
        object oMissing = System.Reflection.Missing.Value;
        object oEndOfDoc = "\\endofdoc"; /* \endofdoc is a predefined bookmark */

        //Start Word and create a new document.
        Microsoft.Office.Interop.Word._Application oWord;
        Microsoft.Office.Interop.Word._Document oDoc;
        oWord = new Microsoft.Office.Interop.Word.Application();
        oWord.Visible = true;
        oDoc = oWord.Documents.Add(ref oMissing, ref oMissing,
            ref oMissing, ref oMissing);

        //Insert a paragraph at the beginning of the document.
        Microsoft.Office.Interop.Word.Paragraph oPara1;
        oPara1 = oDoc.Content.Paragraphs.Add(ref oMissing);
        oPara1.Range.Text = "Commitment No : -";
        oPara1.Range.Font.Bold = 1;
        oPara1.Format.SpaceAfter = 24;    //24 pt spacing after paragraph.
        oPara1.Range.InsertParagraphAfter();

        //Insert a paragraph at the end of the document.
        Microsoft.Office.Interop.Word.Paragraph oPara2;
        object oRng = oDoc.Bookmarks.get_Item(ref oEndOfDoc).Range;
        oPara2 = oDoc.Content.Paragraphs.Add(ref oRng);
        oPara2.Range.Text = "Contractor Name : -";
        oPara2.Format.SpaceAfter = 6;
        oPara2.Range.InsertParagraphAfter();

        //Insert another paragraph.
        Microsoft.Office.Interop.Word.Paragraph oPara3;
        oRng = oDoc.Bookmarks.get_Item(ref oEndOfDoc).Range;
        oPara3 = oDoc.Content.Paragraphs.Add(ref oRng);
        oPara3.Range.Text = "Terms of Reference for Check";
        oPara3.Range.Font.Bold = 0;
        oPara3.Format.SpaceAfter = 14;
        oPara3.Range.InsertParagraphAfter();

        //Insert a 3 x 5 table, fill it with data, and make the first row
        //bold and italic.
        Microsoft.Office.Interop.Word.Table oTable;
        Microsoft.Office.Interop.Word.Range wrdRng = oDoc.Bookmarks.get_Item(ref oEndOfDoc).Range;
        // oTable = oDoc.Tables.Add(wrdRng, 30, 5, ref oMissing, ref oMissing);

        oTable = oDoc.Tables.Add(wrdRng, 11, 2, ref oMissing, ref oMissing);
        oTable.Range.ParagraphFormat.SpaceAfter = 16;
        int r, c;
        string strText;
        for (r = 0; r < lsttxtColl.Count - 1; r++)
            for (c = 0; c < 1; c++)
            {
                strText = lsttxtColl[r];
                oTable.Cell(r, c).Range.Text = strText;
            }
        oTable.Rows[1].Range.Font.Bold = 1;
        oTable.Rows[1].Range.Font.Italic = 1;

        //Add some text after the table.
        Microsoft.Office.Interop.Word.Paragraph oPara4;
        oRng = oDoc.Bookmarks.get_Item(ref oEndOfDoc).Range;
        oPara4 = oDoc.Content.Paragraphs.Add(ref oRng);
        oPara4.Range.InsertParagraphBefore();
        oPara4.Range.Text = "And here's another table -2:";
        oPara4.Format.SpaceAfter = 24;
        oPara4.Range.InsertParagraphAfter();

        //Insert a 5 x 2 table, fill it with data, and change the column widths.
        wrdRng = oDoc.Bookmarks.get_Item(ref oEndOfDoc).Range;
        oTable = oDoc.Tables.Add(wrdRng, 5, 2, ref oMissing, ref oMissing);
        oTable.Range.ParagraphFormat.SpaceAfter = 6;
        for (r = 1; r <= 5; r++)
            for (c = 1; c <= 2; c++)
            {
                strText = "r" + r + "c" + c;
                oTable.Cell(r, c).Range.Text = strText;
            }
        oTable.Columns[1].Width = oWord.InchesToPoints(2); //Change width of columns 1 & 2
        oTable.Columns[2].Width = oWord.InchesToPoints(3);

        //Keep inserting text. When you get to 7 inches from top of the
        //document, insert a hard page break.
        object oPos;
        double dPos = oWord.InchesToPoints(7);
        oDoc.Bookmarks.get_Item(ref oEndOfDoc).Range.InsertParagraphAfter();
        do
        {
            wrdRng = oDoc.Bookmarks.get_Item(ref oEndOfDoc).Range;
            wrdRng.ParagraphFormat.SpaceAfter = 6;
            wrdRng.InsertAfter("A line of text");
            wrdRng.InsertParagraphAfter();
            oPos = wrdRng.get_Information
                           (Microsoft.Office.Interop.Word.WdInformation.wdVerticalPositionRelativeToPage);
        }
        while (dPos >= Convert.ToDouble(oPos));


        object oCollapseEnd = Microsoft.Office.Interop.Word.WdCollapseDirection.wdCollapseEnd;
        object oPageBreak = Microsoft.Office.Interop.Word.WdBreakType.wdPageBreak;
        wrdRng.Collapse(ref oCollapseEnd);
        wrdRng.InsertBreak(ref oPageBreak);
        wrdRng.Collapse(ref oCollapseEnd);
        wrdRng.InsertAfter("We're now on page 2. Here's my chart:");
        wrdRng.InsertParagraphAfter();

        //Insert a chart.
        Microsoft.Office.Interop.Word.InlineShape oShape;
        object oClassType = "MSGraph.Chart.8";

        wrdRng = oDoc.Bookmarks.get_Item(ref oEndOfDoc).Range;

        oShape = wrdRng.InlineShapes.AddOLEObject(ref oClassType, ref oMissing,
            ref oMissing, ref oMissing, ref oMissing,
            ref oMissing, ref oMissing, ref oMissing);

        //Demonstrate use of late bound oChart and oChartApp objects to
        //manipulate the chart object with MSGraph.
        object oChart;
        object oChartApp;
        oChart = oShape.OLEFormat.Object;
        oChartApp = oChart.GetType().InvokeMember("Application",
            BindingFlags.GetProperty, null, oChart, null);

        //Change the chart type to Line.
        object[] Parameters = new Object[1];
        Parameters[0] = 4; //xlLine = 4
        oChart.GetType().InvokeMember("ChartType", BindingFlags.SetProperty,
            null, oChart, Parameters);

        //Update the chart image and quit MSGraph.
        oChartApp.GetType().InvokeMember("Update",
            BindingFlags.InvokeMethod, null, oChartApp, null);
        oChartApp.GetType().InvokeMember("Quit",
            BindingFlags.InvokeMethod, null, oChartApp, null);

        oShape.Width = oWord.InchesToPoints(6.25f);
        oShape.Height = oWord.InchesToPoints(3.57f);

        //Add text after the chart.
        wrdRng = oDoc.Bookmarks.get_Item(ref oEndOfDoc).Range;
        wrdRng.InsertParagraphAfter();




        //Close this form.


        //this.Close();
    }
	
    object start = 0;
    object end = 30; 
  
    protected void btnWord_Click(object sender, EventArgs e)
    {
       
    }
    public bool CloseWordApp()
    {
        bool isSuccess = false;
        if (_wordApplication != null)
        {
            object saveChanges = -1; // Save changes
            _wordApplication.Quit(saveChanges);
            _wordApplication = null;
            isSuccess = true;
        }
        return isSuccess;
    }
    private int GetCountFromRange(dynamic range, string word)
    {
        int count = 0;
        object missing = System.Reflection.Missing.Value;
        object matchAllWord = true;
        object item = 1; // Goto Page
        object whichItem = 1;// First page    
        _wordDoc.Goto(item, whichItem);
        dynamic find = range.Find;
        find.ClearFormatting();
        find.Forward = true;
        find.Text = word;
        find.MatchWholeWord = true;
        find.Execute();
        bool found = find.Found;
        while (found)
        {
            ++count;
            find.Execute();
            found = find.Found;
        }
        return count;
    }  
    dynamic _wordApplication = null;
    dynamic _wordDoc = null;
    public void CreateWordApplication()
    {
        string message = "Failed to create word application. Check whether"
                 + " word installation is correct.";
        Type wordType = Type.GetTypeFromProgID("Word.Application");
        if (wordType == null)
        {
            throw new Exception(message);
        }
        _wordApplication = Activator.CreateInstance(wordType);
        if (_wordApplication == null)
        {
            throw new Exception(message);
        }

        CreateWordDoc(@"D:\Doc12.docx", true);
    }  
    public void CreateWordDoc(object fileName, bool isReadonly)
    {
        
            object readOnly = false;
            object isVisible = true;
            object missing = System.Reflection.Missing.Value;
            // Open a given Word document.
            _wordDoc = _wordApplication.Documents.Open(fileName, missing,
                                isReadonly, missing, missing, missing,
                                missing, missing, missing, missing,
                                missing, isVisible);

            GetWordCount(@"D:\Doc12.docx");
        
    }
    public bool CloseWordDoc(bool canSaveChange)
    {
        bool isSuccess = false;
        if (_wordDoc != null)
        {
            object saveChanges = null;
            if (canSaveChange)
            {
                saveChanges = -1; // Save Changes
            }
            else
            {
                saveChanges = 0; // No changes
            }
            _wordDoc.Close(saveChanges);
            _wordDoc = null;
            isSuccess = true;
        }
        return isSuccess;
    }

    public int GetWordCount(string word)
    {
        object wordDoc = _wordDoc;
        int count = 0;
        do
        {
            if (_wordDoc == null)
            {
                break;
            }
            if (word.Trim().Length == 0)
            {
                break;
            }
            _wordDoc.Activate();
            dynamic content = _wordDoc.Content;
            // Get the count from direct text inside the document.
            count += GetCountFromRange(_wordDoc.Content, word);
            int rangeCount = _wordDoc.Comments.Count;
            for (int i = 1; i <= rangeCount; )
            {
                count += GetCountFromRange(_wordDoc.Comments.Item(i), word);
                break;
            }
            rangeCount = _wordDoc.Sections.Last.Headers.Count;
            for (int i = 1; i <= rangeCount; i++)
            {
                count += GetCountFromRange(
                _wordDoc.Sections.Last.Headers.Item(i).Range, word);
            }
            rangeCount = _wordDoc.Sections.Last.Footers.Count;
            for (int i = 1; i <= rangeCount; i++)
            {
                count += GetCountFromRange(
                _wordDoc.Sections.Last.Footers.Item(i).Range, word);
            }
            rangeCount = _wordDoc.Shapes.Count;
            for (int i = 1; i <= rangeCount; i++)
            {
                dynamic textFrame = _wordDoc.Shapes.Item(i).TextFrame;
                int hasText = textFrame.HasText;
                if (hasText < 0)
                {
                    count += GetCountFromRange(textFrame.TextRange, word);
                }
            }
        }
        while (false);
        return count;
    }


    protected void txtPrjMngr_TextChanged(object sender, EventArgs e)
    {
        UpdateProjectManager(_payID);
    }
    private void UpdateProjectManager(int payID)
    {
        string strQuery = "Update Payment Set projectManager = '" + txtPrjMngr.Text + "' Where payID = " + payID;
        using (SqlConnection cn = new SqlConnection(connValue))
        {
            cn.Open();
            using (SqlCommand cmd = new SqlCommand(strQuery,cn))
            {
                cmd.ExecuteNonQuery();
            }
        }
    }
    
    private void de()
    {
        Microsoft.Office.Interop.Word.Application wordApp = new Microsoft.Office.Interop.Word.Application();
        object fileName = @"D:\ListDocum.docx";
        object confirmConversions = Type.Missing; 
        object readOnly = Type.Missing; 
        object addToRecentFiles = Type.Missing; 
                object passwordDoc = Type.Missing; 
        object passwordTemplate = Type.Missing; 
        object revert = Type.Missing; 
        object writepwdoc = Type.Missing; 
        object writepwTemplate = Type.Missing; 
        object format = Type.Missing; 
        object encoding = Type.Missing; 
        object visible = Type.Missing; 
        object openRepair = Type.Missing; 
        object docDirection = Type.Missing; 
        object notEncoding = Type.Missing; 
        object xmlTransform = Type.Missing;

        Microsoft.Office.Interop.Word.Document doc = wordApp.Documents.Open(ref fileName, ref confirmConversions, ref readOnly, ref addToRecentFiles,
            ref passwordDoc, ref passwordTemplate, ref revert, ref writepwdoc,ref writepwTemplate, ref format, ref encoding, ref visible, ref openRepair,
            ref docDirection, ref notEncoding, ref xmlTransform); 


        string name = string.Empty;
        name = "txtRPNo";

        string text = string.Empty;

        text = "SaiRam";

        if (doc.Bookmarks.Exists(name))
        {
            Microsoft.Office.Interop.Word.Bookmark bm = doc.Bookmarks[name];
            Microsoft.Office.Interop.Word.Range range = bm.Range.Duplicate;

            doc.FormFields[name].Result = text;

         
        }

      

       

    }
    private void ReplaceBookmarkText(Microsoft.Office.Interop.Word.Document doc,string bookmarkName,string text)
    {
        if (doc.Bookmarks.Exists(bookmarkName))
        {

            Object name = bookmarkName;

            Microsoft.Office.Interop.Word.Range range =

            doc.Bookmarks.get_Item(ref name).Range;

            range.Text = text;

            object newRange = range;

            doc.Bookmarks.Add(bookmarkName, ref newRange);
        }       
    }
    private void OpenDoc()
    {
        Application ap = new Application();
        try
        {
            Document doc = ap.Documents.Open(@"D:\LstDoc.docx", ReadOnly: false, Visible: false);
            doc.Activate();
            Selection sel = ap.Selection;
            if (sel != null)
            {
                switch (sel.Type)
                {
                    case WdSelectionType.wdSelectionIP:
                        sel.TypeText(DateTime.Now.ToString());
                        sel.TypeParagraph();
                        break;

                    default:
                        Console.WriteLine("Selection type not handled; no writing done");
                        break;
                }
                // Remove all meta data.
                doc.RemoveDocumentInformation(WdRemoveDocInfoType.wdRDIAll);
                ap.Documents.Save(NoPrompt: true, OriginalFormat: true);
            }
            else
            {
                Console.WriteLine("Unable to acquire Selection...no writing to document done..");
            }
            ap.Documents.Close(SaveChanges: false, OriginalFormat: false, RouteDocument: false);
        }
        catch (Exception ex)
        {
            Console.WriteLine("Exception Caught: " + ex.Message); // Could be that the document is already open (/) or Word is in Memory(?)
        }
        finally
        {
            ((_Application)ap).Quit(SaveChanges: false, OriginalFormat: false, RouteDocument: false);
            System.Runtime.InteropServices.Marshal.ReleaseComObject(ap);
        }
    }

















    protected void Button1_Click1(object sender, EventArgs e)
    {
        string fileName = @"D:\ListDocum.docx";
        string saveAs = @"D:\ListDocum_New.docx";
        CreateWordDoc(fileName, saveAs);      
    }
    private void CreateWordDoc(Object fileName,object saveAs)
    {        
        object missing = System.Reflection.Missing.Value;
        Microsoft.Office.Interop.Word.Application wordApp = new Microsoft.Office.Interop.Word.ApplicationClass();
        Microsoft.Office.Interop.Word.Document aDoc = null;
        if (File.Exists((string)fileName))
        {
            object readOnly = false;         object isVisible = false;            wordApp.Visible = false;
            aDoc = wordApp.Documents.Open(ref fileName,ref missing,ref readOnly,ref missing,ref missing,ref missing,ref missing,ref missing,ref missing,ref missing,ref missing,ref isVisible,ref missing,ref missing,ref missing,ref missing);
            aDoc.Activate();       
           
            if (aDoc.Bookmarks.Exists("txtRPNo"))
            {
                Microsoft.Office.Interop.Word.Bookmark bm = aDoc.Bookmarks["txtRPNo"];
                Microsoft.Office.Interop.Word.Range range = bm.Range.Duplicate;
                aDoc.FormFields["txtRPNo"].Result = "SaiRam";              
            }
        }
        aDoc.SaveAs(ref saveAs,ref missing,ref missing,ref missing,ref missing,ref missing,ref missing,ref missing,ref missing,ref missing,ref missing,ref missing,ref missing,ref missing,ref missing,ref missing);
        aDoc.Close(ref missing,ref missing,ref missing);
     }



   // http://stackoverflow.com/questions/32695964/word-cannot-edit-range

















    private void CreateWordDocTemp(Object fileName, object saveAs)
    {
        object missing = System.Reflection.Missing.Value;
        Microsoft.Office.Interop.Word.Application wordApp = new Microsoft.Office.Interop.Word.ApplicationClass();
        Microsoft.Office.Interop.Word.Document aDoc = null;
        if (File.Exists((string)fileName))
        {
            DateTime today = DateTime.Now;
            object readOnly = false;
            object isVisible = false;
            wordApp.Visible = false;
            aDoc = wordApp.Documents.Open(ref fileName, ref missing, ref readOnly, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref isVisible, ref missing, ref missing, ref missing, ref missing);
            aDoc.Activate();
            string name = string.Empty;
            name = "txtRPNo";
            string text = string.Empty;
            text = "SaiRam";
            if (aDoc.Bookmarks.Exists(name))
            {
                Microsoft.Office.Interop.Word.Bookmark bm = aDoc.Bookmarks[name];
                Microsoft.Office.Interop.Word.Range range = bm.Range.Duplicate;
                aDoc.FormFields[name].Result = text;
            }
        }
        aDoc.SaveAs(ref saveAs, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing);
        aDoc.Close(ref missing, ref missing, ref missing);
    }


















     private void FindAndReplace(Microsoft.Office.Interop.Word.Application WordApp,object findText,object replaceWithText)
     {
         object matchCase = true;
         object matchWholeWord = true;

         object matchWildCards = false;

         object matchSoundsLike = false;

         object matchAllWordForms = false;

         object forward = true;

         object format = false;

         object matchKashida = false;

         object matchDiacritics = false;

         object matchAlefHamza = false;

         object matchControl = false;

         object read_only = false;

         object Visible = true;

         object replace = 2;

         object wrap = 1;

         WordApp.Selection.Find.Execute(ref findText,ref matchCase,ref matchWholeWord,ref matchWildCards,ref matchSoundsLike,ref matchAllWordForms,ref forward,ref wrap,ref format,ref replaceWithText,ref replace,ref matchKashida,ref matchDiacritics,ref matchAlefHamza,ref matchControl);



     }

     private void getDoc()
     {
         //creating instance of word application
         Microsoft.Office.Interop.Word._Application w = new Microsoft.Office.Interop.Word.Application();
         object path = @"D:\LstDoc.docx";
         object read = "ReadWrite";
         object readOnly = false;
         object o = System.Reflection.Missing.Value;
         //opening document
         Microsoft.Office.Interop.Word._Document oDoc = w.Documents.Open(ref path, ref o, ref readOnly, ref o, ref o, ref o, ref o, ref o, ref o, ref o, ref o, ref o, ref o, ref o, ref o, ref o);

         try
         {
             string bookmarkName = string.Empty;

             bookmarkName = "txtRPNo";

             Object name = bookmarkName;

             Microsoft.Office.Interop.Word.Range range =

             oDoc.Bookmarks.get_Item(ref name).Range;

             range.Text = "Dharan";

             object newRange = range;

             oDoc.Bookmarks.Add(bookmarkName, ref newRange);


             //object rng = bookmark.Range;
             //string bookmarkName = bookmark.Name;

             //bookmark.Range.Text = newText;

             //this.Bookmarks.Add(bookmarkName, ref rng); 



             //loop for each paragraph in document
             foreach (Microsoft.Office.Interop.Word.Paragraph p in oDoc.Paragraphs)
             {
                 Microsoft.Office.Interop.Word.Range rng = p.Range;

               

                 Microsoft.Office.Interop.Word.Style styl = rng.get_Style() as Microsoft.Office.Interop.Word.Style;
                 //checking if document containg table
                 if ((bool)rng.get_Information(Microsoft.Office.Interop.Word.WdInformation.wdWithInTable)
                                     == true)
                 {
                     //loop for each cell in table
                     foreach (Microsoft.Office.Interop.Word.Cell c in rng.Cells)
                     {
                         if (rng.Cells.Count > 0)
                         {
                             //checking for desired field in table
                             if (c.Range.Text.ToString().Contains("ID"))
                                 //editing values in tables.
                                 c.Next.Range.Text = "1";
                             if (c.Range.Text.ToString().Contains("Name"))
                                 c.Next.Range.Text = "Haider";
                             if (c.Range.Text.ToString().Contains("Address"))
                                 c.Next.Range.Text = "Allahabad";
                         }
                     }
                     //saving document
                     oDoc.Save();
                 }
             }
             //closing document
             oDoc.Close(ref o, ref o, ref o);
         }
         catch (Exception ex)
         {
             oDoc.Close(ref o, ref o, ref o);
            
         }

     }

     private void createDocForDC(string SavePath)
     {
         object oMissing = System.Reflection.Missing.Value;
         object oEndOfDoc = "\\endofdoc";

       
         Microsoft.Office.Interop.Word._Application oWord;
         Microsoft.Office.Interop.Word._Document oDoc;
         oWord = new Microsoft.Office.Interop.Word.Application();
         oWord.Visible = true;

         oDoc = oWord.Documents.Add(ref oMissing, ref oMissing,  ref oMissing, ref oMissing);

         Object fileName = (Object)SavePath;
         Object fileformat = Microsoft.Office.Interop.Word.WdSaveFormat.wdFormatPDF;
         Object SaveChange = Microsoft.Office.Interop.Word.WdSaveOptions.wdDoNotSaveChanges;
         Object OrianalForamt = Microsoft.Office.Interop.Word.WdOriginalFormat.wdOriginalDocumentFormat;

         oDoc.Activate();

         oDoc.SaveAs(ref fileName, ref fileformat, ref oMissing, ref oMissing, ref oMissing, ref oMissing,
                     ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing);

         oDoc.Saved = true;

         oDoc.Close(ref SaveChange, ref oMissing, ref oMissing);
         oWord.Quit(ref SaveChange, ref OrianalForamt, ref oMissing);

        

      
     }

     protected void lnkDownload_Click1(object sender, EventArgs e)
     {
         LinkButton lnkbtn = sender as LinkButton;
         GridViewRow gvrow = lnkbtn.NamingContainer as GridViewRow;
         string filePath = string.Empty;
         filePath = "C:\\DcChkList_Out\\ " + _payID + "_" + "DCChecklist_Supervision.docx";
         filePath = Session["DCOutPath"].ToString();
         Response.ContentType = "image/jpg";
         Response.AddHeader("Content-Disposition", "attachment;filename=\"" + filePath + "\"");
         Response.TransmitFile(filePath);
         Response.End();
     }
     protected void btnDClist_Click(object sender, EventArgs e)
     {
         CreateDCCheckList();
     }
     private void CreateDCCheckList()
     {
         string srcPath = string.Empty;
         string destPath = string.Empty;

         lnkDownload.Text = "Create Link";

         string strTemp = string.Empty;

         if (chkListType == 1)
         {
             srcPath = @"C:\PaymentChkList\DCChecklist_Supervision.docx";
             strTemp = "C:\\DcChkList_Out\\ " + _payID + "_" + "DCChecklist_Supervision.docx";
         }
         else if (chkListType == 2)
         {
             srcPath = @"C:\PaymentChkList\DCChecklist_Construction.docx";
             strTemp = "C:\\DcChkList_Out\\ " + _payID + "_" + "DCChecklist_Construction.docx";
         }
         else if (chkListType == 3)
         {
             srcPath = @"C:\PaymentChkList\DCChecklist_Design.docx";
             strTemp = "C:\\DcChkList_Out\\ " + _payID + "_" + "DCChecklist_Design.docx";
         }
         else if (chkListType == 4)
         {
             srcPath = @"C:\PaymentChkList\DCChecklist_Other.docx";
             strTemp = "C:\\DcChkList_Out\\ " + _payID + "_" + "DCChecklist_Other.docx";
         }


         Session["DCOutPath"] = strTemp;
         destPath = strTemp;
         CreateWordDocNew(srcPath, destPath);

         lnkDownload.Enabled = true;
         lnkDownload.Text = "DownLoad_Link";
     }
     private void CreateWordDocNew(Object fileName, object saveAs)
     {
         IList<string> strDCColl = getDcCkeckListData();

         object missing = System.Reflection.Missing.Value;
         Microsoft.Office.Interop.Word.Application wordApp = new Microsoft.Office.Interop.Word.ApplicationClass();
         Microsoft.Office.Interop.Word.Document aDoc = null;
         wordApp.Visible = true;
         wordApp.DisplayAlerts = Microsoft.Office.Interop.Word.WdAlertLevel.wdAlertsNone;
         wordApp.DisplayAlerts = WdAlertLevel.wdAlertsNone;

         try
         {
             if (File.Exists((string)fileName))
             {
                 object readOnly = false;
                 object isVisible = false;
                 wordApp.Visible = false;

                 aDoc = wordApp.Documents.Open(ref fileName, ref missing, ref readOnly, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref isVisible, ref missing, ref missing, ref missing, ref missing);
                 //aDoc.Activate();

                 if (aDoc.Bookmarks.Exists("txtContractor"))
                 {
                     Microsoft.Office.Interop.Word.Bookmark bm = aDoc.Bookmarks["txtContractor"];
                     Microsoft.Office.Interop.Word.Range range = bm.Range.Duplicate;
                     aDoc.FormFields["txtContractor"].Result = lblCntr.Text;
                 }
                 if (aDoc.Bookmarks.Exists("txtContractNo"))
                 {
                     Microsoft.Office.Interop.Word.Bookmark bm = aDoc.Bookmarks["txtContractNo"];
                     Microsoft.Office.Interop.Word.Range range = bm.Range.Duplicate;
                     aDoc.FormFields["txtContractNo"].Result = lblCommtment.Text;
                 }
                
               

                 for (int iCnt = 1; iCnt < strDCColl.Count; iCnt++)
                 {
                     string chkName = "Text" + iCnt;
                     if (aDoc.Bookmarks.Exists(chkName))
                     {
                         Microsoft.Office.Interop.Word.Bookmark bm = aDoc.Bookmarks[chkName];
                         Microsoft.Office.Interop.Word.Range range = bm.Range.Duplicate;


                         aDoc.FormFields[chkName].Result = "True";
                        
                     }
                 }
             }
             else
             {
                 //Response.Write("Source File is Not exist");
                 return;
             }

             aDoc.SaveAs(ref saveAs, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing);

             object saveChanges = Microsoft.Office.Interop.Word.WdSaveOptions.wdPromptToSaveChanges;
             object originalFormat = Microsoft.Office.Interop.Word.WdOriginalFormat.wdWordDocument;
             object routeDocument = true;

             object missingValue = Type.Missing;

             ((Microsoft.Office.Interop.Word._Document)aDoc).Close(ref saveChanges, ref originalFormat, ref routeDocument);
             ((Microsoft.Office.Interop.Word._Application)wordApp.Application).Quit(ref missingValue, ref missingValue, ref missingValue);

         }
         catch (Exception ex)
         {
             throw ex;
         }
         finally
         {
             if (aDoc != null)
                 System.Runtime.InteropServices.Marshal.ReleaseComObject(aDoc);

             if (wordApp != null)
                 System.Runtime.InteropServices.Marshal.ReleaseComObject(wordApp);

             wordApp = null;
             aDoc = null;
             GC.Collect();
             GC.WaitForPendingFinalizers();
         }
     }


     private IList<string> getDcCkeckListData()
     {
         IList<string> strColl = new List<string>();
         string sqlQuery = "SELECT jobID, check1, check2, check3, check4, check5, check6, check7, check8, check9, check10, check11, check12, check13, check14, check15 FROM  PayCheckList WHERE (payID = " + _payID + ")";
         using (SqlConnection objCon = new SqlConnection(connValue))
         {
             objCon.Open();
             using (SqlCommand objCmd = new SqlCommand(sqlQuery, objCon))
             {
                 using (SqlDataReader dr = objCmd.ExecuteReader())
                 {
                     while (dr.Read())
                     {
                         strColl.Add(dr["jobID"].ToString());
                         strColl.Add(dr["check1"].ToString());
                         strColl.Add(dr["check2"].ToString());
                         strColl.Add(dr["check3"].ToString());

                         strColl.Add(dr["check4"].ToString());
                         strColl.Add(dr["check5"].ToString());
                         strColl.Add(dr["check6"].ToString());

                         strColl.Add(dr["check7"].ToString());
                         strColl.Add(dr["check8"].ToString());
                         strColl.Add(dr["check9"].ToString());

                         strColl.Add(dr["check10"].ToString());
                     }
                 }
             }
         }
         return strColl;
     }
}