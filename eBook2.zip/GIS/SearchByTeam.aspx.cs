﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Data;
using Datalayer;
using System.IO;
using System.Drawing;
using System.Web.UI.HtmlControls;


public partial class GIS_SearchByTeam : System.Web.UI.Page
{
    string _prjCode = string.Empty;
    IList<string> userRightsColl = new List<string>();
    int _userID = 0;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["UserName"] == null)
        {
            Response.Redirect("~/LoginPage.aspx", false);
        }
        else
        {
            if (Session["ProjectCode"] != null)         // On Click of Project code link within same page
                _prjCode = Session["ProjectCode"].ToString();

            userRightsColl = (IList<string>)Session["UserRightsColl"];

            _userID = Convert.ToInt32(Session["UserID"]);

            if (!IsPostBack)
            {
                string strGISTeam = "SELECT CategoryID,jobTypeName FROM JobType where jobTypeID in (130,131,132,133,134,138) and jobTypeName<>'Internal team Support'";
                PopulateDropDownBox(ddlGISTeam, strGISTeam, "CategoryID", "jobTypeName");

                string strQS = "SELECT Distinct jobOwner.contactID, Contact.userShortName AS UserName FROM JobOwner INNER JOIN  Contact ON jobOwner.contactID = Contact.contactID Where jobOwner.SectionID =11 and jobOwner.jobOwnerStatusID <>7 and Contact.userShortName <>''  Order by Contact.userShortName ";
                PopulateDropDownBox(ddlDCU, strQS, "contactID", "UserName");

                // PopulateDropDownBox(ddlPrj, "SELECT prjCoordID, coordName FROM ProjCoordinator Where sectionID = 10 ORDER BY coordName", "prjCoordID", "coordName");

                // PopulateDropDownBox(ddlPrj, "SELECT DISTINCT Contact.contactID, (Contact.firstName + '  ' + Contact.lastName) AS UserName FROM Job INNER JOIN   Contact ON Job.projCoordinatorID = Contact.contactID WHERE (Job.sectionID = 10)", "contactID", "UserName");

                PopulateDropDownBox(ddlPrj, "SELECT DISTINCT Contact.contactID, Contact.UserShortName FROM Job INNER JOIN   Contact ON Job.projCoordinatorID = Contact.contactID WHERE (Job.sectionID = 11)", "contactID", "UserShortName");


                if (Session["CoordName"] != null)
                {
                    string str = Session["CoordName"].ToString();
                    string QSID = ddlPrj.Items.FindByText(str).Value;
                    ddlPrj.SelectedValue = QSID;
                }

                if (Session["ActionBy"] != null)
                {
                    string strActionBy = Session["ActionBy"].ToString();
                    string staffID = ddlDCU.Items.FindByText(strActionBy).Value;
                    ddlDCU.SelectedValue = staffID;
                }

                if (Session["CategoryID"] == null)
                {
                    GetOngoingMngrData("0");
                }
                else
                {
                    GetOngoingMngrData(Session["CategoryID"].ToString());
                }
            }
        }
    }


    private void PopulateDropDownBox(DropDownList ddlBox, string sqlQuery, string valueMember, string displayName)
    {
        ddlBox.DataSource = new JobOrderData().FillDropdown(sqlQuery);
        ddlBox.DataTextField = displayName;
        ddlBox.DataValueField = valueMember;
        ddlBox.SelectedIndex = -1;
        ddlBox.DataBind();

        ListItem emptyItem = new ListItem("", "");
        ddlBox.Items.Insert(0, emptyItem);
    }

    protected void gvDCLogView_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        gvMngrLogView.PageIndex = e.NewPageIndex;
        DataTable dt = new DataTable();
        dt = Session["getDCJobs"] as DataTable;

        BindData(dt);
    }

    private void BindData(DataTable dt)
    {
        lblCnt.Text = "Job Count :   " + dt.Rows.Count.ToString();

        gvMngrLogView.DataSource = dt;
        gvMngrLogView.DataBind();
    }


    // Function call On-going jobs and project code selection jobs
    private void GetOngoingMngrData(string categoryID)
    {
        int _userID = 0;
        int _coordID = 0;

        if (ddlPrj.SelectedIndex != 0)
            _coordID = Convert.ToInt32(ddlPrj.SelectedValue);

        if (ddlDCU.SelectedIndex != 0)
            _userID = Convert.ToInt32(ddlDCU.SelectedValue);


        DataTable dt = new DataTable();
        if (Session["SectionID"].Equals("11"))        // DCU Section
        {
            if (categoryID == "0")
            {
                if ((_userID != 0) || (_coordID != 0))  // View Payment Request Log
                {
                    dt = ViewOngoingMngrJobs( 0, _userID.ToString(), _coordID.ToString());
                    Session["getDCJobs"] = dt;
                    lblCnt.Text = "Job Count : -  " + dt.Rows.Count.ToString();
                }
                else if (Session["OverDue"].ToString() == "Yes")   // Admin    // Request Controll Admin
                {
                    DataSet ds = (new JobOrderData().GetOverDueMngrDetails(22, 46, 0, 0)); // For overdue request
                    dt = ds.Tables[0];

                    Session["getDCJobs"] = dt;
                    lblCnt.Text = "Job Count : -  " + dt.Rows.Count.ToString();
                }
                else if ((!userRightsColl.Contains("17")))       // View All On-Going List of Job Orders
                {
                    dt = ViewOngoingMngrJobs( 0, "0", "0");

                    Session["getDCJobs"] = dt;
                    lblCnt.Text = "Job Count : -  " + dt.Rows.Count.ToString();
                }
                else               // Only Current User Jobs which is Ongoing
                {
                    dt = ViewOngoingMngrJobs( 0, Session["UserID"].ToString(), "0");
                    Session["getDCJobs"] = dt;
                    lblCnt.Text = "Job Count : -  " + dt.Rows.Count.ToString();
                }
                ddlGISTeam.SelectedValue = dt.Rows[0]["categoryID"].ToString();
            }
            else
            { 
                //if(_userID!=0)
                //{
                    //dt = ViewJobsBasedOnCategory(_userID, _coordID, categoryID.ToString(), Session["SectionID"].ToString());
                if (categoryID == "130")
                {
                    heading.InnerText = "Data and operation/Internal Support team";
                }
                else if (categoryID == "131")
                {
                    heading.InnerText = "Analytics and innovation team";
                }
                else if (categoryID == "132")
                {
                    heading.InnerText = "CAD/BIM team";
                }
                else if (categoryID == "133")
                {
                    heading.InnerText = "Planning and development team";
                }
                else if (categoryID == "134")
                {
                    heading.InnerText = "Analytics and innovation team";
                }                 
                else
                {
                    heading.InnerText = "All Teams";
                }
                //if (ddlDCU.SelectedValue != "")
                //{
                //    dt = ViewJobsBasedOnCategory(categoryID, Session["SectionID"].ToString(), Convert.ToInt32(ddlDCU.SelectedValue), _coordID);
                //}
                //else
                //{
                    dt = ViewJobsBasedOnCategory(categoryID, Session["SectionID"].ToString(), Convert.ToInt32(Session["UserID"].ToString()), _coordID);
                //}
                //}
                //else
                //    dt = ViewJobsBasedOnCategory(Int32.Parse(Session["UserID"].ToString()), _coordID, categoryID.ToString(), Session["SectionID"].ToString());
                Session["getDCJobs"] = dt;
                lblCnt.Text = "Job Count : -  " + dt.Rows.Count.ToString();
            }

        }
        else if (Session["userProfileID"].Equals("15"))   // Admin    // Request Controll Admin
        {
            // dt = ViewOngoingMngrJobs(0, "", "0", "0");

            DataSet ds = (new JobOrderData().GetOverDueMngrDetails(22, 46, 0, 0)); // For overdue request
            dt = ds.Tables[0];

            Session["getDCJobs"] = dt;
            lblCnt.Text = "Job Count : -  " + dt.Rows.Count.ToString();
        }
        else
        {

        }
        BindData(dt);
    }

    // Function used to call ongoing DC jobs
    private DataTable ViewOngoingMngrJobs(int _prjCode, string userID, string _teamID)
    {
        DataSet ds = new DataSet();

        Int32 qsID;
        Int32.TryParse(userID, out qsID);

        Int32 TeamID;
        Int32.TryParse(_teamID, out TeamID);

        try
        {
            ds = (new JobOrderData().View_GISLog(qsID, _prjCode, 11,TeamID));    // SpName - dcu_ViewDCLog //mngr_ViewMngrLog
        }
        catch (Exception ex)
        {

        }
        return ds.Tables[0];
    }

    private DataTable ViewJobsBasedOnCategory(string categoryID, string sectionID,int userID, int coordID)
    {
        DataSet ds = new DataSet();

        //Int32 qsID;
        //Int32.TryParse(userID, out qsID);

        //Int32 CoordID;
        //Int32.TryParse(_CoordID, out CoordID);
        try
        {
            ds = (new JobOrderData().View_GISSpecificTeamJobsLog(categoryID, sectionID,userID, coordID)); // SpName - gis_ViewSpecificTeamJobs
        }
        catch (Exception ex)
        {

        }
        return ds.Tables[0];
    }

    // When user click on JobNo Link Button For view DC Job Details
    protected void lnkJobOrderJobNo_Click(object sender, EventArgs e)
    {
        try
        {
            LinkButton lnkJobID = (LinkButton)sender;
            GridViewRow gvr = (GridViewRow)lnkJobID.NamingContainer;

            Session["JobID"] = ((HtmlGenericControl)gvr.FindControl("divJobID")).InnerText;
            Session["UrlRef"] = Request.Url.AbsoluteUri;

            Response.Redirect("~/GIS/GISDetails.aspx?JobID= " + Session["JobID"] + "", false);
        }
        catch
        {

        }
    }
    protected void btnNewDCLog_Click(object sender, EventArgs e)
    {
        //if (userRightsColl.Contains("2"))
            Response.Redirect("~/GIS/GISServiceReq.aspx", false);
    //    else
    //        ClientScript.RegisterClientScriptBlock(this.GetType(), "Popup", "<script>alert('You have no privilege to Create New Request.')</script>", false);
    }
    protected void btnSearchDCLog_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/GIS/SearchGISData.aspx", false);
    }

    int flag;
    protected void gvDCLogView_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandArgument != "")
        {
            int jobid = Convert.ToInt32(e.CommandArgument);
            switch (e.CommandName)
            {
                case "DeleteJobid":
                    //AccessRightsForDelete();
                    //if (!userRightsColl.Contains("3"))
                    //{
                    //    // Planning to put in Sp Name Like dcu_DeleteJob

                    //    // DeleteJob -spName

                    //    flag = (new JobOrderData().DeleteJobOrder(jobid));             //  Delete DC Job
                    //    new JobOrderData().DeactivateDocumentForJobDelete(jobid);      //  Release docID from Job table for using same document for next job                    
                    //    new JobOrderData().UpdateIsConfirmFalseOnJobDelete(jobid);     //  User Session Task for TempJobNo

                    //    if (flag > 0)
                    //        GetOngoingMngrData();      // After delete job reload Job Data again               
                    //}
                    break;
            }
        }
    }
    private void AccessRightsForDelete()
    {
        if (userRightsColl.Contains("3"))   //Delete Job Order
        {
            Session["lblText"] = "You are not allowed to delete a Job Order.Please contact system Administrator for further inquiry.";
            Session["lblSub"] = "Restricted Access to delete a Job Order.";
            Session["lblBody"] = "This is in reference to Restricted Access to delete a Job Order. I would like to inquire about the restriction.";


            string url = "RestrictedMsgWindow.aspx";
            string s = "window.open('" + url + "', 'popup_window', 'width=500,height=250,left=100,top=100,resizable=yes,scrollbars=yes');";
            ClientScript.RegisterStartupScript(this.GetType(), "script", s, true);
        }
    }
    protected void gvDCLogView_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {

        }
    }

    // Based On User selected DC User it will give related user Info
    protected void ddlDCU_SelectedIndexChanged(object sender, EventArgs e)
    {
        getDataByUserSelection();
    }
    private void getDataByUserSelection()
    {
        DataTable dt = new DataTable();

        string _staffID = string.Empty;

        if (ddlDCU.SelectedIndex != 0)
            _staffID = ddlDCU.SelectedValue;   // Selected staff from dropdown
        else if ((Session["userProfileID"].Equals("1")) || (!userRightsColl.Contains("17")))
            _staffID = "0"; // Admin and the person who have rights -17 
        else
            _staffID = Session["UserID"].ToString();  // Login User

        //string _CoordID = string.Empty;
        //if (ddlPrj.SelectedIndex != 0)
        //    _CoordID = ddlPrj.SelectedValue;

        if (ddlPrj.SelectedValue != "")
        {
            dt = ViewOngoingMngrJobs(Convert.ToInt32(ddlPrj.SelectedValue), _staffID, ddlGISTeam.SelectedValue);
        }
        else
        {
            dt = ViewOngoingMngrJobs( 0, _staffID, ddlGISTeam.SelectedValue);
        }

        Session["getDCJobs"] = dt;
        lblCnt.Text = "Job Count : -  " + dt.Rows.Count.ToString();
        gvMngrLogView.DataSource = dt;
        gvMngrLogView.DataBind();
    }

    #region Export to excel

    // Export to excel

    protected void btnExelDcLog_Click(object sender, EventArgs e)
    {
        ExportToExcel();
    }
    private void ExportToExcel()
    {
        Response.Clear();
        Response.Buffer = true;
        Response.AddHeader("content-disposition", "attachment;filename=GridViewExport.xls");
        Response.Charset = "";
        Response.ContentType = "application/vnd.ms-excel";
        using (StringWriter sw = new StringWriter())
        {
            HtmlTextWriter hw = new HtmlTextWriter(sw);

            //To Export all pages
            gvMngrLogView.AllowPaging = false;

            gvMngrLogView.DataSource = Session["getDCJobs"];
            gvMngrLogView.DataBind();

            gvMngrLogView.HeaderRow.BackColor = Color.White;
            foreach (TableCell cell in gvMngrLogView.HeaderRow.Cells)
            {
                cell.BackColor = gvMngrLogView.HeaderStyle.BackColor;
            }
            foreach (GridViewRow row in gvMngrLogView.Rows)
            {
                row.BackColor = Color.White;
                foreach (TableCell cell in row.Cells)
                {
                    if (row.RowIndex % 2 == 0)
                    {
                        cell.BackColor = gvMngrLogView.AlternatingRowStyle.BackColor;
                    }
                    else
                    {
                        cell.BackColor = gvMngrLogView.RowStyle.BackColor;
                    }
                    cell.CssClass = "textmode";
                }
            }
            gvMngrLogView.RenderControl(hw);

            //style to format numbers to string
            string style = @"<style> .textmode { } </style>";
            Response.Write(style);
            Response.Output.Write(sw.ToString());
            Response.Flush();
            Response.End();
        }
    }
    public override void VerifyRenderingInServerForm(Control control)
    {
        /* Verifies that the control is rendered */
    }

    #endregion

    protected void ddlPrj_SelectedIndexChanged(object sender, EventArgs e)
    {
        getDataByUserSelection();

    }
    protected void ddlGISTeam_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlGISTeam.SelectedValue == "0")
        {
            GetOngoingMngrData("-1");
        }
        else
        {
            GetOngoingMngrData(ddlGISTeam.SelectedValue);
        }
    }
}