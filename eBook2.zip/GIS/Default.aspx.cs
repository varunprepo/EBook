﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Data.SqlClient;
using Datalayer;
using System.Data;
using System.IO;
using System.Configuration;
using PropertyLayer;

using System.DirectoryServices;

public partial class GIS_Default : System.Web.UI.Page
{
    string connValue = System.Configuration.ConfigurationManager.ConnectionStrings["EBSDEBookConn"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
          //  PopulateDropDownBox(drpList, "SELECT serviceTypeID, serviceTypeDescription FROM ServiceType ", "serviceTypeID", "serviceTypeDescription");

            PopulateDropDownBox(ddlDept, "SELECT departmentID, deptName FROM Department", "departmentID", "deptName");

            PopulateDropDownBox(drpList, "SELECT jobTypeID, jobTypeName FROM JobType where sectionID = 11 and CategoryID <> jobTypeID", "jobTypeID", "jobTypeName");

            PopulateDropDownBox(drpListCat, "SELECT jobTypeID, jobTypeName FROM JobType where sectionID = 11 and CategoryID = jobTypeID", "jobTypeID", "jobTypeName");

            drpList.SelectedIndex = -1;

            txtEmail.Focus();

            // txtDate.Text = Convert.ToDateTime(System.DateTime.Now).ToString("dd/MMM/YYYY");

            //txtDate.Text = System.DateTime.Now.ToString();

            fileUpload1.Attributes["onchange"] = "UploadFile(this)";

           

            
        }
    }
    private void SearchForMailInAD()
    {
             //  LDAP://ASHGHAL/CN=Sridher Chandraiah Vadakapuram,OU=Engineering Business Support Section,OU=Engineering Business Support Department,OU=Technical Affairs,OU=Presidents Office,OU=President of PWA,DC=ashghal,DC=gov,DC=qa 

        DirectoryEntry entry = new DirectoryEntry("LDAP://ASHGHAL");
        DirectorySearcher adSearcher = new DirectorySearcher(entry);
        adSearcher.Filter = ("mail=" + txtEmail.Text);
        SearchResultCollection coll = adSearcher.FindAll();


        foreach (SearchResult sResultSet in adSearcher.FindAll())
        {

            // Login Name
            Console.WriteLine(GetProperty(sResultSet, "cn"));
            // First Name
            Console.WriteLine(GetProperty(sResultSet, "givenName"));

            txtName.Text = GetProperty(sResultSet, "givenName");
            ddlDept.SelectedItem.Text = GetProperty(sResultSet, "department");

            // Middle Initials
            Console.Write(GetProperty(sResultSet, "initials"));
            // Last Name
            Console.Write(GetProperty(sResultSet, "sn"));
            // Address
            string tempAddress = GetProperty(sResultSet, "homePostalAddress");

            if (tempAddress != string.Empty)
            {
                string[] addressArray = tempAddress.Split(';');
                string taddr1, taddr2;
                taddr1 = addressArray[0];
                Console.Write(taddr1);
                taddr2 = addressArray[1];
                Console.Write(taddr2);
            }
            // title
            Console.Write(GetProperty(sResultSet, "title"));

            txtPhone.Text = GetProperty(sResultSet, "title");

            // company
            Console.Write(GetProperty(sResultSet, "company"));
            //state
            Console.Write(GetProperty(sResultSet, "st"));
            //city
            Console.Write(GetProperty(sResultSet, "l"));
            //country
            Console.Write(GetProperty(sResultSet, "co"));
            //postal code
            Console.Write(GetProperty(sResultSet, "postalCode"));
            // telephonenumber
            Console.Write(GetProperty(sResultSet, "telephoneNumber"));

            txtID.Text = GetProperty(sResultSet, "telephoneNumber");

            //extention
            Console.Write(GetProperty(sResultSet, "otherTelephone"));
            //fax
            Console.Write(GetProperty(sResultSet, "facsimileTelephoneNumber"));

            // email address
            Console.Write(GetProperty(sResultSet, "mail"));
            // Challenge Question
            Console.Write(GetProperty(sResultSet, "extensionAttribute1"));
            // Challenge Response
            Console.Write(GetProperty(sResultSet, "extensionAttribute2"));
            //Member Company
            Console.Write(GetProperty(sResultSet, "extensionAttribute3"));
            // Company Relation ship Exits
            Console.Write(GetProperty(sResultSet, "extensionAttribute4"));
            //status
            Console.Write(GetProperty(sResultSet, "extensionAttribute5"));
            // Assigned Sales Person
            Console.Write(GetProperty(sResultSet, "extensionAttribute6"));
            // Accept T and C
            Console.Write(GetProperty(sResultSet, "extensionAttribute7"));
            // jobs
            Console.Write(GetProperty(sResultSet, "extensionAttribute8"));
            String tEamil = GetProperty(sResultSet, "extensionAttribute9");

            // email over night
            if (tEamil != string.Empty)
            {
                //string em1, em2, em3;
                //string[] emailArray = tEmail.Split(';');
                //em1 = emailArray[0];
                //em2 = emailArray[1];
                //em3 = emailArray[2];
                //Console.Write(em1 + em2 + em3);

            }
            // email daily emerging market
            Console.Write(GetProperty(sResultSet, "extensionAttribute10"));
            // email daily corporate market
            Console.Write(GetProperty(sResultSet, "extensionAttribute11"));
            // AssetMgt Range
            Console.Write(GetProperty(sResultSet, "extensionAttribute12"));
            // date of account created
            Console.Write(GetProperty(sResultSet, "whenCreated"));
            // date of account changed
            Console.Write(GetProperty(sResultSet, "whenChanged"));

            return;
        }

    }
    private void getActiveDirectoryData()
    {
        DirectoryEntry entry = new DirectoryEntry("LDAP://ASHGHAL");
        DirectorySearcher dSearch = new DirectorySearcher(entry);
        String Name = "svadakapuram@ashghal.gov.qa";
        dSearch.Filter = "(&(objectClass=email)(l=" + Name + "))";



        foreach (SearchResult sResultSet in dSearch.FindAll())
        {
            // Login Name
            Console.WriteLine(GetProperty(sResultSet, "cn"));
            // First Name
            Console.WriteLine(GetProperty(sResultSet, "givenName"));
            // Middle Initials
            Console.Write(GetProperty(sResultSet, "initials"));
            // Last Name
            Console.Write(GetProperty(sResultSet, "sn"));
            // Address
            string tempAddress = GetProperty(sResultSet, "homePostalAddress");

            if (tempAddress != string.Empty)
            {
                string[] addressArray = tempAddress.Split(';');
                string taddr1, taddr2;
                taddr1 = addressArray[0];
                Console.Write(taddr1);
                taddr2 = addressArray[1];
                Console.Write(taddr2);
            }
            // title
            Console.Write(GetProperty(sResultSet, "title"));
            // company
            Console.Write(GetProperty(sResultSet, "company"));
            //state
            Console.Write(GetProperty(sResultSet, "st"));
            //city
            Console.Write(GetProperty(sResultSet, "l"));
            //country
            Console.Write(GetProperty(sResultSet, "co"));
            //postal code
            Console.Write(GetProperty(sResultSet, "postalCode"));
            // telephonenumber
            Console.Write(GetProperty(sResultSet, "telephoneNumber"));
            //extention
            Console.Write(GetProperty(sResultSet, "otherTelephone"));
            //fax
            Console.Write(GetProperty(sResultSet, "facsimileTelephoneNumber"));

            // email address
            Console.Write(GetProperty(sResultSet, "mail"));
            // Challenge Question
            Console.Write(GetProperty(sResultSet, "extensionAttribute1"));
            // Challenge Response
            Console.Write(GetProperty(sResultSet, "extensionAttribute2"));
            //Member Company
            Console.Write(GetProperty(sResultSet, "extensionAttribute3"));
            // Company Relation ship Exits
            Console.Write(GetProperty(sResultSet, "extensionAttribute4"));
            //status
            Console.Write(GetProperty(sResultSet, "extensionAttribute5"));
            // Assigned Sales Person
            Console.Write(GetProperty(sResultSet, "extensionAttribute6"));
            // Accept T and C
            Console.Write(GetProperty(sResultSet, "extensionAttribute7"));
            // jobs
            Console.Write(GetProperty(sResultSet, "extensionAttribute8"));
            String tEamil = GetProperty(sResultSet, "extensionAttribute9");

            // email over night
            if (tEamil != string.Empty)
            {
                //string em1, em2, em3;
                //string[] emailArray = tEmail.Split(';');
                //em1 = emailArray[0];
                //em2 = emailArray[1];
                //em3 = emailArray[2];
                //Console.Write(em1 + em2 + em3);

            }
            // email daily emerging market
            Console.Write(GetProperty(sResultSet, "extensionAttribute10"));
            // email daily corporate market
            Console.Write(GetProperty(sResultSet, "extensionAttribute11"));
            // AssetMgt Range
            Console.Write(GetProperty(sResultSet, "extensionAttribute12"));
            // date of account created
            Console.Write(GetProperty(sResultSet, "whenCreated"));
            // date of account changed
            Console.Write(GetProperty(sResultSet, "whenChanged"));
        }

    }

    public static string GetProperty(SearchResult searchResult,  string PropertyName)
    {
       if(searchResult.Properties.Contains(PropertyName))
       {
        return searchResult.Properties[PropertyName][0].ToString() ;
       }
       else
       {
        return string.Empty;
       }
    }

    protected void Upload_Directly(object sender, EventArgs e)
    {
       // fileUpload.SaveAs(Server.MapPath("~/Uploads/" + Path.GetFileName(fileUpload.FileName)));
       // lblMessage.Visible = true;

        lnkFile.Text = fileUpload1.FileName;

        trBrowse.BgColor = "#F0F0F0";
    }
    string _jobNo = string.Empty;
    protected void btnsave_Click(object sender, EventArgs e)
    {        
        if (lnkFile.Text.Equals("View Attached File"))
        {
            trBrowse.BgColor = "Red";
            ClientScript.RegisterClientScriptBlock(this.GetType(), "Popup", "<script>alert('Please attach the manager approved file.')</script>", false);
            return;
        }

        checkUserExistIneBook(txtEmail.Text);

        int _jobID = InsertJobOrder(Session["UserName"].ToString(), Convert.ToInt32(Session["UserID"]),ref _jobNo);
        
        UploadFile(CreateFolder(true));

       new JobOrderData().SendEmailAlert(new JobOrderData().getEmail("95"), _jobID.ToString(), "", "A new Service Request was created and the details are as follows");

       Session["GIS_JobID"] = _jobID;

       Response.Redirect("~/GIS/GISDetails.aspx", false); //GISInfo

    }
    private string getAllFiles(string newPath)
    {
        String[] allfiles = System.IO.Directory.GetFiles(newPath, "*.*", System.IO.SearchOption.AllDirectories);
        string foldrfileName = string.Empty;
        if (allfiles.Length != 0)
        {
            //foreach (var file in allfiles)
            //{
            FileInfo info = new FileInfo(allfiles[0]);
            foldrfileName = info.FullName;
        }

        return foldrfileName;
    }
    private string CreateFolder(bool isUpload)
    {
        string requestID = string.Empty;
        requestID = _jobNo;
        string newfolderName = null;

        if (!Directory.Exists(ConfigurationManager.AppSettings["GISRequestFolderPath"].ToString()))
            Directory.CreateDirectory(ConfigurationManager.AppSettings["GISRequestFolderPath"].ToString());

        newfolderName = ConfigurationManager.AppSettings["GISRequestFolderPath"].ToString() + "\\" + requestID;
        Directory.CreateDirectory(newfolderName);

        if (newfolderName != null)
        {
            if (!isUpload)
            {
                string fullFilePath = getAllFiles(newfolderName);
                if (fullFilePath != "")
                {
                    fullFilePath.Substring(fullFilePath.LastIndexOf("\\") + 1);
                }
                else
                {

                }
            }
        }
        else
        {

        }
        return newfolderName;
    }

    private void UploadFile(string newfolderNme)
    {
        string filename = string.Empty;
        if (fileUpload1.PostedFile != null)
        {
            filename = Path.GetFileName(fileUpload1.PostedFile.FileName);

            string filePath = string.Empty;
            if (fileUpload1.HasFile)
            {
                try
                {
                    //  string folderName = ConfigurationManager.AppSettings["NonEBDfolderName"].ToString();
                    filePath = Path.Combine(newfolderNme, filename);

                    fileUpload1.SaveAs(filePath);
                }
                catch (Exception ex)
                {
                    Response.Write(ex.Message);

                    string script = "<script type=\"text/javascript\"> displayPopup('" + ex.Message + "'); </script>";
                    ClientScript.RegisterClientScriptBlock(this.GetType(), "myscript", script);

                    return;
                }
            }
            else
            {
                ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Please select file for upload.')</script>", false);
                return;
            }
        }
    }

    private int checkUserExistIneBook(string eMial)
    {
        string _contactID = "0";
        _dtuserDataColl = checkUserExist(txtEmail.Text.Trim());

        if (_dtuserDataColl.Rows.Count == 0)
        {
            _contactID = AddUser(0);
        }

        return Convert.ToInt32(_contactID);
    }

    private string AddUser(int contactID)
    {
        using (SqlConnection sqlConn = new SqlConnection(connValue))
        {
            using (SqlCommand sqlCmd = new SqlCommand())
            {
                try
                {
                    sqlCmd.Parameters.AddWithValue("@firstName", txtName.Text.Trim());
                    sqlCmd.Parameters.AddWithValue("@lastName", txtName.Text.Trim());
                    sqlCmd.Parameters.AddWithValue("@middleName", System.DBNull.Value);
                    sqlCmd.Parameters.AddWithValue("@companyID", 362);
                    sqlCmd.Parameters.AddWithValue("@officeAddress", System.DBNull.Value);
                    sqlCmd.Parameters.AddWithValue("@officePhone", System.DBNull.Value);

                    sqlCmd.Parameters.AddWithValue("@mobPhone", System.DBNull.Value);
                    sqlCmd.Parameters.AddWithValue("@country", System.DBNull.Value);
                    sqlCmd.Parameters.AddWithValue("@emailAddress", txtEmail.Text.Trim());

                    sqlCmd.Parameters.AddWithValue("@jobPosition", txtPhone.Text);
                    sqlCmd.Parameters.AddWithValue("@sectionID", 8); //guest user sectionId is not applicable = 8                     
                    sqlCmd.Parameters.AddWithValue("@teamLeaderID", 6); //guest user teamLeadID is not applicable = 6                    

                    if (contactID == 0)
                        sqlCmd.Parameters.AddWithValue("@contactID", SqlDbType.SmallInt).Direction = ParameterDirection.Output;
                    else
                        sqlCmd.Parameters.AddWithValue("@contactID", contactID);

                    sqlCmd.Parameters.AddWithValue("@currentUser", Session["UserName"].ToString());

                    sqlCmd.Parameters.AddWithValue("@userComments", System.DBNull.Value);

                    sqlCmd.Parameters.AddWithValue("@userShortName", System.DBNull.Value);

                    sqlCmd.Parameters.AddWithValue("@isAuthRepres", System.DBNull.Value);

                    sqlCmd.Parameters.AddWithValue("@isCoordinator", System.DBNull.Value);

                    sqlConn.Open();
                    sqlCmd.Connection = sqlConn;
                    sqlCmd.CommandType = CommandType.StoredProcedure;
                    sqlCmd.CommandText = "InsertUpdateContact";
                    sqlCmd.ExecuteNonQuery();

                    return sqlCmd.Parameters["@contactID"].Value.ToString();
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
        }
    }
    public int InsertJobOrder(string userName, int _userID, ref string jobNo)
    {
        List<string> projData = Session["sessprjColl"] as List<string>;
        SqlConnection con = new SqlConnection(connValue);
        SqlCommand cmd = new SqlCommand();
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Connection = con;
        cmd.CommandText = "gis_CreateJobOrder";   // SP        
       
        cmd.Parameters.AddWithValue("@docID", 1);
        cmd.Parameters.AddWithValue("@JobID", SqlDbType.SmallInt).Direction = ParameterDirection.Output;
        cmd.Parameters.Add(new SqlParameter("@jobNo", SqlDbType.VarChar, 30, ParameterDirection.Output, false, 0, 30, "jobNo", DataRowVersion.Default, null));

        if (drpList.SelectedIndex!=0)
        {
            cmd.Parameters.AddWithValue("@jobCatID", 76);   
            cmd.Parameters.AddWithValue("@jobTypeID", drpList.SelectedValue);            
        }
        else
        {
            cmd.Parameters.AddWithValue("@jobCatID", 77);
            cmd.Parameters.AddWithValue("@jobTypeID", drpList.SelectedValue);            
        }

        cmd.Parameters.AddWithValue("@jobStatusID", 3); // on-going  


        cmd.Parameters.AddWithValue("@affairID", 4);   
    
        if (ddlDept.SelectedValue!="")
           cmd.Parameters.AddWithValue("@deptID", ddlDept.SelectedValue);
        else
            cmd.Parameters.AddWithValue("@deptID", 8);


        cmd.Parameters.AddWithValue("@addendumNO", System.DBNull.Value);
        cmd.Parameters.AddWithValue("@docRefID", 1);       
        cmd.Parameters.AddWithValue("@contractNo", System.DBNull.Value);
        cmd.Parameters.AddWithValue("@projectTitle", txtDesc.Text);
        cmd.Parameters.AddWithValue("@jobDesc", txtDesc.Text);
        cmd.Parameters.AddWithValue("@gradeID", System.DBNull.Value);
        cmd.Parameters.AddWithValue("@workDays", 4);
        cmd.Parameters.AddWithValue("@JobDueDate", Convert.ToDateTime(System.DateTime.Now.Date).ToString("dd/MMM/yyyy"));  
  
        cmd.Parameters.AddWithValue("@contractorID", System.DBNull.Value); 
        cmd.Parameters.AddWithValue("@contractTypeID", System.DBNull.Value); 
 
        cmd.Parameters.AddWithValue("@qsID", System.DBNull.Value);       
        cmd.Parameters.AddWithValue("@peID", System.DBNull.Value);      
        cmd.Parameters.AddWithValue("@ceID", System.DBNull.Value);
        cmd.Parameters.AddWithValue("@dcID", _userID);
        cmd.Parameters.AddWithValue("@createDate", System.DateTime.Now.ToString("dd/MMM/yyyy"));

        cmd.Parameters.AddWithValue("@createUser", Session["UserName"].ToString());
        cmd.Parameters.AddWithValue("@JobReceivedDate", Convert.ToDateTime(System.DateTime.Now.Date).ToString("dd/MMM/yyyy"));

        cmd.Parameters.AddWithValue("@jobCreatedByID", _userID);
        cmd.Parameters.AddWithValue("@SectionID", 11);
        cmd.Parameters.AddWithValue("@StaffRoleID", _userID); // pass value need 
        cmd.Parameters.AddWithValue("@jobPurposeID", 1);
        cmd.Parameters.AddWithValue("@actionDueDate", Convert.ToDateTime(System.DateTime.Now.Date).ToString("dd/MMM/yyyy"));  

        cmd.Parameters.AddWithValue("@daysToAct", 4);
        cmd.Parameters.AddWithValue("@jobOwnerStatusID", 3);
        cmd.Parameters.AddWithValue("@docCreatedByID", _userID);
        cmd.Parameters.AddWithValue("@originID", System.DBNull.Value);
        cmd.Parameters.AddWithValue("@jobOwnerID", System.DBNull.Value);
        cmd.Parameters.AddWithValue("@docReceivedDate", System.DateTime.Now.ToString("dd/MMM/yyyy"));

        cmd.Parameters.AddWithValue("@docDate", System.DBNull.Value);
        cmd.Parameters.AddWithValue("@inchargeDueDate", Convert.ToDateTime(System.DateTime.Now.Date).ToString("dd/MMM/yyyy"));  

        cmd.Parameters.AddWithValue("@ministryCode", System.DBNull.Value);      
        cmd.Parameters.AddWithValue("@budgetRefNo", System.DBNull.Value);       
        cmd.Parameters.AddWithValue("@provisionNo", System.DBNull.Value);
        cmd.Parameters.AddWithValue("@committmentNo", System.DBNull.Value);
        cmd.Parameters.AddWithValue("@projectCode", System.DBNull.Value);
        cmd.Parameters.AddWithValue("@projStstusID", System.DBNull.Value);

        cmd.Parameters.AddWithValue("@emailAddr", txtEmail.Text);
        cmd.Parameters.AddWithValue("@firstName", txtName.Text);
        cmd.Parameters.AddWithValue("@lastName", txtName.Text);
        cmd.Parameters.AddWithValue("@reqBehalf", txtBehalf.Text);        

        try
        {
            con.Open();
            cmd.ExecuteNonQuery();
            con.Dispose();
        }
        catch (Exception ex)
        {

            throw ex;
        }
        finally
        {
            con.Close();
        }

        jobNo = (string)cmd.Parameters["@JobNo"].Value;
        return (int)cmd.Parameters["@JobID"].Value;
        // return _insrttData.jobID;
    }
    protected void btnreset_Click(object sender, EventArgs e)
    {
        txtEmail.Text = "";
        txtBehalf.Text = "";

        txtCntrNo.Text = "";
        txtDesc.Text = "";

        txtName.Text = "";
       // txtDept.Text = "";

        ddlDept.SelectedIndex = 0;

    }
     public DataTable checkUserExist(string userEmail)
    {
        DataTable dt = new DataTable();
        SqlConnection sqlConn = new SqlConnection(connValue);
        try
        {
            sqlConn.Open();

            string strQuery = "SELECT  Contact.firstName, Contact.lastName, Contact.companyID, Contact.jobPosition, Contact.emailAddress, Contact.officePhone, Contact.mobPhone, Contact.officeAddress, " + 
                         " Contact.contactID, Contact.sectionID, Contact.teamLeaderID, Contact.userProfileID, Contact.userName, Contact.password, Contact.deptID, Section.sectionName,  " + 
                         " Department.deptName FROM  Contact INNER JOIN Section ON Contact.sectionID = Section.sectionID INNER JOIN Department ON Section.departmentID = Department.departmentID WHERE (Contact.emailAddress = '" + userEmail + "')";

            //SELECT firstName,lastName,companyID,jobPosition,emailAddress,officePhone,mobPhone,officeAddress, contactID, sectionID, teamLeaderID, userProfileID, userName, password  FROM Contact WHERE (emailAddress = '" + userEmail + "') 

            SqlCommand sqlCom = new SqlCommand(strQuery, sqlConn);

            SqlDataAdapter objDA = new SqlDataAdapter(sqlCom);
            objDA.SelectCommand.CommandText = sqlCom.CommandText.ToString();
            objDA.Fill(dt);

        }
        catch (System.Exception ex)
        {
            throw ex;
        }
        finally
        {
            sqlConn.Close();
        }
        return dt;
    }
    DataTable _dtuserDataColl = new DataTable();
    protected void txtname_TextChanged(object sender, EventArgs e)
    {
        _dtuserDataColl = checkUserExist(txtEmail.Text.Trim());
        if (_dtuserDataColl.Rows.Count > 0)
        {
            //if (_dtuserDataColl.Rows[0]["userName"].ToString() == "")
            {
                txtName.Text = _dtuserDataColl.Rows[0]["firstName"].ToString() + "   " + _dtuserDataColl.Rows[0]["lastName"].ToString() + "";

                txtPhone.Text = _dtuserDataColl.Rows[0]["jobPosition"].ToString();

                ViewState["updcontactID"] = Convert.ToInt32(_dtuserDataColl.Rows[0]["contactID"]);

                ViewState["updsectionID"] = Convert.ToInt32(_dtuserDataColl.Rows[0]["sectionID"]);

                ViewState["updteamLeaderID"] = Convert.ToInt32(_dtuserDataColl.Rows[0]["teamLeaderID"]);

                ViewState["upduserProfileID"] = Convert.ToInt32(_dtuserDataColl.Rows[0]["userProfileID"]);

                //txtDept.Text = _dtuserDataColl.Rows[0]["deptName"].ToString();

                ddlDept.SelectedValue = _dtuserDataColl.Rows[0]["deptID"].ToString();

                //txtDept.Text = _dtuserDataColl.Rows[0]["sectionName"].ToString();

                //lblContactID.Text = _dtuserDataColl.Rows[0]["contactID"].ToString();

                // Response.Write(" User Profile ID " + ViewState["upduserProfileID"].ToString());
            }
        }
        else
        {
            SearchForMailInAD();
        }
    }
    private void PopulateDropDownBox(DropDownList ddlBox, string sqlQuery, string valueMember, string displayName)
    {
        DataTable table = new DataTable();
        try
        {
            using (SqlConnection sqlConn = new SqlConnection(connValue))
            {
                using (SqlDataAdapter da = new SqlDataAdapter(sqlQuery, sqlConn))
                {
                    sqlConn.Open();
                    da.Fill(table);
                }
            }
            //cmbBox.Items.Add("Select");

            ddlBox.DataSource = table;
            ddlBox.DataTextField = displayName;
            ddlBox.DataValueField = valueMember;

            ddlBox.SelectedIndex = -1;
            ddlBox.DataBind();

           ddlBox.Items.Insert(0, new ListItem(""));
        }
        catch (System.Exception ex)
        {
            throw ex;
        }
    }   
    protected void lnkFile_Click(object sender, EventArgs e)
    {

    }
    protected void btnHome_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/JobOrder/DCLogHomePage.aspx", false);
    }
    protected void Button1_Click(object sender, EventArgs e)
    {

    }
    protected void drpListCat_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (drpListCat.SelectedIndex!=0)
          PopulateDropDownBox(drpList, "SELECT jobTypeID, jobTypeName FROM JobType where sectionID = 11 and CategoryID = " + drpListCat.SelectedValue + " ", "jobTypeID", "jobTypeName");
    }
}