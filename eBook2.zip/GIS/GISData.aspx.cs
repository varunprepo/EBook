﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using Datalayer;

using System.Data;

public partial class GIS_GISData : System.Web.UI.Page
{
    string connValue = System.Configuration.ConfigurationManager.ConnectionStrings["EBSDEBookConn"].ConnectionString;

    protected void Page_InIt(object sender, EventArgs e)
    {
        
        //gvJoborder.DataSource = new JobOrderData().GetJobOwnerDetailsForGIS(3);

        gvJoborder.DataSource = new JobOrderData().GetJobOwnerDetailsForGISStaff(Convert.ToInt32(Session["UserID"]));
        gvJoborder.DataBind();
        
    }
    protected void Page_Load(object sender, EventArgs e)
    {
        
    }
    protected void gvJoborder_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            DropDownList l = (DropDownList)e.Row.FindControl("ddljobtype");

            PopulateDropDownBox(l, "SELECT JobStatusid,JobStatusName as JobStatus FROM jobStatus where JobStatusid in(2,3,6,7) ", "JobStatusid", "JobStatus");  // where JobStatusid in(5,6,7,8)

            TextBox lm = (TextBox)e.Row.FindControl("jobid");
            TextBox afr = (TextBox)e.Row.FindControl("TextBox1");
            TextBox InchargeID = (TextBox)e.Row.FindControl("txtInchargeID");

            Session["InchargeID"] = InchargeID.Text;
            
            string lk = lm.Text;

            l.ToolTip = InchargeID.Text;

            l.SelectedValue = afr.Text;

            Session["StatusVal"] = l.SelectedValue;

            l.SelectedIndexChanged += new EventHandler(SelectedIndexChanged);

            Label lblStaff = (Label)e.Row.FindControl("txtStaff");

            Label lblDistributedBy = (Label)e.Row.FindControl("txtDistrubed");

            Label lblConactID = (Label)e.Row.FindControl("txtCnctID");

            TextBox _txtDocID = (TextBox)e.Row.FindControl("txtDocID");
            Session["statusdocID"] = _txtDocID.Text;
            Session["contactID"] = lblConactID.Text;

            Label lblDistribID = (Label)e.Row.FindControl("txtDistributedBy");
            Label lblTeamLeadID = (Label)e.Row.FindControl("lblTeamLead");

            Label _lblJobPurpose = (Label)e.Row.FindControl("lblJobPurpose");          

            Label lblIsActive = (Label)e.Row.FindControl("txtisActive");    //txtDistisActive
            if (lblIsActive.Text.Equals("False"))
            {
                HyperLink _lnkStaff = (HyperLink)e.Row.FindControl("lnkStaff"); //
                HyperLink _lnkDistribStaff = (HyperLink)e.Row.FindControl("DistibActive");
                _lnkStaff.Enabled = false;
              
            }

            Label lblDistIsActive = (Label)e.Row.FindControl("txtDistisActive");
            if (lblDistIsActive.Text.Equals("False"))
            {
                HyperLink _lnkDistribStaff = (HyperLink)e.Row.FindControl("lnkDistirbStaff");
                _lnkDistribStaff.Enabled = false;
            }

          
        }
    }
    
    protected void SelectedIndexChanged(object sender, EventArgs e)
    {
        DropDownList ddl = (DropDownList)sender;
        if (ddl.SelectedIndex != 0)
        {
            string ID = ddl.ID;
            string g = ddl.SelectedValue;
            string inchargeID = ddl.ToolTip;

            Session["_InchargeID"] = inchargeID;
            Session["StatusValCurrent"] = ddl.SelectedValue;

            if (ddl.SelectedValue != "3")
            {
                updateOngoingStatus(Convert.ToInt32(inchargeID), Convert.ToInt32(ddl.SelectedValue));
            }
            else
            {
                updateOngoingStatus(Convert.ToInt32(inchargeID), Convert.ToInt32(ddl.SelectedValue));             
               
            }
            //gvJoborder.DataSource = new JobOrderData().GetJobOwnerDetails(_jobID);
            //gvJoborder.DataBind();

            gvJoborder.DataSource = new JobOrderData().GetJobOwnerDetailsForGISStaff(Convert.ToInt32(Session["UserID"]));
            gvJoborder.DataBind();
        }
    }
    private void updateOngoingStatus(int _ownerID, int _statusID)
    {
        SqlConnection cnn = new SqlConnection(connValue);
        cnn.Open();
        SqlCommand cmm = new SqlCommand();
        cmm.Connection = cnn;
        cmm.CommandText = "update JobOwner set jobOwnerStatusID = @statID,completionDate = @completionDate where jobOwnerID =@ownerID";
        cmm.CommandType = CommandType.Text;

        cmm.Parameters.AddWithValue("@ownerID", _ownerID);
        cmm.Parameters.AddWithValue("@statID", _statusID);
        if (_statusID==3)
          cmm.Parameters.AddWithValue("@completionDate", System.DBNull.Value);
        else
            cmm.Parameters.AddWithValue("@completionDate", Convert.ToDateTime(System.DateTime.Now).ToString("dd/MMM/yyyy"));

        cmm.ExecuteNonQuery();
        cnn.Close();
    }

    protected void gvJoborder_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName.Equals("SelectStaff"))
        {
            

        }
    }
    private void PopulateDropDownBox(DropDownList ddlBox, string sqlQuery, string valueMember, string displayName)
    {
        System.Data.DataTable table = new System.Data.DataTable();

        try
        {
            using (SqlConnection sqlConn = new SqlConnection(connValue))
            {
                using (SqlDataAdapter da = new SqlDataAdapter(sqlQuery, sqlConn))
                {
                    sqlConn.Open();
                    da.Fill(table);
                }
            }
            //cmbBox.Items.Add("Select");
            ddlBox.DataSource = table;
            ddlBox.DataTextField = displayName;
            ddlBox.DataValueField = valueMember;
            ddlBox.SelectedIndex = -1;

            ddlBox.DataBind();
            ddlBox.Items.Insert(0, new ListItem("--Select--"));
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    
    protected void btnSearch_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/GIS/SearchGISData.aspx", false);
    }
   
}