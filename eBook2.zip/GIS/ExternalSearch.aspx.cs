﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Data.SqlClient;
using System.Data;

public partial class GIS_ExternalSearch : System.Web.UI.Page
{
    string connValue = System.Configuration.ConfigurationManager.ConnectionStrings["EBSDEBookConn"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            getData(txtEmail.Text);

            //if (Session["eMail"]==null)
            //   getData(txtEmail.Text);
            //else
            //   getData(Session["eMail"].ToString());
        }
    }
    protected void txtname_TextChanged(object sender, EventArgs e)
    {
        getData(txtEmail.Text);
    }
    private void getData(string _email)
    {
        string sqlQuery = "SELECT Job.jobID, Contact.firstName + ' ' + Contact.lastName AS UserName, Contact.emailAddress, Job.jobReceivedDate, Job.projectTitle, Job.jobNo, JobStatus.jobStatusName, " +
                         "  Job.jobDueDate,job.isReqApproved FROM    Job INNER JOIN Contact ON Job.jobCreatedByID = Contact.contactID INNER JOIN  JobStatus ON Job.jobStatusID = JobStatus.jobStatusID WHERE (Contact.emailAddress = '" + _email + "') AND (Job.sectionID = 11) ORDER BY Job.jobID DESC";

        SqlConnection connection = new SqlConnection(connValue);
        DataSet ds = new DataSet();

        try
        {
            connection.Open();
            SqlDataAdapter adapter = new SqlDataAdapter(sqlQuery, connection);
            adapter.Fill(ds);
            connection.Close();
            grvGISRequest.DataSource = ds.Tables[0];
            grvGISRequest.DataBind();
        }
        catch (Exception ex)
        {

        }

    }
    private void getDataByJobNo(int _jobID)
    {
        string sqlQuery = "SELECT Job.JobID, Contact.firstName + ' ' + Contact.lastName AS UserName, Contact.emailAddress, Job.jobReceivedDate, Job.projectTitle, Job.jobNo, JobStatus.jobStatusName, " +
                         "  Job.jobDueDate FROM    Job INNER JOIN Contact ON Job.jobCreatedByID = Contact.contactID INNER JOIN  JobStatus ON Job.jobStatusID = JobStatus.jobStatusID WHERE (Job.JobID = " + _jobID + ") AND (Job.sectionID = 11) ORDER BY Job.jobID DESC";

        SqlConnection connection = new SqlConnection(connValue);
        DataSet ds = new DataSet();

        try
        {
            connection.Open();
            SqlDataAdapter adapter = new SqlDataAdapter(sqlQuery, connection);
            adapter.Fill(ds);
            connection.Close();
            grvGISRequest.DataSource = ds.Tables[0];
            grvGISRequest.DataBind();
        }
        catch (Exception ex)
        {

        }
    }
    protected void btnNew_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/GIS/MyHelth.aspx", false);    
    }
    protected void grvGISRequest_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName.Equals("SelectStaff"))
        {
            string arguments = e.CommandArgument.ToString();

            if (arguments == "")
                return;

            string[] args = arguments.Split(';');

            int requestID = Convert.ToInt32(args[0]);

            Session["JobID"] = requestID;

            Response.Redirect("GISRequest.aspx", false);

            // getDataByJobNo(requestID);

            //  FillstaffData(staffID);


        }
    }
}