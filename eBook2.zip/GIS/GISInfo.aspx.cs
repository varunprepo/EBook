﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Data.SqlClient;
using Datalayer;
using System.Data;
using System.IO;
using System.Configuration;
using PropertyLayer;


public partial class GIS_GISInfo : System.Web.UI.Page
{
    string connValue = System.Configuration.ConfigurationManager.ConnectionStrings["EBSDEBookConn"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            PopulateDropDownBox(drpList, "SELECT serviceTypeID, serviceTypeDescription FROM ServiceType ", "serviceTypeID", "serviceTypeDescription");


            txtEmail.Focus();

            // txtDate.Text = Convert.ToDateTime(System.DateTime.Now).ToString("dd/MMM/YYYY");

            //txtDate.Text = System.DateTime.Now.ToString();
        }

    }
    protected void btnsave_Click(object sender, EventArgs e)
    {
        int _jobID = InsertJobOrder(Session["UserID"].ToString(), 95);


        Response.Write(_jobID.ToString());

        new JobOrderData().SendEmailAlert(new JobOrderData().getEmail("95"), _jobID.ToString(), "", "A new Service Request was created and the details are as follows");

        Response.Redirect("~/GIS/GISDetails.aspx", false);

    }

    public int InsertJobOrder(string userName, int _userID)
    {
        List<string> projData = Session["sessprjColl"] as List<string>;

        SqlConnection con = new SqlConnection(connValue);
        SqlCommand cmd = new SqlCommand();
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Connection = con;
        cmd.CommandText = "dcu_CreateJobOrder";   // SP

        cmd.Parameters.AddWithValue("@jobNo", "GIS190018");

        cmd.Parameters.AddWithValue("@jobTypeID", 76);
        cmd.Parameters.AddWithValue("@jobCatID", 76);

        cmd.Parameters.AddWithValue("@affairID", System.DBNull.Value);

        cmd.Parameters.AddWithValue("@deptID", System.DBNull.Value);

        cmd.Parameters.AddWithValue("@contractNo", System.DBNull.Value);

        cmd.Parameters.AddWithValue("@projectTitle", txtDesc.Text);

        cmd.Parameters.AddWithValue("@jobDesc", txtDesc.Text);

        cmd.Parameters.AddWithValue("@contractorID", System.DBNull.Value);

        cmd.Parameters.AddWithValue("@jobStatusID", 3); // on-going      

        cmd.Parameters.AddWithValue("@docRefID", 1);

        cmd.Parameters.AddWithValue("@addendumNO", System.DBNull.Value);

        cmd.Parameters.AddWithValue("@contractTypeID", System.DBNull.Value);

        cmd.Parameters.AddWithValue("@gradeID", System.DBNull.Value);

        cmd.Parameters.AddWithValue("@qsID", System.DBNull.Value);

        cmd.Parameters.AddWithValue("@peID", System.DBNull.Value);

        cmd.Parameters.AddWithValue("@ceID", System.DBNull.Value);

        cmd.Parameters.AddWithValue("@dcID", _userID);

        cmd.Parameters.AddWithValue("@actionDueDate", Convert.ToDateTime(System.DateTime.Now.Date).ToString("dd/MMM/yyyy"));

        cmd.Parameters.AddWithValue("@workDays", 4);

        cmd.Parameters.AddWithValue("@JobDueDate", Convert.ToDateTime(System.DateTime.Now.Date).ToString("dd/MMM/yyyy"));

        cmd.Parameters.AddWithValue("@jobCreatedByID", _userID);

        cmd.Parameters.AddWithValue("@SectionID", 11);

        cmd.Parameters.AddWithValue("@JobReceivedDate", Convert.ToDateTime(System.DateTime.Now.Date).ToString("dd/MMM/yyyy"));

        cmd.Parameters.AddWithValue("@createDate", System.DateTime.Now.ToString("dd/MMM/yyyy"));

        cmd.Parameters.AddWithValue("@createUser", userName);

        cmd.Parameters.AddWithValue("@StaffRoleID", _userID); // pass value need      

        cmd.Parameters.AddWithValue("@docID", 1);

        cmd.Parameters.AddWithValue("@jobPurposeID", 1);

        cmd.Parameters.AddWithValue("@inchargeDueDate", Convert.ToDateTime(System.DateTime.Now.Date).ToString("dd/MMM/yyyy"));

        cmd.Parameters.AddWithValue("@daysToAct", 4);

        cmd.Parameters.AddWithValue("@jobOwnerStatusID", 3);

        cmd.Parameters.AddWithValue("@docCreatedByID", System.DBNull.Value);

        cmd.Parameters.AddWithValue("@originID", System.DBNull.Value);

        cmd.Parameters.AddWithValue("@jobOwnerID", System.DBNull.Value);

        cmd.Parameters.AddWithValue("@docReceivedDate", System.DateTime.Now.ToString("dd/MMM/yyyy"));

        cmd.Parameters.AddWithValue("@docDate", System.DBNull.Value);

        cmd.Parameters.AddWithValue("@ministryCode", System.DBNull.Value);

        cmd.Parameters.AddWithValue("@budgetRefNo", System.DBNull.Value);

        cmd.Parameters.AddWithValue("@provisionNo", System.DBNull.Value);

        cmd.Parameters.AddWithValue("@JobID", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

        cmd.Parameters.AddWithValue("@projStstusID", System.DBNull.Value);

        cmd.Parameters.AddWithValue("@committmentNo", System.DBNull.Value);

        cmd.Parameters.AddWithValue("@projectCode", System.DBNull.Value);

        try
        {
            con.Open();
            cmd.ExecuteNonQuery();
            con.Dispose();
        }
        catch (Exception ex)
        {

            throw ex;
        }
        finally
        {
            con.Close();
        }


        return (int)cmd.Parameters["@JobID"].Value;

        // return _insrttData.jobID;
    }
    protected void btnreset_Click(object sender, EventArgs e)
    {

    }
    public DataTable checkUserExist(string userEmail)
    {
        DataTable dt = new DataTable();
        SqlConnection sqlConn = new SqlConnection(connValue);
        try
        {
            sqlConn.Open();

            string strQuery = "SELECT  Contact.firstName, Contact.lastName, Contact.companyID, Contact.jobPosition, Contact.emailAddress, Contact.officePhone, Contact.mobPhone, Contact.officeAddress, " +
                         " Contact.contactID, Contact.sectionID, Contact.teamLeaderID, Contact.userProfileID, Contact.userName, Contact.password, Contact.deptID, Section.sectionName,  " +
                         " Department.deptName FROM  Contact INNER JOIN Section ON Contact.sectionID = Section.sectionID INNER JOIN Department ON Section.departmentID = Department.departmentID WHERE (Contact.emailAddress = '" + userEmail + "')";

            //SELECT firstName,lastName,companyID,jobPosition,emailAddress,officePhone,mobPhone,officeAddress, contactID, sectionID, teamLeaderID, userProfileID, userName, password  FROM Contact WHERE (emailAddress = '" + userEmail + "') 

            SqlCommand sqlCom = new SqlCommand(strQuery, sqlConn);

            SqlDataAdapter objDA = new SqlDataAdapter(sqlCom);
            objDA.SelectCommand.CommandText = sqlCom.CommandText.ToString();
            objDA.Fill(dt);

        }
        catch (System.Exception ex)
        {
            throw ex;
        }
        finally
        {
            sqlConn.Close();
        }
        return dt;
    }
    DataTable _dtuserDataColl = new DataTable();
    protected void txtname_TextChanged(object sender, EventArgs e)
    {
        _dtuserDataColl = checkUserExist(txtEmail.Text.Trim());
        if (_dtuserDataColl.Rows.Count > 0)
        {
            //if (_dtuserDataColl.Rows[0]["userName"].ToString() == "")
            {
                txtName.Text = _dtuserDataColl.Rows[0]["firstName"].ToString() + "   " + _dtuserDataColl.Rows[0]["lastName"].ToString() + "";



                txtName.Text = _dtuserDataColl.Rows[0]["jobPosition"].ToString();


                ViewState["updcontactID"] = Convert.ToInt32(_dtuserDataColl.Rows[0]["contactID"]);
                ViewState["updsectionID"] = Convert.ToInt32(_dtuserDataColl.Rows[0]["sectionID"]);
                ViewState["updteamLeaderID"] = Convert.ToInt32(_dtuserDataColl.Rows[0]["teamLeaderID"]);

                ViewState["upduserProfileID"] = Convert.ToInt32(_dtuserDataColl.Rows[0]["userProfileID"]);


                txtBehalf.Text = _dtuserDataColl.Rows[0]["deptName"].ToString();
                txtDept.Text = _dtuserDataColl.Rows[0]["sectionName"].ToString();


                //lblContactID.Text = _dtuserDataColl.Rows[0]["contactID"].ToString();

                // Response.Write(" User Profile ID " + ViewState["upduserProfileID"].ToString());             

            }
        }

    }
    private void PopulateDropDownBox(DropDownList ddlBox, string sqlQuery, string valueMember, string displayName)
    {
        DataTable table = new DataTable();
        try
        {
            using (SqlConnection sqlConn = new SqlConnection(connValue))
            {
                using (SqlDataAdapter da = new SqlDataAdapter(sqlQuery, sqlConn))
                {
                    sqlConn.Open();
                    da.Fill(table);
                }
            }
            //cmbBox.Items.Add("Select");

            ddlBox.DataSource = table;
            ddlBox.DataTextField = displayName;
            ddlBox.DataValueField = valueMember;

            ddlBox.SelectedIndex = -1;
            ddlBox.DataBind();

            ddlBox.Items.Insert(0, new ListItem("--Select--"));
        }
        catch (System.Exception ex)
        {
            throw ex;
        }
    }
}