﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class GIS_AddKPI : System.Web.UI.Page
{
    string eBookConn = System.Configuration.ConfigurationManager.ConnectionStrings["EBSDEBookConn"].ConnectionString;
    DAL dal = null;
    static string recID = null;
    protected void Page_Load(object sender, EventArgs e)
    {
        if(!IsPostBack)
        {
            int currentYear = DateTime.Now.Year;
            ddlKPIYear.Items.Add("");
            for (int i = 0; i < 5; i++)
			{
                ddlKPIYear.Items.Add(currentYear.ToString());
                currentYear = currentYear - 1;
			}
            dal = new DAL(eBookConn);
            gvViewVendors.DataSource = dal.GetDataFromDB("SurveyKPI", "select * from SurveyKPI");
            gvViewVendors.DataBind();
        }
    }

    protected void btnSaveUpdate_Click(object sender, EventArgs e)
    {
        SqlConnection sqlConn = null;

        try
        {
            using (sqlConn = new SqlConnection(eBookConn))
            {
                sqlConn.Open();
                SqlCommand sqlComm = null;
                using (sqlComm = new SqlCommand())
                {

                    //sqlDtReader.Close();
                    sqlComm = new SqlCommand();
                    sqlComm.Connection = sqlConn;
                    sqlComm.CommandType = CommandType.StoredProcedure;
                    sqlComm.CommandText = "AddOrUpdateSurveyKPI";
                    sqlComm.Parameters.AddWithValue("@kpiYear", ddlKPIYear.SelectedValue);
                    sqlComm.Parameters.AddWithValue("@kpiQtr", ddlKPIQuarter.SelectedValue);
                    sqlComm.Parameters.AddWithValue("@surveyKPI", txtSurveyKPI.Text.Trim());
                    if (recID != null)
                    {
                        sqlComm.Parameters.AddWithValue("@selectedRecID", recID);
                    }
                    else
                    {
                        sqlComm.Parameters.AddWithValue("@selectedRecID", DBNull.Value);
                    }
                    //sqlComm.Parameters.AddWithValue("@projId", HttpUtility.HtmlDecode(Request.QueryString["projectID"].ToString()));
                    //sqlComm.Parameters.AddWithValue("@projId", DBNull.Value);
                    

                    //if (txtEOICollectionDate.Text != "")
                    //{
                    //    sqlComm.Parameters.AddWithValue("@eoiCollectionDate", Convert.ToDateTime(txtEOICollectionDate.Text + " " + DateTime.Now.TimeOfDay)); //strDate = Convert.ToDateTime(strDate).ToString("MM/dd/yyyy", CultureInfo.InvariantCulture);                        
                    //}
                    //else
                    //{
                    //    sqlComm.Parameters.AddWithValue("@eoiCollectionDate", DBNull.Value);
                    //}

                    
                    sqlComm.ExecuteNonQuery();
                    //}
                    //if (btnSave.Text == "Save")
                    //{
                    //btnSaveUpdate.Text = "Update";
                    //}
                    //LoadEOIStages();
                }
                dal = new DAL(eBookConn);
                gvViewVendors.DataSource = dal.GetDataFromDB("SurveyKPI", "select * from SurveyKPI");
                gvViewVendors.DataBind();

            }
        }
        catch (Exception ex)
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Error occurred while inserting or updating the vendor information in the database')</script>", false);
        }
        finally
        {
            sqlConn.Close();
        }
    }

    

    protected void lnkLogOutBtn_Click(object sender, EventArgs e)
    {
        // Added by Varun on 01/Dec/2019
        Session["UserName"] = null;
        Response.Redirect("~/LoginPage.aspx", false);
    }
    protected void imgHome_Click(object sender, ImageClickEventArgs e)
    {
        Response.Redirect("~/JobOrder/SurveyDefaultWindow.aspx", false);
    }
    protected void rdbSelectKpi_OnCheckedChanged(object sender, EventArgs e)
    {
        try
        {
            RadioButton rdoBtn = sender as RadioButton;
            //Session["RdoBtn"] = rdoBtn;
            GridViewRow gvrow = rdoBtn.NamingContainer as GridViewRow;
            //GridView gv = rdoBtn.Parent.Parent as GridView;
            //Int16 rdoSelectIdx = 2;
            //foreach (GridViewRow row in gvViewVendors.Rows)
            //{
            //    if (row.RowIndex != gvrow.RowIndex)
            //    {
            //        ((System.Web.UI.WebControls.RadioButton)row.FindControl("rdbSelectCmp")).Checked = false;
            //    }
            //}
            //for (int itemRow = 0; itemRow < gvViewVendors.Rows.Count; itemRow++)
            //{
            //    if (gvViewVendors.Rows[itemRow].RowIndex != gvrow.RowIndex)
            //    {
            //        ((RadioButton)gvViewVendors.FindControl("gvViewVendors_ctl0" + rdoSelectIdx++ + "_rdbSelectCmp")).Checked = false;
            //    }
            //}

            recID = ((Label)gvrow.FindControl("lblID")).Text;
            //string cmpID = Session["CmpID"].ToString();
            SqlConnection sqlCon = null;
            using (sqlCon = new SqlConnection(eBookConn))
            {
                sqlCon.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = sqlCon;
                cmd.CommandText = "select kpiYear, kpiQtr, SURVKPI from SurveyKPI where ID=@recID";
                cmd.Parameters.AddWithValue("@recID", recID);                 
                SqlDataReader sqlDtReader = cmd.ExecuteReader();
                sqlDtReader.Read();                 
                ddlKPIYear.SelectedValue = sqlDtReader["kpiYear"].ToString();
                ddlKPIQuarter.SelectedValue = sqlDtReader["kpiQtr"].ToString();
                txtSurveyKPI.Text = sqlDtReader["SURVKPI"].ToString();                 
                sqlDtReader.Close();                 
                //FillGridView("CR");
                //FillGridView("SD");
            }
        }
        catch (Exception ex)
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Error occurred while retrieving the information of the vendor from the database')</script>", false);
        }
        //gvViewVendors.DataSource 
    }
}