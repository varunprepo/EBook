﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using Datalayer;
using System.Data;

public partial class GIS_SearchGISData : System.Web.UI.Page
{
    string connValue = System.Configuration.ConfigurationManager.ConnectionStrings["EBSDEBookConn"].ConnectionString;
    string _prjCode = string.Empty; string flag = string.Empty;
    int jobType = 0;
    string _userName = string.Empty; int cntID = 0;
    static IList<string> userRightsColl = null;


    protected void lnkJobOrderJobNo_Click(object sender, EventArgs e)     //ForCommitted
    {
        try
        {
            LinkButton lnkJobID = (LinkButton)sender;
            GridViewRow gvr = (GridViewRow)lnkJobID.NamingContainer;

            Session["JobID"] = ((HtmlGenericControl)gvr.FindControl("divJobID")).InnerText;

            Session["UrlRef"] = Request.Url.AbsoluteUri;

            Response.Redirect("~/GIS/GISDetails.aspx?JobID= " + Session["JobID"] + "", false);

          //  Response.Redirect("~/DCOnline/Default9.aspx?JobID= " + Session["JobID"] + "", false);

            

            //  Response.Redirect("~/DCLog/DcLogDetails.aspx?JobID= " + Session["JobID"] + "", false);

        }
        catch
        {

        }
    }
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["UserName"] == null)
        {
            Response.Redirect("~/LoginPage.aspx", false);
            return;
        }

        string chartStatus = string.Empty;

        userRightsColl = (IList<string>)Session["UserRightsColl"];

        if (Session["ProjectCode"] != null)
            _prjCode = Session["ProjectCode"].ToString(); // Request.QueryString["ProjCode"];      

        if (Session["Flag"] != null)
            flag = Session["Flag"].ToString();

        cntID = new JobOrderData().getUserID(_userName);

        if (!IsPostBack)
        {
            loadData();
        }
    }
    private void loadData()
    {
        DataTable dt = new DataTable();

        int sectionID = Convert.ToInt16(Session["SectionID"]);
     

        DataView dvCommitted = new DataView();
        if (_prjCode == null)
        {
            dt = FillTab2(0, "");     //  SearchJob


            Session["ChartJobs"] = dt;
            gvJoborder.DataSource = dt;
            gvJoborder.DataBind();

     

          //  lblCnt.Text = dt.Rows.Count.ToString();

        }
        else
        {
            dt = FillTab2(0, _prjCode);

            Session["ChartJobs"] = dt;
            gvJoborder.DataSource = dt;
            gvJoborder.DataBind();

           // lblCnt.Text = dt.Rows.Count.ToString();
        }

    }
    private DataTable FillTab2(int searchType, string _prjCode)
    {
        DataSet ds = new DataSet();
        try
        {
            Int16 dptID;
            Int16.TryParse("0", out dptID);

            Int16 consID;

            Int16 jobType;
            Int16.TryParse("0", out jobType);

            Int16 jobStatus;
            jobStatus = 1;
            Int16.TryParse("0", out jobStatus);

            Int16 docRefID;
            Int16.TryParse("0", out docRefID);


            Int16 qsID;
           
                qsID = -1;
                Int16.TryParse(qsID.ToString(), out qsID);
            

            Int16 coOrdID;
           
                coOrdID = -1;
                Int16.TryParse(coOrdID.ToString(), out coOrdID);
           

            string prjTitle = string.Empty;
           

            string cntrNo = string.Empty;
           

            string txtfrom = string.Empty;
          

            string txtTo = string.Empty;



            ds = (new JobOrderData().GetGISLogDetails(jobType, jobStatus, dptID, qsID, prjTitle, txtfrom, txtTo, coOrdID, cntrNo)); // GIS_SearchJobLog

            // ds = (new JobOrderData().GetDCULogDetails(jobType, jobStatus, afrID, dptID, qsID, ceID, peID, prjTitle, cntrID, consultID, prjCode));

        }
        catch (Exception ex)
        {

        }
        return ds.Tables[0];
    }
    protected void gvJoborder_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        gvJoborder.PageIndex = e.NewPageIndex;
        bindGridView();

        DataTable dt = new DataTable();
        dt = FillTab2(0, "");

        Session["ChartJobs"] = dt;

        gvJoborder.DataSource = dt;
        gvJoborder.DataBind();
    }
    private void bindGridView()
    {
        gvJoborder.DataSource = Session["ChartJobs"];
        gvJoborder.DataBind();

    }
    protected void gvJoborder_RowCommand(object sender, GridViewCommandEventArgs e)
    {

    }
    protected void gvJoborder_RowDataBound(object sender, GridViewRowEventArgs e)
    {

    }
    protected void btnDcLog_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/GIS/GISData.aspx", false);
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        //if (userRightsColl.Contains("2"))
           Response.Redirect("~/GIS/GISServiceReq.aspx", false);
    }
    protected void txtJobNo_TextChanged(object sender, EventArgs e)
    {
        Session["OnGoingJobStatus"] = null;

        DataTable dt = new DataTable();
        dt = gis_PartialSearchLogJobNo();

        gvJoborder.DataSource = dt;
        gvJoborder.DataBind();

       // lblCnt.Text = dt.Rows.Count.ToString();
    }
    private DataTable gis_PartialSearchLogJobNo()
    {
        DataSet ds = new DataSet();
        try
        {
            string _jobNo = string.Empty;
            if (txtJobNo.Text != "")
                _jobNo = "%" + txtJobNo.Text + "%";

            string _refNo = string.Empty;
            _refNo = "";

            string _contractNo = string.Empty;
            _contractNo = "";

            string _clsrefNo = string.Empty;
            _clsrefNo = "";

            ds = (new JobOrderData().PartialSearchGISLog(_jobNo, _refNo, _contractNo, _clsrefNo));       
        }
        catch (Exception ex)
        {

        }
        return ds.Tables[0];
    }
   
}