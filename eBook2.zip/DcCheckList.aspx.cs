﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Text.RegularExpressions;
using System.IO;
using Microsoft.Office.Interop.Word;
using System.Runtime.InteropServices;
using System.Reflection;
using System.Drawing;

public partial class DcCheckList : System.Web.UI.Page
{
    string connValue = System.Configuration.ConfigurationManager.ConnectionStrings["EBSDEBookConn"].ConnectionString;

    IList<string> lsttxtColl = new List<string>();
    IList<string> lstChkBoxColl = new List<string>();
    private int numOfRows = 0;
    private int _jobID = 0;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
            getDCJobData(_jobID);
    }
    int chkListType = 0;
    protected void Page_Init(object sender, EventArgs e)
    {
        if (Session["ChkListPayID"] != null)
            _jobID = Convert.ToInt32(Session["ChkListPayID"]);
        else
            return;

       
        if (Session["PayTypeChk"].ToString().Equals("1"))
            chkListType = 1;

        else if (Session["PayTypeChk"].ToString().Equals("2"))
            chkListType = 2;

        else if (Session["PayTypeChk"].ToString().Equals("3"))
            chkListType = 3;

        else if (Session["PayTypeChk"].ToString().Equals("4"))
            chkListType = 4;     

        lblPayType.Text = chkListType.ToString();

        fillData(chkListType);
        fillCheckedData(_jobID);
        numOfRows = lsttxtColl.Count();
        GenerateTable(numOfRows); 

    }
   
    private IList<string> fillCheckedData(int jobID)
    {

        string sqlQuery = " SELECT check1, check2, check3, check4, check5, check6, check7, check8, check9, check10, check11, check12, check13, check14, check15, check16, check17, check18  from dcCheckList where jobID =" + _jobID + "";

        using (SqlConnection objCon = new SqlConnection(connValue))
        {
            objCon.Open();
            SqlCommand objCmd = new SqlCommand(sqlQuery, objCon);
            using (SqlDataReader dr = objCmd.ExecuteReader())
            {
                while (dr.Read())
                {
                    lstChkBoxColl.Add(dr["check1"].ToString());
                    lstChkBoxColl.Add(dr["check2"].ToString());
                    lstChkBoxColl.Add(dr["check3"].ToString());
                    lstChkBoxColl.Add(dr["check4"].ToString());
                    lstChkBoxColl.Add(dr["check5"].ToString());
                    lstChkBoxColl.Add(dr["check6"].ToString());
                    lstChkBoxColl.Add(dr["check7"].ToString());
                    lstChkBoxColl.Add(dr["check8"].ToString());
                    lstChkBoxColl.Add(dr["check9"].ToString());
                    lstChkBoxColl.Add(dr["check10"].ToString());
                    lstChkBoxColl.Add(dr["check11"].ToString());
                    lstChkBoxColl.Add(dr["check12"].ToString());
                    lstChkBoxColl.Add(dr["check13"].ToString());
                    lstChkBoxColl.Add(dr["check14"].ToString());
                    lstChkBoxColl.Add(dr["check15"].ToString());
                    lstChkBoxColl.Add(dr["check16"].ToString());
                    lstChkBoxColl.Add(dr["check17"].ToString());
                    lstChkBoxColl.Add(dr["check18"].ToString());
                }
            }
        }

        return lstChkBoxColl;
    }

    private void GenerateTable(int rowsCount)
    {
        System.Web.UI.WebControls.Table table = new System.Web.UI.WebControls.Table();
        
        table.ID = "Table1";
        Page.Form.Controls.Add(table);

        TableRow rowHeader = new TableRow();
        TableCell cellHeader = new TableCell();
        cellHeader.Text = "Terms of Reference for Check";     
        rowHeader.Cells.Add(cellHeader);
        table.Rows.Add(rowHeader);       
        const int colsCount = 2;
        for (int i = 0; i < numOfRows; i++)
        {
            TableRow row = new TableRow();
            for (int j = 0; j < colsCount; j++)
            {
                if (j == 0)
                {
                    TableCell cell = new TableCell();
                    TextBox tb = new TextBox();
                    tb.Text = lsttxtColl[i].ToString();

                    tb.ID = "TextBoxRow_" + i + "Col_" + j;
                    tb.Width = 800;
                    cell.Controls.Add(tb);
                    row.Cells.Add(cell);
                }
                else if (j == 1)
                {
                    TableCell cell2 = new TableCell();

                    System.Web.UI.WebControls.DropDownList drpList = new System.Web.UI.WebControls.DropDownList();
                    drpList.AutoPostBack = true;

                    drpList.SelectedIndexChanged += new EventHandler(SelectedIndexChanged);
                            //lstChkBoxColl[i]

                    drpList.ID = "check" + (i + 1);

                    if (drpList.DataSource == null)
                        PopulateDropDownBox(drpList, "SELECT dcChkTypeID,chkName FROM DcCheckType", "dcChkTypeID", "chkName");  // where JobStatusid in(5,6,7,8)

                    drpList.SelectedValue = lstChkBoxColl[i];  

                    cell2.Controls.Add(drpList);
                    row.Cells.Add(cell2);
                }   
            
                table.Rows.Add(row);
            }
            rowsCount++;
            ViewState["RowsCount"] = rowsCount;
        }
    }
    private void PopulateDropDownBox(DropDownList ddlBox, string sqlQuery, string valueMember, string displayName)
    {
        System.Data.DataTable table = new System.Data.DataTable();

        try
        {
            using (SqlConnection sqlConn = new SqlConnection(connValue))
            {
                using (SqlDataAdapter da = new SqlDataAdapter(sqlQuery, sqlConn))
                {
                    sqlConn.Open();
                    da.Fill(table);
                }
            }
            //cmbBox.Items.Add("Select");
            ddlBox.DataSource = table;
            ddlBox.DataTextField = displayName;
            ddlBox.DataValueField = valueMember;
            ddlBox.SelectedIndex = -1;

            ddlBox.DataBind();
            ddlBox.Items.Insert(0, new ListItem("--Select--"));
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    protected void SelectedIndexChanged(object sender, EventArgs e)
    {
        DropDownList ddl = (DropDownList)sender;
        if (ddl.SelectedIndex != 0)
        {
            string ID = ddl.ID;
            string DcreqID = ddl.SelectedValue;
            string jobID = ddl.ToolTip;

            UpdateJobDCRequest(Convert.ToInt32(DcreqID), ID);           
        }
    }
    private void UpdateJobDCRequest(int reqID,string clmName)
    {
        // SELECT dcChkTypeID,chkName FROM DcCheckType

        string UpdateQuery = "Update dcCheckList Set " + clmName + "  =" + reqID + " Where jobID = " + _jobID + " ";
        SqlConnection con = new SqlConnection(connValue);
        con.Open();
        SqlCommand com = new SqlCommand(UpdateQuery, con);
        com.ExecuteNonQuery();
        con.Close();
    }
    protected void chk_CheckedChanged(object sender, EventArgs e)
    {

        System.Web.UI.WebControls.CheckBox currentCheckbox = sender as System.Web.UI.WebControls.CheckBox;
        string clmName = currentCheckbox.ID;
        updateWordData(clmName, currentCheckbox.Checked);
        string extractInteger = Regex.Match(currentCheckbox.ID, @"\d+").Value;
        //Label currentlabel = (Label)Labeldiv.FindControl("Label" + extractInteger);
    }

    private void updateWordData(string clmName, Boolean chkStat)
    {
        //string UpdateQuery = "Update payCheckList Set isChk ='" + chkStat + "' Where transID = " + privID + " ";

        string UpdateQuery = "Update dcCheckList Set " + clmName + "  ='" + chkStat + "' Where jobID = " + _jobID + " ";
        SqlConnection con = new SqlConnection(connValue);
        con.Open();
        SqlCommand com = new SqlCommand(UpdateQuery, con);
        com.ExecuteNonQuery();
        con.Close();

        fillCheckedData(100);
    }
    private IList<string> fillData(int chkListTypeID)
    {

        // string sqlQuery = " SELECT CheckNo, CheckList  from dcCheckListData where listTypID = " + chkListTypeID + "";

        string sqlQuery = "SELECT dcChkListID, checkNo, checkList FROM DCCheckListData WHERE listTypeID =  " + chkListTypeID + "";

        using (SqlConnection objCon = new SqlConnection(connValue))
        {
            objCon.Open();
            SqlCommand objCmd = new SqlCommand(sqlQuery, objCon);
            using (SqlDataReader dr = objCmd.ExecuteReader())
            {
                while (dr.Read())
                {
                    lsttxtColl.Add(dr["CheckList"].ToString());
                }
            }
        }

        return lsttxtColl;
    }

    protected void Button1_Click1(object sender, EventArgs e)
    {

    }
    protected void btnWord_Click(object sender, EventArgs e)
    {

    }
    protected void txtPrjMngr_TextChanged(object sender, EventArgs e)
    {

    }
    private void getDCJobData(int jobID)
    {
        string sqlQuery = "SELECT Job.jobID, Job.jobNo, Department.deptName, Company.cmpName, ProjCoordinator.coordName, Job.committmentNo  " +
                     " FROM    Job INNER JOIN     Department ON Job.deptID = Department.departmentID LEFT OUTER JOIN  ProjCoordinator ON Job.projCoordinatorID = ProjCoordinator.prjCoordID LEFT OUTER JOIN " +
                       "   Company ON Job.contractorID = Company.companyID WHERE (Job.jobID = " + _jobID + ")";
        using (SqlConnection objCon = new SqlConnection(connValue))
        {
            objCon.Open();
            using (SqlCommand objCmd = new SqlCommand(sqlQuery, objCon))
            {
                using (SqlDataReader dr = objCmd.ExecuteReader())
                {
                    while (dr.Read())
                    {
                        txtPrjMngr.Text = dr["coordName"].ToString();
                        lblDept.Text = dr["deptName"].ToString();
                        lblCntr.Text = dr["cmpName"].ToString();
                        lblCommtment.Text = dr["committmentNo"].ToString();
                    }
                }
            }
        }        
    }
    private void CreateDCCheckList()
    {
        string srcPath = string.Empty;
        string destPath = string.Empty;

        lnkDownload.Text = "Create Link";

        string strTemp = string.Empty;
          
        if (chkListType == 1)
        {
            srcPath = @"D:\ASD.docx";
            strTemp = "C:\\eBookPaymentFiles\\ " + _jobID + "_" + "ASD.docx";
        }
        else if (chkListType == 2)
        {
            srcPath = @"D:\ASD_2.docx";
            strTemp = "C:\\eBookPaymentFiles\\ " + _jobID + "_" + "ASD_2.docx";
        }
        else if (chkListType == 3)
        {
            srcPath = @"D:\ASD_3.docx";
            strTemp = "C:\\eBookPaymentFiles\\ " + _jobID + "_" + "ASD_3.docx";
        }
        else if (chkListType == 4)
        {
            srcPath = @"D:\ASD_4.docx";
            strTemp = "C:\\eBookPaymentFiles\\ " + _jobID + "_" + "ASD_4.docx";
        }

        destPath = strTemp;  
        CreateWordDocNew(srcPath, destPath);

        lnkDownload.Enabled = true;
        lnkDownload.Text = "DownLoad_Link";
    }    
    protected void lnkDownload_Click1(object sender, EventArgs e)
    {
        LinkButton lnkbtn = sender as LinkButton;
        GridViewRow gvrow = lnkbtn.NamingContainer as GridViewRow;
        string filePath = "C:\\eBookPaymentFiles\\ " + _jobID + "_" + "ASD.docx";
        Response.ContentType = "image/jpg";
        Response.AddHeader("Content-Disposition", "attachment;filename=\"" + filePath + "\"");      
        Response.TransmitFile(filePath);
        Response.End();
    }
    protected void btnDClist_Click(object sender, EventArgs e)
    {
        CreateDCCheckList();
    }
    private void CreateWordDocNew(Object fileName, object saveAs)
    {
        object missing = System.Reflection.Missing.Value;
        Microsoft.Office.Interop.Word.Application wordApp = new Microsoft.Office.Interop.Word.ApplicationClass();
        Microsoft.Office.Interop.Word.Document aDoc = null;      
        wordApp.Visible = true;
        wordApp.DisplayAlerts = Microsoft.Office.Interop.Word.WdAlertLevel.wdAlertsNone;
        wordApp.DisplayAlerts = WdAlertLevel.wdAlertsNone; 
      
        try
        {
            if (File.Exists((string)fileName))
            {
                

                object readOnly = false;
                object isVisible = false;
                wordApp.Visible = false;

                aDoc = wordApp.Documents.Open(ref fileName, ref missing, ref readOnly, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref isVisible, ref missing, ref missing, ref missing, ref missing);
                //aDoc.Activate();

                if (aDoc.Bookmarks.Exists("txtContractor"))
                {
                    Microsoft.Office.Interop.Word.Bookmark bm = aDoc.Bookmarks["txtContractor"];
                    Microsoft.Office.Interop.Word.Range range = bm.Range.Duplicate;
                    aDoc.FormFields["txtContractor"].Result = lblCntr.Text;
                }
                if (aDoc.Bookmarks.Exists("txtContractNo"))
                {
                    Microsoft.Office.Interop.Word.Bookmark bm = aDoc.Bookmarks["txtContractNo"];
                    Microsoft.Office.Interop.Word.Range range = bm.Range.Duplicate;
                    aDoc.FormFields["txtContractNo"].Result = lblCommtment.Text;
                }         
            }
            else
            {
                Label1.Text = "Source File is Not exist";
                return;
            }

            aDoc.SaveAs(ref saveAs, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing);
           
            object saveChanges = Microsoft.Office.Interop.Word.WdSaveOptions.wdPromptToSaveChanges;
            object originalFormat = Microsoft.Office.Interop.Word.WdOriginalFormat.wdWordDocument;
            object routeDocument = true;

            object missingValue = Type.Missing;

            ((Microsoft.Office.Interop.Word._Document)aDoc).Close(ref saveChanges, ref originalFormat, ref routeDocument);

            ((Microsoft.Office.Interop.Word._Application)wordApp.Application).Quit(ref missingValue, ref missingValue, ref missingValue);
        }
        catch (Exception ex)
        {
            throw ex;            
        }
        finally
        {
            if (aDoc != null)
                System.Runtime.InteropServices.Marshal.ReleaseComObject(aDoc);

            if (wordApp != null)
                System.Runtime.InteropServices.Marshal.ReleaseComObject(wordApp);

            wordApp = null;
            aDoc = null;
            GC.Collect();
            GC.WaitForPendingFinalizers();
        }        
    }
    public void EndProcess()
    {
        System.Diagnostics.Process[] p = System.Diagnostics.Process.GetProcesses();
        for (int l = 0; l < p.Length; l++)
        {
            if (p[l].ProcessName.ToLower() == "winword")
            {
                p[l].Kill();
            }
        }
    }
    private void CreateWordDoc(Object fileName, object saveAs)
    {
        // Commitment No.  Submission No. :  Consultant Name :  Checked by:   Date  : 

        object missing = System.Reflection.Missing.Value;
        Microsoft.Office.Interop.Word.Application wordApp = new Microsoft.Office.Interop.Word.ApplicationClass();
        Microsoft.Office.Interop.Word.Document aDoc = null;
       
        if (File.Exists((string)fileName))
        {
            object readOnly = false; object isVisible = false; wordApp.Visible = false;
            aDoc = wordApp.Documents.Open(ref fileName, ref missing, ref readOnly, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref isVisible, ref missing, ref missing, ref missing, ref missing);
            aDoc.Activate();

            if (aDoc.Bookmarks.Exists("txtContractor"))
            {
                Microsoft.Office.Interop.Word.Bookmark bm = aDoc.Bookmarks["txtContractor"];
                Microsoft.Office.Interop.Word.Range range = bm.Range.Duplicate;
                aDoc.FormFields["txtContractor"].Result = lblCntr.Text;
            }
            if (aDoc.Bookmarks.Exists("txtContractNo"))
            {
                Microsoft.Office.Interop.Word.Bookmark bm = aDoc.Bookmarks["txtContractNo"];
                Microsoft.Office.Interop.Word.Range range = bm.Range.Duplicate;
                aDoc.FormFields["txtContractNo"].Result = lblCommtment.Text;
            }            
        }


       // aDoc.SaveAs2(ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing);     


       // aDoc.SaveAs(ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing);     

       // aDoc.Close(ref missing, ref missing, ref missing);




        Object fileNameNew = (Object)saveAs;
        Object fileformat = Microsoft.Office.Interop.Word.WdSaveFormat.wdFormatDocument;
        Object SaveChange = Microsoft.Office.Interop.Word.WdSaveOptions.wdDoNotSaveChanges;
        Object OrianalForamt = Microsoft.Office.Interop.Word.WdOriginalFormat.wdOriginalDocumentFormat;

        aDoc.Activate();



        aDoc.SaveAs2(ref fileNameNew, ref fileformat, ref missing, ref missing, ref missing, ref missing,
                  ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing);

        aDoc.Saved = true;
      //  aDoc.Close(ref SaveChange, ref missing, ref missing);
        
      //  aDoc.Quit(ref SaveChange, ref OrianalForamt, ref missing);
    }

    private void createDocForDC(string SavePath)
    {
        object oMissing = System.Reflection.Missing.Value;
        object oEndOfDoc = "\\endofdoc";

        object missing = System.Reflection.Missing.Value;

        object confirmConversions = Type.Missing;
        object readOnly = Type.Missing;
        object addToRecentFiles = Type.Missing;
        object passwordDoc = Type.Missing;
        object passwordTemplate = Type.Missing;
        object revert = Type.Missing;
        object writepwdoc = Type.Missing;
        object writepwTemplate = Type.Missing;
        object format = Type.Missing;
        object encoding = Type.Missing;
        object visible = Type.Missing;
        object openRepair = Type.Missing;
        object docDirection = Type.Missing;
        object notEncoding = Type.Missing;
        object xmlTransform = Type.Missing;

        Microsoft.Office.Interop.Word._Application oWord;
        Microsoft.Office.Interop.Word._Document oDoc;
        oWord = new Microsoft.Office.Interop.Word.Application();
        oWord.Visible = true;

        Object fileName = (Object)SavePath;
        Object fileformat = Microsoft.Office.Interop.Word.WdSaveFormat.wdFormatPDF;
        Object SaveChange = Microsoft.Office.Interop.Word.WdSaveOptions.wdDoNotSaveChanges;
        Object OrianalForamt = Microsoft.Office.Interop.Word.WdOriginalFormat.wdOriginalDocumentFormat;

        oDoc = oWord.Documents.Open(ref fileName, ref confirmConversions, ref readOnly, ref addToRecentFiles,
            ref passwordDoc, ref passwordTemplate, ref revert, ref writepwdoc, ref writepwTemplate, ref format, ref encoding, ref visible, ref openRepair,
            ref docDirection, ref notEncoding, ref xmlTransform); 

        oDoc.Activate();

        if (oDoc.Bookmarks.Exists("txtContractor"))
        {
            Microsoft.Office.Interop.Word.Bookmark bm = oDoc.Bookmarks["txtContractor"];
            Microsoft.Office.Interop.Word.Range range = bm.Range.Duplicate;
            oDoc.FormFields["txtContractor"].Result = lblCntr.Text;
        }
        if (oDoc.Bookmarks.Exists("txtContractNo"))
        {
            Microsoft.Office.Interop.Word.Bookmark bm = oDoc.Bookmarks["txtContractNo"];
            Microsoft.Office.Interop.Word.Range range = bm.Range.Duplicate;
            oDoc.FormFields["txtContractNo"].Result = lblCommtment.Text;
        }     

        oDoc.Saved = true;

        oDoc.SaveAs(ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing);     


        //oDoc.Close(ref SaveChange, ref oMissing, ref oMissing);
       // oWord.Quit(ref SaveChange, ref OrianalForamt, ref oMissing);

    }

    private void button1_Click(object sender, EventArgs e)
    {
        object fileName = "";
        string filePath = "";
        string strSaveasPath = "";
       
        List<string> _list = new List<string>();
        _list.Add("tridip");
        _list.Add("arijit");

     
        object textToFind = "test";
        object readOnly = false;
        Microsoft.Office.Interop.Word._Application word = new Microsoft.Office.Interop.Word.Application();
        Microsoft.Office.Interop.Word.Document doc = new Microsoft.Office.Interop.Word.Document();
        object missing = Type.Missing;
        try
        {
            doc = word.Documents.Open(ref fileName, ref missing, ref readOnly,  ref missing, ref missing, ref missing, ref missing, ref missing, ref missing,  ref missing, ref missing, ref missing, ref missing, ref missing, ref missing,  ref missing);
            doc.Activate();

            object matchPhrase = false;
            object matchCase = false;
            object matchPrefix = false;
            object matchSuffix = false;
            object matchWholeWord = false;
            object matchWildcards = false;
            object matchSoundsLike = false;
            object matchAllWordForms = false;
            object matchByte = false;
            object ignoreSpace = false;
            object ignorePunct = false;

            object highlightedColor = Microsoft.Office.Interop.Word.WdColor.wdColorGreen;
            object textColor = Microsoft.Office.Interop.Word.WdColor.wdColorLightOrange;

            object missingp = false;
            Microsoft.Office.Interop.Word.Range range = doc.Range();

            foreach (string line in _list)
            {
                textToFind = line;
                bool highlighted = range.Find.HitHighlight(ref textToFind,   ref missing,   ref missing,     ref missing,  ref missing,    ref missing,    ref missing,  ref missing,      ref missing,   ref missing, ref missing,      ref missing,    ref missing,  ref missing,      ref missing,    ref missing,ref missing,     ref missing,    ref missing,             ref missing);
            }

            System.Diagnostics.Process.Start(fileName.ToString());
        }
        catch (Exception ex)
        {
            Console.WriteLine("Error : " + ex.Message);
            //Console.ReadKey(true);
        }
        finally
        {
            //doc.Close(missing, missing, missing);
            if (doc != null)
                System.Runtime.InteropServices.Marshal.ReleaseComObject(doc);

            if (word != null)
                System.Runtime.InteropServices.Marshal.ReleaseComObject(word);

            word = null;
            doc = null;
            GC.Collect();
            GC.WaitForPendingFinalizers();
        }


    }
   
}