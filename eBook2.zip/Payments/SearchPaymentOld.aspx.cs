﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using Datalayer;
using System.Data;
using System.Data.SqlClient;
using System.Globalization;
using System.Drawing;
using System.IO;

public partial class Payments_SearchPaymentOld : System.Web.UI.Page
{
     string connValue = System.Configuration.ConfigurationManager.ConnectionStrings["EBSDEBookConn"].ConnectionString;
    IList<string> userRightsColl = new List<string>();
    string profile_Name = string.Empty;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["UserName"] == null)
        {
            Response.Redirect("~/LoginPage.aspx", false);
            return;
        }
       

        userRightsColl = (IList<string>)Session["UserRightsColl"];
        if (!IsPostBack)
        {
            PopulateDropDownBox(ddlAffair, "SELECT departmentID,deptName FROM Department where AffairID is null ", "departmentID", "deptName");
            PopulateDropDownBox(ddlDept, "SELECT departmentID,deptName FROM Department where AffairID is not null  Order By deptName", "departmentID", "deptName");
            PopulateDropDownBox(ddlStaff, "SELECT DISTINCT Contact.contactID, Contact.userShortName FROM   Payment INNER JOIN   Contact ON Payment.qSID = Contact.contactID WHERE (Contact.userShortName IS NOT NULL) order by Contact.userShortName", "contactID", "userShortName");
            PopulateDropDownBox(ddlJobStatus, "SELECT jobStatusID,jobStatusName FROM JobStatus Where jobStatusID in(4,1,3,2)", "jobStatusID", "jobStatusName");
            PopulateDropDownBox(ddlStaffStatus, "SELECT jobStatusID,jobStatusName FROM JobStatus Where jobStatusID in (3,7)", "jobStatusID", "jobStatusName");

            PopulateDropDownBox(ddlYear, "SELECT distinct year(receivedByEBSD1On) as KeyYear,year(receivedByEBSD1On) as FiscYear FROM Payment WHERE (NOT (YEAR(receivedByEBSD1On) IS NULL)) order by FiscYear", "KeyYear", "FiscYear");

           // PopulateDropDownBox(ddlPrjCode, "SELECT payID,commitmentNo FROM payment order by commitmentNo", "payID", "commitmentNo");

            //SqlConnection sqlCon = new SqlConnection(connValue);
            //SqlCommand cmd = new SqlCommand();
            //cmd.CommandType = CommandType.StoredProcedure;
            //cmd.CommandText = "GetPaymentData";
            //cmd.Connection = sqlCon;
            //DataSet ds = new DataSet();
            //SqlDataAdapter da = new SqlDataAdapter(cmd);
            //da.Fill(ds);

            //if (Session["userProfileID"].Equals("1"))
            //    PopulateDropDownBox(ddlStaff, "SELECT Payment.qSID, Contact.firstName + Contact.lastName AS UserName FROM   Payment INNER JOIN  Contact ON Payment.qSID = Contact.contactID ", "qSID", "UserName");
            //else
            //    txtJobNo.Visible = false;

               DataTable dt = searchAll_PayData(); // sp_GetAllPaymentData

               lblCnt.Text =  "Payment Record Count : " + dt.Rows.Count.ToString();

               Session["getPayData"] = dt;

               grvPaySearch.DataSource = dt;              
               grvPaySearch.DataBind();

               lblDate.Text = System.DateTime.Now.ToString();

               CheckBox1.Checked = false;
        }
    
    }
   
    private void PopulateDropDownBox(DropDownList ddlBox, string sqlQuery, string valueMember, string displayName)
    {
        ddlBox.DataBound += new EventHandler(this.ddlBox_DataBound);
        ddlBox.DataSource = new JobOrderData().FillDropdown(sqlQuery);
        ddlBox.DataTextField = displayName;
        ddlBox.DataValueField = valueMember;
        ddlBox.SelectedIndex = -1;
        ddlBox.DataBind();
    }
    protected void ddlBox_DataBound(object sender, EventArgs e)
    {
        DropDownList ddl = (DropDownList)sender;
        ListItem emptyItem = new ListItem("", "");
        ddl.Items.Insert(0, emptyItem);
    }
    protected void lnkPaymentData_Link(object sender, EventArgs e)     //ForCommitted
    {
        try
        {
            LinkButton lnkJobID = (LinkButton)sender;
            GridViewRow gvr = (GridViewRow)lnkJobID.NamingContainer;
            Session["PayID"] = ((HtmlGenericControl)gvr.FindControl("divpayID")).InnerText;

            Session["UrlRef"] = Request.Url.AbsoluteUri;
            Response.Redirect("~/Payments/PaymentDetails.aspx?PayID = " + Session["PayID"] + "", false);
        }
        catch
        {

        }
    }
    private DataTable FillTab2()
    {
        DataSet ds = new DataSet();
        try
        {
            Int32 qsID;
            if (Session["userProfileID"].Equals("1"))
            {
                qsID = 0;
                Int32.TryParse(qsID.ToString(), out qsID);
            }
            else
                Int32.TryParse(txtJobNo.Text, out qsID);

            ds = (new JobOrderData().GetViewPayOrderDetails(qsID));
           
        }
        catch (Exception ex)
        {

        }
        return ds.Tables[0];
    }

    protected void grvPaySearch_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        grvPaySearch.PageIndex = e.NewPageIndex;
       // bindGridView();

        DataTable dt = new DataTable();
        dt = Session["getPayData"] as DataTable;
        grvPaySearch.DataSource = dt;
        grvPaySearch.DataBind();

        lblCnt.Text = "Payment Record Count :" + dt.Rows.Count.ToString();
    }
    private void bindGridView()
    {
        grvPaySearch.DataSource = Session["getPayData"];
        grvPaySearch.DataBind();
    }
    protected void ddlJobNo_SelectedIndexChanged(object sender, EventArgs e)
    {

    }   
    protected void btnSearch_Click(object sender, EventArgs e)
    {
        DataTable dt = new DataTable();

        //if ((ddlStaff.SelectedIndex == 0) & (ddlStaffStatus.SelectedIndex == 0))
        //    dt = searchAll_PayData();
        //else
        //    dt = searchAll_PayDataByStaff();

        dt = searchAll_PayData();            //sp_GetAllPaymentData

        Session["getPayData"] = dt;

        grvPaySearch.DataSource = dt;
        grvPaySearch.DataBind();

        lblCnt.Text = "Payment Record Count : " + dt.Rows.Count.ToString();
    }
    protected void btnClear_Click(object sender, EventArgs e)
    {
        ddlAffair.SelectedIndex = 0;
        ddlDept.SelectedIndex = 0;

        ddlYear.SelectedIndex = 0;

        ddlStaffStatus.SelectedIndex = 0;
        ddlJobStatus.SelectedIndex = 0;

        ddlStaff.SelectedIndex = 0;

        txtStartDate.Text = "";
        txtEndDate.Text = "";

        txtJobNo.Text = "";
        txtCntrNo.Text = "";
        txtBudjetRef.Text = "";

        txtReturnFinStrDate.Text = "";
        txtReturnFinEndDate.Text = "";


        DataTable dt = new DataTable();
        dt = searchAll_PayData();        

        Session["getPayData"] = dt;

        grvPaySearch.DataSource = dt;
        grvPaySearch.DataBind();

        lblCnt.Text = "Payment Record Count : " + dt.Rows.Count.ToString();
    }
    protected void btnBack_Click(object sender, EventArgs e)
    {    
      if (Session["UrlRef"] != null)
          Response.Redirect(Session["UrlRef"].ToString(), false);
      else
          Response.Redirect("~/Payments/ViewPayments.aspx", false);
    }
   
    private DataTable searchPaymentByPaymentNo()
    {
        DataSet ds = new DataSet();
        try
        {            
            string payJobNo = string.Empty;

           
            if (txtJobNo.Text != "")
                payJobNo = "%" + txtJobNo.Text + "%";

            ds = (new JobOrderData().GetPayOrderDetailsByJobNo(payJobNo));   // sp_GetPaymentDataByJobNo
        }
        catch (Exception ex)
        {

        }
        return ds.Tables[0];
    }
    protected void txtJobNo_TextChanged(object sender, EventArgs e)
    {
        DataTable dt = new DataTable();
        dt = searchPaymentByPaymentNo();
        grvPaySearch.DataSource = dt;
        grvPaySearch.DataBind();

        lblCnt.Text = "Payment Record Count :" + dt.Rows.Count.ToString();
    }
    private DataTable searchAll_PayData()
    {
        DataSet ds = new DataSet();
        try
        {
            Int32 qsID;           
            Int32.TryParse(ddlStaff.SelectedValue, out qsID);

            Int32 deptID;
            Int32.TryParse(ddlDept.SelectedValue, out deptID);

            Int32 affairID;
            Int32.TryParse(ddlAffair.SelectedValue, out affairID);

            //Int32 jobTypeID;
            //Int32.TryParse(ddlStaffStatus.SelectedValue, out jobTypeID);

            Int32 jobStatusID;
            Int32.TryParse(ddlJobStatus.SelectedValue, out jobStatusID);

            Int32 staffStatusID;
            Int32.TryParse(ddlStaffStatus.SelectedValue, out staffStatusID);

             string payJobNo = string.Empty;
           
             string startDate = string.Empty;
            if (txtStartDate.Text != "")
                startDate = txtStartDate.Text;

            string endDate = string.Empty;
            if (txtEndDate.Text != "")
                endDate = txtEndDate.Text;

            string strYear = string.Empty;
            if (ddlYear.SelectedItem.Text != "")
                strYear = ddlYear.SelectedItem.Text;

            string strBudRef = string.Empty;
            if (txtBudjetRef.Text != "")
                strBudRef = txtBudjetRef.Text;           


            string committmentNo = string.Empty;  
            if (txtCntrNo.Text != "")
                committmentNo = "" + txtCntrNo.Text + "";
            committmentNo = committmentNo.Replace(" ", "").Replace("/", "").Replace("-", "");

            string RetunFinStrDate = string.Empty;
            if (txtReturnFinStrDate.Text != "")
                RetunFinStrDate = txtReturnFinStrDate.Text;

            string RetunFinEndDate = string.Empty;
            if (txtReturnFinEndDate.Text != "")
                RetunFinEndDate = txtReturnFinEndDate.Text;

            //string cntrID = string.Empty;
            //if (ddlContractor.SelectedValue != "")
            //    cntrID = ddlContractor.SelectedItem.Text;

            //string paymentFor = string.Empty;
            //if (ddlPayFor.SelectedValue != "")
            //    paymentFor = ddlPayFor.SelectedItem.Text;

            //Int32 payTypeID;
            //Int32.TryParse(ddlPayType.SelectedValue, out payTypeID);
            // GetAllPayOrderDetailsByStaff

            //ds = (new JobOrderData().GetAllPayOrderDetails(staffStatusID, jobStatusID, affairID, deptID, qsID, startDate, endDate, strYear, strBudRef, committmentNo, RetunFinStrDate, RetunFinEndDate, cntrID, paymentFor, payTypeID));   //sp_GetPaymentDataByJobNo     //sp_GetAllPaymentData
        }
        catch (Exception ex)
        {

        }
        return ds.Tables[0];
    }

    private DataTable searchAll_PayDataByStaff()
    {
        DataSet ds = new DataSet();
        try
        {
            Int32 qsID;
            Int32.TryParse(ddlStaff.SelectedValue, out qsID);

            Int32 deptID;
            Int32.TryParse(ddlDept.SelectedValue, out deptID);

            Int32 affairID;
            Int32.TryParse(ddlAffair.SelectedValue, out affairID);

            //Int32 jobTypeID;
            //Int32.TryParse(ddlStaffStatus.SelectedValue, out jobTypeID);

            Int32 jobStatusID;
            Int32.TryParse(ddlJobStatus.SelectedValue, out jobStatusID);

            Int32 staffStatusID;
            Int32.TryParse(ddlStaffStatus.SelectedValue, out staffStatusID);

            string payJobNo = string.Empty;

            string startDate = string.Empty;
            if (txtStartDate.Text != "")
                startDate = txtStartDate.Text;

            string endDate = string.Empty;
            if (txtEndDate.Text != "")
                endDate = txtEndDate.Text;

            string strYear = string.Empty;
            if (ddlYear.SelectedItem.Text != "")
                strYear = ddlYear.SelectedItem.Text;

            string strBudRef = string.Empty;
            if (txtBudjetRef.Text != "")
                strBudRef = txtBudjetRef.Text;

            string committmentNo = string.Empty;
            if (txtCntrNo.Text != "")
                committmentNo = "" + txtCntrNo.Text + "";
            committmentNo = committmentNo.Replace(" ", "").Replace("/", "").Replace("-", "");

            ds = (new JobOrderData().GetAllPayOrderDetailsByStaff(staffStatusID, jobStatusID, affairID, deptID, qsID, startDate, endDate, strYear, strBudRef, committmentNo));       //sp_GetAllPaymentDataByStaff
        }
        catch (Exception ex)
        {

        }
        return ds.Tables[0];
    }
    protected void txtCntrNo_TextChanged(object sender, EventArgs e)
    {    
        DataTable dt = new DataTable();
        dt = SearchPayByCommittmentNo();
        grvPaySearch.DataSource = dt;
        grvPaySearch.DataBind();

        lblCnt.Text = "Payment Record Count :" + dt.Rows.Count.ToString();
        if (dt.Rows.Count.ToString() == "0")
        {
            lblRecords.Visible = true;
            //ClientScript.RegisterClientScriptBlock(this.GetType(), "Popup", "<script>alert('Search results not found.')</script>", false);
        }
        else
            lblRecords.Visible = false;
    }
    private DataTable SearchPayByCommittmentNo()
    {
        DataSet ds = new DataSet();
        try
        {
            string committmentNo = string.Empty;

            //if (txtCntrNo.Text != "")
            //    committmentNo = "%" + txtCntrNo.Text + "%";

            if (txtCntrNo.Text != "")
                committmentNo = "" + txtCntrNo.Text + "";

            committmentNo = committmentNo.Replace(" ", "").Replace("/","").Replace("-","");

            ds = (new JobOrderData().GetPayOrderDetailsByCommittmentNo(committmentNo));     // sp_GetPaymentDataByCommittmentNo
        }
        catch (Exception ex)
        {

        }
        return ds.Tables[0];
    }
    protected void grvPaySearch_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            Label jobNo = (Label)e.Row.FindControl("lblJobNo"); 
          //  Label lblJobRecDate = (Label)e.Row.FindControl("lblCmtRecDate");
            Label lblJobStatus = (Label)e.Row.FindControl("lblJobStatus");

            Label _lblCaluclateDate = (Label)e.Row.FindControl("lblCaluclateDate");

            string calDate = string.Empty;
            if (_lblCaluclateDate.Text != "")
            {
                calDate = getEndDateByGivenDays(_lblCaluclateDate.Text, 7);
            }

            string jobOrderStat = lblJobStatus.Text;    //On-going

            if ((calDate != ""))      
            {
                if ((!jobOrderStat.Equals("Closed")))         //|| (!jobOrderStat.Equals("Cancelled"))
                {
                    if (!jobOrderStat.Equals("Cancelled"))
                    {
                        if (Convert.ToDateTime(calDate) < System.DateTime.Now)
                        {
                            e.Row.BackColor = System.Drawing.Color.LightPink;
                            e.Row.ForeColor = System.Drawing.Color.Red;

                            e.Row.Font.Bold = true;

                            jobNo.BackColor = System.Drawing.Color.Yellow;
                            e.Row.Cells[0].BackColor = System.Drawing.Color.White;
                        }
                    }
                }
            }
        }
    }

    private string getEndDateByGivenDays(string strDate, int workDays)
    {
        SqlConnection con = new SqlConnection(connValue);
        SqlCommand cmd = new SqlCommand();
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Connection = con;

        cmd.CommandText = "AddWorkdays";
        SqlParameter prm = cmd.Parameters.Add("@ad_startDate", SqlDbType.DateTime);
        prm.Value = strDate;
        prm = cmd.Parameters.Add("@actual_workDays", SqlDbType.Int);
        prm.Value = workDays;
        prm = cmd.Parameters.Add("@endDate", SqlDbType.DateTime);
        prm.Direction = ParameterDirection.Output;
        con.Open();
        SqlDataReader dr = cmd.ExecuteReader();
        while (dr.Read())
            Console.WriteLine(dr.GetString(0));
        con.Dispose();
        con.Close();

        return cmd.Parameters[2].Value.ToString();
    }    

    private string getDaysByGivenEndDate(string strDate, string endDate)
    {
        strDate = Convert.ToDateTime(strDate).ToString("MM/dd/yyyy", CultureInfo.InvariantCulture);
        endDate = Convert.ToDateTime(endDate).ToString("MM/dd/yyyy", CultureInfo.InvariantCulture);

        DateTime strDt = DateTime.ParseExact(strDate, "MM/dd/yyyy", CultureInfo.InvariantCulture);
        DateTime endDt = DateTime.ParseExact(endDate, "MM/dd/yyyy", CultureInfo.InvariantCulture);

        SqlConnection con = new SqlConnection(connValue);
        SqlCommand cmd = new SqlCommand();

        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Connection = con;

        cmd.CommandText = "testSP";

        SqlParameter prm = cmd.Parameters.Add("@ad_startDate", SqlDbType.DateTime);
        prm.Value = strDt;

        prm = cmd.Parameters.Add("@ad_endDate", SqlDbType.DateTime);
        prm.Value = endDt;

        prm = cmd.Parameters.Add("@ai_workDays", SqlDbType.Int);
        prm.Direction = ParameterDirection.Output;

        //prm = cmd.Parameters.Add("@as_errMsg", SqlDbType.VarChar);
        //prm.Direction = ParameterDirection.Output;

        con.Open();
        SqlDataReader dr = cmd.ExecuteReader();
        while (dr.Read())
            Console.WriteLine(dr.GetString(0));
        con.Dispose();
        con.Close();

        return cmd.Parameters[2].Value.ToString();
    }


    protected void ddlStaff_SelectedIndexChanged(object sender, EventArgs e)
    {
        //DataTable dt = new DataTable();
        //dt = searchAll_PayDataByStaff();

        //Session["getPayData"] = dt;

        //grvPaySearch.DataSource = dt;
        //grvPaySearch.DataBind();

        //lblCnt.Text = " Record Count : " + dt.Rows.Count.ToString();

        if (ddlStaff.SelectedIndex == 0)
        {
            CheckBox1.Visible = false;
            CheckBox1.Checked = false;
        }
        else
        {
            CheckBox1.Visible = true;
            CheckBox1.Checked = false;
        }
    }
    protected void ddlStaffStatus_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void CheckBox1_CheckedChanged(object sender, EventArgs e)
    {
        DataTable dt = new DataTable();

        if ((ddlStaff.SelectedIndex == 0) & (ddlStaffStatus.SelectedIndex == 0))
        {
            dt = searchAll_PayData();
        }
        else
        {
            if ((CheckBox1.Checked == true))
            {
                dt = searchAll_PayDataByStaff();
                lblCnt.Text = "Payment Task Count : " + dt.Rows.Count.ToString();
            }
            else
            {
                dt = searchAll_PayData();
                lblCnt.Text = "Payment Record Count : " + dt.Rows.Count.ToString();
            }
        }

        Session["getPayData"] = dt;

        grvPaySearch.DataSource = dt;
        grvPaySearch.DataBind();

       

       
    }
    private void TaskCnt()
    {
        // string sqlQuery =  "SELECT COUNT(jobOwnerID) - 1 AS JobCnt, payID, jobNo FROM JobOwner WHERE (sectionID = 2) GROUP BY payID, jobNo HAVING (COUNT(jobOwnerID) - 1 > 0)";

        using (SqlConnection cn = new SqlConnection())
        {
            cn.Open();
            using (SqlCommand cmd = new SqlCommand())
            {
                cmd.Connection = cn;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "temp_updatePayTaskCnt";
                cmd.ExecuteNonQuery();
            }
        }

    }
    protected void btnExcel_Click(object sender, EventArgs e)
    {
        ExportToExcel_Sree();
    }

    #region MyRegion

    private void ExportToExcel_Sree()
    {
        Response.Clear();
        Response.Buffer = true;
        Response.AddHeader("content-disposition", "attachment;filename=GridViewExport.xls");
        Response.Charset = "";
        Response.ContentType = "application/vnd.ms-excel";
        using (StringWriter sw = new StringWriter())
        {
            HtmlTextWriter hw = new HtmlTextWriter(sw);

            //To Export all pages
            grvPaySearch.AllowPaging = false;

            grvPaySearch.DataSource = Session["getPayData"];
            grvPaySearch.DataBind();

            grvPaySearch.HeaderRow.BackColor = Color.White;
            foreach (TableCell cell in grvPaySearch.HeaderRow.Cells)
            {
                cell.BackColor = grvPaySearch.HeaderStyle.BackColor;
            }
            foreach (GridViewRow row in grvPaySearch.Rows)
            {
                row.BackColor = Color.White;
                foreach (TableCell cell in row.Cells)
                {
                    if (row.RowIndex % 2 == 0)
                    {
                        cell.BackColor = grvPaySearch.AlternatingRowStyle.BackColor;
                    }
                    else
                    {
                        cell.BackColor = grvPaySearch.RowStyle.BackColor;
                    }
                    cell.CssClass = "textmode";
                }
            }

            grvPaySearch.RenderControl(hw);

            //style to format numbers to string
            string style = @"<style> .textmode { } </style>";
            Response.Write(style);
            Response.Output.Write(sw.ToString());
            Response.Flush();
            Response.End();
        }
    }
    public override void VerifyRenderingInServerForm(Control control)
    {
        /* Verifies that the control is rendered */
    }

    #endregion
}