﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using Datalayer;
using PropertyLayer;
using System.Threading;
using System.Globalization;
using System.Web.UI.HtmlControls;
using Microsoft.Office.Interop.Word;
using System.Text.RegularExpressions;

public partial class Payments_PaymentDetails : System.Web.UI.Page
{
    private string connValue = System.Configuration.ConfigurationManager.ConnectionStrings["EBSDEBookConn"].ConnectionString;
    IList<string> userRightsColl = null;
    int _payID = 0;
   
    protected void Page_Load(object sender, EventArgs e)
    {
        if ((Request.QueryString["PayID"]!=null))    // From All links
         _payID = Convert.ToInt32(Request.QueryString["PayID"]);

        if ((Request.QueryString["payIDNew"] != null))         // Comming from Add new Paymenyt
            _payID = Convert.ToInt32(Request.QueryString["payIDNew"]);

        //if ((Session["AddPayID"] != null))
        //{
        //    _payID = Convert.ToInt32(Session["AddPayID"]);
        //    Session["AddPayID"] = null;
        //}

        if (_payID==0)
            _payID = Convert.ToInt32(Session["PayID"]);

        lblPayID.Text = "PayID : = " + _payID.ToString();

        userRightsColl = (IList<string>)Session["UserRightsColl"];

        Session["JobID"] = null;  //  //  killing session becuease of link document button when user action on updatepay[PaymentDetails.aspx]/ updatejob[DefaultGrid.aspx] 

        if (!IsPostBack)
        {
            FillDropDown();

            fillPaymentData();      // from eBook

            getPCMAmountData();          // from PCM 

            calcRemainCost();

            BindGridData();

            CheckPCMPaymentCertified();

            //if (userRightsColl.Count == 0)
            //  btnDelete.Visible = true;
            //else
            //  btnDelete.Visible = false;

            if (!userRightsColl.Contains("9"))
            {
                GetPCMProjectAllocationData();
                GetProjectAllocationDataGrid();

                trAllocName.Visible = true;
                trAllocValue.Visible = true;
            }
            else
            {
                trAllocName.Visible = false;
                trAllocValue.Visible = false;
            }

            if (Session["UserID"].ToString().Equals("100"))
            {
                GetPCMProjectAllocationData();               
                GetProjectAllocationDataGrid();

                trAllocName.Visible = true;
                trAllocValue.Visible = true;
            }
            //else
            //{
            //    trAllocName.Visible = false;
            //    trAllocValue.Visible = false;
            //}

        }     

        // getPCMData();
    }
    private void FillDropDown()
    {
        PopulateDropDownBox(ddlDept, "SELECT departmentID, deptName FROM  Department where affairID is not null ORDER BY deptName ", "departmentID", "deptName");
        PopulateDropDownBox(ddlStatus, "SELECT JobStatusID, JobStatusName FROM JobStatus Where JobStatusID in(1,2,3,4,5,6,7) ORDER BY JobStatusName", "JobStatusID", "JobStatusName");

        LoadSubjects();
        LoadSubjectsPayFor();
    }
    private void BindGridData()
    {
        gvJoborder.DataSource = new JobOrderData().GetPaymentJobOwnerDetails(_payID);
        gvJoborder.DataBind();

        gridReceived.DataSource = new JobOrderData().getJobDocumetReceivedDatePay(_payID);
        gridReceived.DataBind();

        gridSent.DataSource = new JobOrderData().getJobDocumetSentDatePay(_payID);
        gridSent.DataBind();

    }
    private void calcRemainCost()
    {
        double Amnt1 = 0; double Amnt2 = 0; double Amnt3 = 0;

        if (txtLatestBudget.Text == "")
            Amnt1 = 0;
        else
            Amnt1 = Convert.ToDouble(txtLatestBudget.Text);

        if (txtPcmPrvTotalAmt.Text == "")        //txtVariationDateAmt
            Amnt2 = 0;
        else
            Amnt2 = Convert.ToDouble(txtPcmPrvTotalAmt.Text);


        //if (txtTotCertAmt.Text == "")
        //    Amnt3 = 0;
        //else
        //    Amnt3 = Convert.ToDouble(txtTotCertAmt.Text);

        double totAmnt = (Amnt1 - Amnt2);
        if (Amnt2!=0)
          txtRemCost.Text = totAmnt.ToString("#,###.##");    

    }
    private void fillPaymentData()
    {
        using (SqlConnection cn = new SqlConnection(connValue))
        {
            cn.Open();
            using (SqlCommand sqlCom = new SqlCommand())
            {
                // sqlCom.CommandType = CommandType.StoredProcedure;
                sqlCom.CommandType = CommandType.Text;
                sqlCom.Connection = cn;

                sqlCom.CommandText = "SELECT payTypeID, paymentForID, jobStatusID,commitmentNo,JobNo,applicationNo, requestedAmt, issuedByContractorOn, issuedBySupervisionOn, issuedByPMCOn, " +
                              "  issuedByArchiveOn, issuedByEBSDOn, receivedByEBSD1On," +
                    " sentBackForCorrectionOn, receivedByEBSD2On, issuedByEBSD2On, issuedByDeptToFinOn, returnByFinOn, reIssuedByDeptToFin, dateCertified, CONVERT(varchar, CAST(contractAmt AS money), 1) as contractAmt, " +
                    " periodEndingOn, prjStartDate, CONVERT(varchar, CAST(latestBudgetAmt AS money), 1) as latestBudgetAmt, CONVERT(varchar, CAST(certifiedAmt AS money), 1) as certifiedAmt, totalCertifiedAmt, CONVERT(varchar, CAST(approvedchangesAmt AS money), 1) as approvedchangesAmt  , projectCode, latestCompletionDate, CONVERT(varchar, CAST(totalAdvancePayment AS money), 1) as totalAdvancePayment, " +
                     " CONVERT(varchar, CAST(advancePayRecoveryAmt AS money), 1) as advancePayRecoveryAmt, latestVONo, provisionNumber, budgetRefNo, CONVERT(varchar, CAST(retentionAmt AS money), 1) as retentionAmt, CONVERT(varchar, CAST(retentionReleaseAmt AS money), 1) as retentionReleaseAmt, CONVERT(varchar, CAST(penaltyAmt AS money), 1) as penaltyAmt , CONVERT(varchar, CAST(prevCertifiedAmt AS money), 1) as prevCertifiedAmt , " +
                     " CONVERT(varchar, CAST(prevTotalCertifiedAmt AS money), 1) as prevTotalCertifiedAmt ,prevRPno, projectTitle, contractor, remarks,deptID,QSID FROM  Payment where payID = " + _payID;

                // CONVERT(varchar, CAST(987654321 AS money), 1),

                using (SqlDataReader sqlReader = sqlCom.ExecuteReader())
                {
                    while (sqlReader.Read())
                    {

                        if (sqlReader["payTypeID"].ToString() != "")

                            ddlPayType.SelectedValue = sqlReader["payTypeID"].ToString();

                        if (sqlReader["paymentForId"].ToString() != "")
                            ddlPayFor.SelectedValue = sqlReader["paymentForID"].ToString();

                        if (sqlReader["jobStatusID"].ToString() != "")
                            ddlStatus.SelectedValue = sqlReader["jobStatusID"].ToString();

                        if (sqlReader["requestedAmt"].ToString() != "")
                            txtReqAmt.Text = Convert.ToDouble(sqlReader["requestedAmt"]).ToString("#,###.##");  
                                                

                        if (sqlReader["issuedByContractorOn"].ToString() != "")
                            txtIssuedByCntr.Text = Convert.ToDateTime(sqlReader["issuedByContractorOn"].ToString()).ToString("dd/MMM/yyyy"); // sqlReader["issuedByContractorOn"].ToString();                           

                        txtJobNo.Text = sqlReader["jobNo"].ToString();
                        txtRPNo.Text = sqlReader["applicationNo"].ToString();
                        txtCntrNo.Text = sqlReader["commitmentNo"].ToString();

                        if (sqlReader["issuedBySupervisionOn"].ToString() != "")
                            txtSupervision.Text = Convert.ToDateTime(sqlReader["issuedBySupervisionOn"].ToString()).ToString("dd/MMM/yyyy");

                        if (sqlReader["issuedByPMCOn"].ToString() != "")
                            txtPMC.Text = Convert.ToDateTime(sqlReader["issuedByPMCOn"].ToString()).ToString("dd/MMM/yyyy"); //sqlReader["issuedByPMCOn"].ToString();

                        if (sqlReader["issuedByArchiveOn"].ToString() != "")
                            txtIssuedArchive.Text = Convert.ToDateTime(sqlReader["issuedByArchiveOn"].ToString()).ToString("dd/MMM/yyyy"); //sqlReader["issuedByArchiveOn"].ToString();

                        if (sqlReader["issuedByEBSDOn"].ToString() != "")
                        {
                            txtIssuedByEbsd.Text = Convert.ToDateTime(sqlReader["issuedByEBSDOn"].ToString()).ToString("dd/MMM/yyyy");  //sqlReader["issuedByEBSDOn"].ToString();

                            txtCorrection.Enabled = false;
                            txtRecCorrection.Enabled = false;
                            txtReIssued.Enabled = false;
                        }
                        else
                        {
                            txtCorrection.Enabled = true;
                            txtRecCorrection.Enabled = true;
                            txtReIssued.Enabled = true;
                        }

                        if (sqlReader["receivedByEBSD1On"].ToString() != "")
                            txtdateRecEbsd.Text = Convert.ToDateTime(sqlReader["receivedByEBSD1On"].ToString()).ToString("dd/MMM/yyyy"); //sqlReader["receivedByEBSD1On"].ToString();

                        if (sqlReader["sentBackForCorrectionOn"].ToString() != "")
                        {
                            txtCorrection.Text = Convert.ToDateTime(sqlReader["sentBackForCorrectionOn"].ToString()).ToString("dd/MMM/yyyy"); // sqlReader["sentBackForCorrectionOn"].ToString();
                            txtIssuedByEbsd.Enabled = false;
                           // txtCorrection.Enabled = false;
                        }
                        else
                        {
                            //txtIssuedByEbsd.Enabled = true;
                           // txtCorrection.Enabled = true;
                        }

                        if (sqlReader["receivedByEBSD2On"].ToString() != "")
                        {
                            txtRecCorrection.Text = Convert.ToDateTime(sqlReader["receivedByEBSD2On"].ToString()).ToString("dd/MMM/yyyy"); //sqlReader["receivedByEBSD2On"].ToString();
                            txtIssuedByEbsd.Enabled = false;

                        }

                        if (sqlReader["issuedByEBSD2On"].ToString() != "")
                        {
                            txtReIssued.Text = Convert.ToDateTime(sqlReader["issuedByEBSD2On"].ToString()).ToString("dd/MMM/yyyy"); //sqlReader["issuedByEBSD2On"].ToString();
                            
                          //  txtIssuedByEbsd.Enabled = false;

                            txtCorrection.Enabled = false;
                            txtRecCorrection.Enabled = false;                        
                        }
                        


                        if (sqlReader["issuedByDeptToFinOn"].ToString() != "")
                            txtIssuedFin.Text = Convert.ToDateTime(sqlReader["issuedByDeptToFinOn"].ToString()).ToString("dd/MMM/yyyy"); //sqlReader["issuedByDeptToFinOn"].ToString();

                        if (sqlReader["returnByFinOn"].ToString() != "")
                            txtRetFin.Text = Convert.ToDateTime(sqlReader["returnByFinOn"].ToString()).ToString("dd/MMM/yyyy");

                        if (sqlReader["reIssuedByDeptToFin"].ToString() != "")
                            txtReIssuedFin.Text = Convert.ToDateTime(sqlReader["reIssuedByDeptToFin"].ToString()).ToString("dd/MMM/yyyy");    //sqlReader["reIssuedByDeptToFin"].ToString();


                        if (sqlReader["dateCertified"].ToString() != "")
                            txtDateCertified.Text = Convert.ToDateTime(sqlReader["dateCertified"].ToString()).ToString("dd/MMM/yyyy"); //sqlReader["dateCertified"].ToString();


                        if (sqlReader["contractAmt"].ToString() != "")
                            txtCntrAmt.Text = Convert.ToDouble(sqlReader["contractAmt"]).ToString("#,###.##");                         

                        if (sqlReader["periodEndingOn"].ToString() != "")
                            txtPeriodEnd.Text = Convert.ToDateTime(sqlReader["periodEndingOn"].ToString()).ToString("dd/MMM/yyyy");    //sqlReader["periodEndingOn"].ToString();


                        if (sqlReader["prjStartDate"].ToString() != "")
                            txtCntrStartDate.Text = Convert.ToDateTime(sqlReader["prjStartDate"].ToString()).ToString("dd/MMM/yyyy");      //sqlReader["prjStartDate"].ToString();


                        //if (sqlReader["latestBudgetAmt"].ToString() != "")
                        //    txtLatestBudget.Text = Convert.ToDouble(sqlReader["latestBudgetAmt"]).ToString("#,###.##");


                        double cntrAmnt = 0;
                        if (sqlReader["contractAmt"].ToString() != "")
                            cntrAmnt = Convert.ToDouble(sqlReader["contractAmt"].ToString());

                         double variationCntrAmnt = 0;
                        if (sqlReader["approvedchangesAmt"].ToString() != "")
                            variationCntrAmnt = Convert.ToDouble(sqlReader["approvedchangesAmt"].ToString());

                        txtLatestBudget.Text = Convert.ToDouble(cntrAmnt + variationCntrAmnt).ToString("#,###.##"); 

                        if (sqlReader["certifiedAmt"].ToString() != "")
                            txtNetCertAmt.Text = Convert.ToDouble(sqlReader["certifiedAmt"]).ToString("#,###.##");

                        if (sqlReader["totalCertifiedAmt"].ToString() != "")
                            txtTotCertAmt.Text = Convert.ToDouble(sqlReader["totalCertifiedAmt"]).ToString("#,###.##");

                        if (sqlReader["approvedchangesAmt"].ToString() != "")
                            txtVariationDateAmt.Text = Convert.ToDouble(sqlReader["approvedchangesAmt"]).ToString("#,###.##");                     


                        txtprjCode.Text = sqlReader["projectCode"].ToString();

                        if (sqlReader["latestCompletionDate"].ToString() != "")
                            txtLtstFinDate.Text = Convert.ToDateTime(sqlReader["latestCompletionDate"].ToString()).ToString("dd/MMM/yyyy");      //sqlReader["latestCompletionDate"].ToString();

                      
                        if (sqlReader["totalAdvancePayment"].ToString() != "")
                            txtTotalAdv.Text = Convert.ToDouble(sqlReader["totalAdvancePayment"]).ToString("#,###.##");  

                        if (sqlReader["advancePayRecoveryAmt"].ToString() != "")
                            txtAdvRecov.Text = Convert.ToDouble(sqlReader["advancePayRecoveryAmt"]).ToString("#,###.##");    
 
                      //  ---------------------------------------------------------------------------------------------------------------------------------------

                           //double Amnt1 =0; double Amnt2 =0; double Amnt3 =0;

                           //if (sqlReader["contractAmt"].ToString() == "")
                           //  Amnt1 = 0;
                           //else
                           // Amnt1 = Convert.ToDouble(sqlReader["contractAmt"]);

                           //if (sqlReader["approvedchangesAmt"].ToString() == "")
                           //    Amnt2 = 0;
                           //else
                           //    Amnt2 = Convert.ToDouble(sqlReader["approvedchangesAmt"]);


                           //if (sqlReader["totalCertifiedAmt"].ToString() == "")
                           //    Amnt3 = 0;
                           //else
                           //    Amnt3 = Convert.ToDouble(sqlReader["totalCertifiedAmt"]);


                           //double totAmnt = (Amnt1 + Amnt2) - Amnt3;
                           // txtRemCost.Text = totAmnt.ToString("#,###.##");      

                     //  ---------------------------------------------------------------------------------------------------------------------------------------

                        txtVoNo.Text = sqlReader["latestVONo"].ToString();
                        txtProvNo.Text = sqlReader["provisionNumber"].ToString();
                        txtBudRef.Text = sqlReader["budgetRefNo"].ToString();


                        if (sqlReader["retentionAmt"].ToString() != "")
                            txtRetensionToDateAmt.Text = Convert.ToDouble(sqlReader["retentionAmt"]).ToString("#,###.##");           //  =  sqlReader["retentionAmt"].ToString();


                        if (sqlReader["retentionReleaseAmt"].ToString() != "")
                            txtRetensionRelease.Text = Convert.ToDouble(sqlReader["retentionReleaseAmt"]).ToString("#,###.##");           //  =  sqlReader["retentionAmt"].ToString();


                        if (sqlReader["penaltyAmt"].ToString() != "")
                            txtPenaltyDate.Text = Convert.ToDouble(sqlReader["penaltyAmt"]).ToString("#,###.##");           //  =  sqlReader["retentionAmt"].ToString();
                       
                        
                        txtProjTitle.Text = sqlReader["projectTitle"].ToString();
                        txtCntrName.Text = sqlReader["contractor"].ToString();
                        txtRemarks.Text = sqlReader["remarks"].ToString();

                        ddlDept.SelectedValue = sqlReader["deptID"].ToString();

                        if (sqlReader["prevCertifiedAmt"].ToString() != "")
                            txtPCMCertAmt.Text = Convert.ToDouble(sqlReader["prevCertifiedAmt"]).ToString("#,###.##");


                        if (sqlReader["prevTotalCertifiedAmt"].ToString() != "")
                            txtPcmPrvTotalAmt.Text = Convert.ToDouble(sqlReader["prevTotalCertifiedAmt"]).ToString("#,###.##");

                        if (sqlReader["prevRPno"].ToString() != "")
                            txtPCMRPno.Text = sqlReader["prevRPno"].ToString();                      

                    }
                }
            }
        }
    }
    private void CheckPCMPaymentCertified()
    {
        string strCntr = string.Empty;
        strCntr = txtCntrNo.Text;

        string strCntrSlas = string.Empty;
        string[] strColl = strCntr.Split('/');
        if (strColl.Length == 3)
            strCntrSlas = strColl[0] + strColl[1] + strColl[2];
        else if (strColl.Length == 2)
            strCntrSlas = strColl[0] + strColl[1];
        else if (strColl.Length == 1)
            strCntrSlas = strColl[0];

        string[] strColl2 = strCntrSlas.Split(' ');

        if (strColl2.Length == 2)
            strCntrSlas = strColl2[0] + strColl2[1];

       

        string strQuery = string.Empty;
        strQuery = "SELECT   PCM_CNMT_TABLE.commitment_no, PCM_RQMT_TABLE.application_no, PCM_RQMT_TABLE.is_certified FROM  PCM_CNMT_TABLE INNER JOIN  PCM_RQMT_TABLE ON PCM_CNMT_TABLE.project_name = PCM_RQMT_TABLE.project_name " +
                             " WHERE (PCM_CNMT_TABLE.eBook_commitment_no = @commitmentNo) AND (PCM_RQMT_TABLE.application_no = @appNo)";
        string cntrNo = string.Empty;
        using (SqlConnection objCon = new SqlConnection(connValue))
        {
            objCon.Open();
            SqlCommand objCmd = new SqlCommand();
            objCmd.CommandType = CommandType.Text;

            objCmd.Connection = objCon;
            objCmd.CommandText = strQuery;

            objCmd.Parameters.AddWithValue("@commitmentNo", strCntrSlas);
            objCmd.Parameters.AddWithValue("@appNo", txtRPNo.Text);           

            using (SqlDataReader dr = objCmd.ExecuteReader())
            {
                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        lblCertified.Text = "Payment Certified " + Convert.ToBoolean(dr["is_Certified"]).ToString();
                    }
                }
                else
                    lblCertified.Text = "PCM Data not found by given committment No : - " + txtCntrNo.Text + "  RPNO  " + txtRPNo.Text;
            }
        }
    }
    private void getPCMAmountData()
    {

        //string sqlQuery = "SELECT Top 1 RQMT_TABLE.Payment_Type,RQMT_TABLE.is_certified,CNMT_TABLE.description, CNMT_TABLE.commitment_no, RQMT_TABLE.application_no, " +
        //" CNMT_TABLE.provision_no, PROJ.project_manager, PROJ.project_number,   PROJ.project_title, RQMT_TABLE.is_certified, RQMT_TABLE.prev_amount_cert, PROJ.budget_code, CNMT_TABLE.to_company, CNMT_TABLE.start_date " +
        //              " ,CNMT_TABLE.revisd_cmpl_date, CNMT_TABLE.completion_date,  CNMT_TABLE.unit_cost, PROJ.minis_dept_cd_nm, RQMT_TABLE.prev_amt_cert_c," +
        //              " RQMT_TABLE.p_retention,RQMT_TABLE.tot_ret_released,RQMT_TABLE.penalty_todate,RQMT_TABLE.advance_payment,RQMT_TABLE.ap_recovery,RQMT_TABLE.period_to, RQMT_TABLE.prev_amt_cert_c,RQMT_TABLE.amount_certified " + 
        //" FROM  CNMT_TABLE INNER JOIN   PROJ ON CNMT_TABLE.project_name = PROJ.project_name LEFT OUTER JOIN  RQMT_TABLE ON CNMT_TABLE.project_name = RQMT_TABLE.project_name " +
        //                " WHERE (CNMT_TABLE.commitment_no = '" + txtCntrNo.Text + "') AND (RQMT_TABLE.application_no = '" + txtRPNo.Text + "') Order By RQMT_TABLE.application_no Desc";


        string cntrNo = string.Empty;
        using (SqlConnection objCon = new SqlConnection(connValue))
        {
            objCon.Open();
            SqlCommand objCmd = new SqlCommand();
            objCmd.CommandType = CommandType.StoredProcedure;

            objCmd.Connection = objCon;
            objCmd.CommandText = "pay_GetCostDataFromPCM";

            // -  C 2014/19        ----------- C/2014/19

            // C2014/19

            cntrNo = txtCntrNo.Text;

           //string[] strColl=  txtCntrNo.Text.Split('/');
           //if (strColl.LongLength > 1)
           //{
           //    cntrNo = strColl[0] + strColl[1]+"/"+
           //}
           //else
           //    cntrNo = txtCntrNo.Text;


            string strCntr = string.Empty;
            strCntr = txtCntrNo.Text;

            string strCntrSlas = string.Empty;
            string[] strColl = strCntr.Split('/');
            if (strColl.Length == 3)
                strCntrSlas = strColl[0] + strColl[1] + strColl[2];
            else if (strColl.Length == 2)
                strCntrSlas = strColl[0] + strColl[1];
            else if (strColl.Length == 1)
                strCntrSlas = strColl[0];

            string[] strColl2 = strCntrSlas.Split(' ');

            if (strColl2.Length == 2)
                strCntrSlas = strColl2[0] + strColl2[1];

            cntrNo = strCntrSlas;

            objCmd.Parameters.AddWithValue("@commitmentNo", cntrNo);
            objCmd.Parameters.AddWithValue("@appNo", txtRPNo.Text);
            
            double dblAmnt1 = 0;double dblAmnt2 = 0;          

            using (SqlDataReader dr = objCmd.ExecuteReader())
            {
                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        txtNetCertAmt.Text = dr["amount_certified"].ToString();

                        if (dr["amount_certified"].ToString() != "")
                            dblAmnt1 = Convert.ToDouble(dr["amount_certified"].ToString());

                        if (dr["prev_amt_cert_c"].ToString() != "")
                            dblAmnt2 = Convert.ToDouble(dr["prev_amt_cert_c"].ToString());

                        txtTotCertAmt.Text = (dblAmnt1 + dblAmnt2).ToString("#,###.##"); 

                        txtTotalAdv.Text = dr["advance_payment"].ToString();

                        txtAdvRecov.Text = dr["ap_recovery"].ToString();

                        txtRetensionToDateAmt.Text = dr["p_retention"].ToString();

                        txtRetensionRelease.Text = dr["tot_ret_released"].ToString();

                        txtPenaltyDate.Text = dr["penalty_todate"].ToString();

                        txtPeriodEnd.Text = Convert.ToDateTime(dr["period_to"]).ToString("dd/MMM/yyyy");

                       // txtPercentComplete.Text = dr["percent_complete"].ToString();

                        if (dr["percent_complete"].ToString()!="")
                          txtPercentComplete.Text = Math.Round(Convert.ToDouble(dr["percent_complete"])).ToString();


                        txtActualDuration.Text = dr["actual_duration"].ToString();

                        txtCertifiedThisYear.Text = dr["certified_this_year"].ToString();

                        if (dr["pcc_date"].ToString() != "")
                        {
                            txtPCCdt.Text = Convert.ToDateTime(dr["pcc_date"]).ToString("dd/MMM/yyyy");
                            chkPCC.Checked = true;
                        }
                        if (dr["mcc_date"].ToString() != "")
                        {
                            txtMccDt.Text = Convert.ToDateTime(dr["mcc_date"]).ToString("dd/MMM/yyyy");
                            chkMCC.Checked = true;
                        }
                        if (dr["fcc_date"].ToString() != "")
                        {
                            txtFccDt.Text = Convert.ToDateTime(dr["fcc_date"]).ToString("dd/MMM/yyyy");
                            chkPay.Checked = true;
                        }
                    }
                }
                //else
                //    lblPCMData.Text = "PCM Data not found by given committment No : - " + txtCntrNo.Text + "  RPNO  "  + txtRPNo.Text;
            }
        }
    }

    private void getPCMData()
    {
        //string sqlQuery = "SELECT  Top 1 CNMT_TABLE.commitment_no, RQMT_TABLE.application_no, CNMT_TABLE.provision_no, PROJ.project_manager, PROJ.project_number, PROJ.project_title,  RQMT_TABLE.amount_certified, RQMT_TABLE.application_no AS Expr2, RQMT_TABLE.certified, RQMT_TABLE.certified_by, RQMT_TABLE.certified_date, " +
        //                 " RQMT_TABLE.prev_amount_cert AS Expr3, RQMT_TABLE.total_sched_valu,RQMT_TABLE.amount_certified,RQMT_TABLE.prev_amt_cert_c  FROM  CNMT_TABLE INNER JOIN   PROJ ON CNMT_TABLE.project_name = PROJ.project_name LEFT OUTER JOIN   RQMT_TABLE ON CNMT_TABLE.project_name = RQMT_TABLE.project_name  WHERE  (CNMT_TABLE.commitment_no = '" + txtCntrNo.Text + "') ORDER BY RQMT_TABLE.application_no DESC";
       
        ////
        using (SqlConnection objCon = new SqlConnection(connValue))
        {
            objCon.Open();
            SqlCommand objCmd = new SqlCommand();
            objCmd.CommandType = CommandType.StoredProcedure;

            objCmd.Connection = objCon;
            objCmd.CommandText = "pay_GetPcmPreviousAmountData";

            objCmd.Parameters.AddWithValue("@commitmentNo", txtCntrNo.Text);
            objCmd.Parameters.AddWithValue("@appNo", txtRPNo.Text);   

            using (SqlDataReader dr = objCmd.ExecuteReader())
            {
                while (dr.Read())
                {
                    if (dr["amount_certified"].ToString() != "")
                        txtPCMCertAmt.Text = Convert.ToDouble(dr["amount_certified"]).ToString("#,###.##");

                    if (dr["prev_amt_cert_c"].ToString() != "")
                        txtPcmPrvTotalAmt.Text = Convert.ToDouble(dr["prev_amt_cert_c"]).ToString("#,###.##");
                  
                    txtPCMRPno.Text = dr["application_no"].ToString();
                }
            }
        }
    }

    #region MyRegion
    
  

    private void PopulateDropDownBox(DropDownList ddlBox, string sqlQuery, string valueMember, string displayName)
    {
        System.Data.DataTable table = new System.Data.DataTable();

        try
        {
            using (SqlConnection sqlConn = new SqlConnection(connValue))
            {
                using (SqlDataAdapter da = new SqlDataAdapter(sqlQuery, sqlConn))
                {
                    sqlConn.Open();
                    da.Fill(table);
                }
            }
            //cmbBox.Items.Add("Select");
            ddlBox.DataSource = table;
            ddlBox.DataTextField = displayName;
            ddlBox.DataValueField = valueMember;
            ddlBox.SelectedIndex = -1;

            ddlBox.DataBind();
            ddlBox.Items.Insert(0, new ListItem(""));
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    private void LoadSubjects()
    {

        System.Data.DataTable subjects = new System.Data.DataTable();

        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["EBSDEBookConn"].ConnectionString))
        {

            try
            {
                SqlDataAdapter adapter = new SqlDataAdapter("SELECT payTypeID, payTypeName FROM  paymentType  ORDER BY payTypeName", con);
                adapter.Fill(subjects);

                ddlPayType.DataSource = subjects;
                ddlPayType.DataTextField = "payTypeName";
                ddlPayType.DataValueField = "payTypeID";
                ddlPayType.DataBind();
            }
            catch (Exception ex)
            {
                // Handle the error
            }

        }

        // Add the initial item - you can add this even if the options from the
        // db were not successfully loaded
        ddlPayType.Items.Insert(0, new ListItem("", "0"));

    }
    private void LoadSubjectsPayFor()
    {

        System.Data.DataTable subjects = new System.Data.DataTable();

        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["EBSDEBookConn"].ConnectionString))
        {

            try
            {
                SqlDataAdapter adapter = new SqlDataAdapter("SELECT paymentForID, paymentForDesc FROM  PaymentFor  ORDER BY paymentForDesc", con);
                adapter.Fill(subjects);

                ddlPayFor.DataSource = subjects;
                ddlPayFor.DataTextField = "paymentForDesc";
                ddlPayFor.DataValueField = "paymentForID";
                ddlPayFor.DataBind();
            }
            catch (Exception ex)
            {
                // Handle the error
            }
        }
        // Add the initial item - you can add this even if the options from the
        // db were not successfully loaded
        ddlPayFor.Items.Insert(0, new ListItem("", "0"));

    }
    protected void lnkDelete_Click(object sender, EventArgs e)
    {
        
    }
    private Boolean checkUserExist(int fileID, int createdBy, int currentUserID)
    {
        using (SqlConnection cn = new SqlConnection(connValue))
        {
            cn.Open();
            using (SqlCommand sqlCom = new SqlCommand())
            {
                // sqlCom.CommandType = CommandType.StoredProcedure;
                sqlCom.CommandType = CommandType.Text;
                sqlCom.Connection = cn;
                sqlCom.CommandText = "Select uploadByID From FilesTable where fileID = " + fileID;

                using (SqlDataReader sqlReader = sqlCom.ExecuteReader())
                {
                    while (sqlReader.Read())
                    {
                        if ((sqlReader["uploadByID"].Equals(currentUserID)) || (Session["userProfileID"].Equals("1")))
                            return true;
                    }
                }
            }
        }
        return false;
    }
    private Boolean checkDocExist(int inChargeID)
    {
        Boolean chkDocExist = false;
        string prjTitle = string.Empty;
        SqlConnection cnn = new SqlConnection(connValue);
        cnn.Open();
        SqlCommand cmm = new SqlCommand();
        cmm.Connection = cnn;
        cmm.CommandText = "SELECT * FROM DocumentDistribution WHERE JobOwnerID = " + inChargeID + " and docStatusID in(1,2)"; //open n Follwup
        SqlDataReader sqlDtReader = cmm.ExecuteReader();
        if (sqlDtReader.HasRows)
        {
            chkDocExist = true;
        }
        else
        {
            prjTitle = "NA";
        }
        sqlDtReader.Close();
        cnn.Close();

        return chkDocExist;
    }

    public string chkDocumentRefWithJob(int _payID)
    {
        string docID = string.Empty;

        SqlConnection sqlConn = new SqlConnection(connValue);
        string sqlQuery = "SELECT docRefID from payment where payID = " + _payID + "";

        try
        {
            sqlConn.Open();
            SqlCommand sqlCom = new SqlCommand(sqlQuery, sqlConn);
            SqlDataReader sqlReader = sqlCom.ExecuteReader();
            while (sqlReader.Read())
            {
                docID = sqlReader[0].ToString();
            }
            sqlReader.Close();
        }
        catch (Exception ex)
        {
            // Response.Write("Error getting while reading data !" + ex.Message);
        }
        finally
        {
            sqlConn.Close();
        }

        return docID;
    }
    public void DeleteDistributionForJobIncharge(int docID)
    {
        string upDateQuery = "DELETE FROM DOCUMENTDISTRIBUTION WHERE documentID = @docID and JobOwnerID is not null";

        SqlConnection sqlCon = new SqlConnection(connValue);
        SqlCommand cmd = new SqlCommand();
        cmd.CommandText = upDateQuery;
        cmd.Connection = sqlCon;

        cmd.Parameters.AddWithValue("@docID", docID);

        try
        {
            sqlCon.Open();
            cmd.ExecuteNonQuery();
            sqlCon.Close();
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    public void UpdateDocumentPayID(int docID)
    {
        string upDateQuery = "Update Document set PaymentID = @payID where documentID = @docID";

        SqlConnection sqlCon = new SqlConnection(connValue);
        SqlCommand cmd = new SqlCommand();
        cmd.CommandText = upDateQuery;
        cmd.Connection = sqlCon;

        cmd.Parameters.AddWithValue("@docID", docID);
        cmd.Parameters.AddWithValue("@payID", System.DBNull.Value);

        try
        {
            sqlCon.Open();
            cmd.ExecuteNonQuery();
            sqlCon.Close();
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    
    #endregion

    protected void btnReceive_Click(object sender, EventArgs e)
    {
        string strUpdateJob = Request.Url.AbsoluteUri;
        try
        {
            if (userRightsColl.Contains("8")) // Access Right is 4 
            {
                ClientScript.RegisterClientScriptBlock(this.GetType(), "Popup", "<script>alert('You have no privilege to add this Document')</script>", false);
                return;
            }
            else
            {
                Session["UrlRef"] = strUpdateJob;
                Session["PayID"] = _payID;
                Response.Redirect("~/Documents/DocumentDetailsWindow.aspx?RecSentCatID=1&Reply=0", false);
            }
        }
        catch (Exception ex)
        {

        }      
    }
    protected void nLinkRec_Click(object sender, EventArgs e)
    {
        Session["CatID"] = "1";
        Session["lnkPayID"] = _payID;
        if (userRightsColl.Contains("8")) // Access Right is 4 
        {
            Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Don't have the permission to Add Staff ')</script>", false);
            return;
        }
        else
        {
            string url = "/eBook/UploadPayDocuments.aspx";     ///eBook/Payments/~/JobOrder/uploadDoc.aspx
            string s = "window.open('" + url + "', 'popup_window', 'width=600,height=400,left=100,top=100,resizable=yes');";
            Page.ClientScript.RegisterStartupScript(this.GetType(), "script", s, true);
        } 
    }
    protected void btnSent_Click(object sender, EventArgs e)
    {
        string strUpdateJob = Request.Url.AbsoluteUri;
        try
        {
            if (userRightsColl.Contains("8")) // Access Right is 4 
            {
                ClientScript.RegisterClientScriptBlock(this.GetType(), "Popup", "<script>alert('You have no privilege to add Document')</script>", false);
                return;
            }
            else
            {
                Session["DocCategoryID"] = "2";    // It shoul be 2
                Session["DocID"] = null;
                Session["UrlRef"] = strUpdateJob;
                Session["PayID"] = _payID;
                Response.Redirect("~/Documents/DocumentDetailsWindow.aspx?RecSentCatID=2&Reply=0", false);
            }
        }
        catch (Exception ex)
        {

        }   
    }
    protected void btnLinkSent_Click(object sender, EventArgs e)
    {
        Session["CatID"] = "2";
        Session["lnkPayID"] = _payID;
        if (userRightsColl.Contains("8")) // Access Right is 4 
        {
            Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Don't have the permission to Add Staff ')</script>", false);
            return;
        }
        else
        {
           // string url = "/eBook/uploadDocuments.aspx";

            string url = "/eBook/UploadPayDocuments.aspx";
            string s = "window.open('" + url + "', 'popup_window', 'width=600,height=400,left=100,top=100,resizable=yes');";
            Page.ClientScript.RegisterStartupScript(this.GetType(), "script", s, true);
        } 
    }
    protected void gvJoborder_RowCommand(object sender, GridViewCommandEventArgs e)
    {

    }
    protected void gvJoborder_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            //DropDownList l = (DropDownList)e.Row.FindControl("ddljobtype");

            //PopulateDropDownBox(l, "SELECT JobStatusid,JobStatusName as JobStatus FROM jobStatus Where JobStatusid in(2,3,6,7) ", "JobStatusid", "JobStatus");  // where JobStatusid in(5,6,7,8)

            TextBox lm = (TextBox)e.Row.FindControl("jobid");
            TextBox afr = (TextBox)e.Row.FindControl("TextBox1");
            TextBox InchargeID = (TextBox)e.Row.FindControl("txtInchargeID");

            Label jobStat = (Label)e.Row.FindControl("txtJobStatus");

            Session["InchargeID"] = InchargeID.Text;

            //string lk = lm.Text;
            //l.ToolTip = InchargeID.Text;

            //l.SelectedValue = afr.Text;
            //Session["StatusVal"] = l.SelectedValue;

          //  l.SelectedIndexChanged += new EventHandler(SelectedIndexChanged);

            TextBox txtdate = (TextBox)e.Row.FindControl("lblJoindate");            // ActionDueDate 
            txtdate.ToolTip = InchargeID.Text;
          //  txtdate.TextChanged += new EventHandler(txtdate_TextChanged);
            Session["JobActionDueDate"] = txtdate.Text;

            System.Web.UI.WebControls.CheckBox chkstate = (System.Web.UI.WebControls.CheckBox)e.Row.FindControl("ad");
            chkstate.ToolTip = InchargeID.Text;
            

            Label lblStaff = (Label)e.Row.FindControl("txtStaff");
            Label lblDistributedBy = (Label)e.Row.FindControl("txtDistrubed");

            Label lblConactID = (Label)e.Row.FindControl("txtCnctID");
            TextBox _txtDocID = (TextBox)e.Row.FindControl("txtDocID");
            Session["statusdocID"] = _txtDocID.Text;
            Session["contactID"] = lblConactID.Text;

            Label lblDistribID = (Label)e.Row.FindControl("txtDistributedBy");

            //Label lblRoleID = (Label)e.Row.FindControl("txtRoleID");
            // chkDelete.CheckedChanged += new EventHandler(chkstate_CheckedChanged);                        

            if (!lblConactID.Text.Equals(Session["userID"]) & !userRightsColl.Contains("21"))
            {
                //l.Enabled = false;
                chkstate.Enabled = false;
                //// txtdate.Enabled = false;

                btnUpdatePay.Enabled = false;
            }
            else if (userRightsColl.Contains("1"))
            {
                 chkstate.Enabled = true;  
                btnUpdatePay.Enabled = true;
            }
            else
            {
                chkstate.Enabled = true;  
                btnUpdatePay.Enabled = true;
            }
            if (lblConactID.Text.Equals(Session["userID"]))
            {
                btnOutlook.Enabled = true;
                Session["ActionDate"] = txtdate.Text;
            }
            if (!lblDistribID.Text.Equals(Session["userID"]))
            {
                txtdate.Enabled = false;
            }
            Label lblIsActive = (Label)e.Row.FindControl("txtisActive");    //txtDistisActive
            if (lblIsActive.Text.Equals("False"))
            {
                HyperLink _lnkStaff = (HyperLink)e.Row.FindControl("lnkStaff"); //
                HyperLink _lnkDistribStaff = (HyperLink)e.Row.FindControl("DistibActive");
                _lnkStaff.Enabled = false;
                //_lnkDistribStaff.Enabled = false;
            }
            Label lblDistIsActive = (Label)e.Row.FindControl("txtDistisActive");
            if (lblDistIsActive.Text.Equals("False"))
            {
                HyperLink _lnkDistribStaff = (HyperLink)e.Row.FindControl("lnkDistirbStaff");
                _lnkDistribStaff.Enabled = false;
            }

            if (txtdate.Text != "")
            {
                if ((Convert.ToDateTime(txtdate.Text) < System.DateTime.Today) & (!jobStat.Text.Equals("Completed")))
                {
                    e.Row.Cells[3].BackColor = System.Drawing.Color.Red;
                    e.Row.Cells[3].ForeColor = System.Drawing.Color.White;

                    txtdate.ForeColor = System.Drawing.Color.White;
                    txtdate.BackColor = System.Drawing.Color.Red;
                }
            }

            //if (Session["userIsActive"].Equals("True"))
            //{
            //    lblStaff.Enabled = false;
            //}     

            //LinkButton lnkDelete = (LinkButton)e.Row.FindControl("btnDeleteInCharge");
            //lnkDelete.Attributes.Add("onclick", "javascript:return " + "confirm('Are you sure you want to delete this Staff?')");
            //lnkDelete.CssClass = "btndelete";
        }
    }  
    string recDocID = string.Empty;
    protected void gridReceived_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        string str = Request.Url.AbsoluteUri;
        //if (e.CommandName == "VIEWREC")
        //{
        //    LinkButton lnkView = (LinkButton)e.CommandSource;
        //    recDocID = lnkView.CommandArgument;
        //    try
        //    {
        //        Session["UrlRef"] = str;
        //        Session["PayID"] = _payID;
        //        Response.Redirect("~/Documents/DocumentDetailsWindow.aspx?PaydocRecID =" + recDocID + "&RecSentCatID=1", false);
        //    }
        //    catch (Exception ex)
        //    {
        //    }
        //}
        //else 
        
        if (e.CommandArgument != "")
        {
            int docID = Convert.ToInt32(e.CommandArgument);
            
            string paydocID  = chkDocumentRefWithJob(_payID);
            switch (e.CommandName)
            {
                case "RecDeleteDocid":

                    if (!docID.ToString().Equals(paydocID))
                    {
                       // if (!docID.ToString().Equals(docLetterIDs[1]))          // closed ref
                        {
                           // new JobOrderData().DeactivateDocumentForJob(docID);
                            DeleteDistributionForJobIncharge(docID);
                            UpdateDocumentPayID(docID);
                        }

                        gridReceived.DataSource = new JobOrderData().getJobDocumetReceivedDatePay(_payID);
                        gridReceived.DataBind();
                    }
                    else
                    {
                        ClientScript.RegisterStartupScript(this.GetType(), "alert", "alert('You can't delete, This document reference with Job');", true);
                    }

                    if (flag > 0)
                    {
                        //  Response.Write("Link Deactivated with Job");
                    }
                    break;
            }

        }
    }
    

    protected void gridReceived_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            LinkButton lnkRef = (LinkButton)e.Row.FindControl("lnkRec");
            Label txtDocType = (Label)e.Row.FindControl("RectxtDocType");
            Label txtDate = (Label)e.Row.FindControl("RectxtDate");
            TextBox txtDocID = (TextBox)e.Row.FindControl("RectxtDocID");
            Label lblOpenRef = (Label)e.Row.FindControl("ReclblOpenDocRef");
            Label lblCloseRef = (Label)e.Row.FindControl("ReclblClosedDocRef");
            Control ctrlReceiveCreateUser = e.Row.FindControl("divRecCreateUserID");
            Control ctrlReceiveOriginContactID = e.Row.FindControl("divRecOriginContactID");

            Control ctrlSuperseded = e.Row.FindControl("divRecSuperseded");

            Label lblSuperseded = (Label)e.Row.FindControl("lblSuperseded");
            HtmlGenericControl htmlCtrlSuperseded = ctrlSuperseded as HtmlGenericControl;
            HtmlGenericControl htmlCtrlctrlReceiveOriginContactID = ctrlReceiveOriginContactID as HtmlGenericControl;
            HtmlGenericControl htmlCtrlReceiveCreateUser = ctrlReceiveCreateUser as HtmlGenericControl;

            string strDocID = txtDocID.Text;
            string strOpenRef = lblOpenRef.Text;
            string strCloesdRef = lblCloseRef.Text;

            LinkButton lnkView = (LinkButton)e.Row.FindControl("RecbtnDelete");
            if (lblSuperseded.Text.Equals("True"))
            {

                e.Row.Cells[3].BackColor = System.Drawing.Color.WhiteSmoke;
                e.Row.Cells[3].ForeColor = System.Drawing.Color.Gray;

                e.Row.Cells[4].BackColor = System.Drawing.Color.WhiteSmoke;
                e.Row.Cells[4].ForeColor = System.Drawing.Color.Gray;

                if (htmlCtrlReceiveCreateUser.InnerText.Equals(Session["UserID"].ToString()) || htmlCtrlctrlReceiveOriginContactID.InnerText.Equals(Session["UserID"].ToString()) || Session["UserProfileID"].ToString().Equals("1"))
                {
                    if (lnkRef != null)
                    {
                        lnkRef.Enabled = true;
                        lnkRef.Font.Underline = true;
                    }
                }
                else
                {
                    lnkRef.Enabled = false;
                    lnkRef.Font.Underline = false;
                    lnkRef.ForeColor = System.Drawing.Color.Gray;

                    e.Row.Cells[2].BackColor = System.Drawing.Color.WhiteSmoke;
                    e.Row.Cells[2].ForeColor = System.Drawing.Color.Black;
                }
            }

            if (strDocID.Equals(strOpenRef))
            {
                lnkView.ForeColor = System.Drawing.Color.White;
            }
            else
            {
                lnkView.Attributes.Add("onclick", "javascript:return " + "confirm('This will delete this document from this Job Order.')");
                lnkView.CssClass = "RecbtnDelete";
            }

            Session["DocDelete"] = "1";
        }        
    }
    string sentDocID = string.Empty;
    int flag = 0;
    protected void gridSent_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        string str = Request.Url.AbsoluteUri;
        if (e.CommandName == "VIEW")
        {
            LinkButton lnkView = (LinkButton)e.CommandSource;
            sentDocID = lnkView.CommandArgument;
            try
            {
                Session["UrlRef"] = str;
                Session["PayID"] = _payID;
                Response.Redirect("~/Documents/DocumentDetailsWindow.aspx?docRecID=" + sentDocID + "&RecSentCatID=2", false);
            }
            catch (Exception ex)
            {

            }
        }
        if (e.CommandArgument != "")
        {           

            int docID = Convert.ToInt32(e.CommandArgument);
            string paydocID = chkDocumentRefWithJob(_payID);
            switch (e.CommandName)
            {
                case "SentDeleteDocid":

                    if (!docID.ToString().Equals(paydocID))
                    {
                        //if (!docID.ToString().Equals(docLetterIDs[1]))
                        {
                           // new JobOrderData().DeactivateDocumentForJob(docID);
                            DeleteDistributionForJobIncharge(docID);
                            UpdateDocumentPayID(docID);
                        }

                        gridSent.DataSource = new JobOrderData().getJobDocumetSentDatePay(_payID);
                        gridSent.DataBind();
                    }

                    else
                        ClientScript.RegisterStartupScript(this.GetType(), "alert", "alert('You can't delete, This document reference with Job');", true);


                    if (flag > 0)
                    {
                        //Response.Write("Link Deactivated with Job");
                    }
                    break;
            }
        }
    }
    protected void gridSent_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            LinkButton lnkRef = (LinkButton)e.Row.FindControl("lnkSent");

            Label txtDocType = (Label)e.Row.FindControl("SenttxtDocType");
            Label txtDate = (Label)e.Row.FindControl("SenttxtDate");
            TextBox txtDocID = (TextBox)e.Row.FindControl("SenttxtDocID");
            Label lblOpenRef = (Label)e.Row.FindControl("SentlblOpenDocRef");
            Label lblCloseRef = (Label)e.Row.FindControl("SentlblClosedDocRef");
            Control ctrlReceiveCreateUser = e.Row.FindControl("divSentCreateUserID");
            Control ctrlReceiveOriginContactID = e.Row.FindControl("divSentOriginContactID");
            Control ctrlSuperseded = e.Row.FindControl("divSentSuperseded");
            HtmlGenericControl htmlCtrlSuperseded = ctrlSuperseded as HtmlGenericControl;
            HtmlGenericControl htmlCtrlctrlReceiveOriginContactID = ctrlReceiveOriginContactID as HtmlGenericControl;
            HtmlGenericControl htmlCtrlReceiveCreateUser = ctrlReceiveCreateUser as HtmlGenericControl;

            string strDocID = txtDocID.Text;
            string strOpenRef = lblOpenRef.Text;
            string strCloesdRef = lblCloseRef.Text;

            LinkButton lnkView = (LinkButton)e.Row.FindControl("SentbtnDelete");
            if (htmlCtrlSuperseded.InnerText.Equals("True"))
            {
                e.Row.Cells[3].BackColor = System.Drawing.Color.WhiteSmoke;
                e.Row.Cells[3].ForeColor = System.Drawing.Color.Gray;

                e.Row.Cells[4].BackColor = System.Drawing.Color.WhiteSmoke;
                e.Row.Cells[4].ForeColor = System.Drawing.Color.Gray;


                if (htmlCtrlReceiveCreateUser.InnerText.Equals(Session["UserID"].ToString()) || htmlCtrlctrlReceiveOriginContactID.InnerText.Equals(Session["UserID"].ToString()) || Session["UserProfileID"].ToString().Equals("1"))
                {
                    if (lnkRef != null)
                    {
                        lnkRef.Enabled = true;
                        lnkRef.Font.Underline = true;
                    }
                }
                else
                {
                    lnkRef.Enabled = false;
                    lnkRef.Font.Underline = false;
                    lnkRef.ForeColor = System.Drawing.Color.Gray;

                    e.Row.Cells[2].BackColor = System.Drawing.Color.WhiteSmoke;
                    e.Row.Cells[2].ForeColor = System.Drawing.Color.Black;
                }
            }

            if (strDocID.Equals(strOpenRef))
            {
                lnkView.ForeColor = System.Drawing.Color.White;
            }
            else
            {
                lnkView.Attributes.Add("onclick", "javascript:return " + "confirm('This will delete this document from this Job Order.')");
                lnkView.CssClass = "RecbtnDelete";
            }

            Session["DocDelete"] = "1";
        }
    }

    protected void lnkReceiveData_Link(object sender, EventArgs e)     //ForCommitted
    {
        try
        {
            LinkButton lnkJobID = (LinkButton)sender;
            GridViewRow gvr = (GridViewRow)lnkJobID.NamingContainer;

            Session["PayID"] = _payID;

            Session["UrlRef"] = Request.Url.AbsoluteUri;
          //  Response.Redirect("~/Payments/PaymentDetails.aspx?PaydocRecID = " + Session["PayID"] + "", false);

            Response.Redirect("~/Documents/DocumentDetailsWindow.aspx?docRecID=" + ((HtmlGenericControl)gvr.FindControl("divDocID")).InnerText + "&RecSentCatID=1", false);
        }
        catch
        {

        }



        //LinkButton lnkView = (LinkButton)e.CommandSource;
        //sentDocID = lnkView.CommandArgument;
        //try
        //{
        //    Session["UrlRef"] = str;
        //    Session["PayID"] = _payID;
        //    Response.Redirect("~/Documents/DocumentDetailsWindow.aspx?docRecID=" + sentDocID + "&RecSentCatID=2", false);
        //}
        //catch (Exception ex)
        //{

        //}

    }

    protected void lnkSentData_Link(object sender, EventArgs e)     //ForCommitted
    {
        try
        {
            LinkButton lnkJobID = (LinkButton)sender;
            GridViewRow gvr = (GridViewRow)lnkJobID.NamingContainer;
            Session["PayID"] = _payID;
            Session["UrlRef"] = Request.Url.AbsoluteUri;         

            Response.Redirect("~/Documents/DocumentDetailsWindow.aspx?docRecID=" + ((HtmlGenericControl)gvr.FindControl("divDocID")).InnerText + "&RecSentCatID=2", false);
        }
        catch
        {

        }       
    }    
    
    public int UpdatePayment(JobOrderProperty _updatePayData, string userName, int _payID)
    {
        SqlConnection con = new SqlConnection(connValue);
        SqlCommand cmd = new SqlCommand();
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Connection = con;
        cmd.CommandText = "UpdatePay";

        try
        {
            cmd.Parameters.AddWithValue("@payID", _payID);

             if (_updatePayData.advancePayRecoveryAmt != 0)
                 cmd.Parameters.AddWithValue("@advancePayRecoveryAmt", _updatePayData.advancePayRecoveryAmt);
             else
                cmd.Parameters.AddWithValue("@advancePayRecoveryAmt", System.DBNull.Value);

             if (_updatePayData.approvedchangesAmt != 0)
                cmd.Parameters.AddWithValue("@approvedchangesAmt", _updatePayData.approvedchangesAmt);      // -15
             else
                 cmd.Parameters.AddWithValue("@approvedchangesAmt",  System.DBNull.Value);

             cmd.Parameters.AddWithValue("@budgetRefNo", _updatePayData.budgetRefNo);

             if (_updatePayData.certifiedAmt != 0)
               cmd.Parameters.AddWithValue("@certifiedAmt", _updatePayData.certifiedAmt);
             else
                 cmd.Parameters.AddWithValue("@certifiedAmt", System.DBNull.Value);

            if (_updatePayData.completionDate != "")
                cmd.Parameters.AddWithValue("@completionDate",  Convert.ToDateTime(_updatePayData.completionDate).ToString("dd/MMM/yyyy"));
            else
                cmd.Parameters.AddWithValue("@completionDate", System.DBNull.Value);

             if (_updatePayData.contractAmt != 0)
                cmd.Parameters.AddWithValue("@contractAmt", _updatePayData.contractAmt);
            else
                cmd.Parameters.AddWithValue("@contractAmt", System.DBNull.Value);

             cmd.Parameters.AddWithValue("@contractor", _updatePayData.contractorName);       // chk  @contractor

            if (_updatePayData.dateCertified != "")
                cmd.Parameters.AddWithValue("@dateCertified",   Convert.ToDateTime(_updatePayData.dateCertified).ToString("dd/MMM/yyyy"));
            else
                cmd.Parameters.AddWithValue("@dateCertified", System.DBNull.Value);

            cmd.Parameters.AddWithValue("@deptID", _updatePayData.deptID);

            if (_updatePayData.issuedByArchiveOn != "")
                cmd.Parameters.AddWithValue("@issuedByArchiveOn", Convert.ToDateTime(_updatePayData.issuedByArchiveOn).ToString("dd/MMM/yyyy"));
            else
                cmd.Parameters.AddWithValue("@issuedByArchiveOn", System.DBNull.Value);

            if (_updatePayData.issuedByContractorOn != "")
                cmd.Parameters.AddWithValue("@issuedByContractorOn",Convert.ToDateTime(_updatePayData.issuedByContractorOn).ToString("dd/MMM/yyyy"));
            else
                cmd.Parameters.AddWithValue("@issuedByContractorOn", System.DBNull.Value);

            if (_updatePayData.issuedByDeptToFinOn != "")
                cmd.Parameters.AddWithValue("@issuedByDeptToFinOn", Convert.ToDateTime(_updatePayData.issuedByDeptToFinOn).ToString("dd/MMM/yyyy"));
            else
                cmd.Parameters.AddWithValue("@issuedByDeptToFinOn", System.DBNull.Value);

            // Updating at Index change event

            //if (_updatePayData.issuedByEBSD2On != "")
            //    cmd.Parameters.AddWithValue("@issuedByEBSD2On",  Convert.ToDateTime(_updatePayData.issuedByEBSD2On).ToString("dd/MMM/yyyy"));
            //else
            //    cmd.Parameters.AddWithValue("@issuedByEBSD2On", System.DBNull.Value);

            //if (_updatePayData.issuedByEBSDOn != "")
            //    cmd.Parameters.AddWithValue("@issuedByEBSDOn", Convert.ToDateTime(_updatePayData.issuedByEBSDOn).ToString("dd/MMM/yyyy"));
            //else
            //    cmd.Parameters.AddWithValue("@issuedByEBSDOn", System.DBNull.Value);

            if (_updatePayData.issuedByPMCOn != "")
                cmd.Parameters.AddWithValue("@issuedByPMCOn", Convert.ToDateTime(_updatePayData.issuedByPMCOn).ToString("dd/MMM/yyyy"));
            else
                cmd.Parameters.AddWithValue("@issuedByPMCOn", System.DBNull.Value);

            if (_updatePayData.issuedBySupervisionOn != "")
                cmd.Parameters.AddWithValue("@issuedBySupervisionOn", Convert.ToDateTime(_updatePayData.issuedBySupervisionOn).ToString("dd/MMM/yyyy"));       // -30
            else
                cmd.Parameters.AddWithValue("@issuedBySupervisionOn", System.DBNull.Value);


            cmd.Parameters.AddWithValue("@jobStatusID", _updatePayData.jobStatusID);

             if (_updatePayData.latestBudgetAmt != 0)
                 cmd.Parameters.AddWithValue("@latestBudgetAmt", _updatePayData.latestBudgetAmt);        //- 25
             else
                   cmd.Parameters.AddWithValue("@latestBudgetAmt", System.DBNull.Value);

            if (_updatePayData.latestCompletionDate != "")
                cmd.Parameters.AddWithValue("@latestCompletionDate", Convert.ToDateTime(_updatePayData.latestCompletionDate).ToString("dd/MMM/yyyy"));
            else
                cmd.Parameters.AddWithValue("@latestCompletionDate", System.DBNull.Value);

            cmd.Parameters.AddWithValue("@latestVONo", _updatePayData.latestVONo);

            cmd.Parameters.AddWithValue("@paymentForId", _updatePayData.paymentForId);
           
            if (ddlPayType.SelectedIndex ==0)
              cmd.Parameters.AddWithValue("@payTypeID", 2);
            else
             cmd.Parameters.AddWithValue("@payTypeID", ddlPayType.SelectedValue);

             if (_updatePayData.penaltyAmt != 0)
               cmd.Parameters.AddWithValue("@penaltyAmt", _updatePayData.penaltyAmt);
             else
               cmd.Parameters.AddWithValue("@penaltyAmt", System.DBNull.Value);

            if (_updatePayData.periodEndingOn != "")
                cmd.Parameters.AddWithValue("@periodEndingOn", Convert.ToDateTime(_updatePayData.periodEndingOn).ToString("dd/MMM/yyyy"));
            else
                cmd.Parameters.AddWithValue("@periodEndingOn", System.DBNull.Value);

            if (_updatePayData.prevCertifiedAmt != 0)
              cmd.Parameters.AddWithValue("@prevCertifiedAmt", _updatePayData.prevCertifiedAmt);       // - 20
            else
              cmd.Parameters.AddWithValue("@prevCertifiedAmt", System.DBNull.Value);


            cmd.Parameters.AddWithValue("@prevRPno", _updatePayData.prevRPno);

             if (_updatePayData.prevTotalCertifiedAmt != 0)
                cmd.Parameters.AddWithValue("@prevTotalCertifiedAmt", _updatePayData.prevTotalCertifiedAmt);
             else
                cmd.Parameters.AddWithValue("@prevTotalCertifiedAmt", System.DBNull.Value);


            if (_updatePayData.prjStartDate != "")
                cmd.Parameters.AddWithValue("@prjStartDate", Convert.ToDateTime(_updatePayData.prjStartDate).ToString("dd/MMM/yyyy"));        // 5 
            else
                cmd.Parameters.AddWithValue("@prjStartDate", System.DBNull.Value);

            cmd.Parameters.AddWithValue("@projectCode", _updatePayData.projectCode);  //- 10
            cmd.Parameters.AddWithValue("@projectTitle", _updatePayData.prjTitle);
            cmd.Parameters.AddWithValue("@provisionNumber", _updatePayData.provisionNumber);

            if (_updatePayData.receivedByEBSD1On != "")
                cmd.Parameters.AddWithValue("@receivedByEBSD1On",  Convert.ToDateTime(_updatePayData.receivedByEBSD1On).ToString("dd/MMM/yyyy"));
            else
                cmd.Parameters.AddWithValue("@receivedByEBSD1On", System.DBNull.Value);

            // Updating at Index change event

            //if (_updatePayData.receivedByEBSD2On != "")
            //    cmd.Parameters.AddWithValue("@receivedByEBSD2On", Convert.ToDateTime(_updatePayData.receivedByEBSD2On).ToString("dd/MMM/yyyy"));
            //else
            //    cmd.Parameters.AddWithValue("@receivedByEBSD2On", System.DBNull.Value);

            if (_updatePayData.reIssuedByDeptToFin != "")
                cmd.Parameters.AddWithValue("@reIssuedByDeptToFin", Convert.ToDateTime(_updatePayData.reIssuedByDeptToFin).ToString("dd/MMM/yyyy"));       // -40
            else
                cmd.Parameters.AddWithValue("@reIssuedByDeptToFin", System.DBNull.Value);

            cmd.Parameters.AddWithValue("@remarks", _updatePayData.remarks);

             if (_updatePayData.requestedAmt != 0)
               cmd.Parameters.AddWithValue("@requestedAmt", _updatePayData.requestedAmt);
             else
                  cmd.Parameters.AddWithValue("@requestedAmt", System.DBNull.Value);

             if (_updatePayData.retentionAmt != 0)
                cmd.Parameters.AddWithValue("@retentionAmt", _updatePayData.retentionAmt);
             else
               cmd.Parameters.AddWithValue("@retentionAmt", System.DBNull.Value);

            if (txtRetensionRelease.Text != "")
                cmd.Parameters.AddWithValue("@retentionReleaseAmt", Convert.ToDouble(txtRetensionRelease.Text));
            else
                cmd.Parameters.AddWithValue("@retentionReleaseAmt", System.DBNull.Value);


            if (_updatePayData.returnByFinOn != "")
                cmd.Parameters.AddWithValue("@returnByFinOn", Convert.ToDateTime(_updatePayData.returnByFinOn).ToString("dd/MMM/yyyy"));
            else
                cmd.Parameters.AddWithValue("@returnByFinOn", System.DBNull.Value);

            // Updating at Index change event

            //if (_updatePayData.sentBackForCorrectionOn != "")
            //    cmd.Parameters.AddWithValue("@sentBackForCorrectionOn", Convert.ToDateTime(_updatePayData.sentBackForCorrectionOn).ToString("dd/MMM/yyyy"));        // -35
            //else
            //    cmd.Parameters.AddWithValue("@sentBackForCorrectionOn", System.DBNull.Value);

             if (_updatePayData.totalAdvancePayment != 0)
                cmd.Parameters.AddWithValue("@totalAdvancePayment", _updatePayData.totalAdvancePayment);
             else
                cmd.Parameters.AddWithValue("@totalAdvancePayment", System.DBNull.Value);

            if (_updatePayData.totalCertifiedAmt != 0)
               cmd.Parameters.AddWithValue("@totalCertifiedAmt", _updatePayData.totalCertifiedAmt);
            else
                cmd.Parameters.AddWithValue("@totalCertifiedAmt", System.DBNull.Value);

           // cmd.Parameters.AddWithValue("@updateDate", Session["UserName"].ToString());
            cmd.Parameters.AddWithValue("@updateUser", Session["UserName"].ToString());
        }
        catch (Exception ex)
        {

            throw ex;
        }

        try
        {
            con.Open();
            cmd.ExecuteNonQuery();
            con.Dispose();
        }
        catch (Exception ex)
        {

            throw ex;
        }
        finally
        {
            con.Close();
        }


        // return sqlCmd.Parameters["@docID"].Value.ToString();



        return _updatePayData.jobID;
    }

    JobOrderProperty _updatePayData = new JobOrderProperty();
    public JobOrderProperty PassPaymentData(JobOrderProperty _updatePayData)
    {
        _updatePayData.prjTitle = txtProjTitle.Text;
        _updatePayData.contractorName = txtCntrName.Text;
        _updatePayData.prjStartDate = txtCntrStartDate.Text;

        _updatePayData.latestCompletionDate = txtLtstFinDate.Text;

        _updatePayData.completionDate = txtLtstFinDate.Text; // change

         if (ddlDept.SelectedValue!="")
           _updatePayData.deptID = Convert.ToInt32(ddlDept.SelectedValue);
         else
            _updatePayData.deptID = 1;

         if (ddlPayFor.SelectedValue != "")
             _updatePayData.paymentForId = Convert.ToInt32(ddlPayFor.SelectedValue);
         else
             _updatePayData.paymentForId = 1;

        _updatePayData.projectCode = txtprjCode.Text;

        _updatePayData.provisionNumber = txtProvNo.Text;
        _updatePayData.budgetRefNo = txtBudRef.Text;

        _updatePayData.periodEndingOn = txtPeriodEnd.Text;

        if (txtCntrAmt.Text != "")
          _updatePayData.contractAmt = Convert.ToDouble(txtCntrAmt.Text);
        else
            _updatePayData.requestedAmt = 0;

        if (txtVariationDateAmt.Text != "")
            _updatePayData.approvedchangesAmt = Convert.ToDouble(txtVariationDateAmt.Text);
        else
            _updatePayData.approvedchangesAmt = 0;

        _updatePayData.latestVONo = txtVoNo.Text;

        if (txtReqAmt.Text != "")
            _updatePayData.requestedAmt = Convert.ToDouble(txtReqAmt.Text);
         else
            _updatePayData.requestedAmt = 0;

        _updatePayData.prevRPno = txtPCMRPno.Text;

        if (txtPcmPrvTotalAmt.Text != "")
            _updatePayData.prevTotalCertifiedAmt = Convert.ToDouble(txtPcmPrvTotalAmt.Text);   
         else
            _updatePayData.prevTotalCertifiedAmt = 0;

         if (txtPCMCertAmt.Text != "")
             _updatePayData.prevCertifiedAmt = Convert.ToDouble(txtPCMCertAmt.Text);         //Prev
         else
            _updatePayData.prevCertifiedAmt = 0;
        //Certified amount 
        if (txtNetCertAmt.Text != "")
            _updatePayData.certifiedAmt = Convert.ToDouble(txtNetCertAmt.Text);
        else
            _updatePayData.certifiedAmt = 0;

        if (txtTotCertAmt.Text != "")
            _updatePayData.totalCertifiedAmt = Convert.ToDouble(txtTotCertAmt.Text);
        else
            _updatePayData.totalCertifiedAmt = 0;

        if (txtTotalAdv.Text != "")
            _updatePayData.totalAdvancePayment = Convert.ToDouble(txtTotalAdv.Text);

        if (txtAdvRecov.Text != "")
            _updatePayData.advancePayRecoveryAmt = Convert.ToDouble(txtAdvRecov.Text);

        if (txtLatestBudget.Text != "")
            _updatePayData.latestBudgetAmt = Convert.ToDouble(txtLatestBudget.Text);
        else
            _updatePayData.latestBudgetAmt = 0;

        if (txtPenaltyDate.Text != "")
            _updatePayData.penaltyAmt = Convert.ToDouble(txtPenaltyDate.Text);
        else
            _updatePayData.penaltyAmt = 0;

        if (txtRetensionToDateAmt.Text != "")
            _updatePayData.retentionAmt = Convert.ToDouble(txtRetensionToDateAmt.Text);
        else
            _updatePayData.retentionAmt = 0;


        _updatePayData.issuedByContractorOn = txtIssuedByCntr.Text;
        _updatePayData.issuedBySupervisionOn = txtSupervision.Text;
         _updatePayData.receivedByEBSD1On = txtdateRecEbsd.Text;        

        _updatePayData.issuedByPMCOn = txtPMC.Text;
        _updatePayData.issuedByArchiveOn = txtIssuedArchive.Text;
        _updatePayData.issuedByEBSDOn = txtIssuedByEbsd.Text;

        _updatePayData.sentBackForCorrectionOn = txtCorrection.Text;

        _updatePayData.receivedByEBSD2On = txtRecCorrection.Text;
        _updatePayData.issuedByEBSD2On = txtReIssued.Text;
        _updatePayData.issuedByDeptToFinOn = txtIssuedFin.Text;
        _updatePayData.returnByFinOn = txtRetFin.Text;

        _updatePayData.reIssuedByDeptToFin = txtReIssuedFin.Text;

        _updatePayData.dateCertified = txtDateCertified.Text;
       
        if (ddlStatus.SelectedValue != "")
        _updatePayData.jobStatusID = Convert.ToInt32(ddlStatus.SelectedValue);
        else
            _updatePayData.jobStatusID =1;

        _updatePayData.remarks = txtRemarks.Text;
        //  _updatePayData.completionDate = ;
        _updatePayData.updateDate = System.DateTime.Now.ToString();

        return _updatePayData;         
    }    

    protected void txtIssuedByEbsd_TextChanged(object sender, EventArgs e)
    {
        if (txtIssuedByEbsd.Text != "")
        {
            DateTime fromDate = Convert.ToDateTime(txtIssuedByEbsd.Text);
            DateTime toDate = Convert.ToDateTime(txtdateRecEbsd.Text);

            DateTime dt = DateTime.Parse(fromDate.ToShortDateString());
            DateTime dt1 = DateTime.Parse(toDate.ToShortDateString());

            double noOfDays = dt.Subtract(dt1).TotalDays;

            if (Convert.ToInt16(noOfDays) < 0)
            {
                txtIssuedByEbsd.Text = "";
                ClientScript.RegisterClientScriptBlock(this.GetType(), "Popup", "<script>alert('The Issued By EBSD Date cannot be less than the Date Received By EBSD.')</script>", false);
                return;
            }
        }

       // Label3.Text = issedByEBSDDate;
        if (txtIssuedByEbsd.Text != "")
        {
            txtCorrection.Enabled = false;
            txtRecCorrection.Enabled = false;
            txtReIssued.Enabled = false;
        }
        else
        {
            txtCorrection.Enabled = true;
            txtRecCorrection.Enabled = true;
            txtReIssued.Enabled = true;
        }       

        if (txtCorrection.Text == "")
        {
            if (Session["contactID"].ToString().Equals(Session["userID"].ToString()))
            {
                //if (txtIssuedByEbsd.Text != "")
                //{
                //    //Response.Write("Status = 7");
                //    updateIssedEbsdPaymentData(_payID, txtIssuedByEbsd.Text, 1, 7);
                //}
                //else
                //{
                //    //Response.Write("Status = 3"); 
                //    updateIssedEbsdPaymentData(_payID, txtIssuedByEbsd.Text, 3, 3);
                //}

              // updateIssedEbsdPaymentData(_payID, txtIssuedByEbsd.Text, 1, 7);

               updateJobOwnerData(_payID, txtIssuedByEbsd.Text, Convert.ToInt32(Session["contactID"]));

                // updateDistributionData(_payID, txtIssuedByEbsd.Text);
            }

           // fillPaymentData();
            gvJoborder.DataSource = new JobOrderData().GetPaymentJobOwnerDetails(_payID);
            gvJoborder.DataBind();
        }
        else
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "Popup", "<script>alert('You can't update Issuedate ')</script>", false);
        }
       
    }
    private void updateIssedEbsdPaymentData(int _payID,string issedByEBSDDate,int jobStatusID,int inchargeStatusID)
    {
        string updPayments = string.Empty;
        
        updPayments = "UPdate Payment Set issuedByEBSDOn = @issuedByEBSDOn where PayID =@payID ";    


        SqlConnection con = new SqlConnection(connValue);
        SqlCommand cmd = new SqlCommand();
        cmd.CommandType = CommandType.Text;
        cmd.Connection = con;
        cmd.CommandText = updPayments;
        try
        {
            cmd.Parameters.AddWithValue("@payID", _payID);            

            //   cmd.Parameters.AddWithValue("@jobStatusID", jobStatusID);

            if (issedByEBSDDate != "")
                cmd.Parameters.AddWithValue("@issuedByEBSDOn", issedByEBSDDate);         
            else
                cmd.Parameters.AddWithValue("@issuedByEBSDOn", System.DBNull.Value);

            if (issedByEBSDDate != "")
                cmd.Parameters.AddWithValue("@completionDate", issedByEBSDDate);
            else
                cmd.Parameters.AddWithValue("@completionDate", System.DBNull.Value);

            
        }
        catch (Exception ex)
        {
            throw ex;            
        }
        try
        {
            con.Open();
            cmd.ExecuteNonQuery();
            con.Dispose();
        }
        catch (Exception ex)
        {

            throw ex;
            Response.Write(ex.Message);
        }
        finally
        {
            con.Close();
        }
    }
    private void CheckAndUpdateJobOwnerData(int payID, string txtValue,int cntctID)
    { 
        SqlConnection con = new SqlConnection(connValue);
        SqlCommand cmd = new SqlCommand();
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Connection = con;
        cmd.CommandText = "pay_ChkAndUpdateStaffData";

        try
        {
            cmd.Parameters.AddWithValue("@payID", payID);
            
            // 7 - completed       
            
            if (txtValue != "")
            {
                cmd.Parameters.AddWithValue("@completionDate", txtValue);
                cmd.Parameters.AddWithValue("@jobDone", true);
                cmd.Parameters.AddWithValue("@jobOwnerStatusID", 7); 
            }
            else
            {
                cmd.Parameters.AddWithValue("@completionDate", System.DBNull.Value);
                cmd.Parameters.AddWithValue("@jobDone", false);
                cmd.Parameters.AddWithValue("@jobOwnerStatusID", 3); 
            }

            cmd.Parameters.AddWithValue("@contactID", cntctID); 
        }
        catch (Exception ex)
        {
            throw ex;
        }
        try
        {
            con.Open();
            cmd.ExecuteNonQuery();
            con.Dispose();
        }
        catch (Exception ex)
        {

            throw ex;
        }
        finally
        {
            con.Close();
        }
    }

    // This function says payment closed when user enter date certified by finance.

    private void updateJobStatusDateCertified(int payID, int statusID, string txtVal)
    {
        //string updJobIncharge = "UPdate JobOwner Set jobOwnerStatusID = @jobOwnerStatusID,jobDone =@jobDone,completionDate= @completionDate  where payID =@payID ";

        SqlConnection con = new SqlConnection(connValue);
        SqlCommand cmd = new SqlCommand();
        cmd.CommandType = CommandType.Text;
        cmd.Connection = con;
        cmd.CommandText = "Update Payment set JobstatusID = @StatusID,dateCertified = @dateCertified where payID =@payID ";

        try
        {
            cmd.Parameters.AddWithValue("@payID", payID);
            cmd.Parameters.AddWithValue("@StatusID", statusID);
           
            if (txtVal == "")
              cmd.Parameters.AddWithValue("@dateCertified", System.DBNull.Value);
            else
                cmd.Parameters.AddWithValue("@dateCertified", txtVal);

        }
        catch (Exception ex)
        {
            throw ex;
        }
        try
        {
            con.Open();
            cmd.ExecuteNonQuery();
            con.Dispose();
        }
        catch (Exception ex)
        {

            throw ex;
        }
        finally
        {
            con.Close();
        }
    }

    private void updateJobStatusPending(int payID, int statusID,string txtVal)
    {
        //string updJobIncharge = "UPdate JobOwner Set jobOwnerStatusID = @jobOwnerStatusID,jobDone =@jobDone,completionDate= @completionDate  where payID =@payID ";

        SqlConnection con = new SqlConnection(connValue);
        SqlCommand cmd = new SqlCommand();
        cmd.CommandType = CommandType.Text;
        cmd.Connection = con;
        cmd.CommandText = "Update Payment set JobstatusID = @StatusID,issuedByDeptToFinOn = @issuedByDeptToFinOn where payID =@payID ";

        try
        {
            cmd.Parameters.AddWithValue("@payID", payID);

            cmd.Parameters.AddWithValue("@StatusID", statusID);
            
            if (txtVal == "")
               cmd.Parameters.AddWithValue("@issuedByDeptToFinOn", System.DBNull.Value);
            else
                cmd.Parameters.AddWithValue("@issuedByDeptToFinOn", txtVal);

        }
        catch (Exception ex)
        {
            throw ex;
        }
        try
        {
            con.Open();
            cmd.ExecuteNonQuery();
            con.Dispose();
        }
        catch (Exception ex)
        {

            throw ex;
        }
        finally
        {
            con.Close();
        }
    }

  //  
    private void UpdatePayCorreIssueData(int payID, string txtValue, int cntctID)
    {
        //string updJobIncharge = "UPdate JobOwner Set jobOwnerStatusID = @jobOwnerStatusID,jobDone =@jobDone,completionDate= @completionDate  where payID =@payID ";

        SqlConnection con = new SqlConnection(connValue);
        SqlCommand cmd = new SqlCommand();
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Connection = con;
        cmd.CommandText = "pay_UpdatePayCorreIssueData";
        try
        {
            cmd.Parameters.AddWithValue("@payID", payID);
            // 7 - completed        

            if (txtValue != "")
            {
                cmd.Parameters.AddWithValue("@Corr_issudDate", txtValue);
                cmd.Parameters.AddWithValue("@jobDone", true);
                cmd.Parameters.AddWithValue("@jobOwnerStatusID", 7);
            }
            else
            {
                cmd.Parameters.AddWithValue("@Corr_issudDate", System.DBNull.Value);
                cmd.Parameters.AddWithValue("@jobDone", false);
                cmd.Parameters.AddWithValue("@jobOwnerStatusID", 3);
            }

            cmd.Parameters.AddWithValue("@contactID", cntctID);

            cmd.Parameters.AddWithValue("@updateUser", Session["UserName"].ToString());

        }
        catch (Exception ex)
        {
            throw ex;
        }
        try
        {
            con.Open();
            cmd.ExecuteNonQuery();
            con.Dispose();
        }
        catch (Exception ex)
        {

            throw ex;
        }
        finally
        {
            con.Close();
        }
    }
    private void updateJobOwnerData(int payID, string txtValue, int cntctID)
    {
        //string updJobIncharge = "UPdate JobOwner Set jobOwnerStatusID = @jobOwnerStatusID,jobDone =@jobDone,completionDate= @completionDate  where payID =@payID ";

        SqlConnection con = new SqlConnection(connValue);
        SqlCommand cmd = new SqlCommand();
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Connection = con;
        cmd.CommandText = "pay_UpdatePayStaffStatus";

        try
        {
            cmd.Parameters.AddWithValue("@payID", payID);
            // 7 - completed

            if (txtValue != "")
            {
                cmd.Parameters.AddWithValue("@issudDate", txtValue);
                cmd.Parameters.AddWithValue("@jobDone", true);
                cmd.Parameters.AddWithValue("@jobOwnerStatusID", 7);
            }
            else
            {
                cmd.Parameters.AddWithValue("@issudDate", System.DBNull.Value);
                cmd.Parameters.AddWithValue("@jobDone", false);
                cmd.Parameters.AddWithValue("@jobOwnerStatusID", 3);
            }

            cmd.Parameters.AddWithValue("@contactID", cntctID);
            cmd.Parameters.AddWithValue("@updateUser", Session["UserName"].ToString());
        }
        catch (Exception ex)
        {
            throw ex;
        }
        try
        {
            con.Open();
            cmd.ExecuteNonQuery();
            con.Dispose();
        }
        catch (Exception ex)
        {

            throw ex;
        }
        finally
        {
            con.Close();
        }
    }   
    private void updateDistributionData(int jobInchargeID, string txtValue)
    {
        string updJobIncharge = "UPdate DocumentDistribution Set docStatusID = @docStatusID,actionDueDate= @actionDueDate,dateOfAction =@dateOfAction  where jobOwnerID =@jobOwnerID ";

        SqlConnection con = new SqlConnection(connValue);
        SqlCommand cmd = new SqlCommand();
        cmd.CommandType = CommandType.Text;
        cmd.Connection = con;
        cmd.CommandText = updJobIncharge;

        try
        {
            cmd.Parameters.AddWithValue("@jobOwnerID", jobInchargeID);
            // 7 - completed        


            if (txtValue != "")
            {
                cmd.Parameters.AddWithValue("@actionDueDate", txtValue);
                cmd.Parameters.AddWithValue("@dateOfAction", txtValue);
                cmd.Parameters.AddWithValue("@docStatusID", 7);
            }
            else
            {
                cmd.Parameters.AddWithValue("@actionDueDate", System.DBNull.Value);
                cmd.Parameters.AddWithValue("@dateOfAction", System.DBNull.Value);
                cmd.Parameters.AddWithValue("@docStatusID", 3);
            }

        }
        catch (Exception ex)
        {
            throw ex;
        }
        try
        {
            con.Open();
            cmd.ExecuteNonQuery();
            con.Dispose();
        }
        catch (Exception ex)
        {

            throw ex;
        }
        finally
        {
            con.Close();
        }
    }
    private void updateJobOwnerDataForReIssued(int payID, string txtValue)
    {
        string updJobIncharge = "UPdate JobOwner Set jobOwnerStatusID = @jobOwnerStatusID,jobDone =@jobDone,completionDate= @completionDate " + 
            " WHERE (jobOwnerID = (SELECT MAX(jobOwnerID) AS Expr1 FROM JobOwner AS JobOwner_1  WHERE (payID = @payID)))";

        SqlConnection con = new SqlConnection(connValue);
        SqlCommand cmd = new SqlCommand();
        cmd.CommandType = CommandType.Text;
        cmd.Connection = con;
        cmd.CommandText = updJobIncharge;

        try
        {
            cmd.Parameters.AddWithValue("@payID", payID);
            // 7 - completed        


            if (txtValue != "")
            {
                cmd.Parameters.AddWithValue("@completionDate", txtValue);
                cmd.Parameters.AddWithValue("@jobDone", true);
                cmd.Parameters.AddWithValue("@jobOwnerStatusID", 7);
            }
            else
            {
                cmd.Parameters.AddWithValue("@completionDate", System.DBNull.Value);
                cmd.Parameters.AddWithValue("@jobDone", false);
                cmd.Parameters.AddWithValue("@jobOwnerStatusID", 3);
            }

        }
        catch (Exception ex)
        {
            throw ex;
        }
        try
        {
            con.Open();
            cmd.ExecuteNonQuery();
            con.Dispose();
        }
        catch (Exception ex)
        {

            throw ex;
        }
        finally
        {
            con.Close();
        }
    }
    protected void txtCorrection_TextChanged(object sender, EventArgs e)
    {
        if ((txtCorrection.Text != "") && (txtdateRecEbsd.Text != ""))
        {
            DateTime fromDate = Convert.ToDateTime(txtCorrection.Text);
            DateTime toDate = Convert.ToDateTime(txtdateRecEbsd.Text);

            DateTime dt = DateTime.Parse(fromDate.ToShortDateString());
            DateTime dt1 = DateTime.Parse(toDate.ToShortDateString());

            double noOfDays = dt.Subtract(dt1).TotalDays;

            if (Convert.ToInt16(noOfDays) < 0)
            {
                txtCorrection.Text = "";
                ClientScript.RegisterClientScriptBlock(this.GetType(), "Popup", "<script>alert('The Back for Correction Date cannot be less than the Date Received By EBSD.')</script>", false);
                return;
            }
        }

        if (Session["contactID"].ToString().Equals(Session["userID"].ToString()))
        {
            if (txtCorrection.Text != "")
                txtIssuedByEbsd.Enabled = false;
            else
                txtIssuedByEbsd.Enabled = true;

            // txtCorrection.Text = Convert.ToDateTime(txtCorrection.Text).ToString("dd/MMM/yyyy");

            txtRecCorrection.Text = "";
            txtReIssued.Text = "";

            updateCorrectionPaymentData(_payID, txtCorrection.Text, 2,Convert.ToInt32(Session["UserID"]));     // 2- Job Returned    // 4- holding Changed as // 7- Closed  // 4- pending 
            
            fillPaymentData();

            gvJoborder.DataSource = new JobOrderData().GetPaymentJobOwnerDetails(_payID);
            gvJoborder.DataBind();
        }

       // getMaxCorrectionNO(_payID);
    }
    private void updateCorrectionPaymentData(int _payID, string issedByEBSDDate, int jobStatusID,int _currentUserID)
    {
       // string updPayments = "Update Payment Set sentBackForCorrectionOn = @sentBackForCorrectionOn,jobStatusID = @jobStatusID,completionDate =@completionDate ,receivedByEBSD2On = @receivedByEBSD2On,issuedByEBSD2On  = @issuedByEBSD2On   where PayID =@payID";

        //completionDate = null

        SqlConnection con = new SqlConnection(connValue);
        SqlCommand cmd = new SqlCommand();
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Connection = con;
        cmd.CommandText ="pay_UpdatePayBackforCorre";

        try
        {
            cmd.Parameters.AddWithValue("@payID", _payID);
            cmd.Parameters.AddWithValue("@jobStatusID", jobStatusID);        // pending or Hold

            if (issedByEBSDDate != "")
                cmd.Parameters.AddWithValue("@sentBackForCorrectionOn", issedByEBSDDate);    //Convert.ToDateTime(issedByEBSDDate).ToString("dd/MMM/yyyy"));
            else
                cmd.Parameters.AddWithValue("@sentBackForCorrectionOn", System.DBNull.Value);

            cmd.Parameters.AddWithValue("@completionDate", System.DBNull.Value);

            cmd.Parameters.AddWithValue("@receivedByEBSD2On", System.DBNull.Value);
            cmd.Parameters.AddWithValue("@issuedByEBSD2On", System.DBNull.Value);

            cmd.Parameters.AddWithValue("@contactID", _currentUserID);

           // cmd.Parameters.AddWithValue("@updateDate", Session["UserName"].ToString());
            cmd.Parameters.AddWithValue("@updateUser", Session["UserName"].ToString());
        }
        catch (Exception ex)
        {

            throw ex;
        }

        try
        {
            con.Open();
            cmd.ExecuteNonQuery();
            con.Dispose();
        }
        catch (Exception ex)
        {

            throw ex;
        }
        finally
        {
            con.Close();
        }


    }
    private void getMaxCorrectionNO(int _payID)
    {
        using (SqlConnection cn = new SqlConnection(connValue))
        {
            cn.Open();
            using (SqlCommand cmd = new SqlCommand())
            {
                cmd.Connection = cn;
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.CommandText = "PaymentTaskCount";
                cmd.Parameters.AddWithValue("@payID", _payID);

                cmd.ExecuteNonQuery();
            }
        }
    }

    protected void txtRecCorrection_TextChanged(object sender, EventArgs e)
    {
        //txtRecCorrection.Text = Convert.ToDateTime(txtRecCorrection.Text).ToString("dd/MMM/yyyy");
        //if (Session["contactID"].ToString().Equals(Session["userID"].ToString()))

        if ((txtRecCorrection.Text != "") && (txtCorrection.Text != ""))
        {
            DateTime fromDate = Convert.ToDateTime(txtRecCorrection.Text);
            DateTime toDate = Convert.ToDateTime(txtCorrection.Text);

            DateTime dt = DateTime.Parse(fromDate.ToShortDateString());
            DateTime dt1 = DateTime.Parse(toDate.ToShortDateString());

            double noOfDays = dt.Subtract(dt1).TotalDays;

            if (Convert.ToInt16(noOfDays) < 0)
            {
                txtRecCorrection.Text = "";
                ClientScript.RegisterClientScriptBlock(this.GetType(), "Popup", "<script>alert('The Corr.Receive By EBSD Date cannot be less than the Back for Correction.')</script>", false);
                return;
            }
        }


        if (txtRecCorrection.Text != "")
        {
            txtReIssued.Enabled = false;
            txtCorrection.Enabled = false;
        }

        if (!userRightsColl.Contains("20"))
        {
            if (txtReIssued.Text == "" && txtCorrection.Text != "")
            {
                if (txtRecCorrection.Text != "")
                {
                    //updateReCorrectionPaymentData(_payID, txtRecCorrection.Text, 3); 
                    InsertStaffPaymentData(_payID, txtRecCorrection.Text, 3);
                }
                else
                {
                    if (txtCorrection.Text != "")
                    {
                        updateReCorrectionPaymentData(_payID, txtRecCorrection.Text, 4);

                       if( getStaffCountOfPay() >1)       // if only one row exist in jobowner table for certain payment then dont delete. Delete only second row that re-process payment. 
                         DeleteStaffData(_payID);
                    }
                }
            }
            {
                ClientScript.RegisterClientScriptBlock(this.GetType(), "Popup", "<script>alert('You can't update Issuedate ')</script>", false);
            }

            fillPaymentData();
            gvJoborder.DataSource = new JobOrderData().GetPaymentJobOwnerDetails(_payID);
            gvJoborder.DataBind();
        }
    }
    private void DeleteStaffData(int _payID)
    {
        string updPayments = "DELETE FROM JobOwner WHERE (jobOwnerID =  (SELECT  TOP (1) jobOwnerID  FROM JobOwner AS JobOwner_1  WHERE   (payID = @payID)  ORDER BY jobOwnerID DESC))";

        SqlConnection con = new SqlConnection(connValue);
        SqlCommand cmd = new SqlCommand();
        cmd.CommandType = CommandType.Text;
        cmd.Connection = con;
        cmd.CommandText = updPayments;


        try
        {
            cmd.Parameters.AddWithValue("@payID", _payID);                
        }
        catch (Exception ex)
        {

            throw ex;
        }

        try
        {
            con.Open();
            cmd.ExecuteNonQuery();
            con.Dispose();
        }
        catch (Exception ex)
        {

            throw ex;
        }
        finally
        {
            con.Close();
        }


       // string insertInchergeDat = "INSERT INTO JOBOWNERE VALUES()";
    }


    private int getStaffCountOfPay()
    {
        int staffCnt = 0;
        using (SqlConnection con = new SqlConnection(connValue))
        {
            using (SqlCommand cmd = new SqlCommand())
            {
                cmd.CommandType = CommandType.Text;
                cmd.Connection = con;

                cmd.CommandText = "SELECT COUNT(jobOwnerID) AS jCnt FROM JobOwner WHERE (payID = " + _payID + ")";                
                con.Open();      
                
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        staffCnt = Convert.ToInt16(dr["jCnt"]);
                    }
                }
                else
                    staffCnt = 0;
            }

            con.Close();
        }

        return staffCnt;        //cmd.Parameters[2].Value.ToString()

    }

    private string getEndDateByGivenDays(string strDate, int workDays)
    {
        SqlConnection con = new SqlConnection(connValue);
        SqlCommand cmd = new SqlCommand();
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Connection = con;

        cmd.CommandText = "AddWorkdays";
        SqlParameter prm = cmd.Parameters.Add("@ad_startDate", SqlDbType.DateTime);
        prm.Value = strDate;
        prm = cmd.Parameters.Add("@actual_workDays", SqlDbType.Int);
        prm.Value = workDays;
        prm = cmd.Parameters.Add("@endDate", SqlDbType.DateTime);
        prm.Direction = ParameterDirection.Output;
        con.Open();
        SqlDataReader dr = cmd.ExecuteReader();
        while (dr.Read())
            Console.WriteLine(dr.GetString(0));
        con.Dispose();
        con.Close();

        return cmd.Parameters[2].Value.ToString();
    }
    private void InsertStaffPaymentData(int _payID, string issedByEBSDDate, int jobStatusID)
    {
        if (issedByEBSDDate == "")
            return;

        //string actionDate = getEndDateByGivenDays(issedByEBSDDate, 4);

        SqlConnection con = new SqlConnection(connValue);
        SqlCommand cmd = new SqlCommand();
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Connection = con;
        cmd.CommandText = "pay_ChkAndUpdateStaffData";


        try
        {
            cmd.Parameters.AddWithValue("@payID", _payID);

            cmd.Parameters.AddWithValue("@contactID", Convert.ToInt32(Session["UserID"]));
           // cmd.Parameters.AddWithValue("@actionDueDate", Convert.ToDateTime(actionDate).ToString("dd/MMM/yyyy"));

            cmd.Parameters.AddWithValue("@staffIssueDate", Convert.ToDateTime(issedByEBSDDate).ToString("dd/MMM/yyyy"));
            
            cmd.Parameters.AddWithValue("@createDate", Convert.ToDateTime(System.DateTime.Now).ToString("dd/MMM/yyyy"));
            cmd.Parameters.AddWithValue("@createUser", Session["Username"].ToString());
        }
        catch (Exception ex)
        {
            throw ex;
        }
        try
        {
            con.Open();
            cmd.ExecuteNonQuery();
            con.Dispose();
        }
        catch (Exception ex)
        {

            throw ex;
        }
        finally
        {
            con.Close();
        }
    }
    private void updateReCorrectionPaymentData(int _payID, string issedByEBSDDate, int jobStatusID)
    {
        string updPayments = "Update Payment Set receivedByEBSD2On = @receivedByEBSD2On,jobStatusID = @jobStatusID,completionDate =@completionDate where PayID =@payID";

        SqlConnection con = new SqlConnection(connValue);
        SqlCommand cmd = new SqlCommand();
        cmd.CommandType = CommandType.Text;
        cmd.Connection = con;
        cmd.CommandText = updPayments;


        try
        {
            cmd.Parameters.AddWithValue("@payID", _payID);
            cmd.Parameters.AddWithValue("@jobStatusID", jobStatusID);

            if (issedByEBSDDate != "")
                cmd.Parameters.AddWithValue("@receivedByEBSD2On", issedByEBSDDate);      //  Convert.ToDateTime(issedByEBSDDate).ToString("dd/MMM/yyyy"));
            else
                cmd.Parameters.AddWithValue("@receivedByEBSD2On", System.DBNull.Value);

            cmd.Parameters.AddWithValue("@completionDate", System.DBNull.Value);

            cmd.Parameters.AddWithValue("@updateUser", Session["UserName"].ToString());
        }
        catch (Exception ex)
        {

            throw ex;
        }

        try
        {
            con.Open();
            cmd.ExecuteNonQuery();
            con.Dispose();
        }
        catch (Exception ex)
        {

            throw ex;
        }
        finally
        {
            con.Close();
        }


        string insertInchergeDat = "INSERT INTO JOBOWNERE VALUES()";
    }
    //private void InsertStaffData(int _payID, string issedByEBSDDate, int jobStatusID)
    //{
    //    string updPayments = "INSERT INTO JOBOWNER(contactID, payID, jobDocRefID, projectCode, projectTitle, jobNo, jobOwnerCatID, actionDueDate, daysToAct, jobOwnerStatusID, jobPurposeID, JobTypeID, StaffRoleID," +
    //                    " sectionID, staffIssueDate, distributedBy, createUser, createDate) VALUES(@contactID, @payID, @jobDocRefID, @projectCode, @projectTitle, @jobNo, @jobOwnerCatID, @actionDueDate, @daysToAct, @jobOwnerStatusID, @jobPurposeID, @JobTypeID, @StaffRoleID," +
    //                    " @sectionID, @staffIssueDate, @distributedBy,@ createUser, @createDate) ";

    //    SqlConnection con = new SqlConnection(connValue);
    //    SqlCommand cmd = new SqlCommand();
    //    cmd.CommandType = CommandType.Text;
    //    cmd.Connection = con;
    //    cmd.CommandText = updPayments;


    //    try
    //    {
    //        cmd.Parameters.AddWithValue("@payID", _payID);
    //        cmd.Parameters.AddWithValue("@jobStatusID", jobStatusID);

    //        if (issedByEBSDDate != "")
    //            cmd.Parameters.AddWithValue("@receivedByEBSD2On", Convert.ToDateTime(issedByEBSDDate).ToString("dd/MMM/yyyy"));
    //        else
    //            cmd.Parameters.AddWithValue("@receivedByEBSD2On", System.DBNull.Value);

    //        cmd.Parameters.AddWithValue("@completionDate", System.DBNull.Value);



    //        cmd.Parameters.AddWithValue("@completionDate", System.DBNull.Value);
    //        cmd.Parameters.AddWithValue("@createDate", System.DBNull.Value);
    //        cmd.Parameters.AddWithValue("@createUser", System.DBNull.Value);
    //    }
    //    catch (Exception ex)
    //    {

    //        throw ex;
    //    }

    //    try
    //    {
    //        con.Open();
    //        cmd.ExecuteNonQuery();
    //        con.Dispose();
    //    }
    //    catch (Exception ex)
    //    {

    //        throw ex;
    //    }
    //    finally
    //    {
    //        con.Close();
    //    }


    //    string insertInchergeDat = "INSERT INTO JOBOWNERE VALUES()";
    //}
    protected void txtReIssued_TextChanged(object sender, EventArgs e)
    {
        //txtReIssued.Text = Convert.ToDateTime(txtReIssued.Text).ToString("dd/MMM/yyyy");

        if ((txtReIssued.Text != "") && (txtRecCorrection.Text != ""))
        {
            DateTime fromDate = Convert.ToDateTime(txtReIssued.Text);
            DateTime toDate = Convert.ToDateTime(txtRecCorrection.Text);

            DateTime dt = DateTime.Parse(fromDate.ToShortDateString());
            DateTime dt1 = DateTime.Parse(toDate.ToShortDateString());

            double noOfDays = dt.Subtract(dt1).TotalDays;

            if (Convert.ToInt16(noOfDays) < 0)
            {
                txtReIssued.Text = "";
                ClientScript.RegisterClientScriptBlock(this.GetType(), "Popup", "<script>alert('The Corr.Issued By EBSD Date cannot be less than the Date Received By EBSD.')</script>", false);
                return;
            }
        }

        if (txtRecCorrection.Text != "")
        {
            if (Session["contactID"].ToString().Equals(Session["userID"].ToString()))
            {
                UpdatePayCorreIssueData(_payID, txtReIssued.Text, Convert.ToInt32(Session["contactID"]));

                fillPaymentData();

                gvJoborder.DataSource = new JobOrderData().GetPaymentJobOwnerDetails(_payID);
                gvJoborder.DataBind();
            }
        }
        else
        {
            txtReIssued.Text = "";            
        }
    }
    private void updateReIssuedPaymentData(int _payID, string issuedByEBSDDate, int jobStatusID)
    {
        string updPayments = "Update Payment Set issuedByEBSD2On = @issuedByEBSD2On,jobStatusID = @jobStatusID,completionDate =@completionDate where PayID =@payID";

        SqlConnection con = new SqlConnection(connValue);
        SqlCommand cmd = new SqlCommand();
        
        cmd.CommandType = CommandType.Text;
        cmd.Connection = con;
        cmd.CommandText = updPayments;

        try
        {
            cmd.Parameters.AddWithValue("@payID", _payID);
            cmd.Parameters.AddWithValue("@jobStatusID", jobStatusID);

            if (issuedByEBSDDate != "")
                cmd.Parameters.AddWithValue("@issuedByEBSD2On", Convert.ToDateTime(issuedByEBSDDate).ToString("dd/MMM/yyyy"));
            else
                cmd.Parameters.AddWithValue("@issuedByEBSD2On", System.DBNull.Value);

            if (issuedByEBSDDate != "")
                cmd.Parameters.AddWithValue("@completionDate", Convert.ToDateTime(issuedByEBSDDate).ToString("dd/MMM/yyyy"));
            else
                cmd.Parameters.AddWithValue("@completionDate", System.DBNull.Value);

            //cmd.Parameters.AddWithValue("@updateDate", System.DBNull.Value);
            //cmd.Parameters.AddWithValue("@updateUser", System.DBNull.Value);
        }
        catch (Exception ex)
        {
            throw ex;
        }

        try
        {
            con.Open();
            cmd.ExecuteNonQuery();
            con.Dispose();
        }
        catch (Exception ex)
        {

            throw ex;
        }
        finally
        {
            con.Close();
        }
    }
    protected void ddlStatus_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    IList<string> lsttxtColl = new List<string>();
    IList<Boolean> lstChkBoxColl = new List<Boolean>();
    private int numOfRows = 0;
   
    protected void Button2_Click(object sender, EventArgs e)
    {
        fillCheckedData();
        getPaySummaryData();
        
    }
    IList<string> prjDataColl = new List<string>();
    private IList<string> getPaySummaryData()
    {

        string sqlQuery = " SELECT  Payment.commitmentNo, Payment.contractor, Payment.deptID, Payment.applicationNo, Payment.projectManager, Department.deptName " +
                      " FROM   Payment INNER JOIN  Department ON Payment.deptID = Department.departmentID WHERE  Payment.payID  = " + _payID + "";
        using (SqlConnection objCon = new SqlConnection(connValue))
        {
            try
            {
                objCon.Open();
                using (SqlCommand objCmd = new SqlCommand(sqlQuery, objCon))
                {
                    using (SqlDataReader dr = objCmd.ExecuteReader())
                    {
                        while (dr.Read())
                        {
                            prjDataColl.Add(dr["commitmentNo"].ToString());
                            prjDataColl.Add(dr["contractor"].ToString());
                            prjDataColl.Add(dr["deptName"].ToString());
                            prjDataColl.Add(dr["applicationNo"].ToString());
                            prjDataColl.Add(dr["projectManager"].ToString());
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        return prjDataColl;
    }
    protected void txtIssuedFin_TextChanged(object sender, EventArgs e)
    {       
        if (Session["contactID"].ToString().Equals(Session["userID"].ToString()))
        {
            if ((txtDateCertified.Text != "") & (txtIssuedFin.Text != ""))
            {               
                updateJobStatusPending(_payID, 1, txtIssuedFin.Text);     // Closed         
            }
            else if ((txtDateCertified.Text == "") & (txtIssuedFin.Text != ""))
            {
                updateJobStatusPending(_payID, 4, txtIssuedFin.Text);  // Pending
            }
            else
                updateJobStatusPending(_payID, 3, txtIssuedFin.Text);   //3 -OnGoing
        }        

        //txtIssuedFin.Text = Convert.ToDateTime(txtIssuedFin.Text).ToString("dd/MMM/yyyy");
    }   
    protected void txtDateCertified_TextChanged(object sender, EventArgs e)
    {
        // This function called for automatic update of PCM data in eBook - 15/may
        UpdatePayment(PassPaymentData(_updatePayData), "", _payID);

     //  if (!lblConactID.Text.Equals(Session["userID"]) & !Session["userProfileID"].ToString().Equals("1"))

        if (Session["contactID"].ToString().Equals(Session["userID"].ToString()))    // & userRightsColl.Contains("21")
        {
            if (txtDateCertified.Text != "")
                updateJobStatusDateCertified(_payID, 1, txtDateCertified.Text);   //1 -Closed
            else
                updateJobStatusDateCertified(_payID, 3, txtDateCertified.Text);   //3 -OnGoing
        }
        else if (!userRightsColl.Contains("21"))
        {
            if (txtDateCertified.Text != "")
                updateJobStatusDateCertified(_payID, 1, txtDateCertified.Text);   //1 -Closed
            else
                updateJobStatusDateCertified(_payID, 3, txtDateCertified.Text);   //3 -OnGoing
        } 

        fillPaymentData();

        //txtDateCertified.Text = Convert.ToDateTime(txtDateCertified.Text).ToString("dd/MMM/yyyy");
    }   
    protected void Button1_Click(object sender, EventArgs e)
    {
        if (ddlPayFor.SelectedIndex ==0)
        {
            // ClientScript.RegisterClientScriptBlock(this.GetType(), "Popup", "<script>alert('Please update payment for befor update checkList.')</script>", false);
            return;
        }
        string strUpdateJob = Request.Url.AbsoluteUri;
        Session["UrlRef"] = strUpdateJob;

         Session["ChkListPayID"] = _payID;

         Session["PayTypeChk"] = ddlPayType.SelectedValue;
         Session["PayForChk"] = ddlPayFor.SelectedValue;

        string url = "/eBook/CreateTable.aspx";
        string s = "window.open('" + url + "', 'popup_window', 'width=910,height=600,left=100,top=100,resizable=yes,scrollbars=yes');";
        ClientScript.RegisterStartupScript(this.GetType(), "script", s, true);    

    }
   
    private IList<string> fillData()
    {

        string sqlQuery = " SELECT CheckNo, CheckList  from payCheckListData where listTypID =2";

        using (SqlConnection objCon = new SqlConnection(connValue))
        {
            objCon.Open();
            SqlCommand objCmd = new SqlCommand(sqlQuery, objCon);
            using (SqlDataReader dr = objCmd.ExecuteReader())
            {
                while (dr.Read())
                {
                    lsttxtColl.Add(dr["CheckList"].ToString());
                }
            }
        }

        return lsttxtColl;
    }
    
    private IList<Boolean> fillCheckedData()
    {

        string sqlQuery = " SELECT check1, check2, check3, check4, check5, check6, check7, check8, check9, check10, check11, check12, check13, check14, check15, check16, check17, check18  from payCheckList where payID =" + _payID + "";

        using (SqlConnection objCon = new SqlConnection(connValue))
        {
            objCon.Open();
            SqlCommand objCmd = new SqlCommand(sqlQuery, objCon);
            using (SqlDataReader dr = objCmd.ExecuteReader())
            {
                while (dr.Read())
                {
                    lstChkBoxColl.Add(Convert.ToBoolean(dr["check1"].ToString()));
                    lstChkBoxColl.Add(Convert.ToBoolean(dr["check2"].ToString()));
                    lstChkBoxColl.Add(Convert.ToBoolean(dr["check3"].ToString()));
                    lstChkBoxColl.Add(Convert.ToBoolean(dr["check4"].ToString()));
                    lstChkBoxColl.Add(Convert.ToBoolean(dr["check5"].ToString()));
                    lstChkBoxColl.Add(Convert.ToBoolean(dr["check6"].ToString()));
                    lstChkBoxColl.Add(Convert.ToBoolean(dr["check7"].ToString()));
                    lstChkBoxColl.Add(Convert.ToBoolean(dr["check8"].ToString()));
                    lstChkBoxColl.Add(Convert.ToBoolean(dr["check9"].ToString()));
                    lstChkBoxColl.Add(Convert.ToBoolean(dr["check10"].ToString()));
                    lstChkBoxColl.Add(Convert.ToBoolean(dr["check11"].ToString()));
                    lstChkBoxColl.Add(Convert.ToBoolean(dr["check12"].ToString()));
                    lstChkBoxColl.Add(Convert.ToBoolean(dr["check13"].ToString()));
                    lstChkBoxColl.Add(Convert.ToBoolean(dr["check14"].ToString()));
                    lstChkBoxColl.Add(Convert.ToBoolean(dr["check15"].ToString()));
                    lstChkBoxColl.Add(Convert.ToBoolean(dr["check16"].ToString()));
                    lstChkBoxColl.Add(Convert.ToBoolean(dr["check17"].ToString()));
                    lstChkBoxColl.Add(Convert.ToBoolean(dr["check18"].ToString()));
                }
            }
        }

        return lstChkBoxColl;
    } 
    protected void chk_CheckedChanged(object sender, EventArgs e)
    {

        System.Web.UI.WebControls.CheckBox currentCheckbox = sender as System.Web.UI.WebControls.CheckBox;
        string clmName = currentCheckbox.ID;
        //updateWordData(clmName, currentCheckbox.Checked);
        string extractInteger = Regex.Match(currentCheckbox.ID, @"\d+").Value;
        //Label currentlabel = (Label)Labeldiv.FindControl("Label" + extractInteger);
    }

    protected void txtCntrAmt_TextChanged(object sender, EventArgs e)
    {
        txtCntrAmt.Text = Convert.ToDouble(txtCntrAmt.Text).ToString("#,###.##");

        double Amnt1 = 0; double Amnt2 = 0; double Amnt3 = 0;

        if (txtCntrAmt.Text == "")
            Amnt1 = 0;
        else
            Amnt1 = Convert.ToDouble(txtCntrAmt.Text);


        if (txtVariationDateAmt.Text == "")
            Amnt2 = 0;
        else
            Amnt2 = Convert.ToDouble(txtVariationDateAmt.Text);


        if (txtTotCertAmt.Text == "")
            Amnt3 = 0;
        else
            Amnt3 = Convert.ToDouble(txtTotCertAmt.Text);

         double totAmnt = (Amnt1 + Amnt2) - Amnt3;

        txtRemCost.Text = totAmnt.ToString("#,###.##");      
    }
    protected void txtTotCertAmt_TextChanged(object sender, EventArgs e)
    {
        txtTotCertAmt.Text = Convert.ToDouble(txtTotCertAmt.Text).ToString("#,###.##");


         
        double Amnt1 = 0; double Amnt2 = 0; double Amnt3 = 0;

        if (txtCntrAmt.Text == "")
            Amnt1 = 0;
        else
            Amnt1 = Convert.ToDouble(txtCntrAmt.Text);

        if (txtVariationDateAmt.Text == "")
            Amnt2 = 0;
        else
            Amnt2 = Convert.ToDouble(txtVariationDateAmt.Text);


        if (txtTotCertAmt.Text == "")
            Amnt3 = 0;
        else
            Amnt3 = Convert.ToDouble(txtTotCertAmt.Text);


        double totAmnt = (Amnt1 + Amnt2) - Amnt3;
        txtRemCost.Text = totAmnt.ToString("#,###.##");  
    }
    protected void txtVariationDate_TextChanged(object sender, EventArgs e)
    {
        txtVariationDateAmt.Text = Convert.ToDouble(txtVariationDateAmt.Text).ToString("#,###.##");

        double Amnt1 = 0; double Amnt2 = 0; double Amnt3 = 0;

        if (txtCntrAmt.Text == "")
            Amnt1 = 0;
        else
            Amnt1 = Convert.ToDouble(txtCntrAmt.Text);

        if (txtVariationDateAmt.Text == "")
            Amnt2 = 0;
        else
            Amnt2 = Convert.ToDouble(txtVariationDateAmt.Text);


        if (txtTotCertAmt.Text == "")
            Amnt3 = 0;
        else
            Amnt3 = Convert.ToDouble(txtTotCertAmt.Text);


        double totAmnt = (Amnt1 + Amnt2) - Amnt3;
        txtRemCost.Text = totAmnt.ToString("#,###.##");         
    }
    protected void btnUpdatePay_Click(object sender, EventArgs e)
    {
        if (Session["UserProfileID"].Equals("20"))
        {
            Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('You don't have access to update payment')</script>", false);
            return;
        }
        else
        {
            UpdatePayment(PassPaymentData(_updatePayData), "", _payID);
        }
    } 
    protected void btnSearch_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/Payments/SearchPayment.aspx",false);
    }   
    protected void btnOngoingPay_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/Payments/ViewPayments.aspx", false);
    }
    protected void lnkPrjSummary_Click(object sender, EventArgs e)
    {
        string strUpdateJob = Request.Url.AbsoluteUri;
        Session["CntrNo"] = txtCntrNo.Text;
        Session["PrevPage"] = strUpdateJob;
        Response.Redirect("~/Reports/rptProjectSummary.aspx",false);
    }
    protected void txtRetFin_TextChanged(object sender, EventArgs e)
    {

    }
    protected void txtRemCost_TextChanged(object sender, EventArgs e)
    {

    }
    protected void btnDelete_Click(object sender, EventArgs e)
    {
        if (Session["UserProfileID"].Equals("20"))
        {
            btnDelete.Enabled = false;
        }        
        else if (!userRightsColl.Contains("3"))  // delete job Order
        {
            DeletePay();            
        }
        else
        {
            btnDelete.Enabled = false;
        }
    }
    private void DeletePay()
    {
        string updPayments = "Delete From Payment Where PayID =@payID";

        // string updPayments = "Update Payment Set isPaymentActive =0 Where PayID =@payID";

        SqlConnection con = new SqlConnection(connValue);
        SqlCommand cmd = new SqlCommand();
        cmd.CommandType = CommandType.Text;
        cmd.Connection = con;
        cmd.CommandText = updPayments;

        cmd.Parameters.AddWithValue("@payID", _payID);

        try
        {
            con.Open();
            cmd.ExecuteNonQuery();
            con.Dispose();
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            con.Close();
        }
    }

    protected void btnUpdate_Click(object sender, EventArgs e)
    {
        if (ddlAlloc.SelectedValue == "")
        {
            Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Please select allocation year')</script>", false);            
            return;
        }

        //if (ddlAlloc.SelectedValue == "")
        //{

        //}

        using (SqlConnection cn = new SqlConnection(connValue))
        {
            cn.Open();

            using (SqlCommand cmd = new SqlCommand())
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Connection = cn;
                cmd.CommandText = "ProjectAllocationAmount";

                cmd.Parameters.AddWithValue("@contractNo", txtCntrNo.Text);

                if (ddlAlloc.SelectedValue == "")
                    cmd.Parameters.AddWithValue("@allocationYear", System.DBNull.Value);
                else
                    cmd.Parameters.AddWithValue("@allocationYear", ddlAlloc.SelectedValue);

                if (txtAmount.Text == "")
                    cmd.Parameters.AddWithValue("@allocationAmt", System.DBNull.Value);
                else
                    cmd.Parameters.AddWithValue("@allocationAmt", txtAmount.Text);

                cmd.ExecuteNonQuery();
            }

            cn.Close();
        }

        GetProjectAllocationDataGrid();
    }
    private void GetPCMProjectAllocationData()
    {
       // string sqlQuery = "Select allocation_this_year,Year(start_date) as StartYear from PCM_CNMT_TABLE where eBook_commitment_no = @contractNo";

        string sqlQuery = "Select allocationAmt, allocationYear as StartYear from PCM_CNMT_TABLE where eBook_commitment_no = @contractNo order by allocationYear";

        string committmentNo = string.Empty;     

        if (txtCntrNo.Text != "")
            committmentNo = "" + txtCntrNo.Text + "";

        committmentNo = committmentNo.Replace(" ", "").Replace("/", "").Replace("-", "");

        using (SqlConnection cn = new SqlConnection(connValue))
        {
            cn.Open();

            using (SqlCommand cmd = new SqlCommand())
            {
                cmd.CommandType = CommandType.Text;
                cmd.Connection = cn;
                cmd.CommandText = sqlQuery;

                cmd.Parameters.AddWithValue("@contractNo", committmentNo);
                SqlDataReader dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    txtPCMYear.Text = dr["allocationAmt"].ToString();

                    lblStartYear.Text = dr["StartYear"].ToString();           
                }
            }
        }
    }
    //private void GetProjectAllocationData()
    //{
    //    //string sqlQuery = "Select * from PaymentAllocation where contractNo = @contractNo";

    //    string sqlQuery = "Select allocationYear,allocationAmt from ProjectAllocation where commitmentNo = @contractNo";

    //    using (SqlConnection cn = new SqlConnection(connValue))
    //    {
    //        cn.Open();

    //        using (SqlCommand cmd = new SqlCommand())
    //        {
    //            cmd.CommandType = CommandType.Text;
    //            cmd.Connection = cn;
    //            cmd.CommandText = sqlQuery;

    //            cmd.Parameters.AddWithValue("@contractNo", txtCntrNo.Text);
    //            SqlDataReader dr = cmd.ExecuteReader();

    //            while (dr.Read())
    //            {
    //                if (dr["allocationYear"].ToString().Equals("2015"))
    //                    txtYear15.Text = dr["allocationAmt"].ToString();
    //                else if (dr["allocationYear"].ToString().Equals("2016"))
    //                    txtYear16.Text = dr["allocationAmt"].ToString();
    //                else if (dr["allocationYear"].ToString().Equals("2017"))
    //                    txtYear17.Text = dr["allocationAmt"].ToString();
    //                else if (dr["allocationYear"].ToString().Equals("2018"))
    //                    txtYear18.Text = dr["allocationAmt"].ToString();
    //                else if (dr["allocationYear"].ToString().Equals("2019"))
    //                    txtYear19.Text = dr["allocationAmt"].ToString();
    //                else if (dr["allocationYear"].ToString().Equals("2020"))
    //                    txtYear20.Text = dr["allocationAmt"].ToString();  
    //            }
    //        }
    //    }
    //}
    
   
    private void GetProjectAllocationDataGrid()
    {
        string sqlQuery = "Select Id,CommitmentNo,AllocationYear,AllocationAmt from ProjectAllocation Where commitmentNo = @contractNo order by AllocationYear desc";
        DataSet ds = new DataSet();
        using (SqlConnection cn = new SqlConnection(connValue))
        {
            cn.Open();

            using (SqlCommand cmd = new SqlCommand())
            {
                cmd.CommandType = CommandType.Text;
                cmd.Connection = cn;
                cmd.CommandText = sqlQuery;
                cmd.Parameters.AddWithValue("@contractNo", txtCntrNo.Text);

                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(ds);

                gridPrjAllocation.DataSource = ds.Tables[0];
                gridPrjAllocation.DataBind();
            }
        }
    }

    private void GetProjectCompletionPercentage(string _cNo)
    {
       // string strColl = _cNo.Split('');

        string strCno_1 = string.Empty; string strCno_2 = string.Empty; string strCno_Result = string.Empty; 

        string[] cnoSplit = _cNo.Split('/');

        foreach (char item in cnoSplit[0])
	    {
            if (item.ToString() != " ")
            {
                strCno_1 += item.ToString();
            }
	    }

        int _index = 0;
        string strCno_1_res = string.Empty;
        foreach (char item in strCno_1)
        {
            _index = _index + 1;

            if ((_index !=2) & (_index !=3))
            {
                strCno_1_res += item.ToString();
            }
        }

        foreach (char item in cnoSplit[1])
        {
            strCno_2 += item.ToString();
        }

        
        string strCno_2_res = string.Empty;
        strCno_2_res = strCno_2;  
        strCno_Result = strCno_1_res + strCno_2_res;

        string sqlQuery = "SELECT M.project_name, M.application_no, M.total_stored FROM PCM_RQMT_TABLE AS M RIGHT OUTER JOIN (SELECT project_name, MAX(application_no) AS app_no " +
                              " FROM  PCM_RQMT_TABLE GROUP BY project_name) AS D ON M.project_name = D.project_name AND D.app_no = M.application_no WHERE  (M.project_name = '" + strCno_Result + "') ORDER BY D.project_name";


        using (SqlConnection cn = new SqlConnection(connValue))
        {
            cn.Open();

            using (SqlCommand cmd = new SqlCommand())
            {
                cmd.CommandType = CommandType.Text;
                cmd.Connection = cn;
                cmd.CommandText = sqlQuery;

               // cmd.Parameters.AddWithValue("@contractNo", txtCntrNo.Text);
                SqlDataReader dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                   // txtPrjCompletion.Text = dr["total_stored"].ToString();                  
                }
            }
        }
    }

    protected void gvJoborder_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void gridPrjAllocation_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandArgument != "")
        {
            int allocID = Convert.ToInt32(e.CommandArgument);       
      
            switch (e.CommandName)
            {
                case "RecDeleteAllocId":

                    DeleteAllocation(allocID);
                    ClientScript.RegisterStartupScript(this.GetType(), "alert", "alert('You don't have the permission to delete.');", true);
                                       
                    break;
            }
        }
    }

    public void DeleteAllocation(int _allocID)
    {
        string upDateQuery = "DELETE FROM ProjectAllocation WHERE id = @allocID";

        SqlConnection sqlCon = new SqlConnection(connValue);
        SqlCommand cmd = new SqlCommand();
        cmd.CommandText = upDateQuery;
        cmd.Connection = sqlCon;

        cmd.Parameters.AddWithValue("@allocID", _allocID);

        try
        {
            sqlCon.Open();
            cmd.ExecuteNonQuery();
            sqlCon.Close();
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
}