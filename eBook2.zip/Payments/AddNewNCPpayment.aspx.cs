﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Datalayer;
using System.Data.SqlClient;
using System.Data;
using System.IO;
using Datalayer;
using PropertyLayer;
using System.Globalization;
using System.Configuration;

public partial class Payments_AddNewNCPpayment : System.Web.UI.Page
{
    private SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["EBSDEBookConn"].ConnectionString);

    string connValueTCMS = System.Configuration.ConfigurationManager.ConnectionStrings["TCMSConn"].ConnectionString;
    IList<string> userRightsColl = null;
    protected void Page_Load(object sender, EventArgs e)
    {
        //upd_UserID = Convert.ToInt32(Request.QueryString["ContactID"]);
        if (!IsPostBack)
        {
            FillDropBox();
            txtWorkDays.Text = "4";
            txtDueDate.Text = Convert.ToDateTime(getEndDateByGivenDays(4, System.DateTime.Now.ToString())).ToString("dd/MMM/yyyy");

            txtPopupDatepicker.Text = Convert.ToDateTime((System.DateTime.Now.ToString())).ToString("dd/MMM/yyyy");
            txtDateReceived.Text = Convert.ToDateTime((System.DateTime.Now.ToString())).ToString("dd/MMM/yyyy");

            //gvDetails.Visible = false;
            //fileUpload1.Visible = false;
            //btnUpload0.Visible = false;
            trFile.Visible = false;
            trImgBtn.Visible = false;

            trUpload.Visible = false;
            trgrid.Visible = false;

            //if (HttpContext.Current.Session["PrjCP/NCP"].ToString().Equals("NCP"))
            //{
            lblNewPayment.Text = "Non Capital Projects New Payment Request ";
            //    txtCp1.Value = "NCP";
            //    txtCp2.Text = "NCP";
            //}
            //else
            //{
            //    lblNewPayment.Text = "Capital Projects New Payment Request ";
            //    txtCp1.Value = "CP";
            //}

            btnContinue.Enabled = false;
        }
    }
    private string GenarateAutomate_JobNo()
    {
       string strYear = System.DateTime.Now.Year.ToString().Substring(2, 2);

        string _jobNo = string.Empty;
        int _maxjobNo = 0;
        string tempJobNo = string.Empty;

        //   _jobNo = new JobOrderData().getMaxJobNoSeriesOfPayment();

        _jobNo = new JobOrderData().getMaxPayJobNo(strYear + "%");

        if (_jobNo != "")
        {
            tempJobNo = _jobNo.Substring(_jobNo.Length - 4, 4);
            _maxjobNo = Convert.ToInt32(tempJobNo) + 1;

            // _maxjobNo = Convert.ToInt32(_jobNo) + 1;

            if (_maxjobNo.ToString().Length == 1)
                tempJobNo = "000" + _maxjobNo;

            if (_maxjobNo.ToString().Length == 2)
                tempJobNo = "00" + _maxjobNo;

            if (_maxjobNo.ToString().Length == 3)
                tempJobNo = "0" + _maxjobNo;

            if (_maxjobNo.ToString().Length == 4)
                tempJobNo = _maxjobNo.ToString();

            _jobNo = tempJobNo;
        }
        else
        {
            _jobNo = "0001";

            // txtJobNo.Text = "PR150001";


        }

        return _jobNo;
    }
    private string MaxPayNo()
    {
        string strPayNo = string.Empty;
        using (SqlConnection cn = new SqlConnection(connValue))
        {
            cn.Open();
            using (SqlCommand sqlCom = new SqlCommand())
            {

                sqlCom.CommandType = CommandType.Text;
                sqlCom.Connection = cn;
                sqlCom.CommandText = "Select max(JobNo)+1 as PayNo From payment";

                using (SqlDataReader sqlReader = sqlCom.ExecuteReader())
                {
                    while (sqlReader.Read())
                    {
                        strPayNo = sqlReader[0].ToString();
                    }
                }
            }
        }
        return strPayNo;
    }
    private void FillDropBox()
    {
        PopulateDropDownBox(ddlDept, "SELECT departmentID, deptName FROM  Department where affairID is not null and isActive = 1 ORDER BY deptName ", "departmentID", "deptName");
       // PopulateDropDownBox(ddlDept, "SELECT departmentID, deptName FROM  Department where affairID is not null and isActive =1 ORDER BY deptName ", "departmentID", "deptName");

        //if (Session["PrjType"].ToString().Equals("CP"))
        //    LoadPCM_CommitmentData();
        //else
        //    PopulateDropDownBox_TCMS(ddlCommitNo, "SELECT bidder_ID,Contract_No FROM CONTRACTORS WHERE (Contract_No IS NOT NULL) and (Contract_No != '')  ORDER BY Contract_No", "bidder_ID", "Contract_No");


        LoadSubjects();



        PopulateDropDownBox(ddlPaymentFor, "SELECT paymentForID, paymentForDesc FROM  PaymentFor  ORDER BY paymentForDesc ", "paymentForID", "paymentForDesc");
        PopulateDropDownBox(ddlOriginSender, "SELECT contactID, (firstName + ' ' + lastName) as OriginSender FROM  Contact ORDER BY OriginSender ", "contactID", "OriginSender");
    }
    //private void LoadPCM_CommitmentData()
    //{

    //    DataTable subjects = new DataTable();

    //    using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["EBSDEBookPCMConn"].ConnectionString))
    //    {

    //        try
    //        {
    //            SqlDataAdapter adapter = new SqlDataAdapter("SELECT Distinct commitment_no, commitment_no FROM  CNMT_TABLE Where commitment_no is not null  ORDER BY commitment_no", con);
    //            adapter.Fill(subjects);

    //            ddlCommitNo.DataSource = subjects;
    //            ddlCommitNo.DataTextField = "commitment_no";
    //            ddlCommitNo.DataValueField = "commitment_no";
    //            ddlCommitNo.DataBind();
    //        }
    //        catch (Exception ex)
    //        {
    //            // Handle the error
    //        }

    //    }

    //    // Add the initial item - you can add this even if the options from the
    //    // db were not successfully loaded
    //    ddlCommitNo.Items.Insert(0, new ListItem("", "0"));  //<Select Subject>

    //}
    private void LoadSubjects()
    {

        DataTable subjects = new DataTable();

        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["EBSDEBookConn"].ConnectionString))
        {

            try
            {
                SqlDataAdapter adapter = new SqlDataAdapter("SELECT payTypeID, payTypeName FROM  paymentType  ORDER BY payTypeName", con);
                adapter.Fill(subjects);

                ddlPayType.DataSource = subjects;
                ddlPayType.DataTextField = "payTypeName";
                ddlPayType.DataValueField = "payTypeID";
                ddlPayType.DataBind();
            }
            catch (Exception ex)
            {
                // Handle the error
            }

        }

        // Add the initial item - you can add this even if the options from the
        // db were not successfully loaded
        ddlPayType.Items.Insert(0, new ListItem("", "0"));      // <Select Subject>

    }
    private void LoadSubjectsPayFor()
    {

        DataTable subjects = new DataTable();

        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["EBSDEBookConn"].ConnectionString))
        {

            try
            {
                SqlDataAdapter adapter = new SqlDataAdapter("SELECT paymentForID, paymentForDesc FROM  PaymentFor  ORDER BY paymentForDesc", con);
                adapter.Fill(subjects);

                ddlPaymentFor.DataSource = subjects;
                ddlPaymentFor.DataTextField = "paymentForDesc";
                ddlPaymentFor.DataValueField = "paymentForID";
                ddlPaymentFor.DataBind();


            }
            catch (Exception ex)
            {
                // Handle the error
            }

        }

        // Add the initial item - you can add this even if the options from the
        // db were not successfully loaded
        ddlPaymentFor.Items.Insert(0, new ListItem("", "0"));       // <Select Subject>

    }
    private void PopulateDropDownBox(DropDownList ddlBox, string sqlQuery, string valueMember, string displayName)
    {
        ddlBox.DataBound += new EventHandler(this.ddlBox_DataBound);
        ddlBox.DataSource = new JobOrderData().FillDropdown(sqlQuery);
        ddlBox.DataTextField = displayName;
        ddlBox.DataValueField = valueMember;
        ddlBox.SelectedIndex = -1;
        ddlBox.DataBind();
    }
    protected void ddlBox_DataBound(object sender, EventArgs e)
    {
        DropDownList ddl = (DropDownList)sender;
        ListItem emptyItem = new ListItem("", "");
        ddl.Items.Insert(0, emptyItem);
    }
    private void PopulateDropDownBox_TCMS(DropDownList ddlBox, string sqlQuery, string valueMember, string displayName)
    {
        ddlBox.DataBound += new EventHandler(this.ddlBox_DataBound);
        ddlBox.DataSource = new JobOrderData().FillDropdown_TCMS(sqlQuery);
        ddlBox.DataTextField = displayName;
        ddlBox.DataValueField = valueMember;
        ddlBox.SelectedIndex = -1;
        ddlBox.DataBind();
    }

    private string getEndDateByGivenDays(int _days, string strDate)
    {

        SqlCommand cmd = new SqlCommand();
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Connection = con;

        cmd.CommandText = "AddWorkdays";
        SqlParameter prm = cmd.Parameters.Add("@ad_startDate", SqlDbType.DateTime);
        prm.Value = strDate;
        prm = cmd.Parameters.Add("@actual_workDays", SqlDbType.Int);
        prm.Value = Convert.ToInt32(_days);
        prm = cmd.Parameters.Add("@endDate", SqlDbType.DateTime);
        prm.Direction = ParameterDirection.Output;
        con.Open();
        SqlDataReader dr = cmd.ExecuteReader();
        while (dr.Read())
            Console.WriteLine(dr.GetString(0));
        con.Dispose();
        con.Close();

        return cmd.Parameters[2].Value.ToString();
    }

    private string checkJobNoconfimed()
    {
        string strJobNo = string.Empty;
        SqlConnection con = new SqlConnection(connValue);
        using (con)
        {
            con.Open();
            using (SqlCommand sqlCom = new SqlCommand())
            {
                sqlCom.CommandType = CommandType.Text;

                sqlCom.Connection = con;
                //sqlCom.CommandText = "sp_CheckJobNoConfirm";

                sqlCom.CommandText = "SELECT  tempID, CategoryID, sectionID, JobNo, sessionUser, confirmed FROM  TempJobNo WHERE (CategoryID =2) and  (sectionID = 2) AND (sessionUser IS NULL) AND (confirmed = 0)";

                using (SqlDataReader sqlReader = sqlCom.ExecuteReader())
                {
                    while (sqlReader.Read())
                    {
                        strJobNo = sqlReader["JobNo"].ToString();
                    }
                }
            }
        }

        return strJobNo;
    }
    private string CheckCurrentUserSessioExist(string userName)
    {
        string jobNo = string.Empty;

        try
        {
            using (SqlConnection con = new SqlConnection(connValue))
            {
                con.Open();
                using (SqlCommand sqlCom = new SqlCommand())
                {
                    sqlCom.CommandType = CommandType.Text;
                    sqlCom.Connection = con;
                    // sqlCom.CommandText = "sp_CheckCurrentUserSessioExist";

                    sqlCom.CommandText = "SELECT  tempID, CategoryID, sectionID, JobNo, sessionUser, confirmed FROM  TempJobNo WHERE (seriesTypeID =2) AND (sessionUser = '" + userName + "') AND (confirmed = 1)";
                    using (SqlDataReader sqlReader = sqlCom.ExecuteReader())
                    {
                        while (sqlReader.Read())
                        {
                            jobNo = sqlReader["JobNo"].ToString();
                        }
                    }
                }
            }
        }
        catch (Exception ex)
        {

        }
        finally
        {
            con.Close();
        }
        return jobNo;
    }
    private string getMaxPayJobNo()
    {
        string str = " SELECT Max(JobNo) as JobNo  FROM   TempJobNo WHERE (seriesTypeID = 2)  AND (confirmed = 1)  and (JobNo like 'PR15%')";   //AND (sessionUser IS NULL)
        string strJobNo = string.Empty;
        SqlConnection con = new SqlConnection(connValue);
        using (con)
        {
            con.Open();
            using (SqlCommand sqlCom = new SqlCommand())
            {
                // sqlCom.CommandType = CommandType.StoredProcedure;
                sqlCom.CommandType = CommandType.Text;
                sqlCom.Connection = con;
                sqlCom.CommandText = str;

                using (SqlDataReader sqlReader = sqlCom.ExecuteReader())
                {
                    while (sqlReader.Read())
                    {
                        strJobNo = sqlReader["JobNo"].ToString();
                    }
                }
            }
        }

        return strJobNo;
    }
    private void InsertTemJobNo()
    {
        string str = " INSERT INTO TempJobNo(CategoryID, sectionID, JobNo, sessionUser, confirmed,seriesTypeID) VALUES(2,2,'" + txtJobNo.Text + "','" + Session["UserName"] + "',1,2)";

        SqlConnection cn = new SqlConnection(connValue);
        SqlCommand sqlCmd = new SqlCommand();
        sqlCmd.CommandType = CommandType.Text;
        sqlCmd.CommandText = str;
        sqlCmd.Connection = cn;

        // sqlCmd.Parameters.AddWithValue("@docDate", Convert.ToDateTime(txtPopupDatepicker.Text).ToString("dd/MMM/yyyy"));

        try
        {
            cn.Open();
            sqlCmd.ExecuteNonQuery();
        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
        finally
        {
            cn.Close();
        }
    }
    private void UpdateSessionUser()
    {
        string strUpdate = "Update TempJobNo Set sessionUser = '" + Session["UserName"] + "',confirmed = 1  WHERE (seriesTypeID = 2) AND (sessionUser IS NULL) AND (confirmed = 0)";

        SqlConnection cn = new SqlConnection(connValue);
        SqlCommand sqlCmd = new SqlCommand();
        sqlCmd.CommandType = CommandType.Text;
        sqlCmd.CommandText = strUpdate;
        sqlCmd.Connection = cn;

        // sqlCmd.Parameters.AddWithValue("@docDate", Convert.ToDateTime(txtPopupDatepicker.Text).ToString("dd/MMM/yyyy"));

        try
        {
            cn.Open();
            sqlCmd.ExecuteNonQuery();
        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
        finally
        {
            cn.Close();
        }
    }
    private void deleteTempJobNO()
    {
        // string strUpdate = "Delete from TempJobNo WHERE(CategoryID = 2) AND (sectionID = 2) AND (confirmed = 1) AND (sessionUser IS NULL) ";

        string strUpdate = "Delete from TempJobNo WHERE(seriesTypeID= 2) AND (confirmed = 1) AND (sessionUser IS NULL)  AND (DateCreated < CONVERT(VARCHAR(11), GETDATE(), 106))";

        SqlConnection cn = new SqlConnection(connValue);
        SqlCommand sqlCmd = new SqlCommand();
        sqlCmd.CommandType = CommandType.Text;
        sqlCmd.CommandText = strUpdate;
        sqlCmd.Connection = cn;

        // sqlCmd.Parameters.AddWithValue("@docDate", Convert.ToDateTime(txtPopupDatepicker.Text).ToString("dd/MMM/yyyy"));

        try
        {
            cn.Open();
            sqlCmd.ExecuteNonQuery();
        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
        finally
        {
            cn.Close();
        }
    }
    private void UpdateSessionUserNull()
    {
        string strUpdate = "Update TempJobNo Set sessionUser = @sessionUser  WHERE (seriesTypeID = 2) AND (confirmed = 1) AND (sessionUser ='" + Session["UserName"].ToString() + "')";

        SqlConnection cn = new SqlConnection(connValue);
        SqlCommand sqlCmd = new SqlCommand();
        sqlCmd.CommandType = CommandType.Text;
        sqlCmd.CommandText = strUpdate;
        sqlCmd.Connection = cn;

        sqlCmd.Parameters.AddWithValue("@sessionUser", System.DBNull.Value);

        try
        {
            cn.Open();
            sqlCmd.ExecuteNonQuery();
        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
        finally
        {
            cn.Close();
        }
    }
    List<string> contractColl = new List<string>();
    protected void ddlCommitNo_SelectedIndexChanged(object sender, EventArgs e)
    {
        lblmsg.Text = "";

        string userSessionJobNo = string.Empty;

        // SELECT  tempID, CategoryID, sectionID, JobNo, sessionUser, confirmed FROM  TempJobNo WHERE (CategoryID =2) and  (sectionID = 2) AND (sessionUser = @userName) AND (confirmed = 1)
        userSessionJobNo = CheckCurrentUserSessioExist(Session["UserName"].ToString());

        if (userSessionJobNo != "")
        {
            // Same user come back So Same Job No.
            txtJobNo.Text = userSessionJobNo;
        }
        else
        {
            if (checkJobNoconfimed() == "")
            {
                txtJobNo.Text = "PR15" + GenarateAutomate_JobNo();
                InsertTemJobNo();
            }
            else
            {
                txtJobNo.Text = checkJobNoconfimed();
                UpdateSessionUser();
            }
        }


        if (Session["PrjType"].ToString().Equals("CP"))
        {
            getPCMCommitmentData();
            getPCMData();
        }
        else
        {
            string companyNameID = string.Empty;
            if (txtSearch.Text != "")
            {
                contractColl = new JobOrderData().getVendorData(Convert.ToInt32(txtSearch.Text));
                Session["sessprjColl"] = contractColl;
                txtPrjTitle.Text = contractColl[0];
                txtCntr.Text = contractColl[5];
            }

            // --------------------------------------------------------------------------------------------------------------------------------------------------


            if (new JobOrderData().getMaxPaymentRequestNo(txtSearch.Text) == "")
            {
                txtApplicationNo.Text = "00000";

                // --------------------------------------------------------------------------------------------------------------------------------------------------

                if (txtApplicationNo.Text.Equals("00000"))
                {
                    if (ddlPayType.SelectedIndex == 0)
                        ddlPayType.SelectedValue = "1";       // first Payment                 

                }
            }
            else
            {
                txtApplicationNo.Text = new JobOrderData().getMaxPaymentRequestNo(txtSearch.Text);
                if (ddlPayType.SelectedIndex == 0)
                    ddlPayType.SelectedValue = "2";
            }

            int iCnt = (Convert.ToInt32(txtApplicationNo.Text) + 1);

            if (iCnt.ToString().Length == 1)
                txtApplicationNo.Text = "0000" + iCnt;
            else if (iCnt.ToString().Length == 2)
                txtApplicationNo.Text = "000" + iCnt;
            else if (iCnt.ToString().Length == 3)
                txtApplicationNo.Text = "00" + iCnt;
            else if (iCnt.ToString().Length == 4)
                txtApplicationNo.Text = "0" + iCnt;



            // --------------------------------------------------------------------------------------------------------------------------------------------------

            if (new JobOrderData().getAssignedPM(txtSearch.Text) == "")
                txtPM.Text = "Unknown";
            else
                txtPM.Text = new JobOrderData().getAssignedPM(txtSearch.Text);

            // --------------------------------------------------------------------------------------------------------------------------------------------------

            // contractColl[7].ToString(); 

            ddlDept.SelectedValue = geteBookDept(Convert.ToInt32(contractColl[7].ToString())).ToString();

            // ddlDept.SelectedIndex = 1;      //contractColl[7]; 

            if (new JobOrderData().getPaymentFor(txtSearch.Text).ToString() != "0")
                ddlPaymentFor.SelectedValue = new JobOrderData().getPaymentFor(txtSearch.Text).ToString();  //ddlCommitNo.SelectedItem.Text
            else
                ddlPaymentFor.SelectedIndex = -1;
        }
    }
    private void getPCMData()
    {
       // string sqlQuery = "SELECT TOP (1) contract_number, project_name, amount_certified, application_no, certified, certified_by, certified_date, prev_amount_cert, total_sched_valu, is_certified,  Payment_Type FROM      RQMT_TABLE WHERE   (contract_number = '" + txtSearch.Text + "') ORDER BY application_no DESC";


        string sqlQuery = "SELECT TOP (1) contract_number, project_name, amount_certified, application_no, certified, certified_by, certified_date, prev_amount_cert, total_sched_valu, is_certified,  Payment_Type FROM PCM_RQMT_TABLE WHERE   (contract_number = '" + txtSearch.Text + "') ORDER BY application_no DESC";
        using (SqlConnection objCon = new SqlConnection(connValue))
        {
            objCon.Open();
            SqlCommand objCmd = new SqlCommand(sqlQuery, objCon);
            using (SqlDataReader dr = objCmd.ExecuteReader())
            {
                while (dr.Read())
                {
                    //txtPCMCertAmt.Text = dr["amount_certified"].ToString();
                    //txtPcmPrvTotalAmt.Text = dr["total_sched_valu"].ToString();

                    // txtApplicationNo.Text = txtApplicationNo.Text + 1;

                    if (dr["application_no"].ToString().Length == 1)
                        txtApplicationNo.Text = "0000" + dr["application_no"].ToString();
                    else if (dr["application_no"].ToString().Length == 2)
                        txtApplicationNo.Text = "000" + dr["application_no"].ToString();
                    else if (dr["application_no"].ToString().Length == 3)
                        txtApplicationNo.Text = "00" + dr["application_no"].ToString();
                    else if (dr["application_no"].ToString().Length == 4)
                        txtApplicationNo.Text = "0" + dr["application_no"].ToString();



                    //if (!dr["is_certified"].Equals("1"))   



                    if (dr["Payment_Type"].ToString() != "")
                    {

                        string str = dr["Payment_Type"].ToString();
                        string payTypeID = ddlPayType.Items.FindByText(str).Value;



                        ddlPayType.SelectedValue = payTypeID;
                    }
                    else
                        ddlPayType.SelectedIndex = 1;


                }
            }
        }
    }
   
    static IList<string> CNMTColl = new List<string>();
    private IList<string> getPCMCommitmentData()
    {
        // string sqlQuery = "SELECT commitment_no,to_company, description, provision_no, completion_date, revisd_cmpl_date,project_manager,project_number,start_date FROM  CNMT_TABLE  WHERE (commitment_no = '" + ddlCommitNo.SelectedValue + "')";

        CNMTColl.Clear();

        string sqlQuery = "SELECT  TOP (1) PCM_PROJ.project_name, PCM_RQMT_TABLE.Payment_Type, PCM_RQMT_TABLE.is_certified, PCM_CNMT_TABLE.description, " +
                      " PCM_CNMT_TABLE.commitment_no, PCM_RQMT_TABLE.application_no, PCM_CNMT_TABLE.provision_no, PCM_PROJ.project_manager, " +
                       "  PCM_PROJ.project_number, PCM_PROJ.project_title, PCM_RQMT_TABLE.is_certified AS Expr1, PCM_RQMT_TABLE.prev_amount_cert, PCM_PROJ.budget_code, " + 
                        " PCM_CNMT_TABLE.to_company, PCM_CNMT_TABLE.start_date, PCM_CNMT_TABLE.revisd_cmpl_date, PCM_CNMT_TABLE.completion_date, " +
                         " PCM_CNMT_TABLE.unit_cost, PCM_PROJ.minis_dept_cd_nm, PCM_RQMT_TABLE.prev_amt_cert_c, PCM_RQMT_TABLE.p_retention, " +
                         " PCM_RQMT_TABLE.tot_ret_released, PCM_RQMT_TABLE.penalty_todate, PCM_RQMT_TABLE.Advance_payment, PCM_RQMT_TABLE.AP_Recovery, " +  
                         " PCM_RQMT_TABLE.period_to, PCM_RQMT_TABLE.prev_amt_cert_c AS Expr2, PCM_RQMT_TABLE.amount_certified " +
                          " FROM PCM_CNMT_TABLE INNER JOIN PCM_PROJ ON PCM_CNMT_TABLE.ID = PCM_PROJ.ID INNER JOIN PCM_RQMT_TABLE ON PCM_CNMT_TABLE.ID = PCM_RQMT_TABLE.ID WHERE (PCM_CNMT_TABLE.commitment_no = @commitmentNo) Order By RQMT_TABLE.application_no Desc";
        
        


        using (SqlConnection objCon = new SqlConnection(connValue))
        {
            objCon.Open();
            SqlCommand objCmd = new SqlCommand();

            ////objCmd.CommandType = CommandType.StoredProcedure;
            //objCmd.CommandText = "pay_GetPcmDataByContractNo";

            objCmd.CommandType = CommandType.Text;
            objCmd.CommandText = sqlQuery;
            objCmd.Connection = objCon;

            objCmd.Parameters.AddWithValue("@commitmentNo", txtSearch.Text);

            using (SqlDataReader dr = objCmd.ExecuteReader())
            {
                while (dr.Read())
                {
                    txtPrjTitle.Text = dr["description"].ToString();
                    txtCntr.Text = dr["to_company"].ToString();
                    txtPM.Text = dr["project_manager"].ToString();


                    if (dr["application_no"].ToString() == "")
                        txtApplicationNo.Text = "00001";
                    else
                    {
                        int iCnt = (Convert.ToInt32(dr["application_no"]) + 1);

                        if (iCnt.ToString().Length == 1)
                            txtApplicationNo.Text = "0000" + iCnt;
                        else if (iCnt.ToString().Length == 2)
                            txtApplicationNo.Text = "000" + iCnt;
                        else if (iCnt.ToString().Length == 3)
                            txtApplicationNo.Text = "00" + iCnt;
                        else if (iCnt.ToString().Length == 4)
                            txtApplicationNo.Text = "0" + iCnt;

                        if (dr["is_certified"].ToString().Equals("1"))
                        {

                        }
                        else
                        {
                            if (!txtApplicationNo.Text.Equals("00001"))
                                lblmsg.Text = "Previous payment request not yet certified.";
                        }

                    }

                    if (txtApplicationNo.Text == "00001")
                        ddlPayType.SelectedValue = "1";           // for advance payment
                    else
                        ddlPayType.SelectedValue = "2";    //interim


                    if (dr["payment_certification_for"].ToString() != "")
                    {

                        string str = dr["payment_certification_for"].ToString();
                        string payFor = ddlPaymentFor.Items.FindByText(str).Value;

                        //if (ddlPaymentFor != null)
                        //{
                        //    ddlPaymentFor.ClearSelection();
                        //    ddlPaymentFor.Items.FindByValue(dr["payment_certification_for"].ToString()).Selected = true;

                        //   // ddlPaymentFor.Items.FindByText(dr["payment_certification_for"].ToString().Trim()).Selected = true;
                        //}

                        ddlPaymentFor.SelectedValue = payFor;
                    }
                    else
                        ddlPaymentFor.SelectedIndex = 1;

                    CNMTColl.Add(dr["provision_no"].ToString());    // --------0
                    CNMTColl.Add(dr["budget_code"].ToString());
                    CNMTColl.Add(dr["minis_dept_cd_nm"].ToString());

                    CNMTColl.Add(dr["project_number"].ToString());
                    CNMTColl.Add(dr["start_date"].ToString());

                    CNMTColl.Add(dr["unit_cost"].ToString());              //--------------------------------5 
                    CNMTColl.Add(dr["amount_certified"].ToString());
                    CNMTColl.Add(dr["prev_amt_cert_c"].ToString());

                    CNMTColl.Add(dr["revisd_cmpl_date"].ToString());
                    CNMTColl.Add(dr["completion_date"].ToString());

                    CNMTColl.Add(dr["application_no"].ToString());        //------------------------- 10

                    CNMTColl.Add(dr["approved_changes"].ToString());

                    CNMTColl.Add(dr["rev_budget"].ToString());

                }
            }
        }

        return CNMTColl;
    }
    private int geteBookDept(int tcmsDept)
    {
        int eBookDept = 0;
        string sqlQuery = "SELECT departmentID From Department where tcmsDeptID = " + tcmsDept + "";
        //string sqlQuery = "SELECT d2.departmentID,d2.deptName,d1.deptName From " +
        //" Department d1 INNER JOIN Department d2 On d2.departmentID = d1.newDeptID where d1.tcmsDeptID = " + tcmsDept + "";
        try
        {
            con.Open();
            SqlCommand sqlCom = new SqlCommand(sqlQuery, con);
            SqlDataReader sqlReader = sqlCom.ExecuteReader();
            while (sqlReader.Read())
            {
                eBookDept = Convert.ToInt32(sqlReader["departmentID"]);
            }
            sqlReader.Close();
        }
        catch (Exception ex)
        {
            // Response.Write("Error getting while reading data !" + ex.Message);
        }
        finally
        {
            con.Close();
        }
        return eBookDept;
    }
    protected void btnUpload_Click(object sender, EventArgs e)
    {
        string prefixfileName = string.Empty;
        string filename = Path.GetFileName(fileUpload1.PostedFile.FileName);
        prefixfileName = Session["Dist_docID"] + "_" + filename;

        string folderName = ConfigurationManager.AppSettings["PayfolderName"].ToString();
        string filePath = Path.Combine(folderName, prefixfileName);

       // string filePath = Path.Combine(@"C:\eBookPaymentFiles", prefixfileName);

        if (fileUpload1.HasFile)
        {
            // filePath = Path.Combine(@"C:\eBookFiles", fileUpload1.FileName);
            fileUpload1.SaveAs(filePath);
            con.Open();
            SqlCommand cmd = new SqlCommand("Insert Into FilesTable(fileName,docfileName,filePath,docID,fileType,sectionID,createUser,createDate,uploadByID) values(@Name,@docfileName,@Path,@docID,@fileType,@sectionID,@createUser,@createDate,@uploadByID)", con);
            cmd.Parameters.AddWithValue("@Name", filename);
            cmd.Parameters.AddWithValue("@docfileName", prefixfileName);
            cmd.Parameters.AddWithValue("@Path", filePath);
            cmd.Parameters.AddWithValue("@docID", Convert.ToInt32(Session["Dist_docID"]));
            cmd.Parameters.AddWithValue("@fileType", Session["fileType"].ToString());
            cmd.Parameters.AddWithValue("@sectionID", Session["SectionID"]);
            cmd.Parameters.AddWithValue("@createUser", Session["Username"].ToString());

           // cmd.Parameters.AddWithValue("@createDate", System.DateTime.Now.ToString("dd/MMM/yyyy"));

            cmd.Parameters.AddWithValue("@createDate", System.DateTime.Now);
            cmd.Parameters.AddWithValue("@uploadByID", Convert.ToInt32(Session["UserID"]));
            cmd.ExecuteNonQuery();
            con.Close();

            BindGridviewData();

            btnContinue.Text = "Save";
        }
        else
        {
            //Response.Write("Please browse to upload the file ");
        }
        CheckAttachments(Convert.ToInt32(Session["Dist_docID"]));

    }
    private void CheckAttachments(int chkdocID)
    {
        int fileCnt = 0;
        fileCnt = coverLetterExist(chkdocID);
        if (fileCnt == 0)
            ImageButton1.Visible = false;
        else
        {
            ImageButton1.Visible = true;
            lblCover.Text = "( " + fileCnt + " )";
        }

        int attCnt = 0;
        attCnt = fileAttachmentsExist(chkdocID);
        if (attCnt == 0)
            ImageButton2.Visible = false;
        else
        {
            ImageButton2.Visible = true;
            lblAttch.Text = "( " + attCnt + " )";
        }
    }
    private int coverLetterExist(int filedocID)
    {
        int fileCnt = 0;
        using (SqlConnection con = new SqlConnection(connValue))
        {
            con.Open();
            using (SqlCommand sqlCom = new SqlCommand())
            {
                // sqlCom.CommandType = CommandType.StoredProcedure;
                sqlCom.CommandType = CommandType.Text;
                sqlCom.Connection = con;
                string sqlfileType = "select  count(fileID)  from FilesTable where isFileActive = 1 and  fileType ='F' and docID = " + filedocID + "";
                sqlCom.CommandText = sqlfileType;

                using (SqlDataReader sqlReader = sqlCom.ExecuteReader())
                {
                    while (sqlReader.Read())
                    {
                        fileCnt = Convert.ToInt32(sqlReader[0].ToString());
                    }
                }
            }
        }
        return fileCnt;
    }
    private int fileAttachmentsExist(int filedocID)
    {
        int fileCnt = 0;
        using (SqlConnection con = new SqlConnection(connValue))
        {
            con.Open();
            using (SqlCommand sqlCom = new SqlCommand())
            {
                // sqlCom.CommandType = CommandType.StoredProcedure;
                sqlCom.CommandType = CommandType.Text;
                sqlCom.Connection = con;
                string sqlfileType = "select  count(fileID) from FilesTable where isFileActive = 1 and  fileType ='A' and docID = " + filedocID + " ";
                sqlCom.CommandText = sqlfileType;

                using (SqlDataReader sqlReader = sqlCom.ExecuteReader())
                {
                    while (sqlReader.Read())
                    {
                        fileCnt = Convert.ToInt32(sqlReader[0].ToString());
                    }
                }
            }
        }
        return fileCnt;
    }
    private void BindGridviewData()
    {
        con.Open();
        string sqlfileType = string.Empty;
        if (Session["fileType"].Equals("F"))
            sqlfileType = "select  fileID, FileName, FilePath, docID from FilesTable where fileType ='F' and docID = " + Convert.ToInt32(Session["Dist_docID"]);
        else
            sqlfileType = "select  fileID, FileName, FilePath, docID from FilesTable where fileType ='A' and docID = " + Convert.ToInt32(Session["Dist_docID"]);

        SqlCommand cmd = new SqlCommand(sqlfileType, con);
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        DataSet ds = new DataSet();
        da.Fill(ds);
        con.Close();
        gvDetails.DataSource = ds;
        gvDetails.DataBind();
    }
    private void addDocument()
    {
        int jobdocID = 0;
        // jobdocID = InsertJobDocumentData();
    }
    private int InsertJobDocumentDataForPayment(int payID)
    {
        int _cmpID = getCompanyID(Convert.ToInt32(ddlOriginSender.SelectedValue));


        SqlConnection cn = new SqlConnection(connValue);
        SqlCommand sqlCmd = new SqlCommand();
        sqlCmd.CommandType = CommandType.StoredProcedure;
        sqlCmd.CommandText = "sp_InsertDocument";
        sqlCmd.Connection = cn;

        sqlCmd.Parameters.AddWithValue("@docDate", Convert.ToDateTime(txtPopupDatepicker.Text).ToString("dd/MMM/yyyy"));

        //sqlCmd.Parameters.AddWithValue("@docDate", DateTime.ParseExact(txtPopupDatepicker.Text, "dd/MMM/yyyy", CultureInfo.InvariantCulture));
        sqlCmd.Parameters.AddWithValue("@docTypeID", 1); // Job Order
        sqlCmd.Parameters.AddWithValue("@originID", ddlOriginSender.SelectedValue);
        sqlCmd.Parameters.AddWithValue("@originCoID", _cmpID);
        sqlCmd.Parameters.AddWithValue("@referenceNo", txtDocRefNo.Text);
        sqlCmd.Parameters.AddWithValue("@docReceivedDate", Convert.ToDateTime(txtDateReceived.Text).ToString("dd/MMM/yyyy"));


        // sqlCmd.Parameters.AddWithValue("@docReceivedDate", DateTime.ParseExact(txtDateReceived.Text, "dd/MMM/yyyy", CultureInfo.InvariantCulture));
        sqlCmd.Parameters.AddWithValue("@crossReferenceNo", System.DBNull.Value);

        sqlCmd.Parameters.AddWithValue("@docSubject", txtDocSubject.Text);
        sqlCmd.Parameters.AddWithValue("@docContent", System.DBNull.Value);

        sqlCmd.Parameters.AddWithValue("@docCatID", 1); // Receive 
        sqlCmd.Parameters.AddWithValue("@docCreatedByID", Session["UserID"].ToString());

        sqlCmd.Parameters.AddWithValue("@createUser", Session["UserName"].ToString());


        sqlCmd.Parameters.AddWithValue("@docID", SqlDbType.SmallInt).Direction = ParameterDirection.Output;
        //string actionDueDate = getEndDateByGivenDays(txtDateReceived.Text, 1);
        sqlCmd.Parameters.AddWithValue("@actionDueDate", System.DBNull.Value);
        sqlCmd.Parameters.AddWithValue("@isImportance", 0);
        sqlCmd.Parameters.AddWithValue("@isSuperseded", 0);

        sqlCmd.Parameters.AddWithValue("@jobID", System.DBNull.Value);
        sqlCmd.Parameters.AddWithValue("@payID", payID);


        //Session["originContactID"] = ddlOriginSender.SelectedValue;
        //Session["docCreatedByID"] = Session["UserID"].ToString();


        try
        {
            cn.Open();
            sqlCmd.ExecuteNonQuery();

            //Response.Write("Document Added SuccessFully!");

            Label1.Text = "Document Added";
        }
        catch (Exception ex)
        {
            // throw ex;

            Response.Write(ex.Message);
        }
        finally
        {
            cn.Close();
        }

        return (int)sqlCmd.Parameters["@docID"].Value;
    }

    private int getCompanyID(int contactID)
    {
        int CmpID = 0;

        string sqlQuery = "SELECT companyID From Contact where contactID = " + contactID + "";

        try
        {
            con.Open();
            SqlCommand sqlCom = new SqlCommand(sqlQuery, con);
            SqlDataReader sqlReader = sqlCom.ExecuteReader();
            while (sqlReader.Read())
            {
                CmpID = Convert.ToInt32(sqlReader["companyID"]);
            }
            sqlReader.Close();
        }
        catch (Exception ex)
        {
            // Response.Write("Error getting while reading data !" + ex.Message);
        }
        finally
        {
            con.Close();
        }
        return CmpID;
    }
    protected void lnkUploadFile_Click(object sender, EventArgs e)
    {
        //if (lblJobDocID.Text == "")
        //    addDocument();

        Session["fileType"] = "";
        if (lblJobDocID.Text == "")
        {
            // addDocument();
            trUpload.Visible = true;
            trgrid.Visible = true;
        }
        else
        {
            trUpload.Visible = true;
            trgrid.Visible = true;
        }

        Session["fileType"] = "F"; // File
        BindGridviewData();
    }
    protected void lnkAttach_Click(object sender, EventArgs e)
    {
        Session["fileType"] = "";
        if (lblJobDocID.Text == "")
        {
            // addDocument();
            trUpload.Visible = true;
            trgrid.Visible = true;
        }
        else
        {
            trUpload.Visible = true;
            trgrid.Visible = true;
        }

        Session["fileType"] = "A";    // Attachments
        BindGridviewData();
    }
    protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
    {
        Session["fileType"] = "";
        if (lblJobDocID.Text == "")
        {
            // addDocument();
            trUpload.Visible = true;
            trgrid.Visible = true;
        }
        else
        {
            trUpload.Visible = true;
            trgrid.Visible = true;
        }

        Session["fileType"] = "F"; // File

        BindGridviewData();
    }
    protected void ImageButton2_Click(object sender, ImageClickEventArgs e)
    {
        Session["fileType"] = "";
        if (lblJobDocID.Text == "")
        {
            // addDocument();
            trUpload.Visible = true;
            trgrid.Visible = true;

        }
        else
        {

            trUpload.Visible = true;
            trgrid.Visible = true;
        }
        Session["fileType"] = "A"; // File
        BindGridviewData();
    }

    JobOrderProperty _insertPayData = new JobOrderProperty();
    protected void btnSaveJobDoc_Click(object sender, EventArgs e)
    {
        if (CheckFileExist())
        {
            Session["Dist_docID"] = null;
            Response.Redirect("~/Payments/PaymentDetails.aspx", false);
        }
        else
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "Popup", "<script>alert('Please attach the file.')</script>", false);
        }
    }
    private Boolean CheckFileExist()
    {
        con.Open();
        string sqlfileType = string.Empty;

        sqlfileType = "select  fileID, FileName, FilePath, docID from FilesTable where docID = " + Convert.ToInt32(Session["Dist_docID"]);

        SqlCommand cmd = new SqlCommand(sqlfileType, con);
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        DataSet ds = new DataSet();
        da.Fill(ds);
        con.Close();

        if (ds.Tables[0].Rows.Count > 0)
            return true;
        else
            return false;
    }
    public JobOrderProperty insertPassPaymentData(JobOrderProperty _updatePayData, int paydocID)
    {
        //CNMTColl.Add(dr["provision_no"].ToString());         CNMTColl.Add(dr["budget_code"].ToString());        CNMTColl.Add(dr["minis_dept_cd_nm"].ToString());
        //CNMTColl.Add(dr["project_number"].ToString());        CNMTColl.Add(dr["start_date"].ToString());        CNMTColl.Add(dr["unit_cost"].ToString());
        //CNMTColl.Add(dr["prev_amount_cert"].ToString());        CNMTColl.Add(dr["prev_amt_cert_c"].ToString());


        _updatePayData.applicationNo = txtApplicationNo.Text;


        if (CNMTColl.Count != 0)
        {
            _updatePayData.provisionNumber = CNMTColl[0].ToString();

            _updatePayData.budgetRefNo = CNMTColl[1].ToString();

            // _updatePayData = CNMTColl[2].ToString();
            _updatePayData.projectCode = CNMTColl[3].ToString();

            _updatePayData.prjStartDate = CNMTColl[4].ToString();

            _updatePayData.contractAmt = Convert.ToDouble(CNMTColl[5]);

            if ((CNMTColl[6].ToString() != null))
            {
                if ((CNMTColl[6].ToString() != ""))
                    _updatePayData.prevCertifiedAmt = Convert.ToDouble(CNMTColl[6]);
                else
                    _updatePayData.prevCertifiedAmt = 0;

            }
            else
                _updatePayData.prevCertifiedAmt = 0;

            if ((CNMTColl[7].ToString() != null))
            {
                if ((CNMTColl[7].ToString() != ""))
                    _updatePayData.prevTotalCertifiedAmt = Convert.ToDouble(CNMTColl[7]);
                else
                    _updatePayData.prevTotalCertifiedAmt = 0;
            }
            else
                _updatePayData.prevTotalCertifiedAmt = 0;

            _updatePayData.prevTotalCertifiedAmt = _updatePayData.prevCertifiedAmt + _updatePayData.prevTotalCertifiedAmt;

            _updatePayData.approvedchangesAmt = Convert.ToDouble(CNMTColl[11]);

            _updatePayData.prevRPno = CNMTColl[10].ToString();
        }
        else
        {
            _updatePayData.budgetRefNo = "";
            _updatePayData.contractAmt = 0;
            _updatePayData.prevCertifiedAmt = 0;
            _updatePayData.prjStartDate = "";
            _updatePayData.projectCode = "";
            _updatePayData.provisionNumber = "";
            _updatePayData.prevTotalCertifiedAmt = 0;

            _updatePayData.approvedchangesAmt = 0;

            _updatePayData.prevRPno = "";

            //  _updatePayData.retentionAmt rev_budget,

            //  _updatePayData.rev = 0;
        }


        _updatePayData.commitmentNo = txtSearch.Text;

        _updatePayData.contractorName = txtCntr.Text;
        _updatePayData.createDate = System.DateTime.Now.ToString("dd/MMM/YYYY");
        _updatePayData.createUser = Session["UserName"].ToString();
        _updatePayData.daysToAct = 4;

        if (ddlDept.SelectedIndex != 0)
            _updatePayData.deptID = Convert.ToInt32(ddlDept.SelectedValue);
        else
            _updatePayData.deptID = 1;


        _updatePayData.docRefID = paydocID;
        _updatePayData.jobDueDate = txtDueDate.Text;
        _updatePayData.jobNo = txtJobNo.Text;
        _updatePayData.jobStatusID = 3;       // ongoing
        _updatePayData.jobTypeID = 2;          //Payment

        _updatePayData.paymentForId = Convert.ToInt32(ddlPaymentFor.SelectedItem.Value);
        _updatePayData.payTypeID = Convert.ToInt32(ddlPayType.SelectedValue);



        _updatePayData.projectManager = txtPM.Text;
        _updatePayData.projectTitle = txtPrjTitle.Text.Trim();

        _updatePayData.qsID = Convert.ToInt32(Session["UserID"].ToString());
        _updatePayData.receivedByEBSD1On = txtDateReceived.Text;

        if (txtReqAmnt.Text != "")
            _updatePayData.requestedAmt = Convert.ToDouble(txtReqAmnt.Text);
        else
            _updatePayData.requestedAmt = 0;


        return _updatePayData;

    }
    string connValue = System.Configuration.ConfigurationManager.ConnectionStrings["EBSDEBookConn"].ConnectionString;
    public int InsertJobOrderPay(JobOrderProperty _insertPayData, string userName, int _outDocID)
    {
        SqlConnection con = new SqlConnection(connValue);
        SqlCommand cmd = new SqlCommand();
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Connection = con;
        cmd.CommandText = "sp_CreatePay";

        if (_insertPayData.applicationNo.Length == 1)
        {
            _insertPayData.applicationNo = "0000" + _insertPayData.applicationNo;
        }
        else if (_insertPayData.applicationNo.Length == 2)
        {
            _insertPayData.applicationNo = "000" + _insertPayData.applicationNo;
        }
        else if (_insertPayData.applicationNo.Length == 3)
        {
            _insertPayData.applicationNo = "00" + _insertPayData.applicationNo;
        }
        else if (_insertPayData.applicationNo.Length == 4)
        {
            _insertPayData.applicationNo = "0" + _insertPayData.applicationNo;
        }

        cmd.Parameters.AddWithValue("@applicationNo", _insertPayData.applicationNo);

        if (_insertPayData.approvedchangesAmt != 0)
            cmd.Parameters.AddWithValue("@approvedchangesAmt", _insertPayData.approvedchangesAmt);
        else
            cmd.Parameters.AddWithValue("@approvedchangesAmt", System.DBNull.Value);

        cmd.Parameters.AddWithValue("@budgetRefNo", _insertPayData.budgetRefNo);
        cmd.Parameters.AddWithValue("@commitmentNo", _insertPayData.commitmentNo.ToUpper());

        if (_insertPayData.contractAmt != 0)
            cmd.Parameters.AddWithValue("@contractAmt", _insertPayData.contractAmt);
        else
            cmd.Parameters.AddWithValue("@contractAmt", System.DBNull.Value);


        cmd.Parameters.AddWithValue("@contractor", _insertPayData.contractorName);       // chk

        cmd.Parameters.AddWithValue("@createDate", Convert.ToDateTime(System.DateTime.Now.ToString()).ToString("dd/MMM/yyyy"));
        cmd.Parameters.AddWithValue("@createUser", _insertPayData.createUser);
        cmd.Parameters.AddWithValue("@daysToAct", _insertPayData.daysToAct);
        cmd.Parameters.AddWithValue("@deptID", _insertPayData.deptID);
        cmd.Parameters.AddWithValue("@docRefID", SqlDbType.SmallInt).Direction = ParameterDirection.Output;


        cmd.Parameters.AddWithValue("@jobDueDate", Convert.ToDateTime(_insertPayData.jobDueDate).ToString("dd/MMM/yyyy"));

        cmd.Parameters.AddWithValue("@jobNo", _insertPayData.jobNo);
        cmd.Parameters.AddWithValue("@jobStatusID", _insertPayData.jobStatusID);
        cmd.Parameters.AddWithValue("@jobTypeID", _insertPayData.jobTypeID);
        cmd.Parameters.AddWithValue("@paymentForId", _insertPayData.paymentForId);
        cmd.Parameters.AddWithValue("@payTypeID", _insertPayData.payTypeID);

        if (_insertPayData.prevCertifiedAmt != 0)
            cmd.Parameters.AddWithValue("@prevCertifiedAmt", _insertPayData.prevCertifiedAmt);
        else
            cmd.Parameters.AddWithValue("@prevCertifiedAmt", System.DBNull.Value);

        cmd.Parameters.AddWithValue("@prevRPno", _insertPayData.prevRPno);

        if (_insertPayData.prevCertifiedAmt != 0)
            cmd.Parameters.AddWithValue("@prevTotalCertifiedAmt", _insertPayData.prevCertifiedAmt);
        else
            cmd.Parameters.AddWithValue("@prevTotalCertifiedAmt", System.DBNull.Value);

        if (_insertPayData.prjStartDate != "")
            cmd.Parameters.AddWithValue("@prjStartDate", Convert.ToDateTime(_insertPayData.prjStartDate).ToString("dd/MMM/yyyy")); // _insertPayData.prjStartDate     ------------------------------------------------------//---------------------------------------------------------------------2
        else
            cmd.Parameters.AddWithValue("@prjStartDate", System.DBNull.Value);

        cmd.Parameters.AddWithValue("@projectCode", _insertPayData.projectCode);
        cmd.Parameters.AddWithValue("@projectManager", _insertPayData.projectManager);
        cmd.Parameters.AddWithValue("@projectTitle", _insertPayData.projectTitle);
        cmd.Parameters.AddWithValue("@provisionNumber", _insertPayData.provisionNumber);
        cmd.Parameters.AddWithValue("@qsID", _insertPayData.qsID);

        cmd.Parameters.AddWithValue("@receivedByEBSD1On", _insertPayData.receivedByEBSD1On);       //   _insertPayData.receivedByEBSD1On

        if (_insertPayData.requestedAmt != 0)
            cmd.Parameters.AddWithValue("@requestedAmt", _insertPayData.requestedAmt);
        else
            cmd.Parameters.AddWithValue("@requestedAmt", System.DBNull.Value);

        cmd.Parameters.AddWithValue("@payID", SqlDbType.SmallInt).Direction = ParameterDirection.Output;


        // ------------------------------------------------------------------------------------------------------------------------------------------------

        cmd.Parameters.AddWithValue("@originCoID", 1); // Temp

        cmd.Parameters.AddWithValue("@referenceNo", txtDocRefNo.Text);
        cmd.Parameters.AddWithValue("@crossReferenceNo", System.DBNull.Value);


        cmd.Parameters.AddWithValue("@docSubject", txtDocSubject.Text);
        cmd.Parameters.AddWithValue("@docContent", System.DBNull.Value);

        cmd.Parameters.AddWithValue("@docCatID", 1); // Receive 

        cmd.Parameters.AddWithValue("@actionDueDate", System.DBNull.Value);
        cmd.Parameters.AddWithValue("@isImportance", 0);
        cmd.Parameters.AddWithValue("@isSuperseded", 0);

        cmd.Parameters.AddWithValue("@originID", ddlOriginSender.SelectedValue);
        cmd.Parameters.AddWithValue("@docCreatedByID", Session["UserID"].ToString());


        cmd.Parameters.AddWithValue("@docReceivedDate", Convert.ToDateTime(txtDateReceived.Text).ToString("dd/MMM/yyyy"));

        cmd.Parameters.AddWithValue("@docDate", Convert.ToDateTime(txtPopupDatepicker.Text).ToString("dd/MMM/yyyy"));

        cmd.Parameters.AddWithValue("@rev_budget", System.DBNull.Value);         //--------------------------------------------------------------------- 3 

        cmd.Parameters.AddWithValue("@minis_dept_cd_nm", System.DBNull.Value);     //---------------------------------------------------------------------4 

        cmd.Parameters.AddWithValue("@projectType", "NCP");
        try
        {
            con.Open();
            cmd.ExecuteNonQuery();
            con.Dispose();
        }
        catch (Exception ex)
        {

            throw ex;
        }
        finally
        {
            con.Close();
        }

        Session["Dist_docID"] = Convert.ToInt32(cmd.Parameters["@docRefID"].Value.ToString());

        lblJobDocID.Text = Session["Dist_docID"].ToString();

        return Convert.ToInt32(cmd.Parameters["@payID"].Value.ToString());

    }


    public int InsertCapitalProjectsForPay(JobOrderProperty _insertPayData, string userName, int _outDocID)
    {
        SqlConnection con = new SqlConnection(connValue);
        SqlCommand cmd = new SqlCommand();
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Connection = con;
        cmd.CommandText = "CreatePay";



        cmd.Parameters.AddWithValue("@applicationNo", _insertPayData.applicationNo);

        if (_insertPayData.approvedchangesAmt.ToString() != "0")
            cmd.Parameters.AddWithValue("@approvedchangesAmt", _insertPayData.approvedchangesAmt);            //---------------------------------------------------------------------1
        else
            cmd.Parameters.AddWithValue("@approvedchangesAmt", System.DBNull.Value);

        cmd.Parameters.AddWithValue("@budgetRefNo", _insertPayData.budgetRefNo);
        cmd.Parameters.AddWithValue("@commitmentNo", _insertPayData.commitmentNo);

        if (_insertPayData.contractAmt.ToString() != "0")
            cmd.Parameters.AddWithValue("@contractAmt", _insertPayData.contractAmt);
        else
            cmd.Parameters.AddWithValue("@contractAmt", System.DBNull.Value);


        cmd.Parameters.AddWithValue("@contractor", _insertPayData.contractorName);       // chk

        cmd.Parameters.AddWithValue("@createDate", Convert.ToDateTime(System.DateTime.Now.ToString()).ToString("dd/MMM/yyyy"));
        cmd.Parameters.AddWithValue("@createUser", _insertPayData.createUser);
        cmd.Parameters.AddWithValue("@daysToAct", _insertPayData.daysToAct);
        cmd.Parameters.AddWithValue("@deptID", _insertPayData.deptID);

        cmd.Parameters.AddWithValue("@docRefID", SqlDbType.SmallInt).Direction = ParameterDirection.Output;


        // cmd.Parameters.AddWithValue("@docRefID", _outDocID);


        cmd.Parameters.AddWithValue("@jobDueDate", Convert.ToDateTime(_insertPayData.jobDueDate).ToString("dd/MMM/yyyy"));

        cmd.Parameters.AddWithValue("@jobNo", _insertPayData.jobNo);
        cmd.Parameters.AddWithValue("@jobStatusID", _insertPayData.jobStatusID);
        cmd.Parameters.AddWithValue("@jobTypeID", _insertPayData.jobTypeID);

        if (_insertPayData.applicationNo.Equals("00001"))
            cmd.Parameters.AddWithValue("@paymentForId", 1);     // 
        else
            cmd.Parameters.AddWithValue("@paymentForId", _insertPayData.paymentForId);

        if (_insertPayData.payTypeID != 0)
            cmd.Parameters.AddWithValue("@payTypeID", _insertPayData.payTypeID);
        else
            cmd.Parameters.AddWithValue("@payTypeID", 2);          // Temp  Delete and Chk condition

        if (_insertPayData.prevCertifiedAmt.ToString() != "0")
            cmd.Parameters.AddWithValue("@prevCertifiedAmt", _insertPayData.prevCertifiedAmt);
        else
            cmd.Parameters.AddWithValue("@prevCertifiedAmt", System.DBNull.Value);

        cmd.Parameters.AddWithValue("@prevRPno", _insertPayData.prevRPno);

        if (_insertPayData.prevTotalCertifiedAmt.ToString() != "0")
            cmd.Parameters.AddWithValue("@prevTotalCertifiedAmt", _insertPayData.prevTotalCertifiedAmt);
        else
            cmd.Parameters.AddWithValue("@prevTotalCertifiedAmt", System.DBNull.Value);

        if (_insertPayData.prjStartDate != "")
            cmd.Parameters.AddWithValue("@prjStartDate", Convert.ToDateTime(_insertPayData.prjStartDate).ToString("dd/MMM/yyyy")); // _insertPayData.prjStartDate     ------------------------------------------------------//---------------------------------------------------------------------2
        else
            cmd.Parameters.AddWithValue("@prjStartDate", System.DBNull.Value);

        cmd.Parameters.AddWithValue("@projectCode", _insertPayData.projectCode);
        cmd.Parameters.AddWithValue("@projectManager", _insertPayData.projectManager);
        cmd.Parameters.AddWithValue("@projectTitle", _insertPayData.projectTitle);
        cmd.Parameters.AddWithValue("@provisionNumber", _insertPayData.provisionNumber);
        cmd.Parameters.AddWithValue("@qsID", _insertPayData.qsID);

        cmd.Parameters.AddWithValue("@receivedByEBSD1On", _insertPayData.receivedByEBSD1On);       //   _insertPayData.receivedByEBSD1On

        if (_insertPayData.requestedAmt.ToString() != "0")
            cmd.Parameters.AddWithValue("@requestedAmt", _insertPayData.requestedAmt);
        else
            cmd.Parameters.AddWithValue("@requestedAmt", System.DBNull.Value);

        cmd.Parameters.AddWithValue("@payID", SqlDbType.SmallInt).Direction = ParameterDirection.Output;


        // ------------------------------------------------------------------------------------------------------------------------------------------------

        cmd.Parameters.AddWithValue("@originCoID", 1); // Temp

        cmd.Parameters.AddWithValue("@referenceNo", txtDocRefNo.Text);
        cmd.Parameters.AddWithValue("@crossReferenceNo", System.DBNull.Value);


        cmd.Parameters.AddWithValue("@docSubject", txtDocSubject.Text);
        cmd.Parameters.AddWithValue("@docContent", System.DBNull.Value);

        cmd.Parameters.AddWithValue("@docCatID", 1); // Receive 

        cmd.Parameters.AddWithValue("@actionDueDate", System.DBNull.Value);
        cmd.Parameters.AddWithValue("@isImportance", 0);
        cmd.Parameters.AddWithValue("@isSuperseded", 0);

        cmd.Parameters.AddWithValue("@originID", ddlOriginSender.SelectedValue);
        cmd.Parameters.AddWithValue("@docCreatedByID", Session["UserID"].ToString());


        cmd.Parameters.AddWithValue("@docReceivedDate", Convert.ToDateTime(txtDateReceived.Text).ToString("dd/MMM/yyyy"));

        cmd.Parameters.AddWithValue("@docDate", Convert.ToDateTime(txtPopupDatepicker.Text).ToString("dd/MMM/yyyy"));


        cmd.Parameters.AddWithValue("@rev_budget", CNMTColl[12].ToString());           //--------------------------------------------------------------------- 3 

        cmd.Parameters.AddWithValue("@minis_dept_cd_nm", CNMTColl[3].ToString());     //---------------------------------------------------------------------4 


        try
        {
            con.Open();
            cmd.ExecuteNonQuery();
            con.Dispose();
        }
        catch (Exception ex)
        {

            throw ex;
        }
        finally
        {
            con.Close();
        }

        Session["Dist_docID"] = Convert.ToInt32(cmd.Parameters["@docRefID"].Value.ToString());

        lblJobDocID.Text = Session["Dist_docID"].ToString();

        return Convert.ToInt32(cmd.Parameters["@payID"].Value.ToString());

    }
    protected void btnCancelDoc_Click1(object sender, EventArgs e)
    {

    }

    protected void ddlOriginSender_SelectedIndexChanged(object sender, EventArgs e)
    {

    }

    protected void lnkDelete_Click(object sender, EventArgs e)
    {
        try
        {
            LinkButton lnkbtn = sender as LinkButton;
            GridViewRow gvrow = lnkbtn.NamingContainer as GridViewRow;
            string fileID = gvDetails.DataKeys[gvrow.RowIndex].Values[1].ToString();

            if (!userRightsColl.Contains("26"))
            {
                if (checkUserExist(Convert.ToInt32(fileID), 1, Convert.ToInt32(Session["UserID"])))
                {

                    con.Open();
                    SqlCommand cmd = new SqlCommand("Update FilesTable Set isFileActive = 0 where fileID =" + fileID, con);
                    cmd.ExecuteNonQuery();
                    con.Close();

                    BindGridviewData();
                }

                else
                {
                    Response.Write("You don't have rights to delete this file..");
                    //ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('You don't have rights to delete this file..')</script>", false);
                }
            }
            else
            {
                Response.Write("Please contact Administrator,You don't have rights to delete this file..'");
                //ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Please contact Administrator,You don't have rights to delete this file..')</script>", false);
            }
        }
        catch (Exception ex)
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Error occurred while processing the request')</script>", false);
        }
    }
    private Boolean checkUserExist(int fileID, int createdBy, int currentUserID)
    {
        using (con)
        {
            con.Open();
            using (SqlCommand sqlCom = new SqlCommand())
            {
                // sqlCom.CommandType = CommandType.StoredProcedure;
                sqlCom.CommandType = CommandType.Text;
                sqlCom.Connection = con;
                sqlCom.CommandText = "Select uploadByID From FilesTable where fileID = " + fileID;

                using (SqlDataReader sqlReader = sqlCom.ExecuteReader())
                {
                    while (sqlReader.Read())
                    {
                        if ((sqlReader["uploadByID"].Equals(currentUserID)) || (Session["userProfileID"].Equals("1")))
                            return true;
                    }
                }
            }
        }
        return false;
    }
    protected void txtDocRefNo_TextChanged(object sender, EventArgs e)
    {
        if (checkDocExist())
        {
            //this.Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('This document reference No was already loaded in the system')</script>", false);

            lblRefNo.Text = "Reference No Exist";
            txtDocRefNo.BackColor = System.Drawing.Color.Red;
            txtDocRefNo.Text = "";
            txtDocRefNo.Focus();
            return;
        }
        else
        {
            lblRefNo.Text = "Document Reference No.";
            txtDocRefNo.BackColor = System.Drawing.Color.White;
        }
    }
    private Boolean checkDocExist()
    {
        string prjTitle = string.Empty;

        using (SqlConnection cnn = new SqlConnection(connValue))
        {
            cnn.Open();
            using (SqlCommand cmm = new SqlCommand())
            {
                cmm.Connection = cnn;
                cmm.CommandText = "SELECT referenceNo  FROM Document WHERE referenceNo = '" + txtDocRefNo.Text.Trim() + "' ";
                using (SqlDataReader sqlDtReader = cmm.ExecuteReader())
                {
                    if (sqlDtReader.HasRows)
                    {
                        return true;
                    }
                }
            }
        }
        return false;
    }
    protected void txtDateReceived_TextChanged(object sender, EventArgs e)
    {
        if (txtDateReceived.Text != "")
        {
            string endDate = getEndDateByGivenDays(4, txtDateReceived.Text);
            txtDueDate.Text = Convert.ToDateTime(endDate).ToString("dd/MMM/yyyy");
        }
    }
    private string getDaysByGivenEndDate(string strDate, DateTime endDate)
    {
        strDate = Convert.ToDateTime(strDate).ToString("MM/dd/yyyy", CultureInfo.InvariantCulture);
        //endDate = Convert.ToDateTime(endDate).ToString("MM/dd/yyyy", CultureInfo.InvariantCulture);

        //DateTime dt = DateTime.ParseExact(endDate, "d/M/yyyy", null);
        //endDate = dt.ToString("dd/MM/yyyy");

        DateTime strDt = DateTime.ParseExact(strDate, "MM/dd/yyyy", CultureInfo.InvariantCulture);
        //DateTime endDt = DateTime.ParseExact(endDate, "MM/dd/yyyy", CultureInfo.InvariantCulture);

        SqlConnection con = new SqlConnection(connValue);
        SqlCommand cmd = new SqlCommand();

        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Connection = con;

        cmd.CommandText = "testSP";

        SqlParameter prm = cmd.Parameters.Add("@ad_startDate", SqlDbType.DateTime);
        prm.Value = strDt;

        prm = cmd.Parameters.Add("@ad_endDate", SqlDbType.DateTime);
        prm.Value = endDate;

        prm = cmd.Parameters.Add("@ai_workDays", SqlDbType.Int);
        prm.Direction = ParameterDirection.Output;

        //prm = cmd.Parameters.Add("@as_errMsg", SqlDbType.VarChar);
        //prm.Direction = ParameterDirection.Output;

        con.Open();
        SqlDataReader dr = cmd.ExecuteReader();
        while (dr.Read())
            Console.WriteLine(dr.GetString(0));
        con.Dispose();
        con.Close();

        return cmd.Parameters[2].Value.ToString();
    }
    protected void btnCancelDoc_Click(object sender, EventArgs e)
    {
       // string strUpdate = "Delete from TempJobNo WHERE  (sessionUser = '" + Session["UserName"].ToString() + "') ";

        string strUpdate = "Update TempJobNo Set confirmed =0, sessionUser =@sessionUser WHERE  (sessionUser = '" + Session["UserName"].ToString() + "') ";

        SqlConnection cn = new SqlConnection(connValue);
        SqlCommand sqlCmd = new SqlCommand();
        sqlCmd.CommandType = CommandType.Text;
        sqlCmd.CommandText = strUpdate;
        sqlCmd.Connection = cn;

        sqlCmd.Parameters.AddWithValue("@sessionUser", System.DBNull.Value);

        try
        {
            cn.Open();
            sqlCmd.ExecuteNonQuery();
        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
        finally
        {
            cn.Close();
        }

        Response.Redirect("~/JobOrder/DefaultWindow.aspx");
    }
    protected void btnContinue_Click(object sender, EventArgs e)
    {
        // int payD = InsertJobOrderPay(insertPassPaymentData(_insertPayData, 0), "", 0);

        int payID = 0;

        if (btnContinue.ToolTip != "")
        {
            //if (Session["PrjCP/NCP"].ToString().Equals("NCP"))
            //    payID = InsertJobOrderPay(insertPassPaymentData(_insertPayData, 0), "", 0);
            //else
            //    payID = InsertCapitalProjectsForPay(insertPassPaymentData(_insertPayData, 0), "", 0);

            payID = InsertJobOrderPay(insertPassPaymentData(_insertPayData, 0), "", 0);

            int seriesID = 2;
            new JobOrderData().deleteTempJobNO(seriesID);
            new JobOrderData().UpdateSessionUserNull(Session["UserName"].ToString(), seriesID, payID);

            // InsertJobDocumentDataForPayment(payD);

            lblPayID.Text = payID.ToString();
            Session["AddPayID"] = payID;

            //gvDetails.Visible = true;
            //fileUpload1.Visible = true;
            //btnUpload0.Visible = true;

            trFile.Visible = true;
            trImgBtn.Visible = true;

            lnkUploadFile.Visible = true;
            lnkAttach.Visible = true;

            ImageButton1.Visible = true;
            ImageButton2.Visible = true;

            // btnSaveJobDoc.Enabled = true;


            Session["PrjType"] = null;

            btnContinue.Text = " Attach File ";
            btnContinue.ToolTip = "";

            btnCancelDoc.Visible = false;
        }
        else
        {
            if (CheckFileExist())
            {
                Session["Dist_docID"] = null;
                Response.Redirect("~/Payments/PaymentDetails.aspx?payIDNew=" + lblPayID.Text, false);
            }
            else
            {
                ClientScript.RegisterClientScriptBlock(this.GetType(), "Popup", "<script>alert('Please attach the file.')</script>", false);
            }

            // btnContinue.Enabled = false;
        }
    }
    protected void txtReqAmnt_TextChanged(object sender, EventArgs e)
    {
        // string s = Convert.ToInt32(txtReqAmnt.Text).ToString("N2");


        txtReqAmnt.Text = Convert.ToDouble(txtReqAmnt.Text).ToString("#,###.##");
    }
    protected void btnCntrNo_Click(object sender, EventArgs e)
    {

    }
    protected void txtAuto_TextChanged(object sender, EventArgs e)
    {

    }
    private void genaratePaymentNo()
    {
        // lblmsg.Text = "";

        string userSessionJobNo = string.Empty;

        // SELECT  tempID, CategoryID, sectionID, JobNo, sessionUser, confirmed FROM  TempJobNo WHERE (CategoryID =2) and  (sectionID = 2) AND (sessionUser = @userName) AND (confirmed = 1)
        userSessionJobNo = new JobOrderData().CheckCurrentUserSessioExist(Session["UserName"].ToString(),2);

        if (userSessionJobNo == "")
        {
            userSessionJobNo = CheckSessionUserNull(2);
            if (userSessionJobNo != "")
                updateSessionUser(2);
        }

        //update sessionuserName  as current user and confirmed is true

        string strYear = System.DateTime.Now.Year.ToString().Substring(2, 2);

        string jobShortName = getJobTypeShortName(2);      // for payment seriesID = 2

        if (userSessionJobNo != "")
        {
            // Same user come back So Same Job No.
            txtJobNo.Text = jobShortName + userSessionJobNo;
        }
        else
        {
            if (new JobOrderData().checkJobNoconfimed(2) == "")
            {
                txtJobNo.Text = jobShortName + strYear + GenarateAutomate_JobNo();

                string strTempJobNo = strYear + GenarateAutomate_JobNo();

                new JobOrderData().InsertTemJobNo(strTempJobNo, Session["UserName"].ToString(),2,2,2);
            }
            else
            {
                txtJobNo.Text = new JobOrderData().checkJobNoconfimed(2);
                new JobOrderData().UpdateSessionUser(Session["UserName"].ToString(),2);
            }
        }
    }
    private string CheckSessionUserNull(int seriesID)
    {
        string jobNo = string.Empty;

        try
        {
            using (SqlConnection con = new SqlConnection(connValue))
            {
                con.Open();
                using (SqlCommand sqlCom = new SqlCommand())
                {
                    sqlCom.CommandType = CommandType.Text;
                    sqlCom.Connection = con;
                    // sqlCom.CommandText = "sp_CheckCurrentUserSessioExist";

                    sqlCom.CommandText = "SELECT JobNo FROM  TempJobNo WHERE (seriesTypeID = " + seriesID + ") AND (confirmed = 0) and SessionUser is null";
                    using (SqlDataReader sqlReader = sqlCom.ExecuteReader())
                    {
                        while (sqlReader.Read())
                        {
                            jobNo = sqlReader["JobNo"].ToString();
                        }
                    }
                }
            }
        }
        catch (Exception ex)
        {

        }
        finally
        {

        }
        return jobNo;
    }
    private void updateSessionUser(int seriesID)
    {
        // string strUpdate = "Delete from TempJobNo WHERE  (sessionUser = '" + Session["UserName"].ToString() +"') ";

        string strUpdate = "Update TempJobNo Set sessionUser = '" + Session["UserName"].ToString() + "' , confirmed =1 WHERE (sessionUser is null) and (seriesTypeID = " + seriesID + ") and confirmed =0";

        SqlConnection cn = new SqlConnection(connValue);
        SqlCommand sqlCmd = new SqlCommand();
        sqlCmd.CommandType = CommandType.Text;
        sqlCmd.CommandText = strUpdate;
        sqlCmd.Connection = cn;

        // sqlCmd.Parameters.AddWithValue("@docDate", Convert.ToDateTime(txtPopupDatepicker.Text).ToString("dd/MMM/yyyy"));

        try
        {
            cn.Open();
            sqlCmd.ExecuteNonQuery();
        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
        finally
        {
            cn.Close();
        }

        
    }
    private string getJobTypeShortName(int seriesID)
    {
        string jobType = string.Empty;
        using (SqlConnection con = new SqlConnection(connValue))
        {
            con.Open();
            using (SqlCommand sqlCom = new SqlCommand())
            {
                // sqlCom.CommandType = CommandType.StoredProcedure;
                sqlCom.CommandType = CommandType.Text;
                sqlCom.Connection = con;
                sqlCom.CommandText = "SELECT jobTypeShortName FROM JobType WHERE  seriesTypeID = " + seriesID;

                using (SqlDataReader sqlReader = sqlCom.ExecuteReader())
                {
                    while (sqlReader.Read())
                    {
                        jobType = sqlReader["jobTypeShortName"].ToString();
                    }
                }
            }
        }
        return jobType;
    }
    private void getContractData()
    {
        string contractNo = Request.Form[txtSearch.UniqueID];
        string customerId = Request.Form[hfCustomerId.UniqueID];
        string typeOfPay = Request.Form[hfPayType.UniqueID];

        lblmsg.Text = "";

        string userSessionJobNo = string.Empty;


      //  ------------------------------------------------------------------------------

            // Stop tempjobno from july 15
           // genaratePaymentNo();

      // -----------------------------------------------------------------------

        //userSessionJobNo = CheckCurrentUserSessioExist(Session["UserName"].ToString());

        //if (userSessionJobNo != "")
        //{
        //    // Same user come back So Same Job No.
        //    txtJobNo.Text = userSessionJobNo;
        //}
        //else
        //{
        //    if (checkJobNoconfimed() == "")
        //    {
        //        txtJobNo.Text = "PR16" + GenarateAutomate_JobNo();
        //        InsertTemJobNo();
        //    }
        //    else
        //    {
        //        txtJobNo.Text = checkJobNoconfimed();
        //        UpdateSessionUser();
        //    }
        //}


        //if (Application["PrjType"].ToString().Equals("CP"))
        //{
        //    getPCMCommitmentData();
        //    getPCMData();
        //}
        //else
        {
            string companyNameID = string.Empty;
            if (txtSearch.Text != "")
            {
                if (customerId != "")
                {
                    contractColl = new JobOrderData().getVendorData(Convert.ToInt32(customerId));
                    if (contractColl.Count > 0)
                    {
                        Session["sessprjColl"] = contractColl;
                        txtPrjTitle.Text = contractColl[0];
                        txtCntr.Text = contractColl[5];
                    }
                    else
                    {

                    }
                }
            }

            // --------------------------------------------------------------------------------------------------------------------------------------------------


            if (new JobOrderData().getMaxPaymentRequestNo(txtSearch.Text) == "")
            {
                txtApplicationNo.Text = "00000";

                // --------------------------------------------------------------------------------------------------------------------------------------------------

                if (txtApplicationNo.Text.Equals("00000"))
                {
                    if (ddlPayType.SelectedIndex == 0)
                        ddlPayType.SelectedValue = "1";       // first Payment                 

                }
            }
            else
            {
                txtApplicationNo.Text = new JobOrderData().getMaxPaymentRequestNo(txtSearch.Text);
                if (ddlPayType.SelectedIndex == 0)
                    ddlPayType.SelectedValue = "2";
            }

            int iCnt = (Convert.ToInt32(txtApplicationNo.Text) + 1);

            if (iCnt.ToString().Length == 1)
                txtApplicationNo.Text = "0000" + iCnt;
            else if (iCnt.ToString().Length == 2)
                txtApplicationNo.Text = "000" + iCnt;
            else if (iCnt.ToString().Length == 3)
                txtApplicationNo.Text = "00" + iCnt;
            else if (iCnt.ToString().Length == 4)
                txtApplicationNo.Text = "0" + iCnt;



            // --------------------------------------------------------------------------------------------------------------------------------------------------

            if (new JobOrderData().getAssignedPM(txtSearch.Text) == "")
                txtPM.Text = "Unknown";
            else
                txtPM.Text = new JobOrderData().getAssignedPM(txtSearch.Text);

            // --------------------------------------------------------------------------------------------------------------------------------------------------

            // contractColl[7].ToString(); 

            if (customerId != "")
            {
                ddlDept.SelectedValue = geteBookDept(Convert.ToInt32(contractColl[7].ToString())).ToString();

                if (new JobOrderData().getPaymentFor(txtSearch.Text).ToString() != "0")
                    ddlPaymentFor.SelectedValue = new JobOrderData().getPaymentFor(txtSearch.Text).ToString();
                else
                    ddlPaymentFor.SelectedIndex = -1;
            }

             if (contractColl.Count == 0)
                 ClientScript.RegisterClientScriptBlock(this.GetType(), "Popup", "<script>alert('Data is not available.Please enter all details of Payment Request.')</script>", false);
        }
    }
    protected void btnData_Click(object sender, EventArgs e)
    {
        // ClearData();       

        if (txtSearch.Text != "")
        {
            getContractData();
            btnContinue.Enabled = true;
        }
       

        // Application["PrjType"] = null; 
    }
    private void ClearData()
    {
        txtApplicationNo.Text = "";
        ddlOriginSender.SelectedIndex = 0;
        ddlPaymentFor.SelectedIndex = 0;
        ddlPayType.SelectedIndex = 0;

        ddlDept.SelectedIndex = 0;

        txtDocRefNo.Text = "";
        txtDocSubject.Text = "";
        txtPM.Text = "";

        txtPrjTitle.Text = "";
        txtCntr.Text = "";
    }


}