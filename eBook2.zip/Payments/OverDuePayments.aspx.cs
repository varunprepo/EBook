﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using System.Drawing;
using Datalayer;
using System.Data;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class Payments_OverDuePayments : System.Web.UI.Page
{
    string connValue = System.Configuration.ConfigurationManager.ConnectionStrings["EBSDEBookConn"].ConnectionString;
    IList<string> userRightsColl = new List<string>();
    string profile_Name = string.Empty;
    int _userID = 0;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["UserName"] == null)
        {
            Response.Redirect("~/LoginPage.aspx", false);
            return;
        }

        userRightsColl = (IList<string>)Session["UserRightsColl"];
        _userID = Convert.ToInt32(Session["UserID"]);

        if (!IsPostBack)
        {
            DataTable dt = new DataTable();
            if ((Session["userProfileID"].Equals("1")) || (!userRightsColl.Contains("17")))
            {              
                string strQS = "SELECT Distinct jobOwner.contactID, Contact.userShortName AS UserName FROM JobOwner INNER JOIN  Contact ON jobOwner.contactID = Contact.contactID Where payID is not null and jobOwnerStatusID <>7  Order by Contact.userShortName ";
                PopulateDropDownBox(ddlStaff, strQS, "contactID", "UserName");
                dt = getViewPaymentData(0);
                lblCnt.Text = dt.Rows.Count.ToString();
            }
            else
            {
                ddlStaff.Visible = false;
                lblStaffName.Visible = false;
                dt = getViewPaymentData(_userID);
                lblCnt.Text = dt.Rows.Count.ToString();
            }

            gridPayView.DataSource = dt;
            Session["getPayData"] = dt;
            gridPayView.DataBind();
        }
    }
    public void getOverDueJobs()
    {
       string sqlQuery = " SELECT Affair.affairName, COUNT(Affair.affairName) AS PayCnt " +
                           " FROM  Department INNER JOIN Affair ON Department.affairID = Affair.affairID RIGHT OUTER JOIN Payment ON Department.departmentID = Payment.deptID " +
                      " GROUP BY Affair.affairName UNION ALL SELECT 'Total' AS Total, COUNT(Affair_1.affairName) AS Expr1 FROM Department AS Department_1 INNER JOIN Affair AS Affair_1 ON Department_1.affairID = Affair_1.affairID RIGHT OUTER JOIN " +
                        "  Payment AS Payment_1 ON Department_1.departmentID = Payment_1.deptID";


        SqlConnection objCon = new SqlConnection(connValue);
        objCon.Open();
        SqlCommand objCmd = new SqlCommand(sqlQuery, objCon);
        SqlDataAdapter objDA = new SqlDataAdapter(objCmd);
        DataSet dsTndr123 = new DataSet();
        objDA.Fill(dsTndr123);

        gridPayView.DataSource = dsTndr123.Tables[0];
        Session["getPayData"] = dsTndr123.Tables[0];
        gridPayView.DataBind();
    }
    protected void lnkPaymentData_Link(object sender, EventArgs e)     //ForCommitted
    {
        //Session["PayID"] = null;
        try
        {
            LinkButton lnkJobID = (LinkButton)sender;
            GridViewRow gvr = (GridViewRow)lnkJobID.NamingContainer;
            Session["PayID"] = ((HtmlGenericControl)gvr.FindControl("divpayID")).InnerText;
            Session["UrlRef"] = Request.Url.AbsoluteUri;
            Response.Redirect("~/Payments/PaymentDetails.aspx?payID = " + Session["PayID"] + "", false);
        }
        catch
        {

        }
    }   
    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        DataTable dt = new DataTable();
        if (ddlStaff.SelectedIndex != 0)
            dt = getViewPaymentData(_userID);
        else
        {
            if ((Session["userProfileID"].Equals("1")) || (!userRightsColl.Contains("17")))
            {
                dt = getViewPaymentData(0);
                lblCnt.Text = dt.Rows.Count.ToString();
            }
        }

        Session["getPayData"] = dt;
        lblCnt.Text = dt.Rows.Count.ToString();

        gridPayView.DataSource = dt;
        gridPayView.DataBind();
    }
    private DataTable getViewPaymentData(int userID)
    {
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        try
        {
            Int32 qsID;
            if (ddlStaff.SelectedValue != "")
                Int32.TryParse(ddlStaff.SelectedValue, out qsID);
            else
            {
                qsID = 0;
                Int32.TryParse(userID.ToString(), out qsID);
            }
            ds = (new JobOrderData().GetOverDuePaymentData());       //SpName - sp_GetPaymentData
        }
        catch (Exception ex)
        {
            throw ex;
        }

        if (ds.Tables.Count == 0)
            return dt;
        else
            return ds.Tables[0];
    }
    protected void btnExel_Click(object sender, EventArgs e)
    {
        ExportToExcel();
    }
    protected void gridPayView_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        gridPayView.PageIndex = e.NewPageIndex;

        //gridPayView.DataSource = Session["getPayData"];
        //gridPayView.DataBind();

        DataTable dt = new DataTable();
        dt = Session["getPayData"] as DataTable;

        lblCnt.Text = " (" + dt.Rows.Count.ToString() + ")";

        gridPayView.DataSource = dt;
        gridPayView.DataBind();
    }
    protected void gridPayView_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            Label jobNo = (Label)e.Row.FindControl("lblJobNo");
            //  Label lblJobRecDate = (Label)e.Row.FindControl("lblCmtRecDate");
            Label lblJobStatus = (Label)e.Row.FindControl("lblJobStatus");

            Label _lblCaluclateDate = (Label)e.Row.FindControl("lblCaluclateDate");

            string calDate = string.Empty;
            if (_lblCaluclateDate.Text != "")
            {
                calDate = new JobOrderData().pay_getEndDateByGivenDays(_lblCaluclateDate.Text, 7);
            }

            string jobOrderStat = lblJobStatus.Text;    //On-going

            if ((calDate != ""))
            {
                if (!jobOrderStat.Equals("Closed"))   //|| (!jobOrderStat.Equals("Cancelled"))
                {

                    if (Convert.ToDateTime(calDate) < System.DateTime.Now)
                    {
                        e.Row.BackColor = System.Drawing.Color.LightPink;
                        e.Row.ForeColor = System.Drawing.Color.Red;

                        e.Row.Font.Bold = true;

                        jobNo.BackColor = System.Drawing.Color.Yellow;
                        e.Row.Cells[0].BackColor = System.Drawing.Color.White;
                    }
                }
            }
        }
    }

    #region Functions

    private void PopulateDropDownBox(DropDownList ddlBox, string sqlQuery, string valueMember, string displayName)
    {
        ddlBox.DataSource = new JobOrderData().FillDropdown(sqlQuery);
        ddlBox.DataTextField = displayName;
        ddlBox.DataValueField = valueMember;
        ddlBox.SelectedIndex = -1;
        ddlBox.DataBind();

        ListItem emptyItem = new ListItem("", "");
        ddlBox.Items.Insert(0, emptyItem);
    }

    private void ExportToExcel()
    {
        Response.Clear();
        Response.Buffer = true;
        Response.AddHeader("content-disposition", "attachment;filename=GridViewExport.xls");
        Response.Charset = "";
        Response.ContentType = "application/vnd.ms-excel";
        using (StringWriter sw = new StringWriter())
        {
            HtmlTextWriter hw = new HtmlTextWriter(sw);

            //To Export all pages
            gridPayView.AllowPaging = false;

            gridPayView.DataSource = Session["getPayData"];
            gridPayView.DataBind();

            gridPayView.HeaderRow.BackColor = Color.White;
            foreach (TableCell cell in gridPayView.HeaderRow.Cells)
            {
                cell.BackColor = gridPayView.HeaderStyle.BackColor;
            }
            foreach (GridViewRow row in gridPayView.Rows)
            {
                row.BackColor = Color.White;
                foreach (TableCell cell in row.Cells)
                {
                    if (row.RowIndex % 2 == 0)
                    {
                        cell.BackColor = gridPayView.AlternatingRowStyle.BackColor;
                    }
                    else
                    {
                        cell.BackColor = gridPayView.RowStyle.BackColor;
                    }
                    cell.CssClass = "textmode";
                }
            }

            gridPayView.RenderControl(hw);

            //style to format numbers to string
            string style = @"<style> .textmode { } </style>";
            Response.Write(style);
            Response.Output.Write(sw.ToString());
            Response.Flush();
            Response.End();
        }
    }
    public override void VerifyRenderingInServerForm(Control control)
    {
        /* Verifies that the control is rendered */
    }

    #endregion
}