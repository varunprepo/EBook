﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using Datalayer;
using System.Data.SqlClient;

public partial class Payments_PaymentCheckList : System.Web.UI.Page
{
    string connValue = System.Configuration.ConfigurationManager.ConnectionStrings["EBSDEBookConn"].ConnectionString;
    int _payID = 0;
    protected void Page_Load(object sender, EventArgs e)
    {
        gridChkList.DataSource = new JobOrderData().getchecklistData(1);
        gridChkList.DataBind();

    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        UpdatePaymentCheckList();
    }
    private void UpdatePaymentCheckList()
    {
        foreach (GridViewRow  gridRow in gridChkList.Rows)
	    {

            Boolean grvcheck1 = true;
            Boolean grvcheck2 = true;
            Boolean grvcheck3 = true;
            Boolean grvcheck4 = true;
            Boolean grvcheck5 = true;
            Boolean grvcheck6 = true;
            Boolean grvcheck7 = true;
            Boolean grvcheck8 = true;
            Boolean grvcheck9 = true;
            Boolean grvcheck10 = true;
            Boolean grvcheck11 = true;
            Boolean grvcheck12 = true;
            Boolean grvcheck13 = true;
            Boolean grvcheck14 = true;
            Boolean grvcheck15 = true;
            Boolean grvcheck16 = true;
            Boolean grvcheck17 = true;
            Boolean grvcheck18 = true;            
	    

        SqlConnection con = new SqlConnection(connValue);
        SqlCommand cmd = new SqlCommand();
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Connection = con;
        cmd.CommandText = "UpdatePayChkList";
        try
        {
            cmd.Parameters.AddWithValue("@payID", _payID);
            cmd.Parameters.AddWithValue("@check1", grvcheck1);
            cmd.Parameters.AddWithValue("@check2", grvcheck2);
            cmd.Parameters.AddWithValue("@check3", grvcheck3);
            cmd.Parameters.AddWithValue("@check4", grvcheck4);
            cmd.Parameters.AddWithValue("@check5", grvcheck5);
            cmd.Parameters.AddWithValue("@check6", grvcheck6);
            cmd.Parameters.AddWithValue("@check7", grvcheck7);
            cmd.Parameters.AddWithValue("@check8", grvcheck8);
            cmd.Parameters.AddWithValue("@check9", grvcheck9);
            cmd.Parameters.AddWithValue("@check10", grvcheck10);
            cmd.Parameters.AddWithValue("@check11", grvcheck11);
            cmd.Parameters.AddWithValue("@check12", grvcheck12);
            cmd.Parameters.AddWithValue("@check13", grvcheck13);
            cmd.Parameters.AddWithValue("@check14", grvcheck14);
            cmd.Parameters.AddWithValue("@check15", grvcheck15);
            cmd.Parameters.AddWithValue("@check16", grvcheck16);
            cmd.Parameters.AddWithValue("@check17", grvcheck17);
            cmd.Parameters.AddWithValue("@check18", grvcheck18);
        }
        catch (Exception ex)
        {

            throw ex;
        }

        try
        {
            con.Open();
            cmd.ExecuteNonQuery();
            con.Dispose();
        }
        catch (Exception ex)
        {

            throw ex;
        }
        finally
        {
            con.Close();
        }
        }
    }
}