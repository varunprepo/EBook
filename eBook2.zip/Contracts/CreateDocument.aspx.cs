﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using Datalayer;
using System.Data.SqlClient;
using System.Data;
using System.Globalization;
using System.Configuration;
using System.Collections;
using System.IO;
using System.Text;
using System.Web.UI.HtmlControls;
using System.Net;
using System.Net.Mail;
using System.Security.Cryptography.X509Certificates;
using System.Net.Security;

public partial class Contracts_CreateDocument : System.Web.UI.Page
{
    string connValue = System.Configuration.ConfigurationManager.ConnectionStrings["EBSDEBookConn"].ConnectionString;
    string connValueTCMS = System.Configuration.ConfigurationManager.ConnectionStrings["TCMSConn"].ConnectionString;

    int _docID = 0;
    int _docCatID = 0;

    string _flag = string.Empty;
    string replyToClose = string.Empty;

    int _currentUserID = 0;
    string _userName = string.Empty;

    IList<string> userRightsColl = null; int _profileID = 0;

    static ArrayList docrowList = new ArrayList();
    static DataTable dtDistrUserExist = new DataTable();

    #region MyRegion

    protected void Page_Load(object sender, EventArgs e)
    {

        pageInitDataLoad();

        //  trDocJobNo.Visible = false;

        // trDistrib.Visible = false;         

        Label2.Text = "Rights : - " + userRightsColl.Count.ToString();
        lblCatID.Text = "CatID - : - " + _docCatID.ToString();

        if (ViewState["replyToClose"] != null)
        {
            lblRply.Text = " rplyCls " + ViewState["replyToClose"].ToString();
            if (Session["referenceNo"] != null)
                txtRplyDoc.Text = Session["referenceNo"].ToString();
        }
        else
        {
            lblRply.Text = " rplyCls = NULL";
            txtRplyDoc.Text = "";
        }

        if (Session["personOnLeave"] != null)
            lblLeave.Text = Session["personOnLeave"].ToString();

        if (!IsPostBack)
        {
            trCntrls.Visible = false;

            lblDocID.Text = _docID.ToString();
            if (Session["JobID"] != null)
            {
                lblJobID.Text = Session["JobID"].ToString();
                lblSessionJob.Text = "Session Job ID : - " + Session["JobID"].ToString();
            }

            Session["distribDocID"] = null;           // it should kill for button click on rec/Sent new from job or payment details ------ ist comming from disribution document

            if (_docID == 0)
            {
                // btnSave.Enabled = false; 
                btnDelete.Visible = false;



                ddlProjectID.Enabled = false;
                ddlTenderNo.Enabled = false;
                ddlContractNo.Enabled = false;


                txtPopupDatepicker.Text = System.DateTime.Now.ToString("dd/MMM/yyyy");
                txtDateReceived.Text = System.DateTime.Now.ToString("dd/MMM/yyyy");

                if (_docCatID == 2)
                {
                    ddlOriginSender.SelectedValue = _currentUserID.ToString();
                    ddlCompany.SelectedValue = Session["CmpID"].ToString();
                }
            }
            else
            {
                // btnDelete.Visible = true;

                lnkAttachments.Enabled = true;
                lnkFile.Enabled = true;
                ImageButton1.Enabled = true;
                ImageButton2.Enabled = true;
                CheckAttachments(_docID);

                btnSubmit.Visible = true;
            }


            if (_docCatID == 2)
            {
                txtDateReceived.Visible = false;
                lblRecDate.Visible = false;
                txtPopupDatepicker.Width = 250;
            }


            if (Session["docSender"] != null)
                ddlOriginSender.SelectedValue = Session["docSender"].ToString();
            if (Session["docOrginCmpID"] != null)
                ddlCompany.SelectedValue = Session["docOrginCmpID"].ToString();



            // ============================================================================================================

            FillDropdownData();

            trDocCreated.Visible = false;

            if (_docID != 0)
            {
                FillAllDocumentData();
                DistributionGridView();

                FillDocRelatedTasks(_docID, _currentUserID);

            }

            if (_docID == 0 & Session["distribDocID"] != null)
            {
                _docID = Convert.ToInt32(Session["distribDocID"]);
                Session["distribDocID"] = null;
            }

            // ============================================================================================================

            // check enable for btnDelete last execution

            if (Session["JobID"] != null)
            {
                if (Session["JobID"].ToString() != "")
                {
                    if (CheckOpenClosedDocExistForJob(Convert.ToInt32(Session["JobID"])))
                        btnDelete.Enabled = false;
                    btnDelete.BackColor = System.Drawing.Color.WhiteSmoke;
                }
            }

            int _distribID = 0;
            if (_docID != 0)
            {
                if (checkUserExistDateRead(ref _distribID))
                    new JobOrderData().UpdateDistributionDateRead(_distribID, _currentUserID);

                // DistributionGridView(); //Added newly
            }

            trDocCreated.Visible = false;

            // testCode();

        }

        if (lblDocID.Text != "")
            _docID = Convert.ToInt32(lblDocID.Text);

        if (_docID != 0)
            btnCreateDoc.Text = "Update Document";

        else
            btnCreateDoc.Text = "Prepare Document";


        // For Non EBD Doc Type Session

        if (Session["docType"] != null)
            ddlTypeOfDocs.SelectedValue = Session["docType"].ToString();

        if (gvDocProjAttributes.Rows.Count > 0)
            btnSubmit.Visible = false;
        else if (txtDocSubject.Text == "")
            btnSubmit.Visible = false;
        else
            btnSubmit.Visible = true;

        if (lblDocJobNO.Text == "")
            JobRelatedControls(false);

    }
    private void CheckAttachments(int chkdocID)
    {
        int fileCnt = 0;
        fileCnt = coverLetterExist(chkdocID);

        if (fileCnt == 0)
            ImageButton1.Visible = false;
        else
        {
            ImageButton1.Visible = true;
            lblCover.Text = "( " + fileCnt + " )";
        }

        int attCnt = 0;

        attCnt = fileAttachmentsExist(chkdocID);
        if (attCnt == 0)
            ImageButton2.Visible = false;
        else
        {
            ImageButton2.Visible = true;
            lblAttch.Text = "( " + attCnt + " )";
        }
    }

    private void pageInitDataLoad()
    {
        if (Session["UserName"] == null)
        {
            Response.Redirect("~/LoginPage.aspx", false);
            return;
        }

        // =============================================================================================================================

        //_docID = 0;
        //_docCatID = 0;

        _currentUserID = Convert.ToInt32(Session["UserID"]);
        userRightsColl = (IList<string>)Session["UserRightsColl"];
        _profileID = Convert.ToInt32(Session["UserProfileID"]);
        _userName = Session["UserName"].ToString();


        // --------------------------------------------------------------------------------------------------------------------------------------

        if (ViewState["replyToClose"] == null)
            ViewState["replyToClose"] = Request.QueryString["Reply"];

        if (_docID == 0)
            _docID = Convert.ToInt32(Request.QueryString["docRecID"]); //docRecID 

        //if (_docID == 0)
        //    _docID = Convert.ToInt32(Request.QueryString["PaydocRecID"]);   

        if (_docCatID == 0)
            _docCatID = Convert.ToInt32(Request.QueryString["RecSentCatID"]); //ReceiveAndSent Document Page of Receive/Upload Grid link    


        //  ======================================================== ==========================================================================                     

        if (_docID == 0)
            _docID = Convert.ToInt32(Session["SearchDocID"]);               //  From Search Document Page

        if (_docCatID == 0)
            _docCatID = Convert.ToInt32(Session["SearchDocCatID"]);         //  From Search Document Page

        if (Request.QueryString["Flag"] == null)
            ViewState["_flag"] = "0";     // not from reply to close
        else
            ViewState["_flag"] = Request.QueryString["Flag"]; //  from reply to close

        //   ===================================================================================================================================    

        if (!IsPostBack)
        {
            if (_docID == 0 & lblDocID.Text != "")
                _docID = Convert.ToInt32(lblDocID.Text);

            if (_docID == 0 & Session["distribDocID"] != null)       // Document Distribution Page 
                _docID = Convert.ToInt32(Session["distribDocID"]);
        }

        //  ============================================================================================================================================= 

        if (lblDocID.Text == "")
            lblDocID.Text = _docID.ToString();

    }
    private void JobRelatedControls(Boolean isStatus)
    {
        if (isStatus)
        {
            trDocJobNo.Visible = true;
            trlblJobNo.Visible = true;
            trDistrib.Visible = true;
            trDisrubTbl.Visible = true;
        }
        else
        {
            trDocJobNo.Visible = false;
            trlblJobNo.Visible = false;
            trDistrib.Visible = false;
            trDisrubTbl.Visible = false;
        }
    }
    private void DistributionGridView()
    {
        if (_docID != 0)
        {
            _docID = Convert.ToInt32(lblDocID.Text);
            dtDistrUserExist = fillDataDistribution(_docID);
            if (dtDistrUserExist.Rows.Count > 0)
            {
                DataRow[] rows = dtDistrUserExist.Select("contactID = " + _currentUserID);

                if ((rows.Count() == 0) & (_docID != 0))
                {
                    if (_profileID.Equals(1) || Session["docCreatedByID"].Equals(_currentUserID.ToString()) || Session["originContactID"].Equals(_currentUserID.ToString()))
                    {
                        EnableControlsStatusForNonDistribution();
                        //  chkSuperseded.Visible = true;
                        // tdSuper.Visible = true;
                        // tdDivSuperseded.Visible = true;
                    }
                    else
                    {
                        DisableControlsStatusForNonDistribution();
                        //   chkSuperseded.Visible = false;
                        //   tdSuper.Visible = false;
                        //  tdDivSuperseded.Visible = false;
                    }
                }
                else
                    EnableControlsStatusForNonDistribution();
            }
        }
        else
            EnableControlsStatusForNonDistribution();
    }
    private void FillAllDocumentData()
    {
        fillDocumentData(_docID);
        gridloadForProjectAttributeData();
        gridloadForDBSValues();
        checkOpenCloseDocumentInJob(_docID);

        gridloadForDocDistributeData(_docID); // new Added

    }
    private Boolean checkUserExistDateRead(ref int _disribID)
    {
        string prjTitle = string.Empty;

        using (SqlConnection cnn = new SqlConnection(connValue))
        {
            cnn.Open();
            using (SqlCommand cmm = new SqlCommand())
            {
                cmm.Connection = cnn;
                cmm.CommandText = "SELECT contactID,distributeID  FROM DocumentDistribution WHERE dateread is null and documentID = " + _docID + " and  contactID  = '" + _currentUserID + "' ";
                using (SqlDataReader sqlDtReader = cmm.ExecuteReader())
                {
                    if (sqlDtReader.HasRows)
                    {
                        while (sqlDtReader.Read())
                        {
                            _disribID = Convert.ToInt32(sqlDtReader["distributeID"].ToString());
                            return true;
                        }
                    }
                }
            }
        }
        return false;
    }
    protected void lnkJobNo_Click(object sender, EventArgs e)
    {
        try
        {
            LinkButton lnkJobID = (LinkButton)sender;
            GridViewRow gvr = (GridViewRow)lnkJobID.NamingContainer;

            Session["JobID"] = ((HtmlGenericControl)gvr.FindControl("divLnkJobID")).InnerText;
            Session["JobInchargeID"] = lnkJobID.ToolTip;

            Session["JobCatID"] = ((HtmlGenericControl)gvr.FindControl("divJoCatbID")).InnerText;

            if (((HtmlGenericControl)gvr.FindControl("divJoCatbID")).InnerText != "1")
            {
                Session["UrlRef"] = "~/JobOrder/DefaultGrid.aspx";
                Response.Redirect("~/JobOrder/DefaultGrid.aspx?JobID= " + Session["JobID"] + "", false);
            }
            else
            {
                Session["UrlRef"] = "~/JobOrder/PSAJobDetails.aspx";
                Response.Redirect("~/JobOrder/PSAJobDetails.aspx?JobID= " + Session["JobID"] + "", false);
            }
        }
        catch (Exception ex)
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Error occurred while processing the request')</script>", false);
        }
    }
    private void DisableControlsStatusForNonDistribution()
    {


        btnDelete.Enabled = false;
        btnDelete.BackColor = System.Drawing.Color.WhiteSmoke;
        btnAddProjAttrib.Enabled = false;



        ddlContractNo.Enabled = false;
        ddlProjectID.Enabled = false;
        ddlTenderNo.Enabled = false;



        txtPopupDatepicker.Enabled = false;
        txtDateReceived.Enabled = false;
    }
    private void EnableControlsStatusForNonDistribution()
    {


        btnDelete.Enabled = true;
        btnAddProjAttrib.Enabled = true;



        ddlContractNo.Enabled = true;
        ddlProjectID.Enabled = true;
        ddlTenderNo.Enabled = true;



        txtPopupDatepicker.Enabled = true;
        txtDateReceived.Enabled = true;
    }


    #region MyRegion


    private int coverLetterExist(int filedocID)
    {
        int fileCnt = 0;
        using (SqlConnection con = new SqlConnection(connValue))
        {
            con.Open();
            using (SqlCommand sqlCom = new SqlCommand())
            {
                // sqlCom.CommandType = CommandType.StoredProcedure;
                sqlCom.CommandType = CommandType.Text;
                sqlCom.Connection = con;
                string sqlfileType = "select  count(fileID)  from FilesTable where isFileActive = 1 and  fileType ='F' and docID = " + filedocID + "";
                sqlCom.CommandText = sqlfileType;

                using (SqlDataReader sqlReader = sqlCom.ExecuteReader())
                {
                    while (sqlReader.Read())
                    {
                        fileCnt = Convert.ToInt32(sqlReader[0].ToString());
                    }
                }
            }
        }
        return fileCnt;
    }
    private int fileAttachmentsExist(int filedocID)
    {
        int fileCnt = 0;
        using (SqlConnection con = new SqlConnection(connValue))
        {
            con.Open();
            using (SqlCommand sqlCom = new SqlCommand())
            {
                // sqlCom.CommandType = CommandType.StoredProcedure;
                sqlCom.CommandType = CommandType.Text;
                sqlCom.Connection = con;
                string sqlfileType = "select  count(fileID)  from FilesTable where isFileActive = 1 and  fileType ='A' and docID = " + filedocID + " ";
                sqlCom.CommandText = sqlfileType;

                using (SqlDataReader sqlReader = sqlCom.ExecuteReader())
                {
                    while (sqlReader.Read())
                    {
                        fileCnt = Convert.ToInt32(sqlReader[0].ToString());
                    }
                }
            }
        }
        return fileCnt;
    }

    private void FillDropdownData()
    {
        string selectName = string.Empty;

        //  dropdown index 0 should no as Select string for required feild validatior

        PopulateDropDownBox(ddlTypeOfDocs, "SELECT docTypeID, documentType FROM DocumentType ORDER BY documentType ", "docTypeID", "documentType", "");

        ddlTypeOfDocs.SelectedValue = "8"; // Internal memo

        PopulateDropDownBox(ddlOriginSender, "SELECT contactID, (firstName + ' ' + lastName) as OriginSender FROM  Contact  ORDER BY OriginSender ", "contactID", "OriginSender", ""); //WHERE (isActive = 1)

        PopulateDropDownBox(ddlCompany, "SELECT companyID, cmpName FROM  Company ORDER BY cmpName ", "companyID", "cmpName", "");

        // PopulateDropDownBox(ddlDocCrossRefNo1, "SELECT documentID, referenceNo FROM  Document ORDER BY referenceNo ", "documentID", "referenceNo", "");

        PopulateDropDownBox_TCMS(ddlProjectID, "SELECT  proj_id, project_code FROM  PROJECTS ORDER BY project_code", "proj_id", "project_code", "Select Project ID to Add");

        PopulateDropDownBox_TCMS(ddlTenderNo, "SELECT  proj_id, tender_no FROM PROJECTS WHERE (tender_no IS NOT NULL)  ORDER BY tender_no", "proj_id", "tender_no", "Select Tender No. to Add");

        PopulateDropDownBox_TCMS(ddlContractNo, "SELECT bidder_id,Contract_No FROM CONTRACTORS WHERE (Contract_No IS NOT NULL) and (Contract_No != '')  ORDER BY Contract_No", "bidder_id", "Contract_No", "Select Contract No.to Add");

        //  PopulateDropDownBox(ddlPrjCoordinator, "Select prjCoordID,CoordName From ProjCoordinator order by CoordName", "prjCoordID", "CoordName", "");

        PopulateDropDownBox(ddlPrjCoordinator, "Select ContactID, (firstName + ' ' + lastName) as PrjCoordinator From Contact where CompanyID in(366,367) order by PrjCoordinator", "ContactID", "PrjCoordinator", "");

    }
    private void PopulateDropDownBox_TCMS(DropDownList ddlBox, string sqlQuery, string valueMember, string displayName, string selectName)
    {

        ddlBox.DataSource = new JobOrderData().FillDropdown_TCMS(sqlQuery);
        ddlBox.DataTextField = displayName;
        ddlBox.DataValueField = valueMember;
        ddlBox.SelectedIndex = -1;

        ddlBox.DataBind();

        ListItem emptyItem = new ListItem(selectName, selectName);
        ddlBox.Items.Insert(0, emptyItem);
    }

    private void PopulateDropDownBox(DropDownList ddlBox, string sqlQuery, string valueMember, string displayName, string selectName)
    {
        ddlBox.DataSource = new JobOrderData().FillDropdown(sqlQuery);
        ddlBox.DataTextField = displayName;
        ddlBox.DataValueField = valueMember;
        ddlBox.SelectedIndex = -1;
        ddlBox.DataBind();

        ListItem emptyItem = new ListItem(selectName, selectName);
        ddlBox.Items.Insert(0, emptyItem);
    }

    #endregion

    protected void ddlMajorDBSValues_SelectedIndexChanged(object sender, EventArgs e)
    {

    }

    static Boolean isprjCodeChanged = false;
    protected void ddlOriginSender_SelectedIndexChanged(object sender, EventArgs e)
    {
        int cmpID = 0;
        if (ddlOriginSender.SelectedIndex != 0)
        {
            cmpID = getCompanyID(Convert.ToInt32(ddlOriginSender.SelectedValue));

            ddlCompany.SelectedValue = cmpID.ToString();
        }


        if ((cmpID == 362) || (cmpID == 2783)) // From EBSD
            lblDocCatID.Text = "2";
        else
            lblDocCatID.Text = "1";


        isprjCodeChanged = true;

        txtDocRefNo.Focus();

    }
    public IList<int> getDistributionDataForOrginSender(int orginID)
    {
        IList<int> strColl = new List<int>();
        try
        {
            string qry = "SELECT distributeID, contactID  From DocumentDistribution WHERE (documentID = " + _docID + ") AND (contactID = " + orginID + ")";

            using (SqlConnection sqlConn = new SqlConnection(connValue))
            {
                sqlConn.Open();

                using (SqlCommand sqlCmd = new SqlCommand())
                {
                    sqlCmd.Connection = sqlConn;
                    sqlCmd.CommandText = qry;

                    using (SqlDataReader dr = sqlCmd.ExecuteReader())
                    {
                        while (dr.Read())
                        {
                            strColl.Add(Convert.ToInt32(dr["distributeID"].ToString()));
                        }
                    }
                }
            }
        }
        catch (Exception ex)
        {
        }

        return strColl;
    }

    public void PrjCodeChangeLog(string changeDesc, string windowName, string NewprjCode, string oldPrjCode)
    {
        if (ddlOriginSender.SelectedIndex != 0)
        {
            string upDateQuery = "INSERT INTO CHANGELOG(ChangeData,windowName,oldData,newData,updateUser) VALUES('" + changeDesc + "','" + windowName + "','" + NewprjCode + "','" + oldPrjCode + "', '" + Session["UserName"].ToString() + "')";
            SqlConnection sqlCon = new SqlConnection(connValue);
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = upDateQuery;
            cmd.Connection = sqlCon;
            try
            {
                sqlCon.Open();
                cmd.ExecuteNonQuery();
                sqlCon.Close();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }

    protected void ddlCompany_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlCompany.SelectedValue != "362") // From EBSD
            lblDocCatID.Text = "2";
        else
            lblDocCatID.Text = "1";
    }
    private void UpdateDistributionContactID(int distID, int _contactID, string userName)
    {
        // Update contactID and IssedBy and DistributedTo When changing Existed Orgin Sender

        SqlConnection cn = new SqlConnection(connValue);
        SqlCommand sqlCmd = new SqlCommand();
        sqlCmd.CommandType = CommandType.Text;
        sqlCmd.CommandText = "Update DocumentDistribution Set ContactID=@ContactID,createUser = @createUser  Where disributeID= @distID";
        sqlCmd.Connection = cn;

        sqlCmd.Parameters.AddWithValue("@ContactID", _contactID);
        sqlCmd.Parameters.AddWithValue("@distID", distID);
        sqlCmd.Parameters.AddWithValue("@createUser", userName);

        try
        {
            cn.Open();
            sqlCmd.ExecuteNonQuery();
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            cn.Close();
        }
    }
    private void UpdateDocumetOrgin()
    {
        // Update OriginSender and IssedBy and DistributedTo When changing Existed Orgin Sender

        SqlConnection cn = new SqlConnection(connValue);
        SqlCommand sqlCmd = new SqlCommand();
        sqlCmd.CommandType = CommandType.Text;
        sqlCmd.CommandText = "Update Document Set originContactID = @originContactID Where documentID =@docID";
        sqlCmd.Connection = cn;

        sqlCmd.Parameters.AddWithValue("@docID", _docID);
        sqlCmd.Parameters.AddWithValue("@originContactID", ddlOriginSender.SelectedValue);

        try
        {
            cn.Open();
            sqlCmd.ExecuteNonQuery();
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            cn.Close();
        }
    }
    private void UpdateDistributionOrginForIssuedBy(int _NeworginID, int _oldOrginID)
    {
        // Update OriginSender and IssedBy and DistributedTo When changing Existed Orgin Sender

        SqlConnection cn = new SqlConnection(connValue);
        SqlCommand sqlCmd = new SqlCommand();
        sqlCmd.CommandType = CommandType.Text;
        sqlCmd.CommandText = "Update DocumentDistribution Set issuedByContactID= " + _NeworginID + "Where documentID = " + _docID + " and issuedByContactID= " + _oldOrginID + " ";
        sqlCmd.Connection = cn;

        try
        {
            cn.Open();
            sqlCmd.ExecuteNonQuery();
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            cn.Close();
        }
    }
    private void UpdateDistributionOrginForDistributedTo(int _NeworginID, int _oldOrginID)
    {
        // Update OriginSender and IssedBy and DistributedTo When changing Existed Orgin Sender

        SqlConnection cn = new SqlConnection(connValue);
        SqlCommand sqlCmd = new SqlCommand();
        sqlCmd.CommandType = CommandType.Text;

        sqlCmd.CommandText = "Update DocumentDistribution Set ContactID= " + _NeworginID + "  Where documentID = " + _docID + " and ContactID = " + _oldOrginID + " ";
        sqlCmd.Connection = cn;

        try
        {
            cn.Open();
            sqlCmd.ExecuteNonQuery();
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            cn.Close();
        }
    }


    public void gridloadForProjectAttributeData()
    {
        DataSet ds = new DataSet();
        ds = (new JobOrderData().FillDocAttributeData(_docID, _currentUserID));
        gvDocProjAttributes.DataSource = ds;
        gvDocProjAttributes.DataBind();
    }
    public void gridloadForDBSValues()
    {
        DataSet ds = new DataSet();
        ds = (new JobOrderData().FillDBSValues(_docID));

    }


    #region AllFunctions

    private int getCompanyID(int _contactID)
    {
        int cmpID = 0;

        SqlConnection cnn = new SqlConnection(connValue);
        cnn.Open();
        SqlCommand cmm = new SqlCommand();
        cmm.Connection = cnn;

        cmm.CommandText = "SELECT companyID From contact where contactid = " + _contactID;

        SqlDataReader sqlDtReader = cmm.ExecuteReader();
        if (sqlDtReader.HasRows)
        {
            while (sqlDtReader.Read())
            {
                cmpID = Convert.ToInt32(sqlDtReader["companyID"]);
            }
        }
        sqlDtReader.Close();
        cnn.Close();
        return cmpID;
    }

    #endregion

    private string CreateDocument()
    {
        Boolean chkData = false;
        using (SqlConnection cn = new SqlConnection(connValue))
        {
            using (SqlCommand sqlCmd = new SqlCommand())
            {
                try
                {
                    sqlCmd.CommandType = CommandType.StoredProcedure;
                    sqlCmd.CommandText = "sp_InsertDocument_NonEBD";
                    sqlCmd.Connection = cn;

                    // sqlCmd.Parameters.AddWithValue("@docDate", DateTime.ParseExact(txtPopupDatepicker.Text, "dd/MMM/yyyy", CultureInfo.InvariantCulture));

                    sqlCmd.Parameters.AddWithValue("@docDate", Convert.ToDateTime(txtPopupDatepicker.Text).ToString("dd/MMM/yyyy"));
                    sqlCmd.Parameters.AddWithValue("@docTypeID", ddlTypeOfDocs.SelectedValue);
                    sqlCmd.Parameters.AddWithValue("@originID", ddlOriginSender.SelectedValue);

                    Session["originContactID"] = ddlOriginSender.SelectedValue;

                    sqlCmd.Parameters.AddWithValue("@originCoID", ddlCompany.SelectedValue);
                    sqlCmd.Parameters.AddWithValue("@referenceNo", txtDocRefNo.Text);

                    sqlCmd.Parameters.AddWithValue("@docReceivedDate", Convert.ToDateTime(txtDateReceived.Text).ToString("dd/MMM/yyyy"));

                    // sqlCmd.Parameters.AddWithValue("@docReceivedDate", DateTime.ParseExact(txtDateReceived.Text, "dd/MMM/yyyy", CultureInfo.InvariantCulture));
                    if (txtRplyDoc.Text != "")
                        sqlCmd.Parameters.AddWithValue("@crossReferenceNo", txtRplyDoc.Text);
                    else
                        sqlCmd.Parameters.AddWithValue("@crossReferenceNo", System.DBNull.Value);

                    sqlCmd.Parameters.AddWithValue("@docSubject", txtDocSubject.Text);
                    sqlCmd.Parameters.AddWithValue("@docContent", txtDocDescription.Text);

                    if ((ddlCompany.SelectedValue == "362") || (ddlCompany.SelectedValue == "2783"))
                    {
                        sqlCmd.Parameters.AddWithValue("@docCatID", 2);
                        _docCatID = 2;
                    }
                    else
                    {
                        sqlCmd.Parameters.AddWithValue("@docCatID", 1);
                        _docCatID = 1;
                    }

                    sqlCmd.Parameters.AddWithValue("@docCreatedByID", Session["UserID"].ToString());

                    Session["docCreatedByID"] = Session["UserID"].ToString();

                    sqlCmd.Parameters.AddWithValue("@createUser", Session["UserName"].ToString());

                    //sqlCmd.Parameters.AddWithValue("@createDate ", DateTime.ParseExact(DateTime.Now.ToString("dd/MMM/yyyy HH:mm:ss"), "dd/MMM/yyyy HH:mm:ss", CultureInfo.InvariantCulture));

                    if (_docID == 0)
                        sqlCmd.Parameters.AddWithValue("@docID", SqlDbType.SmallInt).Direction = ParameterDirection.Output;
                    else
                        sqlCmd.Parameters.AddWithValue("@docID", _docID);

                    string actionDueDate = getEndDateByGivenDays(txtDateReceived.Text, 1);

                    sqlCmd.Parameters.AddWithValue("@actionDueDate", Convert.ToDateTime(actionDueDate).ToString("dd/MMM/yyyy"));

                    sqlCmd.Parameters.AddWithValue("@isImportance", chkData);
                    sqlCmd.Parameters.AddWithValue("@isSuperseded", chkData);

                    if (Session["JobID"] == null || Session["JobID"].ToString() == "")    // Reply to close validation for JobID
                        sqlCmd.Parameters.AddWithValue("@jobID", System.DBNull.Value);
                    else
                        sqlCmd.Parameters.AddWithValue("@jobID", Convert.ToInt32(Session["JobID"]));

                    // Newly added Parameter for Payment Module

                    if (Session["PayID"] == null)
                        sqlCmd.Parameters.AddWithValue("@payID", System.DBNull.Value);
                    else
                        sqlCmd.Parameters.AddWithValue("@payID", Convert.ToInt32(Session["PayID"]));


                    if (ddlPrjCoordinator.SelectedIndex == 0)
                        sqlCmd.Parameters.AddWithValue("@prjCoordID", System.DBNull.Value);
                    else
                        sqlCmd.Parameters.AddWithValue("@prjCoordID", Convert.ToInt32(ddlPrjCoordinator.SelectedValue));

                    cn.Open();
                    sqlCmd.ExecuteNonQuery();

                }
                catch (Exception ex)
                {
                    throw ex;
                }

                return sqlCmd.Parameters["@docID"].Value.ToString();
            }
        }
    }

    protected void btnCreateDoc_Click1(object sender, EventArgs e)
    {
        saveDocument();
    }
    private void saveDocument()
    {
        _docID = Convert.ToInt32(CreateDocument());

        Session["docSender"] = null;

        Session["File_docID"] = _docID;

        if ((Session["JobID"] != null))        // Coming from Job Order /PSA 
        {
            if (ViewState["replyToClose"] != null)                             // (replyToClose != null)       // Clicked On Rec/Send Button for new Doc Creation
            {
                AddDistributionData(Convert.ToInt32(Session["JobID"]));
                CheckandDeleteDistributionData(_docID);

                // if (replyToClose.Equals("1")) // Clicked On Reply To Close Button

                if (ViewState["replyToClose"].Equals("1")) // Clicked On Reply To Close Button
                    updateJobClosedDate_ReplyToClose(Convert.ToInt32(Session["JobID"]), txtPopupDatepicker.Text);

                lblJobID.Text = Session["JobID"].ToString();
            }
            else
            {
                // Clicked on Link button of Rec/Sent Grid
            }
        }

        Session["JobID"] = null;   // Make Session Null becos of its carring from Job page for new document creation
        Session["PayID"] = null;

        lblDocID.Text = _docID.ToString();



        ddlProjectID.Enabled = true;
        ddlTenderNo.Enabled = true;
        ddlContractNo.Enabled = true;



    }
    private void AddDistributionData(int jobID)
    {
        //Session["DocID"] = 203;

        string sqlQuery = "SELECT contactID, daysToAct, convert(nvarchar,actionDueDate,103) as ActionDueDate,jobOwnerStatusID,JobOwnerID,distributedBy,docID FROM JobOwner WHERE jobID =" + jobID;
        DataTable dtJobOwner = GetDataFromDB("JobOwner", sqlQuery);

        short jobOwnerCounter = 0;
        while (jobOwnerCounter < dtJobOwner.Rows.Count)
        {
            string InchargeStat = dtJobOwner.Rows[jobOwnerCounter]["jobOwnerStatusID"].ToString();

            SqlConnection sqlConn = new SqlConnection(connValue);
            SqlCommand sqlCmd = new SqlCommand();
            sqlCmd.Connection = sqlConn;

            sqlCmd.CommandType = CommandType.StoredProcedure;
            sqlCmd.CommandText = "InsertDocDistributionFromJob";

            sqlCmd.Parameters.AddWithValue("@contactID", dtJobOwner.Rows[jobOwnerCounter]["contactID"].ToString());

            if (InchargeStat != "7")       //
            {
                sqlCmd.Parameters.AddWithValue("@docPurposeID", 1); //// For Action
                sqlCmd.Parameters.AddWithValue("@docStatusID", 1);

                string actionDate = Convert.ToDateTime(dtJobOwner.Rows[jobOwnerCounter][2]).ToString("dd/MMM/yyyy");

                sqlCmd.Parameters.AddWithValue("@actionDueDate", actionDate);   //DateTime.ParseExact(dtJobOwner.Rows[jobOwnerCounter][2].ToString().Split(' ')[0].Split(' ')[0], "dd/MM/yyyy", CultureInfo.InvariantCulture));
                sqlCmd.Parameters.AddWithValue("@daysToReply", dtJobOwner.Rows[jobOwnerCounter]["daysToAct"].ToString());
                sqlCmd.Parameters.AddWithValue("@dateRead", System.DBNull.Value);
            }
            else
            {
                sqlCmd.Parameters.AddWithValue("@docPurposeID", 2);       // For Info
                sqlCmd.Parameters.AddWithValue("@docStatusID", 4);
                sqlCmd.Parameters.AddWithValue("@actionDueDate", System.DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@daysToReply", System.DBNull.Value);
                sqlCmd.Parameters.AddWithValue("@dateRead", System.DateTime.Now.ToString("dd/MMM/yyyy"));
            }

            // sqlCmd.Parameters.AddWithValue("@issuedByContactID", Session["UserID"].ToString());

            sqlCmd.Parameters.AddWithValue("@issuedByContactID", dtJobOwner.Rows[jobOwnerCounter]["distributedBy"].ToString());

            sqlCmd.Parameters.AddWithValue("@createUser", Session["UserName"].ToString());

            sqlCmd.Parameters.AddWithValue("@documentID", _docID);
            sqlCmd.Parameters.AddWithValue("@inchargeID", dtJobOwner.Rows[jobOwnerCounter]["JobOwnerID"].ToString());

            // sqlCmd.Parameters.AddWithValue("@docIssuedDate", System.DateTime.Now.ToString("dd/MMM/yyyy"));
            sqlCmd.Parameters.AddWithValue("@docCatID", 1);


            sqlConn.Open();
            sqlCmd.ExecuteNonQuery();
            sqlConn.Close();

            jobOwnerCounter++;
        }
    }
    private void CheckandDeleteDistributionData(int DocID)
    {
        string sqlQuery = "SELECT documentID, docCatID, distributeID, contactID FROM  DocumentDistribution WHERE   (documentID IN (SELECT documentID FROM  DocumentDistribution AS Tmp  GROUP BY documentID, contactID HAVING   (COUNT(*) > 1) AND (contactID = DocumentDistribution.contactID) AND (documentID = " + DocID + ")))  ORDER BY documentID, docCatID, distributeID";
        DataTable dtDocumentDistribution = GetDataFromDB("DocumentDistribution", sqlQuery);

        if (dtDocumentDistribution.Rows.Count != 0)
            DeleteDistributionData(Convert.ToInt32(dtDocumentDistribution.Rows[0]["distributeID"]));
    }


    private void DeleteDistributionData(int documentID)
    {
        string updateSql = "Delete From DocumentDistribution Where distributeID = " + documentID + " ";
        using (SqlConnection sqlConn = new SqlConnection(connValue))
        {
            using (SqlCommand cmd = new SqlCommand())
            {
                cmd.CommandText = updateSql;
                cmd.Connection = sqlConn;

                try
                {
                    sqlConn.Open();
                    cmd.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    Response.Write(ex.Message);
                }
            }
        }
    }

    public DataTable GetDataFromDB(string dataTabName, string sqlQuery)
    {
        DataTable table = null;
        SqlConnection sqlConn = new SqlConnection(connValue);
        sqlConn.Open();
        SqlDataAdapter sqlDtAdptr = null;
        table = new DataTable(dataTabName);
        sqlDtAdptr = new SqlDataAdapter(@sqlQuery, sqlConn);
        sqlDtAdptr.Fill(table);
        sqlConn.Close();
        return table;
    }

    public void updateJobClosedDate_ReplyToClose(int jobID, string closedDate)
    {
        try
        {
            using (SqlConnection sqlConn = new SqlConnection(connValue))
            {
                string strUpdate = "Update Job Set jobClosedDate = @jobClosedDate,JobStatusID =@JobStatusID,closedDocRefID = @closedDocRefID where jobID = " + jobID + "";

                using (SqlCommand sqlCom = new SqlCommand())
                {
                    // sqlCom.CommandType = CommandType.StoredProcedure;
                    sqlCom.CommandType = CommandType.Text;

                    sqlCom.Connection = sqlConn;
                    sqlCom.CommandText = strUpdate;          //ReplyToCloseJob

                    sqlCom.Parameters.AddWithValue("@jobClosedDate", Convert.ToDateTime(closedDate).ToString("dd/MMM/yyyy"));
                    sqlCom.Parameters.AddWithValue("@JobStatusID", 1);   // Closed
                    sqlCom.Parameters.AddWithValue("@closedDocRefID", _docID);
                    sqlCom.Parameters.AddWithValue("@jobID", jobID);
                    sqlConn.Open();
                    sqlCom.ExecuteNonQuery();

                }
            }
        }
        catch (System.Exception ex)
        {
            throw ex;
        }
    }
    protected void btnDistribute_Click(object sender, EventArgs e)
    {
        if (lblDocID.Text != "")
            _docID = Convert.ToInt32(lblDocID.Text);

        //string url = "~/Documents/DistributionWindow.aspx";
        if (userRightsColl.Contains("27")) // Access Right is 4 
        {


            ClientScript.RegisterClientScriptBlock(this.GetType(), "Popup", "<script>alert('You have no privilege to Distribute to staff')</script>", false);
            //return;
        }
        else
        {
            Session["Dist_docID"] = _docID;
            string url = "DistributionWindow.aspx";
            string s = "window.open('" + url + "', 'popup_window', 'width=800,height=520,left=100,top=100,resizable=yes,scrollbars=yes');";
            ClientScript.RegisterStartupScript(this.GetType(), "script", s, true);
        }
    }
    private string getEndDateByGivenDays(string strDate, int workDays)
    {
        SqlConnection con = new SqlConnection(connValue);
        SqlCommand cmd = new SqlCommand();
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Connection = con;

        cmd.CommandText = "AddWorkdays";
        SqlParameter prm = cmd.Parameters.Add("@ad_startDate", SqlDbType.DateTime);
        prm.Value = strDate;
        prm = cmd.Parameters.Add("@actual_workDays", SqlDbType.Int);
        prm.Value = workDays;
        prm = cmd.Parameters.Add("@endDate", SqlDbType.DateTime);
        prm.Direction = ParameterDirection.Output;
        con.Open();
        SqlDataReader dr = cmd.ExecuteReader();
        while (dr.Read())
            Console.WriteLine(dr.GetString(0));
        con.Dispose();
        con.Close();

        return cmd.Parameters[2].Value.ToString();
    }
    protected void btnAddProjAttrib_Click(object sender, EventArgs e)
    {
        if (lblDocID.Text != "")
            _docID = Convert.ToInt32(lblDocID.Text);

        if (ddlContractNo.SelectedIndex != 0)
        {
            IList<string> projectInfoColl = new List<string>();
            projectInfoColl = new JobOrderData().FillDropDownSelectedContractValues(Convert.ToInt32(ddlContractNo.SelectedValue));
            InsertProjectAttributes(projectInfoColl, Convert.ToInt32(ddlContractNo.SelectedValue));
            gridloadForProjectAttributeData();
            ddlContractNo.SelectedIndex = 0;
        }
        else if (ddlTenderNo.SelectedIndex != 0)
        {
            IList<string> projectInfoColl = new List<string>();
            projectInfoColl = new JobOrderData().FillDropDownSelectedValues(Convert.ToInt32(ddlTenderNo.SelectedValue));
            InsertProjectAttributes(projectInfoColl, Convert.ToInt32(ddlTenderNo.SelectedValue));
            gridloadForProjectAttributeData();
            ddlTenderNo.SelectedIndex = 0;
        }
        else if (ddlProjectID.SelectedIndex != 0)
        {
            IList<string> projectInfoColl = new List<string>();
            projectInfoColl = new JobOrderData().FillDropDownSelectedValues(Convert.ToInt32(ddlProjectID.SelectedValue));
            InsertProjectAttributes(projectInfoColl, Convert.ToInt32(ddlProjectID.SelectedValue));
            gridloadForProjectAttributeData();
            ddlProjectID.SelectedIndex = 0;
        }
    }
    private void InsertProjectAttributes(IList<string> prjDataColl, int prjID)
    {
        try
        {
            using (SqlConnection cn = new SqlConnection(connValue))
            {
                using (SqlCommand sqlCmd = new SqlCommand())
                {
                    sqlCmd.Connection = cn;
                    sqlCmd.CommandType = CommandType.StoredProcedure;
                    sqlCmd.CommandText = "InsertProjectAttributes";

                    sqlCmd.Parameters.AddWithValue("@docID", _docID);
                    sqlCmd.Parameters.AddWithValue("@prjID", prjID);
                    sqlCmd.Parameters.AddWithValue("@contractNo", prjDataColl[3].ToString());
                    sqlCmd.Parameters.AddWithValue("@projectCode", prjDataColl[1].ToString());
                    sqlCmd.Parameters.AddWithValue("@projectTitle", prjDataColl[4].ToString());
                    sqlCmd.Parameters.AddWithValue("@tenderNo", prjDataColl[2].ToString());

                    cn.Open();
                    sqlCmd.ExecuteNonQuery();
                }
            }
        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
    }



    protected void gvDocProjAttributes_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandArgument != "")
        {
            int attributeID = Convert.ToInt32(e.CommandArgument);
            switch (e.CommandName)
            {
                case "DeleteDocid":
                    new JobOrderData().DeleteAttributeData(attributeID);
                    gridloadForProjectAttributeData();
                    break;
            }
        }
    }

    Boolean chkDistributeID = false;
    protected void gvDistribution_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            DropDownList ddlStatus = (DropDownList)e.Row.FindControl("ddljobtype0");

            TextBox txtBoxRemarks = (TextBox)e.Row.FindControl("txtRemarks");

            PopulateDropDownBox(ddlStatus, "SELECT docStatusID,docStatusName as docStatusName FROM DocumentStatus", "docStatusID", "docStatusName", "");  // where JobStatusid in(5,6,7,8)

            //TextBox lm = (TextBox)e.Row.FindControl("jobid0");
            TextBox txtdocStatus = (TextBox)e.Row.FindControl("TextBox1");
            TextBox InchargeID = (TextBox)e.Row.FindControl("jobid0");

            Session["InchargeID"] = InchargeID.Text;


            ddlStatus.ToolTip = InchargeID.Text;

            ddlStatus.SelectedValue = txtdocStatus.Text;

            Session["StatusVal"] = ddlStatus.SelectedValue;

            ddlStatus.SelectedIndexChanged += new EventHandler(SelectedIndexChanged);

            // txtBoxRemarks.TextChanged += new EventHandler(TextChanged);

            //  txtBoxRemarks.ToolTip = InchargeID.Text;

            TextBox txtdate = (TextBox)e.Row.FindControl("lblJoindate");            // ActionDueDate 
            txtdate.ToolTip = InchargeID.Text;
            txtdate.TextChanged += new EventHandler(txtdate_TextChanged);
            Session["JobActionDueDate"] = txtdate.Text;

            Label lblDistribID = (Label)e.Row.FindControl("txtDistributeID");
            TextBox _txtContactID = (TextBox)e.Row.FindControl("txtContactID");
            LinkButton btnDelete = (LinkButton)e.Row.FindControl("btnDelete0");
            Label _lblDateofAction = (Label)e.Row.FindControl("lblDateofAction");

            if (!lblDistribID.Text.Equals(Session["userID"]))
                txtdate.Enabled = false;

            if (!_txtContactID.Text.Equals(Session["userID"]))
                ddlStatus.Enabled = false;

            if (txtdate.Text != "")
            {
                if ((Convert.ToDateTime(txtdate.Text) > System.DateTime.Now) & (_lblDateofAction.Text == "") & (ddlStatus.SelectedValue == "2"))
                {
                    // Update distributio docSttsu as open - 1
                    new JobOrderData().UpdateDocStatus(Convert.ToInt32(InchargeID.Text), Convert.ToInt32(ddlStatus.SelectedValue), _userName);
                }
                //if ((Convert.ToDateTime(txtdate.Text) < System.DateTime.Today) & (_lblDateofAction.Text == "") & (ddlStatus.SelectedValue == "2"))
                //{
                //    e.Row.Cells[4].BackColor = System.Drawing.Color.Red;
                //    e.Row.Cells[4].ForeColor = System.Drawing.Color.White;

                //    txtdate.ForeColor = System.Drawing.Color.White;
                //    txtdate.BackColor = System.Drawing.Color.Red;
                //}
            }



        }
    }
    protected void SelectedIndexChanged(object sender, EventArgs e)
    {
        DropDownList ddl = (DropDownList)sender;
        if (ddl.SelectedIndex != 0)
        {
            string ID = ddl.ID;
            string g = ddl.SelectedValue;
            int _distrID = Convert.ToInt32(ddl.ToolTip);

            new JobOrderData().UpdateDocStatus(_distrID, Convert.ToInt32(ddl.SelectedValue), _userName);
            //new JobOrderData().UpdateDistributionDateOfAction(_distrID, Convert.ToInt32(ddl.SelectedValue)); 
            fillDataDistribution(_docID);
        }
    }

    protected void TextChanged(object sender, EventArgs e)
    {
        TextBox txtBox = (TextBox)sender;
        if (txtBox.Text != "")
        {
            string gRemarks = txtBox.Text;
            int _distrID = Convert.ToInt32(txtBox.ToolTip);

            new JobOrderData().UpdateDocRemarks(_distrID, gRemarks, _userName);
            //new JobOrderData().UpdateDistributionDateOfAction(_distrID, Convert.ToInt32(ddl.SelectedValue)); 
            fillDataDistribution(_docID);
        }
    }

    int flag = 0;
    protected void gvDistribution_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandArgument != "")
        {
            int distributeID = Convert.ToInt32(e.CommandArgument);
            switch (e.CommandName)
            {
                case "DeleteDocid":
                    if (checkUserExist(distributeID, Convert.ToInt32(Session["docCreatedByID"]), Convert.ToInt32(Session["UserID"])))
                        AccessRightsForDelete(distributeID);

                    if (flag > 0)
                    {
                        //Response.Write("Link Deactivated with Job");
                    }
                    break;
            }
        }
    }
    private void AccessRightsForDelete(int distributeID)
    {
        if (userRightsColl.Contains("30"))   //Add New Project
        {
            Session["lblText"] = "You are not allowed to delete Distribution.Please contact system Administrator for further inquiry.";
            Session["lblSub"] = "Restricted Access to delete Distribution.";
            Session["lblBody"] = "This is in reference to Restricted Access to delete Distribution. I would like to inquire about the restriction.";


            string url = "RestrictedMsgWindow.aspx";
            string s = "window.open('" + url + "', 'popup_window', 'width=500,height=250,left=100,top=100,resizable=yes,scrollbars=yes');";
            ClientScript.RegisterStartupScript(this.GetType(), "script", s, true);
        }
        else
        {
            new JobOrderData().DeleteDistributionInfo(distributeID);
            fillDataDistribution(_docID);
        }
    }
    private Boolean checkUserExist(int distributeID, int createdBy, int currentUserID)
    {
        using (SqlConnection sqlConn = new SqlConnection(connValue))
        {
            sqlConn.Open();
            using (SqlCommand sqlCom = new SqlCommand())
            {
                // sqlCom.CommandType = CommandType.StoredProcedure;
                sqlCom.CommandType = CommandType.Text;
                sqlCom.Connection = sqlConn;
                sqlCom.CommandText = "Select contactID,issuedByContactID From DocumentDistribution where distributeID = " + distributeID;

                sqlCom.Parameters.AddWithValue("@docID", _docID);

                using (SqlDataReader sqlReader = sqlCom.ExecuteReader())
                {
                    while (sqlReader.Read())
                    {
                        if ((!sqlReader["contactID"].Equals(createdBy)) & (sqlReader["issuedByContactID"].Equals(currentUserID)))
                            return true;
                    }
                }
            }
        }
        return false;
    }

    protected void txtdate_TextChanged(object sender, EventArgs e)
    {
        TextBox tdate = (TextBox)sender;
        string actionDate = tdate.Text;
        int distID = Convert.ToInt32(tdate.ToolTip);
        // new JobOrderData().UpdateDistributionActionDueDate(Convert.ToInt32(distID), actionDate, getWorkDays(actionDate));

        UpdateDistributionActionDueDate(Convert.ToInt32(distID), actionDate, getWorkDays(actionDate));
        fillDataDistribution(_docID);
    }
    public void UpdateDistributionActionDueDate(int distID, string _actionDate, int workDays)
    {
        using (SqlConnection sqlConn = new SqlConnection(connValue))
        {
            sqlConn.Open();
            using (SqlCommand sqlCom = new SqlCommand())
            {
                sqlCom.CommandType = CommandType.Text;
                sqlCom.Connection = sqlConn;
                sqlCom.CommandText = "Update DocumentDistribution Set actionDueDate= @actionDueDate,daysToReply = @daysToReply Where distributeID= " + distID + "";

                sqlCom.Parameters.AddWithValue("@actionDueDate", Convert.ToDateTime(_actionDate).ToString("dd/MMM/yyyy"));
                sqlCom.Parameters.AddWithValue("@daysToReply", workDays);
                sqlCom.Parameters.AddWithValue("@distributeID", distID);

                sqlCom.ExecuteNonQuery();

            }
        }
    }
    public DataTable fillDataDistribution(int _docID)
    {
        DataTable dt = new DataTable();
        try
        {
            DataSet dsMain = new DataSet();
            int x;
            x = 0;

            dsMain = (new JobOrderData().FillDocDistributeData(_docID));
            dt = dsMain.Tables[0];

        }
        catch (Exception ex)
        {

        }

        return dt;
    }
    private int getWorkDays(string actionDate)
    {
        int _workDays = 0;
        DateTime dateEnd = System.DateTime.Now;
        dateEnd = ConvertToDateTime(actionDate);
        return _workDays = Convert.ToInt32(getDaysByGivenEndDate(System.DateTime.Now.ToString(), dateEnd));
    }
    private string getDaysByGivenEndDate(string strDate, DateTime endDate)
    {
        strDate = Convert.ToDateTime(strDate).ToString("MM/dd/yyyy", CultureInfo.InvariantCulture);


        DateTime strDt = DateTime.ParseExact(strDate, "MM/dd/yyyy", CultureInfo.InvariantCulture);
        //DateTime endDt = DateTime.ParseExact(endDate, "MM/dd/yyyy", CultureInfo.InvariantCulture);

        SqlConnection con = new SqlConnection(connValue);
        SqlCommand cmd = new SqlCommand();

        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Connection = con;

        cmd.CommandText = "testSP";

        SqlParameter prm = cmd.Parameters.Add("@ad_startDate", SqlDbType.DateTime);
        prm.Value = strDt;

        prm = cmd.Parameters.Add("@ad_endDate", SqlDbType.DateTime);
        prm.Value = endDate;

        prm = cmd.Parameters.Add("@ai_workDays", SqlDbType.Int);
        prm.Direction = ParameterDirection.Output;



        con.Open();
        SqlDataReader dr = cmd.ExecuteReader();
        while (dr.Read())
            Console.WriteLine(dr.GetString(0));
        con.Dispose();
        con.Close();

        return cmd.Parameters[2].Value.ToString();
    }
    private DateTime ConvertToDateTime(string strDateTime)
    {
        DateTime dtFinaldate; string sDateTime;
        try
        {
            //dtFinaldate = Convert.ToDateTime(strDateTime); 

            string[] sDate = strDateTime.Split('/');
            sDateTime = sDate[1] + '/' + sDate[0] + '/' + sDate[2];
            dtFinaldate = Convert.ToDateTime(sDateTime);
        }
        catch (Exception e)
        {
            string[] sDate = strDateTime.Split('/');
            sDateTime = sDate[0] + '/' + sDate[1] + '/' + sDate[2];
            dtFinaldate = Convert.ToDateTime(sDateTime);
        }
        return dtFinaldate;
    }
    protected void gvDBS_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandArgument != "")
        {
            int attributeID = Convert.ToInt32(e.CommandArgument);
            switch (e.CommandName)
            {
                case "DeleteDocid":
                    new JobOrderData().DeleteDBSData(attributeID);
                    gridloadForDBSValues();
                    break;
            }
        }
    }
    private Boolean checkOpenCloseDocumentInJob(int _docID)
    {
        SqlConnection sqlConn = new SqlConnection(connValue);
        SqlCommand sqlCom = new SqlCommand();

        try
        {
            sqlConn.Open();
            string strValue = "SELECT  docRefID, closedDocRefID FROM Job WHERE (docRefID =" + _docID + " ) OR  (closedDocRefID = " + _docID + ")";
            sqlCom = new SqlCommand(strValue, sqlConn);
            SqlDataReader sqlReader = sqlCom.ExecuteReader();
            if (sqlReader.HasRows)
            {
                return true;
            }
            sqlReader.Close();
            sqlConn.Close();


        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            sqlConn.Close();
        }
        return false;
    }
    public void fillDocumentData(int _docID)
    {
        try
        {
            SqlConnection sqlConn = new SqlConnection(connValue);
            sqlConn.Open();


            string strValue = "SELECT  [Document].documentID, [Document].docCatID, [Document].docTypeID, [Document].docStatusID, [Document].referenceNo, [Document].crossReferenceNo,  " +
                        " [Document].docSubject, replace(convert(NVARCHAR, [Document].docDate, 106), ' ', '/') AS docDate, [Document].docContent, [Document].importance, " +
                        " [Document].superseded, [Document].originContactID, [Document].originCompanyID, REPLACE(CONVERT(NVARCHAR, [Document].docReceivedDate, 106), ' ', '/') " +
                        " AS docReceivedDate, [Document].docCreatedByID, [Document].jobID, [Document].paymentID,Contact.firstName + '  ' + Contact.lastName AS DocCreatedBy, Contact.contactID,[Document].prjCoordID " +
                       " FROM  [Document] INNER JOIN   Contact ON [Document].docCreatedByID = Contact.contactID WHERE  ([Document].documentID = " + _docID + ")";

            SqlCommand sqlCom = new SqlCommand(strValue, sqlConn);
            SqlDataReader sqlReader = sqlCom.ExecuteReader();

            while (sqlReader.Read())
            {
                txtDocRefNo.Text = sqlReader["referenceNo"].ToString();
                txtDocDescription.Text = sqlReader["docContent"].ToString();
                txtDocSubject.Text = sqlReader["docSubject"].ToString();
                txtPopupDatepicker.Text = sqlReader["docDate"].ToString();

                //  importance,superseded,originContactID,originCompanyID,docReceivedDate

                ddlCompany.SelectedValue = sqlReader["originCompanyID"].ToString();
                txtRplyDoc.Text = sqlReader["crossReferenceNo"].ToString();
                ddlOriginSender.SelectedValue = sqlReader["originContactID"].ToString();

                Session["originContactID"] = sqlReader["originContactID"].ToString();


                txtDateReceived.Text = sqlReader["docReceivedDate"].ToString();
                ddlTypeOfDocs.SelectedValue = sqlReader["docTypeID"].ToString();

                //lblDocID.Text = sqlReader["documentID"].ToString();

                lblDocCatID.Text = sqlReader["docCatID"].ToString();

                lblJobID.Text = sqlReader["jobID"].ToString();

                lblPayID.Text = sqlReader["paymentID"].ToString();

                lblDocCreatedBy.Text = sqlReader["docCreatedByID"].ToString();

                Session["docCreatedByID"] = sqlReader["docCreatedByID"].ToString();



                if (sqlReader["originContactID"].Equals(sqlReader["docCreatedByID"]))
                    ddlOriginSender.Enabled = false;
                if (sqlReader["docCatID"].Equals("2"))
                    txtDateReceived.Enabled = false;

                if (!_currentUserID.Equals(sqlReader["docCreatedByID"]))
                {
                    if (!Session["UserProfileID"].Equals("1"))
                    {
                        if (userRightsColl.Contains("28"))
                        {
                            btnCreateDoc.Enabled = false;
                        }
                        if (userRightsColl.Contains("29"))
                        {
                            btnDelete.Enabled = false;
                            btnDelete.BackColor = System.Drawing.Color.WhiteSmoke;
                        }
                    }
                }
                if (_profileID.Equals(1) || sqlReader["originContactID"].Equals(_currentUserID) || sqlReader["docCreatedByID"].Equals(_currentUserID))
                {
                    // tdSuper.Visible = true;
                    EnableControlsStatusForNonDistribution();
                    btnDelete.Enabled = true;

                }
                else
                {
                    // tdSuper.Visible = false;
                    DisableControlsStatusForNonDistribution();
                    btnDelete.Enabled = false;
                    btnDelete.BackColor = System.Drawing.Color.WhiteSmoke;

                }

                lblCreatedByName.Text = "Document Created By : - " + sqlReader["DocCreatedBy"].ToString();


                if (sqlReader["prjCoordID"].ToString() != "")
                    ddlPrjCoordinator.SelectedValue = sqlReader["prjCoordID"].ToString();
            }
            sqlReader.Close();
            sqlConn.Close();
        }
        catch (Exception ex)
        {
            throw ex;
        }

        Session["orginName"] = ddlOriginSender.SelectedItem.Text;
        Session["DocRefNo"] = txtDocRefNo.Text;
    }
    private ArrayList getCurrentDocumentData(int _docID)
    {
        ArrayList docCollLList = new ArrayList();
        using (SqlConnection sqlConn = new SqlConnection(connValue))
        {
            sqlConn.Open();
            using (SqlCommand sqlCom = new SqlCommand())
            {
                sqlCom.CommandType = CommandType.StoredProcedure;
                sqlCom.Connection = sqlConn;
                sqlCom.CommandText = "GetDocumentData";

                sqlCom.Parameters.AddWithValue("@docID", _docID);

                using (SqlDataReader sqlReader = sqlCom.ExecuteReader())
                {
                    while (sqlReader.Read())
                    {
                        object[] values = new object[sqlReader.FieldCount];
                        sqlReader.GetValues(values);
                        docCollLList.Add(values);
                    }
                }
            }
        }
        return docCollLList;
    }
    protected void btnDelete_Click(object sender, EventArgs e)
    {
        if (_profileID.Equals(1))
        {
            new JobOrderData().DeleteMainDocument(_docID);
        }
        else if (userRightsColl.Contains("29") & (!Session["originContactID"].Equals(_currentUserID.ToString())))
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "Popup", "<script>alert('You have no privilege to Delete this document')</script>", false);
            return;
        }
        else if (Session["docCreatedByID"].Equals(_currentUserID.ToString()) || Session["originContactID"].Equals(_currentUserID.ToString()))
            new JobOrderData().DeleteMainDocument(_docID);

        lblDocID.Text = "";

        if (Session["UrlRef"] != null)
            Response.Redirect(Session["UrlRef"].ToString(), false);
        else
            Response.Redirect("~/Documents/ReceiveSentDocuments.aspx", false);
    }
    public Boolean CheckOpenClosedDocExistForJob(int jobID)
    {
        using (SqlConnection sqlConn = new SqlConnection(connValue))
        {
            sqlConn.Open();
            string strValue = "SELECT  jobID, docRefID, closedDocRefID FROM Job  WHERE (jobID = " + jobID + ") AND (docRefID = " + _docID + ") OR   (jobID = " + jobID + ") AND (closedDocRefID = " + _docID + ")";

            using (SqlCommand sqlCom = new SqlCommand(strValue, sqlConn))
            {
                using (SqlDataReader sqlReader = sqlCom.ExecuteReader())
                {
                    while (sqlReader.Read())
                    {
                        return true;
                    }
                }
            }
        }
        return false;
    }
    protected void btnSave_Click(object sender, EventArgs e)
    {


    }


    private int getOrginContactID(int _docID)
    {
        int orginID = 0;
        SqlConnection sqlConn = new SqlConnection(connValue);
        sqlConn.Open();

        string strValue = "SELECT originContactID From Document WHERE (documentID = " + _docID + ")";

        SqlCommand sqlCom = new SqlCommand(strValue, sqlConn);
        SqlDataReader sqlReader = sqlCom.ExecuteReader();

        while (sqlReader.Read())
        {
            orginID = Convert.ToInt32(sqlReader["originContactID"]);
        }
        sqlReader.Close();
        sqlConn.Close();

        return orginID;
    }
    private void OpenPageByUsingJS(string url, string width, string height)
    {
        string s = "window.open('" + url + "', 'popup_window', 'width=" + width + ",height=" + height + "left=100,top=100,resizable=yes');";
        Page.ClientScript.RegisterStartupScript(this.GetType(), "script", s, true);
    }
    static Boolean isdocRefChanged = false;
    protected void txtDocRefNo_TextChanged(object sender, EventArgs e)
    {
        //// isdocRefChanged = true;

        if (checkDocExist())
        {

            lblRefNo.Text = "Reference No Exist";

            txtDocRefNo.BackColor = System.Drawing.Color.Pink;
            lblRefNo.ForeColor = System.Drawing.Color.Red;

            txtDocRefNo.Text = txtDocRefNo.Text + " - Copy";
            txtDocRefNo.Focus();


        }
        else
        {
            lblRefNo.Text = "Document Reference No.";
            txtDocRefNo.BackColor = System.Drawing.Color.White;

            txtDocSubject.Focus();
        }
    }
    private Boolean checkDocExist()
    {
        string prjTitle = string.Empty;

        using (SqlConnection cnn = new SqlConnection(connValue))
        {
            cnn.Open();
            using (SqlCommand cmm = new SqlCommand())
            {
                cmm.Connection = cnn;
                cmm.CommandText = "SELECT referenceNo  FROM Document WHERE referenceNo = '" + txtDocRefNo.Text.Trim() + "' ";
                using (SqlDataReader sqlDtReader = cmm.ExecuteReader())
                {
                    if (sqlDtReader.HasRows)
                    {
                        return true;
                    }
                }
            }
        }

        return false;
    }

    protected void btnAddDbs_Click(object sender, EventArgs e)
    {
        if (lblDocID.Text != "")
            _docID = Convert.ToInt32(lblDocID.Text);


        gridloadForDBSValues();
    }

    protected void lnkJobNo_Click2(object sender, EventArgs e)
    {
        string strUpdateJob = Request.Url.AbsoluteUri;
        try
        {
            LinkButton lnkJobID = (LinkButton)sender;

            Session["JobID"] = lnkJobID.ToolTip;
            Session["JobCatID"] = txtCatID.Value;

            if (txtCatID.Value.Equals("1"))
            {

                Session["UrlRef"] = "~/JobOrder/PSAJobDetails.aspx";
                Response.Redirect("~/JobOrder/PSAJobDetails.aspx?JobID= " + Session["JobID"] + "", false);
            }
            else if (txtCatID.Value.Equals("2"))
            {

                Session["UrlRef"] = strUpdateJob;
                Response.Redirect("~/Payments/PaymentDetails.aspx?PayID= " + Session["JobID"] + "", false);
            }
            else if (txtCatID.Value.Equals("8"))
            {
                Session["UrlRef"] = "~/DCLog/DCDetails.aspx";
                Response.Redirect("~/DCLog/DCDetails.aspx?JobID= " + Session["JobID"] + "", false);
            }
            else
            {
                Session["UrlRef"] = "~/JobOrder/DefaultGrid.aspx";
                Response.Redirect("~/JobOrder/DefaultGrid.aspx?JobID= " + Session["JobID"] + "", false);
            }
        }
        catch (Exception ex)
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Error occurred while processing the request')</script>", false);
        }
    }

    #region FileAttchment Functions


    protected void lnkFile_Click(object sender, EventArgs e)
    {
        if (lblDocID.Text != "")
            _docID = Convert.ToInt32(lblDocID.Text);

        if ((Session["File_docID"] == null) || (Session["File_docID"] == "0") || _docID != 0)
            Session["File_docID"] = _docID;

        //else
        //    return;

        Session["fileType"] = "";
        Session["fileType"] = "F";

        string url = "/eBook/FileUpload.aspx";
        string s = "window.open('" + url + "', 'popup_window', 'width=640,height=520,left=100,top=100,resizable=yes,scrollbars=yes');";
        ClientScript.RegisterStartupScript(this.GetType(), "script", s, true);

    }
    protected void lnkAttachments_Click(object sender, EventArgs e)
    {
        if (lblDocID.Text != "")
            _docID = Convert.ToInt32(lblDocID.Text);

        if ((Session["File_docID"] == null) || (Session["File_docID"] == "0") || _docID != 0)
            Session["File_docID"] = _docID;

        Session["fileType"] = "";
        Session["fileType"] = "A";


        Session["lblCatID"] = lblDocCatID.Text;

        string strUpdateJob = Request.Url.AbsoluteUri;
        Session["UrlRef"] = strUpdateJob;
        Response.Redirect("~/Documents/UploadFiles.aspx", false);

    }
    protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
    {
        if (lblDocID.Text != "")
            _docID = Convert.ToInt32(lblDocID.Text);

        if ((Session["File_docID"] == null) || (Session["File_docID"] == "0") || _docID != 0)
            Session["File_docID"] = _docID;

        Session["fileType"] = "";
        Session["fileType"] = "F";


        string url = "/eBook/FileUpload.aspx";
        string s = "window.open('" + url + "', 'popup_window', 'width=810,height=520,left=100,top=100,resizable=yes,scrollbars=yes');";
        ClientScript.RegisterStartupScript(this.GetType(), "script", s, true);

        // Response.Redirect("~/DocumetAttachments.aspx", false);
    }
    protected void ImageButton2_Click(object sender, ImageClickEventArgs e)
    {
        if (lblDocID.Text != "")
            _docID = Convert.ToInt32(lblDocID.Text);

        if ((Session["File_docID"] == null) || (Session["File_docID"] == "0") || _docID != 0)
            Session["File_docID"] = _docID;

        Session["fileType"] = "";
        Session["fileType"] = "A";


        string url = "/eBook/FileUpload.aspx";
        string s = "window.open('" + url + "', 'popup_window', 'width=810,height=520,left=100,top=100,resizable=yes,scrollbars=yes');";
        ClientScript.RegisterStartupScript(this.GetType(), "script", s, true);


    }

    #endregion


    #region Not Using Functions


    // ----------------------------------------------------- Not Using -- ------------------------------------------------------------------------------------------------------------------------------------------------------

    public void docReferenceChangeLog(string changeDesc, string windowName, string NewprjCode, string oldPrjCode)
    {
        if (ddlOriginSender.SelectedIndex != 0)
        {
            string upDateQuery = "INSERT INTO CHANGELOG(ChangeData,windowName,oldData,newData,updateUser) VALUES('" + changeDesc + "','" + windowName + "','" + NewprjCode + "','" + oldPrjCode + "', '" + Session["UserDisplayName"].ToString() + "')";
            using (SqlConnection sqlCon = new SqlConnection(connValue))
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.CommandText = upDateQuery;
                    cmd.Connection = sqlCon;
                    try
                    {
                        sqlCon.Open();
                        cmd.ExecuteNonQuery();
                    }
                    catch (Exception ex)
                    {
                        Response.Write(ex.Message);
                    }
                }
            }
        }
    }
    private void getData()
    {
        if (!IsPostBack)
        {
            using (SqlConnection scon = new SqlConnection(connValue))
            {
                using (SqlCommand scmd = new SqlCommand())
                {
                    string strQuery = "SELECT JobOwner.jobNo, JobStatus.jobStatusName, Section.sectionName, JobType.jobTypeName " +
                                " FROM   JobOwner INNER JOIN  JobStatus ON JobOwner.jobOwnerStatusID = JobStatus.jobStatusID INNER JOIN " +
                      " Section ON JobOwner.sectionID = Section.sectionID INNER JOIN JobType ON JobOwner.jobOwnerCatID = JobType.jobTypeID FULL OUTER JOIN " +
            " DocumentDistribution ON JobOwner.jobOwnerID = DocumentDistribution.jobOwnerID";

                    scmd.Connection = scon;
                    scmd.CommandType = CommandType.Text;
                    scmd.CommandText = strQuery;
                    scon.Open();
                    SqlDataReader articleReader = scmd.ExecuteReader();

                    StringBuilder htmlTable = new StringBuilder();

                    htmlTable.Append("<table border='1'>");
                    htmlTable.Append("<tr><th>jobNo.</th><th>jobStatusName</th><th>sectionName</th><th>jobTypeName</th></tr>");

                    if (articleReader.HasRows)
                    {
                        while (articleReader.Read())
                        {
                            htmlTable.Append("<tr>");
                            htmlTable.Append("<td>" + articleReader["jobNo"] + "</td>");
                            htmlTable.Append("<td>" + articleReader["jobStatusName"] + "</td>");
                            htmlTable.Append("<td>" + articleReader["sectionName"] + "</td>");
                            htmlTable.Append("<td>" + articleReader["jobTypeName"] + "</td>");
                            htmlTable.Append("</tr>");
                        }
                        htmlTable.Append("</table>");

                        // PlaceHolder1.Controls.Add(new Literal { Text = htmlTable.ToString() });

                        articleReader.Close();
                        articleReader.Dispose();
                    }
                }
            }
        }
    }
    private void updateDocument(int _docid)
    {
        Boolean chkDataUpd = false;

        SqlConnection cn = new SqlConnection(connValue);
        SqlCommand sqlCmd = new SqlCommand();
        sqlCmd.CommandType = CommandType.StoredProcedure;
        sqlCmd.CommandText = "UpdateDocument";
        sqlCmd.Connection = cn;

        sqlCmd.Parameters.AddWithValue("@docDate", Convert.ToDateTime(txtPopupDatepicker.Text).ToString("dd/MMM/yyyy"));
        sqlCmd.Parameters.AddWithValue("@docTypeID", ddlTypeOfDocs.SelectedValue);
        sqlCmd.Parameters.AddWithValue("@originID", ddlOriginSender.SelectedValue);
        sqlCmd.Parameters.AddWithValue("@originCoID", ddlCompany.SelectedValue);
        sqlCmd.Parameters.AddWithValue("@referenceNo", txtDocRefNo.Text);
        sqlCmd.Parameters.AddWithValue("@docReceivedDate", Convert.ToDateTime(txtDateReceived.Text).ToString("dd/MMM/yyyy"));

        if (txtRplyDoc.Text != "")
            sqlCmd.Parameters.AddWithValue("@crossReferenceNo", txtRplyDoc.Text);
        else
            sqlCmd.Parameters.AddWithValue("@crossReferenceNo", System.DBNull.Value);

        sqlCmd.Parameters.AddWithValue("@docSubject", txtDocSubject.Text);
        sqlCmd.Parameters.AddWithValue("@docContent", txtDocDescription.Text);

        sqlCmd.Parameters.AddWithValue("@docCatID", lblDocCatID.Text);
        sqlCmd.Parameters.AddWithValue("@docCreatedByID", Session["UserID"].ToString());

        sqlCmd.Parameters.AddWithValue("@updateUser", Session["UserName"].ToString());
        sqlCmd.Parameters.AddWithValue("@updateDate ", System.DBNull.Value);    // DateTime.ParseExact(DateTime.Now.ToString("dd/MMM/yyyy HH:mm:ss"), "dd/MMM/yyyy HH:mm:ss", CultureInfo.InvariantCulture)

        sqlCmd.Parameters.AddWithValue("@docID", _docID);
        sqlCmd.Parameters.AddWithValue("@isImportance", chkDataUpd);
        sqlCmd.Parameters.AddWithValue("@isSuperseded", chkDataUpd);


        try
        {
            cn.Open();
            sqlCmd.ExecuteNonQuery();
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            cn.Close();
        }
    }

    // ----------------------------------------------------- Not Using -- ------------------------------------------------------------------------------------------------------------------------------------------------------

    #endregion
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        lblDocID.Text = "";

        //if (Session["UrlRef"] != null)
        //  Response.Redirect(Session["UrlRef"].ToString(), false);
        //else 
        //  Response.Redirect("~/Documents/ReceiveSentDocuments.aspx", false);

        if (Session["UrlRef"] != null)
            Response.Redirect(Session["UrlRef"].ToString(), false);
        else if ((Session["CmpID"].ToString() != "362"))
            Response.Redirect("~/JobOrder/DefaultWindow.aspx", false);
        else if (Session["SectionID"].Equals("4"))
            Response.Redirect("~/JobOrder/SurveyDefaultWindow.aspx", false);
        else
            Response.Redirect("~/Documents/ReceiveSentDocuments.aspx", false);

        Session["docSender"] = null;
    }
    protected void btnCreateDoc_Click(object sender, EventArgs e)
    {
        // string strUpdateJob = Request.Url.AbsoluteUri;
        // Session["UrlRef"] = strUpdateJob;

        if (lblDocID.Text != "")
        {
            _docID = Convert.ToInt32(lblDocID.Text);
        }

        if (_docID != 0)
        {
            if (getOrginContactID(_docID) != Convert.ToInt32(ddlOriginSender.SelectedValue))
            {
                UpdateDistributionOrginForIssuedBy(Convert.ToInt32(ddlOriginSender.SelectedValue), Convert.ToInt32(Session["originContactID"].ToString()));
                UpdateDistributionOrginForDistributedTo(Convert.ToInt32(ddlOriginSender.SelectedValue), Convert.ToInt32(Session["originContactID"].ToString()));
            }

            if (_profileID.Equals(1) || Session["docCreatedByID"].Equals(_currentUserID.ToString()) || Session["originContactID"].Equals(_currentUserID.ToString()))
                saveDocument();
            else if (!userRightsColl.Contains("28") & dtDistrUserExist.Rows.Count > 0)  //Check Current user partofDistribution Data
                saveDocument();

            if (ddlPrjCoordinator.SelectedIndex != 0)
            {
                string _eMail = getEmail(ddlPrjCoordinator.SelectedValue);
                // OutLookAlertQuick(_eMail, "");
            }

        }
        else
        {
            saveDocument();
            trDocCreated.Visible = true;
            trDocCreated.Visible = true;
            lnkAttachments.Enabled = true;
            lnkFile.Enabled = true;

            ImageButton1.Enabled = true;
            ImageButton2.Enabled = true;

            btnCreateDoc.Text = "Update Document";

            if (ddlPrjCoordinator.SelectedIndex != 0)
            {
                string _eMail = getEmail(ddlPrjCoordinator.SelectedValue);
                // OutLookAlertQuick(_eMail, "");    
            }

        }

        btnAddProjAttrib.Enabled = true;
        btnSubmit.Visible = true;

        btnCreateDoc.Enabled = false;


    }
    protected void txtDocSubject_TextChanged(object sender, EventArgs e)
    {

    }

    protected void LinkButton3_Click(object sender, EventArgs e)
    {
        string url = "file://ebsd-vpuchnanda/Doc_In/C2010-87/13384";

        string s = "window.open('" + url + "', 'popup_window', 'width=640,height=520,left=100,top=100,resizable=yes,scrollbars=yes');";
        ClientScript.RegisterStartupScript(this.GetType(), "script", s, true);

        return;

        Session["Path"] = LinkButton3.Text;
        Response.Redirect("~/Documents/OpenFilePath123.aspx", false);
    }
    private IList<string> getJobNO(int docID)
    {


        IList<string> strColl = new List<string>();
        using (SqlConnection cnn = new SqlConnection(connValue))
        {
            cnn.Open();
            using (SqlCommand cmm = new SqlCommand())
            {
                cmm.Connection = cnn;
                cmm.CommandText = "SELECT contractNo,JobNo  FROM Job WHERE docRefID = " + docID + " ";
                using (SqlDataReader sqlDtReader = cmm.ExecuteReader())
                {
                    if (sqlDtReader.HasRows)
                    {
                        while (sqlDtReader.Read())
                        {
                            strColl.Add(sqlDtReader["contractNo"].ToString());
                            strColl.Add(sqlDtReader["JobNo"].ToString());
                        }
                    }
                }
            }
        }

        return strColl;
    }

    protected void txtDocRefNo_Unload(object sender, EventArgs e)
    {
        LinkButton3.Text = "Link_Not_Found Now";
    }


    #endregion
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        if (gvDocProjAttributes.Rows.Count > 0)
            btnSubmit.Visible = false;
        else
            ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Please add above project details')</script>", false);
    }









    #region MyRegion

    private void SendCompletedCallback(SmtpClient smtpclient, System.Net.Mail.MailMessage mail) //private static void SendCompletedCallback(object sender, AsyncCompletedEventArgs e
    {
        try
        {
            smtpclient.Send(mail);
        }
        catch (Exception ex)
        {
            Console.WriteLine(ex);
            if (ex.InnerException != null)
            {
                Console.WriteLine("InnerException is: {0}", ex.InnerException);
            }
        }
        //finally
        //{
        //    mail.Dispose();
        //    mail = null;
        //    // smtpclient = null;
        //}
    }

    private void OutLookAlertQuick(string eMail, string mailBody)
    {
        //Session["jobNo"] = txtDocRefNo.Text;

        SmtpClient smtpclient = new SmtpClient("10.250.50.201", 587);
        System.Net.Mail.MailMessage mail = new System.Net.Mail.MailMessage();
        MailAddress fromaddress = new MailAddress("EBSD@ashghal.gov.qa");
        mail.From = fromaddress;
        mail.To.Add(eMail);
        mail.Subject = ("eBook Document Reference No. " + txtDocRefNo.Text);
        mail.IsBodyHtml = true;

        // mail.Body = "Please be informed that a new Job Order was assigned to you under the above subject. Please log on to eBook Application to see the details of the Job Order.";

        mail.Body = "<html><body><i style='font-family:Calibri; font-size:15'>Dear eBook Team,</i><br/><br/><i style='font-family:Calibri; font-size:15'>This is an automated alert from Document & Task Management System.</i><br/><br/><i style='font-family:Calibri;font-size:15'>" +
                            "Please be noted that</i><i style='color:Maroon;font-family:Calibri; font-size:15'> Document Reference No. " + txtDocRefNo.Text + "</i><i style='font-family:Calibri; font-size:15'> a new Document Reference NO. was created and the details are as follows:-</i><br /><br />" +
                            "<table style='width:80%' border='1'><tr><td align='center' colspan='2' style='background-color:Maroon;color:White;font-family:Calibri;font-size:18;font-weight:bold'>Reference NO: " + txtDocRefNo.Text + "</td>" +
                            "</tr><tr><td style='background-color:#B58AA5;font-family:Calibri;font-size:15'><i> Document Subject </i></td><td style='font-family:Calibri;font-size:15'>" + txtDocSubject.Text + "</td></tr>" +
                            "<tr><td style='background-color:#B58AA5;font-family:Calibri;font-size:15'><i>eBook URL</i></td><td style='font-family:Calibri;font-size:15'>   http://mv2ebdbookp01/eBook/LoginPage.aspx   </td></tr>" +
                            "<tr><td style='background-color:#B58AA5;font-family:Calibri;font-size:15'><i>Date of Creation</i></td><td style='font-family:Calibri;font-size:15'>" + System.DateTime.Now + "</td></tr>" +
                            "<tr><td style='background-color:#B58AA5;font-family:Calibri;font-size:15'><i>Created By</i></td><td style='font-family:Calibri;font-size:15'>" + Session["UserDisplayName"].ToString() + "</td></tr>" +
                            "</table><br/><br/><div style='font-family:Calibri; font-size:15'>Best Regards,<br/>eBook Team</div></body></html>";


        smtpclient.EnableSsl = true;
        smtpclient.UseDefaultCredentials = true;

        try
        {
            smtpclient.Credentials = new System.Net.NetworkCredential(@"Ashghal\EBSD", ConfigurationManager.AppSettings["passWordForReport"].ToString()); //i
            ServicePointManager.ServerCertificateValidationCallback = delegate(object s, X509Certificate certificate, X509Chain chain, SslPolicyErrors sslPolicyErrors) { return true; };

            // Added code for qucik mail

            SendEmail myAction = new SendEmail(SendCompletedCallback);
            myAction.BeginInvoke(smtpclient, mail, null, null);
        }
        catch (System.Exception ex)
        {
            Console.WriteLine(ex);
            if (ex.InnerException != null)
            {
                Console.WriteLine("InnerException is: {0}", ex.InnerException);
            }
        }
        //finally
        //{
        //    //mail.Dispose();
        //    //mail = null;
        //    //// smtpclient = null;
        //}

    }

    private delegate void SendEmail(SmtpClient smtpclient, System.Net.Mail.MailMessage mail);



    private string getEmail(string contactID)
    {
        string streMail = string.Empty;
        try
        {
            SqlConnection sqlConn = new SqlConnection(connValue);
            sqlConn.Open();
            SqlCommand sqlCom = new SqlCommand("Select emailAddress from Contact where ContactID = " + Convert.ToInt32(contactID) + "", sqlConn);
            SqlDataReader sqlReader = sqlCom.ExecuteReader();
            while (sqlReader.Read())
            {
                streMail = sqlReader["emailAddress"].ToString();
            }
            sqlReader.Close();
            sqlConn.Close();
        }
        catch (System.Exception ex)
        {
            throw ex;
        }

        return streMail;
    }

    #endregion

    public void FillDocRelatedTasks(int _docID, int currentUserID)
    {
        try
        {
            string qry = "SELECT DISTINCT  JobOwner.jobID,JobOwner.payID, JobOwner.jobNo, JobType_1.jobTypeName, Section.sectionName, JobStatus.jobStatusName, DocumentDistribution.documentID,   JobOwner.jobOwnerID, JobOwner.contactID, JobOwner.JobTypeID, JobType_1.CategoryID, JobOwner.sectionID " +
                       " FROM    JobOwner INNER JOIN   JobStatus ON JobOwner.jobOwnerStatusID = JobStatus.jobStatusID INNER JOIN   Section ON JobOwner.sectionID = Section.sectionID INNER JOIN  JobType ON JobOwner.JobTypeID = JobType.jobTypeID INNER JOIN " +
                   " JobType AS JobType_1 ON JobType.CategoryID = JobType_1.jobTypeID FULL OUTER JOIN  DocumentDistribution ON JobOwner.jobOwnerID = DocumentDistribution.jobOwnerID  WHERE (DocumentDistribution.documentID = " + _docID + ") AND (JobOwner.jobOwnerID IS NOT NULL)"; //AND (JobOwner.contactID = " + currentUserID + ")

            using (SqlConnection sqlConn = new SqlConnection(connValue))
            {
                sqlConn.Open();

                using (SqlCommand sqlCmd = new SqlCommand())
                {
                    sqlCmd.Connection = sqlConn;
                    sqlCmd.CommandText = qry;

                    using (SqlDataReader dr = sqlCmd.ExecuteReader())
                    {
                        while (dr.Read())
                        {
                            if (dr["jobNo"].ToString() != "")
                                lblDocJobNO.Text = dr["jobNo"].ToString();
                            else
                                trDocJobNo.Visible = false;
                        }
                    }
                }
            }
        }
        catch (Exception ex)
        {

        }
    }





    public void gridloadForDocDistributeData(int _docID)
    {
        DataSet ds = new DataSet();
        ds = (new JobOrderData().FillDocDistributeData(_docID));
        gvDistribution.DataSource = ds;
        gvDistribution.DataBind();
    }
}