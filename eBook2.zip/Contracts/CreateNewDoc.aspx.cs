﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Datalayer;
using System.Data.SqlClient;
using System.Data;
using System.Globalization;
using System.Configuration;
using System.Collections;
using System.IO;
using System.Text;
using System.Web.UI.HtmlControls;
using System.Net;
using System.Net.Mail;
using System.Security.Cryptography.X509Certificates;
using System.Net.Security;
public partial class Contracts_CreateNewDoc : System.Web.UI.Page
{
    string connValue = System.Configuration.ConfigurationManager.ConnectionStrings["EBSDEBookConn"].ConnectionString;
  
      
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["UserName"] == null)
        {
            Response.Redirect("~/LoginPage.aspx", false);
            return;
        }
        if (!IsPostBack)
         FillDropdownData();
    }
    private void FillDropdownData()
    {
        string selectName = string.Empty;

        //  dropdown index 0 should no as Select string for required feild validatior

        PopulateDropDownBox(ddlTypeOfDocs, "SELECT docTypeID, documentType FROM DocumentType ORDER BY documentType ", "docTypeID", "documentType", "");

        ddlTypeOfDocs.SelectedValue = "8"; // Internal memo

        PopulateDropDownBox(ddlOriginSender, "SELECT contactID, (firstName + ' ' + lastName) as OriginSender FROM  Contact  ORDER BY OriginSender ", "contactID", "OriginSender", ""); //WHERE (isActive = 1)

        PopulateDropDownBox(ddlCompany, "SELECT companyID, cmpName FROM  Company ORDER BY cmpName ", "companyID", "cmpName", "");

        PopulateDropDownBox(ddlPrjCoordinator, "Select ContactID, (firstName + ' ' + lastName) as PrjCoordinator From Contact where CompanyID in(366,367) order by PrjCoordinator", "ContactID", "PrjCoordinator", "");

    }
    private void PopulateDropDownBox(DropDownList ddlBox, string sqlQuery, string valueMember, string displayName, string selectName)
    {
        ddlBox.DataSource = new JobOrderData().FillDropdown(sqlQuery);
        ddlBox.DataTextField = displayName;
        ddlBox.DataValueField = valueMember;
        ddlBox.SelectedIndex = -1;
        ddlBox.DataBind();

        ListItem emptyItem = new ListItem(selectName, selectName);
        ddlBox.Items.Insert(0, emptyItem);
    }
    protected void btnNewPrj_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/Contracts/CreateNewDoc.aspx", false);
    }
    protected void btnSearch_Click(object sender, EventArgs e)
    {

    }
    protected void btnTndrNo_Click(object sender, EventArgs e)
    {

    }
    protected void btnClaimSearch_Click(object sender, EventArgs e)
    {

    }
    protected void lnkLogOutBtn_Click(object sender, EventArgs e)
    {

    }
    protected void ddlOriginSender_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
    {
        if (lblDocID.Text != "")
            _docID = Convert.ToInt32(lblDocID.Text);

        if ((Session["File_docID"] == null) || (Session["File_docID"] == "0") || _docID != 0)
            Session["File_docID"] = _docID;

        Session["fileType"] = "";
        Session["fileType"] = "F";


        string url = "/eBook/FileUpload.aspx";
        string s = "window.open('" + url + "', 'popup_window', 'width=810,height=520,left=100,top=100,resizable=yes,scrollbars=yes');";
        ClientScript.RegisterStartupScript(this.GetType(), "script", s, true);
    }
    protected void ImageButton2_Click(object sender, ImageClickEventArgs e)
    {
        if (lblDocID.Text != "")
            _docID = Convert.ToInt32(lblDocID.Text);

        if ((Session["File_docID"] == null) || (Session["File_docID"] == "0") || _docID != 0)
            Session["File_docID"] = _docID;

        Session["fileType"] = "";
        Session["fileType"] = "A";


        string url = "/eBook/FileUpload.aspx";
        string s = "window.open('" + url + "', 'popup_window', 'width=810,height=520,left=100,top=100,resizable=yes,scrollbars=yes');";
        ClientScript.RegisterStartupScript(this.GetType(), "script", s, true);

       
    }
    protected void btnCreateDoc_Click(object sender, EventArgs e)
    {
        if (lblDocID.Text != "")
        {
            _docID = Convert.ToInt32(lblDocID.Text);
        }

        if (_docID != 0)
        {
            saveDocument();
               

           

        }
        else
        {
            saveDocument();
           

            ImageButton1.Enabled = true;
            ImageButton2.Enabled = true;

            btnCreateDoc.Text = "Update Document";

           

        }
      

        btnCreateDoc.Enabled = false;
    }
    int _docID = 0;
    int _docCatID = 0;
    private void saveDocument()
    {
        _docID = Convert.ToInt32(CreateDocument());

        Session["docSender"] = null;

        Session["File_docID"] = _docID;

        if ((Session["JobID"] != null))        // Coming from Job Order /PSA 
        {
            if (ViewState["replyToClose"] != null)                             // (replyToClose != null)       // Clicked On Rec/Send Button for new Doc Creation
            {
               

                lblJobID.Text = Session["JobID"].ToString();
            }
            else
            {
               
            }
        }

        Session["JobID"] = null;   
        Session["PayID"] = null;

        lblDocID.Text = _docID.ToString();



     


    }

    private string CreateDocument()
    {
        Boolean chkData = false;
        using (SqlConnection cn = new SqlConnection(connValue))
        {
            using (SqlCommand sqlCmd = new SqlCommand())
            {
                try
                {
                    sqlCmd.CommandType = CommandType.StoredProcedure;
                    sqlCmd.CommandText = "sp_InsertDocument_NonEBD";
                    sqlCmd.Connection = cn;

                    // sqlCmd.Parameters.AddWithValue("@docDate", DateTime.ParseExact(txtPopupDatepicker.Text, "dd/MMM/yyyy", CultureInfo.InvariantCulture));

                    sqlCmd.Parameters.AddWithValue("@docDate", Convert.ToDateTime(txtDocDate.Text).ToString("dd/MMM/yyyy"));
                    sqlCmd.Parameters.AddWithValue("@docTypeID", ddlTypeOfDocs.SelectedValue);
                    sqlCmd.Parameters.AddWithValue("@originID", ddlOriginSender.SelectedValue);

                    Session["originContactID"] = ddlOriginSender.SelectedValue;

                    sqlCmd.Parameters.AddWithValue("@originCoID", ddlCompany.SelectedValue);
                    sqlCmd.Parameters.AddWithValue("@referenceNo", txtDocRefNo.Text);

                    sqlCmd.Parameters.AddWithValue("@docReceivedDate", Convert.ToDateTime(txtDocDate.Text).ToString("dd/MMM/yyyy"));

                    // sqlCmd.Parameters.AddWithValue("@docReceivedDate", DateTime.ParseExact(txtDateReceived.Text, "dd/MMM/yyyy", CultureInfo.InvariantCulture));
                   
                        sqlCmd.Parameters.AddWithValue("@crossReferenceNo", System.DBNull.Value);

                    sqlCmd.Parameters.AddWithValue("@docSubject", txtDocSubject.Text);
                    sqlCmd.Parameters.AddWithValue("@docContent", txtDocDescription.Text);

                    if ((ddlCompany.SelectedValue == "362") || (ddlCompany.SelectedValue == "2783"))
                    {
                        sqlCmd.Parameters.AddWithValue("@docCatID", 2);
                        _docCatID = 2;
                    }
                    else
                    {
                        sqlCmd.Parameters.AddWithValue("@docCatID", 1);
                        _docCatID = 1;
                    }

                    sqlCmd.Parameters.AddWithValue("@docCreatedByID", Session["UserID"].ToString());

                    Session["docCreatedByID"] = Session["UserID"].ToString();

                    sqlCmd.Parameters.AddWithValue("@createUser", Session["UserName"].ToString());

                    //sqlCmd.Parameters.AddWithValue("@createDate ", DateTime.ParseExact(DateTime.Now.ToString("dd/MMM/yyyy HH:mm:ss"), "dd/MMM/yyyy HH:mm:ss", CultureInfo.InvariantCulture));

                    if (_docID == 0)
                        sqlCmd.Parameters.AddWithValue("@docID", SqlDbType.SmallInt).Direction = ParameterDirection.Output;
                    else
                        sqlCmd.Parameters.AddWithValue("@docID", _docID);

                    string actionDueDate = getEndDateByGivenDays(txtDocDate.Text, 1);

                    sqlCmd.Parameters.AddWithValue("@actionDueDate", Convert.ToDateTime(actionDueDate).ToString("dd/MMM/yyyy"));

                    sqlCmd.Parameters.AddWithValue("@isImportance", chkData);
                    sqlCmd.Parameters.AddWithValue("@isSuperseded", chkData);

                    if (Session["JobID"] == null || Session["JobID"].ToString() == "")    // Reply to close validation for JobID
                        sqlCmd.Parameters.AddWithValue("@jobID", System.DBNull.Value);
                    else
                        sqlCmd.Parameters.AddWithValue("@jobID", Convert.ToInt32(Session["JobID"]));

                    // Newly added Parameter for Payment Module

                    if (Session["PayID"] == null)
                        sqlCmd.Parameters.AddWithValue("@payID", System.DBNull.Value);
                    else
                        sqlCmd.Parameters.AddWithValue("@payID", Convert.ToInt32(Session["PayID"]));


                    if (ddlPrjCoordinator.SelectedIndex == 0)
                        sqlCmd.Parameters.AddWithValue("@prjCoordID", System.DBNull.Value);
                    else
                        sqlCmd.Parameters.AddWithValue("@prjCoordID", Convert.ToInt32(ddlPrjCoordinator.SelectedValue));

                    cn.Open();
                    sqlCmd.ExecuteNonQuery();

                }
                catch (Exception ex)
                {
                    throw ex;
                }

                return sqlCmd.Parameters["@docID"].Value.ToString();
            }
        }
    }
    private string getEndDateByGivenDays(string strDate, int workDays)
    {
        SqlConnection con = new SqlConnection(connValue);
        SqlCommand cmd = new SqlCommand();
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Connection = con;

        cmd.CommandText = "AddWorkdays";
        SqlParameter prm = cmd.Parameters.Add("@ad_startDate", SqlDbType.DateTime);
        prm.Value = strDate;
        prm = cmd.Parameters.Add("@actual_workDays", SqlDbType.Int);
        prm.Value = workDays;
        prm = cmd.Parameters.Add("@endDate", SqlDbType.DateTime);
        prm.Direction = ParameterDirection.Output;
        con.Open();
        SqlDataReader dr = cmd.ExecuteReader();
        while (dr.Read())
            Console.WriteLine(dr.GetString(0));
        con.Dispose();
        con.Close();

        return cmd.Parameters[2].Value.ToString();
    }
    static Boolean isprjCodeChanged = false;
    protected void ddlOriginSender_SelectedIndexChanged1(object sender, EventArgs e)
    {
        int cmpID = 0;
        if (ddlOriginSender.SelectedIndex != 0)
        {
            cmpID = getCompanyID(Convert.ToInt32(ddlOriginSender.SelectedValue));

            ddlCompany.SelectedValue = cmpID.ToString();
        }


        if ((cmpID == 362) || (cmpID == 2783)) // From EBSD
            lblDocCatID.Text = "2";
        else
            lblDocCatID.Text = "1";


        isprjCodeChanged = true;

        txtDocRefNo.Focus();
    }
    private int getCompanyID(int _contactID)
    {
        int cmpID = 0;

        SqlConnection cnn = new SqlConnection(connValue);
        cnn.Open();
        SqlCommand cmm = new SqlCommand();
        cmm.Connection = cnn;

        cmm.CommandText = "SELECT companyID From contact where contactid = " + _contactID;

        SqlDataReader sqlDtReader = cmm.ExecuteReader();
        if (sqlDtReader.HasRows)
        {
            while (sqlDtReader.Read())
            {
                cmpID = Convert.ToInt32(sqlDtReader["companyID"]);
            }
        }
        sqlDtReader.Close();
        cnn.Close();
        return cmpID;
    }
    protected void ddlCompany_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlCompany.SelectedValue != "362") // From EBSD
            lblDocCatID.Text = "2";
        else
            lblDocCatID.Text = "1";
    }
    protected void lnkAttachments_Click(object sender, EventArgs e)
    {

    }
    protected void lnkFile_Click(object sender, EventArgs e)
    {

    }
}