﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Data;
using System.Data.SqlClient;
using Datalayer;
using System.IO;
using System.Configuration;
using System.Globalization;
using System.Threading;
using System.Net.Mail;
using System.Security.Cryptography.X509Certificates;
using System.Net.Security;
using System.Net;

public partial class Contracts_ClaimDetails : System.Web.UI.Page
{
    string connValue = System.Configuration.ConfigurationManager.ConnectionStrings["EBSDEBookConn"].ConnectionString;
    string _jobNo = string.Empty;
    int _jobID = 0;
    IList<string> userRightsColl = new List<string>();
    string profile_Name = string.Empty;
    int _tabType = 0;

    private DataSet GetData(string query)
    {
        string conString = ConfigurationManager.ConnectionStrings["EBSDEBookConn"].ConnectionString;
        SqlCommand cmd = new SqlCommand(query);
        using (SqlConnection con = new SqlConnection(conString))
        {
            using (SqlDataAdapter sda = new SqlDataAdapter())
            {
                cmd.Connection = con;
                sda.SelectCommand = cmd;
                using (DataSet ds = new DataSet())
                {
                    sda.Fill(ds);
                    return ds;
                }
            }
        }
    }

    protected void lnkLogOutBtn_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/LoginPage.aspx", false);
    }

    protected void OnRowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            ////Find the DropDownList in the Row.
            //DropDownList ddlCountries = (e.Row.FindControl("ddlCountries") as DropDownList);
            //ddlCountries.DataSource = GetData("SELECT DISTINCT tender_no FROM Projects where proj_id <= 60");
            //ddlCountries.DataTextField = "tender_no";
            //ddlCountries.DataValueField = "tender_no";
            //ddlCountries.DataBind();

            ////Add Default Item in the DropDownList.
            //ddlCountries.Items.Insert(0, new ListItem("Please select"));

            ////Select the Country of Customer in DropDownList.
            //string country = (e.Row.FindControl("lblCountry") as Label).Text;
            //ddlCountries.Items.FindByValue(country).Selected = true;
        }
    }
    protected void Page_Init(object sender, EventArgs e)
    {
        if (Session["UserName"] == null)
        {
            Response.Redirect("~/LoginPage.aspx", false);
            return;
        }

        if (_jobID == 0)
            _jobID = Convert.ToInt32(Request.QueryString["JobID"]);

        if (_jobID == 0)
            _jobID = Convert.ToInt32(Session["GIS_JobID"]);
        lblUser.Text = Session["UserDisplayName"].ToString();
        lblUserProfile.Text = Session["ProfileName"].ToString();
        //Session["StaffJobID"] = Convert.ToInt32(Request.QueryString["JobID"]);

        _tabType = Convert.ToInt32(Request.QueryString["tabType"]);

        // _jobID = 17621;

        userRightsColl = (IList<string>)Session["UserRightsColl"];



        if (!IsPostBack)
        {
            PopulateDropDownBox(ddlJobCat, "SELECT  jobTypeID, jobTypeName, CategoryID, sectionID FROM   JobType WHERE (sectionID = 12) ", "jobTypeID", "jobTypeName"); // AND (jobTypeID <> CategoryID)

            PopulateDropDownBox(ddlJobType, "SELECT  jobTypeID, jobTypeName, CategoryID, sectionID FROM   JobType WHERE (sectionID = 12) AND (jobTypeID <> CategoryID) ", "jobTypeID", "jobTypeName"); // 

            // PopulateDropDownBox(drpSubTaskType, "SELECT  subTypeID, subTypeName, typeID FROM  SubTaskType Where typeID = 67 ", "subTypeID", "subTypeName");  // Where typeID = 67   no need            

            //PopulateDropDownBox(drpActionBy, "SELECT contactID, firstName FROM Contact where sectionID = 22", "contactID", "firstName");

            PopulateDropDownBox(ddlJobStatus, "SELECT JobStatusID, JobStatusName FROM JobStatus Where JobStatusID in(1,3,5,7,15,17) ORDER BY JobStatusName", "JobStatusID", "JobStatusName");   //4, Ongoing and Pending ,18

            //ddlQS.DataSource = null;

            string getStaff = "SELECT  contactID, (firstName + ' ' + lastName) as UserName FROM  Contact WHERE (userShortName IS NOT NULL) AND (contactID <> 1) AND (isActive = 1) and sectionID = 12  ORDER BY UserName";

            PopulateDropDownBox(ddlQS, getStaff, "contactID", "UserName");

            PopulateDropDownBox(ddlStaff, getStaff, "contactID", "UserName");

            PopulateDropDownBox(ddlReqVia, "SELECT ReqID, ReqVia FROM RequestService", "ReqID", "ReqVia");

            PopulateDropDownBox(ddlDept, "SELECT departmentID, deptName FROM  Department where affairID is not null ORDER BY deptName ", "departmentID", "deptName");

            PopulateDropDownBox_TCMS(ddlVendor, "SELECT co_id, co_name FROM Company ORDER BY co_name", "co_id", "co_name");
            // After job cat fill 

          //  PopulateDropDownBox(ddlJobType, "SELECT  jobTypeID, jobTypeName, CategoryID, sectionID FROM JobType WHERE (sectionID = 11) AND (jobTypeID <> CategoryID) and CategoryID = " + Session["JobCatID"].ToString() + " ", "jobTypeID", "jobTypeName"); // AND (jobTypeID <> CategoryID)

            PopulateDropDownBox(ddlPurpose, "SELECT jobPurposeID, jobPurposeName FROM JobPurpose where jobPurposeID in(1,8,9,10,14,62) OR sectionID = 11", "jobPurposeID", "jobPurposeName"); //  For Distribution -1  // For Review - 8// For Approval - 9// For Action -10 // 14 - For Coordination

         //   string sqlQuery = "select x.jobTypeID,a.jobtypeid,d.jobPurposeID,x.jobTypeName as jobCategory,a.jobTypeName,d.jobpurposename from JobType a inner join JobType x ON x.jobTypeID = a.CategoryID inner join JobTypePurpose b on a.jobTypeID = b.jobTypeID " +
         //" inner join JobPurpose d on b.jobPurposeID = d.jobPurposeID where a.jobTypeID = " + Session["jobTypeID"].ToString() + " order by x.jobTypeID";

         //   PopulateDropDownBox(ddlPurpose, sqlQuery, "jobPurposeID", "jobPurposeName"); //  For Distribution -1  // For Review - 8// For Approval - 9// For Action -10 // 14 - For Coordination
           
            PopulateDropDownBox(ddlReplyPreparedBy, getStaff, "contactID", "UserName");

            Fill_JobOrder_Information(_jobID);

            txtStaffRemarks.Enabled = false;

            trStaffRmrks.Visible = false;

          //  GridView1.DataSource = GetData("SELECT proj_id, tender_no FROM Projects where proj_ID <= 60");
          //  GridView1.DataBind();

            PopulateDropDownBox(ddlCommitNo, "SELECT  contract_no, contract_no FROM   CONTRACTORS where (contract_no is not null and contract_no <> '') ", "contract_no", "contract_no"); // AND (jobTypeID <> CategoryID)

            string sql = "SELECT     JobContract.JobContractID,  JobContract.jobID, CONTRACTORS.contract_no, CONTRACTORS.ContractTitle, TCMS_Company.co_name " +
          " FROM JobContract INNER JOIN CONTRACTORS ON JobContract.projectCode = CONTRACTORS.contract_no COLLATE Latin1_General_CI_AI INNER JOIN " +
                      "  TCMS_Company ON CONTRACTORS.co_id = TCMS_Company.co_id WHERE (JobContract.jobID = " + _jobID + ") Order by JobContract.JobContractID";

            GridView1.DataSource = GetDataContract(sql);
            GridView1.DataBind();
        }

        gvJoborder.DataSource = new JobOrderData().GetMngrJobOwnerDetails(_jobID);
        gvJoborder.DataBind();

        gridReceived.DataSource = new JobOrderData().getJobDocumetReceivedDate(_jobID);
        gridReceived.DataBind();

        gridSent.DataSource = new JobOrderData().getJobDocumetSentDate(_jobID);
        gridSent.DataBind();

    }    
    protected void Unnamed_Click(object sender, EventArgs e)
    {
       
    }
    protected void GridView2_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        PlaceHolder phDropDown = e.Row.FindControl("phDropDown") as PlaceHolder;
        if (null != phDropDown && e.Row.RowType == DataControlRowType.DataRow)
        {
            DropDownList ddlDynamic = new DropDownList();
            ddlDynamic.ID = "ddlDynamic" + e.Row.RowIndex.ToString();
            ddlDynamic.EnableViewState = true;
            ddlDynamic.DataSource = GetDataForDropDown();
            ddlDynamic.DataBind();
            phDropDown.Controls.Add(ddlDynamic);

            //-- to retain state of previously selected value in dropdown.. after postback
            string ddlKey = Request.Form.AllKeys.Where(key => key.EndsWith(ddlDynamic.ID)).FirstOrDefault();
            if (!string.IsNullOrEmpty(ddlKey) &&
                null != Request.Form[ddlKey] &&
                null != ddlDynamic.Items.FindByText(Request.Form[ddlKey]))
                ddlDynamic.Items.FindByText(Request.Form[ddlKey]).Selected = true;
            //-- to retain state of previously selected value in dropdown.. after postback
        }
    }
    private List<string> GetDataForDropDown()
    {
        //-- for example, fetch data from db
        List<string> listData = new List<string>() { "AAA", "BBB", "CCC" };
        return listData;
    }
    private void PopulateDropDownBox_TCMS(DropDownList ddlBox, string sqlQuery, string valueMember, string displayName)
    {
        ddlBox.DataSource = new JobOrderData().FillDropdown_TCMS(sqlQuery);
        ddlBox.DataTextField = displayName;
        ddlBox.DataValueField = valueMember;
        ddlBox.SelectedIndex = -1;
        ddlBox.DataBind();
        ddlBox.Items.Insert(0, new ListItem("--Select--"));
    }
    string filename = string.Empty;   
   
    
    private void PopulateDropDownBox(DropDownList ddlBox, string sqlQuery, string valueMember, string displayName)
    {
        DataTable table = new DataTable();
        try
        {
            using (SqlConnection sqlConn = new SqlConnection(connValue))
            {
                using (SqlDataAdapter da = new SqlDataAdapter(sqlQuery, sqlConn))
                {
                    sqlConn.Open();
                    da.Fill(table);
                }
            }
            //cmbBox.Items.Add("Select");

            ddlBox.DataSource = table;
            ddlBox.DataTextField = displayName;
            ddlBox.DataValueField = valueMember;

            ddlBox.SelectedIndex = -1;
            ddlBox.DataBind();

            ddlBox.Items.Insert(0, new ListItem(""));
        }
        catch (System.Exception ex)
        {
            throw ex;
        }
    }
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnsave_Click(object sender, EventArgs e)
    {
        if (userRightsColl.Contains("7"))
        {
            // UpdateRequest_RemarksOnly(_jobID);
        }
        else
        {
            UpdateJobOrder(_jobID); // GIS_UpdateLog
        }
    }
    protected void SelectedIndexChanged(object sender, EventArgs e)
    {
        DropDownList ddl = (DropDownList)sender;
        if (ddl.SelectedIndex != -1)
        {
            string ID = ddl.ID;
            string g = ddl.SelectedValue;
            string inchargeID = ddl.ToolTip;

            Session["_InchargeID"] = inchargeID;
            Session["StatusValCurrent"] = ddl.SelectedValue;

            if (ddl.SelectedValue != "3")
            {
                int rowFnd = getandChkData(Convert.ToInt32(inchargeID), Convert.ToInt32(ddl.SelectedValue));
                if (rowFnd != 0)
                {
                    ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Action By Staff not yet completed')</script>", false);
                    ddl.SelectedValue = "3";
                }
                else
                {
                     updateOngoingStatus(Convert.ToInt32(inchargeID), Convert.ToInt32(ddl.SelectedValue));
                     if (ddl.SelectedValue == "7") //7 == Completed
                     {
                         //new JobOrderData().SendEmailAlert(new JobOrderData().getEmail("269"), txtJobNo.Text, "", "all the tasks are completed and the details are as follows");  //105 is Nazar ContactID                             
                         new JobOrderData().SendEmailAlert(new JobOrderData().getEmail(Session["teamLeaderID"].ToString()), txtJobNo.Text, "", "all the tasks are completed and the details are as follows");  //105 is Nazar ContactID                             
                     }
                    gvJoborder.DataSource = new JobOrderData().GetJobOwnerDetails(_jobID);
                    gvJoborder.DataBind();
                }
            }
            else
            {
                updateOngoingStatus(Convert.ToInt32(inchargeID), Convert.ToInt32(ddl.SelectedValue));

                //if (ddl.SelectedValue == "3")
                //{
                //    new JobOrderData().UpdateCompletionDate(Convert.ToInt32(inchargeID));
                //}


                //if (ddl.SelectedValue == "3" || ddl.SelectedValue == "7")
                //    new JobOrderData().UpdateJobDoneCheckBox(Convert.ToInt32(inchargeID), Convert.ToInt32(ddl.SelectedValue)); //cmldaten jobdone

                //if (ddl.SelectedValue != "7")
                //{
                //    new JobOrderData().UpdateCompletionDate(Convert.ToInt32(inchargeID));
                //}

                // new JobOrderData().UpdateJobStatus(Convert.ToInt32(inchargeID), Convert.ToInt32(ddl.SelectedValue), Session["UserName"].ToString());

                gvJoborder.DataSource = new JobOrderData().GetJobOwnerDetails(_jobID);
                gvJoborder.DataBind();
            }
        }
    }
    private int getandChkDataTeamLead(int _ownerID, int _statusID)
    {
        int iCnt = 0;
        SqlConnection cnn = new SqlConnection(connValue);
        cnn.Open();
        SqlCommand cmm = new SqlCommand();
        cmm.Connection = cnn;
        cmm.CommandText = "select COUNT(*) AS rCnt from JobOwner where jobID = @jobID and jobownerID <> @ownerID and jobOwnerStatusID = 3";
        cmm.CommandType = CommandType.Text;

        cmm.Parameters.AddWithValue("@jobID", _jobID);
        cmm.Parameters.AddWithValue("@statID", _statusID);
        cmm.Parameters.AddWithValue("@ownerID", _ownerID);

        SqlDataReader dr = cmm.ExecuteReader();

        if (dr.HasRows)
        {
            while (dr.Read())
                iCnt = Convert.ToInt16(dr["rCnt"]);
        }
        cnn.Close();

        return iCnt;
    }
    private int getandChkData(int _ownerID, int _statusID)
    {
        SqlConnection cnn = new SqlConnection(connValue);
        cnn.Open();
        SqlCommand cmm = new SqlCommand();
        cmm.Connection = cnn;
        cmm.CommandText = "gis_chkTeamLeadStatus";
        cmm.CommandType = CommandType.StoredProcedure;

        cmm.Parameters.AddWithValue("@jobID", _jobID);
        cmm.Parameters.AddWithValue("@userID", Convert.ToInt32(Session["UserID"]));
        cmm.Parameters.AddWithValue("@ownerID", _ownerID);
        cmm.Parameters.AddWithValue("@statID", _statusID);
        cmm.Parameters.AddWithValue("@rCnt", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

        cmm.ExecuteNonQuery();
        cnn.Close();

        return (int)cmm.Parameters["@rCnt"].Value;
    }
    private void updateOngoingStatus(int _ownerID, int _statusID)
    {
        SqlConnection cnn = new SqlConnection(connValue);
        cnn.Open();
        SqlCommand cmm = new SqlCommand();
        cmm.Connection = cnn;

        if (_statusID == 17)
        {
            cmm.CommandText = "update JobOwner set jobOwnerStatusID = @statID,completionDate = @completionDate,draftSubmitted = @draftSubmitted,draftCompleted = @draftCompleted where jobOwnerID =@ownerID";
        }
        else if (_statusID == 18)
        {
            cmm.CommandText = "update JobOwner set jobOwnerStatusID = @statID,completionDate = @completionDate,draftCompleted = @draftCompleted where jobOwnerID =@ownerID";
        }
        else if (_statusID != 3)
        {
            cmm.CommandText = "update JobOwner set jobOwnerStatusID = @statID,completionDate = @completionDate where jobOwnerID =@ownerID";
        } 
        else
        {
            cmm.CommandText = "update JobOwner set jobOwnerStatusID = @statID,completionDate = @completionDate,draftSubmitted = @draftSubmitted,draftCompleted  = @draftCompleted where jobOwnerID =@ownerID";
        }

        cmm.CommandType = CommandType.Text;

        cmm.Parameters.AddWithValue("@ownerID", _ownerID);
        cmm.Parameters.AddWithValue("@statID", _statusID);

        if (_statusID == 17)
        {
            cmm.Parameters.AddWithValue("@draftSubmitted", Convert.ToDateTime(System.DateTime.Now).ToString("dd/MMM/yyyy"));
            cmm.Parameters.AddWithValue("@draftCompleted", System.DBNull.Value);
            cmm.Parameters.AddWithValue("@completionDate", System.DBNull.Value);
        }
        else if (_statusID == 18)
        {
            cmm.Parameters.AddWithValue("@draftSubmitted", System.DBNull.Value);
            cmm.Parameters.AddWithValue("@draftCompleted", Convert.ToDateTime(System.DateTime.Now).ToString("dd/MMM/yyyy"));
            cmm.Parameters.AddWithValue("@completionDate", System.DBNull.Value);
        }
        else if (_statusID != 3)
        {
            cmm.Parameters.AddWithValue("@completionDate", Convert.ToDateTime(System.DateTime.Now).ToString("dd/MMM/yyyy"));
        }        
        else
        {
            cmm.Parameters.AddWithValue("@draftSubmitted", System.DBNull.Value);
            cmm.Parameters.AddWithValue("@draftCompleted", System.DBNull.Value);
            cmm.Parameters.AddWithValue("@completionDate", System.DBNull.Value);           
        }

        cmm.ExecuteNonQuery();
        cnn.Close();
    }
    public void UpdateJobOrder(int upd_JobID)
    {
        SqlConnection sqlCon = new SqlConnection(connValue);
        SqlCommand cmd = new SqlCommand();
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.CommandText = "GIS_UpdateLog";
        cmd.Connection = sqlCon;

        cmd.Parameters.AddWithValue("@Job_id", upd_JobID);

        if (ddlJobType.SelectedIndex != 0)
            cmd.Parameters.AddWithValue("@Job_Type_id", ddlJobType.SelectedValue);
        else
            cmd.Parameters.AddWithValue("@Job_Type_id", ddlJobType.SelectedValue);

        cmd.Parameters.AddWithValue("@Project_Code", txtPrjCode.Text);
        cmd.Parameters.AddWithValue("@jobDesc", txtPrjTitle.Text);
        cmd.Parameters.AddWithValue("@Project_Title", txtPrjTitle.Text);

        if(ddlVendor.SelectedIndex!=0)
           cmd.Parameters.AddWithValue("@ContractorID", ddlVendor.SelectedItem.Value);
        else
            cmd.Parameters.AddWithValue("@ContractorID", System.DBNull.Value);

        cmd.Parameters.AddWithValue("@ConsultantID", System.DBNull.Value);

        if (ddlJobStatus.SelectedIndex != 0)
            cmd.Parameters.AddWithValue("@Job_Status_id", ddlJobStatus.SelectedValue);
        else
            cmd.Parameters.AddWithValue("@Job_Status_id", System.DBNull.Value);
                        
        if (ddlDept.SelectedIndex != 0)
            cmd.Parameters.AddWithValue("@DepartmentID", ddlDept.SelectedValue);  // Not Applicable
        else
            cmd.Parameters.AddWithValue("@DepartmentID", 22);  // EBD

        cmd.Parameters.AddWithValue("@QSID", System.DBNull.Value);

        cmd.Parameters.AddWithValue("@PEID", System.DBNull.Value);

        cmd.Parameters.AddWithValue("@CEID", System.DBNull.Value);

        cmd.Parameters.AddWithValue("@remarks", txtRemarks.Text);

        if (ddlPrjSize.SelectedIndex != 0)
            cmd.Parameters.AddWithValue("@gradeID", ddlPrjSize.SelectedValue);
        else
            cmd.Parameters.AddWithValue("@gradeID", 1);        

        cmd.Parameters.AddWithValue("@addendumNO", System.DBNull.Value);

        cmd.Parameters.AddWithValue("@contractTypeID", System.DBNull.Value);

        cmd.Parameters.AddWithValue("@workDays", 1);

        cmd.Parameters.AddWithValue("@dueDate", Convert.ToDateTime(txtDueDate.Text).ToString("dd/MMM/yyyy"));

        cmd.Parameters.AddWithValue("@updateUser", Session["UserName"]);

        cmd.Parameters.AddWithValue("@submissionNo", System.DBNull.Value);
        cmd.Parameters.AddWithValue("@projStstusID", System.DBNull.Value);     

        cmd.Parameters.AddWithValue("@dcRejectionID", System.DBNull.Value);

        cmd.Parameters.AddWithValue("@sentOnSurveyTeam", System.DBNull.Value);

        cmd.Parameters.AddWithValue("@receivedSurveyTeamOn", System.DBNull.Value);        

        cmd.Parameters.AddWithValue("@reviewDate", System.DBNull.Value);
        cmd.Parameters.AddWithValue("@attRecDate", System.DBNull.Value);       

        cmd.Parameters.AddWithValue("@projectCode", txtPrjCode.Text);

        cmd.Parameters.AddWithValue("@projCoordinatorID", 216);

        cmd.Parameters.AddWithValue("@committmentNo", txtCntrNo.Text);

        cmd.Parameters.AddWithValue("@requesterName", System.DBNull.Value);

        if (ddlReplyPreparedBy.SelectedIndex !=0)
          
            cmd.Parameters.AddWithValue("@DCID", ddlReplyPreparedBy.SelectedValue);
        else
            cmd.Parameters.AddWithValue("@DCID", System.DBNull.Value);

        if (ddlReqVia.SelectedIndex != 0)
            cmd.Parameters.AddWithValue("@recVia", ddlReqVia.SelectedValue);
        else
            cmd.Parameters.AddWithValue("@recVia", 1);

        cmd.Parameters.AddWithValue("@subTypeID", System.DBNull.Value);

        cmd.Parameters.AddWithValue("@taskPct", 100);

        cmd.Parameters.AddWithValue("@externalDept", System.DBNull.Value);

        cmd.Parameters.AddWithValue("@BarcodeNo", System.DBNull.Value);

            cmd.Parameters.AddWithValue("@ReqBehalf", System.DBNull.Value);
               

        try
        {
            sqlCon.Open();
            cmd.ExecuteNonQuery();
            sqlCon.Close();
        }
        catch (Exception ex)
        {
            throw ex;
        }
        //lblResult.Text = "Data Updated Successfully";
        // Response.Write();
    }
    private void UpdateRemarks(int jobOwnerID, string remarks)
    {
        if (txtStaffRemarks.Text.Trim() != "" && lblInchargeID.Text.Trim() != "")
        {
            SqlConnection con = new SqlConnection(connValue);
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.Text;
            cmd.Connection = con;

            cmd.CommandText = "Update JobOwner set remarks=@remarks,remarksDate=@remarksDate Where jobOwnerID=@jobOwnerID";
            cmd.Parameters.AddWithValue("@remarks", remarks);
            cmd.Parameters.AddWithValue("@remarksDate", System.DateTime.Now.ToString("dd/MMM/yyyy"));
            cmd.Parameters.AddWithValue("@jobOwnerID", jobOwnerID);

            try
            {
                con.Open();
                cmd.ExecuteNonQuery();
                con.Dispose();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                con.Close();
            }
        }

    }
    private void InsertStaffData()
    {
        int _ownerID = 0;

        _ownerID = AddInchargeDataDC(Session["Username"].ToString(), Convert.ToInt32(Session["UserID"]), Convert.ToInt32(Session["SectionID"]), txtReceivedDate.Text);
    }
    public int AddInchargeDataDC(string userName, int _currentUserID, int _currentSecID, string staffStartDate)
    {
        int _ownerID = 0;
        using (SqlConnection con = new SqlConnection(connValue))
        {
            using (SqlCommand cmd = new SqlCommand())
            {
                try
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Connection = con;

                    cmd.CommandText = "AddJobInchargeDC";

                    cmd.Parameters.AddWithValue("@jobID", _jobID);

                    cmd.Parameters.AddWithValue("@contactID", ddlStaff.SelectedValue);

                    cmd.Parameters.AddWithValue("@distributedBy", _currentUserID);

                    cmd.Parameters.AddWithValue("@actionDueDate", txtStaffDueDate.Text);

                    cmd.Parameters.AddWithValue("@daysToAct", 1);

                    cmd.Parameters.AddWithValue("@createUser", userName);

                    cmd.Parameters.AddWithValue("@StaffRoleID", 1);

                    if (ddlPurpose.SelectedIndex != 0)
                        cmd.Parameters.AddWithValue("@jobPurposeID", ddlPurpose.SelectedValue);
                    else
                        cmd.Parameters.AddWithValue("@jobPurposeID", 1);

                    cmd.Parameters.AddWithValue("@sectionID", 12);

                    cmd.Parameters.AddWithValue("@jobOwnerID", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                    //if (staffStartDate != "")
                    //    cmd.Parameters.AddWithValue("@startDate", Convert.ToDateTime(System.DateTime.Now).ToString("dd/MMM/yyyy"));
                    //else
                    //    cmd.Parameters.AddWithValue("@startDate", System.DBNull.Value);

                    cmd.Parameters.AddWithValue("@startDate", txtStaffStartDate.Text);

                    con.Open();
                    cmd.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    throw ex;
                }

                return _ownerID = (int)cmd.Parameters["@jobOwnerID"].Value;
            }
        }
    }
    private void ClearStaffData()
    {
        //  ddlPrjSize.SelectedIndex = -1;
        //  ddlPurpose.SelectedIndex = -1;

        //  //txtStartDate.Text = "";
        //  //txtDueDate.Text = "";


        //  txtStaffRemarks.Text = "";

        ////  lblDistributedBy.Text = "";

        //  lblInchargeID.Text = "";





        // // txtMngrComments.Text = "";
        // // lblDistributedBy.Text = "";




    }
    private void PopulateDropDownBox_Staff(DropDownList ddlBox, string sqlQuery, string valueMember, string displayName)
    {
        DataTable table = new DataTable();
        try
        {
            using (SqlConnection sqlConn = new SqlConnection(connValue))
            {
                using (SqlDataAdapter da = new SqlDataAdapter(sqlQuery, sqlConn))
                {
                    sqlConn.Open();
                    da.Fill(table);
                }
            }
            //cmbBox.Items.Add("Select");

            ddlBox.DataSource = table;
            ddlBox.DataTextField = displayName;
            ddlBox.DataValueField = valueMember;

            ddlBox.SelectedIndex = -1;
            ddlBox.DataBind();

            // ddlBox.Items.Insert(0, new ListItem("--Select--"));
        }
        catch (System.Exception ex)
        {
            throw ex;
        }
    }
    Boolean isDisabled = false;
    protected void gvJoborder_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            //e.Row.Cells[8].Width = new Unit("60px");
            //e.Row.Cells[8].Height = new Unit("60px");
            //e.Row.Cells[8].Wrap = true;
            
            DropDownList l = (DropDownList)e.Row.FindControl("ddljobtype");

            PopulateDropDownBox_Staff(l, "SELECT JobStatusid,JobStatusName as JobStatus FROM jobStatus where JobStatusid in(2,3,6,7,15,17,18,62) ", "JobStatusid", "JobStatus");  // where JobStatusid in(5,6,7,8) // 15,16

            TextBox lm = (TextBox)e.Row.FindControl("jobid");
            TextBox afr = (TextBox)e.Row.FindControl("TextBox1");
            TextBox InchargeID = (TextBox)e.Row.FindControl("txtInchargeID");

            Session["InchargeID"] = InchargeID.Text;

            string lk = lm.Text;

            l.ToolTip = InchargeID.Text;
            
            l.SelectedValue = afr.Text;

            Session["StatusVal"] = l.SelectedValue;

            l.SelectedIndexChanged += new EventHandler(SelectedIndexChanged);

            TextBox txtdate = (TextBox)e.Row.FindControl("lblJoindate");
            txtdate.ToolTip = InchargeID.Text;
            txtdate.TextChanged += new EventHandler(txtdate_TextChanged);
            Session["JobActionDueDate"] = txtdate.Text;

            Label lblStaff = (Label)e.Row.FindControl("txtStaff");

            Label lblDistributedBy = (Label)e.Row.FindControl("txtDistrubed");

            Label lblConactID = (Label)e.Row.FindControl("txtCnctID");

            TextBox _txtDocID = (TextBox)e.Row.FindControl("txtDocID");
            Session["statusdocID"] = _txtDocID.Text;
            Session["contactID"] = lblConactID.Text;

            Label lblDistribID = (Label)e.Row.FindControl("txtDistributedBy");
            Label lblTeamLeadID = (Label)e.Row.FindControl("lblTeamLead");

            //Label lblRoleID = (Label)e.Row.FindControl("txtRoleID");
            // chkDelete.CheckedChanged += new EventHandler(chkstate_CheckedChanged);                        

            if ((!lblConactID.Text.Equals(Session["userID"])))
            {
                l.Enabled = false;
            }
            if (lblConactID.Text.Equals(Session["userID"]))
            {
                //  btnOutlook.Enabled = true;
                Session["ActionDate"] = txtdate.Text;
            }
            if (!lblDistribID.Text.Equals(Session["userID"]))
            {
                txtdate.Enabled = false;
            }

            if (!isDisabled)
            {
                LinkButton lnkSelect = (LinkButton)e.Row.FindControl("btnSelect");
                lnkSelect.Enabled = false;
                isDisabled = true;
            }


        }
    }
    protected void txtdate_TextChanged(object sender, EventArgs e)
    {
        TextBox tdate = (TextBox)sender;
        //string format = "dd/mm/yyyy";

        string dfs = tdate.Text;


        DateTime dd = new DateTime();
        Thread.CurrentThread.CurrentCulture = new CultureInfo("en-GB");
        CultureInfo ci = System.Threading.Thread.CurrentThread.CurrentCulture;
        DateTime dt;

        //dt = DateTime.Parse(tdate.Text, ci); 
        // DateTime dt = DateTime.Parse(tdate.Text, CultureInfo.GetCultureInfo("en-gb"));
        // new JobOrderData().UpdateJobDate(Convert.ToInt32(tdate.ToolTip), dd.ToString());

        new JobOrderData().UpdateJobDate(Convert.ToInt32(tdate.ToolTip), dfs);

        gvJoborder.DataSource = new JobOrderData().GetJobOwnerDetails(_jobID);
        gvJoborder.DataBind();
    }
    protected void gvJoborder_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName.Equals("SelectStaff"))
        {
            string arguments = e.CommandArgument.ToString();

            if (arguments == "")
                return;

            string[] args = arguments.Split(';');

            int staffID = Convert.ToInt32(args[0]);

            FillstaffData(staffID);

            btnStaffSave.Text = " Update Data";

            txtStaffRemarks.Enabled = true;

            trStaffRmrks.Visible = true;

            ddlStaff.Enabled = false;
        }
    }
    private void FillstaffData(int staffID)
    {
        string qry = "SELECT  jobOwnerID, jobID, contactID, jobNo,REPLACE(CONVERT(NVARCHAR, actionDueDate, 106), ' ', '/') AS actionDueDate,  daysToAct, REPLACE(CONVERT(NVARCHAR, completionDate, 106), ' ', '/') AS completionDate, jobOwnerStatusID, jobPurposeID, JobTypeID, " +
        "REPLACE(CONVERT(NVARCHAR, staffIssueDate, 106), ' ', '/') AS staffIssueDate , distributedBy,   remarks, REPLACE(CONVERT(NVARCHAR, staffStartDate, 106), ' ', '/') AS staffStartDate  FROM  JobOwner WHERE (jobOwnerID = " + staffID + ")";

        using (SqlConnection cn = new SqlConnection(connValue))
        {
            cn.Open();
            using (SqlCommand cmd = new SqlCommand(qry, cn))
            {
                using (SqlDataReader dr = cmd.ExecuteReader())
                {
                    while (dr.Read())
                    {
                        lblInchargeID.Text = dr["JobOwnerID"].ToString();
                        // lblDistributedBy.Text = "95";

                        ddlPurpose.SelectedValue = dr["jobPurposeID"].ToString();

                        txtStaffStartDate.Text = dr["staffIssueDate"].ToString();

                        //  txtWorkDays.Text = dr["daysToAct"].ToString();
                        txtStaffDueDate.Text = dr["actionDueDate"].ToString();

                        txtStaffRemarks.Text = dr["remarks"].ToString();

                        lblDistributedBy.Text = dr["distributedBy"].ToString();

                        try
                        {
                            ddlStaff.SelectedValue = dr["contactID"].ToString();
                        }
                        catch (Exception ex)
                        {

                        }
                    }
                }
            }
        }
    }
    private void LoadDrpData()
    {
        PopulateDropDownBox(ddlDept, "SELECT departmentID, deptName FROM  Department  where affairID is not null ORDER BY deptName ", "departmentID", "deptName");
       
       // PopulateDropDownBox(ddlSectionName, "Select sectionID,sectionName From Section order by sectionName", "sectionID", "sectionName");

        PopulateDropDownBox(ddlJobType, "SELECT jobTypeID, jobTypeName FROM JobType ORDER BY jobTypeName", "jobTypeID", "jobTypeName");            //Where jobTypeID not in(1,2,3,4,5,6,7,8)        

        PopulateDropDownBox(ddlJobCat, "SELECT jobTypeID, jobTypeName FROM JobType ORDER BY jobTypeName", "jobTypeID", "jobTypeName");  

        PopulateDropDownBox(ddlJobStatus, "SELECT JobStatusID, JobStatusName FROM JobStatus Where JobStatusID in(1,2,3,5,6,7) ORDER BY JobStatusName", "JobStatusID", "JobStatusName");   //4, Ongoing and Pending

        PopulateDropDownBox(ddlQS, "Select contactID,UserShortName From Contact  order by firstName", "contactID", "UserShortName");        // added where sectionID = 3

        // PopulateDropDownBox(ddlReqType, "Select contactID,UserShortName From Contact order by firstName", "contactID", "UserShortName");

        // PopulateDropDownBox(ddlPE, "Select contactID,UserShortName From Contact order by firstName", "contactID", "UserShortName");

        // PopulateDropDownBox(ddlCntrType, "SELECT contractTypeID, contractTypeName FROM  ContractType Order by contractTypeName ", "contractTypeID", "contractTypeName");

       // PopulateDropDownBox(ddlPrjCoordinator, "Select prjCoordID,CoordName From ProjCoordinator order by CoordName", "prjCoordID", "CoordName");

        //PopulateDropDownBox(ddlReqType, "SELECT reqStatusID, reqStatusName FROM  DCRequestStatus  ", "reqStatusID", "reqStatusName"); // Order by reqStatusName

       // PopulateDropDownBox(ddlCntrType, "SELECT contractTypeID, tcms_CntrName FROM  ContractType Order by tcms_CntrName ", "contractTypeID", "tcms_CntrName");

       // PopulateDropDownBox(ddlGrade, "SELECT jobPriorityID, jobPriorityName FROM JobPriority ORDER BY jobPriorityID", "jobPriorityID", "jobPriorityName");


        //PopulateDropDownBox_TCMS(ddlVendor, "SELECT co_id, co_name FROM Company ORDER BY co_name", "co_id", "co_name");

       // PopulateDropDownBox_TCMS(ddlConsultantNo, "SELECT co_id, co_name FROM Company ORDER BY co_name", "co_id", "co_name");
    }
    public void Fill_JobOrder_Information(int _jobID)
    {
        try
        {
            SqlConnection sqlConn = new SqlConnection(connValue);
            sqlConn.Open();

            //string strValue = "SELECT Job.jobNo, Job.jobTypeID, Job.jobPriorityID, Job.jobStatusID, Job.remarks AS Instruction, Job.deptID, Job.contractNo, Job.qsID, Job.ceID, Job.peID, Job.dcID, Job.contractTypeID AS Contract_Type_id, Job.projectTitle, Job.remarks, Job.contractorID, Job.consultantID, Job.jobID, Job.addendumNO, Job.jobTypeID AS Expr1, " +
            //            " Job.jobDesc, Job.docRefID, Job.workDays, Job.jobDueDate, Job.jobReceivedDate, Job.jobStatusClosedDate, Job.jobClosedDate, Job.docRefID AS Expr2,   JobType.CategoryID AS JobCatID, Job.projectCode, Job.committmentNo, Job.attRcvdDateDC, Job.reviewDateDC, Job.sentToSurveyTeamDC, Job.receivedBySurveyTeamDC, " +
            //            " Job.reqStatusID, Job.submissionNoDC, Job.projCoordinatorID, ProjCoordinator.CoordName,Job.dcRejectionID, Job.closedDocRefID,job.jobPriorityID FROM   Job INNER JOIN  JobType ON Job.jobTypeID = JobType.jobTypeID LEFT OUTER JOIN   ProjCoordinator ON Job.projCoordinatorID = ProjCoordinator.prjCoordID  WHERE  (Job.jobID = " + _jobID + ")";



            // SqlCommand sqlCom = new SqlCommand(strValue, sqlConn);

            SqlCommand sqlCom = new SqlCommand();
            sqlCom.Connection = sqlConn;
            sqlCom.CommandType = CommandType.StoredProcedure;
            sqlCom.CommandText = "dcu_GetDcLogInfo";
            sqlCom.Parameters.AddWithValue("@JobID", _jobID);

            SqlDataReader sqlReader = sqlCom.ExecuteReader();

            while (sqlReader.Read())
            {
                txtJobNo.Text = sqlReader["JobNo"].ToString();

                 ddlJobCat.SelectedValue = sqlReader["jobCatID"].ToString();

                if (!sqlReader["jobCatID"].ToString().Equals(sqlReader["jobTypeID"].ToString()))
                {
                    //if (!sqlReader["jobTypeID"].ToString().Equals(4) || !sqlReader["jobTypeID"].ToString().Equals(5) || !sqlReader["jobTypeID"].ToString().Equals(6))
                    {
                        ddlJobType.SelectedValue = sqlReader["jobTypeID"].ToString();
                        Session["jobTypeID"] = sqlReader["jobTypeID"].ToString();
                    }
                }
                else
                {
                    Session["jobTypeID"] = "";
                }

                //ddlJobStatus.SelectedValue = sqlReader["jobStatusID"].ToString();

                ddlJobStatus.SelectedValue = sqlReader["jobStatusID"].ToString();

                if (sqlReader["closedDocRefID"].ToString() == "")
                    ddlJobStatus.Enabled = true;
                else if ((sqlReader["closedDocRefID"].ToString() == null))
                    ddlJobStatus.Enabled = true;
                else
                    ddlJobStatus.Enabled = false;

                Session["jobCatID"] = sqlReader["jobCatID"].ToString();
                Session["jobTypeID"] = sqlReader["jobTypeID"].ToString();
                Session["JobStatusID"] = sqlReader["jobStatusID"].ToString();
                Session["opendocRefID"] = sqlReader["docRefID"].ToString();

                Session["deptSecID"] = sqlReader["deptID"].ToString();    // Newly added on 8th OCt 18

                if (sqlReader["deptID"].ToString() != "")
                    ddlDept.SelectedValue = sqlReader["deptID"].ToString();

                if (sqlReader["dcID"].ToString() != "")
                    ddlReplyPreparedBy.SelectedValue = sqlReader["dcID"].ToString();

                //if (sqlReader["peID"].ToString() != "")
                //    ddlPE.SelectedValue = sqlReader["peID"].ToString();

                //if (sqlReader["ceID"].ToString() != "")
                //    ddlReqType.SelectedValue = sqlReader["ceID"].ToString();

                txtPrjCode.Text = sqlReader["contractNo"].ToString();

                Session["contractNo"] = sqlReader["contractNo"].ToString();

                txtPrjTitle.Text = sqlReader["projectTitle"].ToString();

                txtRemarks.Text = sqlReader["remarks"].ToString();
               // txtJobDesc.Text = sqlReader["jobDesc"].ToString();

                //if (sqlReader["consultantID"].ToString() != "")
                //    ddlConsultantNo.SelectedValue = sqlReader["consultantID"].ToString();

                //if (sqlReader["Contract_Type_id"].ToString() != "")
                //    ddlCntrType.SelectedValue = sqlReader["Contract_Type_id"].ToString();


                if (sqlReader["contractorID"].ToString() != "")
                    ddlVendor.SelectedValue = sqlReader["contractorID"].ToString();

                //if (sqlReader["jobPriorityID"].ToString() != "")
                //    ddlGrade.SelectedValue = sqlReader["jobPriorityID"].ToString();

                Session["GradeVal"] = sqlReader["jobPriorityID"].ToString();

                // txtAddendum.Text = sqlReader["addendumNO"].ToString();

                Session["subdocID"] = sqlReader["docRefID"].ToString();

                //txtWorkDays.Text = sqlReader["workDays"].ToString();
                txtDueDate.Text = Convert.ToDateTime(sqlReader["jobDueDate"]).ToString("dd/MMM/yyyy");

                if (sqlReader["jobReceivedDate"].ToString() != "")
                    txtReceivedDate.Text = Convert.ToDateTime(sqlReader["jobReceivedDate"]).ToString("dd/MMM/yyyy");
                else
                    txtReceivedDate.Text = "";

                if (sqlReader["jobStatusClosedDate"].ToString() != "")
                    txtStatusClose.Text = Convert.ToDateTime(sqlReader["jobStatusClosedDate"]).ToString("dd/MMM/yyyy");
                else
                    txtStatusClose.Text = "";

                //if (sqlReader["jobClosedDate"].ToString() != "")
                //    TextBox4.Text = Convert.ToDateTime(sqlReader["jobClosedDate"]).ToString("dd/MMM/yyyy");
                //else
                //    TextBox4.Text = "";

                //txtSubmission.Text = sqlReader["submissionNoDC"].ToString();
                txtPrjCode.Text = sqlReader["projectCode"].ToString();
                txtCntrNo.Text = sqlReader["committmentNo"].ToString();

                //if (sqlReader["attRcvdDateDC"].ToString() != "")
                //    txtAttRecDate.Text = Convert.ToDateTime(sqlReader["attRcvdDateDC"]).ToString("dd/MMM/yyyy");

                //if (sqlReader["reviewDateDC"].ToString() != "")
                //    txtReviewDate.Text = Convert.ToDateTime(sqlReader["reviewDateDC"]).ToString("dd/MMM/yyyy");

                //if (sqlReader["sentToSurveyTeamDC"].ToString() != "")
                //{
                //    txtSentOnSurvey.Text = Convert.ToDateTime(sqlReader["sentToSurveyTeamDC"]).ToString("dd/MMM/yyyy");
                //    txtSurveyReply.Enabled = true;
                //}
                //else
                //{
                //    txtSentOnSurvey.Enabled = false;
                //    txtSurveyReply.Enabled = false;
                //}

                //if (sqlReader["receivedBySurveyTeamDC"].ToString() != "")
                //    txtSurveyReply.Text = Convert.ToDateTime(sqlReader["receivedBySurveyTeamDC"]).ToString("dd/MMM/yyyy");

                //if (sqlReader["projCoordinatorID"].ToString() != "")
                //    ddlPrjCoordinator.SelectedValue = sqlReader["projCoordinatorID"].ToString();

                //if (sqlReader["reqStatusID"].ToString() != "")
                //{
                //    if (ddlReqType.DataSource != null)
                //        ddlReqType.SelectedValue = sqlReader["reqStatusID"].ToString();

                //    if (sqlReader["reqStatusID"].ToString() == "2")
                //    {
                //        // ddlReject.Visible = true;

                //        trlistView.Visible = true;  // ListView


                //        // lblDcRej.Visible = true;
                //        // tdRej.Visible = true;
                //    }
                //    else if ((sqlReader["reqStatusID"].ToString() == "4") || (sqlReader["reqStatusID"].ToString() == "5"))
                //    {
                //        // lnkDownload.Visible = true;
                //        // lblReqName.Visible = true;
                //    }
                //    else
                //    {
                //        //lnkDownload.Visible = false;
                //        //lblReqName.Visible = false;
                //    }
                //}
                //if (sqlReader["reqStatusID"].ToString() != "")
                //{
                //    if (sqlReader["reqStatusID"].ToString() == "2")
                //    {
                //        // ddlReject.Visible = true;

                //        trlistView.Visible = true;   // ListView

                //        //lblDcRej.Visible = true;
                //        //  tdRej.Visible = true;

                //        if (ddlReject.DataSource == null)
                //            PopulateDropDownBox(ddlReject, "SELECT dcRejectionCauseID,rejectionDesc FROM DcRejectionCauses  WHERE (rejIsActive = 1)", "dcRejectionCauseID", "rejectionDesc"); // Order by reqStatusName
                //    }
                //    else
                //    {
                //        //lnkDownload.Visible = false;
                //        //lblReqName.Visible = false;
                //    }

                //    if (sqlReader["dcRejectionID"].ToString() != "")
                //    {
                //        if (sqlReader["dcRejectionID"].ToString() != "0")
                //            ddlReject.SelectedValue = sqlReader["dcRejectionID"].ToString();
                //    }
                //}

                //if (sqlReader["jobPriorityID"].ToString() != "")
                //{
                //    ddlGrade.SelectedValue = sqlReader["jobPriorityID"].ToString();
                //}

                //txtDrawingCnt.Text = sqlReader["DrawingCnt"].ToString();

                //txtDrawingApprd.Text = sqlReader["drawingApprovedCnt"].ToString();

                //txtDrawingNotApprd.Text = sqlReader["drawingRejectedCnt"].ToString();

                //txtAsbuiltCnt.Text = sqlReader["asbuiltPercentage"].ToString();


                //if (sqlReader["deptSectionID"].ToString() != "")
                //    ddlSectionName.SelectedValue = sqlReader["deptSectionID"].ToString();

                //txtDCOnlineNo.Text = sqlReader["dcOnlineReqNo"].ToString();

            }
            sqlReader.Close();
            sqlConn.Close();
        }
        catch (Exception ex)
        {
            throw ex;
        }

        //  WorkingDaysCaluclationByGrade(Session["GradeVal"].ToString());

        //if (Session["subDocID"].ToString() != "")
        //    getDocuemnetSubject(Convert.ToInt32(Session["subdocID"]));

    }
    protected void btnreset_Click(object sender, EventArgs e)
    {
        ddlStaff.SelectedIndex = 0;
        ddlPurpose.SelectedIndex = 0;
        txtStaffDueDate.Text = "";

        txtStaffStartDate.Text = "";
        txtStaffRemarks.Text = "";

        ddlStaff.Enabled = true;

        btnStaffSave.Text = "ADD Staff";
    }
    
    protected void gvFileUpload_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {

    }  
     
  
   
    private void reset_StaffData()
    {
        ddlStaff.SelectedIndex = 0;
        ddlPurpose.SelectedIndex = 0;
        txtStaffDueDate.Text = "";
        txtStaffRemarks.Text = "";

        lblInchargeID.Text = "";

        btnStaffSave.Text = "ADD Staff";
    }
    protected void btnStaffSave_Click(object sender, EventArgs e)
    {
        int InchargeID = 0;

        if (lblInchargeID.Text != "")
            InchargeID = Convert.ToInt32(lblInchargeID.Text);

        if (InchargeID == 0)
        {
            if (userRightsColl.Contains("4"))
            {
                ClientScript.RegisterClientScriptBlock(this.GetType(), "Popup", "<script>alert('You have no privilege to Add Staff')</script>", false);
                return;
            }

            InsertStaffData();


           string _eMail = getEmail(ddlStaff.SelectedValue);
           OutLookAlertQuick(_eMail, "");

            reset_StaffData();
        }
        else
        {
            //  UpdateRemarks(InchargeID, txtStaffRemarks.Text.Trim());

            UpdateInchargeData(InchargeID);

            //reset_StaffData();
        }

        //gvJoborder.DataSource = new JobOrderData().GetJobOwnerDetails(_jobID);
        //gvJoborder.DataBind();
        gvJoborder.DataSource = new JobOrderData().GetMngrJobOwnerDetails(_jobID);
        gvJoborder.DataBind();
        txtStaffRemarks.Enabled = false;
        trStaffRmrks.Visible = true;
        ddlStaff.Enabled = true;

    }
    private string getEmail(string contactID)
    {
        string streMail = string.Empty;
        try
        {
            SqlConnection sqlConn = new SqlConnection(connValue);
            sqlConn.Open();
            SqlCommand sqlCom = new SqlCommand("Select emailAddress from Contact where ContactID = " + Convert.ToInt32(contactID) + "", sqlConn);
            SqlDataReader sqlReader = sqlCom.ExecuteReader();
            while (sqlReader.Read())
            {
                streMail = sqlReader["emailAddress"].ToString();
            }
            sqlReader.Close();
            sqlConn.Close();
        }
        catch (System.Exception ex)
        {
            throw ex;
        }

        return streMail;
    }
    public void UpdateInchargeData(int inchargeID)
    {
        using (SqlConnection con = new SqlConnection(connValue))
        {
            using (SqlCommand cmd = new SqlCommand())
            {
                try
                {
                    cmd.CommandType = CommandType.Text;
                    cmd.Connection = con;

                    if (lblDistributedBy.Text.Equals(Session["UserID"].ToString()))
                    {
                        cmd.CommandText = "Update JobOwner Set remarks =@inchargeRemarks,jobPurposeID = @jobPurposeID, " +
                        " actionDueDate =@actionDueDate where jobOwnerID = " + inchargeID;

                        // ,teamStatusID = @taskStatusID

                        cmd.Parameters.AddWithValue("@actionDueDate", Convert.ToDateTime(txtStaffDueDate.Text).ToString("dd/MMM/yyyy"));
                        cmd.Parameters.AddWithValue("@jobPurposeID", ddlPurpose.SelectedValue);
                    }
                    else if (!userRightsColl.Contains("4"))
                    {
                        cmd.CommandText = "Update JobOwner Set remarks =@inchargeRemarks,jobPurposeID = @jobPurposeID, " +
                        " actionDueDate =@actionDueDate where jobOwnerID = " + inchargeID;

                        // ,teamStatusID = @taskStatusID

                        cmd.Parameters.AddWithValue("@actionDueDate", Convert.ToDateTime(txtStaffDueDate.Text).ToString("dd/MMM/yyyy"));
                        cmd.Parameters.AddWithValue("@jobPurposeID", ddlPurpose.SelectedValue);
                    }
                    else
                    {
                        cmd.CommandText = "Update JobOwner Set remarks =@inchargeRemarks where jobOwnerID = " + inchargeID;
                    }

                    cmd.Parameters.AddWithValue("@inchargeRemarks", txtStaffRemarks.Text);
                    cmd.Parameters.AddWithValue("@jobOwnerID", SqlDbType.SmallInt).Direction = ParameterDirection.Output;


                    con.Open();
                    cmd.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
        }
    }
    protected void ddlPrjSize_SelectedIndexChanged(object sender, EventArgs e)
    {
        string endDate = string.Empty;
        if (ddlPrjSize.SelectedIndex == 0)
        {
            lblSize.Text = "- 7 Days";
            endDate = getEndDateByGivenDays(7, txtReceivedDate.Text);
        }
        else if (ddlPrjSize.SelectedIndex == 1)
        {
            lblSize.Text = "- 10 Days";
            endDate = getEndDateByGivenDays(10, txtReceivedDate.Text);

        }
        else if (ddlPrjSize.SelectedIndex == 2)
        {
            lblSize.Text = "- 15 Days";
            endDate = getEndDateByGivenDays(15, txtReceivedDate.Text);
        }
        else
        {
            endDate = getEndDateByGivenDays(7, txtReceivedDate.Text);
        }

        txtDueDate.Text = Convert.ToDateTime(endDate).ToString("dd/MMM/yyyy");

    }
    private void WorkingDaysCaluclationByGrade(string strDate)
    {
        string endDate = string.Empty;
        switch (ddlPrjSize.SelectedItem.ToString())
        {
            case "1":

                endDate = getEndDateByGivenDays(7, strDate);
                txtDueDate.Text = Convert.ToDateTime(endDate).ToString("dd/MMM/yyyy");

                //txtDueDate.Text = System.DateTime.Now.AddDays(5).ToString("dd/MMM/yyyy");
                break;
            case "2":
                endDate = getEndDateByGivenDays(10, strDate);
                txtDueDate.Text = Convert.ToDateTime(endDate).ToString("dd/MMM/yyyy");
                break;

            case "3":
                endDate = getEndDateByGivenDays(15, strDate);
                txtDueDate.Text = Convert.ToDateTime(endDate).ToString("dd/MMM/yyyy");
                break;

            case "4":
                endDate = getEndDateByGivenDays(20, strDate);
                txtDueDate.Text = Convert.ToDateTime(endDate).ToString("dd/MMM/yyyy");
                break;

            case "":
                txtDueDate.Text = "";
                //txtWorkDays.Text = "";
                break;

            default:
                break;
        }
    }
    private string getEndDateByGivenDays(int _days, string strDate)
    {
        SqlConnection con = new SqlConnection(connValue);
        SqlCommand cmd = new SqlCommand();
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Connection = con;

        cmd.CommandText = "AddWorkdays";
        SqlParameter prm = cmd.Parameters.Add("@ad_startDate", SqlDbType.DateTime);
        prm.Value = strDate;
        prm = cmd.Parameters.Add("@actual_workDays", SqlDbType.Int);
        prm.Value = Convert.ToInt32(_days);
        prm = cmd.Parameters.Add("@endDate", SqlDbType.DateTime);
        prm.Direction = ParameterDirection.Output;
        con.Open();
        SqlDataReader dr = cmd.ExecuteReader();
        while (dr.Read())
            Console.WriteLine(dr.GetString(0));
        con.Dispose();
        con.Close();

        return cmd.Parameters[2].Value.ToString();
    }
    protected void ddlJobStatus_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (userRightsColl.Contains("6")) // Access Right is 6
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Don't have the permission to edit this field ')</script>", false);
        }
        else if (getStaffStatus() == true)
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Action By Staff not yet completed')</script>", false);
            ddlJobStatus.SelectedValue = "3";
        }
        else
        {
            if (ddlJobStatus.SelectedIndex != 0)
            {
                Session["lnkJobID"] = _jobID;

                if ((ddlJobStatus.SelectedValue == "2") || (ddlJobStatus.SelectedValue == "5"))     //Rej or Cancelleted 2 n 5
                {
                    UpdateJobStatuCompletedsDate(_jobID, Convert.ToInt32(ddlJobStatus.SelectedValue));

                    // UpdateJobStatusByUserSelection(_jobID, Convert.ToInt32(ddlJobStatus.SelectedValue));
                }
                else if ((ddlJobStatus.SelectedValue == "3"))  // ongoing
                {
                    // UpdateJobStatusByUserSelection(_jobID, Convert.ToInt32(ddlJobStatus.SelectedValue));

                    UpdateJobStatuCompletedsDate(_jobID, Convert.ToInt32(ddlJobStatus.SelectedValue));
                }
                else if ((ddlJobStatus.SelectedValue == "7"))               // Close n Completed 7
                {
                    UpdateJobStatuCompletedsDate(_jobID, Convert.ToInt32(ddlJobStatus.SelectedValue));
                    string _eMail = new JobOrderData().getEmail(ddlReplyPreparedBy.SelectedValue); //jobCreatedByID
                    //string _eMail = new JobOrderData().getEmail("269"); //jobCreatedByID                     
                    OutLookAlert_Requester(_eMail);
                    // txtWt.Text = "100";
                }
                else if ((ddlJobStatus.SelectedValue == "16"))               // Re Open Job
                {
                    UpdateReOpenStatus(_jobID, Convert.ToInt32(ddlJobStatus.SelectedValue));
                    
                }
                //else if (ddlJobStatus.SelectedValue == "1")
                //{
                //    CloseJob();

                //    UpdateJobClosedDate(_jobID, Convert.ToInt32(ddlJobStatus.SelectedValue));

                //    txtWt.Text = "100";
                //}
                else
                {
                    UpdateJobStatusByUserSelection(_jobID, Convert.ToInt32(ddlJobStatus.SelectedValue));
                }

                Fill_JobOrder_Information(_jobID);
            }
        }
    }

    private void OutLookAlert_Requester(string eMail)
    {
        string jobNo = txtJobNo.Text;
        string emailBody = "";
        string SRTitle = txtPrjTitle.Text;

        using (SmtpClient smtpclient = new SmtpClient("10.250.50.201", 587))
        {
            System.Net.Mail.MailMessage mail = new System.Net.Mail.MailMessage();
            MailAddress fromaddress = new MailAddress("EBSD@ashghal.gov.qa");
            mail.From = fromaddress;
            mail.To.Add(eMail);
            mail.Subject = ("eBook Job No. " + txtJobNo.Text + " Completed");
            mail.IsBodyHtml = true;

            mail.Body = "<html><body><i style='font-family:Calibri; font-size:15'>Dear eBook Team,</i><br/><br/><i style='font-family:Calibri; font-size:15'>This is an automated alert from Document & Task Management System.</i><br/><br/><i style='font-family:Calibri;font-size:15'>" +
                                    "Please be noted that</i><i style='color:Maroon;font-family:Calibri; font-size:15'>  Service Request No. " + jobNo + " </i> <i style='font-family:Calibri;font-size:15'> has been completed </i> <i style='font-family:Calibri; font-size:15'> " + emailBody + ":-</i><br /><br />" +
                                    "<table style='width:80%' border='1'><tr><td align='center' colspan='2' style='background-color:Maroon;color:White;font-family:Calibri;font-size:18;font-weight:bold'>Service Request No.: " + jobNo + "</td>" +
                                    "</tr><tr><td style='background-color:#B58AA5;font-family:Calibri;font-size:15'><i>Service Request Title</i></td><td style='font-family:Calibri;font-size:15'>" + SRTitle + "</td></tr>" +
                                    "<tr><td style='background-color:#B58AA5;font-family:Calibri;font-size:15'><i>Service Request URL</i></td><td style='font-family:Calibri;font-size:15'> http://mv2ebdbookp01/ServiceRequest/ServiceRequest/SearchSR?emailID=" + eMail + "&searchSR=SearchServiceRequest" + "</td></tr>" +
                                    "<tr><td style='background-color:#B58AA5;font-family:Calibri;font-size:15'><i>Date of Creation</i></td><td style='font-family:Calibri;font-size:15'>" + Convert.ToDateTime(txtReceivedDate.Text).ToString("dd/MMM/yyyy") + "</td></tr>" +
                                    "<tr><td style='background-color:#B58AA5;font-family:Calibri;font-size:15'><i>Date of Complted</i></td><td style='font-family:Calibri;font-size:15'>" + Convert.ToDateTime(System.DateTime.Now).ToString("dd/MMM/yyyy") + "</td></tr>" +
                                    "</table><br/><br/><div style='font-family:Calibri; font-size:15'>Best Regards,<br/>eBook Team</div></body></html>";

            // mail.Body = "Please be informed that a new Job Order was assigned to you under the above subject. Please log on to eBook Application to see the details of the Job Order.";  

            smtpclient.EnableSsl = true;
            smtpclient.UseDefaultCredentials = true;

            try
            {
                smtpclient.Credentials = new System.Net.NetworkCredential(@"Ashghal\EBSD", ConfigurationManager.AppSettings["passWordForReport"].ToString());
                ServicePointManager.ServerCertificateValidationCallback = delegate(object s, X509Certificate certificate, X509Chain chain, SslPolicyErrors sslPolicyErrors) { return true; };
                smtpclient.Send(mail);
            }
            catch (System.Exception ex)
            {
                //Console.WriteLine(ex);
                //if (ex.InnerException != null)
                //{
                //    Console.WriteLine("InnerException is: {0}", ex.InnerException);
                //}
            }
            finally
            {
                mail.Dispose();
                mail = null;
                // smtpclient = null;
            }
        }
    }
    public void UpdateReOpenStatus(int _jobID, int statusID)
    {
        string upDateQuery = string.Empty;

       // upDateQuery = "UPDATE Job SET jobStatusID =@jobStatusID,jobStatusClosedDate=@jobStatusClosedDate WHERE JobID = @JobID";          // jobClosedDate =@jobClosedDate,

        upDateQuery = "JobReOpen";
                
        SqlConnection sqlCon = new SqlConnection(connValue);
        SqlCommand cmd = new SqlCommand(); // JobReOpen
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.CommandText = upDateQuery;
        cmd.Connection = sqlCon;

       // cmd.Parameters.AddWithValue("@JobID", _jobID);


        //if (statusID == 16) // Re Open
        //    cmd.Parameters.AddWithValue("@jobStatusClosedDate", System.DBNull.Value);
        //else
        //    cmd.Parameters.AddWithValue("@jobStatusClosedDate", System.DateTime.Now.ToString("dd/MMM/yyyy"));

        //if (statusID == 16)
        //    cmd.Parameters.AddWithValue("@jobStatusID", 16);
        //else
        //    cmd.Parameters.AddWithValue("@jobStatusID", statusID);


        cmd.Parameters.AddWithValue("@JobID", _jobID);

        cmd.Parameters.AddWithValue("@contactID", Convert.ToInt32(Session["UserID"]));     

        cmd.Parameters.AddWithValue("@staffIssueDate", System.DBNull.Value);

        cmd.Parameters.AddWithValue("@createDate", Convert.ToDateTime(System.DateTime.Now).ToString("dd/MMM/yyyy"));
        cmd.Parameters.AddWithValue("@createUser", Session["Username"].ToString());

        try
        {
            sqlCon.Open();
            cmd.ExecuteNonQuery();
            sqlCon.Close();
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    public void UpdateJobStatuCompletedsDate(int _jobID, int statusID)
    {
        string upDateQuery = string.Empty;

        upDateQuery = "UPDATE Job SET jobStatusID =@jobStatusID,jobStatusClosedDate=@jobStatusClosedDate WHERE JobID = @JobID";          // jobClosedDate =@jobClosedDate,


        SqlConnection sqlCon = new SqlConnection(connValue);
        SqlCommand cmd = new SqlCommand();
        cmd.CommandText = upDateQuery;
        cmd.Connection = sqlCon;

        cmd.Parameters.AddWithValue("@JobID", _jobID);


        if ((statusID == 3) || (statusID == 16)) // On going
            cmd.Parameters.AddWithValue("@jobStatusClosedDate", System.DBNull.Value);
        else
            cmd.Parameters.AddWithValue("@jobStatusClosedDate", System.DateTime.Now.ToString("dd/MMM/yyyy"));

        if (statusID == 3)
            cmd.Parameters.AddWithValue("@jobStatusID", 3);
        else if  (statusID == 16)
            cmd.Parameters.AddWithValue("@jobStatusID", 16);
        else
            cmd.Parameters.AddWithValue("@jobStatusID", statusID);

        try
        {
            sqlCon.Open();
            cmd.ExecuteNonQuery();
            sqlCon.Close();
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    public void UpdateJobStatusByUserSelection(int _jobID, int statusID)
    {
        string upDateQuery = string.Empty;

        upDateQuery = "UPDATE Job SET jobStatusID =@jobStatusID WHERE JobID = @JobID";          // jobClosedDate =@jobClosedDate,


        using (SqlConnection sqlCon = new SqlConnection(connValue))
        {
            using (SqlCommand cmd = new SqlCommand())
            {
                cmd.CommandText = upDateQuery;
                cmd.Connection = sqlCon;

                cmd.Parameters.AddWithValue("@JobID", _jobID);
                cmd.Parameters.AddWithValue("@jobStatusID", statusID);

                try
                {
                    sqlCon.Open();
                    cmd.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
        }
    }

    private Boolean getStaffStatus()
    {
        Boolean chkStaffStatus = false;

        try
        {
            SqlConnection sqlConn = new SqlConnection(connValue);
            sqlConn.Open();

            string strValue = "SELECT jobOwnerID FROM  JobOwner WHERE (jobID = @JobID) AND (jobOwnerStatusID = 3)";

            SqlCommand sqlCom = new SqlCommand(strValue, sqlConn);
            sqlCom.CommandText = strValue;

            sqlCom.Parameters.AddWithValue("@JobID", _jobID);
            SqlDataReader sqlReader = sqlCom.ExecuteReader();

            if (sqlReader.HasRows)
                chkStaffStatus = true;
            else
                chkStaffStatus = false;

            sqlReader.Close();
            sqlConn.Close();
        }
        catch (Exception ex)
        {
            throw ex;
        }

        return chkStaffStatus;
    }
    protected void btnSearch_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/Guest/SearchClaims.aspx", false);
    }

    protected void ddlStaff_SelectedIndexChanged(object sender, EventArgs e)
    {
        //string sqlQuery = "SELECT  JobType_1.jobTypeName AS jobCategory, JobType.jobTypeName,JobPurpose.jobPurposeID, JobPurpose.jobPurposeName, JobType.CategoryID, JobType.jobTypeID FROM JobTypePurpose INNER JOIN " + 
        //               "  JobType ON JobTypePurpose.jobTypeID = JobType.jobTypeID INNER JOIN JobPurpose ON JobTypePurpose.jobPurposeID = JobPurpose.jobPurposeID INNER JOIN JobType AS JobType_1 ON JobType_1.jobTypeID = JobType.CategoryID " +
        //   "WHERE        (JobType.jobTypeID  = " + ddlJobType.SelectedItem.Value + ")  or (JobPurpose.jobPurposeID in(8,10))";



        //string sqlQuery = "select x.jobTypeID,a.jobtypeid,d.jobPurposeID,x.jobTypeName as jobCategory,a.jobTypeName,d.jobpurposename from JobType a inner join JobType x ON x.jobTypeID = a.CategoryID inner join JobTypePurpose b on a.jobTypeID = b.jobTypeID " +
        //  " inner join JobPurpose d on b.jobPurposeID = d.jobPurposeID where a.jobTypeID = " + ddlJobType.SelectedItem.Value + " order by x.jobTypeID";

        //PopulateDropDownBox(ddlPurpose, sqlQuery, "jobPurposeID", "jobPurposeName"); //  For Distribution -1  // For Review - 8// For Approval - 9// For Action -10 // 14 - For Coordination
    }
    protected void btnDelete_Click(object sender, EventArgs e)
    {
        if (userRightsColl.Contains("4"))
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "Popup", "<script>alert('You have no privilege to Update this Job')</script>", false);
            return;
        }
        else
        {
            if (lblInchargeID.Text == "")
                return;

            int InchargeID = Convert.ToInt32(lblInchargeID.Text);
            new JobOrderData().DeleteIncharge(InchargeID);

            gvJoborder.DataSource = new JobOrderData().GetMngrJobOwnerDetails(_jobID);
            gvJoborder.DataBind();

            reset_StaffData();

            ddlStaff.Enabled = true;

            // ClearStaffData();
        }
    }
    

    #region MyRegion

    private void SendCompletedCallback(SmtpClient smtpclient, System.Net.Mail.MailMessage mail) //private static void SendCompletedCallback(object sender, AsyncCompletedEventArgs e
    {
        try
        {
            smtpclient.Send(mail);
        }
        catch (Exception ex)
        {
            Console.WriteLine(ex);
            if (ex.InnerException != null)
            {
                Console.WriteLine("InnerException is: {0}", ex.InnerException);
            }
        }
        //finally
        //{
        //    mail.Dispose();
        //    mail = null;
        //    // smtpclient = null;
        //}
    }

    private void OutLookAlertQuick(string eMail, string mailBody)
    {
        SmtpClient smtpclient = new SmtpClient("10.250.50.201", 587);
        System.Net.Mail.MailMessage mail = new System.Net.Mail.MailMessage();
        MailAddress fromaddress = new MailAddress("EBSD@ashghal.gov.qa");
        mail.From = fromaddress;
        mail.To.Add(eMail);
        mail.Subject = ("eBook Job No. " + txtJobNo.Text.ToString());
        mail.IsBodyHtml = true;

        // mail.Body = "Please be informed that a new Job Order was assigned to you under the above subject. Please log on to eBook Application to see the details of the Job Order.";

        mail.Body = "<html><body><i style='font-family:Calibri; font-size:15'>Dear eBook Team,</i><br/><br/><i style='font-family:Calibri; font-size:15'>This is an automated alert from Document & Task Management System.</i><br/><br/><i style='font-family:Calibri;font-size:15'>" +
                            "Please be noted that</i><i style='color:Maroon;font-family:Calibri; font-size:15'> Job No. " + txtJobNo.Text.ToString() + "</i><i style='font-family:Calibri; font-size:15'> a new Job Order was assigned to you and the details are as follows:-</i><br /><br />" +
                            "<table style='width:80%' border='1'><tr><td align='center' colspan='2' style='background-color:Maroon;color:White;font-family:Calibri;font-size:18;font-weight:bold'>JOB NO: " + txtJobNo.Text.ToString() + "</td>" +
                             "</tr><tr><td style='background-color:#B58AA5;font-family:Calibri;font-size:15'><i>Contract No / Job Subject </i></td><td style='font-family:Calibri;font-size:15'>" + txtPrjTitle.Text.ToString() + "</td>" +
                            "</tr><tr><td style='background-color:#B58AA5;font-family:Calibri;font-size:15'><i>Contract No / Project Code </i></td><td style='font-family:Calibri;font-size:15'>" + txtCntrNo.Text.ToString() + "</td></tr>" +
                            "<tr><td style='background-color:#B58AA5;font-family:Calibri;font-size:15'><i>eBook URL</i></td><td style='font-family:Calibri;font-size:15'><a href='http://mv2ebdbookp01/eBook/LoginPage.aspx'>http://mv2ebdbookp01/eBook/LoginPage.aspx</a></td></tr>" +
                            "<tr><td style='background-color:#B58AA5;font-family:Calibri;font-size:15'><i>Date of Creation</i></td><td style='font-family:Calibri;font-size:15'>" + System.DateTime.Now + "</td></tr>" +
                            "</table><br/><br/><div style='font-family:Calibri; font-size:15'>Best Regards,<br/>eBook Team</div></body></html>";


        smtpclient.EnableSsl = true;
        smtpclient.UseDefaultCredentials = true;

        try
        {
            smtpclient.Credentials = new System.Net.NetworkCredential(@"Ashghal\EBSD", ConfigurationManager.AppSettings["passWordForReport"].ToString()); //i
            ServicePointManager.ServerCertificateValidationCallback = delegate(object s, X509Certificate certificate, X509Chain chain, SslPolicyErrors sslPolicyErrors) { return true; };

            // Added code for qucik mail

            SendEmail myAction = new SendEmail(SendCompletedCallback);
            myAction.BeginInvoke(smtpclient, mail, null, null);
        }
        catch (System.Exception ex)
        {
            Console.WriteLine(ex);
            if (ex.InnerException != null)
            {
                Console.WriteLine("InnerException is: {0}", ex.InnerException);
            }
        }
        //finally
        //{
        //    //mail.Dispose();
        //    //mail = null;
        //    //// smtpclient = null;
        //}

    }

    private delegate void SendEmail(SmtpClient smtpclient, System.Net.Mail.MailMessage mail);



    #endregion
    protected void btnReceive_Click(object sender, EventArgs e)
    {
        string strUpdateJob = Request.Url.AbsoluteUri;
        try
        {
            if (userRightsColl.Contains("8")) // Access Right is 4 
            {
                ClientScript.RegisterClientScriptBlock(this.GetType(), "Popup", "<script>alert('You have no privilege to add this Document')</script>", false);
                return;
            }
            else
            {
                Session["UrlRef"] = strUpdateJob;
                Session["jobID"] = _jobID;
                Response.Redirect("~/Documents/DocumentDetailsWindow.aspx?RecSentCatID=1&Reply=0", false);
            }
        }
        catch (Exception ex)
        {

        }
    }
    protected void nLinkRec_Click(object sender, EventArgs e)
    {
        Session["CatID"] = "1";
        Session["lnkJobID"] = _jobID;

        if (userRightsColl.Contains("8")) // Access Right is 4 
        {
            Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Don't have the permission to Add Staff ')</script>", false);
            return;
        }
        else
        {
            string url = "/eBook/DCLOg/UploadDoc_DC.aspx"; //  /eBook/DCLOg/UploadDoc_DC.aspx
            string s = "window.open('" + url + "', 'popup_window', 'width=600,height=400,left=100,top=100,resizable=yes');";
            Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "script", s, true);
        }
    }
    protected void btnSent_Click(object sender, EventArgs e)
    {
        string strUpdateJob = Request.Url.AbsoluteUri;
        try
        {
            if (userRightsColl.Contains("8")) // Access Right is 4 
            {
                ClientScript.RegisterClientScriptBlock(this.GetType(), "Popup", "<script>alert('You have no privilege to add Document')</script>", false);
                return;
            }
            else
            {
                Session["DocCategoryID"] = "2";    // It shoul be 2
                Session["DocID"] = null;
                Session["UrlRef"] = strUpdateJob;
                Session["JobID"] = _jobID;
                Response.Redirect("~/Documents/DocumentDetailsWindow.aspx?RecSentCatID=2&Reply=0", false);
            }
        }
        catch (Exception ex)
        {

        }
    }
    protected void btnLinkSent_Click(object sender, EventArgs e)
    {
        Session["CatID"] = "2";
        Session["lnkJobID"] = _jobID;

        if (userRightsColl.Contains("8")) // Access Right is 4 
        {
            Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Don't have the permission to Add Staff')</script>", false);
            return;
        }
        else
        {
            //Response.Redirect("/DCLog/UploadDoc_DC.aspx", false);
            string url = "/eBook/DCLOg/UploadDoc_DC.aspx"; //  /eBook/DCLOg/UploadDoc_DC.aspx
            string s = "window.open('" + url + "', 'popup_window', 'width=600,height=400,left=100,top=100,resizable=yes');";
            Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "script", s, true);

            //string url = "UploadDoc_DC.aspx"; 
            //string s = "window.open('" + url + "', 'popup_window', 'width=600,height=400,left=100,top=100,resizable=yes');";
            //Page.ClientScript.RegisterStartupScript(this.GetType(), "script", s, true);

            // ddlDocRef.Visible = true;

            //if (Session["CatID"].ToString().Equals("2"))
            //    PopulateDropDownBox(ddlDocRef, "SELECT [Document].documentID, [Document].referenceNo, Job.jobID, [Document].docCatID FROM  Job RIGHT OUTER JOIN  [Document] ON Job.docRefID = [Document].documentID " +
            //                  " WHERE (Document.jobID IS NULL)  And (Document.paymentID IS NULL) AND ([Document].docCatID = 2) ORDER BY [Document].createDate", "documentID", "referenceNo");
            //else
            //    PopulateDropDownBox(ddlDocRef, "SELECT [Document].documentID, [Document].referenceNo, Job.jobID, [Document].docCatID FROM  Job RIGHT OUTER JOIN  [Document] ON Job.docRefID = [Document].documentID " +
            //                  " WHERE (Document.jobID IS NULL) And (Document.paymentID IS NULL) AND ([Document].docCatID = 1) ORDER BY [Document].createDate", "documentID", "referenceNo");
        }
    }
    string sentDocID = string.Empty;
    int flag = 0;
    protected void gridReceived_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        string str = Request.Url.AbsoluteUri;
        if (e.CommandName == "VIEWREC")
        {
            if (userRightsColl.Contains("3"))
            {
                ClientScript.RegisterStartupScript(this.GetType(), "alert", "alert('You don't have the rights to open documents');", true);
            }
            else
            {
                LinkButton lnkView = (LinkButton)e.CommandSource;
                recDocID = lnkView.CommandArgument;
                try
                {
                    Session["UrlRef"] = str;
                    Session["JobID"] = _jobID;
                    Response.Redirect("~/Documents/DocumentDetailsWindow.aspx?docRecID=" + recDocID + "&RecSentCatID=1", false);
                }
                catch (Exception ex)
                {
                }
            }
        }

        if (e.CommandName == "ViewFile")
        {
            if (userRightsColl.Contains("3"))
            {
                ClientScript.RegisterStartupScript(this.GetType(), "alert", "alert('You don't have the rights to open documents');", true);
            }
            else
            {

                LinkButton lnkAdd = (LinkButton)e.CommandSource;
                recDocID = lnkAdd.CommandArgument;
                try
                {
                    Session["UrlRef"] = str;
                    Session["JobID"] = _jobID;

                    if ((Session["File_docID"] == null) || (Session["File_docID"] == "0") || recDocID != "0")
                        Session["File_docID"] = recDocID;

                    Session["fileType"] = "";
                    Session["fileType"] = "F";


                    string url = "/eBook/FileUpload.aspx";
                    string s = "window.open('" + url + "', 'popup_window', 'width=810,height=520,left=100,top=100,resizable=yes,scrollbars=yes');";
                    ClientScript.RegisterStartupScript(this.GetType(), "script", s, true);
                }
                catch (Exception ex)
                {

                }
            }
        }
        if (e.CommandName == "ViewAttach")
        {
            if (userRightsColl.Contains("3"))
            {
                ClientScript.RegisterStartupScript(this.GetType(), "alert", "alert('You don't have the rights to open documents');", true);
            }
            else
            {
                LinkButton lnkAdd = (LinkButton)e.CommandSource;
                recDocID = lnkAdd.CommandArgument;
                try
                {
                    Session["UrlRef"] = str;
                    Session["JobID"] = _jobID;

                    if ((Session["File_docID"] == null) || (Session["File_docID"] == "0") || recDocID != "0")
                        Session["File_docID"] = recDocID;

                    Session["fileType"] = "";
                    Session["fileType"] = "A";


                    string url = "/eBook/FileUpload.aspx";
                    string s = "window.open('" + url + "', 'popup_window', 'width=810,height=520,left=100,top=100,resizable=yes,scrollbars=yes');";
                    ClientScript.RegisterStartupScript(this.GetType(), "script", s, true);
                }
                catch (Exception ex)
                {
                }
            }
        }
        if (e.CommandArgument != "")
        {

            int docID = Convert.ToInt32(e.CommandArgument);
            IList<string> docLetterIDs = new List<string>();
            docLetterIDs = (new JobOrderData().chkDocumentRefWithDCJob(_jobID));
            switch (e.CommandName)
            {
                case "RecDeleteDocid":
                    
                    foreach (var item in docLetterIDs)
                    {
                        if (!docID.ToString().Equals(item))
                        {
                            new JobOrderData().DeactivateDocumentForJob(docID);
                            DeleteDistributionForJobIncharge(docID);
                        }                        
                    }

                    if (docLetterIDs.Count != 0)
                    {
                        gridReceived.DataSource = new JobOrderData().getJobDocumetReceivedDate(_jobID);
                        gridReceived.DataBind();
                    }
                    //if (!docID.ToString().Equals(docLetterIDs[0]))
                    //{
                    //    if (!docID.ToString().Equals(docLetterIDs[1]))
                    //    {
                    //        new JobOrderData().DeactivateDocumentForJob(docID);
                    //        DeleteDistributionForJobIncharge(docID);
                    //    }

                    //    gridReceived.DataSource = new JobOrderData().getJobDocumetReceivedDate(_jobID);
                    //    gridReceived.DataBind();
                    //}
                    //else
                    //{
                    //    ClientScript.RegisterStartupScript(this.GetType(), "alert", "alert('You can't delete, This document reference with Job');", true);
                    //}                    
                    break;
            }
        }
    }
    public void DeleteDistributionForJobIncharge(int docID)
    {
        string upDateQuery = "DELETE FROM DOCUMENTDISTRIBUTION WHERE documentID = @docID and JobOwnerID is not null";

        SqlConnection sqlCon = new SqlConnection(connValue);
        SqlCommand cmd = new SqlCommand();
        cmd.CommandText = upDateQuery;
        cmd.Connection = sqlCon;

        cmd.Parameters.AddWithValue("@docID", docID);

        try
        {
            sqlCon.Open();
            cmd.ExecuteNonQuery();
            sqlCon.Close();
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    public void DeleteContractJob(int docID)
    {
        string upDateQuery = "DELETE FROM JobContract WHERE JobContractID = @JobContractID";

        SqlConnection sqlCon = new SqlConnection(connValue);
        SqlCommand cmd = new SqlCommand();
        cmd.CommandText = upDateQuery;
        cmd.Connection = sqlCon;

        cmd.Parameters.AddWithValue("@JobContractID", docID);

        try
        {
            sqlCon.Open();
            cmd.ExecuteNonQuery();
            sqlCon.Close();
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    protected void gridReceived_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            //LinkButton lnkDelete = (LinkButton)e.Row.FindControl("btnDeleteInCharge");
            //lnkDelete.Attributes.Add("onclick", "javascript:return " + "confirm('Are you sure you want to delete this Staff?')");
            //lnkDelete.CssClass = "btndelete";
        }
    }
    string recDocID = string.Empty;
    protected void gridSent_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        string str = Request.Url.AbsoluteUri;
        if (e.CommandName == "VIEWREC")
        {
            if (userRightsColl.Contains("3"))
            {
                ClientScript.RegisterStartupScript(this.GetType(), "alert", "alert('You don't have the rights to open documents');", true);
            }
            else
            {
                LinkButton lnkView = (LinkButton)e.CommandSource;
                recDocID = lnkView.CommandArgument;
                try
                {
                    Session["UrlRef"] = str;
                    Session["JobID"] = _jobID;
                    Response.Redirect("~/Documents/DocumentDetailsWindow.aspx?docRecID=" + recDocID + "&RecSentCatID=1", false);
                }
                catch (Exception ex)
                {
                }
            }
        }

        if (e.CommandName == "ViewFile")
        {
            if (userRightsColl.Contains("3"))
            {
                ClientScript.RegisterStartupScript(this.GetType(), "alert", "alert('You don't have the rights to open documents');", true);
            }
            else
            {
                LinkButton lnkAdd = (LinkButton)e.CommandSource;
                recDocID = lnkAdd.CommandArgument;
                try
                {
                    Session["UrlRef"] = str;
                    Session["JobID"] = _jobID;

                    if ((Session["File_docID"] == null) || (Session["File_docID"] == "0") || recDocID != "0")
                        Session["File_docID"] = recDocID;

                    Session["fileType"] = "";
                    Session["fileType"] = "F";


                    string url = "/eBook/FileUpload.aspx";
                    string s = "window.open('" + url + "', 'popup_window', 'width=810,height=520,left=100,top=100,resizable=yes,scrollbars=yes');";
                    ClientScript.RegisterStartupScript(this.GetType(), "script", s, true);
                }
                catch (Exception ex)
                {

                }
            }
        }
        if (e.CommandName == "ViewAttach")
        {
            if (userRightsColl.Contains("3"))
            {
                ClientScript.RegisterStartupScript(this.GetType(), "alert", "alert('You don't have the rights to open documents');", true);
            }
            else
            {
                LinkButton lnkAdd = (LinkButton)e.CommandSource;
                recDocID = lnkAdd.CommandArgument;
                try
                {
                    Session["UrlRef"] = str;
                    Session["JobID"] = _jobID;

                    if ((Session["File_docID"] == null) || (Session["File_docID"] == "0") || recDocID != "0")
                        Session["File_docID"] = recDocID;

                    Session["fileType"] = "";
                    Session["fileType"] = "A";


                    string url = "/eBook/FileUpload.aspx";
                    string s = "window.open('" + url + "', 'popup_window', 'width=810,height=520,left=100,top=100,resizable=yes,scrollbars=yes');";
                    ClientScript.RegisterStartupScript(this.GetType(), "script", s, true);
                }
                catch (Exception ex)
                {
                }
            }
        }
        if (e.CommandArgument != "")
        {
            int docID = Convert.ToInt32(e.CommandArgument);
            IList<string> docLetterIDs = new List<string>();
            docLetterIDs = (new JobOrderData().chkDocumentRefWithDCJob(_jobID));
            switch (e.CommandName)
            {
                case "RecDeleteDocid":
                    foreach (var item in docLetterIDs)
                    {
                        if (!docID.ToString().Equals(item))
                        {
                            new JobOrderData().DeactivateDocumentForJob(docID);
                           // DeleteDistributionForJobIncharge(docID);
                        }
                        else
                            ClientScript.RegisterClientScriptBlock(this.GetType(), "alert", "alert('You cannot delete, This document reference with Job');", true);
                    }
                    if (docLetterIDs.Count() != 0)
                    {
                        gridReceived.DataSource = new JobOrderData().getJobDocumetReceivedDate(_jobID);
                        gridReceived.DataBind();
                    }
                    break;
                // Added by Varun on 01/Dec/2019
                case "SentDeleteDocid":
                    foreach (var item in docLetterIDs)
                    {
                        if (!docID.ToString().Equals(item))
                        {
                            new JobOrderData().DeactivateDocumentForJob(docID);
                           // DeleteDistributionForJobIncharge(docID);
                        }
                        else
                            ClientScript.RegisterClientScriptBlock(this.GetType(), "alert", "alert('You cannot delete, This document reference with Job');", true);
                    }
                    if (docLetterIDs.Count() != 0)
                    {
                        gridSent.DataSource = new JobOrderData().getJobDocumetSentDate(_jobID);
                        gridSent.DataBind();
                    }
                    break;
            }
        }
    }
    protected void gridSent_RowDataBound(object sender, GridViewRowEventArgs e)
    {

    }
    protected void btnReply_Click(object sender, EventArgs e)
    {
        string strUpdateJob = Request.Url.AbsoluteUri;

        Session["UrlRef"] = strUpdateJob;
        Session["JobID"] = _jobID;

        AccessRightsForReply();
        if ((checkJobStatusCompleteDate(_jobID) == "") & (!userRightsColl.Contains("9")))
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Request Status is still In Progress. Please update the Request Status before closing this Job Order.')</script>", false);
        }
        else
        {
            ReplytoCloseCommittedJobs(_jobID);
        }
    }
    private void AccessRightsForReply()
    {
        if (userRightsColl.Contains("9"))   //Add New Project
        {
            Session["lblText"] = "You are not allowed to directly Reply and Close a Job Order.Please contact system Administrator for further inquiry.";
            Session["lblSub"] = "Restricted Access to Reply and Close a Job Order.";
            Session["lblBody"] = "This is in reference to Restricted Access to Reply and Close a Job Order. I would like to inquire about the restriction.";


            string url = "RestrictedMsgWindow.aspx";
            string s = "window.open('" + url + "', 'popup_window', 'width=500,height=250,left=100,top=100,resizable=yes,scrollbars=yes');";
            ClientScript.RegisterStartupScript(this.GetType(), "script", s, true);
        }

        return;
    }
    private string checkJobStatusCompleteDate(int _jobID)
    {
        string jobStatusClosedDate = string.Empty;
        SqlConnection sqlConn = new SqlConnection(connValue);
        string sqlQuery = "SELECT jobStatusClosedDate From Job Where jobID = '" + _jobID + "' ";

        try
        {
            sqlConn.Open();
            SqlCommand sqlCom = new SqlCommand(sqlQuery, sqlConn);
            SqlDataReader sqlReader = sqlCom.ExecuteReader();
            while (sqlReader.Read())
            {
                jobStatusClosedDate = sqlReader["jobStatusClosedDate"].ToString();
            }
            sqlReader.Close();
        }
        catch (Exception ex)
        {
            Response.Write("Error getting while reading data !" + ex.Message);
        }
        finally
        {
            sqlConn.Close();
        }
        return jobStatusClosedDate;
    }
    private void ReplytoCloseCommittedJobs(int jobid)
    {
        if (userRightsColl.Contains("9"))   //Add New Document
        {
            Session["lblText"] = "You are not allowed to directly Reply and Close a Job Order.Please contact system Administrator for further inquiry.";
            Session["lblSub"] = "Restricted Access to Reply and Close a Job Order.";
            Session["lblBody"] = "This is in reference to Restricted Access to Reply and Close a Job Order. I would like to inquire about the restriction.";

            string url = "RestrictedMsgWindow.aspx";
            string s = "window.open('" + url + "', 'popup_window', 'width=500,height=250,left=100,top=100,resizable=yes,scrollbars=yes');";
            ClientScript.RegisterStartupScript(this.GetType(), "script", s, true);
        }
        else
        {
            if (getJobStatusClosingDate())      //if (Convert.ToBoolean(getJobStatusClosingDate)==true)
            {
                // Session["UrlRef"] = "~/JobOrder/JobOrder.aspx";

                // Session["UrlRef"] = "~/DCLog/DCDetails.aspx";
                Session["JobID"] = jobid;
                Response.Redirect("~/Documents/DocumentDetailsWindow.aspx?RecSentCatID=2&Reply=1", false);
            }
            else
            {
                ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('The job order is not yet completed. Please update the Job Order Status before closing the job.')</script>", false);
            }
        }
    }

    private Boolean getJobStatusClosingDate()
    {
        //jobStatusClosedDate

        return true;
    }
    protected void imgbtn3_Click(object sender, ImageClickEventArgs e)
    {
        Response.Redirect("~/Contracts/ClaimsHomePage.aspx", false);
    }
     
    protected void ddlDocRef_SelectedIndexChanged(object sender, EventArgs e)
    {
        //if (ddlDocRef.SelectedIndex != 0)
        //{
        //    int docID = Convert.ToInt32(ddlDocRef.SelectedValue);

        //    if (Session["lnkJobID"] != null)
        //        new JobOrderData().UpdateJobIDforDocument(Convert.ToInt32(Session["lnkJobID"]), docID);           

        //    if (Session["lnkPayID"] != null)
        //        new JobOrderData().UpdatePayIDforDocument(Convert.ToInt32(Session["lnkPayID"]), docID);
           

        //    AddDistributionData();
        //    CheckandDeleteDistributionData(docID);
        //}

        //Session["lnkJobID"] = null;        
    }

    //private void AddDistributionData()
    //{
    //    //Session["DocID"] = 203;

    //    string sqlQuery = string.Empty;
    //    if (updateJobID != 0) // Not Payment Data
    //        sqlQuery = "SELECT contactID, daysToAct, convert(nvarchar,actionDueDate,103) as ActionDueDate,jobOwnerStatusID,JobOwnerID,distributedBy,docID FROM JobOwner WHERE jobID =" + updateJobID;
    //    else
    //        sqlQuery = "SELECT contactID, daysToAct, convert(nvarchar,actionDueDate,103) as ActionDueDate,jobOwnerStatusID,JobOwnerID,distributedBy,docID FROM JobOwner WHERE payID =" + updatePayID;

    //    DataTable dtJobOwner = GetDataFromDB("JobOwner", sqlQuery);

    //    short jobOwnerCounter = 0;
    //    while (jobOwnerCounter < dtJobOwner.Rows.Count)
    //    {
    //        string InchargeStat = dtJobOwner.Rows[jobOwnerCounter]["jobOwnerStatusID"].ToString();

    //        SqlConnection sqlConn = new SqlConnection(connValue);
    //        SqlCommand sqlCmd = new SqlCommand();
    //        sqlCmd.Connection = sqlConn;

    //        sqlCmd.CommandType = CommandType.StoredProcedure;
    //        sqlCmd.CommandText = "InsertDocDistributionFromJob";
    //        sqlCmd.Parameters.AddWithValue("@contactID", dtJobOwner.Rows[jobOwnerCounter]["contactID"].ToString());


    //        if (InchargeStat != "7")       //
    //        {
    //            sqlCmd.Parameters.AddWithValue("@docPurposeID", 1); //// For Action
    //            sqlCmd.Parameters.AddWithValue("@docStatusID", 1);
    //            sqlCmd.Parameters.AddWithValue("@actionDueDate", DateTime.ParseExact(dtJobOwner.Rows[jobOwnerCounter][2].ToString().Split(' ')[0].Split(' ')[0], "dd/MM/yyyy", CultureInfo.InvariantCulture));
    //            sqlCmd.Parameters.AddWithValue("@daysToReply", dtJobOwner.Rows[jobOwnerCounter]["daysToAct"].ToString());
    //            sqlCmd.Parameters.AddWithValue("@dateread", System.DBNull.Value);
    //        }
    //        else
    //        {
    //            sqlCmd.Parameters.AddWithValue("@docPurposeID", 2);       // For Info
    //            sqlCmd.Parameters.AddWithValue("@docStatusID", 4);
    //            sqlCmd.Parameters.AddWithValue("@actionDueDate", System.DBNull.Value);
    //            sqlCmd.Parameters.AddWithValue("@daysToReply", System.DBNull.Value);
    //            sqlCmd.Parameters.AddWithValue("@dateRead", System.DateTime.Now.ToString("dd/MMM/yyyy"));
    //        }

    //        sqlCmd.Parameters.AddWithValue("@issuedByContactID", dtJobOwner.Rows[jobOwnerCounter]["distributedBy"].ToString());      // Session["UserID"].ToString()
    //        sqlCmd.Parameters.AddWithValue("@createUser", Session["UserName"].ToString());

    //        sqlCmd.Parameters.AddWithValue("@documentID", Convert.ToInt32(Session["lnkdocID"]));
    //        sqlCmd.Parameters.AddWithValue("@inchargeID", dtJobOwner.Rows[jobOwnerCounter]["JobOwnerID"].ToString());

    //        // sqlCmd.Parameters.AddWithValue("@docIssuedDate", System.DateTime.Now.ToString("dd/MMM/yyyy"));
    //        sqlCmd.Parameters.AddWithValue("@docCatID", 1);

    //        sqlConn.Open();
    //        sqlCmd.ExecuteNonQuery();
    //        sqlConn.Close();

    //        jobOwnerCounter++;
    //    }
    //}
    //private void CheckandDeleteDistributionData(int DocID)
    //{
    //    string sqlQuery = "SELECT documentID, docCatID, distributeID, contactID FROM  DocumentDistribution WHERE (documentID IN (SELECT documentID FROM  DocumentDistribution AS Tmp  GROUP BY documentID, contactID HAVING   (COUNT(*) > 1) " +
    //                              " AND (contactID = DocumentDistribution.contactID) AND (documentID = " + DocID + ")))  ORDER BY documentID, docCatID, distributeID";

    //    DataTable dtDocumentDistribution = GetDataFromDB("DocumentDistribution", sqlQuery);

    //    if (dtDocumentDistribution.Rows.Count != 0)
    //        DeleteDistributionData(Convert.ToInt32(dtDocumentDistribution.Rows[0]["distributeID"]));
    //}
    protected void btnGrid_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/Guest/GridViewAddUpdate.aspx", false);
    }
    protected void btnAddContract_Click(object sender, EventArgs e)
    {
        if (ddlCommitNo.SelectedIndex != 0)
        {
            string sqlStatement = "INSERT INTO JobContract (JobID,projectCode,CreateUser,UpdateUser) VALUES(" + _jobID + ",'" + ddlCommitNo.SelectedItem.Text + "','" + Session["UserID"].ToString() + "','" + Session["UserID"].ToString() + "')";

            using (SqlConnection connection = new SqlConnection(connValue))
            {
                connection.Open();
                using (SqlCommand cmd = new SqlCommand(sqlStatement, connection))
                {
                    cmd.CommandType = CommandType.Text;
                    cmd.ExecuteNonQuery();
                }
            }

            string sql = "SELECT       JobContract.JobContractID,JobContract.jobID, CONTRACTORS.contract_no, CONTRACTORS.ContractTitle, TCMS_Company.co_name " +
               " FROM JobContract INNER JOIN CONTRACTORS ON JobContract.projectCode = CONTRACTORS.contract_no COLLATE Latin1_General_CI_AI INNER JOIN " +
                           "  TCMS_Company ON CONTRACTORS.co_id = TCMS_Company.co_id WHERE (JobContract.jobID = " + _jobID + ") order by JobContract.JobContractID";

            GridView1.DataSource = GetDataContract(sql);
            GridView1.DataBind();
        }
        else
        {
            ClientScript.RegisterStartupScript(this.GetType(), "alert", "alert('Please select a Contract Number');", true);
            ddlCommitNo.Focus();
        }
    }
    private DataSet GetDataContract(string query)
    {
        string conString = ConfigurationManager.ConnectionStrings["EBSDEBookConn"].ConnectionString;
        SqlCommand cmd = new SqlCommand(query);
        using (SqlConnection con = new SqlConnection(conString))
        {
            using (SqlDataAdapter sda = new SqlDataAdapter())
            {
                cmd.Connection = con;

                sda.SelectCommand = cmd;
                using (DataSet ds = new DataSet())
                {
                    sda.Fill(ds);
                    return ds;
                }
            }
        }
    }
    protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName.Equals("SelectStaff"))
        {
            string arguments = e.CommandArgument.ToString();
            string[] args = arguments.Split(';');

            IList<string> staffData = new List<string>();
           
            int contractJobID = Convert.ToInt32(args[0]);

            DeleteContractJob(contractJobID);

            string sql = "SELECT     JobContract.JobContractID,  JobContract.jobID, CONTRACTORS.contract_no, CONTRACTORS.ContractTitle, TCMS_Company.co_name " +
       " FROM JobContract INNER JOIN CONTRACTORS ON JobContract.projectCode = CONTRACTORS.contract_no COLLATE Latin1_General_CI_AI INNER JOIN " +
                   "  TCMS_Company ON CONTRACTORS.co_id = TCMS_Company.co_id WHERE (JobContract.jobID = " + _jobID + ") Order by JobContract.JobContractID";

            GridView1.DataSource = GetDataContract(sql);
            GridView1.DataBind();

        }

        //if (e.CommandArgument != "")
        //{
        //    int docID = Convert.ToInt32(e.CommandArgument);
        //    IList<string> docLetterIDs = new List<string>();
        //    docLetterIDs = (new JobOrderData().chkDocumentRefWithDCJob(_jobID));
        //    switch (e.CommandName)
        //    {
        //        case "RecDeleteDocid":

        //            foreach (var item in docLetterIDs)
        //            {
        //                if (!docID.ToString().Equals(item))
        //                {
        //                    new JobOrderData().DeactivateDocumentForJob(docID);
        //                    DeleteDistributionForJobIncharge(docID);
        //                }
        //                else
        //                    ClientScript.RegisterStartupScript(this.GetType(), "alert", "alert('You can't delete, This document reference with Job');", true);
        //            }
                   
        //            if (flag > 0)
        //            {
                        
        //            }
        //            break;
        //    }
        //}
    }
}