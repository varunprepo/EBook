﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

using System.Data.SqlClient;
using System.Data;
using System.Configuration;
using System.Windows.Forms;


/// <summary>
/// Summary description for clsTs_Stage
/// </summary>
public class clsTs_Stage
{

    string connStr = string.Empty; //ConfigurationSettings.AppSettings["TCMSConnString"].ToString();     // By Sree
    DAL dalObj = new DAL("");
    string _userName = string.Empty;
    public clsTs_Stage(string user)
	{
        _userName = user;
	}

    public int GetbidderCount(int prjId)
    {
        Int16 bidCnt = 0;
        try
        {
            using (SqlConnection sqlConn = new SqlConnection(connStr))
            {
                sqlConn.Open();
                // Modified by Varun
                string sqlquery = "SELECT COUNT(ts_tender_issue) AS Expr1 FROM TenderDatesInfo WHERE (proj_id = " + prjId + ") and stage_id=2 and Tender_Issued=1"; //(ts_tender_issue IS NOT NULL) AND 
                SqlCommand cmd = new SqlCommand(sqlquery, sqlConn);
                cmd.CommandTimeout = 80;
                bidCnt = Convert.ToInt16(cmd.ExecuteScalar());
            }
        }
        catch (Exception ex)
        {
            return bidCnt;
        }
        finally
        {
        }
        return bidCnt;
    }

    // Added by Varun
    public int GetShortListCount(int prjId)
    {
        Int16 shortListCnt = 0;
        try
        {
            using (SqlConnection sqlConn = new SqlConnection(connStr))
            {
                sqlConn.Open();
                string sqlquery = "SELECT COUNT(co_id) AS Expr1 FROM TenderDatesInfo WHERE (co_id IS NOT NULL) AND (proj_id = " + prjId + ") and stage_id=2";
                SqlCommand cmd = new SqlCommand(sqlquery, sqlConn);
                cmd.CommandTimeout = 80;
                shortListCnt = Convert.ToInt16(cmd.ExecuteScalar());
            }
        }
        catch (Exception ex)
        {
            return shortListCnt;
        }
        finally
        {
        }
        return shortListCnt;
    }
    public short GetModifiedClosingDateCount(int prjId)
    {
        Int16 circularCnt = 0;
        try
        {
            using (SqlConnection sqlConn = new SqlConnection(connStr))
            {
                sqlConn.Open();
                string sqlquery = "SELECT COUNT(proj_id) FROM tndr_ModifiedDates WHERE (proj_id = " + prjId + ")";
                SqlCommand cmd = new SqlCommand(sqlquery, sqlConn);
                circularCnt = Convert.ToInt16(cmd.ExecuteScalar());
                sqlConn.Close();
            }
        }
        catch (Exception ex)
        {
            return circularCnt;
        }
        finally
        {
        }
        return circularCnt;
    }
    public int GetCircularCount(int prjId)
    {
        int circularCnt = 0;
        try
        {
           
            string sqlquery = "SELECT CircularNo FROM DOCUMENTS WHERE (doc_type_id = 2) and stage_id=2 AND (proj_id = " + prjId + ") and (CircularNo is not NULL) and (date_id IS NULL)";
            
            //circularCnt = dalObj.GetDataFromDB("DocCount", sqlquery).Rows.Count; // By Sree
          
        }
        catch (Exception ex)
        {
            return circularCnt;
        }
        finally
        {
        }
        return circularCnt;
    }
    public string UpdateTenderNo(int prjIDtndr, string tndrNo, string userName, int fiscalID)
    {
        string executionStatus = "";
        try
        {
            using (SqlConnection sqlConn = new SqlConnection(connStr))
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    sqlConn.Open();
                    cmd.Connection = sqlConn;
                    cmd.CommandText = @"UPDATE PROJECTS SET TENDER_NO = @tenderNo,update_Date = @updateDate,update_User = @updateUser,FYID=@FYID  WHERE PROJ_ID = @PROJID ";
                    cmd.Parameters.AddWithValue("@PROJID", prjIDtndr);
                    cmd.Parameters.AddWithValue("@tenderNo", tndrNo);
                    cmd.Parameters.AddWithValue("@FYID", fiscalID);
                    cmd.Parameters.AddWithValue("@updateDate", System.DateTime.Now.ToString());
                    cmd.Parameters.AddWithValue("@updateUser", userName);

                    int exUpdated = cmd.ExecuteNonQuery();
                    cmd.Parameters.Clear();
                    sqlConn.Close();

                    ////MessageBox.Show("Tender Number Created Successfully \n", "Create Tender Number");

                }
            }
        }
        catch (Exception ex)
        {
            ////MessageBox.Show("Error occurred while Creating the TenderNo records, Try again." + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
            // Added by Varun on 10 Feb 2014 for checking the exception occurence and to stop sending email alerts if there is a problem in updating the Tender No.
            executionStatus = "Exception";
        }
        finally
        {
        }
        return executionStatus;
    }
    public int GetStage2DateID(int ts_prjID)
    {
        int dateIDStg2 = 0;
        using (SqlConnection sqlCn = new SqlConnection(connStr))
        {
            sqlCn.Open();
            String readData = "SELECT DATE_ID FROM TenderDatesInfo Where proj_id = " + ts_prjID + " AND stage_id = 2 AND ts_tender_issue is null";
            SqlCommand cmd = new SqlCommand(readData, sqlCn);
            dateIDStg2 = Convert.ToInt16(cmd.ExecuteScalar());

            sqlCn.Close();
        }
        return dateIDStg2;
    }
    public void UpdateTBV_FirstExtension(string TBV_FirstExt, int ts_prjID, int bondValidityDays)
    {
        int _dateIDStg2 = GetStage2DateID(ts_prjID);

        try
        {
            using (SqlConnection sqlConn = new SqlConnection(connStr))
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    sqlConn.Open();
                    cmd.Connection = sqlConn;
                    cmd.CommandText = @"UPDATE TenderDatesInfo SET [tenderbond_validity_ext1]= @TBV_ext,org_tenderbond_to_expire =@tndrBondValidity Where date_id = @dateId";
                    cmd.Parameters.AddWithValue("@dateId", _dateIDStg2);
                    if (TBV_FirstExt != "")
                    {
                        cmd.Parameters.AddWithValue("@TBV_ext", TBV_FirstExt);
                    }
                    else
                    {
                        cmd.Parameters.AddWithValue("@TBV_ext", DBNull.Value);
                    }

                    cmd.Parameters.AddWithValue("@tndrBondValidity", bondValidityDays);
                    int exUpdated = cmd.ExecuteNonQuery();
                    cmd.Parameters.Clear();
                }
            }
        }
        catch (Exception ex)
        {
            ////MessageBox.Show("Error occurred while Updating the UPDATE TenderDatesInfo records, Try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
    public void UpdateTBV_LastExtension(string TBV_LastExt, int ts_prjID, int bondValidityDays)
    {
        int _dateIDStg2 = GetStage2DateID(ts_prjID);
        try
        {
            using (SqlConnection sqlConn = new SqlConnection(connStr))
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    sqlConn.Open();
                    cmd.Connection = sqlConn;
                    cmd.CommandText = @"UPDATE TenderDatesInfo SET [tenderbond_validity_ext2]= @TBV_LstExt,org_tenderbond_to_expire =@tndrBondValidity Where date_id=@dateId";
                    cmd.Parameters.AddWithValue("@dateId", _dateIDStg2);
                    if (TBV_LastExt != "")
                    {
                        cmd.Parameters.AddWithValue("@TBV_LstExt", TBV_LastExt);
                    }
                    else
                    {
                        cmd.Parameters.AddWithValue("@TBV_LstExt", DBNull.Value);
                    }
                    cmd.Parameters.AddWithValue("@tndrBondValidity", bondValidityDays);

                    int exUpdated = cmd.ExecuteNonQuery();
                    cmd.Parameters.Clear();
                }
            }
        }
        catch (Exception ex)
        {
            ////MessageBox.Show("Error occurred while Updating the UPDATE TenderDatesInfo records, Try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
    public void UpdateTV_Original_Extension(int ValidityDays, int dateId)
    {
        // commented by varun on 5 Feb 2014 because can get date_id from the previous function
        //int _dateIDStg2 = GetStage2DateID(ts_prjID);
        try
        {
            using (SqlConnection sqlConn = new SqlConnection(connStr))
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    sqlConn.Open();
                    cmd.Connection = sqlConn;
                    cmd.CommandText = @"UPDATE TenderDatesInfo SET org_tender_to_expire = @tndrValDays Where date_id=@dateId";

                    cmd.Parameters.AddWithValue("@dateId", dateId);

                    cmd.Parameters.AddWithValue("@tndrValDays", ValidityDays);

                    int exUpdated = cmd.ExecuteNonQuery();
                    cmd.Parameters.Clear();
                }
            }
        }
        catch (Exception ex)
        {
            ////MessageBox.Show("Error occurred while Updating the UPDATE TenderDatesInfo records, Try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
    public void UpdateTBV_Original_Extension(int bond_ValidityDays, int dateId)
    {
        // commented by varun on 5 Feb 2014 because can get date_id from the previous function
        //int _dateIDStg2 = GetStage2DateID(ts_prjID);
        try
        {
            using (SqlConnection sqlConn = new SqlConnection(connStr))
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    sqlConn.Open();
                    cmd.Connection = sqlConn;
                    cmd.CommandText = @"UPDATE TenderDatesInfo SET org_tenderbond_to_expire = @tndrValDays Where date_id=@dateId";
                    cmd.Parameters.AddWithValue("@dateId", dateId);

                    cmd.Parameters.AddWithValue("@tndrValDays", bond_ValidityDays);

                    int exUpdated = cmd.ExecuteNonQuery();
                    cmd.Parameters.Clear();
                }
            }
        }
        catch (Exception ex)
        {
            ////MessageBox.Show("Error occurred while Updating the UPDATE TenderDatesInfo records, Try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
    public void UpdateTV_FirstExtension(string TV_FirstExt, int ts_prjID, int ValidityDays)
    {
        int _dateIDStg2 = GetStage2DateID(ts_prjID);
        try
        {
            using (SqlConnection sqlConn = new SqlConnection(connStr))
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    sqlConn.Open();
                    cmd.Connection = sqlConn;
                    cmd.CommandText = @"UPDATE TenderDatesInfo SET [tender_validity_ext1]= @TV_ext1,org_tender_to_expire = @tndrValDays Where date_id=@dateId";
                    cmd.Parameters.AddWithValue("@dateId", _dateIDStg2);
                    if (TV_FirstExt != "")
                    {
                        cmd.Parameters.AddWithValue("@TV_ext1", TV_FirstExt);
                    }
                    else
                    {
                        cmd.Parameters.AddWithValue("@TV_ext1", DBNull.Value);
                    }

                    cmd.Parameters.AddWithValue("@tndrValDays", ValidityDays);

                    int exUpdated = cmd.ExecuteNonQuery();
                    cmd.Parameters.Clear();
                }
            }
        }
        catch (Exception ex)
        {
            ////MessageBox.Show("Error occurred while Updating the UPDATE TenderDatesInfo records, Try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
    public void UpdateTV_LastExtension(string TV_LastExt, int ts_prjID, int validityDays)
    {
        int _dateIDStg2 = GetStage2DateID(ts_prjID);
        try
        {
            using (SqlConnection sqlConn = new SqlConnection(connStr))
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    sqlConn.Open();
                    cmd.Connection = sqlConn;
                    cmd.CommandText = @"UPDATE TenderDatesInfo SET [tender_validity_ext2]= @TV_Lastext1,org_tender_to_expire = @tndrValDays Where date_id=@dateId";
                    cmd.Parameters.AddWithValue("@dateId", _dateIDStg2);
                    if (TV_LastExt != "")
                    {
                        cmd.Parameters.AddWithValue("@TV_Lastext1", TV_LastExt);
                    }
                    else
                    {
                        cmd.Parameters.AddWithValue("@TV_Lastext1", DBNull.Value);
                    }
                    cmd.Parameters.AddWithValue("@tndrValDays", validityDays);

                    int exUpdated = cmd.ExecuteNonQuery();
                    cmd.Parameters.Clear();
                }
            }
        }
        catch (Exception ex)
        {
            ////MessageBox.Show("Error occurred while Updating the UPDATE TenderDatesInfo records, Try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
    public string getMaxTenderNo(string sqlQuery)
    {
        string tendrNo = string.Empty;
        using (SqlConnection sqlConn = new SqlConnection(connStr))
        {
            using (SqlCommand cmd = new SqlCommand(sqlQuery, sqlConn))
            {
                sqlConn.Open();

                using (SqlDataReader dataReader = cmd.ExecuteReader())
                {
                    if (dataReader.HasRows)
                    {
                        while (dataReader.Read())
                        {
                            tendrNo = dataReader[0].ToString();
                        }
                    }
                    else
                    {
                        tendrNo = "";
                    }
                }
                sqlConn.Close();
            }
        }
        return tendrNo;
    }
    public void InsertTS_TenderBond_ProjectCostData(string txtAmont, int stg4_prjID)
    {
        string insertQueryBdgt = "INSERT INTO ProjectCost(stage_id, proj_id, tender_bond) VALUES(@stgID,@PrjID,@tenderBond)";
        using (SqlConnection sqlConn = new SqlConnection(connStr))
        {
            sqlConn.Open();
            using (SqlCommand cmd = new SqlCommand(insertQueryBdgt, sqlConn))
            {
                cmd.Parameters.AddWithValue("@stgID", 4);
                cmd.Parameters.AddWithValue("@PrjID", stg4_prjID);
                if (txtAmont != "")
                {
                    if (txtAmont.Contains("QAR"))
                    {
                        string budjetAmnt = txtAmont.Substring(3, txtAmont.Length - 3);
                        cmd.Parameters.AddWithValue("@tenderBond", Convert.ToDouble(budjetAmnt));
                    }
                    else
                    {
                        string budjetAmnt = txtAmont;
                        cmd.Parameters.AddWithValue("@tenderBond", Convert.ToDouble(budjetAmnt));
                    }
                }
                else
                {
                    cmd.Parameters.AddWithValue("@tenderBond", DBNull.Value);
                }
                int exUpdated = cmd.ExecuteNonQuery();
                cmd.Parameters.Clear();
            }
        }
    }
    public void UpdateTS_TenderBond_ProjectCostData(string tndrBondAmnt, int ts_prjID)
    {
        try
        {
            using (SqlConnection sqlConn = new SqlConnection(connStr))
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    sqlConn.Open();
                    cmd.Connection = sqlConn;
                    cmd.CommandText = @"UPDATE PROJECTCOST SET tender_bond=@tender_bondAmnt where proj_id=@prjID and Stage_id =4";
                    if (tndrBondAmnt != "")
                        cmd.Parameters.AddWithValue("@tender_bondAmnt", Convert.ToDouble(tndrBondAmnt));
                    else
                        cmd.Parameters.AddWithValue("@tender_bondAmnt", System.DBNull.Value);
                    cmd.Parameters.AddWithValue("@prjID", ts_prjID);
                    int exUpdated = cmd.ExecuteNonQuery();
                    cmd.Parameters.Clear();
                }
            }
        }
        catch (Exception ex)
        {
            //MessageBox.Show("Error occurred while Updating the Tender Bond Amount records, Try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
    public void InsertTS_DocFee_ProjectCostData(string txtAmont, int doc_prjID)
    {
        string insertQueryBdgt = "INSERT INTO ProjectCost(stage_id, proj_id, doc_fee) VALUES(@stgID,@PrjID,@docFeeAmnt)";
        using (SqlConnection sqlConn = new SqlConnection(connStr))
        {
            sqlConn.Open();
            using (SqlCommand cmd = new SqlCommand(insertQueryBdgt, sqlConn))
            {
                cmd.Parameters.AddWithValue("@stgID", 4);
                cmd.Parameters.AddWithValue("@PrjID", doc_prjID);
                if (txtAmont != "")
                {
                    if (txtAmont.Contains("QAR"))
                    {
                        string budjetAmnt = txtAmont.Substring(3, txtAmont.Length - 3);
                        cmd.Parameters.AddWithValue("@docFeeAmnt", Convert.ToDouble(budjetAmnt));
                    }
                    else
                    {
                        string budjetAmnt = txtAmont;
                        cmd.Parameters.AddWithValue("@docFeeAmnt", Convert.ToDouble(budjetAmnt));
                    }
                }
                else
                {
                    cmd.Parameters.AddWithValue("@docFeeAmnt", DBNull.Value);
                }

                int exUpdated = cmd.ExecuteNonQuery();
                cmd.Parameters.Clear();
            }
        }
    }
    public void UpdateTS_DocFee_ProjectCostData(string docAmnt, int doc_prjID) // txtDocumentFree
    {
        try
        {
            using (SqlConnection sqlConn = new SqlConnection(connStr))
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    sqlConn.Open();
                    cmd.Connection = sqlConn;
                    cmd.CommandText = @"UPDATE PROJECTCOST SET doc_fee=@doc_feeAmnt where proj_id=@prjID and Stage_ID = 4";
                    if (docAmnt != "")
                        cmd.Parameters.AddWithValue("@doc_feeAmnt", Convert.ToDouble(docAmnt));
                    else
                        cmd.Parameters.AddWithValue("@doc_feeAmnt", System.DBNull.Value);
                    cmd.Parameters.AddWithValue("@prjID", doc_prjID);
                    int exUpdated = cmd.ExecuteNonQuery();
                    cmd.Parameters.Clear();
                }
            }
        }
        catch (Exception ex)
        {
            //MessageBox.Show("Error occurred while Updating the Tender Doc Amount records, Try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
    public void GetCommitee_FiscalYear(ref int cmt_ID, ref int fiscalYear_ID, ref string _cmtShortName, ref string fiscalYear, int tndr_prjiD)
    {
        string sqlQuery = "SELECT  Committee.committee_id, [FiscalYear].FYID, Committee.committee_short_name, [FiscalYear].FiscalYear " +
           " FROM PROJECTS INNER JOIN Committee ON PROJECTS.committee_id = Committee.committee_id INNER JOIN [FiscalYear] ON PROJECTS.FYID = [FiscalYear].FYID INNER JOIN " +
            " [TenderTypes] ON PROJECTS.tender_type_id = [TenderTypes].tender_type_id WHERE (PROJECTS.proj_id = " + tndr_prjiD + ")";

        using (SqlConnection sqlConn = new SqlConnection(connStr))
        {
            using (SqlCommand cmd = new SqlCommand(sqlQuery, sqlConn))
            {
                sqlConn.Open();
                using (SqlDataReader dataReader = cmd.ExecuteReader())
                {
                    if (dataReader.HasRows)
                    {
                        while (dataReader.Read())
                        {
                            cmt_ID = Convert.ToInt16(dataReader[0]);
                            fiscalYear_ID = Convert.ToInt16(dataReader[1]);
                            _cmtShortName = dataReader[2].ToString();
                            fiscalYear = dataReader[3].ToString();
                        }
                    }
                }
            }
        }
    }
    public void GetCommitee_FiscalYear(ref int cmt_ID, ref int fiscalYear_ID, ref string _cmtShortName, ref string fiscalYear, int tndr_prjiD, ref string tndrTypeName, ref string _userDept, ref string prjCreated, ref string _Affairs)
    {
        string sqlQuery = "SELECT Committee.committee_id, FiscalYear.FYID, Committee.committee_short_name, FiscalYear.FiscalYear,TenderTypes.tender_type_name, " +     //TenderTypes.tender_type_name
                 " Department.Department, PROJECTS.create_date,AFFAIRS.Affairs_Name " +
                 " FROM PROJECTS INNER JOIN " +
                  " Committee ON PROJECTS.committee_id = Committee.committee_id INNER JOIN " +
                 " FiscalYear ON PROJECTS.FYID = FiscalYear.FYID INNER JOIN " +
                 " TenderTypes ON PROJECTS.tender_type_id = TenderTypes.tender_type_id INNER JOIN " +
                  " Department ON PROJECTS.department_id = Department.department_id INNER JOIN AFFAIRS ON PROJECTS.Affair_id = AFFAIRS.Affair_id  " +
                   " WHERE (PROJECTS.proj_id = " + tndr_prjiD + ") ";

        SqlDataReader dataReader = null;
        SqlCommand cmd = null;
        using (SqlConnection sqlConn = new SqlConnection(connStr))
        {
            using (cmd = new SqlCommand(sqlQuery, sqlConn))
            {
                sqlConn.Open();
                using (dataReader = cmd.ExecuteReader())
                {
                    //    if (dataReader.HasRows)
                    //    {
                    if (dataReader.Read())
                    {
                        cmt_ID = Convert.ToInt16(dataReader[0]);
                        fiscalYear_ID = Convert.ToInt16(dataReader[1]);
                        _cmtShortName = dataReader[2].ToString();
                        fiscalYear = dataReader[3].ToString();
                        //fiscalYear = "2014-2015";
                        tndrTypeName = dataReader[4].ToString();
                        _userDept = dataReader[5].ToString();
                        prjCreated = dataReader[6].ToString();
                        _Affairs = dataReader[7].ToString();
                    }

                    //Added by Varun on 31 May 2015 (Change in Fiscal Year Requirement)
                    dataReader.Close();
                    if (Convert.ToInt16(fiscalYear.Split('-')[0]) < DateTime.Today.Subtract(TimeSpan.FromDays(365)).Year)
                    {
                        fiscalYear_ID = --fiscalYear_ID;
                        cmd.Dispose();
                        cmd = new SqlCommand("select FiscalYear from FiscalYear where FYID=" + fiscalYear_ID, sqlConn);
                        dataReader = cmd.ExecuteReader();
                        dataReader.Read();
                        fiscalYear = dataReader["FiscalYear"].ToString();
                    }
                    //}
                }
            }
        }


    }

    // Added by Varun on 5 Feb 2014 
    public void GetAffairsName(int tndr_prjiD, ref string deptName, ref string affairName)
    {
        string sqlQuery = "SELECT Department.Department,AFFAIRS.Affairs_Name " +
                 " FROM PROJECTS INNER JOIN " +
                  " Committee ON PROJECTS.committee_id = Committee.committee_id INNER JOIN " +
                 " FiscalYear ON PROJECTS.FYID = FiscalYear.FYID INNER JOIN " +
                 " TenderTypes ON PROJECTS.tender_type_id = TenderTypes.tender_type_id INNER JOIN " +
                  " Department ON PROJECTS.department_id = Department.department_id INNER JOIN AFFAIRS ON PROJECTS.Affair_id = AFFAIRS.Affair_id  " +
                   " WHERE (PROJECTS.proj_id = " + tndr_prjiD + ") ";

        using (SqlConnection sqlConn = new SqlConnection(connStr))
        {
            using (SqlCommand cmd = new SqlCommand(sqlQuery, sqlConn))
            {
                sqlConn.Open();
                using (SqlDataReader dataReader = cmd.ExecuteReader())
                {
                    if (dataReader.HasRows)
                    {
                        while (dataReader.Read())
                        {
                            deptName = dataReader[0].ToString();
                            affairName = dataReader[1].ToString();
                        }
                    }
                }
            }
        }

    }

    //Modified by Varun on 11/01/2016 Accessing FiscalID of the current year instead FiscalID of the project that is being getting transferred
    public void GetCommitee_FiscalYear_For_Transfor(ref int cmt_ID, ref int fiscalYear_ID, ref string _cmtShortName, ref string fiscalYear, int tndr_prjiD, ref string tndrTypeName, ref string _userDept, ref string prjCreated, ref string _Affairs)
    {
        string sqlQuery = "SELECT Committee.committee_id, Committee.committee_short_name,TenderTypes.tender_type_name, " +     //TenderTypes.tender_type_name
        " Department.Department, PROJECTS.create_date,AFFAIRS.Affairs_Name FROM PROJECTS INNER JOIN Committee ON PROJECTS.committee_id = Committee.committee_id INNER JOIN " +
        " FiscalYear ON PROJECTS.FYID = FiscalYear.FYID INNER JOIN " +
        " TenderTypes ON PROJECTS.tender_type_id = TenderTypes.tender_type_id INNER JOIN " +
        " Department ON PROJECTS.department_id = Department.department_id INNER JOIN AFFAIRS ON PROJECTS.Affair_id = AFFAIRS.Affair_id  " +
        " WHERE (PROJECTS.proj_id = " + tndr_prjiD + ") ";

        using (SqlConnection sqlConn = new SqlConnection(connStr))
        {
            SqlCommand cmd = null;
            using (cmd = new SqlCommand(sqlQuery, sqlConn))
            {
                sqlConn.Open();
                SqlDataReader dataReader = null;
                using (dataReader = cmd.ExecuteReader())
                {
                    if (dataReader.HasRows)
                    {
                        while (dataReader.Read())
                        {
                            cmt_ID = Convert.ToInt16(dataReader[0]);
                            _cmtShortName = dataReader[1].ToString();
                            tndrTypeName = dataReader[2].ToString();
                            _userDept = dataReader[3].ToString();
                            prjCreated = dataReader[4].ToString();
                            _Affairs = dataReader[5].ToString();
                        }
                        dataReader.Close();
                        cmd.Dispose();
                        sqlQuery = "select FYID from FiscalYear where FiscalYear='" + DateTime.Now.Year + "'";
                        using (cmd = new SqlCommand(sqlQuery, sqlConn))
                        {
                            using (dataReader = cmd.ExecuteReader())
                            {
                                if (dataReader.Read())
                                {
                                    fiscalYear_ID = Convert.ToInt16(dataReader[0]);
                                    fiscalYear = DateTime.Now.Year.ToString();
                                }
                                dataReader.Close();
                                cmd.Dispose();
                            }
                        }

                    }
                }
            }
        }

    }

    public void GetCommitee_FiscalYear(ref int cmt_ID, ref int fiscalYear_ID, ref string _cmtShortName, ref string fiscalYear, ref string tndrTypeName, ref string _userDept, ref string prjCreated, int tndr_prjiD)
    {
        //string sqlQuery = "SELECT  Committee.committee_id, [FiscalYear].FYID, Committee.committee_short_name, [FiscalYear].FiscalYear " +
        //   " FROM PROJECTS INNER JOIN Committee ON PROJECTS.committee_id = Committee.committee_id INNER JOIN [FiscalYear] ON PROJECTS.FYID = [FiscalYear].FYID INNER JOIN " +
        //    " [TenderTypes] ON PROJECTS.tender_type_id = [TenderTypes].tender_type_id WHERE (PROJECTS.proj_id = " + tndr_prjiD + ")";


        string sqlQuery = "SELECT Committee.committee_id, FiscalYear.FYID, Committee.committee_short_name, FiscalYear.FiscalYear,TenderTypes.tender_type_name, " +     //TenderTypes.tender_type_name
                  " Department.Department, PROJECTS.create_date " +
                  " FROM PROJECTS INNER JOIN " +
                   " Committee ON PROJECTS.committee_id = Committee.committee_id INNER JOIN " +
                  " FiscalYear ON PROJECTS.FYID = FiscalYear.FYID INNER JOIN " +
                  " TenderTypes ON PROJECTS.tender_type_id = TenderTypes.tender_type_id INNER JOIN " +
                   " Department ON PROJECTS.department_id = Department.department_id " +
                    " WHERE     (PROJECTS.proj_id = " + tndr_prjiD + ") ";

        using (SqlConnection sqlConn = new SqlConnection(connStr))
        {
            using (SqlCommand cmd = new SqlCommand(sqlQuery, sqlConn))
            {
                sqlConn.Open();
                using (SqlDataReader dataReader = cmd.ExecuteReader())
                {
                    if (dataReader.HasRows)
                    {
                        while (dataReader.Read())
                        {
                            cmt_ID = Convert.ToInt16(dataReader[0]);
                            fiscalYear_ID = Convert.ToInt16(dataReader[1]);
                            _cmtShortName = dataReader[2].ToString();
                            fiscalYear = dataReader[3].ToString();
                            tndrTypeName = dataReader[4].ToString();
                            _userDept = dataReader[5].ToString();
                            prjCreated = dataReader[6].ToString();
                        }
                    }
                }
            }
        }
    }  

}