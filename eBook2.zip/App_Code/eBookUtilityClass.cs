﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Configuration;
using System.Data.SqlClient;

/// <summary>
/// Summary description for eBookUtilityClass
/// </summary>
public class eBookUtilityClass : System.Web.UI.Page
{
    System.Web.UI.Page pageCls = null;
    private string connValue = ConfigurationManager.ConnectionStrings["EBSDEBookConn"].ToString();
	public eBookUtilityClass(System.Web.UI.Page page)
	{
        pageCls = page;
	}
    public void CheckUserAuthentication()
    {

        string strQuery = "SELECT  Contact.firstName + '  ' + Contact.lastName AS displayName, Contact.emailAddress, Contact.contactID, Contact.companyID, UserSecurityProfile.profileName, " +
                        " Contact.systemUserName, Contact.sectionID, Contact.isActive, Contact.userProfileID, Section.sectionName,Contact.userName, Contact.password " +
                          " FROM Contact INNER JOIN " +
                          " Section ON Contact.sectionID = Section.sectionID INNER JOIN " +
                         " UserSecurityProfile ON Contact.userProfileID = UserSecurityProfile.userProfileID WHERE (Contact.userName = @userName)";

        SqlConnection SqlConnection = new System.Data.SqlClient.SqlConnection(connValue);
        SqlConnection.Open();
        SqlCommand sqlCmd = new SqlCommand();
        sqlCmd.Connection = SqlConnection;
        sqlCmd.CommandText = strQuery;
               
        SqlDataReader sqlDtRead = sqlCmd.ExecuteReader();
        if (sqlDtRead.HasRows)
        {
            while (sqlDtRead.Read())
            {
                Session["UserDisplayName"] = sqlDtRead["displayName"].ToString().Trim();
                Session["IssuedByEmailAddress"] = sqlDtRead["emailAddress"].ToString();
                Session["UserID"] = sqlDtRead["contactID"].ToString();
                Session["CmpID"] = sqlDtRead["companyID"].ToString();
                Session["ProfileName"] = sqlDtRead["profileName"].ToString();
               // Session["UserName"] = sqlDtRead["systemUserName"].ToString();

                Session["UserName"] = sqlDtRead["userName"].ToString(); 

                Session["SectionID"] = sqlDtRead["sectionID"].ToString();
                Session["IsActive"] = sqlDtRead["isActive"].ToString();
                Session["userProfileID"] = sqlDtRead["userProfileID"].ToString();
                Session["SectionName"] = sqlDtRead["sectionName"].ToString();
            }
        }
        sqlDtRead.Close();
        SqlConnection.Close();
    }
    public IList<string> GetUserAccessList(string userID, IList<string> userRightsColl)
    {
        SqlConnection sqlConn = new SqlConnection(connValue);
        string sqlQuery = "SELECT UserPrivilege.accessID FROM UserSecurityProfile INNER JOIN UserPrivilege ON UserSecurityProfile.userProfileID = UserPrivilege.userProfileID INNER JOIN Contact ON UserSecurityProfile.userProfileID = Contact.userProfileID " +
        "WHERE (UserPrivilege.hasPrivilege = 0) AND (Contact.contactID = " + userID + ")";

        try
        {
            sqlConn.Open();
            SqlCommand sqlCom = new SqlCommand(sqlQuery, sqlConn);
            SqlDataReader sqlReader = sqlCom.ExecuteReader();
            while (sqlReader.Read())
                userRightsColl.Add(sqlReader[0].ToString());
            sqlReader.Close();
        }
        catch (Exception ex)
        {
           
        }
        finally
        {
            sqlConn.Close();
        }
        return userRightsColl;
    }
    
}