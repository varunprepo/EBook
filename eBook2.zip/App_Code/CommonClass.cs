﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

using System.Net.Mail;

using System.Runtime.Serialization.Formatters.Binary;
using System.IO;

using System.Diagnostics;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;
using System.Text;
using Spire.Doc;
using System.Drawing;


/// <summary>
/// Summary description for CommonClass
/// </summary>
public class CommonClass
{
    SqlCommand sqlCmd;
    SqlDataReader sqlDtReader;
    SqlConnection sqlConn = null;
    string connStr = ConfigurationManager.ConnectionStrings["EBSDEBookConn"].ToString();

    static string _userName = string.Empty;        
   
    public CommonClass(string user)
	{
        _userName = user;
	}


    private string getUserFullName(string _userName)
    {
        string strActualName = string.Empty;
        SqlConnection cn = new SqlConnection(connStr);
        cn.Open();
        string strQuery = "SELECT  actual_name FROM USERS where user_name = '" + _userName + "' ";
        SqlCommand cmd = new SqlCommand(strQuery, cn);

        using (SqlDataReader dr = cmd.ExecuteReader())
        {
            while (dr.Read())
            {
                strActualName = dr[0].ToString();
            }
        }
        return strActualName;
    }

    public int DateDiff(string inputDate)
    {
        DateTime startdate;
        DateTime enddate;
        TimeSpan remaindate;

        startdate = DateTime.Parse(System.DateTime.Now.ToString()).Date;
        enddate = DateTime.Parse(inputDate).Date;

        remaindate = enddate - startdate;

        return Convert.ToInt16(remaindate.TotalDays);
    }

    public string getUserEmailID(string _userName)
    {
        string emailAddress = null;
        SqlConnection cn = new SqlConnection(connStr);
        try
        {
            cn.Open();
            string strQuery = "SELECT email_address FROM USERS where user_name = '" + _userName + "' ";
            SqlCommand cmd = new SqlCommand(strQuery, cn);

            using (SqlDataReader dr = cmd.ExecuteReader())
            {
                while (dr.Read())
                {
                    emailAddress = dr["email_address"].ToString();
                }
            }
        }
        catch (Exception ex)
        {
        }
        finally
        {
            cn.Close();
        }
        return emailAddress;
    }

    // Added by Varun on 02/02/14 for creating a reusable function  // By Sree
    ////public void ExportToExcel(WebBrowser wbReport)
    ////{

    ////    try
    ////    {
    ////        // Added by Varun for storing the exported file in excel format only on 25/02/14 based on Adonis request
    ////        SaveFileDialog saveFileDialog1 = new SaveFileDialog();
    ////        // commented by Varun on 31/May/2015 Excel Format|*.xlsx is not working Excel 97-2003 WorkBook|*.xls|Excel WorkBook|*.xlsx
    ////        saveFileDialog1.Filter = "Excel 97-2003 WorkBook|*.xls";
    ////        saveFileDialog1.Title = "Save an Excel File";
    ////        saveFileDialog1.ShowDialog();
    ////        //string strFileName = "ExportExcel.xls";
    ////        //saveFileDialog1.FileName = "ExportExcel.xls";
    ////        string strFileName = saveFileDialog1.FileName.ToString();
    ////        StreamWriter writer = new StreamWriter(strFileName);
    ////        writer.Write(wbReport.DocumentText.ToString());
    ////        writer.Close();
    ////    }
    ////    catch (Exception ex)
    ////    {
    ////        string exMsg = ex.Message;
    ////    }
    ////} 

    //public void DisplayContractNumber(Label lblContractNoDisplay, Label lblContractNo, Button btnWorkOrder, int prjID) // By Sree
    //{
    //    clsDatabase clsDB = new clsDatabase(ConfigurationManager.AppSettings["TCMSConnString"].ToString());
    //    clsDB.ConnectDB();
    //    sqlDtReader = clsDB.ExecuteReader1("SELECT CONTRACTORS.contract_no FROM CONTRACTORS INNER JOIN COMPANY ON " +
    //    "CONTRACTORS.co_id = COMPANY.co_id  WHERE (CONTRACTORS.proj_id = " + prjID + " and CONTRACTORS.stage_id=4) " +
    //    " and CONTRACTORS.contract_no is not Null", 'C'); //
    //    if (sqlDtReader.HasRows)
    //    {
    //        sqlDtReader.Read();
    //        string contractNo = sqlDtReader[0].ToString();
    //        if (contractNo != "")
    //        {
    //            lblContractNoDisplay.Visible = true;
    //            lblContractNo.Visible = true;
    //            lblContractNoDisplay.Text = contractNo;
    //            if (contractNo.Contains("Frame") || contractNo.Contains("order"))
    //            {
    //                btnWorkOrder.Visible = true;
    //            }
    //        }
    //    }
    //    sqlDtReader.Close();

    //    sqlDtReader = clsDB.ExecuteReader1("SELECT workOrderID FROM WorkOrders WHERE (proj_id = " + prjID + ")", 'C');
    //    if (sqlDtReader.HasRows)
    //    {
    //        btnWorkOrder.Visible = true;
    //    }
    //    sqlDtReader.Close();
    //    clsDB.DisconnectDB();
    //} 

    public static char isSaved = 'N';
    public static int prjID = 0;

    //public DataTable PopulateComboBox(ComboBox cmbBox, string sqlQuery, string valueMember, string displayName)
    //{
    //    DataTable table = new DataTable();
    //    try
    //    {
    //        using (SqlConnection sqlConn = new SqlConnection(connStr))
    //        {
    //            using (SqlDataAdapter da = new SqlDataAdapter(sqlQuery, sqlConn))
    //                da.Fill(table);
    //            sqlConn.Close();
    //        }
    //        cmbBox.DataSource = table;
    //        cmbBox.DisplayMember = displayName;
    //        cmbBox.ValueMember = valueMember;
    //        cmbBox.SelectedIndex = -1;

    //    }
    //    catch (Exception ex)
    //    {
    //        table = null;
    //    }
    //    return table;
    //}

    //public DataTable PopulateComboBox1(ComboBox cmbBox, string sqlQuery, string valueMember, string displayName)
    //{
    //    DataTable table = new DataTable();
    //    try
    //    {
    //        using (SqlConnection sqlConn = new SqlConnection(connStr))
    //        {
    //            using (SqlDataAdapter da = new SqlDataAdapter(sqlQuery, sqlConn))
    //                da.Fill(table);
    //            sqlConn.Close();
    //        }
    //        short rowCounter = 0;
    //        DataTable dtCmpDetails = new DataTable();
    //        dtCmpDetails.Columns.Add("CO_NAME");
    //        dtCmpDetails.Columns.Add("Ids");
    //        dtCmpDetails.AcceptChanges();

    //        while (rowCounter < table.Rows.Count)
    //        {
    //            DataRow dr = dtCmpDetails.NewRow();
    //            dr[0] = table.Rows[rowCounter][2];
    //            dr[1] = table.Rows[rowCounter][0] + "," + table.Rows[rowCounter][1];
    //            dtCmpDetails.Rows.Add(dr);
    //            dtCmpDetails.AcceptChanges();
    //            rowCounter++;
    //        }

    //        cmbBox.DataSource = dtCmpDetails;
    //        cmbBox.DisplayMember = "CO_NAME";
    //        cmbBox.ValueMember = "Ids";
    //        cmbBox.SelectedIndex = -1;

    //    }
    //    catch (Exception ex)
    //    {
    //        table = null;
    //    }
    //    return table;
    //}

    // Moved by Varun on 24/02/14 from frmTenderExpiry.cs file to make it resuable function 
    //public string SelectTextFile(string initialDirectory)      // By Sree
    //{
    //    string strFile = string.Empty;
    //    SaveFileDialog saveFileDialog1 = new SaveFileDialog();
    //    saveFileDialog1.Filter = "Excel Path|*.xls|Excel Format|*.xlsx";
    //    saveFileDialog1.Title = "Save an Excel File";
    //    saveFileDialog1.ShowDialog();

    //    // If the file name is not an empty string open it for saving.
    //    if (saveFileDialog1.FileName != "")
    //    {
    //        try
    //        {
    //            // Saves the Image via a FileStream created by the OpenFile method.
    //            System.IO.FileStream fs =
    //               (System.IO.FileStream)saveFileDialog1.OpenFile();
    //            strFile = saveFileDialog1.FileName;
    //            fs.Close();
    //        }
    //        catch (Exception)
    //        {
    //            MessageBox.Show("Error Occurred!! Please close the file already opened, then try to save the file again");
    //        }
    //    }
    //    return strFile;
    //}

    // Added by Varun on 24/02/14 for exporting the company details to excel sheet 
    //public void export_datagridview_to_excel(DataGridView dgv, string excel_file, char chCompany)
    //{
    //    int cols;
    //    //open file
    //    if (excel_file == "")
    //    {
    //        return;
    //    }
    //    StreamWriter wr = new StreamWriter(excel_file);

    //    //determine the number of columns and write columns to file
    //    cols = dgv.Columns.Count;
    //    for (int i = 1; i < cols - 1; i++)
    //    {
    //        wr.Write(dgv.Columns[i].HeaderText.ToString().ToUpper() + "\t");
    //    }

    //    wr.WriteLine();

    //    //write rows to excel file
    //    for (int i = 0; i < (dgv.Rows.Count - 1); i++)
    //    {
    //        for (int j = 1; j < cols - 1; j++)
    //        {
    //            if (dgv.Rows[i].Cells[j].Value != null)
    //                wr.Write(dgv.Rows[i].Cells[j].Value + "\t");
    //            else
    //            {
    //                wr.Write("\t");
    //            }
    //        }

    //        wr.WriteLine();
    //    }

    //    //close file
    //    wr.Close();

    //    MessageBox.Show("Data Exported Successfully");
    //} // By Sree

    // Moved by Varun on 24/02/14 from frmTenderExpiry.cs file to make it resuable function
    //public void export_datagridview_to_excel(DataGridView dgv, string excel_file)
    //{
    //    int cols;
    //    //open file
    //    if (excel_file == "")
    //    {
    //        return;
    //    }
    //    StreamWriter wr = new StreamWriter(excel_file);

    //    //determine the number of columns and write columns to file
    //    cols = dgv.Columns.Count;
    //    for (int i = 0; i < cols; i++)
    //    {
    //        if (i != 1) // added by Varun on 24/02/14 for skipping the proj_id column 
    //            wr.Write(dgv.Columns[i].HeaderText.ToString().ToUpper() + "\t");
    //    }

    //    wr.WriteLine();

    //    //write rows to excel file
    //    for (int i = 0; i < (dgv.Rows.Count - 1); i++)
    //    {
    //        for (int j = 0; j < cols; j++)
    //        {
    //            if (j != 1)
    //            {
    //                if (dgv.Rows[i].Cells[j].Value != null)
    //                    wr.Write(dgv.Rows[i].Cells[j].Value + "\t");
    //                else
    //                {
    //                    wr.Write("\t");
    //                }
    //            }
    //        }

    //        wr.WriteLine();
    //    }

    //    //close file
    //    wr.Close();

    //    MessageBox.Show("Data Exported Successfully");
    //}    // By Sree
    // Added by Varun on 10 Feb 2014 for checking the affairs rights assigned to particular user
    public string checkAccessRightsForAffairs(IList<string> userRightsColl, string affairShortName)
    {
        if (!userRightsColl.Contains("61"))
        {
            affairShortName = "All";
            return affairShortName;
        }
        if (!userRightsColl.Contains("62"))
        {
            affairShortName = "'BA'";
        }
        if (!userRightsColl.Contains("63"))
        {
            if (affairShortName == "")
                affairShortName = "'IA-D'" + "," + "'IA-R'";
            else
                affairShortName = affairShortName + "," + "'IA-D'" + "," + "'IA-R'";
        }
        if (!userRightsColl.Contains("64"))
        {
            if (affairShortName == "")
                affairShortName = "'JSA'";
            else
                affairShortName = affairShortName + "," + "'JSA'";
        }
        if (!userRightsColl.Contains("65"))
        {
            if (affairShortName == "")
                affairShortName = "'TSA'";
            else
                affairShortName = affairShortName + "," + "'TSA'";
        }
        if (!userRightsColl.Contains("66"))
        {
            if (affairShortName == "")
                affairShortName = "'AA'";
            else
                affairShortName = affairShortName + "," + "'AA'";
        }
        if (!userRightsColl.Contains("67"))
        {
            if (affairShortName == "")
                affairShortName = "'PO'";
            else
                affairShortName = affairShortName + "," + "'PO'";
        }
        return affairShortName;
    }

    // Added by Varun on 10 Feb 2014 for checking the Committee rights assigned to particular user
    public string checkAccessRightsForCommittee(IList<string> userRightsColl, string committeeShortName)
    {
        if (!userRightsColl.Contains("54") || !userRightsColl.Contains("61"))
        {
            committeeShortName = "All";
            return committeeShortName;
        }
        if (!userRightsColl.Contains("55"))
        {
            committeeShortName = "'" + "GTC" + "'";
        }
        if (!userRightsColl.Contains("56"))
        {
            if (committeeShortName == "")
                committeeShortName = "'" + "STC" + "'";
            else
                committeeShortName = committeeShortName + "," + "'" + "STC" + "'";
        }
        if (!userRightsColl.Contains("57"))
        {
            if (committeeShortName == "")
                committeeShortName = "'" + "ITC" + "'";
            else
                committeeShortName = committeeShortName + "," + "'" + "ITC" + "'";
        }
        if (!userRightsColl.Contains("58"))
        {
            if (committeeShortName == "")
                committeeShortName = "'" + "MRPSC" + "'";
            else
                committeeShortName = committeeShortName + "," + "'" + "MRPSC" + "'";

        }
        if (!userRightsColl.Contains("59"))
        {
            if (committeeShortName == "")
            {
                //commented by Varun on 11/08/14                     
                //cmbCommittee.Items.Add("U&EWTC");
                committeeShortName = "'" + "EUWC" + "'";
            }
            else
            {
                //commented by Varun on 11/08/14                     
                //committeeShortName = committeeShortName + "," + "'" + "U&EWTC" + "'";
                committeeShortName = committeeShortName + "," + "'" + "EUWC" + "'";
            }
        }
        if (!userRightsColl.Contains("60"))
        {
            if (committeeShortName == "")
                committeeShortName = "'" + "WPC" + "'";
            else
                committeeShortName = committeeShortName + "," + "'" + "WPC" + "'";
        }
        if (committeeShortName == "")
            committeeShortName = "'" + "NC" + "'";
        else
            committeeShortName = committeeShortName + "," + "'" + "NC" + "'";

        if (committeeShortName == "")
            committeeShortName = "'NC'";
        return committeeShortName;
        //buildSqlQuery.Append(" and AFFAIRS.Affairs_Short_name in(" + affairShortName + ") ORDER BY PROJECTS.dummyfield DESC");            

    }

    // Added by Varun on 18 Feb 2014 for checking the Committee rights assigned to particular user
    public StringBuilder SetFilteredQuery(StringBuilder sqlBuildQuery, string committeeShortName, string affairShortName, string orderByClause)
    {
        if (!committeeShortName.Contains("All") && affairShortName.Contains("All"))
            sqlBuildQuery.Append(" And [Committee].committee_short_name in (" + committeeShortName + ") " + orderByClause);

        else if (!committeeShortName.Contains("All") && (!affairShortName.Contains("All") && affairShortName != ""))
            sqlBuildQuery.Append(" And [Committee].committee_short_name in (" + committeeShortName + ") and AFFAIRS.Affairs_Short_name in (" + affairShortName + ") " + orderByClause);

        else if (committeeShortName.Contains("All") && (!affairShortName.Contains("All") && affairShortName != ""))
            sqlBuildQuery.Append(" and AFFAIRS.Affairs_Short_name in (" + affairShortName + ") " + orderByClause);

        else if (!committeeShortName.Contains("All") && affairShortName == "")
        {
            if (committeeShortName != "")
            {
                sqlBuildQuery.Append(" And [Committee].committee_short_name in (" + committeeShortName + ") " + orderByClause);
            }
            else
            {
                sqlBuildQuery.Append(orderByClause);
            }
        }
        else if (committeeShortName.Contains("All") && affairShortName == "")
            sqlBuildQuery.Append(orderByClause);
        return sqlBuildQuery;
    }

    public string GetTypeOfTender(string typeOfTender)
    {
        if (typeOfTender == "L")
            typeOfTender = "Limited";
        else if (typeOfTender == "R")
            typeOfTender = "Re-Tender";
        else if (typeOfTender == "DO")
            typeOfTender = "Direct Order";
        else if (typeOfTender == "PT")
            typeOfTender = "Public Tender";

        return typeOfTender;
    }


    //Modified By Varun on 16th Feb 2014 replace prAdvDate by tenderIssueDate based on Riyas request

    //Modified By Sreedhar on 23rd June 2014 add new parameter that logo type 

    //public void createPDF_Table(Document doc, string strTendrNo, string strTendrTitle, string[] companyInfo, PdfWriter writer, bool isWorkOrder)     // By Sree
    //{
    //    // Document doc = new Document(PageSize.A4);

    //    string userFullName = getUserFullName(_userName);

    //    BaseFont bfArabic = BaseFont.CreateFont(@"C:\Windows\Fonts\arialuni.ttf", BaseFont.IDENTITY_H, BaseFont.EMBEDDED); //"F:/ArabicFonts/MOHANAD.ttf", BaseFont.IDENTITY_H, true MOHAND F:\ArabicFonts\                                                        
    //    BaseFont bfArial = BaseFont.CreateFont(@"C:\Windows\Fonts\arial.ttf", BaseFont.IDENTITY_H, BaseFont.EMBEDDED);

    //    Font arabicBoldMaroonFont = new Font(bfArabic, 9, Font.BOLD, new BaseColor(176, 48, 96)); //255, 20, 147)); //C:\Windows\Fonts\Al-MOHANAD.ttf arialuni
    //    Font arabicBoldBlackFont = new Font(bfArabic, 10, Font.BOLD, BaseColor.BLACK);
    //    Font arabicNormalBlackFont = new Font(bfArabic, 9, Font.NORMAL, BaseColor.BLACK);
    //    Font arabicNormalBlackFont_7 = new Font(bfArabic, 7, Font.NORMAL, BaseColor.BLACK);

    //    BaseFont bfArialItemNames = BaseFont.CreateFont(@"C:\Windows\Fonts\arial.ttf", BaseFont.IDENTITY_H, BaseFont.EMBEDDED);
    //    iTextSharp.text.Font companyNameFont = new iTextSharp.text.Font(bfArialItemNames, 10f, Font.NORMAL, iTextSharp.text.BaseColor.BLUE);

    //    iTextSharp.text.Font digitFont = new iTextSharp.text.Font(bfArial, 10f, iTextSharp.text.Font.NORMAL, iTextSharp.text.BaseColor.RED);
    //    iTextSharp.text.Font plainText = new iTextSharp.text.Font(bfArial, 9f);
    //    iTextSharp.text.Font boldText = new iTextSharp.text.Font(bfArial, 10f, iTextSharp.text.Font.BOLD, iTextSharp.text.BaseColor.BLACK);
    //    iTextSharp.text.Font headFont = new iTextSharp.text.Font(bfArial, 10f, iTextSharp.text.Font.BOLD, iTextSharp.text.BaseColor.BLACK);
    //    iTextSharp.text.Font plainText_7 = new iTextSharp.text.Font(bfArial, 6f);

    //    iTextSharp.text.Font digitFont_6 = new iTextSharp.text.Font(bfArial, 7f, iTextSharp.text.Font.NORMAL, iTextSharp.text.BaseColor.BLUE);
    //    iTextSharp.text.Font digitFont_7 = new iTextSharp.text.Font(bfArial, 7f, iTextSharp.text.Font.NORMAL, new iTextSharp.text.BaseColor(0, 0, 255));

    //    PdfPTable table1 = new PdfPTable(1);
    //    table1.HorizontalAlignment = Element.ALIGN_RIGHT;
    //    table1.RunDirection = PdfWriter.RUN_DIRECTION_RTL;
    //    doc.Add(table1);

    //    PdfPTable table4 = new PdfPTable(1);
    //    table4.RunDirection = PdfWriter.RUN_DIRECTION_RTL;
    //    PdfPCell cell4 = new PdfPCell(new Phrase("إيصال استلام عروض مناقصة", arabicBoldBlackFont));
    //    cell4.Border = 0;
    //    cell4.HorizontalAlignment = PdfPCell.ALIGN_CENTER;
    //    table4.AddCell(cell4);

    //    Paragraph pg1 = new Paragraph();
    //    pg1.Alignment = iTextSharp.text.pdf.PdfContentByte.ALIGN_CENTER;
    //    pg1.Add(table4);
    //    pg1.SpacingBefore = 3f;
    //    doc.Add(pg1);

    //    Chunk headLine2 = new Chunk();
    //    headLine2 = new Chunk("Receipt Voucher for Tender Submission", headFont);

    //    headLine2.SetUnderline(1f, -2f);
    //    Phrase p2 = new Phrase(headLine2);
    //    Paragraph pg2 = new Paragraph();
    //    pg2.Alignment = iTextSharp.text.pdf.PdfContentByte.ALIGN_CENTER;
    //    pg2.Add(p2);
    //    pg2.SpacingAfter = 15f;
    //    doc.Add(pg2);

    //    PdfPTable table2 = new PdfPTable(1);
    //    table2.WidthPercentage = 100;

    //    table2.HorizontalAlignment = Element.ALIGN_CENTER;
    //    PdfPCell cell3 = new PdfPCell(new Phrase());
    //    //cell3.BorderWidthLeft = 1f;
    //    //cell3.BorderWidthRight = 1f;
    //    //cell3.BorderWidthTop = 1f;
    //    //cell3.BorderWidthBottom = 1f;
    //    table2.AddCell(cell3);
    //    doc.Add(table2);

    //    PdfPTable table3 = new PdfPTable(3);
    //    table3.DefaultCell.Border = 0;
    //    table3.WidthPercentage = 100;

    //    float[] widths = new float[] { 45, 100, 45 };
    //    table3.SetWidths(widths);

    //    PdfPCell cell7 = new PdfPCell(new Phrase("Tender No.:", plainText));
    //    //cell7.Border = 0;
    //    cell7.HorizontalAlignment = PdfPCell.ALIGN_LEFT;
    //    cell7.FixedHeight = 20f;
    //    cell7.VerticalAlignment = iTextSharp.text.Element.ALIGN_MIDDLE;
    //    table3.AddCell(cell7);

    //    PdfPCell cell8 = new PdfPCell(new Phrase(strTendrNo, plainText));
    //    // cell8.Border = 0;
    //    cell8.HorizontalAlignment = PdfPCell.ALIGN_CENTER;
    //    cell8.VerticalAlignment = iTextSharp.text.Element.ALIGN_MIDDLE;
    //    table3.AddCell(cell8);

    //    PdfPCell cell12 = new PdfPCell(new Phrase("رقم المناقصة", arabicNormalBlackFont));
    //    //cell12.Border = 0;
    //    cell12.RunDirection = PdfWriter.RUN_DIRECTION_RTL;
    //    cell12.HorizontalAlignment = PdfPCell.ALIGN_LEFT;
    //    cell12.VerticalAlignment = iTextSharp.text.Element.ALIGN_MIDDLE;
    //    table3.AddCell(cell12);

    //    if (isWorkOrder)
    //    {
    //        PdfPCell cellFrameworkTitle = new PdfPCell(new Phrase("Framework Title:", plainText));
    //        cellFrameworkTitle.HorizontalAlignment = PdfPCell.ALIGN_LEFT;
    //        cellFrameworkTitle.FixedHeight = 20f;
    //        cellFrameworkTitle.VerticalAlignment = iTextSharp.text.Element.ALIGN_MIDDLE;
    //        table3.AddCell(cellFrameworkTitle);

    //        PdfPCell cellFrameworkTitleValue = new PdfPCell(new Phrase(strTendrTitle, plainText));
    //        cellFrameworkTitleValue.VerticalAlignment = iTextSharp.text.Element.ALIGN_MIDDLE;
    //        cellFrameworkTitleValue.HorizontalAlignment = PdfPCell.ALIGN_CENTER;
    //        table3.AddCell(cellFrameworkTitleValue);

    //        PdfPCell cellArabicFrameworkTitleValue = new PdfPCell(new Phrase("اسم التعاقدالإطاري", arabicNormalBlackFont));
    //        cellArabicFrameworkTitleValue.VerticalAlignment = iTextSharp.text.Element.ALIGN_MIDDLE;
    //        cellArabicFrameworkTitleValue.RunDirection = PdfWriter.RUN_DIRECTION_RTL;
    //        cellArabicFrameworkTitleValue.HorizontalAlignment = PdfPCell.ALIGN_LEFT;
    //        table3.AddCell(cellArabicFrameworkTitleValue);

    //        PdfPCell cellWorkorderNo = new PdfPCell(new Phrase("Workorder No.:", plainText));
    //        cellWorkorderNo.HorizontalAlignment = PdfPCell.ALIGN_LEFT;
    //        cellWorkorderNo.FixedHeight = 20f;
    //        cellWorkorderNo.VerticalAlignment = iTextSharp.text.Element.ALIGN_MIDDLE;
    //        table3.AddCell(cellWorkorderNo);

    //        PdfPCell cellWorkorderNoValue = new PdfPCell(new Phrase(companyInfo[10].ToString(), plainText));
    //        cellWorkorderNoValue.VerticalAlignment = iTextSharp.text.Element.ALIGN_MIDDLE;
    //        cellWorkorderNoValue.HorizontalAlignment = PdfPCell.ALIGN_CENTER;
    //        table3.AddCell(cellWorkorderNoValue);

    //        PdfPCell cellArabicWorkorderNoValue = new PdfPCell(new Phrase("رقم أوامر العمل", arabicNormalBlackFont));
    //        cellArabicWorkorderNoValue.VerticalAlignment = iTextSharp.text.Element.ALIGN_MIDDLE;
    //        cellArabicWorkorderNoValue.RunDirection = PdfWriter.RUN_DIRECTION_RTL;
    //        cellArabicWorkorderNoValue.HorizontalAlignment = PdfPCell.ALIGN_LEFT;
    //        table3.AddCell(cellArabicWorkorderNoValue);

    //        PdfPCell cellWorkorderTitle = new PdfPCell(new Phrase("Workorder Title:", plainText));
    //        cellWorkorderTitle.HorizontalAlignment = PdfPCell.ALIGN_LEFT;
    //        cellWorkorderTitle.FixedHeight = 20f;
    //        cellWorkorderTitle.VerticalAlignment = iTextSharp.text.Element.ALIGN_MIDDLE;
    //        table3.AddCell(cellWorkorderTitle);

    //        PdfPCell cellWorkorderTitleValue = new PdfPCell(new Phrase(companyInfo[11].ToString(), plainText));
    //        cellWorkorderTitleValue.VerticalAlignment = iTextSharp.text.Element.ALIGN_MIDDLE;
    //        cellWorkorderTitleValue.HorizontalAlignment = PdfPCell.ALIGN_CENTER;
    //        table3.AddCell(cellWorkorderTitleValue);

    //        PdfPCell cellArabicWorkorderTitleValue = new PdfPCell(new Phrase("اسم أوامر العمل", arabicNormalBlackFont));
    //        cellArabicWorkorderTitleValue.VerticalAlignment = iTextSharp.text.Element.ALIGN_MIDDLE;
    //        cellArabicWorkorderTitleValue.RunDirection = PdfWriter.RUN_DIRECTION_RTL;
    //        cellArabicWorkorderTitleValue.HorizontalAlignment = PdfPCell.ALIGN_LEFT;
    //        table3.AddCell(cellArabicWorkorderTitleValue);
    //    }
    //    if (!isWorkOrder)
    //    {
    //        PdfPCell cell9 = new PdfPCell(new Phrase("Tender Title:", plainText));
    //        // cell9.Border = 10;
    //        //cell9.FixedHeight = 45f;     
    //        cell9.HorizontalAlignment = PdfPCell.ALIGN_LEFT;

    //        cell9.FixedHeight = 20f;
    //        cell9.VerticalAlignment = iTextSharp.text.Element.ALIGN_MIDDLE;
    //        cell9.VerticalAlignment = PdfPCell.ALIGN_MIDDLE;
    //        table3.AddCell(cell9);

    //        PdfPCell cell13 = new PdfPCell(new Phrase(strTendrTitle, plainText));
    //        // cell13.Border = 10;
    //        cell13.NoWrap = false;
    //        //cell13.FixedHeight = 20f;                                   
    //        cell13.HorizontalAlignment = PdfPCell.ALIGN_CENTER;
    //        cell13.VerticalAlignment = iTextSharp.text.Element.ALIGN_MIDDLE;
    //        table3.AddCell(cell13);

    //        PdfPCell cell14 = new PdfPCell(new Phrase("اسم المناقصة", arabicNormalBlackFont));
    //        // cell14.Border = 10;
    //        //cell14.FixedHeight = 20f;     
    //        cell14.RunDirection = PdfWriter.RUN_DIRECTION_RTL;
    //        cell14.HorizontalAlignment = PdfPCell.ALIGN_LEFT;
    //        cell14.VerticalAlignment = iTextSharp.text.Element.ALIGN_MIDDLE;
    //        table3.AddCell(cell14);
    //    }

    //    PdfPCell cell10 = new PdfPCell(new Phrase("Company Name:", plainText));
    //    // cell10.Border = 10;
    //    cell10.FixedHeight = 20f;
    //    cell10.HorizontalAlignment = PdfPCell.ALIGN_LEFT;
    //    cell10.VerticalAlignment = PdfPCell.ALIGN_MIDDLE;
    //    cell10.VerticalAlignment = iTextSharp.text.Element.ALIGN_MIDDLE;
    //    table3.AddCell(cell10);

    //    PdfPCell cell5 = new PdfPCell(new Phrase(companyInfo[1], plainText));
    //    //cell5.Border = 10;
    //    cell5.HorizontalAlignment = PdfPCell.ALIGN_CENTER;
    //    cell5.VerticalAlignment = iTextSharp.text.Element.ALIGN_MIDDLE;
    //    table3.AddCell(cell5);

    //    PdfPCell cell11 = new PdfPCell(new Phrase("اسم الشركة", arabicNormalBlackFont));
    //    //cell11.Border = 10;
    //    cell11.RunDirection = PdfWriter.RUN_DIRECTION_RTL;
    //    cell11.HorizontalAlignment = PdfPCell.ALIGN_LEFT;
    //    cell11.VerticalAlignment = iTextSharp.text.Element.ALIGN_MIDDLE;
    //    table3.AddCell(cell11);

    //    PdfPCell cell15 = new PdfPCell(new Phrase("Delivered by:", plainText));
    //    // cell15.Border = 10;
    //    //cell15.FixedHeight = 35f;
    //    cell15.VerticalAlignment = iTextSharp.text.Element.ALIGN_MIDDLE;
    //    cell15.FixedHeight = 20f;
    //    cell15.HorizontalAlignment = PdfPCell.ALIGN_LEFT;
    //    table3.AddCell(cell15);

    //    PdfPCell cell16 = new PdfPCell(new Phrase(companyInfo[9].ToString(), plainText));
    //    // cell16.Border = 10;
    //    // cell16.FixedHeight = 35f;                                 
    //    cell16.HorizontalAlignment = PdfPCell.ALIGN_CENTER;
    //    cell16.VerticalAlignment = iTextSharp.text.Element.ALIGN_MIDDLE;
    //    table3.AddCell(cell16);

    //    PdfPCell cell17 = new PdfPCell(new Phrase("سلمت بواسطة", arabicNormalBlackFont));
    //    // cell17.Border = 10;
    //    //cell17.FixedHeight = 35f;                                 
    //    cell17.RunDirection = PdfWriter.RUN_DIRECTION_RTL;
    //    cell17.HorizontalAlignment = PdfPCell.ALIGN_LEFT;
    //    cell17.VerticalAlignment = iTextSharp.text.Element.ALIGN_MIDDLE;
    //    table3.AddCell(cell17);

    //    PdfPCell cell30 = new PdfPCell(new Phrase("Nos. of Envelops:", plainText));
    //    //  cell30.Border = 10; 
    //    cell30.FixedHeight = 20f;
    //    cell30.HorizontalAlignment = PdfPCell.ALIGN_LEFT;
    //    cell30.VerticalAlignment = iTextSharp.text.Element.ALIGN_MIDDLE;
    //    table3.AddCell(cell30);


    //    PdfPCell cell31 = new PdfPCell();
    //    // cell31.Border = 10;   

    //    cell31 = new PdfPCell(new Phrase(companyInfo[2].ToString(), plainText));

    //    cell31.HorizontalAlignment = PdfPCell.ALIGN_CENTER;
    //    cell31.VerticalAlignment = iTextSharp.text.Element.ALIGN_MIDDLE;
    //    table3.AddCell(cell31);


    //    PdfPCell cell32 = new PdfPCell(new Phrase("عدد المظاريف", arabicNormalBlackFont));
    //    // cell32.Border = 10;   
    //    cell32.RunDirection = PdfWriter.RUN_DIRECTION_RTL;
    //    cell32.HorizontalAlignment = PdfPCell.ALIGN_LEFT;
    //    cell32.VerticalAlignment = iTextSharp.text.Element.ALIGN_MIDDLE;
    //    table3.AddCell(cell32);

    //    PdfPCell cell18 = null;
    //    cell18 = new PdfPCell(new Phrase("Recieved by:", plainText));
    //    //cell18.Border = 10;

    //    cell18.FixedHeight = 20f;
    //    cell18.NoWrap = true;
    //    cell18.HorizontalAlignment = PdfPCell.ALIGN_LEFT;
    //    cell18.VerticalAlignment = iTextSharp.text.Element.ALIGN_MIDDLE;
    //    table3.AddCell(cell18);

    //    PdfPCell cell19 = new PdfPCell(new Phrase(userFullName, plainText));
    //    // cell19.Border = 10;
    //    cell19.HorizontalAlignment = PdfPCell.ALIGN_CENTER;
    //    cell18.VerticalAlignment = iTextSharp.text.Element.ALIGN_MIDDLE;
    //    table3.AddCell(cell19);

    //    PdfPCell cell20 = null;
    //    cell20 = new PdfPCell(new Phrase("استلمت بواسطة", arabicNormalBlackFont));

    //    //cell20.Border = 10;
    //    cell20.RunDirection = PdfWriter.RUN_DIRECTION_RTL;
    //    cell20.HorizontalAlignment = PdfPCell.ALIGN_LEFT;
    //    cell18.VerticalAlignment = iTextSharp.text.Element.ALIGN_MIDDLE;
    //    table3.AddCell(cell20);

    //    PdfPCell cell21 = new PdfPCell(new Phrase("Signature:", plainText));
    //    // cell21.Border = 10;

    //    cell21.FixedHeight = 20f;
    //    cell21.HorizontalAlignment = PdfPCell.ALIGN_LEFT;
    //    cell21.VerticalAlignment = iTextSharp.text.Element.ALIGN_MIDDLE;
    //    table3.AddCell(cell21);

    //    PdfPCell cell22 = new PdfPCell(new Phrase("", plainText));
    //    // cell22.Border = 10;
    //    cell22.VerticalAlignment = iTextSharp.text.Element.ALIGN_MIDDLE;
    //    cell22.HorizontalAlignment = PdfPCell.ALIGN_CENTER;
    //    cell18.VerticalAlignment = iTextSharp.text.Element.ALIGN_MIDDLE;
    //    table3.AddCell(cell22);

    //    PdfPCell cell23 = new PdfPCell(new Phrase("التوقيع", arabicNormalBlackFont));
    //    //  cell23.Border = 10;
    //    cell23.RunDirection = PdfWriter.RUN_DIRECTION_RTL;
    //    cell23.HorizontalAlignment = PdfPCell.ALIGN_LEFT;
    //    cell23.VerticalAlignment = iTextSharp.text.Element.ALIGN_MIDDLE;
    //    cell18.VerticalAlignment = iTextSharp.text.Element.ALIGN_MIDDLE;
    //    table3.AddCell(cell23);
    //    doc.Add(table3);

    //    Chunk headLineUser = new Chunk("Printed By" + ":" + userFullName + " Dated: " + DateTime.Now.ToString("dd/MMM/yyyy HH:mm:ss"), digitFont_6);           //

    //    Phrase pUser = new Phrase(headLineUser);
    //    Paragraph pgUser = new Paragraph();
    //    pgUser.Alignment = iTextSharp.text.pdf.PdfContentByte.ALIGN_LEFT;
    //    pgUser.Add(pUser);
    //    pgUser.SpacingAfter = 0f;
    //    doc.Add(pgUser);

    //    Chunk headLine222 = new Chunk();
    //    Phrase p222 = new Phrase(headLine222);
    //    Paragraph pg222 = new Paragraph();
    //    pg222.Add(p222);
    //    pg222.SpacingAfter = 10f;
    //    doc.Add(pg222);

    //    PdfPTable tableNew = new PdfPTable(1);
    //    tableNew.DefaultCell.Border = 0;
    //    tableNew.WidthPercentage = 100;

    //    var str = " إدارة العقود، هيئة الأشغال العامة، هاتف: 0077 4495 974+ ، فاكس: 0780 4495 974+ ، ص. ب.: 22188 الدوحة – قطر : ";
    //    PdfPCell cellNew = new PdfPCell(new Phrase(str, plainText_7));
    //    cellNew.Border = 0;
    //    cellNew.RunDirection = PdfWriter.RUN_DIRECTION_RTL;
    //    cellNew.HorizontalAlignment = PdfPCell.ALIGN_CENTER;
    //    cellNew.VerticalAlignment = iTextSharp.text.Element.ALIGN_MIDDLE;
    //    tableNew.AddCell(cellNew);
    //    doc.Add(tableNew);


    //    Chunk headLine22 = new Chunk("Contracts Department, Public Works Authority Tel : + 97444950077,Fax : + 974 4495 0780,P.O Box 22188, Doha - Qatar", plainText_7);
    //    // headLine21.SetUnderline(1f, -2f);
    //    Phrase p22 = new Phrase(headLine22);
    //    Paragraph pg22 = new Paragraph();
    //    pg22.Alignment = iTextSharp.text.pdf.PdfContentByte.ALIGN_CENTER;
    //    pg22.Add(p22);
    //    pg22.SpacingAfter = -1f;
    //    //pg22.SpacingAfter = 0f;
    //    doc.Add(pg22);

    //    Chunk headLine23 = new Chunk("www.ashghal.gov.qa", digitFont_7);
    //    // headLine21.SetUnderline(1f, -2f);
    //    Phrase p23 = new Phrase(headLine23);
    //    Paragraph pg23 = new Paragraph();
    //    pg23.Alignment = iTextSharp.text.pdf.PdfContentByte.ALIGN_CENTER;
    //    pg23.Add(p23);
    //    pg23.SpacingAfter = 20f;
    //    doc.Add(pg23);

    //} 
    ////public void createPDF_Table_TenderDocuments(Document doc, string strTendrNo, string strTendrTitle, string[] companyInfo, PdfWriter writer, string docFee, string projCode, string tenderIssueDate, string tenderBond, string strClosingDate, string strModifiedDate, Int16 noOfExtns, string strEligibleTenderTypes, string typeOfTender, int totCircularNos)
    ////{
    ////    // Document doc = new Document(PageSize.A4);

    ////    string userFullName = getUserFullName(_userName);

    ////    BaseFont bfArabic = BaseFont.CreateFont(@"C:\Windows\Fonts\arialuni.ttf", BaseFont.IDENTITY_H, BaseFont.EMBEDDED); //"F:/ArabicFonts/MOHANAD.ttf", BaseFont.IDENTITY_H, true MOHAND F:\ArabicFonts\                                                        
    ////    BaseFont bfArial = BaseFont.CreateFont(@"C:\Windows\Fonts\arial.ttf", BaseFont.IDENTITY_H, BaseFont.EMBEDDED);
    ////    Font arabicBoldMaroonFont = new Font(bfArabic, 10, Font.BOLD, new BaseColor(176, 48, 96)); //255, 20, 147)); //C:\Windows\Fonts\Al-MOHANAD.ttf arialuni
    ////    Font arabicBoldBlackFont = new Font(bfArabic, 11, Font.BOLD, BaseColor.BLACK);
    ////    Font arabicNormalBlackFont = new Font(bfArabic, 10, Font.NORMAL, BaseColor.BLACK);
    ////    Font arabicNormalBlackFont_7 = new Font(bfArabic, 7, Font.NORMAL, BaseColor.BLACK);

    ////    BaseFont bfArialItemNames = BaseFont.CreateFont(@"C:\Windows\Fonts\arial.ttf", BaseFont.IDENTITY_H, BaseFont.EMBEDDED);
    ////    iTextSharp.text.Font companyNameFont = new iTextSharp.text.Font(bfArialItemNames, 10f, Font.NORMAL, iTextSharp.text.BaseColor.BLUE);

    ////    iTextSharp.text.Font digitFont = new iTextSharp.text.Font(bfArial, 10f, iTextSharp.text.Font.NORMAL, iTextSharp.text.BaseColor.RED);
    ////    iTextSharp.text.Font plainText = new iTextSharp.text.Font(bfArial, 10f);
    ////    iTextSharp.text.Font boldText = new iTextSharp.text.Font(bfArial, 10f, iTextSharp.text.Font.BOLD, iTextSharp.text.BaseColor.BLACK);
    ////    iTextSharp.text.Font headFont = new iTextSharp.text.Font(bfArial, 12f, iTextSharp.text.Font.BOLD, iTextSharp.text.BaseColor.BLACK);
    ////    iTextSharp.text.Font plainText_7 = new iTextSharp.text.Font(bfArial, 6f);

    ////    iTextSharp.text.Font plainText_8 = new iTextSharp.text.Font(bfArial, 8f);
    ////    iTextSharp.text.Font plainText_9 = new iTextSharp.text.Font(bfArial, 9f);

    ////    iTextSharp.text.Font digitFont_7 = new iTextSharp.text.Font(bfArial, 7f, iTextSharp.text.Font.NORMAL, iTextSharp.text.BaseColor.BLUE);

    ////    PdfPTable table1 = new PdfPTable(1);
    ////    table1.HorizontalAlignment = Element.ALIGN_RIGHT;
    ////    table1.RunDirection = PdfWriter.RUN_DIRECTION_RTL;
    ////    doc.Add(table1);

    ////    PdfPTable table4 = new PdfPTable(1);
    ////    table4.RunDirection = PdfWriter.RUN_DIRECTION_RTL;
    ////    PdfPCell cell4 = new PdfPCell(new Phrase("إيصال استلام عروض مناقصة", arabicBoldBlackFont));
    ////    cell4.Border = 0;
    ////    cell4.HorizontalAlignment = PdfPCell.ALIGN_CENTER;
    ////    table4.AddCell(cell4);

    ////    Paragraph pg1 = new Paragraph();
    ////    pg1.Alignment = iTextSharp.text.pdf.PdfContentByte.ALIGN_CENTER;
    ////    pg1.Add(table4);
    ////    pg1.SpacingBefore = 1f;
    ////    doc.Add(pg1);

    ////    Chunk headLine2 = new Chunk();
    ////    bool isCommitteePQ = false;
    ////    isCommitteePQ = strTendrNo.Contains("PQ");
    ////    if (!isCommitteePQ)
    ////    {
    ////        headLine2 = new Chunk("Receipt Voucher for Tender Documents", headFont);
    ////    }
    ////    else
    ////    {
    ////        headLine2 = new Chunk("Receipt Voucher for Documents", headFont);
    ////    }
    ////    headLine2.SetUnderline(1f, -2f);
    ////    Phrase p2 = new Phrase(headLine2);
    ////    Paragraph pg2 = new Paragraph();
    ////    pg2.Alignment = iTextSharp.text.pdf.PdfContentByte.ALIGN_CENTER;
    ////    pg2.Add(p2);
    ////    pg2.SpacingAfter = 12f;
    ////    doc.Add(pg2);

    ////    PdfPTable table2 = new PdfPTable(1);
    ////    table2.WidthPercentage = 100;

    ////    table2.HorizontalAlignment = Element.ALIGN_CENTER;
    ////    PdfPCell cell3 = new PdfPCell(new Phrase());
    ////    table2.AddCell(cell3);
    ////    doc.Add(table2);

    ////    int rowSize = 18;
    ////    PdfPTable table3 = new PdfPTable(3);
    ////    table3.DefaultCell.Border = 0;
    ////    table3.WidthPercentage = 100;

    ////    float[] widths = new float[] { 45, 100, 45 };
    ////    table3.SetWidths(widths);

    ////    PdfPCell cell7 = new PdfPCell(new Phrase("Tender No.:", plainText));
    ////    //cell7.Border = 0;
    ////    cell7.HorizontalAlignment = PdfPCell.ALIGN_LEFT;
    ////    cell7.FixedHeight = rowSize;
    ////    cell7.VerticalAlignment = iTextSharp.text.Element.ALIGN_MIDDLE;
    ////    table3.AddCell(cell7);

    ////    PdfPCell cell8 = new PdfPCell(new Phrase(strTendrNo, plainText));            // cell8.Border = 0;           
    ////    cell8.VerticalAlignment = iTextSharp.text.Element.ALIGN_MIDDLE;
    ////    cell8.HorizontalAlignment = PdfPCell.ALIGN_CENTER;
    ////    table3.AddCell(cell8);

    ////    PdfPCell cell12 = new PdfPCell(new Phrase("رقم المناقصة", arabicNormalBlackFont));
    ////    cell12.VerticalAlignment = iTextSharp.text.Element.ALIGN_MIDDLE;
    ////    cell12.RunDirection = PdfWriter.RUN_DIRECTION_RTL;
    ////    cell12.HorizontalAlignment = PdfPCell.ALIGN_LEFT;
    ////    table3.AddCell(cell12);

    ////    PdfPCell cell9 = new PdfPCell(new Phrase("Tender Title:", plainText));
    ////    // cell9.Border = 10;
    ////    //cell9.FixedHeight = 45f;  
    ////    //cell9.FixedHeight = 20f;
    ////    cell9.VerticalAlignment = iTextSharp.text.Element.ALIGN_MIDDLE;
    ////    cell9.HorizontalAlignment = PdfPCell.ALIGN_LEFT;
    ////    cell9.VerticalAlignment = PdfPCell.ALIGN_MIDDLE;
    ////    table3.AddCell(cell9);

    ////    PdfPCell cell13 = new PdfPCell(new Phrase(strTendrTitle, plainText));
    ////    // cell13.Border = 10;
    ////    cell13.NoWrap = false;
    ////    //cell13.FixedHeight = 35f;                                   
    ////    cell13.HorizontalAlignment = PdfPCell.ALIGN_CENTER;
    ////    table3.AddCell(cell13);

    ////    PdfPCell cell14 = new PdfPCell(new Phrase("اسم المناقصة", arabicNormalBlackFont));
    ////    // cell14.Border = 10;
    ////    //cell14.FixedHeight = 35f;     
    ////    cell14.RunDirection = PdfWriter.RUN_DIRECTION_RTL;
    ////    cell14.HorizontalAlignment = PdfPCell.ALIGN_LEFT;
    ////    cell14.VerticalAlignment = iTextSharp.text.Element.ALIGN_MIDDLE;
    ////    table3.AddCell(cell14);

    ////    PdfPCell cellFee = new PdfPCell(new Phrase("Document Fee(QR):", plainText));
    ////    cellFee.FixedHeight = rowSize;
    ////    cellFee.VerticalAlignment = iTextSharp.text.Element.ALIGN_MIDDLE;
    ////    cellFee.HorizontalAlignment = PdfPCell.ALIGN_LEFT;
    ////    cellFee.VerticalAlignment = PdfPCell.ALIGN_MIDDLE;
    ////    table3.AddCell(cellFee);

    ////    // docFee = string.Format("{0:#,##0.00}", double.Parse((docFee).ToString()));

    ////    if (docFee != "")
    ////        docFee = Convert.ToDecimal(docFee).ToString("#,##0.00");

    ////    PdfPCell cellFee1 = new PdfPCell(new Phrase(docFee));
    ////    //cell5.Border = 10;
    ////    cellFee1.HorizontalAlignment = PdfPCell.ALIGN_CENTER;
    ////    cellFee1.VerticalAlignment = iTextSharp.text.Element.ALIGN_MIDDLE;
    ////    table3.AddCell(cellFee1);

    ////    PdfPCell cellFee2 = new PdfPCell(new Phrase("رسوم المستند ( رق)", arabicNormalBlackFont));
    ////    //cell11.Border = 10;
    ////    cellFee2.RunDirection = PdfWriter.RUN_DIRECTION_RTL;
    ////    cellFee2.HorizontalAlignment = PdfPCell.ALIGN_LEFT;
    ////    table3.AddCell(cellFee2);

    ////    PdfPCell cellBill = new PdfPCell(new Phrase("Pay Bill No :", plainText));
    ////    // cell10.Border = 10;
    ////    cellBill.FixedHeight = rowSize;
    ////    cellBill.VerticalAlignment = iTextSharp.text.Element.ALIGN_MIDDLE;
    ////    cellBill.HorizontalAlignment = PdfPCell.ALIGN_LEFT;
    ////    cellBill.VerticalAlignment = PdfPCell.ALIGN_MIDDLE;
    ////    table3.AddCell(cellBill);

    ////    PdfPCell cellBill1 = new PdfPCell(new Phrase(companyInfo[4], plainText));
    ////    //cell5.Border = 10;
    ////    cellBill1.HorizontalAlignment = PdfPCell.ALIGN_CENTER;
    ////    table3.AddCell(cellBill1);

    ////    PdfPCell cellBill2 = new PdfPCell(new Phrase("رقم إيصال الإيداع", arabicNormalBlackFont));
    ////    //cell11.Border = 10;
    ////    cellBill2.RunDirection = PdfWriter.RUN_DIRECTION_RTL;
    ////    cellBill2.HorizontalAlignment = PdfPCell.ALIGN_LEFT;
    ////    table3.AddCell(cellBill2);

    ////    PdfPCell cell10 = new PdfPCell(new Phrase("Company Name:", plainText));
    ////    // cell10.Border = 10;
    ////    cell10.FixedHeight = rowSize;
    ////    cell10.VerticalAlignment = iTextSharp.text.Element.ALIGN_MIDDLE;
    ////    cell10.HorizontalAlignment = PdfPCell.ALIGN_LEFT;
    ////    cell10.VerticalAlignment = PdfPCell.ALIGN_MIDDLE;
    ////    cell10.VerticalAlignment = iTextSharp.text.Element.ALIGN_MIDDLE;
    ////    table3.AddCell(cell10);

    ////    PdfPCell cell5 = new PdfPCell(new Phrase(companyInfo[0], plainText)); //1
    ////    //cell5.Border = 10;
    ////    cell5.HorizontalAlignment = PdfPCell.ALIGN_CENTER;
    ////    cell5.VerticalAlignment = iTextSharp.text.Element.ALIGN_MIDDLE;
    ////    table3.AddCell(cell5);

    ////    PdfPCell cell11 = new PdfPCell(new Phrase("اسم الشركة", arabicNormalBlackFont));
    ////    //cell11.Border = 10;
    ////    cell11.RunDirection = PdfWriter.RUN_DIRECTION_RTL;
    ////    cell11.HorizontalAlignment = PdfPCell.ALIGN_LEFT;
    ////    cell11.VerticalAlignment = iTextSharp.text.Element.ALIGN_MIDDLE;
    ////    table3.AddCell(cell11);

    ////    PdfPCell cell30 = new PdfPCell(new Phrase("Nos. of Circulars:", plainText));
    ////    //  cell30.Border = 10;     

    ////    cell30.FixedHeight = rowSize;
    ////    cell30.VerticalAlignment = iTextSharp.text.Element.ALIGN_MIDDLE;
    ////    cell30.HorizontalAlignment = PdfPCell.ALIGN_LEFT;
    ////    table3.AddCell(cell30);


    ////    PdfPCell cell31 = new PdfPCell();
    ////    // cell31.Border = 10;    
    ////    if (totCircularNos.ToString() == "")
    ////        cell31 = new PdfPCell(new Phrase("0", plainText));
    ////    else
    ////        cell31 = new PdfPCell(new Phrase(totCircularNos.ToString(), plainText));

    ////    cell31.HorizontalAlignment = PdfPCell.ALIGN_CENTER;
    ////    cell31.VerticalAlignment = iTextSharp.text.Element.ALIGN_MIDDLE;
    ////    table3.AddCell(cell31);


    ////    PdfPCell cell32 = new PdfPCell(new Phrase("عدد التعاميم ", arabicNormalBlackFont));
    ////    // cell32.Border = 10; 
    ////    cell32.RunDirection = PdfWriter.RUN_DIRECTION_RTL;
    ////    cell32.HorizontalAlignment = PdfPCell.ALIGN_LEFT;
    ////    cell32.VerticalAlignment = iTextSharp.text.Element.ALIGN_MIDDLE;
    ////    table3.AddCell(cell32);

    ////    PdfPCell cell15 = new PdfPCell(new Phrase("Collected by:", plainText));
    ////    // cell15.Border = 10;
    ////    cell15.FixedHeight = rowSize;
    ////    cell15.VerticalAlignment = iTextSharp.text.Element.ALIGN_MIDDLE;
    ////    //cell15.FixedHeight = 35f;                                 
    ////    cell15.HorizontalAlignment = PdfPCell.ALIGN_LEFT;
    ////    table3.AddCell(cell15);


    ////    PdfPCell cell16 = null;
    ////    if (companyInfo.Length == 7) //When Issue A Tender
    ////        cell16 = new PdfPCell(new Phrase(companyInfo[6], plainText));   //collectedBy                 
    ////    else
    ////        cell16 = new PdfPCell(new Phrase(companyInfo[9], plainText));   //collectedBy                
    ////    // cell16.Border = 10;
    ////    // cell16.FixedHeight = 35f;                                 
    ////    cell16.HorizontalAlignment = PdfPCell.ALIGN_CENTER;
    ////    cell16.VerticalAlignment = iTextSharp.text.Element.ALIGN_MIDDLE;
    ////    table3.AddCell(cell16);


    ////    PdfPCell cell17 = new PdfPCell(new Phrase(" استلمت بواسطة", arabicNormalBlackFont));
    ////    // cell17.Border = 10;
    ////    //cell17.FixedHeight = 35f;                                 
    ////    cell17.RunDirection = PdfWriter.RUN_DIRECTION_RTL;
    ////    cell17.HorizontalAlignment = PdfPCell.ALIGN_LEFT;
    ////    cell17.VerticalAlignment = iTextSharp.text.Element.ALIGN_MIDDLE;
    ////    table3.AddCell(cell17);

    ////    PdfPCell cell21 = new PdfPCell(new Phrase("Signature:", plainText));
    ////    // cell21.Border = 10;
    ////    cell21.FixedHeight = rowSize;
    ////    cell21.HorizontalAlignment = PdfPCell.ALIGN_LEFT;
    ////    cell21.VerticalAlignment = iTextSharp.text.Element.ALIGN_MIDDLE;
    ////    table3.AddCell(cell21);

    ////    PdfPCell cell22 = new PdfPCell(new Phrase("", plainText));
    ////    // cell22.Border = 10;
    ////    cell22.VerticalAlignment = iTextSharp.text.Element.ALIGN_MIDDLE;
    ////    cell22.HorizontalAlignment = PdfPCell.ALIGN_CENTER;
    ////    table3.AddCell(cell22);

    ////    PdfPCell cell23 = new PdfPCell(new Phrase("التوقيع", arabicNormalBlackFont));
    ////    //  cell23.Border = 10;
    ////    cell23.RunDirection = PdfWriter.RUN_DIRECTION_RTL;
    ////    cell23.HorizontalAlignment = PdfPCell.ALIGN_LEFT;
    ////    cell23.VerticalAlignment = iTextSharp.text.Element.ALIGN_MIDDLE;
    ////    table3.AddCell(cell23);
    ////    doc.Add(table3);

    ////    Chunk headLineUser = new Chunk("User Name" + ":" + userFullName + " Dated:" + DateTime.Now.ToString(), digitFont_7);
    ////    Phrase pUser = new Phrase(headLineUser);
    ////    Paragraph pgUser = new Paragraph();
    ////    pgUser.Alignment = iTextSharp.text.pdf.PdfContentByte.ALIGN_LEFT;
    ////    pgUser.Add(pUser);
    ////    pgUser.SpacingAfter = 0f;
    ////    doc.Add(pgUser);

    ////    Chunk headLine222 = new Chunk();
    ////    Phrase p222 = new Phrase(headLine222);
    ////    Paragraph pg222 = new Paragraph();
    ////    pg222.Add(p222);
    ////    pg222.SpacingAfter = 10f;
    ////    doc.Add(pg222);

    ////    PdfPTable tableNew = new PdfPTable(1);
    ////    tableNew.DefaultCell.Border = 0;
    ////    tableNew.WidthPercentage = 100;

    ////    var str = " إدارة العقود، هيئة الأشغال العامة، هاتف: 0077 4495 974+ ، فاكس: 0780 4495 974+ ، ص. ب.: 22188 الدوحة – قطر  ";
    ////    PdfPCell cellNew = new PdfPCell(new Phrase(str, plainText_9));
    ////    cellNew.Border = 0;
    ////    cellNew.RunDirection = PdfWriter.RUN_DIRECTION_RTL;
    ////    cellNew.HorizontalAlignment = PdfPCell.ALIGN_CENTER;
    ////    cellNew.VerticalAlignment = iTextSharp.text.Element.ALIGN_MIDDLE;
    ////    tableNew.AddCell(cellNew);
    ////    doc.Add(tableNew);

    ////    Chunk headLine22 = new Chunk("Contracts Department, Public Works Authority Tel : + 97444950077,Fax : + 974 4495 0780,P.O Box 22188, Doha - Qatar", plainText_8);
    ////    // headLine21.SetUnderline(1f, -2f);
    ////    Phrase p22 = new Phrase(headLine22);
    ////    Paragraph pg22 = new Paragraph();
    ////    pg22.Alignment = iTextSharp.text.pdf.PdfContentByte.ALIGN_CENTER;
    ////    pg22.Add(p22);
    ////    pg22.SpacingAfter = 0f;
    ////    doc.Add(pg22);

    ////    Chunk headLine23 = new Chunk("www.ashghal.gov.qa", digitFont_7);
    ////    // headLine21.SetUnderline(1f, -2f);
    ////    Phrase p23 = new Phrase(headLine23);
    ////    Paragraph pg23 = new Paragraph();
    ////    pg23.Alignment = iTextSharp.text.pdf.PdfContentByte.ALIGN_CENTER;
    ////    pg23.Add(p23);
    ////    pg23.SpacingAfter = 3f;
    ////    doc.Add(pg23);


    ////    //if (chkPDFrnd == false)
    ////    //{
    ////    //    Chunk ch110 = new Chunk();
    ////    //    Chunk boldCh110 = null;
    ////    //    boldCh110 = new Chunk(" -------------------------------------------------------------------------------------------------------------------------------- ");
    ////    //    Phrase p12 = new Phrase(ch110);
    ////    //    p12.Add(boldCh110);
    ////    //    Paragraph pg12 = new Paragraph();
    ////    //    pg12.Add(p12);
    ////    //    pg12.SpacingAfter = 6f;
    ////    //    doc.Add(pg12);
    ////    //    // OnEndPage(writer, doc);
    ////    //}  

    ////    // OnEndPage(writer, doc);

    ////}



    //public void createPDFTableForTenderSubmission(Document doc, string strTendrNo, string strTendrTitle, string committeeName, DataTable dataTable, string closingDate, string[] companyInfo, bool isWorkOrder)
    //{
    //    // Document doc = new Document(PageSize.A4);

    //    string userFullName = null;

    //    if (strTendrNo != null)
    //        userFullName = getUserFullName(_userName);
    //    else
    //        userFullName = getUserFullName(strTendrTitle);

    //    //BaseFont bfArabic = BaseFont.CreateFont(@"C:\Windows\Fonts\arialuni.ttf", BaseFont.IDENTITY_H, BaseFont.EMBEDDED); //"F:/ArabicFonts/MOHANAD.ttf", BaseFont.IDENTITY_H, true MOHAND F:\ArabicFonts\                                                        
    //    BaseFont bfArial = BaseFont.CreateFont(@"C:\Windows\Fonts\arial.ttf", BaseFont.IDENTITY_H, BaseFont.EMBEDDED);

    //    //BaseFont bfArialItemNames = BaseFont.CreateFont(@"C:\Windows\Fonts\arial.ttf", BaseFont.IDENTITY_H, BaseFont.EMBEDDED);
    //    //iTextSharp.text.Font companyNameFont = new iTextSharp.text.Font(bfArialItemNames, 10f, Font.NORMAL, iTextSharp.text.BaseColor.BLUE);

    //    //iTextSharp.text.Font digitFont = new iTextSharp.text.Font(bfArial, 10f, iTextSharp.text.Font.NORMAL, iTextSharp.text.BaseColor.RED);
    //    iTextSharp.text.Font plainText = new iTextSharp.text.Font(bfArial, 9f);
    //    iTextSharp.text.Font headerText = new iTextSharp.text.Font(bfArial, 8f, iTextSharp.text.Font.BOLD, iTextSharp.text.BaseColor.WHITE);
    //    iTextSharp.text.Font boldText = new iTextSharp.text.Font(bfArial, 10f, iTextSharp.text.Font.BOLD, iTextSharp.text.BaseColor.BLACK);
    //    iTextSharp.text.Font headFont = new iTextSharp.text.Font(bfArial, 12f, iTextSharp.text.Font.BOLD, iTextSharp.text.BaseColor.BLACK);
    //    iTextSharp.text.Font plainText_7 = new iTextSharp.text.Font(bfArial, 6f);

    //    iTextSharp.text.Font plainText_8 = new iTextSharp.text.Font(bfArial, 8f);
    //    iTextSharp.text.Font plainText_9 = new iTextSharp.text.Font(bfArial, 9f);

    //    iTextSharp.text.Font digitFont_6 = new iTextSharp.text.Font(bfArial, 7f, iTextSharp.text.Font.NORMAL, iTextSharp.text.BaseColor.BLUE);

    //    //PdfPTable table1 = new PdfPTable(1);
    //    //table1.HorizontalAlignment = Element.ALIGN_RIGHT;
    //    //table1.RunDirection = PdfWriter.RUN_DIRECTION_LTR;
    //    //doc.Add(table1);             

    //    //Paragraph pg1 = new Paragraph();
    //    //pg1.Alignment = iTextSharp.text.pdf.PdfContentByte.ALIGN_CENTER;
    //    //pg1.Add(table1);
    //    //pg1.SpacingBefore = 1f;
    //    //doc.Add(pg1);

    //    Chunk headLine = new Chunk();
    //    if (!isWorkOrder)
    //    {
    //        if (strTendrNo != null)
    //            headLine = new Chunk("TENDER SUBMISSION SUMMARY", headFont);
    //        else
    //            headLine = new Chunk("QS WORKING STATUS ON TENDER PREPARATION", headFont);
    //    }
    //    else
    //        headLine = new Chunk("WORK ORDER TENDER SUBMISSION SUMMARY", headFont);

    //    headLine.SetUnderline(1f, -2f);
    //    Phrase phrase = new Phrase(headLine);
    //    Paragraph paraGraph = new Paragraph();
    //    paraGraph.Alignment = iTextSharp.text.pdf.PdfContentByte.ALIGN_CENTER;
    //    paraGraph.Add(phrase);
    //    paraGraph.SpacingAfter = 12f;
    //    doc.Add(paraGraph);

    //    if (strTendrNo != null)
    //    {
    //        headLine = new Chunk();
    //        headLine = new Chunk("Tender No.: " + strTendrNo, boldText);
    //        phrase = new Phrase(headLine);
    //        paraGraph = new Paragraph();
    //        paraGraph.Alignment = iTextSharp.text.pdf.PdfContentByte.ALIGN_LEFT;
    //        paraGraph.Add(phrase);
    //        paraGraph.SpacingAfter = 12f;
    //        doc.Add(paraGraph);
    //        if (!isWorkOrder)
    //            headLine = new Chunk("Tender Title: " + strTendrTitle, boldText);
    //        else
    //            headLine = new Chunk("Framework Title: " + strTendrTitle, boldText);

    //        phrase = new Phrase(headLine);
    //        paraGraph = new Paragraph();
    //        paraGraph.Alignment = iTextSharp.text.pdf.PdfContentByte.ALIGN_LEFT;
    //        paraGraph.Add(phrase);
    //        paraGraph.SpacingAfter = 12f;
    //        doc.Add(paraGraph);

    //        if (isWorkOrder)
    //        {
    //            headLine = new Chunk();
    //            headLine = new Chunk("Work Order No.: " + companyInfo[0], boldText);
    //            phrase = new Phrase(headLine);
    //            paraGraph = new Paragraph();
    //            paraGraph.Alignment = iTextSharp.text.pdf.PdfContentByte.ALIGN_LEFT;
    //            paraGraph.Add(phrase);
    //            paraGraph.SpacingAfter = 12f;
    //            doc.Add(paraGraph);
    //            headLine = new Chunk("Work Order Title: " + companyInfo[1], boldText);
    //            phrase = new Phrase(headLine);
    //            paraGraph = new Paragraph();
    //            paraGraph.Alignment = iTextSharp.text.pdf.PdfContentByte.ALIGN_LEFT;
    //            paraGraph.Add(phrase);
    //            paraGraph.SpacingAfter = 12f;
    //            doc.Add(paraGraph);
    //        }

    //        headLine = new Chunk();
    //        headLine = new Chunk("Closing Date : " + closingDate + "                     No. of Submision:" + dataTable.Select("Submission<>'' and Submission<>'Regret and Not Submitted'").Count() + "                        No. of Non-Submission:" + dataTable.Select("Submission is null or Submission='Regret and Not Submitted'").Count(), boldText);

    //        phrase = new Phrase(headLine);
    //        paraGraph = new Paragraph();
    //        paraGraph.Alignment = iTextSharp.text.pdf.PdfContentByte.ALIGN_LEFT;
    //        paraGraph.Add(phrase);
    //        paraGraph.SpacingAfter = 12f;
    //        doc.Add(paraGraph);

    //        int rowSize = 18;
    //        PdfPTable headerTable = new PdfPTable(6);
    //        headerTable.DefaultCell.Border = 0;
    //        headerTable.WidthPercentage = 100;

    //        float[] widths = new float[] { 30, 120, 100, 95, 110, 141 };
    //        headerTable.SetWidths(widths);

    //        PdfPCell pdfCell = new PdfPCell(new Phrase("SNo.", headerText));
    //        //cell7.Border = 0;
    //        pdfCell.HorizontalAlignment = PdfPCell.ALIGN_CENTER;
    //        pdfCell.FixedHeight = rowSize;
    //        pdfCell.BackgroundColor = iTextSharp.text.BaseColor.BLACK;
    //        pdfCell.VerticalAlignment = iTextSharp.text.Element.ALIGN_MIDDLE;
    //        headerTable.AddCell(pdfCell);

    //        pdfCell = new PdfPCell(new Phrase("Tenderer Name", headerText));
    //        //cell7.Border = 0;
    //        pdfCell.HorizontalAlignment = PdfPCell.ALIGN_CENTER;
    //        pdfCell.FixedHeight = rowSize;
    //        pdfCell.BackgroundColor = iTextSharp.text.BaseColor.BLACK;
    //        pdfCell.VerticalAlignment = iTextSharp.text.Element.ALIGN_MIDDLE;
    //        headerTable.AddCell(pdfCell);

    //        pdfCell = new PdfPCell(new Phrase("No. Of Envelopes", headerText));
    //        //pdfCell.NoWrap = false;
    //        //cell7.Border = 0;
    //        pdfCell.HorizontalAlignment = PdfPCell.ALIGN_CENTER;
    //        pdfCell.FixedHeight = rowSize;
    //        pdfCell.BackgroundColor = iTextSharp.text.BaseColor.BLACK;
    //        pdfCell.VerticalAlignment = iTextSharp.text.Element.ALIGN_MIDDLE;
    //        headerTable.AddCell(pdfCell);

    //        pdfCell = new PdfPCell(new Phrase("Remarks", headerText));
    //        //cell7.Border = 0;
    //        pdfCell.HorizontalAlignment = PdfPCell.ALIGN_CENTER;
    //        pdfCell.FixedHeight = rowSize;
    //        pdfCell.BackgroundColor = iTextSharp.text.BaseColor.BLACK;
    //        pdfCell.VerticalAlignment = iTextSharp.text.Element.ALIGN_MIDDLE;
    //        headerTable.AddCell(pdfCell);

    //        pdfCell = new PdfPCell(new Phrase("Submission Status", headerText));
    //        pdfCell.NoWrap = false;
    //        pdfCell.HorizontalAlignment = PdfPCell.ALIGN_CENTER;
    //        pdfCell.FixedHeight = rowSize;
    //        pdfCell.BackgroundColor = iTextSharp.text.BaseColor.BLACK;
    //        pdfCell.VerticalAlignment = iTextSharp.text.Element.ALIGN_MIDDLE;
    //        headerTable.AddCell(pdfCell);

    //        pdfCell = new PdfPCell(new Phrase("Submitted Time", headerText));
    //        //cell7.Border = 0;
    //        pdfCell.HorizontalAlignment = PdfPCell.ALIGN_CENTER;
    //        pdfCell.FixedHeight = rowSize;
    //        pdfCell.BackgroundColor = iTextSharp.text.BaseColor.BLACK;
    //        pdfCell.VerticalAlignment = iTextSharp.text.Element.ALIGN_MIDDLE;
    //        headerTable.AddCell(pdfCell);
    //        headerTable.HeaderRows = 1;

    //        PdfPCell rowCell = null;
    //        //Paragraph tableCellParaGraph = null;
    //        // storing Each row and column value to pdf file
    //        for (int i = 0; i < dataTable.Rows.Count; i++)
    //        {
    //            rowCell = new PdfPCell(new Phrase((i + 1).ToString(), plainText));//for SNO column
    //            //rowCell.BackgroundColor = new BaseColor(255, 255, 0);
    //            rowCell.HorizontalAlignment = PdfPCell.ALIGN_CENTER;
    //            headerTable.AddCell(rowCell);
    //            for (int j = 0; j < 6; j++)
    //            {
    //                if (j != 1)
    //                {
    //                    if (dataTable.Rows[i][j].ToString() != "")
    //                    {
    //                        rowCell = new PdfPCell(new Phrase(dataTable.Rows[i][j].ToString(), plainText));
    //                    }
    //                    else
    //                    {
    //                        if (j != 4)
    //                        {
    //                            rowCell = new PdfPCell(new Phrase("-", plainText));
    //                        }
    //                        else if (dataTable.Rows[i][4].ToString() == "")
    //                        {
    //                            rowCell = new PdfPCell(new Phrase("Not Submitted", plainText));
    //                        }
    //                    }
    //                    //rowCell.BackgroundColor = new BaseColor(255, 255, 0);
    //                    rowCell.HorizontalAlignment = PdfPCell.ALIGN_CENTER;
    //                    //tableCellParaGraph = new Paragraph(dataTable.Rows[i][j].ToString(), plainText);
    //                    //tableCellParaGraph.Alignment = iTextSharp.text.pdf.PdfContentByte.ALIGN_CENTER;
    //                    //rowCell.AddElement(tableCellParaGraph);
    //                    headerTable.AddCell(rowCell);
    //                }
    //            }
    //        }

    //        headerTable.SpacingAfter = 10f;
    //        headerTable.HorizontalAlignment = iTextSharp.text.pdf.PdfContentByte.ALIGN_CENTER;

    //        doc.Add(headerTable);

    //        Chunk headLineUser = new Chunk("Printed By" + ":" + userFullName + " Dated:" + DateTime.Now.ToString(), digitFont_6);
    //        Phrase pUser = new Phrase(headLineUser);
    //        Paragraph pgUser = new Paragraph();
    //        pgUser.Alignment = iTextSharp.text.pdf.PdfContentByte.ALIGN_LEFT;
    //        pgUser.Add(pUser);
    //        pgUser.SpacingAfter = 0f;
    //        doc.Add(pgUser);
    //    }
    //    else
    //    {
    //        plainText = new iTextSharp.text.Font(bfArial, 8f);
    //        int rowSize = 18;
    //        PdfPTable headerTable = new PdfPTable(11);
    //        headerTable.DefaultCell.Border = 0;
    //        headerTable.WidthPercentage = 110;
    //        headerTable.TotalWidth = 555f;

    //        float[] widths = new float[] { 31, 103, 95, 115, 125, 65, 85, 85, 85, 85, 80 };
    //        headerTable.SetWidths(widths);

    //        // storing header part in pdf file
    //        for (int i = 1; i < 12; i++)
    //        {
    //            if (i == 1) //SN
    //            {
    //                PdfPCell pdfCell = new PdfPCell(new Phrase("SN", headerText));
    //                pdfCell.BorderWidth = 1f;
    //                pdfCell.HorizontalAlignment = PdfPCell.ALIGN_CENTER;
    //                pdfCell.FixedHeight = rowSize;
    //                pdfCell.VerticalAlignment = iTextSharp.text.Element.ALIGN_CENTER;
    //                pdfCell.BackgroundColor = iTextSharp.text.BaseColor.BLACK;
    //                headerTable.AddCell(pdfCell);
    //            }
    //            else if (i == 2) //QSStaffName
    //            {
    //                PdfPCell pdfCell = new PdfPCell(new Phrase(dataTable.Columns[12].ColumnName, headerText));
    //                pdfCell.BorderWidth = 1f;
    //                pdfCell.HorizontalAlignment = PdfPCell.ALIGN_CENTER;
    //                pdfCell.FixedHeight = rowSize;
    //                pdfCell.VerticalAlignment = iTextSharp.text.Element.ALIGN_CENTER;
    //                pdfCell.BackgroundColor = iTextSharp.text.BaseColor.BLACK;
    //                headerTable.AddCell(pdfCell);
    //            }
    //            else if (i == 3) //ReceivedDate
    //            {
    //                PdfPCell pdfCell = new PdfPCell(new Phrase(dataTable.Columns[13].ColumnName, headerText));
    //                pdfCell.BorderWidth = 1f;
    //                pdfCell.HorizontalAlignment = PdfPCell.ALIGN_CENTER;
    //                pdfCell.FixedHeight = rowSize;
    //                pdfCell.VerticalAlignment = iTextSharp.text.Element.ALIGN_CENTER;
    //                pdfCell.BackgroundColor = iTextSharp.text.BaseColor.BLACK;
    //                headerTable.AddCell(pdfCell);
    //            }
    //            else if (i == 4) //ProjectCode
    //            {
    //                PdfPCell pdfCell = new PdfPCell(new Phrase(dataTable.Columns[2].ColumnName, headerText));
    //                pdfCell.NoWrap = false;
    //                pdfCell.BorderWidth = 1f;
    //                pdfCell.HorizontalAlignment = PdfPCell.ALIGN_CENTER;
    //                pdfCell.FixedHeight = rowSize;
    //                pdfCell.VerticalAlignment = iTextSharp.text.Element.ALIGN_CENTER;
    //                pdfCell.BackgroundColor = iTextSharp.text.BaseColor.BLACK;
    //                headerTable.AddCell(pdfCell);
    //            }
    //            else if (i == 5) //ProjectTitle
    //            {
    //                PdfPCell pdfCell = new PdfPCell(new Phrase(dataTable.Columns[3].ColumnName, headerText));
    //                pdfCell.NoWrap = false;
    //                pdfCell.BorderWidth = 1f;
    //                pdfCell.HorizontalAlignment = PdfPCell.ALIGN_CENTER;
    //                pdfCell.FixedHeight = rowSize;
    //                pdfCell.VerticalAlignment = iTextSharp.text.Element.ALIGN_CENTER;
    //                pdfCell.BackgroundColor = iTextSharp.text.BaseColor.BLACK;
    //                headerTable.AddCell(pdfCell);
    //            }
    //            else if (i == 6) //Purpose 
    //            {
    //                PdfPCell pdfCell = new PdfPCell(new Phrase(dataTable.Columns[14].ColumnName, headerText));
    //                pdfCell.BorderWidth = 1f;
    //                pdfCell.HorizontalAlignment = PdfPCell.ALIGN_CENTER;
    //                pdfCell.FixedHeight = rowSize;
    //                pdfCell.VerticalAlignment = iTextSharp.text.Element.ALIGN_CENTER;
    //                pdfCell.BackgroundColor = iTextSharp.text.BaseColor.BLACK;
    //                headerTable.AddCell(pdfCell);
    //            }
    //            else if (i == 7) //TypeOfTender
    //            {
    //                PdfPCell pdfCell = new PdfPCell(new Phrase(dataTable.Columns[7].ColumnName, headerText));
    //                pdfCell.BorderWidth = 1f;
    //                pdfCell.HorizontalAlignment = PdfPCell.ALIGN_CENTER;
    //                pdfCell.FixedHeight = rowSize;
    //                pdfCell.VerticalAlignment = iTextSharp.text.Element.ALIGN_CENTER;
    //                pdfCell.BackgroundColor = iTextSharp.text.BaseColor.BLACK;
    //                headerTable.AddCell(pdfCell);
    //            }
    //            else if (i == 8) //TenderStatus
    //            {
    //                PdfPCell pdfCell = new PdfPCell(new Phrase(dataTable.Columns[6].ColumnName, headerText));
    //                pdfCell.NoWrap = false;
    //                pdfCell.BorderWidth = 1f;
    //                pdfCell.HorizontalAlignment = PdfPCell.ALIGN_CENTER;
    //                pdfCell.FixedHeight = rowSize;
    //                pdfCell.VerticalAlignment = iTextSharp.text.Element.ALIGN_CENTER;
    //                pdfCell.BackgroundColor = iTextSharp.text.BaseColor.BLACK;
    //                headerTable.AddCell(pdfCell);
    //            }
    //            else if (i == 9) //UserDepartment
    //            {
    //                PdfPCell pdfCell = new PdfPCell(new Phrase(dataTable.Columns[11].ColumnName, headerText));
    //                pdfCell.NoWrap = false;
    //                pdfCell.BorderWidth = 1f;
    //                pdfCell.HorizontalAlignment = PdfPCell.ALIGN_CENTER;
    //                pdfCell.FixedHeight = rowSize;
    //                pdfCell.VerticalAlignment = iTextSharp.text.Element.ALIGN_CENTER;
    //                pdfCell.BackgroundColor = iTextSharp.text.BaseColor.BLACK;
    //                headerTable.AddCell(pdfCell);
    //            }
    //            else if (i == 10) //TenderCommittee
    //            {
    //                PdfPCell pdfCell = new PdfPCell(new Phrase(dataTable.Columns[8].ColumnName, headerText));
    //                pdfCell.NoWrap = false;
    //                pdfCell.BorderWidth = 1f;
    //                pdfCell.HorizontalAlignment = PdfPCell.ALIGN_CENTER;
    //                pdfCell.FixedHeight = rowSize;
    //                pdfCell.VerticalAlignment = iTextSharp.text.Element.ALIGN_CENTER;
    //                pdfCell.BackgroundColor = iTextSharp.text.BaseColor.BLACK;
    //                headerTable.AddCell(pdfCell);
    //            }
    //            else if (i == 11) //FiscalYear
    //            {
    //                PdfPCell pdfCell = new PdfPCell(new Phrase(dataTable.Columns[10].ColumnName, headerText));
    //                pdfCell.BorderWidth = 1f;
    //                pdfCell.HorizontalAlignment = PdfPCell.ALIGN_CENTER;
    //                pdfCell.FixedHeight = rowSize;
    //                pdfCell.VerticalAlignment = iTextSharp.text.Element.ALIGN_CENTER;
    //                pdfCell.BackgroundColor = iTextSharp.text.BaseColor.BLACK;
    //                headerTable.AddCell(pdfCell);
    //            }
    //        }
    //        headerTable.HeaderRows = 1;

    //        PdfPCell rowCell = null;
    //        for (int i = 0; i < dataTable.Rows.Count; i++)
    //        {
    //            rowCell = new PdfPCell(new Phrase((i + 1).ToString(), plainText));//for SNO column
    //            //rowCell.BackgroundColor = new BaseColor(255, 255, 0);
    //            rowCell.HorizontalAlignment = PdfPCell.ALIGN_CENTER;
    //            headerTable.AddCell(rowCell);
    //            for (int j = 1; j < 11; j++)
    //            {
    //                if (j == 1) //QSStaffName
    //                {
    //                    rowCell = new PdfPCell(new Phrase("", plainText));
    //                    if (dataTable.Rows[i][12].ToString() != "")
    //                    {
    //                        rowCell = new PdfPCell(new Phrase(dataTable.Rows[i][12].ToString(), plainText));
    //                        //rowCell.BackgroundColor = new BaseColor(255, 255, 0);                                
    //                        //tableCellParaGraph = new Paragraph(dataTable.Rows[i][j].ToString(), plainText);
    //                        //tableCellParaGraph.Alignment = iTextSharp.text.pdf.PdfContentByte.ALIGN_CENTER;
    //                        //rowCell.AddElement(tableCellParaGraph);                             
    //                    }
    //                    headerTable.AddCell(rowCell);
    //                }
    //                else if (j == 2) //ReceivedDate
    //                {
    //                    rowCell = new PdfPCell(new Phrase("", plainText));
    //                    if (dataTable.Rows[i][13].ToString() != "")
    //                        rowCell = new PdfPCell(new Phrase(dataTable.Rows[i][13].ToString(), plainText));
    //                    headerTable.AddCell(rowCell);
    //                }
    //                else if (j == 3) //ProjectCode
    //                {
    //                    rowCell = new PdfPCell(new Phrase("", plainText));
    //                    if (dataTable.Rows[i][2].ToString() != "")
    //                        rowCell = new PdfPCell(new Phrase(dataTable.Rows[i][2].ToString(), plainText));
    //                    headerTable.AddCell(rowCell);
    //                }
    //                else if (j == 4) //ProjectTitle
    //                {
    //                    rowCell = new PdfPCell(new Phrase("", plainText));
    //                    if (dataTable.Rows[i][3].ToString() != "")
    //                        rowCell = new PdfPCell(new Phrase(dataTable.Rows[i][3].ToString(), plainText));
    //                    headerTable.AddCell(rowCell);
    //                }
    //                else if (j == 5) //Purpose
    //                {
    //                    rowCell = new PdfPCell(new Phrase("", plainText));
    //                    if (dataTable.Rows[i][14].ToString() != "")
    //                        rowCell = new PdfPCell(new Phrase(dataTable.Rows[i][14].ToString(), plainText));
    //                    headerTable.AddCell(rowCell);
    //                }
    //                else if (j == 6) //TypeOfTender
    //                {
    //                    rowCell = new PdfPCell(new Phrase("", plainText));
    //                    if (dataTable.Rows[i][7].ToString() != "")
    //                        rowCell = new PdfPCell(new Phrase(dataTable.Rows[i][7].ToString(), plainText));
    //                    headerTable.AddCell(rowCell);
    //                }
    //                else if (j == 7) //TenderStatus
    //                {
    //                    rowCell = new PdfPCell(new Phrase("", plainText));
    //                    if (dataTable.Rows[i][6].ToString() != "")
    //                        rowCell = new PdfPCell(new Phrase(dataTable.Rows[i][6].ToString(), plainText));
    //                    headerTable.AddCell(rowCell);
    //                }
    //                else if (j == 8) //UserDepartment
    //                {
    //                    rowCell = new PdfPCell(new Phrase("", plainText));
    //                    if (dataTable.Rows[i][11].ToString() != "")
    //                        rowCell = new PdfPCell(new Phrase(dataTable.Rows[i][11].ToString(), plainText));
    //                    headerTable.AddCell(rowCell);
    //                }
    //                else if (j == 9) //TenderCommittee
    //                {
    //                    rowCell = new PdfPCell(new Phrase("", plainText));
    //                    if (dataTable.Rows[i][8].ToString() != "")
    //                        rowCell = new PdfPCell(new Phrase(dataTable.Rows[i][8].ToString(), plainText));
    //                    headerTable.AddCell(rowCell);
    //                }
    //                else if (j == 10) //FiscalYear
    //                {
    //                    rowCell = new PdfPCell(new Phrase("", plainText));
    //                    if (dataTable.Rows[i][10].ToString() != "")
    //                        rowCell = new PdfPCell(new Phrase(dataTable.Rows[i][10].ToString(), plainText));
    //                    headerTable.AddCell(rowCell);
    //                }

    //            }
    //        }

    //        headerTable.SpacingAfter = 10f;
    //        headerTable.HorizontalAlignment = iTextSharp.text.pdf.PdfContentByte.ALIGN_CENTER;
    //        doc.Add(headerTable);

    //        Chunk headLineUser = new Chunk("Printed By" + ":" + userFullName + " Dated:" + DateTime.Now.ToString(), digitFont_6);
    //        Phrase pUser = new Phrase(headLineUser);
    //        Paragraph pgUser = new Paragraph();
    //        pgUser.Alignment = iTextSharp.text.pdf.PdfContentByte.ALIGN_LEFT;
    //        pgUser.Add(pUser);
    //        pgUser.SpacingAfter = 0f;
    //        doc.Add(pgUser);
    //    }

    //}

    //public void ExportToPDF(string typeOfReport, string strCon, DataTable finalTenderersInfo, string tenderNo, string committeeName, string projTitle, string tenderClosingDate, ref string[] workOrderInfo, bool isWorkOrder, bool isTenderClosingDateStage2)
    //{
    //    string sqlQuery = null;
    //    SqlDataReader sqlDtReader = null;
    //    StringBuilder strBuild = null;
    //    try
    //    {
    //        byte[] newPdf = null;
    //        //BaseFont bf = BaseFont.CreateFont("C:/Windows/Fonts/Al-MOHANAD.ttf", BaseFont.IDENTITY_H, BaseFont.EMBEDDED);                                     
    //        using (var pdfMemStream = new MemoryStream())
    //        {
    //            var doc = new Document(iTextSharp.text.PageSize.A4);
    //            using (PdfWriter writer = PdfWriter.GetInstance(doc, pdfMemStream))
    //            {
    //                doc.AddAuthor("PWA-ASHGHAL");
    //                doc.AddCreator("TCMS-APP");
    //                PageEventHelper pageEventHelper = new PageEventHelper();
    //                if (typeOfReport != "OngoingTenders")
    //                    pageEventHelper.CheckReceipt = 'O';
    //                writer.PageEvent = pageEventHelper;

    //                //string sylfaenpath = Environment.GetEnvironmentVariable("SystemRoot") + "\\fonts\\Al-MOHANAD.ttf";                             

    //                doc.Open();
    //                BaseFont bfArialItemNames = BaseFont.CreateFont(@"C:\Windows\Fonts\arial.ttf", BaseFont.IDENTITY_H, BaseFont.EMBEDDED);
    //                iTextSharp.text.Font companyNameFont = new iTextSharp.text.Font(bfArialItemNames, 10f, Font.NORMAL, iTextSharp.text.BaseColor.BLUE);
    //                sqlQuery = "Select LogoImage from Logo where LogoId = 2";
    //                iTextSharp.text.Image pngImg = null;
    //                sqlConn = new SqlConnection(strCon);
    //                sqlConn.Open();
    //                SqlCommand sqlCom = new SqlCommand(sqlQuery, sqlConn);
    //                sqlDtReader = sqlCom.ExecuteReader();
    //                if (sqlDtReader.Read())
    //                    pngImg = iTextSharp.text.Image.GetInstance((byte[])sqlDtReader[0]);
    //                sqlDtReader.Close();
    //                pngImg.ScaleToFit(540f, 540f);

    //                doc.Add(pngImg);
    //                if (typeOfReport != "OngoingTenders")
    //                    createPDFTableForTenderSubmission(doc, tenderNo, projTitle, committeeName, finalTenderersInfo, tenderClosingDate, workOrderInfo, isWorkOrder);
    //                else
    //                    createPDFTableForTenderSubmission(doc, null, projTitle, null, finalTenderersInfo, null, null, false);
    //                //doc.Add(pngImg);
    //                //createPDF_Table(doc, strTendrNo, strTendrTitle, companyInfo, writer, true);                               
    //                //  createPDF_Table_TenderDocuments(doc, strTendrNo, strTendrTitle, companyInfo, writer, docFee, totCircularNos, true);                        
    //                doc.Close();
    //                newPdf = pdfMemStream.GetBuffer();
    //            }
    //        }
    //        try
    //        {
    //            strBuild = stringBuilderFunction('R', tenderNo, ref workOrderInfo, newPdf, 'N', 1, sqlConn, null, isWorkOrder, isTenderClosingDateStage2);
    //        }
    //        catch (Exception ex)
    //        {
    //            MessageBox.Show("Error occurred while creating the pdf file. Please close already created and opened pdf file and then try again! " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
    //        }
    //    }
    //    catch (DocumentException dex)
    //    {
    //        MessageBox.Show("Exception occurred while creating the pdf file " + dex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
    //    }
    //    catch (IOException ioex)
    //    {
    //        //Handle IO exception //"Exception occurred while creating the pdf file"
    //        MessageBox.Show("Exception occurred while creating the pdf file " + ioex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
    //    }
    //    catch (Exception ex)
    //    {
    //        MessageBox.Show("Exception occurred while creating the pdf file" + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
    //    }
    //    //return strBuild.ToString();


    //    //return null;
    //}

    //public string ExportToPDF(string strCon, SqlCommand sqlCom, DataGridView dataGridView, System.Data.DataView dv, string strTendrNo, string projCode, string strTendrTitle, int projID, string closingDate, string strModifiedDate, int totCircularNos, string tenderBond, string docFee, string tenderIssueDate, char isTenderExpiry, char isEmail, string strEligibleTenderTypes, string typeOfTender, Int16 noOfExtns, string[] companyInfo, int logoType, string typeOfPdfDoc, short numOfPages, string versionNo, bool isWorkOrder, bool isTenderClosingDateStage2)
    //{
    //    string sqlQuery = null;
    //    SqlDataReader sqlDtReader = null;
    //    StringBuilder strBuild = null;
    //    try
    //    {
    //        byte[] newPdf = null;
    //        //BaseFont bf = BaseFont.CreateFont("C:/Windows/Fonts/Al-MOHANAD.ttf", BaseFont.IDENTITY_H, BaseFont.EMBEDDED);                                     
    //        using (var pdfMemStream = new MemoryStream())
    //        {
    //            var doc = new Document(iTextSharp.text.PageSize.A4);
    //            using (PdfWriter writer = PdfWriter.GetInstance(doc, pdfMemStream))
    //            {
    //                doc.AddAuthor("PWA-ASHGHAL");
    //                doc.AddCreator("TCMS-APP");
    //                PageEventHelper pageEventHelper = new PageEventHelper();

    //                if (isTenderExpiry == 'I')
    //                {
    //                    pageEventHelper.CheckReceipt = 'I';
    //                    pageEventHelper.TypeOfDoc = typeOfPdfDoc;
    //                }
    //                else if (isTenderExpiry == 'T')
    //                {
    //                    pageEventHelper.CheckReceipt = 'T';
    //                    pageEventHelper.TypeOfDoc = companyInfo[5].ToString();
    //                }
    //                else if (isTenderExpiry != 'Y')
    //                    pageEventHelper.CheckReceipt = 'O';

    //                writer.PageEvent = pageEventHelper;

    //                //string sylfaenpath = Environment.GetEnvironmentVariable("SystemRoot") + "\\fonts\\Al-MOHANAD.ttf";                             

    //                doc.Open();
    //                BaseFont bfArialItemNames = BaseFont.CreateFont(@"C:\Windows\Fonts\arial.ttf", BaseFont.IDENTITY_H, BaseFont.EMBEDDED);
    //                iTextSharp.text.Font companyNameFont = new iTextSharp.text.Font(bfArialItemNames, 10f, Font.NORMAL, iTextSharp.text.BaseColor.BLUE);

    //                if (logoType == 2)
    //                    sqlQuery = "Select LogoImage from Logo where LogoId = 2";
    //                else
    //                    sqlQuery = "Select LogoImage from Logo where LogoId = 1";

    //                iTextSharp.text.Image pngImg = null;
    //                sqlConn = new SqlConnection(strCon);
    //                sqlConn.Open();
    //                sqlCom = new SqlCommand(sqlQuery, sqlConn);
    //                sqlDtReader = sqlCom.ExecuteReader();
    //                if (sqlDtReader.Read())
    //                    pngImg = iTextSharp.text.Image.GetInstance((byte[])sqlDtReader[0]);
    //                sqlDtReader.Close();
    //                pngImg.ScaleToFit(540f, 540f);

    //                //  Code isTenderExpiry == 'I' code written by Varun on 02/05/2014            // - Tender submission T
    //                if (isTenderExpiry == 'T') // Create pdf file for the receipt to be issued to the bidder after inserting the new bidder info
    //                {
    //                    doc.Add(pngImg);
    //                    createPDF_Table(doc, strTendrNo, strTendrTitle, companyInfo, writer, isWorkOrder);
    //                    //doc.Add(pngImg);
    //                    //createPDF_Table(doc, strTendrNo, strTendrTitle, companyInfo, writer, true);                               
    //                    //  createPDF_Table_TenderDocuments(doc, strTendrNo, strTendrTitle, companyInfo, writer, docFee, totCircularNos, true);                        
    //                }
    //                // Code isTenderExpiry == 'I' code written by Varun on 02/05/2014                                // I - Issue tender
    //                else if (isTenderExpiry == 'I') // Create pdf file for the receipt to be issued to the bidder after inserting the new bidder info (on Issue A Tender)
    //                {
    //                    doc.Add(pngImg);
    //                    createPDF_Table_TenderDocuments(doc, strTendrNo, strTendrTitle, companyInfo, writer, docFee, projCode, tenderIssueDate, tenderBond, closingDate, strModifiedDate, noOfExtns, strEligibleTenderTypes, typeOfTender, totCircularNos);

    //                    //doc.Add(pngImg);
    //                    //createPDF_Table_TenderDocuments(doc, strTendrNo, strTendrTitle, companyInfo, writer, docFee, true, projCode, tenderIssueDate, tenderBond, strClosingDate, strModifiedDate, noOfExtns, strEligibleTenderTypes, typeOfTender, totCircularNos, collectedBy);
    //                }
    //                // N means Not Tender submission and Issue tender
    //                else if (isTenderExpiry == 'N')
    //                {
    //                    noTender(doc, pngImg, dataGridView, dv, strTendrNo, strTendrTitle, projCode, tenderIssueDate, tenderBond, closingDate, strModifiedDate, noOfExtns, strEligibleTenderTypes, typeOfTender, totCircularNos, docFee);
    //                }
    //                else
    //                {
    //                    NonTenderSub(doc, dataGridView);
    //                }
    //                // doc.Add(pngImg);

    //                doc.Close();
    //                newPdf = pdfMemStream.GetBuffer();
    //            }
    //        }
    //        try
    //        {

    //            strBuild = stringBuilderFunction(isTenderExpiry, strTendrNo, ref companyInfo, newPdf, isEmail, numOfPages, sqlConn, versionNo, isWorkOrder, isTenderClosingDateStage2);
    //        }
    //        catch (Exception ex)
    //        {
    //            MessageBox.Show("Error occurred while creating the pdf file. Please close already created and opened pdf file and then try again! " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
    //        }
    //    }
    //    catch (DocumentException dex)
    //    {
    //        MessageBox.Show("Exception occurred while creating the pdf file " + dex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
    //    }
    //    catch (IOException ioex)
    //    {
    //        //Handle IO exception //"Exception occurred while creating the pdf file"
    //        MessageBox.Show("Exception occurred while creating the pdf file " + ioex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
    //    }
    //    catch (Exception ex)
    //    {
    //        MessageBox.Show("Exception occurred while creating the pdf file" + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
    //    }
    //    return strBuild.ToString();
    //}

    string strCmt = string.Empty;
    private string getCommitteName(int _mProjId)
    {
        using (SqlConnection sqlCn = new SqlConnection(connStr))
        {
            sqlCn.Open();
            string sqlQuery = "SELECT Committee.committee_short_name, PROJECTS.project_code FROM  PROJECTS INNER JOIN Committee ON PROJECTS.committee_id = Committee.committee_id  " +
                           " WHERE PROJECTS.proj_id = " + _mProjId;

            SqlCommand sqlCmd = new SqlCommand(sqlQuery, sqlCn);
            SqlDataReader sqlDr = sqlCmd.ExecuteReader();
            while (sqlDr.Read())
            {
                strCmt = sqlDr[0].ToString();
            }
            sqlDr.Close();
        }
        return strCmt;
    }


    //private StringBuilder stringBuilderFunction(char isTenderExpiry, string strTendrNo, ref string[] companyInfo, byte[] newPdf, char isEmail, short numOfPages, SqlConnection sqlConn, string versionNo, bool isWorkOrder, bool isTenderClosingDateStage2)
    //{
    //    StringBuilder strBuild = new StringBuilder();
    //    MemoryStream mStram = new MemoryStream();
    //    mStram.Write(newPdf, 0, newPdf.Length);
    //    mStram.Seek(0, SeekOrigin.Begin);

    //    //var tempFilePath = Path.ChangeExtension(Path.GetTempFileName(), ".pdf");
    //    string tempFilePath = null;
    //    if (!isWorkOrder)
    //        tempFilePath = ConfigurationManager.AppSettings["TCMSFiles"].ToString();
    //    else
    //    {
    //        if (isTenderExpiry != 'R')
    //            tempFilePath = ConfigurationManager.AppSettings["TCMSWOFiles"].ToString();
    //        else
    //            tempFilePath = ConfigurationManager.AppSettings["TCMSTenderWOSubmissionReports"].ToString();
    //    }
    //    if (strTendrNo != null)
    //    {
    //        string folderName = strTendrNo.Replace("/", "-").Replace("\\", "-");
    //        //strBuild.Append(tempFilePath.Substring(0, tempFilePath.LastIndexOf('\\')).ToString() + "\\" + folderName);
    //        strBuild.Append(tempFilePath + "\\" + folderName);
    //        if (!Directory.Exists(strBuild.ToString()))  // if it doesn't exist, create
    //            Directory.CreateDirectory(strBuild.ToString());
    //    }

    //    if (isTenderExpiry == 'N')
    //    {
    //        if (strBuild.Length != 0)
    //            strBuild.Append("\\Tender Collection Summary Report.pdf");
    //        else
    //            strBuild.Append(tempFilePath + "\\Tender Collection Summary Report.pdf");
    //    }
    //    else if (isTenderExpiry == 'Y')
    //        strBuild.Append(tempFilePath + "\\Tender Validity Expiration Per Committee.pdf");
    //    else if (isTenderExpiry == 'I') //I for Issue A Tender
    //    {
    //        strBuild.Append("\\" + strTendrNo.Replace("/", "-") + companyInfo[5].Replace("/", "-").Replace("\\", "-").Trim().ToString() + ".pdf");

    //        if (File.Exists(strBuild.ToString()))
    //            File.Delete(strBuild.ToString());
    //    }
    //    else if (isTenderExpiry == 'T') //T for TenderSubmission
    //    {
    //        //Added by Varun on 7th May 2014
    //        string pdfFileName = companyInfo[1].Replace("/\r\n", "-").Replace("\\", "-").Replace("/", "") + "-" + strTendrNo.Replace("/", "-") + "-" + companyInfo[4].Replace("/", "-");
    //        strBuild.Append("\\" + pdfFileName + ".pdf");
    //    }
    //    else if (isTenderExpiry == 'R') //R for Report Generation for TenderSubmission and Work Order Submission
    //    {
    //        string pdfFileName = null;
    //        if (strTendrNo != null)
    //        {
    //            //Added by Varun on 2nd Nov 2015
    //            if (companyInfo != null)
    //                pdfFileName = strTendrNo.Replace("/", "-") + "-" + companyInfo[0] + "-WorkOrderSubmissionReport";
    //            else
    //                pdfFileName = strTendrNo.Replace("/", "-") + "-TenderSubmissionReport";
    //        }
    //        else
    //        {
    //            if (!Directory.Exists("C:\\OngoingTendersReport"))  // if it doesn't exist, create
    //                Directory.CreateDirectory("C:\\OngoingTendersReport");
    //            strBuild.Append("C:\\OngoingTendersReport");
    //            pdfFileName = "OngoingTendersReport";
    //        }
    //        strBuild.Append("\\" + pdfFileName + ".pdf");
    //    }


    //    File.WriteAllBytes(strBuild.ToString(), newPdf);

    //    string pdfOut = string.Empty;
    //    if (isTenderExpiry == 'T')
    //    {
    //        pdfOut = getPDF("", strBuild.ToString(), numOfPages, sqlConn, versionNo, ref companyInfo, null, isWorkOrder, isTenderClosingDateStage2);
    //        //  pdfOut = getPDF_Next("", strBuild.ToString());
    //        //File.Create(pdfOut, newPdf.Length, FileOptions.DeleteOnClose);
    //        Process.Start(pdfOut);
    //    }
    //    else if (isTenderExpiry == 'I')
    //    {
    //        string committeeShortName = null;
    //        if (strTendrNo.Contains("STC"))
    //            committeeShortName = "STC";
    //        else if (strTendrNo.Contains("GTC"))
    //            committeeShortName = "GTC";
    //        else if (strTendrNo.Contains("ITC"))
    //            committeeShortName = "ITC";
    //        else if (strTendrNo.Contains("MRPSC"))
    //            committeeShortName = "MRPSC";
    //        else if (strTendrNo.Contains("EUWC"))
    //            committeeShortName = "EUWC";
    //        else if (strTendrNo.Contains("NC"))
    //            committeeShortName = "NC";
    //        pdfOut = getPDF("", strBuild.ToString(), numOfPages, sqlConn, versionNo, ref companyInfo, committeeShortName, isWorkOrder, isTenderClosingDateStage2);
    //        Process.Start(pdfOut);
    //    }
    //    else
    //    {
    //        Process.Start(strBuild.ToString());
    //    }

    //    // writePDF("", strBuild.ToString());

    //    //  System.Diagnostics.Process.Start(pdfOut);
    //    if (isEmail != 'Y')

    //        try
    //        {
    //            // Process.Start(strBuild.ToString());
    //            if (isTenderExpiry == 'T')
    //            {
    //                strBuild = new StringBuilder();
    //                strBuild.Append("Opened");
    //                //MessageBox.Show("Pdf file is successfully created and is ready for Print command");
    //            }
    //        }
    //        catch (Exception ex)
    //        {
    //            MessageBox.Show("Unable to open pdf file, Please install Adobe Acrobat Reader software and then try again! " + ex.Message, "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
    //        }


    //    return strBuild;
    //}
    ////private void NonTenderSub(Document doc, DataGridView dgView)
    //{
    //    BaseFont bfArabic = BaseFont.CreateFont(@"C:\Windows\Fonts\arialuni.ttf", BaseFont.IDENTITY_H, BaseFont.EMBEDDED); //"F:/ArabicFonts/MOHANAD.ttf", BaseFont.IDENTITY_H, true MOHAND F:\ArabicFonts\                                                        
    //    BaseFont bfArial = BaseFont.CreateFont(@"C:\Windows\Fonts\arial.ttf", BaseFont.IDENTITY_H, BaseFont.EMBEDDED);

    //    BaseFont bfArialItemNames = BaseFont.CreateFont(@"C:\Windows\Fonts\arial.ttf", BaseFont.IDENTITY_H, BaseFont.EMBEDDED);
    //    iTextSharp.text.Font companyNameFont = new iTextSharp.text.Font(bfArialItemNames, 10f, Font.NORMAL, iTextSharp.text.BaseColor.BLUE);

    //    iTextSharp.text.Font plainText = new iTextSharp.text.Font(bfArial, 10f);
    //    iTextSharp.text.Font boldText = new iTextSharp.text.Font(bfArial, 10f, iTextSharp.text.Font.BOLD, iTextSharp.text.BaseColor.BLACK);

    //    iTextSharp.text.Font digitFont_7 = new iTextSharp.text.Font(bfArial, 7f, iTextSharp.text.Font.NORMAL, iTextSharp.text.BaseColor.RED);

    //    iTextSharp.text.Font headerText = new iTextSharp.text.Font(iTextSharp.text.Font.FontFamily.TIMES_ROMAN, 12f);
    //    plainText = new iTextSharp.text.Font(iTextSharp.text.Font.FontFamily.TIMES_ROMAN, 8f);
    //    boldText = new iTextSharp.text.Font(iTextSharp.text.Font.FontFamily.TIMES_ROMAN, 9f, iTextSharp.text.Font.BOLD, iTextSharp.text.BaseColor.BLACK);

    //    DAL dalObj = new DAL();
    //    BindingSource bidSource = (BindingSource)dgView.DataSource;
    //    DataTable dtTenderExpiries = (DataTable)bidSource.DataSource;
    //    //dalObj.GetDataFromDB("TenderExpiries", sqlQuery);
    //    PdfPTable table = null;
    //    table = new PdfPTable(7);
    //    table.TotalWidth = 555f;
    //    table.LockedWidth = true;
    //    float[] widths = new float[] { 9f, 23f, 27f, 16f, 10f, 13f, 19f };
    //    //float[] widths = new float[] { 8f, 22f, 27f, 16f, 10f, 13f, 17f,10f,10f };
    //    table.SetWidths(widths);
    //    int totRows = 0;
    //    totRows = dtTenderExpiries.Rows.Count;

    //    Chunk ch = new Chunk("List of Projects where Tender Validity Expiration is Less than 20 days", headerText);
    //    Chunk boldCh4 = new Chunk("                                            Project Count =" + totRows, plainText);

    //    Phrase p1 = new Phrase(ch);
    //    p1.Add(boldCh4);

    //    Paragraph pg4 = new Paragraph();
    //    pg4.Add(p1);
    //    pg4.SpacingAfter = 10f;
    //    doc.Add(pg4);

    //    if (totRows != 0)
    //    {
    //        table = createTable(totRows, table, plainText, boldText, null, dtTenderExpiries.DefaultView, 'Y');
    //        doc.Add(table);
    //    }
    //}
    //private void noTender(Document doc, iTextSharp.text.Image pngImg, DataGridView dgView, System.Data.DataView dv, string strTendrNo, string strTendrTitle, string projCode, string tenderIssueDate, string tenderBond, string strClosingDate, string strModifiedDate, Int16 noOfExtns, string strEligibleTenderTypes, string typeOfTender, int totCircularNos, string docFee)
    //{
    //    BaseFont bfArabic = BaseFont.CreateFont(@"C:\Windows\Fonts\arialuni.ttf", BaseFont.IDENTITY_H, BaseFont.EMBEDDED); //"F:/ArabicFonts/MOHANAD.ttf", BaseFont.IDENTITY_H, true MOHAND F:\ArabicFonts\                                                        
    //    BaseFont bfArial = BaseFont.CreateFont(@"C:\Windows\Fonts\arial.ttf", BaseFont.IDENTITY_H, BaseFont.EMBEDDED);
    //    Font arabicBoldMaroonFont = new Font(bfArabic, 10, Font.BOLD, new BaseColor(176, 48, 96)); //255, 20, 147)); //C:\Windows\Fonts\Al-MOHANAD.ttf arialuni
    //    Font arabicBoldBlackFont = new Font(bfArabic, 11, Font.BOLD, BaseColor.BLACK);
    //    Font arabicNormalBlackFont = new Font(bfArabic, 10, Font.NORMAL, BaseColor.BLACK);
    //    Font arabicNormalBlackFont_7 = new Font(bfArabic, 7, Font.NORMAL, BaseColor.BLACK);

    //    BaseFont bfArialItemNames = BaseFont.CreateFont(@"C:\Windows\Fonts\arial.ttf", BaseFont.IDENTITY_H, BaseFont.EMBEDDED);
    //    iTextSharp.text.Font companyNameFont = new iTextSharp.text.Font(bfArialItemNames, 10f, Font.NORMAL, iTextSharp.text.BaseColor.BLUE);

    //    iTextSharp.text.Font digitFont = new iTextSharp.text.Font(bfArial, 10f, iTextSharp.text.Font.NORMAL, iTextSharp.text.BaseColor.RED);
    //    iTextSharp.text.Font plainText = new iTextSharp.text.Font(bfArial, 10f);
    //    iTextSharp.text.Font boldText = new iTextSharp.text.Font(bfArial, 10f, iTextSharp.text.Font.BOLD, iTextSharp.text.BaseColor.BLACK);
    //    iTextSharp.text.Font headFont = new iTextSharp.text.Font(bfArial, 12f, iTextSharp.text.Font.BOLD, iTextSharp.text.BaseColor.BLACK);
    //    iTextSharp.text.Font plainText_7 = new iTextSharp.text.Font(bfArial, 6f);

    //    iTextSharp.text.Font digitFont_7 = new iTextSharp.text.Font(bfArial, 7f, iTextSharp.text.Font.NORMAL, iTextSharp.text.BaseColor.RED);
    //    doc.Add(pngImg);

    //    Chunk headLine = new Chunk("Tender Collection Summary", headFont);
    //    headLine.SetUnderline(1f, -2f);
    //    Phrase p1 = new Phrase(headLine);
    //    Paragraph pg1 = new Paragraph();
    //    pg1.Alignment = iTextSharp.text.pdf.PdfContentByte.ALIGN_CENTER;
    //    pg1.Add(p1);
    //    pg1.SpacingAfter = 5f;
    //    doc.Add(pg1);

    //    typeOfTender = GetTypeOfTender(typeOfTender);
    //    Chunk chTypeOfTender = new Chunk("Type of Tender :", plainText);
    //    Chunk boldTypeOfTender = new Chunk("  " + typeOfTender, boldText);
    //    Phrase pTypeOfTender = new Phrase(chTypeOfTender);
    //    pTypeOfTender.Add(boldTypeOfTender);
    //    Paragraph pgTypeOfTender = new Paragraph();
    //    pgTypeOfTender.Add(pTypeOfTender);
    //    pgTypeOfTender.SpacingAfter = 5f;
    //    doc.Add(pgTypeOfTender);

    //    Chunk ch4 = new Chunk("Tender No        :", plainText);
    //    Chunk boldCh4 = new Chunk("  " + strTendrNo, boldText);
    //    Phrase p4 = new Phrase(ch4);
    //    p4.Add(boldCh4);
    //    Paragraph pg4 = new Paragraph();
    //    pg4.Add(p4);
    //    pg4.SpacingAfter = 5f;
    //    doc.Add(pg4);

    //    Chunk ch2 = new Chunk("Project Code     :", plainText);
    //    Chunk boldCh2 = new Chunk(" " + projCode, boldText);
    //    Phrase p2 = new Phrase(ch2);
    //    p2.Add(boldCh2);
    //    Paragraph pg2 = new Paragraph();
    //    pg2.Add(p2);
    //    pg2.SpacingAfter = 5f;
    //    doc.Add(pg2);

    //    Chunk ch3 = new Chunk("Tender Title       :", plainText);
    //    Chunk boldCh3 = new Chunk(" " + strTendrTitle, boldText);
    //    Phrase p3 = new Phrase(ch3);
    //    p3.Add(boldCh3);
    //    Paragraph pg3 = new Paragraph();
    //    pg3.Add(p3);
    //    pg3.SpacingAfter = 5f;
    //    doc.Add(pg3);

    //    //dtProjCost = dalObj.GetDataFromDB("ProjectCost", "select tender_bond,doc_fee from ProjectCost where proj_id=" + projID);
    //    Chunk ch8 = new Chunk("Tender Bond      :", plainText);
    //    Chunk boldCh8 = null;
    //    boldCh8 = new Chunk(" " + tenderBond, boldText);
    //    Phrase p8 = new Phrase(ch8);
    //    p8.Add(boldCh8);
    //    Paragraph pg8 = new Paragraph();
    //    pg8.Add(p8);
    //    pg8.SpacingAfter = 5f;
    //    doc.Add(pg8);

    //    //Modified By Varun on 16th Feb 2014 replace prAdvDate by tenderIssueDate based on Riyas request
    //    Chunk ch9 = new Chunk("Date of Tender Announcement  :", plainText);
    //    Chunk boldCh9 = new Chunk("  " + tenderIssueDate, boldText);
    //    Phrase p9 = new Phrase(ch9);
    //    p9.Add(boldCh9);
    //    Paragraph pg9 = new Paragraph();
    //    pg9.Add(p9);
    //    pg9.SpacingAfter = 5f;
    //    doc.Add(pg9);

    //    Chunk boldCh10 = null;
    //    Chunk ch10 = new Chunk("Document Fee      :", plainText);
    //    boldCh10 = new Chunk("  " + docFee, boldText);
    //    Phrase p10 = new Phrase(ch10);
    //    p10.Add(boldCh10);
    //    Paragraph pg10 = new Paragraph();
    //    pg10.Add(p10);
    //    pg10.SpacingAfter = 5f;
    //    doc.Add(pg10);

    //    Chunk ch5 = new Chunk("Tender Closing Date  :", plainText);
    //    Chunk boldCh5 = new Chunk("  " + strClosingDate, boldText);
    //    Phrase p5 = new Phrase(ch5);
    //    p5.Add(boldCh5);

    //    if (strModifiedDate != "")
    //    {
    //        Chunk ch7 = new Chunk("                   ", plainText);
    //        p5.Add(ch7);
    //        Chunk ch6 = new Chunk("Modified Closing Date :", plainText);
    //        Chunk boldCh6 = new Chunk("  " + strModifiedDate, boldText);
    //        p5.Add(ch6);
    //        p5.Add(boldCh6);

    //        Chunk ckNoOfExtnsSpace = new Chunk("             ", plainText);
    //        p5.Add(ckNoOfExtnsSpace);
    //        Chunk ckNoOfExtns = new Chunk("No. of Extensions    :", plainText);
    //        p5.Add(ckNoOfExtns);
    //        Chunk boldChNoOfExtns = new Chunk("  " + (noOfExtns + 1), boldText);
    //        p5.Add(boldChNoOfExtns);
    //    }
    //    Paragraph pg5 = new Paragraph();
    //    pg5.Add(p5);
    //    pg5.SpacingAfter = 5f;
    //    doc.Add(pg5);

    //    Chunk ch11 = new Chunk("No. of Circulars    :", plainText);
    //    Chunk boldCh11 = null;
    //    if (totCircularNos == 0)
    //        boldCh11 = new Chunk(" " + "0", boldText);
    //    else
    //        boldCh11 = new Chunk(" " + totCircularNos, boldText);
    //    Phrase p11 = new Phrase(ch11);
    //    p11.Add(boldCh11);
    //    Paragraph pg11 = new Paragraph();
    //    pg11.Add(p11);
    //    pg11.SpacingAfter = 5f;
    //    doc.Add(pg11);

    //    Chunk boldCh12 = null;
    //    Chunk ch12 = new Chunk("Eligible To Tender:", plainText);
    //    boldCh12 = new Chunk(" " + strEligibleTenderTypes, boldText);
    //    Phrase p12 = new Phrase(ch12);
    //    p12.Add(boldCh12);
    //    Paragraph pg12 = new Paragraph();
    //    pg12.Add(p12);
    //    pg12.SpacingAfter = 5f;
    //    doc.Add(pg12);

    //    PdfPTable table2 = null;
    //    table2 = new PdfPTable(10);
    //    table2.TotalWidth = 561f;
    //    table2.LockedWidth = true;
    //    float[] widths = new float[] { 5f, 18f, 13f, 14f, 13f, 12f, 12f, 13f, 20f, 14f };
    //    //float[] widths = new float[] { 5f, 17f, 13f, 14f, 12f, 10f, 10f, 9f, 16f,11f,15f };
    //    table2.SetWidths(widths);
    //    int totRows = 0;

    //    if (dgView == null)
    //        totRows = dv.Table.Rows.Count;
    //    else
    //        totRows = dgView.Rows.Count;

    //    table2 = createTable(totRows, table2, plainText, boldText, dgView, dv, 'N');
    //    doc.Add(table2);
    //}

    //private void IssueTender(Document doc, string strTendrNo, string strTendrTitle, string[] companyInfo, PdfWriter writer, iTextSharp.text.Image pngImg, int totCircularNos, string docFee, string collectedBy)
    //{
    //    BaseFont bfArabic = BaseFont.CreateFont(@"C:\Windows\Fonts\arialuni.ttf", BaseFont.IDENTITY_H, BaseFont.EMBEDDED); //"F:/ArabicFonts/MOHANAD.ttf", BaseFont.IDENTITY_H, true MOHAND F:\ArabicFonts\                                                        
    //    BaseFont bfArial = BaseFont.CreateFont(@"C:\Windows\Fonts\arial.ttf", BaseFont.IDENTITY_H, BaseFont.EMBEDDED);
    //    Font arabicBoldMaroonFont = new Font(bfArabic, 10, Font.BOLD, new BaseColor(176, 48, 96)); //255, 20, 147)); //C:\Windows\Fonts\Al-MOHANAD.ttf arialuni
    //    Font arabicBoldBlackFont = new Font(bfArabic, 11, Font.BOLD, BaseColor.BLACK);
    //    Font arabicNormalBlackFont = new Font(bfArabic, 10, Font.NORMAL, BaseColor.BLACK);
    //    Font arabicNormalBlackFont_7 = new Font(bfArabic, 7, Font.NORMAL, BaseColor.BLACK);

    //    BaseFont bfArialItemNames = BaseFont.CreateFont(@"C:\Windows\Fonts\arial.ttf", BaseFont.IDENTITY_H, BaseFont.EMBEDDED);
    //    iTextSharp.text.Font companyNameFont = new iTextSharp.text.Font(bfArialItemNames, 10f, Font.NORMAL, iTextSharp.text.BaseColor.BLUE);

    //    iTextSharp.text.Font digitFont = new iTextSharp.text.Font(bfArial, 10f, iTextSharp.text.Font.NORMAL, iTextSharp.text.BaseColor.RED);
    //    iTextSharp.text.Font plainText = new iTextSharp.text.Font(bfArial, 10f);
    //    iTextSharp.text.Font boldText = new iTextSharp.text.Font(bfArial, 10f, iTextSharp.text.Font.BOLD, iTextSharp.text.BaseColor.BLACK);
    //    iTextSharp.text.Font headFont = new iTextSharp.text.Font(bfArial, 12f, iTextSharp.text.Font.BOLD, iTextSharp.text.BaseColor.BLACK);
    //    iTextSharp.text.Font plainText_7 = new iTextSharp.text.Font(bfArial, 6f);
    //    iTextSharp.text.Font digitFont_7 = new iTextSharp.text.Font(bfArial, 7f, iTextSharp.text.Font.NORMAL, iTextSharp.text.BaseColor.RED);


    //    PdfPTable table1 = new PdfPTable(1);
    //    table1.HorizontalAlignment = Element.ALIGN_RIGHT;
    //    table1.RunDirection = PdfWriter.RUN_DIRECTION_RTL;
    //    doc.Add(table1);
    //    doc.Add(pngImg);

    //    Chunk ch7 = new Chunk("No. " + companyInfo[5].Trim().ToString(), digitFont);
    //    Phrase p17 = new Phrase(ch7);
    //    Paragraph pg4 = new Paragraph();
    //    pg4.Alignment = iTextSharp.text.pdf.PdfContentByte.ALIGN_RIGHT;
    //    pg4.Add(p17);
    //    pg4.SpacingBefore = 5f;
    //    pg4.SpacingAfter = 5f;
    //    doc.Add(pg4);

    //    Chunk headLine = new Chunk("RECEIPT OF TENDER DOCUMENTS", headFont);
    //    headLine.SetUnderline(1f, -2f);
    //    Phrase p1 = new Phrase(headLine);
    //    Paragraph pg1 = new Paragraph();
    //    pg1.Alignment = iTextSharp.text.pdf.PdfContentByte.ALIGN_CENTER;
    //    pg1.Add(p1);
    //    pg1.SpacingAfter = 20f;
    //    doc.Add(pg1);

    //    // typeOfTender = GetTypeOfTender(typeOfTender);  

    //}
   
    //private void GetData(Document doc, System.Windows.Forms.DataGridView dgView, System.Data.DataView dv, string strTendrNo, string projCode, string strTendrTitle, int projID, string strClosingDate, string strModifiedDate, int totCircularNos, string tenderBond, string docFee, string tenderIssueDate, char isTenderExpiry, char isEmail, string strEligibleTenderTypes, string typeOfTender, Int16 noOfExtns, string[] companyInfo, ref string tenderSubmissionDateAndTime)
    //{
    //    BaseFont bfArabic = BaseFont.CreateFont(@"C:\Windows\Fonts\arialuni.ttf", BaseFont.IDENTITY_H, BaseFont.EMBEDDED); //"F:/ArabicFonts/MOHANAD.ttf", BaseFont.IDENTITY_H, true MOHAND F:\ArabicFonts\                                                        
    //    BaseFont bfArial = BaseFont.CreateFont(@"C:\Windows\Fonts\arial.ttf", BaseFont.IDENTITY_H, BaseFont.EMBEDDED);
    //    Font arabicBoldMaroonFont = new Font(bfArabic, 10, Font.BOLD, new BaseColor(176, 48, 96)); //255, 20, 147)); //C:\Windows\Fonts\Al-MOHANAD.ttf arialuni
    //    Font arabicBoldBlackFont = new Font(bfArabic, 11, Font.BOLD, BaseColor.BLACK);
    //    Font arabicNormalBlackFont = new Font(bfArabic, 10, Font.NORMAL, BaseColor.BLACK);
    //    Font arabicNormalBlackFont_7 = new Font(bfArabic, 7, Font.NORMAL, BaseColor.BLACK);

    //    BaseFont bfArialItemNames = BaseFont.CreateFont(@"C:\Windows\Fonts\arial.ttf", BaseFont.IDENTITY_H, BaseFont.EMBEDDED);
    //    iTextSharp.text.Font companyNameFont = new iTextSharp.text.Font(bfArialItemNames, 10f, Font.NORMAL, iTextSharp.text.BaseColor.BLUE);

    //    iTextSharp.text.Font digitFont = new iTextSharp.text.Font(bfArial, 10f, iTextSharp.text.Font.NORMAL, iTextSharp.text.BaseColor.RED);
    //    iTextSharp.text.Font plainText = new iTextSharp.text.Font(bfArial, 10f);
    //    iTextSharp.text.Font boldText = new iTextSharp.text.Font(bfArial, 10f, iTextSharp.text.Font.BOLD, iTextSharp.text.BaseColor.BLACK);
    //    iTextSharp.text.Font headFont = new iTextSharp.text.Font(bfArial, 12f, iTextSharp.text.Font.BOLD, iTextSharp.text.BaseColor.BLACK);
    //    iTextSharp.text.Font plainText_7 = new iTextSharp.text.Font(bfArial, 6f);
    //    iTextSharp.text.Font digitFont_7 = new iTextSharp.text.Font(bfArial, 7f, iTextSharp.text.Font.NORMAL, iTextSharp.text.BaseColor.RED);

    //    iTextSharp.text.Image pngImg = null;
    //    string sqlQuery = "select LogoImage from Logo where LogoId = 2";
    //    sqlConn = new SqlConnection(connStr);
    //    sqlConn.Open();
    //    SqlCommand sqlCom = new SqlCommand(sqlQuery, sqlConn);

    //    sqlDtReader = sqlCom.ExecuteReader();
    //    if (sqlDtReader.Read())
    //        pngImg = iTextSharp.text.Image.GetInstance((byte[])sqlDtReader[0]);

    //    sqlDtReader.Close();
    //    pngImg.ScaleToFit(540f, 540f);

    //    // Code isTenderExpiry == 'I' code written by Varun on 02/05/2014
    //    if (isTenderExpiry == 'T') // Create pdf file for the receipt to be issued to the bidder after inserting the new bidder info
    //    {
    //        doc.Add(pngImg);

    //        // Chunk chImg1 = new Chunk("قســـم لجـــان المناقصـــات والمزايـــدات Tenders & Auctions Committees Section", arabicBoldMaroonFont); //                                                                                                                                                     
    //        PdfPTable table1 = new PdfPTable(1);
    //        table1.HorizontalAlignment = Element.ALIGN_RIGHT;
    //        table1.RunDirection = PdfWriter.RUN_DIRECTION_RTL;
    //        // PdfPCell cell1 = new PdfPCell(new Phrase(chImg1));                                 
    //        // cell1.Border = 0;
    //        // table1.AddCell(cell1);

    //        //PdfPCell cell2 = null;
    //        //if (projCode == "STC")
    //        //{                                     
    //        //    cell2 = new PdfPCell(new Phrase("لجنـــة المناقصـــات الصغـــرى Small Tenders Committee", arabicBoldMaroonFont));                                    
    //        //    cell2.Border = 0;
    //        //    table1.AddCell(cell2);                           
    //        //}
    //        //else if (projCode == "ITC")
    //        //{                                                              
    //        //    cell2 = new PdfPCell(new Phrase("لجنـــة المناقصـــات الوســـطى  Intermediate Tenders Committee", arabicBoldMaroonFont));                                    
    //        //    cell2.Border = 0;
    //        //    table1.AddCell(cell2);   
    //        //}
    //        //else if (projCode == "GTC")
    //        //{                                     
    //        //    cell2 = new PdfPCell(new Phrase("لجنـــة المناقصـــات الكبـــرى  Grand Tenders Committee", arabicBoldMaroonFont));                                    
    //        //    cell2.Border = 0;
    //        //    table1.AddCell(cell2);  
    //        //}
    //        //else if (projCode == "MRPSC")
    //        //{                                     
    //        //    cell2 = new PdfPCell(new Phrase("لجنـــة تسييـــر مشروعـــات إنشـــاء الطـــرق الرئيسيـــة  Main Roads Projects Steering Committee", arabicBoldMaroonFont));                                    
    //        //    cell2.Border = 0;
    //        //    table1.AddCell(cell2);  
    //        //}
    //        //else if (projCode == "EUWC")
    //        //{                                     
    //        //    cell2 = new PdfPCell(new Phrase("لجنـــة الحـــالات الطارئـــة والعاجلـــة  Emergency & Urgent Works Committee", arabicBoldMaroonFont));                                    
    //        //    cell2.Border = 0;
    //        //    table1.AddCell(cell2);  
    //        //}
    //        doc.Add(table1);

    //        PdfPTable table4 = new PdfPTable(1);
    //        table4.RunDirection = PdfWriter.RUN_DIRECTION_RTL;
    //        PdfPCell cell4 = new PdfPCell(new Phrase("إيصال استلام عروض مناقصة", arabicBoldBlackFont));
    //        cell4.Border = 0;
    //        cell4.HorizontalAlignment = PdfPCell.ALIGN_CENTER;
    //        table4.AddCell(cell4);

    //        Paragraph pg1 = new Paragraph();
    //        pg1.Alignment = iTextSharp.text.pdf.PdfContentByte.ALIGN_CENTER;
    //        pg1.Add(table4);
    //        pg1.SpacingBefore = 3f;
    //        doc.Add(pg1);

    //        Chunk headLine2 = new Chunk("Receipt Voucher for Tender Offers", headFont);
    //        headLine2.SetUnderline(1f, -2f);
    //        Phrase p2 = new Phrase(headLine2);
    //        Paragraph pg2 = new Paragraph();
    //        pg2.Alignment = iTextSharp.text.pdf.PdfContentByte.ALIGN_CENTER;
    //        pg2.Add(p2);
    //        pg2.SpacingAfter = 15f;
    //        doc.Add(pg2);

    //        //Chunk ch8 = null;
    //        //Chunk ch9 = null;
    //        //ch8 = new Chunk("Ver. No. ", digitFont);
    //        //if (companyInfo[6].ToString() == "")
    //        //    ch9 = new Chunk("1", digitFont);
    //        //else
    //        //    ch9 = new Chunk(companyInfo[6].ToString(), digitFont);
    //        //Phrase p18 = new Phrase(ch8);
    //        //p18.Add(ch9);
    //        //Paragraph pg5 = new Paragraph();
    //        //pg5.Alignment = iTextSharp.text.pdf.PdfContentByte.ALIGN_LEFT;
    //        //pg5.Add(p18);
    //        //pg5.SpacingAfter = 5f;
    //        //doc.Add(pg5);

    //        //Chunk ch7 = null;
    //        //ch7 = new Chunk("No. " + companyInfo[0].ToString(), digitFont);
    //        //Phrase p17 = new Phrase(ch7);
    //        //Paragraph pg4 = new Paragraph();
    //        //pg4.Alignment = iTextSharp.text.pdf.PdfContentByte.ALIGN_LEFT;
    //        //pg4.Add(p17);
    //        //pg4.SpacingAfter = 6f;
    //        //doc.Add(pg4);


    //        PdfPTable table2 = new PdfPTable(1);
    //        table2.WidthPercentage = 100;

    //        table2.HorizontalAlignment = Element.ALIGN_CENTER;
    //        PdfPCell cell3 = new PdfPCell(new Phrase());
    //        //cell3.BorderWidthLeft = 1f;
    //        //cell3.BorderWidthRight = 1f;
    //        //cell3.BorderWidthTop = 1f;
    //        //cell3.BorderWidthBottom = 1f;
    //        table2.AddCell(cell3);

    //        PdfPTable table3 = new PdfPTable(3);
    //        table3.HorizontalAlignment = Element.ALIGN_CENTER;
    //        int[] secondTablecellWidth = { 18, 25, 18 };
    //        table3.SetWidths(secondTablecellWidth);

    //        PdfPCell cell10 = new PdfPCell(new Phrase("Date  &  Time  :", plainText));
    //        //cell10.Border = 10;
    //        cell10.HorizontalAlignment = PdfPCell.ALIGN_LEFT;
    //        table3.AddCell(cell10);

    //        tenderSubmissionDateAndTime = DateTime.Now.ToLongDateString() + " " + DateTime.Now.ToLongTimeString();
    //        PdfPCell cell5 = new PdfPCell(new Phrase(tenderSubmissionDateAndTime, plainText));
    //        cell5.Border = 10;
    //        cell5.HorizontalAlignment = PdfPCell.ALIGN_CENTER;
    //        table3.AddCell(cell5);

    //        PdfPCell cell11 = new PdfPCell(new Phrase(":  التاريخ و الوقت", arabicNormalBlackFont));
    //        cell11.Border = 10;
    //        cell11.RunDirection = PdfWriter.RUN_DIRECTION_RTL;
    //        cell11.HorizontalAlignment = PdfPCell.ALIGN_LEFT;
    //        table3.AddCell(cell11);

    //        PdfPCell cell7 = new PdfPCell(new Phrase("Tender No.      :", plainText));
    //        cell7.Border = 10;
    //        cell7.HorizontalAlignment = PdfPCell.ALIGN_LEFT;
    //        table3.AddCell(cell7);

    //        PdfPCell cell8 = new PdfPCell(new Phrase(strTendrNo, plainText));
    //        cell8.Border = 10;
    //        cell8.HorizontalAlignment = PdfPCell.ALIGN_CENTER;
    //        table3.AddCell(cell8);

    //        PdfPCell cell12 = new PdfPCell(new Phrase(": 	رقم المناقصة", arabicNormalBlackFont));
    //        cell12.Border = 10;
    //        cell12.RunDirection = PdfWriter.RUN_DIRECTION_RTL;
    //        cell12.HorizontalAlignment = PdfPCell.ALIGN_LEFT;
    //        table3.AddCell(cell12);

    //        PdfPCell cell9 = new PdfPCell(new Phrase("Tender Title     :", plainText));
    //        cell9.Border = 10;
    //        cell9.FixedHeight = 45f;
    //        cell9.HorizontalAlignment = PdfPCell.ALIGN_LEFT;
    //        table3.AddCell(cell9);

    //        PdfPCell cell13 = new PdfPCell(new Phrase(strTendrTitle, plainText));
    //        cell13.Border = 10;
    //        cell13.NoWrap = false;
    //        cell13.FixedHeight = 35f;
    //        cell13.HorizontalAlignment = PdfPCell.ALIGN_CENTER;
    //        table3.AddCell(cell13);

    //        PdfPCell cell14 = new PdfPCell(new Phrase(": 	اسم المناقصة", arabicNormalBlackFont));
    //        cell14.Border = 10;
    //        cell14.FixedHeight = 35f;
    //        cell14.RunDirection = PdfWriter.RUN_DIRECTION_RTL;
    //        cell14.HorizontalAlignment = PdfPCell.ALIGN_LEFT;
    //        table3.AddCell(cell14);

    //        PdfPCell cell15 = new PdfPCell(new Phrase("Received from	 :", plainText));
    //        cell15.Border = 10;
    //        cell15.FixedHeight = 35f;
    //        cell15.HorizontalAlignment = PdfPCell.ALIGN_LEFT;
    //        table3.AddCell(cell15);

    //        PdfPCell cell16 = new PdfPCell(new Phrase(companyInfo[1].ToString(), companyNameFont));
    //        cell16.Border = 10;
    //        cell16.FixedHeight = 35f;
    //        cell16.HorizontalAlignment = PdfPCell.ALIGN_CENTER;
    //        table3.AddCell(cell16);

    //        PdfPCell cell17 = new PdfPCell(new Phrase(": 	استلمت من السادة", arabicNormalBlackFont));
    //        cell17.Border = 10;
    //        cell17.FixedHeight = 35f;
    //        cell17.RunDirection = PdfWriter.RUN_DIRECTION_RTL;
    //        cell17.HorizontalAlignment = PdfPCell.ALIGN_LEFT;
    //        table3.AddCell(cell17);

    //        if (companyInfo[4].ToString() != "")
    //        {
    //            PdfPCell cell30 = new PdfPCell(new Phrase("Tenderer Submission Remarks   :", plainText));
    //            cell30.Border = 10;
    //            cell30.HorizontalAlignment = PdfPCell.ALIGN_LEFT;
    //            table3.AddCell(cell30);

    //            PdfPCell cell31 = new PdfPCell(new Phrase(companyInfo[4].ToString(), plainText));
    //            cell31.Border = 10;
    //            cell31.HorizontalAlignment = PdfPCell.ALIGN_CENTER;
    //            table3.AddCell(cell31);

    //            PdfPCell cell32 = new PdfPCell(new Phrase("", plainText));
    //            cell32.Border = 10;
    //            cell32.HorizontalAlignment = PdfPCell.ALIGN_RIGHT;
    //            table3.AddCell(cell32);
    //        }

    //        PdfPCell cell18 = null;
    //        if (companyInfo[2].ToString() == "")
    //            cell18 = new PdfPCell(new Phrase("No Envelopes for the above Tender", plainText));
    //        else
    //            cell18 = new PdfPCell(new Phrase("No. (" + companyInfo[2].ToString() + ") Envelopes for the above Tender", plainText));
    //        cell18.Border = 10;
    //        cell18.NoWrap = true;
    //        cell18.HorizontalAlignment = PdfPCell.ALIGN_LEFT;
    //        table3.AddCell(cell18);

    //        PdfPCell cell19 = new PdfPCell(new Phrase("  "));
    //        cell19.Border = 10;
    //        cell19.HorizontalAlignment = PdfPCell.ALIGN_CENTER;
    //        table3.AddCell(cell19);

    //        PdfPCell cell20 = null;
    //        if (companyInfo[2].ToString() == "")
    //            cell20 = new PdfPCell(new Phrase("عدد (" + 0 + ") ظرفاً للمناقصة المذكورة أعلاه", arabicNormalBlackFont));
    //        else
    //            cell20 = new PdfPCell(new Phrase("عدد (" + companyInfo[2].ToString() + ") ظرفاً للمناقصة المذكورة أعلاه", arabicNormalBlackFont));
    //        cell20.Border = 10;
    //        cell20.RunDirection = PdfWriter.RUN_DIRECTION_RTL;
    //        cell20.HorizontalAlignment = PdfPCell.ALIGN_LEFT;
    //        table3.AddCell(cell20);

    //        PdfPCell cell21 = new PdfPCell(new Phrase("Received and Signed by  :", plainText));
    //        cell21.Border = 10;
    //        cell21.HorizontalAlignment = PdfPCell.ALIGN_LEFT;
    //        table3.AddCell(cell21);

    //        PdfPCell cell22 = new PdfPCell(new Phrase(companyInfo[3].ToString(), plainText));
    //        cell22.Border = 10;
    //        cell22.HorizontalAlignment = PdfPCell.ALIGN_CENTER;
    //        table3.AddCell(cell22);

    //        PdfPCell cell23 = new PdfPCell(new Phrase("إسم وتوقيع المستلم", arabicNormalBlackFont));
    //        cell23.Border = 10;
    //        cell23.RunDirection = PdfWriter.RUN_DIRECTION_RTL;
    //        cell23.HorizontalAlignment = PdfPCell.ALIGN_LEFT;
    //        table3.AddCell(cell23);

    //        PdfPCell cell27 = new PdfPCell(new Phrase("", plainText));
    //        cell27.Border = 10;
    //        cell27.FixedHeight = 25f;
    //        cell27.HorizontalAlignment = PdfPCell.ALIGN_LEFT;
    //        table3.AddCell(cell27);

    //        PdfPCell cell28 = new PdfPCell(new Phrase("", plainText));
    //        cell28.Border = 10;
    //        cell28.FixedHeight = 25f;
    //        cell28.HorizontalAlignment = PdfPCell.ALIGN_CENTER;
    //        table3.AddCell(cell28);

    //        PdfPCell cell29 = new PdfPCell(new Phrase("", arabicNormalBlackFont));
    //        cell29.Border = 10;
    //        cell29.FixedHeight = 25f;
    //        cell29.RunDirection = PdfWriter.RUN_DIRECTION_RTL;
    //        cell29.HorizontalAlignment = PdfPCell.ALIGN_LEFT;
    //        table3.AddCell(cell29);

    //        PdfPCell cell24 = new PdfPCell(new Phrase("", plainText));
    //        cell24.Border = 10;
    //        cell24.HorizontalAlignment = PdfPCell.ALIGN_LEFT;
    //        table3.AddCell(cell24);

    //        PdfPCell cell25 = new PdfPCell(new Phrase("Signature", plainText));
    //        // cell25.Border = 10;
    //        cell25.HorizontalAlignment = PdfPCell.ALIGN_LEFT;
    //        table3.AddCell(cell25);

    //        PdfPCell cell26 = new PdfPCell(new Phrase("", arabicNormalBlackFont));
    //        // cell26.Border = 10;
    //        // cell26.RunDirection = PdfWriter.RUN_DIRECTION_RTL;
    //        //cell26.HorizontalAlignment = PdfPCell.ALIGN_LEFT;
    //        table3.AddCell(cell26);

    //        table2.AddCell(table3);
    //        doc.Add(table2);

    //        // Chunk ch11 = new Chunk("COLLECTED BY :", plainText);

    //        Chunk headLine21 = new Chunk(" إدارة العقود، هيئة الأشغال العامة، هاتف: 0077 4495 974+ ، فاكس: 0780 4495 974+ ، ص. ب.: 22188 الدوحة – قطر.", arabicNormalBlackFont_7);
    //        // headLine21.SetUnderline(1f, -2f);
    //        Phrase p21 = new Phrase(headLine21);
    //        Paragraph pg21 = new Paragraph();
    //        pg21.Alignment = iTextSharp.text.pdf.PdfContentByte.ALIGN_CENTER;
    //        pg21.Add(p21);
    //        pg21.SpacingBefore = 15f;
    //        doc.Add(pg21);

    //        // Chunk headLine21 = new Chunk("P.O. Box: 22188, Doha – Qatar, Tel: +974 44950743/44950758, Fax: +974 44950777 email:contracts@ashghal.gov.qa");

    //        Chunk headLine22 = new Chunk("Contracts Department, Public Works Authority Tel : + 97444950077,Fax : + 974 4495 0780,P.O Box 22188, Doha - Qatar", plainText_7);
    //        // headLine21.SetUnderline(1f, -2f);
    //        Phrase p22 = new Phrase(headLine22);
    //        Paragraph pg22 = new Paragraph();
    //        pg22.Alignment = iTextSharp.text.pdf.PdfContentByte.ALIGN_CENTER;
    //        pg22.Add(p22);
    //        pg22.SpacingAfter = 0f;
    //        doc.Add(pg22);

    //        Chunk headLine23 = new Chunk("www.ashghal.gov.qa", digitFont_7);
    //        // headLine21.SetUnderline(1f, -2f);
    //        Phrase p23 = new Phrase(headLine23);
    //        Paragraph pg23 = new Paragraph();
    //        pg23.Alignment = iTextSharp.text.pdf.PdfContentByte.ALIGN_CENTER;
    //        pg23.Add(p23);
    //        pg23.SpacingAfter = 6f;
    //        doc.Add(pg23);

    //        //Chunk ch110 = new Chunk();
    //        //Chunk boldCh110 = null;
    //        //boldCh110 = new Chunk(" ___________________________________________________________________________ ");
    //        //Phrase p12 = new Phrase(ch110);
    //        //p12.Add(boldCh110);
    //        //Paragraph pg12 = new Paragraph();
    //        //pg12.Add(p12);
    //        //pg12.SpacingAfter = 8f;
    //        //doc.Add(pg12);         

    //    }
    //    // Code isTenderExpiry == 'I' code written by Varun on 02/05/2014
    //    else if (isTenderExpiry == 'I') // Create pdf file for the receipt to be issued to the bidder after inserting the new bidder info (on Issue A Tender)
    //    {

    //        doc.Add(pngImg);
    //        Chunk ch7 = new Chunk("No. " + companyInfo[5].Trim().ToString(), digitFont);
    //        Phrase p17 = new Phrase(ch7);
    //        Paragraph pg4 = new Paragraph();
    //        pg4.Alignment = iTextSharp.text.pdf.PdfContentByte.ALIGN_RIGHT;
    //        pg4.Add(p17);
    //        pg4.SpacingBefore = 5f;
    //        pg4.SpacingAfter = 5f;
    //        doc.Add(pg4);

    //        Chunk headLine = new Chunk("RECEIPT OF TENDER DOCUMENTS", headFont);
    //        headLine.SetUnderline(1f, -2f);
    //        Phrase p1 = new Phrase(headLine);
    //        Paragraph pg1 = new Paragraph();
    //        pg1.Alignment = iTextSharp.text.pdf.PdfContentByte.ALIGN_CENTER;
    //        pg1.Add(p1);
    //        pg1.SpacingAfter = 20f;
    //        doc.Add(pg1);

    //        typeOfTender = GetTypeOfTender(typeOfTender);
    //        Chunk chTypeOfTender = new Chunk("Tender No.      :", plainText);
    //        Chunk boldTypeOfTender = new Chunk("  " + strTendrNo, boldText);
    //        Phrase pTypeOfTender = new Phrase(chTypeOfTender);
    //        pTypeOfTender.Add(boldTypeOfTender);
    //        Paragraph pgTypeOfTender = new Paragraph();
    //        pgTypeOfTender.Add(pTypeOfTender);
    //        pgTypeOfTender.SpacingAfter = 12f;
    //        doc.Add(pgTypeOfTender);

    //        Chunk ch3 = new Chunk("Tender Title    :", plainText);
    //        Chunk boldCh3 = new Chunk(" " + strTendrTitle, boldText);
    //        Phrase p3 = new Phrase(ch3);
    //        p3.Add(boldCh3);
    //        Paragraph pg3 = new Paragraph();
    //        pg3.Add(p3);
    //        pg3.SpacingAfter = 12f;
    //        doc.Add(pg3);

    //        Chunk ch2 = new Chunk("Project Code    :", plainText);
    //        Chunk boldCh2 = new Chunk(" " + projCode, boldText);
    //        Phrase p2 = new Phrase(ch2);
    //        p2.Add(boldCh2);
    //        Paragraph pg2 = new Paragraph();
    //        pg2.Add(p2);
    //        pg2.SpacingAfter = 12f;
    //        doc.Add(pg2);

    //        Chunk boldCh10 = null;
    //        Chunk ch10 = new Chunk("Document Fee  :", plainText);
    //        boldCh10 = new Chunk(" " + docFee, boldText);
    //        Phrase p10 = new Phrase(ch10);
    //        p10.Add(boldCh10);
    //        Paragraph pg10 = new Paragraph();
    //        pg10.Add(p10);
    //        pg10.SpacingAfter = 12f;
    //        doc.Add(pg10);

    //        Chunk ch8 = new Chunk("Pay Bill No.     :", plainText);
    //        Chunk boldCh8 = null;
    //        boldCh8 = new Chunk(" " + companyInfo[4].Trim().ToString(), boldText);
    //        Phrase p8 = new Phrase(ch8);
    //        p8.Add(boldCh8);
    //        Paragraph pg8 = new Paragraph();
    //        pg8.Add(p8);
    //        pg8.SpacingAfter = 12f;
    //        doc.Add(pg8);


    //        //Modified By Varun on 16th Feb 2014 replace prAdvDate by tenderIssueDate based on Riyas request
    //        Chunk ch9 = new Chunk("Date of Tender Issue  :", plainText);
    //        Chunk boldCh9 = new Chunk("  " + tenderIssueDate, boldText);
    //        Phrase p9 = new Phrase(ch9);
    //        p9.Add(boldCh9);
    //        Paragraph pg9 = new Paragraph();
    //        pg9.Add(p9);
    //        pg9.SpacingAfter = 12f;
    //        doc.Add(pg9);


    //        Chunk ch11 = new Chunk("COLLECTED BY :", plainText);
    //        Chunk boldCh11 = null;
    //        boldCh11 = new Chunk(" ____________________________________________________", boldText);
    //        Phrase p11 = new Phrase(ch11);
    //        p11.Add(boldCh11);
    //        Paragraph pg11 = new Paragraph();
    //        pg11.Add(p11);
    //        pg11.SpacingAfter = 12f;
    //        doc.Add(pg11);

    //        Chunk boldCh12 = null;
    //        Chunk ch12 = new Chunk("FOR AND ON BEHALF OF : ", plainText);
    //        boldCh12 = new Chunk(companyInfo[0].ToString(), boldText);
    //        Phrase p12 = new Phrase(ch12);
    //        p12.Add(boldCh12);
    //        Paragraph pg12 = new Paragraph();
    //        pg12.Add(p12);
    //        pg12.SpacingAfter = 12f;
    //        doc.Add(pg12);

    //        Chunk boldCh13 = null;
    //        Chunk ch13 = new Chunk("Company Address : ", plainText);
    //        boldCh13 = new Chunk(companyInfo[1].Trim().ToString(), boldText);
    //        Phrase p13 = new Phrase(ch13);
    //        p13.Add(boldCh13);
    //        Paragraph pg13 = new Paragraph();
    //        pg13.Add(p13);
    //        pg13.SpacingAfter = 12f;
    //        doc.Add(pg13);

    //        Chunk boldCh14 = null;
    //        Chunk ch14 = new Chunk("Company Tel/Fax/Cell : ", plainText);
    //        boldCh14 = new Chunk(companyInfo[2].Trim().ToString(), boldText);
    //        Phrase p14 = new Phrase(ch14);
    //        p14.Add(boldCh14);
    //        Paragraph pg14 = new Paragraph();
    //        pg14.Add(p14);
    //        pg14.SpacingAfter = 12f;
    //        doc.Add(pg14);

    //        Chunk boldCh15 = null;
    //        Chunk ch15 = new Chunk("Contact Email Address : ", plainText);
    //        boldCh15 = new Chunk(companyInfo[3].Trim().ToString(), boldText);
    //        Phrase p15 = new Phrase(ch15);
    //        p15.Add(boldCh15);
    //        Paragraph pg15 = new Paragraph();
    //        pg15.Add(p15);
    //        pg15.SpacingAfter = 12f;
    //        doc.Add(pg15);

    //        Chunk boldCh16 = null;
    //        Chunk ch16 = new Chunk("Date and Time Drawings/Specs/DVD Collected  :", plainText);
    //        boldCh16 = new Chunk(" " + tenderIssueDate, boldText);
    //        Phrase p16 = new Phrase(ch16);
    //        p16.Add(boldCh16);
    //        Paragraph pg16 = new Paragraph();
    //        pg16.Add(p16);
    //        pg16.SpacingAfter = 12f;
    //        doc.Add(pg16);

    //        Chunk ch20 = new Chunk("Total No. of Tender Circulars Issued  :", plainText);
    //        Chunk boldCh28 = null;
    //        boldCh28 = new Chunk(" " + totCircularNos, boldText);
    //        Phrase p28 = new Phrase(ch20);
    //        p28.Add(boldCh28);
    //        Paragraph pg28 = new Paragraph();
    //        pg28.Add(p28);
    //        pg28.SpacingAfter = 12f;
    //        doc.Add(pg28);
    //    }
    //    else if (isTenderExpiry == 'N')
    //    {
    //        doc.Add(pngImg);
    //        Chunk headLine = new Chunk("Tender Collection Summary", headFont);
    //        headLine.SetUnderline(1f, -2f);
    //        Phrase p1 = new Phrase(headLine);
    //        Paragraph pg1 = new Paragraph();
    //        pg1.Alignment = iTextSharp.text.pdf.PdfContentByte.ALIGN_CENTER;
    //        pg1.Add(p1);
    //        pg1.SpacingAfter = 5f;
    //        doc.Add(pg1);

    //        typeOfTender = GetTypeOfTender(typeOfTender);
    //        Chunk chTypeOfTender = new Chunk("Type of Tender :", plainText);
    //        Chunk boldTypeOfTender = new Chunk("  " + typeOfTender, boldText);
    //        Phrase pTypeOfTender = new Phrase(chTypeOfTender);
    //        pTypeOfTender.Add(boldTypeOfTender);
    //        Paragraph pgTypeOfTender = new Paragraph();
    //        pgTypeOfTender.Add(pTypeOfTender);
    //        pgTypeOfTender.SpacingAfter = 5f;
    //        doc.Add(pgTypeOfTender);

    //        Chunk ch4 = new Chunk("Tender No        :", plainText);
    //        Chunk boldCh4 = new Chunk("  " + strTendrNo, boldText);
    //        Phrase p4 = new Phrase(ch4);
    //        p4.Add(boldCh4);
    //        Paragraph pg4 = new Paragraph();
    //        pg4.Add(p4);
    //        pg4.SpacingAfter = 5f;
    //        doc.Add(pg4);

    //        Chunk ch2 = new Chunk("Project Code     :", plainText);
    //        Chunk boldCh2 = new Chunk(" " + projCode, boldText);
    //        Phrase p2 = new Phrase(ch2);
    //        p2.Add(boldCh2);
    //        Paragraph pg2 = new Paragraph();
    //        pg2.Add(p2);
    //        pg2.SpacingAfter = 5f;
    //        doc.Add(pg2);

    //        Chunk ch3 = new Chunk("Tender Title       :", plainText);
    //        Chunk boldCh3 = new Chunk(" " + strTendrTitle, boldText);
    //        Phrase p3 = new Phrase(ch3);
    //        p3.Add(boldCh3);
    //        Paragraph pg3 = new Paragraph();
    //        pg3.Add(p3);
    //        pg3.SpacingAfter = 5f;
    //        doc.Add(pg3);

    //        //dtProjCost = dalObj.GetDataFromDB("ProjectCost", "select tender_bond,doc_fee from ProjectCost where proj_id=" + projID);
    //        Chunk ch8 = new Chunk("Tender Bond      :", plainText);
    //        Chunk boldCh8 = null;
    //        boldCh8 = new Chunk(" " + tenderBond, boldText);
    //        Phrase p8 = new Phrase(ch8);
    //        p8.Add(boldCh8);
    //        Paragraph pg8 = new Paragraph();
    //        pg8.Add(p8);
    //        pg8.SpacingAfter = 5f;
    //        doc.Add(pg8);

    //        //Modified By Varun on 16th Feb 2014 replace prAdvDate by tenderIssueDate based on Riyas request
    //        Chunk ch9 = new Chunk("Date of Tender Announcement  :", plainText);
    //        Chunk boldCh9 = new Chunk("  " + tenderIssueDate, boldText);
    //        Phrase p9 = new Phrase(ch9);
    //        p9.Add(boldCh9);
    //        Paragraph pg9 = new Paragraph();
    //        pg9.Add(p9);
    //        pg9.SpacingAfter = 5f;
    //        doc.Add(pg9);

    //        Chunk boldCh10 = null;
    //        Chunk ch10 = new Chunk("Document Fee      :", plainText);
    //        boldCh10 = new Chunk("  " + docFee, boldText);
    //        Phrase p10 = new Phrase(ch10);
    //        p10.Add(boldCh10);
    //        Paragraph pg10 = new Paragraph();
    //        pg10.Add(p10);
    //        pg10.SpacingAfter = 5f;
    //        doc.Add(pg10);

    //        Chunk ch5 = new Chunk("Tender Closing Date  :", plainText);
    //        Chunk boldCh5 = new Chunk("  " + strClosingDate, boldText);
    //        Phrase p5 = new Phrase(ch5);
    //        p5.Add(boldCh5);

    //        if (strModifiedDate != "")
    //        {
    //            Chunk ch7 = new Chunk("                   ", plainText);
    //            p5.Add(ch7);
    //            Chunk ch6 = new Chunk("Modified Closing Date :", plainText);
    //            Chunk boldCh6 = new Chunk("  " + strModifiedDate, boldText);
    //            p5.Add(ch6);
    //            p5.Add(boldCh6);

    //            Chunk ckNoOfExtnsSpace = new Chunk("             ", plainText);
    //            p5.Add(ckNoOfExtnsSpace);
    //            Chunk ckNoOfExtns = new Chunk("No. of Extensions    :", plainText);
    //            p5.Add(ckNoOfExtns);
    //            Chunk boldChNoOfExtns = new Chunk("  " + (noOfExtns + 1), boldText);
    //            p5.Add(boldChNoOfExtns);

    //        }
    //        Paragraph pg5 = new Paragraph();
    //        pg5.Add(p5);
    //        pg5.SpacingAfter = 5f;
    //        doc.Add(pg5);

    //        Chunk ch11 = new Chunk("No. of Circulars    :", plainText);
    //        Chunk boldCh11 = null;
    //        if (totCircularNos == 0)
    //            boldCh11 = new Chunk(" " + "0", boldText);
    //        else
    //            boldCh11 = new Chunk(" " + totCircularNos, boldText);
    //        Phrase p11 = new Phrase(ch11);
    //        p11.Add(boldCh11);
    //        Paragraph pg11 = new Paragraph();
    //        pg11.Add(p11);
    //        pg11.SpacingAfter = 5f;
    //        doc.Add(pg11);

    //        Chunk boldCh12 = null;
    //        Chunk ch12 = new Chunk("Eligible To Tender:", plainText);
    //        boldCh12 = new Chunk(" " + strEligibleTenderTypes, boldText);
    //        Phrase p12 = new Phrase(ch12);
    //        p12.Add(boldCh12);
    //        Paragraph pg12 = new Paragraph();
    //        pg12.Add(p12);
    //        pg12.SpacingAfter = 5f;
    //        doc.Add(pg12);

    //        PdfPTable table2 = null;
    //        table2 = new PdfPTable(10);
    //        table2.TotalWidth = 561f;
    //        table2.LockedWidth = true;
    //        float[] widths = new float[] { 5f, 18f, 13f, 14f, 13f, 12f, 12f, 13f, 20f, 14f };
    //        //float[] widths = new float[] { 5f, 17f, 13f, 14f, 12f, 10f, 10f, 9f, 16f,11f,15f };
    //        table2.SetWidths(widths);
    //        int totRows = 0;
    //        if (dgView == null)
    //            totRows = dv.Table.Rows.Count;
    //        else
    //            totRows = dgView.Rows.Count;

    //        table2 = createTable(totRows, table2, plainText, boldText, dgView, dv, 'N');
    //        doc.Add(table2);
    //    }
    //    else
    //    {
    //        iTextSharp.text.Font headerText = new iTextSharp.text.Font(iTextSharp.text.Font.FontFamily.TIMES_ROMAN, 12f);
    //        plainText = new iTextSharp.text.Font(iTextSharp.text.Font.FontFamily.TIMES_ROMAN, 8f);
    //        boldText = new iTextSharp.text.Font(iTextSharp.text.Font.FontFamily.TIMES_ROMAN, 9f, iTextSharp.text.Font.BOLD, iTextSharp.text.BaseColor.BLACK);

    //        DAL dalObj = new DAL();
    //        BindingSource bidSource = (BindingSource)dgView.DataSource;
    //        DataTable dtTenderExpiries = (DataTable)bidSource.DataSource;
    //        //dalObj.GetDataFromDB("TenderExpiries", sqlQuery);
    //        PdfPTable table = null;
    //        table = new PdfPTable(7);
    //        table.TotalWidth = 555f;
    //        table.LockedWidth = true;
    //        float[] widths = new float[] { 9f, 23f, 27f, 16f, 10f, 13f, 19f };
    //        //float[] widths = new float[] { 8f, 22f, 27f, 16f, 10f, 13f, 17f,10f,10f };
    //        table.SetWidths(widths);
    //        int totRows = 0;
    //        totRows = dtTenderExpiries.Rows.Count;

    //        Chunk ch = new Chunk("List of Projects where Tender Validity Expiration is Less than 20 days", headerText);
    //        Chunk boldCh4 = new Chunk("                                            Project Count =" + totRows, plainText);
    //        Phrase p1 = new Phrase(ch);
    //        p1.Add(boldCh4);
    //        Paragraph pg4 = new Paragraph();
    //        pg4.Add(p1);
    //        pg4.SpacingAfter = 10f;
    //        doc.Add(pg4);

    //        if (totRows != 0)
    //        {
    //            table = createTable(totRows, table, plainText, boldText, null, dtTenderExpiries.DefaultView, 'Y');
    //            doc.Add(table);
    //        }

    //    }
    //}


   

    private string getBarcode(bool isWorkOrder, SqlConnection sqlConn)
    {
        string barCodeNo = null;
        string sqlQuery = null;
        if (!isWorkOrder)
            sqlQuery = "Select max(barcodeID)+1 from IssueVoucherBarcodesSeq";
        else
            sqlQuery = "Select max(barcodeID)+1 from IssueVoucherWOBarcodesSeq";

        SqlCommand cmd = new SqlCommand(sqlQuery, sqlConn);
        SqlDataReader dr = cmd.ExecuteReader();

        while (dr.Read())
        {
            barCodeNo = dr[0].ToString();
        }
        dr.Close();

        if (barCodeNo.Length == 1)
            barCodeNo = "00000" + barCodeNo;
        if (barCodeNo.Length == 2)
            barCodeNo = "0000" + barCodeNo;
        if (barCodeNo.Length == 3)
            barCodeNo = "000" + barCodeNo;
        if (barCodeNo.Length == 4)
            barCodeNo = "00" + barCodeNo;
        if (barCodeNo.Length == 5)
            barCodeNo = "0" + barCodeNo;

        return barCodeNo;
    }


    private void getPDF_Aspose()
    {
        //Aspose.Pdf.Generator.Image image1 = new Aspose.Pdf.Generator.Image(sec1);

        ////Load image data from memory stream to the image object
        //image1.ImageInfo.ImageFileType = Aspose.Pdf.Generator.ImageFileType.MemoryBmp;
        //image1.ImageInfo.OpenType = Aspose.Pdf.Generator.ImageOpenType.Memory;
        //image1.ImageScale = 0.5F;
        //System.IO.BinaryReader reader = new System.IO.BinaryReader(ms);
        //ms.Position = 0;
        //image1.ImageInfo.MemoryData = reader.ReadBytes((int)ms.Length);

        ////Add image to the paragraphs collection of the section
        //sec1.Paragraphs.Add(image1);

        ////Save the Pdf
        //pdf1.Save("MyBarCode.pdf");
    }

    //static iTextSharp.text.Image barcodeImage1 = null;
    //private string getPDF(string pdfFile, string pdfFileOut, short numOfPages, SqlConnection sqlConn, string versionNo, ref string[] arrInfo, string cmtShortName, bool isWorkOrder, bool isTenderClosingDateStage2)
    //{
    //    pdfFile = "";
    //    pdfFile = pdfFileOut.Substring(0, (pdfFileOut.Length - 4));
    //    pdfFile = pdfFile + "_OutPut_" + DateTime.Now.Hour + DateTime.Now.Minute + DateTime.Now.Second + DateTime.Now.Millisecond + ".pdf";

    //    // pdfFile = @"C:\Users\ebsd_svadakapuram\AppData\Local\Temp\Al Jaber and Partners for Construction & Energy Projects (WLL)-MRPSC-001-2014-2015-L_451.pdf";

    //    int dpi = 300;
    //    iTextSharp.text.pdf.PdfReader pdfReader = new iTextSharp.text.pdf.PdfReader(pdfFileOut);
    //    iTextSharp.text.pdf.PdfStamper pdfStamper = new iTextSharp.text.pdf.PdfStamper(pdfReader, new System.IO.FileStream(pdfFile, System.IO.FileMode.OpenOrCreate, System.IO.FileAccess.Write));
    //    iTextSharp.text.pdf.PdfContentByte pdfPage = pdfStamper.GetOverContent(1);
    //    float pageWidth = pdfReader.GetPageSize(1).Width;
    //    float pageHeight = pdfReader.GetPageSize(1).Height;

    //    string barCodeSerialNo = null;

    //    if (numOfPages == 1)
    //    {
    //        barCodeSerialNo = getBarcode(isWorkOrder, sqlConn);
    //        string currentDateTime = Convert.ToDateTime(System.DateTime.Now).ToString("dd/MMM/yyyy H:mm:ss tt");
    //        barcodeImage1 = getBarCodeImage(pdfReader, barCodeSerialNo, currentDateTime, dpi, pageWidth, pageHeight, pdfPage, versionNo, ref arrInfo, cmtShortName, isWorkOrder, isTenderClosingDateStage2);
    //        putBarcode(isWorkOrder, sqlConn, barCodeSerialNo);
    //    }
    //    else
    //    {
    //        pdfPage.AddImage(barcodeImage1);
    //        barcodeImage1 = null;
    //    }


    //    pdfStamper.Close();
    //    pdfReader.Close();

    //    return pdfFile;
    //}

    //Added by Varun on 02 Jul 15 based on req. from Riyas
    //public void CreateWorkOrderGridViewColumns(DataGridView dgvWorkOrders, int PC_prjID, int contractorID)
    //{
    //    SqlConnection sqlConn = null;
    //    if (dgvWorkOrders.ColumnCount == 0)
    //    {
    //        //CreateCheckBox chkBox = null;
    //        //CheckBox headerCheckBox = new CheckBox();
    //        //chkBox = new CreateCheckBox(dgvWorkOrders, headerCheckBox);
    //        //chkBox.AddHeaderCheckBox();

    //        DataGridViewCheckBoxColumn col0 = new DataGridViewCheckBoxColumn();

    //        var col1 = new DataGridViewLinkColumn();
    //        var col2 = new DataGridViewTextBoxColumn();
    //        var col3 = new DataGridViewTextBoxColumn();
    //        var col4 = new DataGridViewTextBoxColumn();
    //        var col5 = new DataGridViewTextBoxColumn();
    //        var col6 = new DataGridViewTextBoxColumn();
    //        var col7 = new DataGridViewTextBoxColumn();
    //        var col8 = new DataGridViewTextBoxColumn();
    //        var col9 = new DataGridViewTextBoxColumn();
    //        var col10 = new DataGridViewTextBoxColumn();
    //        var col11 = new DataGridViewTextBoxColumn();
    //        var col12 = new DataGridViewTextBoxColumn();
    //        var col13 = new DataGridViewTextBoxColumn();
    //        var col14 = new DataGridViewTextBoxColumn();

    //        dgvWorkOrders.Columns.AddRange(new DataGridViewColumn[] { col0, col1, col2, col3, col4, col5, col6, col7, col8, col9, col10, col11, col12, col13, col14 });

    //        dgvWorkOrders.AutoGenerateColumns = false;
    //        dgvWorkOrders.AllowUserToAddRows = false;
    //        dgvWorkOrders.AutoResizeColumns();

    //        col0.Name = "chkBxSelect1";
    //        col0.DataPropertyName = "Select";
    //        col0.HeaderText = "";
    //        col0.Width = 10;

    //        col1.DataPropertyName = "workOrderNo";
    //        col1.HeaderText = "Work Order No.";
    //        DataGridViewCellStyle style = new DataGridViewCellStyle();
    //        style.Font = new System.Drawing.Font(dgvWorkOrders.Font, System.Drawing.FontStyle.Bold);
    //        col1.DefaultCellStyle = style;
    //        col1.Resizable = System.Windows.Forms.DataGridViewTriState.True;
    //        col1.Width = 35;

    //        col2.DataPropertyName = "workOrderTitle";
    //        col2.HeaderText = "Work Order Title";
    //        //col2.Resizable = System.Windows.Forms.DataGridViewTriState.True;
    //        col2.Width = 150;

    //        col3.DataPropertyName = "workOrderStatus";
    //        col3.HeaderText = "Work Order Status";
    //        col3.Width = 20;

    //        col4.DataPropertyName = "ContractStatus";
    //        col4.HeaderText = "Contract Status";
    //        col4.Width = 20;

    //        col5.DataPropertyName = "contract_no";
    //        col5.HeaderText = "Commitment No.";
    //        col5.Width = 20;

    //        col6.DataPropertyName = "workOrderID";
    //        col6.HeaderText = "workOrderID";

    //        col7.DataPropertyName = "bidder_Id";
    //        col7.HeaderText = "bidder_Id";

    //        col8.DataPropertyName = "workOrderClosingDate";
    //        col8.HeaderText = "workOrderClosingDate";

    //        col9.DataPropertyName = "tender_open_date";
    //        col9.HeaderText = "tender_open_date";

    //        col10.DataPropertyName = "evaluation_report_datesend";
    //        col10.HeaderText = "evaluation_report_datesend";

    //        col11.DataPropertyName = "techno_financial_totalworkdays";
    //        col11.HeaderText = "techno_financial_totalworkdays";

    //        col12.DataPropertyName = "no_of_meetings";
    //        col12.HeaderText = "no_of_meetings";

    //        col13.DataPropertyName = "evaluation_report_daterecvd";
    //        col13.HeaderText = "evaluation_report_daterecvd";

    //        col14.DataPropertyName = "tender_award_approvaldate";
    //        col14.HeaderText = "tender_award_approvaldate";

    //        //col3.Resizable = System.Windows.Forms.DataGridViewTriState.True;
    //        //headerCheckBox.KeyUp += new KeyEventHandler(chkBox.HeaderCheckBox_KeyUp);
    //        //headerCheckBox.MouseClick += new MouseEventHandler(chkBox.HeaderCheckBox_MouseClick);

    //        dgvWorkOrders.ColumnHeadersDefaultCellStyle.BackColor = System.Drawing.Color.Gainsboro;
    //        dgvWorkOrders.ColumnHeadersDefaultCellStyle.ForeColor = System.Drawing.Color.Chocolate;
    //        dgvWorkOrders.ColumnHeadersDefaultCellStyle.Font = new System.Drawing.Font(dgvWorkOrders.Font, System.Drawing.FontStyle.Regular);
    //        dgvWorkOrders.EnableHeadersVisualStyles = false;
    //        dgvWorkOrders.DefaultCellStyle.WrapMode = DataGridViewTriState.True;
    //    }

    //    try
    //    {
    //        sqlConn = new SqlConnection(ConfigurationManager.AppSettings["TCMSConnString"].ToString());
    //        sqlConn.Open();

    //        string sqlQuery = null;

    //        //if (contractorID == 0)
    //        //{
    //        //    sqlQuery = "SELECT distinct WorkOrders.workOrderNo, WorkOrders.workOrderTitle, WorkOrders.workOrderStatus,WorkOrders.workOrderID,WorkOrders.bidder_Id,WorkOrders.workOrderClosingDate," +
    //        //    "WorkOrders.tender_open_date,WorkOrders.evaluation_report_datesend,WorkOrders.techno_financial_totalworkdays,WorkOrders.no_of_meetings," +
    //        //    "WorkOrders.evaluation_report_daterecvd,WorkOrders.tender_award_approvaldate FROM WorkOrders WHERE WorkOrders.proj_id = " + PC_prjID + " order by WorkOrders.workOrderNo";
    //        //}
    //        //else
    //        //{
    //        //    sqlQuery = "SELECT distinct WorkOrders.workOrderNo, WorkOrders.workOrderTitle, WorkOrders.workOrderStatus,ContractStatus.ContractStatus,CONTRACTORS.contract_no,WorkOrders.workOrderID,WorkOrders.bidder_Id,WorkOrders.workOrderClosingDate," +
    //        //    "WorkOrders.tender_open_date,WorkOrders.evaluation_report_datesend,WorkOrders.techno_financial_totalworkdays,WorkOrders.no_of_meetings," +
    //        //    "WorkOrders.evaluation_report_daterecvd,WorkOrders.tender_award_approvaldate FROM WorkOrders inner join CONTRACTORS ON CONTRACTORS.bidder_id = WorkOrders.bidder_Id inner join ContractStatus ON CONTRACTORS.contract_status_id = " +
    //        //    "ContractStatus.contract_status_id WHERE WorkOrders.proj_id = " + PC_prjID + " and WorkOrders.bidder_Id=" + contractorID + " and CONTRACTORS.contract_no like '%C%' order by WorkOrders.workOrderNo";
    //        //}

    //        if (contractorID == 0)
    //        {
    //            sqlQuery = "SELECT distinct WorkOrders.workOrderNo, WorkOrders.workOrderTitle, WorkOrders.workOrderStatus,ContractStatus.ContractStatus,CONTRACTORS.contract_no,WorkOrders.workOrderID,WorkOrders.bidder_Id,WorkOrders.workOrderClosingDate," +
    //            "WorkOrders.tender_open_date,WorkOrders.evaluation_report_datesend,WorkOrders.techno_financial_totalworkdays,WorkOrders.no_of_meetings," +
    //            "WorkOrders.evaluation_report_daterecvd,WorkOrders.tender_award_approvaldate FROM WorkOrders LEFT OUTER join CONTRACTORS ON CONTRACTORS.bidder_id = WorkOrders.bidder_Id LEFT OUTER join ContractStatus ON CONTRACTORS.contract_status_id = " +
    //            "ContractStatus.contract_status_id WHERE WorkOrders.proj_id = " + PC_prjID + " and (CONTRACTORS.contract_no like '%C%' OR CONTRACTORS.contract_no IS NULL) order by WorkOrders.workOrderNo ";
    //        }
    //        else
    //        {
    //            sqlQuery = "SELECT distinct WorkOrders.workOrderNo, WorkOrders.workOrderTitle, WorkOrders.workOrderStatus,ContractStatus.ContractStatus,CONTRACTORS.contract_no,WorkOrders.workOrderID,WorkOrders.bidder_Id,WorkOrders.workOrderClosingDate," +
    //            "WorkOrders.tender_open_date,WorkOrders.evaluation_report_datesend,WorkOrders.techno_financial_totalworkdays,WorkOrders.no_of_meetings," +
    //            "WorkOrders.evaluation_report_daterecvd,WorkOrders.tender_award_approvaldate FROM WorkOrders LEFT OUTER join CONTRACTORS ON CONTRACTORS.bidder_id = WorkOrders.bidder_Id LEFT OUTER join ContractStatus ON CONTRACTORS.contract_status_id = " +
    //            "ContractStatus.contract_status_id WHERE WorkOrders.proj_id = " + PC_prjID + " and WorkOrders.bidder_Id=" + contractorID + " and (CONTRACTORS.contract_no like '%C%' OR CONTRACTORS.contract_no IS NULL) order by WorkOrders.workOrderNo";
    //        }

    //        //myBindingSource = new BindingSource();
    //        DataTable dtWorkOrders = GetDataTable(sqlQuery, sqlConn);
    //        if (dtWorkOrders.Rows.Count != 0)
    //        {
    //            int rowCounter = 0;
    //            while (rowCounter < dtWorkOrders.Rows.Count)
    //            {
    //                string woStatus = null;
    //                int noOfDays = DateDiff(dtWorkOrders.Rows[rowCounter][7].ToString());
    //                if (noOfDays <= 0)
    //                {
    //                    if (noOfDays == 0)
    //                    {
    //                        if (DateTime.Now.TimeOfDay.Hours >= 13)
    //                            woStatus = "Closed";
    //                        else
    //                            woStatus = "Open";
    //                    }
    //                    else
    //                        woStatus = "Closed";
    //                }
    //                else
    //                    woStatus = "Open";
    //                dtWorkOrders.Rows[rowCounter][2] = woStatus;
    //                dtWorkOrders.AcceptChanges();
    //                rowCounter++;
    //            }
    //            dgvWorkOrders.DataSource = dtWorkOrders;
    //            dgvWorkOrders.Visible = true;
    //        }
    //        else
    //        {
    //            dgvWorkOrders.DataSource = null;
    //            dgvWorkOrders.Visible = false;
    //        }

    //        //dgvWorkOrders.Columns[4].Visible = false;
    //        //dgvWorkOrders.Columns[5].Visible = false;
    //        dgvWorkOrders.Columns[6].Visible = false;
    //        dgvWorkOrders.Columns[7].Visible = false;
    //        dgvWorkOrders.Columns[8].Visible = false;
    //        dgvWorkOrders.Columns[9].Visible = false;
    //        dgvWorkOrders.Columns[10].Visible = false;
    //        dgvWorkOrders.Columns[11].Visible = false;
    //        dgvWorkOrders.Columns[12].Visible = false;
    //        dgvWorkOrders.Columns[13].Visible = false;
    //        dgvWorkOrders.Columns[14].Visible = false;

    //    }
    //    catch (Exception ex)
    //    {
    //        MessageBox.Show("Error occurred while displaying the Work Orders", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
    //    }
    //    finally
    //    {
    //        sqlConn.Close();
    //    }
    //}

    System.Data.DataTable dtFinalTenderersInfo = null;
    System.Data.DataTable dtFirstTenderersInfo = null;
    System.Data.DataTable dtSecondTenderersInfo = null;

    //Added By Varun on 23rd Nov 2016 Based on Riyas Request For showing the projects for years 2010--2016 based on access rights 
    public string CheckAccessRightsForTenderNoYear(IList<string> userRightsColl)
    {
        string whereClause = null;
        if (userRightsColl.Contains("93") && userRightsColl.Contains("94") && userRightsColl.Contains("95") && userRightsColl.Contains("96") && userRightsColl.Contains("97") && userRightsColl.Contains("98") && userRightsColl.Contains("99") && userRightsColl.Contains("100")
           && userRightsColl.Contains("112") && userRightsColl.Contains("113") && userRightsColl.Contains("114") && (!userRightsColl.Contains("115")))
        {
            whereClause = " and (p.tender_no LIKE '%2020%' or p.tender_no IS NULL) and (p.FYID=19) ";
        }
        else if (userRightsColl.Contains("93") && userRightsColl.Contains("94") && userRightsColl.Contains("95") && userRightsColl.Contains("96") && userRightsColl.Contains("97") && userRightsColl.Contains("98") && userRightsColl.Contains("99") && userRightsColl.Contains("100")
           && userRightsColl.Contains("112") && userRightsColl.Contains("113") && (!userRightsColl.Contains("114")) && userRightsColl.Contains("115"))
        {
            whereClause = " and (p.tender_no LIKE '%2019%' or p.tender_no IS NULL) and (p.FYID=18) ";
        }
        else if (userRightsColl.Contains("93") && userRightsColl.Contains("94") && userRightsColl.Contains("95") && userRightsColl.Contains("96") && userRightsColl.Contains("97") && userRightsColl.Contains("98") && userRightsColl.Contains("99") && userRightsColl.Contains("100")
            && userRightsColl.Contains("112") && (!userRightsColl.Contains("113")) && userRightsColl.Contains("114") && userRightsColl.Contains("115"))
        {
            whereClause = " and (p.tender_no LIKE '%2018%' or p.tender_no IS NULL) and (p.FYID=17) ";
        }
        else if (userRightsColl.Contains("93") && userRightsColl.Contains("94") && userRightsColl.Contains("95") && userRightsColl.Contains("96") && userRightsColl.Contains("97") && userRightsColl.Contains("98") && userRightsColl.Contains("99") && userRightsColl.Contains("100")
            && (!userRightsColl.Contains("112")) && userRightsColl.Contains("113") && userRightsColl.Contains("114") && userRightsColl.Contains("115"))
        {
            whereClause = " and (p.tender_no LIKE '%2017%' or p.tender_no IS NULL) and (p.FYID=16) ";
        }
        else if (userRightsColl.Contains("93") && userRightsColl.Contains("94") && userRightsColl.Contains("95") && userRightsColl.Contains("96") && userRightsColl.Contains("97") && userRightsColl.Contains("98") && userRightsColl.Contains("99") && (!userRightsColl.Contains("100")))
        {
            whereClause = " and (p.tender_no LIKE '%2016%' or p.tender_no IS NULL) and (p.FYID=15) ";
        }
        else if (userRightsColl.Contains("93") && userRightsColl.Contains("94") && userRightsColl.Contains("95") && userRightsColl.Contains("96") && userRightsColl.Contains("97") && userRightsColl.Contains("98") && (!userRightsColl.Contains("99")) && userRightsColl.Contains("100"))
        {
            whereClause = " and (p.tender_no LIKE '%2015%' or p.tender_no IS NULL) and (p.FYID=14) ";
        }
        else if (userRightsColl.Contains("93") && userRightsColl.Contains("94") && userRightsColl.Contains("95") && userRightsColl.Contains("96") && (!userRightsColl.Contains("97")) && (!userRightsColl.Contains("98")) && userRightsColl.Contains("99") && userRightsColl.Contains("100"))
        {
            whereClause = " and (p.tender_no LIKE '%2014%' or p.tender_no IS NULL) and (p.FYID=13) ";
        }
        else if (userRightsColl.Contains("93") && userRightsColl.Contains("94") && userRightsColl.Contains("95") && userRightsColl.Contains("96") && (!userRightsColl.Contains("97")) && userRightsColl.Contains("98") && userRightsColl.Contains("99") && userRightsColl.Contains("100"))
        {
            whereClause = " and (p.tender_no LIKE '%2013%' or p.tender_no IS NULL) and (p.FYID=12) ";
        }
        else if (userRightsColl.Contains("93") && userRightsColl.Contains("94") && (!userRightsColl.Contains("95")) && (!userRightsColl.Contains("96")) && userRightsColl.Contains("97") && userRightsColl.Contains("98") && userRightsColl.Contains("99") && userRightsColl.Contains("100"))
        {
            whereClause = " and (p.tender_no LIKE '%2012%' or p.tender_no IS NULL) and (p.FYID=11) ";
        }
        else if (userRightsColl.Contains("93") && userRightsColl.Contains("94") && (!userRightsColl.Contains("95")) && userRightsColl.Contains("96") && userRightsColl.Contains("97") && userRightsColl.Contains("98") && userRightsColl.Contains("99") && userRightsColl.Contains("100"))
        {
            whereClause = " and (p.tender_no LIKE '%2011%' or p.tender_no IS NULL) and (p.FYID=10) ";
        }
        else if (userRightsColl.Contains("93") && (!userRightsColl.Contains("94")) && userRightsColl.Contains("95") && userRightsColl.Contains("96") && userRightsColl.Contains("97") && userRightsColl.Contains("98") && userRightsColl.Contains("99") && userRightsColl.Contains("100"))
        {
            whereClause = " and (p.tender_no LIKE '%2010%' or p.tender_no IS NULL) and (p.FYID=9) ";
        }
        else if (userRightsColl.Contains("93") && userRightsColl.Contains("94") && userRightsColl.Contains("95") && userRightsColl.Contains("96") && userRightsColl.Contains("97") && userRightsColl.Contains("98") && userRightsColl.Contains("99") && userRightsColl.Contains("100"))
        {
            whereClause = " and (p.tender_no is Null ) and (p.FYID<>9 and p.FYID<>10 and p.FYID<>11 and p.FYID<>12 and p.FYID<>13 and p.FYID<>14 and p.FYID<>15)";
        }
        if (userRightsColl.Contains("93") && userRightsColl.Contains("94") && userRightsColl.Contains("95") && userRightsColl.Contains("96") && userRightsColl.Contains("97") && userRightsColl.Contains("98") && (!userRightsColl.Contains("99")) && (!userRightsColl.Contains("100"))
            && userRightsColl.Contains("112") && userRightsColl.Contains("113") && userRightsColl.Contains("114") && userRightsColl.Contains("115"))
        {
            whereClause = " and (p.tender_no LIKE '%2016%' OR p.tender_no LIKE '%2015%' or p.tender_no IS NULL) and (p.FYID=14 or p.FYID=15) ";
        }
        else if (userRightsColl.Contains("93") && userRightsColl.Contains("94") && userRightsColl.Contains("95") && userRightsColl.Contains("96") && userRightsColl.Contains("97") && (!userRightsColl.Contains("98")) && (!userRightsColl.Contains("99")) && (!userRightsColl.Contains("100"))
            && userRightsColl.Contains("112") && userRightsColl.Contains("113") && userRightsColl.Contains("114") && userRightsColl.Contains("115"))
        {
            whereClause = " and ((p.tender_no LIKE '%2016%') OR (p.tender_no LIKE '%2015%') OR (p.tender_no LIKE '%2014%') or p.tender_no IS NULL) and (p.FYID=13 or p.FYID=14 or p.FYID=15) ";
        }
        else if (userRightsColl.Contains("93") && userRightsColl.Contains("94") && userRightsColl.Contains("95") && userRightsColl.Contains("96") && (!userRightsColl.Contains("97")) && (!userRightsColl.Contains("98")) && (!userRightsColl.Contains("99")) && (!userRightsColl.Contains("100"))
            && userRightsColl.Contains("112") && userRightsColl.Contains("113") && userRightsColl.Contains("114") && userRightsColl.Contains("115"))
        {
            whereClause = " and ((p.tender_no LIKE '%2016%') OR (p.tender_no LIKE '%2015%') OR (p.tender_no LIKE '%2014%') OR (p.tender_no LIKE '%2013%') or p.tender_no IS NULL) and (p.FYID=12 or p.FYID=13 or p.FYID=14 or p.FYID=15) ";
        }
        else if (userRightsColl.Contains("93") && userRightsColl.Contains("94") && userRightsColl.Contains("95") && (!userRightsColl.Contains("96")) && (!userRightsColl.Contains("97")) && (!userRightsColl.Contains("98")) && (!userRightsColl.Contains("99")) && (!userRightsColl.Contains("100"))
            && userRightsColl.Contains("112") && userRightsColl.Contains("113") && userRightsColl.Contains("114") && userRightsColl.Contains("115"))
        {
            whereClause = " and ((p.tender_no LIKE '%2016%') OR (p.tender_no LIKE '%2015%') OR (p.tender_no LIKE '%2014%') OR (p.tender_no LIKE '%2013%') OR (p.tender_no LIKE '%2012%') or p.tender_no IS NULL) and (p.FYID=11 or p.FYID=12 or p.FYID=13 or p.FYID=14 or p.FYID=15) ";
        }
        else if (userRightsColl.Contains("93") && userRightsColl.Contains("94") && (!userRightsColl.Contains("95")) && (!userRightsColl.Contains("96")) && (!userRightsColl.Contains("97")) && (!userRightsColl.Contains("98")) && (!userRightsColl.Contains("99")) && (!userRightsColl.Contains("100"))
            && userRightsColl.Contains("112") && userRightsColl.Contains("113") && userRightsColl.Contains("114") && userRightsColl.Contains("115"))
        {
            whereClause = " and ((p.tender_no LIKE '%2016%') OR (p.tender_no LIKE '%2015%') OR (p.tender_no LIKE '%2014%') OR (p.tender_no LIKE '%2013%') OR (p.tender_no LIKE '%2012%') OR (p.tender_no LIKE '%2011%') or p.tender_no IS NULL) and (p.FYID=10 or p.FYID=11 or p.FYID=12 or p.FYID=13 or p.FYID=14 or p.FYID=15) ";
        }
        else if (userRightsColl.Contains("93") && (!userRightsColl.Contains("94")) && (!userRightsColl.Contains("95")) && (!userRightsColl.Contains("96")) && (!userRightsColl.Contains("97")) && (!userRightsColl.Contains("98")) && (!userRightsColl.Contains("99")) && (!userRightsColl.Contains("100")) && userRightsColl.Contains("112") &&
            userRightsColl.Contains("113") && userRightsColl.Contains("114") && userRightsColl.Contains("115"))
        {
            whereClause = " and ((p.tender_no LIKE '%2016%') OR (p.tender_no LIKE '%2015%') OR (p.tender_no LIKE '%2014%') OR (p.tender_no LIKE '%2013%') OR (p.tender_no LIKE '%2012%') OR (p.tender_no LIKE '%2011%') OR (p.tender_no LIKE '%2010%') or p.tender_no IS NULL) and (p.FYID=10 or p.FYID=11 or p.FYID=12 or p.FYID=13 or p.FYID=14 or p.FYID=15) ";
        }
        else if (userRightsColl.Contains("93") && (!userRightsColl.Contains("94")) && (!userRightsColl.Contains("95")) && (!userRightsColl.Contains("96")) && (!userRightsColl.Contains("97")) && (!userRightsColl.Contains("98")) && (!userRightsColl.Contains("99")) && (!userRightsColl.Contains("100")) && (!userRightsColl.Contains("112")) &&
        userRightsColl.Contains("113") && userRightsColl.Contains("114") && userRightsColl.Contains("115"))
        {
            whereClause = " and ((p.tender_no LIKE '%2017%') OR (p.tender_no LIKE '%2016%') OR (p.tender_no LIKE '%2015%') OR (p.tender_no LIKE '%2014%') OR (p.tender_no LIKE '%2013%') OR (p.tender_no LIKE '%2012%') OR (p.tender_no LIKE '%2011%') OR (p.tender_no LIKE '%2010%') or p.tender_no IS NULL) and (p.FYID=10 or p.FYID=11 or p.FYID=12 or p.FYID=13 or p.FYID=14 or p.FYID=15 or p.FYID=16) ";
        }
        else if (userRightsColl.Contains("93") && (!userRightsColl.Contains("94")) && (!userRightsColl.Contains("95")) && (!userRightsColl.Contains("96")) && (!userRightsColl.Contains("97")) && (!userRightsColl.Contains("98")) && (!userRightsColl.Contains("99")) && (!userRightsColl.Contains("100")) && (!userRightsColl.Contains("112")) &&
        (!userRightsColl.Contains("113")) && userRightsColl.Contains("114") && userRightsColl.Contains("115"))
        {
            whereClause = " and ((p.tender_no LIKE '%2018%') OR (p.tender_no LIKE '%2017%') OR (p.tender_no LIKE '%2016%') OR (p.tender_no LIKE '%2015%') OR (p.tender_no LIKE '%2014%') OR (p.tender_no LIKE '%2013%') OR (p.tender_no LIKE '%2012%') OR (p.tender_no LIKE '%2011%') OR (p.tender_no LIKE '%2010%') or p.tender_no IS NULL) and (p.FYID=10 or p.FYID=11 or " +
            "p.FYID=12 or p.FYID=13 or p.FYID=14 or p.FYID=15 or p.FYID=16 or p.FYID=17) ";
        }
        else if (userRightsColl.Contains("93") && (!userRightsColl.Contains("94")) && (!userRightsColl.Contains("95")) && (!userRightsColl.Contains("96")) && (!userRightsColl.Contains("97")) && (!userRightsColl.Contains("98")) && (!userRightsColl.Contains("99")) && (!userRightsColl.Contains("100")) && (!userRightsColl.Contains("112")) &&
        (!userRightsColl.Contains("113")) && (!userRightsColl.Contains("114")) && userRightsColl.Contains("115"))
        {
            whereClause = " and ((p.tender_no LIKE '%2019%') OR (p.tender_no LIKE '%2018%') OR (p.tender_no LIKE '%2017%') OR (p.tender_no LIKE '%2016%') OR (p.tender_no LIKE '%2015%') OR (p.tender_no LIKE '%2014%') OR (p.tender_no LIKE '%2013%') OR (p.tender_no LIKE '%2012%') OR (p.tender_no LIKE '%2011%') OR (p.tender_no LIKE '%2010%') or p.tender_no IS NULL) and " +
            "(p.FYID=10 or p.FYID=11 or p.FYID=12 or p.FYID=13 or p.FYID=14 or p.FYID=15 or p.FYID=16 or p.FYID=17 or p.FYID=18) ";
        }
        else if (userRightsColl.Contains("93") && (!userRightsColl.Contains("94")) && (!userRightsColl.Contains("95")) && (!userRightsColl.Contains("96")) && (!userRightsColl.Contains("97")) && (!userRightsColl.Contains("98")) && (!userRightsColl.Contains("99")) && (!userRightsColl.Contains("100")) && (!userRightsColl.Contains("112")) &&
        (!userRightsColl.Contains("113")) && (!userRightsColl.Contains("114")) && (!userRightsColl.Contains("115")))
        {
            whereClause = " and ((p.tender_no LIKE '%2020%') OR (p.tender_no LIKE '%2019%') OR (p.tender_no LIKE '%2018%') OR (p.tender_no LIKE '%2017%') OR (p.tender_no LIKE '%2016%') OR (p.tender_no LIKE '%2015%') OR (p.tender_no LIKE '%2014%') OR (p.tender_no LIKE '%2013%') OR (p.tender_no LIKE '%2012%') OR (p.tender_no LIKE '%2011%') OR (p.tender_no LIKE '%2010%') or p.tender_no IS NULL) and " +
            "(p.FYID=10 or p.FYID=11 or p.FYID=12 or p.FYID=13 or p.FYID=14 or p.FYID=15 or p.FYID=16 or p.FYID=17 or p.FYID=18 or p.FYID=19) ";
        }
        else if ((!userRightsColl.Contains("93") || userRightsColl.Contains("93")) && (!userRightsColl.Contains("94")) && (!userRightsColl.Contains("95")) && (!userRightsColl.Contains("96")) && (!userRightsColl.Contains("97")) && (!userRightsColl.Contains("98")) && (!userRightsColl.Contains("99")) && (!userRightsColl.Contains("100"))
            && (!userRightsColl.Contains("112")) && (!userRightsColl.Contains("113")) && (!userRightsColl.Contains("114")) && (!userRightsColl.Contains("115")))
        {
            whereClause = "";
        }
        else if ((!userRightsColl.Contains("93")) && (userRightsColl.Contains("94")) && (userRightsColl.Contains("95")) && (userRightsColl.Contains("96")) && (userRightsColl.Contains("97")) && (userRightsColl.Contains("98")) && (userRightsColl.Contains("99")) && (userRightsColl.Contains("100"))
            && userRightsColl.Contains("112") && userRightsColl.Contains("113") && userRightsColl.Contains("114") && userRightsColl.Contains("115"))
        {
            whereClause = "";
        }

        if ((!userRightsColl.Contains("61")) && (userRightsColl.Contains("62")) && (userRightsColl.Contains("63")) && (userRightsColl.Contains("64")) && (userRightsColl.Contains("65")) && (userRightsColl.Contains("66")) && (userRightsColl.Contains("67")) && (userRightsColl.Contains("118")))
        {
            if (whereClause == null)
            {
                whereClause = "";
            }
        }
        else
        {
            if ((!userRightsColl.Contains("61")) || (!userRightsColl.Contains("62")) || (!userRightsColl.Contains("63")) || (!userRightsColl.Contains("64")) || (!userRightsColl.Contains("65")) || (!userRightsColl.Contains("66")) || (!userRightsColl.Contains("67")) || (!userRightsColl.Contains("118")))
            {
                if (whereClause == null)
                {
                    whereClause = "";
                }
            }
            else if (userRightsColl.Contains("61") && (!userRightsColl.Contains("62")) && (!userRightsColl.Contains("63")) && (!userRightsColl.Contains("64")) && (!userRightsColl.Contains("65")) && (!userRightsColl.Contains("66")) && (!userRightsColl.Contains("67")) && (userRightsColl.Contains("118")))
            {
                if (whereClause == "")
                {
                    whereClause = "    (p.Affair_id=1 or p.Affair_id=8 or p.Affair_id=4 or p.Affair_id=5 or p.Affair_id=6 or p.Affair_id=7)";
                }
                else
                {
                    whereClause = whereClause + " and (p.Affair_id=1 or p.Affair_id=8 or p.Affair_id=4 or p.Affair_id=5 or p.Affair_id=6 or p.Affair_id=7)";
                }
            }
            else if ((!userRightsColl.Contains("62")) && (!userRightsColl.Contains("63")) && (!userRightsColl.Contains("64")) && (!userRightsColl.Contains("65")) && (!userRightsColl.Contains("66")) && (!userRightsColl.Contains("67")) && (!userRightsColl.Contains("118")))
            {
                if (whereClause == "")
                {
                    whereClause = "    (p.Affair_id=1 or p.Affair_id=8 or p.Affair_id=4 or p.Affair_id=5 or p.Affair_id=6 or p.Affair_id=7 or p.Affair_id=9)";
                }
                else
                {
                    whereClause = whereClause + " and (p.Affair_id=1 or p.Affair_id=8 or p.Affair_id=4 or p.Affair_id=5 or p.Affair_id=6 or p.Affair_id=7 or p.Affair_id=9)";
                }
            }
            else if ((userRightsColl.Contains("62")) && (!userRightsColl.Contains("63")) && (!userRightsColl.Contains("64")) && (!userRightsColl.Contains("65")) && (!userRightsColl.Contains("66")) && (!userRightsColl.Contains("67")) && (!userRightsColl.Contains("118")))
            {
                if (whereClause == "")
                {
                    whereClause = "    (p.Affair_id=8 or p.Affair_id=4 or p.Affair_id=5 or p.Affair_id=6 or p.Affair_id=7 or p.Affair_id=9)";
                }
                else
                {
                    whereClause = whereClause + " and (p.Affair_id=8 or p.Affair_id=4 or p.Affair_id=5 or p.Affair_id=6 or p.Affair_id=7 or p.Affair_id=9)";
                }
            }
            else if ((userRightsColl.Contains("62")) && (userRightsColl.Contains("63")) && (!userRightsColl.Contains("64")) && (!userRightsColl.Contains("65")) && (!userRightsColl.Contains("66")) && (!userRightsColl.Contains("67")) && (!userRightsColl.Contains("118")))
            {
                if (whereClause == "")
                {
                    whereClause = "    (p.Affair_id=4 or p.Affair_id=5 or p.Affair_id=6 or p.Affair_id=7 or p.Affair_id=9)";
                }
                else
                {
                    whereClause = whereClause + " and (p.Affair_id=4 or p.Affair_id=5 or p.Affair_id=6 or p.Affair_id=7 or p.Affair_id=9)";
                }
            }
            else if ((userRightsColl.Contains("62")) && (userRightsColl.Contains("63")) && (userRightsColl.Contains("64")) && (!userRightsColl.Contains("65")) && (!userRightsColl.Contains("66")) && (!userRightsColl.Contains("67")) && (!userRightsColl.Contains("118")))
            {
                if (whereClause == "")
                {
                    whereClause = "    (p.Affair_id=5 or p.Affair_id=6 or p.Affair_id=7 or p.Affair_id=9)";
                }
                else
                {
                    whereClause = whereClause + " and (p.Affair_id=5 or p.Affair_id=6 or p.Affair_id=7 or p.Affair_id=9)";
                }
            }
            else if ((userRightsColl.Contains("62")) && (userRightsColl.Contains("63")) && (userRightsColl.Contains("64")) && (userRightsColl.Contains("65")) && (!userRightsColl.Contains("66")) && (!userRightsColl.Contains("67")) && (!userRightsColl.Contains("118")))
            {
                if (whereClause == "")
                {
                    whereClause = "    (p.Affair_id=6 or p.Affair_id=7 or p.Affair_id=9)";
                }
                else
                {
                    whereClause = whereClause + " and (p.Affair_id=6 or p.Affair_id=7 or p.Affair_id=9)";
                }
            }
            else if ((userRightsColl.Contains("62")) && (userRightsColl.Contains("63")) && (userRightsColl.Contains("64")) && (userRightsColl.Contains("65")) && (userRightsColl.Contains("66")) && (!userRightsColl.Contains("67")) && (!userRightsColl.Contains("118")))
            {
                if (whereClause == "")
                {
                    whereClause = "    (p.Affair_id=7 or p.Affair_id=9)";
                }
                else
                {
                    whereClause = whereClause + " and (p.Affair_id=7 or p.Affair_id=9)";
                }
            }
            else if ((userRightsColl.Contains("62")) && (userRightsColl.Contains("63")) && (userRightsColl.Contains("64")) && (userRightsColl.Contains("65")) && (userRightsColl.Contains("66")) && (!userRightsColl.Contains("67")) && (userRightsColl.Contains("118")))
            {
                if (whereClause == "")
                {
                    whereClause = "    (p.Affair_id=7)";
                }
                else
                {
                    whereClause = whereClause + " and (p.Affair_id=7)";
                }
            }
            else if ((userRightsColl.Contains("62")) && (userRightsColl.Contains("63")) && (userRightsColl.Contains("64")) && (userRightsColl.Contains("65")) && (userRightsColl.Contains("66")) && (userRightsColl.Contains("67")) && (!userRightsColl.Contains("118")))
            {
                if (whereClause == "")
                {
                    whereClause = "    (p.Affair_id=9)";
                }
                else
                {
                    whereClause = whereClause + " and (p.Affair_id=9)";
                }
            }
            else if ((userRightsColl.Contains("62")) && (userRightsColl.Contains("63")) && (userRightsColl.Contains("64")) && (userRightsColl.Contains("65")) && (!userRightsColl.Contains("66")) && (userRightsColl.Contains("67")) && (userRightsColl.Contains("118")))
            {
                if (whereClause == "")
                {
                    whereClause = "    (p.Affair_id=6)";
                }
                else
                {
                    whereClause = whereClause + " and (p.Affair_id=6)";
                }
            }
            else if ((userRightsColl.Contains("62")) && (userRightsColl.Contains("63")) && (userRightsColl.Contains("64")) && (!userRightsColl.Contains("65")) && (userRightsColl.Contains("66")) && (userRightsColl.Contains("67")) && (userRightsColl.Contains("118")))
            {
                if (whereClause == "")
                {
                    whereClause = "    (p.Affair_id=5)";
                }
                else
                {
                    whereClause = whereClause + " and (p.Affair_id=5)";
                }
            }
            else if ((userRightsColl.Contains("62")) && (userRightsColl.Contains("63")) && (!userRightsColl.Contains("64")) && (userRightsColl.Contains("65")) && (userRightsColl.Contains("66")) && (userRightsColl.Contains("67")) && (userRightsColl.Contains("118")))
            {
                if (whereClause == "")
                {
                    whereClause = "    (p.Affair_id=4)";
                }
                else
                {
                    whereClause = whereClause + " and (p.Affair_id=4)";
                }
            }
            else if ((userRightsColl.Contains("62")) && (!userRightsColl.Contains("63")) && (userRightsColl.Contains("64")) && (userRightsColl.Contains("65")) && (userRightsColl.Contains("66")) && (userRightsColl.Contains("67")) && (userRightsColl.Contains("118")))
            {
                if (whereClause == "")
                {
                    whereClause = "    (p.Affair_id=8)";
                }
                else
                {
                    whereClause = whereClause + " and (p.Affair_id=8)";
                }
            }
            else if ((!userRightsColl.Contains("62")) && (userRightsColl.Contains("63")) && (userRightsColl.Contains("64")) && (userRightsColl.Contains("65")) && (userRightsColl.Contains("66")) && (userRightsColl.Contains("67")) && (userRightsColl.Contains("118")))
            {
                if (whereClause == "")
                {
                    whereClause = "    (p.Affair_id=1)";
                }
                else
                {
                    whereClause = whereClause + " and (p.Affair_id=1)";
                }
            }
        }

        if (whereClause == null)
        {
            whereClause = "";
        }

        return whereClause;
    }

    public string CheckAccessRightsForTenderNoYear_New(IList<string> userRightsColl)
    {
        string whereClause = null;
        if (userRightsColl.Contains("93") && userRightsColl.Contains("94") && userRightsColl.Contains("95") && userRightsColl.Contains("96") && userRightsColl.Contains("97") && userRightsColl.Contains("98") && userRightsColl.Contains("99") && userRightsColl.Contains("100")
           && userRightsColl.Contains("112") && userRightsColl.Contains("113") && userRightsColl.Contains("114") && (!userRightsColl.Contains("115")))
        {
            whereClause = " && (p.Field<string>('tender_no') LIKE '%2020%' || p.Field<string>('tender_no') IS NULL) && (p.Field<int>('FYID')=19) ";
        }
        else if (userRightsColl.Contains("93") && userRightsColl.Contains("94") && userRightsColl.Contains("95") && userRightsColl.Contains("96") && userRightsColl.Contains("97") && userRightsColl.Contains("98") && userRightsColl.Contains("99") && userRightsColl.Contains("100")
           && userRightsColl.Contains("112") && userRightsColl.Contains("113") && (!userRightsColl.Contains("114")) && userRightsColl.Contains("115"))
        {
            whereClause = " && (p.Field<string>('tender_no') LIKE '%2019%' || p.Field<string>('tender_no') IS NULL) && (p.Field<int>('FYID')=18) ";
        }
        else if (userRightsColl.Contains("93") && userRightsColl.Contains("94") && userRightsColl.Contains("95") && userRightsColl.Contains("96") && userRightsColl.Contains("97") && userRightsColl.Contains("98") && userRightsColl.Contains("99") && userRightsColl.Contains("100")
            && userRightsColl.Contains("112") && (!userRightsColl.Contains("113")) && userRightsColl.Contains("114") && userRightsColl.Contains("115"))
        {
            whereClause = " && (p.Field<string>('tender_no') LIKE '%2018%' || p.Field<string>('tender_no') IS NULL) && (p.Field<int>('FYID')=17) ";
        }
        else if (userRightsColl.Contains("93") && userRightsColl.Contains("94") && userRightsColl.Contains("95") && userRightsColl.Contains("96") && userRightsColl.Contains("97") && userRightsColl.Contains("98") && userRightsColl.Contains("99") && userRightsColl.Contains("100")
            && (!userRightsColl.Contains("112")) && userRightsColl.Contains("113") && userRightsColl.Contains("114") && userRightsColl.Contains("115"))
        {
            whereClause = " && (p.Field<string>('tender_no') LIKE '%2017%' || p.Field<string>('tender_no') IS NULL) && (p.Field<int>('FYID')=16) ";
        }
        else if (userRightsColl.Contains("93") && userRightsColl.Contains("94") && userRightsColl.Contains("95") && userRightsColl.Contains("96") && userRightsColl.Contains("97") && userRightsColl.Contains("98") && userRightsColl.Contains("99") && (!userRightsColl.Contains("100")))
        {
            whereClause = " && (p.Field<string>('tender_no') LIKE '%2016%' || p.Field<string>('tender_no') IS NULL) && (p.Field<int>('FYID')=15) ";
        }
        else if (userRightsColl.Contains("93") && userRightsColl.Contains("94") && userRightsColl.Contains("95") && userRightsColl.Contains("96") && userRightsColl.Contains("97") && userRightsColl.Contains("98") && (!userRightsColl.Contains("99")) && userRightsColl.Contains("100"))
        {
            whereClause = " && (p.Field<string>('tender_no') LIKE '%2015%' || p.Field<string>('tender_no') IS NULL) && (p.Field<int>('FYID')=14) ";
        }
        else if (userRightsColl.Contains("93") && userRightsColl.Contains("94") && userRightsColl.Contains("95") && userRightsColl.Contains("96") && (!userRightsColl.Contains("97")) && (!userRightsColl.Contains("98")) && userRightsColl.Contains("99") && userRightsColl.Contains("100"))
        {
            whereClause = " && (p.Field<string>('tender_no') LIKE '%2014%' || p.Field<string>('tender_no') IS NULL) && (p.Field<int>('FYID')=13) ";
        }
        else if (userRightsColl.Contains("93") && userRightsColl.Contains("94") && userRightsColl.Contains("95") && userRightsColl.Contains("96") && (!userRightsColl.Contains("97")) && userRightsColl.Contains("98") && userRightsColl.Contains("99") && userRightsColl.Contains("100"))
        {
            whereClause = " && (p.Field<string>('tender_no') LIKE '%2013%' || p.Field<string>('tender_no') IS NULL) && (p.Field<int>('FYID')=12) ";
        }
        else if (userRightsColl.Contains("93") && userRightsColl.Contains("94") && (!userRightsColl.Contains("95")) && (!userRightsColl.Contains("96")) && userRightsColl.Contains("97") && userRightsColl.Contains("98") && userRightsColl.Contains("99") && userRightsColl.Contains("100"))
        {
            whereClause = " && (p.Field<string>('tender_no') LIKE '%2012%' || p.Field<string>('tender_no') IS NULL) && (p.Field<int>('FYID')=11) ";
        }
        else if (userRightsColl.Contains("93") && userRightsColl.Contains("94") && (!userRightsColl.Contains("95")) && userRightsColl.Contains("96") && userRightsColl.Contains("97") && userRightsColl.Contains("98") && userRightsColl.Contains("99") && userRightsColl.Contains("100"))
        {
            whereClause = " && (p.Field<string>('tender_no') LIKE '%2011%' || p.Field<string>('tender_no') IS NULL) && (p.Field<int>('FYID')=10) ";
        }
        else if (userRightsColl.Contains("93") && (!userRightsColl.Contains("94")) && userRightsColl.Contains("95") && userRightsColl.Contains("96") && userRightsColl.Contains("97") && userRightsColl.Contains("98") && userRightsColl.Contains("99") && userRightsColl.Contains("100"))
        {
            whereClause = " && (p.Field<string>('tender_no') LIKE '%2010%' || p.Field<string>('tender_no') IS NULL) && (p.Field<int>('FYID')=9) ";
        }
        else if (userRightsColl.Contains("93") && userRightsColl.Contains("94") && userRightsColl.Contains("95") && userRightsColl.Contains("96") && userRightsColl.Contains("97") && userRightsColl.Contains("98") && userRightsColl.Contains("99") && userRightsColl.Contains("100"))
        {
            whereClause = " && (p.Field<string>('tender_no') is Null ) && (p.Field<int>('FYID')<>9 && p.Field<int>('FYID')<>10 && p.Field<int>('FYID')<>11 && p.Field<int>('FYID')<>12 && p.Field<int>('FYID')<>13 && p.Field<int>('FYID')<>14 && p.Field<int>('FYID')<>15)";
        }
        if (userRightsColl.Contains("93") && userRightsColl.Contains("94") && userRightsColl.Contains("95") && userRightsColl.Contains("96") && userRightsColl.Contains("97") && userRightsColl.Contains("98") && (!userRightsColl.Contains("99")) && (!userRightsColl.Contains("100"))
            && userRightsColl.Contains("112") && userRightsColl.Contains("113") && userRightsColl.Contains("114") && userRightsColl.Contains("115"))
        {
            whereClause = " && (p.Field<string>('tender_no') LIKE '%2016%' || p.Field<string>('tender_no') LIKE '%2015%' || p.Field<string>('tender_no') IS NULL) && (p.Field<int>('FYID')=14 || p.Field<int>('FYID')=15) ";
        }
        else if (userRightsColl.Contains("93") && userRightsColl.Contains("94") && userRightsColl.Contains("95") && userRightsColl.Contains("96") && userRightsColl.Contains("97") && (!userRightsColl.Contains("98")) && (!userRightsColl.Contains("99")) && (!userRightsColl.Contains("100"))
            && userRightsColl.Contains("112") && userRightsColl.Contains("113") && userRightsColl.Contains("114") && userRightsColl.Contains("115"))
        {
            whereClause = " && ((p.Field<string>('tender_no') LIKE '%2016%') || (p.Field<string>('tender_no') LIKE '%2015%') || (p.Field<string>('tender_no') LIKE '%2014%') || p.Field<string>('tender_no') IS NULL) && (p.Field<int>('FYID')=13 || p.Field<int>('FYID')=14 || p.Field<int>('FYID')=15) ";
        }
        else if (userRightsColl.Contains("93") && userRightsColl.Contains("94") && userRightsColl.Contains("95") && userRightsColl.Contains("96") && (!userRightsColl.Contains("97")) && (!userRightsColl.Contains("98")) && (!userRightsColl.Contains("99")) && (!userRightsColl.Contains("100"))
            && userRightsColl.Contains("112") && userRightsColl.Contains("113") && userRightsColl.Contains("114") && userRightsColl.Contains("115"))
        {
            whereClause = " && ((p.Field<string>('tender_no') LIKE '%2016%') || (p.Field<string>('tender_no') LIKE '%2015%') || (p.Field<string>('tender_no') LIKE '%2014%') || (p.Field<string>('tender_no') LIKE '%2013%') || p.Field<string>('tender_no') IS NULL) && (p.Field<int>('FYID')=12 || p.Field<int>('FYID')=13 || p.Field<int>('FYID')=14 || p.Field<int>('FYID')=15) ";
        }
        else if (userRightsColl.Contains("93") && userRightsColl.Contains("94") && userRightsColl.Contains("95") && (!userRightsColl.Contains("96")) && (!userRightsColl.Contains("97")) && (!userRightsColl.Contains("98")) && (!userRightsColl.Contains("99")) && (!userRightsColl.Contains("100"))
            && userRightsColl.Contains("112") && userRightsColl.Contains("113") && userRightsColl.Contains("114") && userRightsColl.Contains("115"))
        {
            whereClause = " && ((p.Field<string>('tender_no') LIKE '%2016%') || (p.Field<string>('tender_no') LIKE '%2015%') || (p.Field<string>('tender_no') LIKE '%2014%') || (p.Field<string>('tender_no') LIKE '%2013%') || (p.Field<string>('tender_no') LIKE '%2012%') || p.Field<string>('tender_no') IS NULL) && (p.Field<int>('FYID')=11 || p.Field<int>('FYID')=12 || p.Field<int>('FYID')=13 || p.Field<int>('FYID')=14 || p.Field<int>('FYID')=15) ";
        }
        else if (userRightsColl.Contains("93") && userRightsColl.Contains("94") && (!userRightsColl.Contains("95")) && (!userRightsColl.Contains("96")) && (!userRightsColl.Contains("97")) && (!userRightsColl.Contains("98")) && (!userRightsColl.Contains("99")) && (!userRightsColl.Contains("100"))
            && userRightsColl.Contains("112") && userRightsColl.Contains("113") && userRightsColl.Contains("114") && userRightsColl.Contains("115"))
        {
            whereClause = " && ((p.Field<string>('tender_no') LIKE '%2016%') || (p.Field<string>('tender_no') LIKE '%2015%') || (p.Field<string>('tender_no') LIKE '%2014%') || (p.Field<string>('tender_no') LIKE '%2013%') || (p.Field<string>('tender_no') LIKE '%2012%') || (p.Field<string>('tender_no') LIKE '%2011%') || p.Field<string>('tender_no') IS NULL) && (p.Field<int>('FYID')=10 || p.Field<int>('FYID')=11 || p.Field<int>('FYID')=12 || p.Field<int>('FYID')=13 || p.Field<int>('FYID')=14 || p.Field<int>('FYID')=15) ";
        }
        else if (userRightsColl.Contains("93") && (!userRightsColl.Contains("94")) && (!userRightsColl.Contains("95")) && (!userRightsColl.Contains("96")) && (!userRightsColl.Contains("97")) && (!userRightsColl.Contains("98")) && (!userRightsColl.Contains("99")) && (!userRightsColl.Contains("100")) && userRightsColl.Contains("112") &&
            userRightsColl.Contains("113") && userRightsColl.Contains("114") && userRightsColl.Contains("115"))
        {
            whereClause = " && ((p.Field<string>('tender_no') LIKE '%2016%') || (p.Field<string>('tender_no') LIKE '%2015%') || (p.Field<string>('tender_no') LIKE '%2014%') || (p.Field<string>('tender_no') LIKE '%2013%') || (p.Field<string>('tender_no') LIKE '%2012%') || (p.Field<string>('tender_no') LIKE '%2011%') || (p.Field<string>('tender_no') LIKE '%2010%') || p.Field<string>('tender_no') IS NULL) && (p.Field<int>('FYID')=10 || p.Field<int>('FYID')=11 || p.Field<int>('FYID')=12 || p.Field<int>('FYID')=13 || p.Field<int>('FYID')=14 || p.Field<int>('FYID')=15) ";
        }
        else if (userRightsColl.Contains("93") && (!userRightsColl.Contains("94")) && (!userRightsColl.Contains("95")) && (!userRightsColl.Contains("96")) && (!userRightsColl.Contains("97")) && (!userRightsColl.Contains("98")) && (!userRightsColl.Contains("99")) && (!userRightsColl.Contains("100")) && (!userRightsColl.Contains("112")) &&
        userRightsColl.Contains("113") && userRightsColl.Contains("114") && userRightsColl.Contains("115"))
        {
            whereClause = " && ((p.Field<string>('tender_no') LIKE '%2017%') || (p.Field<string>('tender_no') LIKE '%2016%') || (p.Field<string>('tender_no') LIKE '%2015%') || (p.Field<string>('tender_no') LIKE '%2014%') || (p.Field<string>('tender_no') LIKE '%2013%') || (p.Field<string>('tender_no') LIKE '%2012%') || (p.Field<string>('tender_no') LIKE '%2011%') || (p.Field<string>('tender_no') LIKE '%2010%') || p.Field<string>('tender_no') IS NULL) && (p.Field<int>('FYID')=10 || p.Field<int>('FYID')=11 || p.Field<int>('FYID')=12 || p.Field<int>('FYID')=13 || p.Field<int>('FYID')=14 || p.Field<int>('FYID')=15 || p.Field<int>('FYID')=16) ";
        }
        else if (userRightsColl.Contains("93") && (!userRightsColl.Contains("94")) && (!userRightsColl.Contains("95")) && (!userRightsColl.Contains("96")) && (!userRightsColl.Contains("97")) && (!userRightsColl.Contains("98")) && (!userRightsColl.Contains("99")) && (!userRightsColl.Contains("100")) && (!userRightsColl.Contains("112")) &&
        (!userRightsColl.Contains("113")) && userRightsColl.Contains("114") && userRightsColl.Contains("115"))
        {
            whereClause = " && ((p.Field<string>('tender_no') LIKE '%2018%') || (p.Field<string>('tender_no') LIKE '%2017%') || (p.Field<string>('tender_no') LIKE '%2016%') || (p.Field<string>('tender_no') LIKE '%2015%') || (p.Field<string>('tender_no') LIKE '%2014%') || (p.Field<string>('tender_no') LIKE '%2013%') || (p.Field<string>('tender_no') LIKE '%2012%') || (p.Field<string>('tender_no') LIKE '%2011%') || (p.Field<string>('tender_no') LIKE '%2010%') || p.Field<string>('tender_no') IS NULL) && (p.Field<int>('FYID')=10 || p.Field<int>('FYID')=11 || " +
            "p.Field<int>('FYID')=12 || p.Field<int>('FYID')=13 || p.Field<int>('FYID')=14 || p.Field<int>('FYID')=15 || p.Field<int>('FYID')=16 || p.Field<int>('FYID')=17) ";
        }
        else if (userRightsColl.Contains("93") && (!userRightsColl.Contains("94")) && (!userRightsColl.Contains("95")) && (!userRightsColl.Contains("96")) && (!userRightsColl.Contains("97")) && (!userRightsColl.Contains("98")) && (!userRightsColl.Contains("99")) && (!userRightsColl.Contains("100")) && (!userRightsColl.Contains("112")) &&
        (!userRightsColl.Contains("113")) && (!userRightsColl.Contains("114")) && userRightsColl.Contains("115"))
        {
            whereClause = " && ((p.Field<string>('tender_no') LIKE '%2019%') || (p.Field<string>('tender_no') LIKE '%2018%') || (p.Field<string>('tender_no') LIKE '%2017%') || (p.Field<string>('tender_no') LIKE '%2016%') || (p.Field<string>('tender_no') LIKE '%2015%') || (p.Field<string>('tender_no') LIKE '%2014%') || (p.Field<string>('tender_no') LIKE '%2013%') || (p.Field<string>('tender_no') LIKE '%2012%') || (p.Field<string>('tender_no') LIKE '%2011%') || (p.Field<string>('tender_no') LIKE '%2010%') || p.Field<string>('tender_no') IS NULL) && " +
            "(p.Field<int>('FYID')=10 || p.Field<int>('FYID')=11 || p.Field<int>('FYID')=12 || p.Field<int>('FYID')=13 || p.Field<int>('FYID')=14 || p.Field<int>('FYID')=15 || p.Field<int>('FYID')=16 || p.Field<int>('FYID')=17 || p.Field<int>('FYID')=18) ";
        }
        else if (userRightsColl.Contains("93") && (!userRightsColl.Contains("94")) && (!userRightsColl.Contains("95")) && (!userRightsColl.Contains("96")) && (!userRightsColl.Contains("97")) && (!userRightsColl.Contains("98")) && (!userRightsColl.Contains("99")) && (!userRightsColl.Contains("100")) && (!userRightsColl.Contains("112")) &&
        (!userRightsColl.Contains("113")) && (!userRightsColl.Contains("114")) && (!userRightsColl.Contains("115")))
        {
            whereClause = " && ((p.Field<string>('tender_no') LIKE '%2020%') || (p.Field<string>('tender_no') LIKE '%2019%') || (p.Field<string>('tender_no') LIKE '%2018%') || (p.Field<string>('tender_no') LIKE '%2017%') || (p.Field<string>('tender_no') LIKE '%2016%') || (p.Field<string>('tender_no') LIKE '%2015%') || (p.Field<string>('tender_no') LIKE '%2014%') || (p.Field<string>('tender_no') LIKE '%2013%') || (p.Field<string>('tender_no') LIKE '%2012%') || (p.Field<string>('tender_no') LIKE '%2011%') || (p.Field<string>('tender_no') LIKE '%2010%') || p.Field<string>('tender_no') IS NULL) && " +
            "(p.Field<int>('FYID')=10 || p.Field<int>('FYID')=11 || p.Field<int>('FYID')=12 || p.Field<int>('FYID')=13 || p.Field<int>('FYID')=14 || p.Field<int>('FYID')=15 || p.Field<int>('FYID')=16 || p.Field<int>('FYID')=17 || p.Field<int>('FYID')=18 || p.Field<int>('FYID')=19) ";
        }
        else if ((!userRightsColl.Contains("93") || userRightsColl.Contains("93")) && (!userRightsColl.Contains("94")) && (!userRightsColl.Contains("95")) && (!userRightsColl.Contains("96")) && (!userRightsColl.Contains("97")) && (!userRightsColl.Contains("98")) && (!userRightsColl.Contains("99")) && (!userRightsColl.Contains("100"))
            && (!userRightsColl.Contains("112")) && (!userRightsColl.Contains("113")) && (!userRightsColl.Contains("114")) && (!userRightsColl.Contains("115")))
        {
            whereClause = "";
        }
        else if ((!userRightsColl.Contains("93")) && (userRightsColl.Contains("94")) && (userRightsColl.Contains("95")) && (userRightsColl.Contains("96")) && (userRightsColl.Contains("97")) && (userRightsColl.Contains("98")) && (userRightsColl.Contains("99")) && (userRightsColl.Contains("100"))
            && userRightsColl.Contains("112") && userRightsColl.Contains("113") && userRightsColl.Contains("114") && userRightsColl.Contains("115"))
        {
            whereClause = "";
        }

        return whereClause;
    }


    //public void Populate(ref DataGridView dgvTendererInfo, IList<string> mUserRightsColl, string strCon, int mProjId, string mSelectedWorkOrderInfo, bool mIsWorkOrder, bool mIsHeadOfSection, int noOfDaysForClosing, bool isTenderClosingDateStage2)
    //{
    //    try
    //    {
    //        dgvTendererInfo.DataSource = null;

    //        StringBuilder buildSqlQuery = new StringBuilder();
    //        if (!mIsWorkOrder)
    //        {
    //            if (isTenderClosingDateStage2)
    //            {
    //                buildSqlQuery.Append("SELECT COMPANY.co_name AS TendererName,TenderDatesInfo.printDeliveredBy,TenderDatesInfo.NoOfEnvelopes, TenderDatesInfo.TenderSubmissionRemarks, TenderDatesInfo.PrintStatus AS Submission,TenderDatesInfo.TenderSubmittedTime, " +
    //                " TenderDatesInfo.VersionNo, TenderDatesInfo.date_id,TenderDatesInfo.employee_id,TenderDatesInfo.co_id FROM TenderDatesInfo INNER JOIN COMPANY ON TenderDatesInfo.co_id = COMPANY.co_id WHERE (TenderDatesInfo.proj_id = " + mProjId + ") AND (TenderDatesInfo.Tender_Issued = 1) and " +
    //                "TenderDatesInfo.TenderSubmittedTime is not NULL and eval_tendersubmission_stage=2 order by TenderDatesInfo.TenderSubmittedTime");
    //            }
    //            else
    //            {
    //                buildSqlQuery.Append("SELECT COMPANY.co_name AS TendererName,TenderDatesInfo.printDeliveredBy,TenderDatesInfo.NoOfEnvelopes, TenderDatesInfo.TenderSubmissionRemarks, TenderDatesInfo.PrintStatus AS Submission,TenderDatesInfo.TenderSubmittedTime, " +
    //                " TenderDatesInfo.VersionNo, TenderDatesInfo.date_id,TenderDatesInfo.employee_id,TenderDatesInfo.co_id FROM TenderDatesInfo INNER JOIN COMPANY ON TenderDatesInfo.co_id = COMPANY.co_id WHERE (TenderDatesInfo.proj_id = " + mProjId + ") AND (TenderDatesInfo.Tender_Issued = 1) and " +
    //                "TenderDatesInfo.TenderSubmittedTime is not NULL and eval_tendersubmission_stage=1 order by TenderDatesInfo.TenderSubmittedTime");
    //            }
    //        }
    //        else
    //        {
    //            buildSqlQuery.Append("SELECT COMPANY.co_name AS TendererName, WorkOrderSubmissions.printDeliveredBy,WorkOrderSubmissions.NoOfEnvelopes, WorkOrderSubmissions.TenderSubmissionRemarks, WorkOrderSubmissions.PrintStatus AS Submission,WorkOrderSubmissions.TenderSubmittedTime," +
    //            "WorkOrderSubmissions.VersionNo, CONTRACTORS.bidder_id,WorkOrderSubmissions.workOrderSubmissionID FROM WorkOrderSubmissions Full Outer JOIN CONTRACTORS ON CONTRACTORS.bidder_id = WorkOrderSubmissions.bidder_id INNER JOIN COMPANY ON COMPANY.co_id = CONTRACTORS.co_id " +
    //            "WHERE (WorkOrderSubmissions.tenderSubmittedTime IS NOT NULL) and CONTRACTORS.proj_id = " + mProjId + " and WorkOrderSubmissions.workOrderID=" + mSelectedWorkOrderInfo.Split(',')[2] + " and (CONTRACTORS.stage_Id = 4) order by WorkOrderSubmissions.TenderSubmittedTime");
    //        }

    //        sqlConn = new SqlConnection(strCon);
    //        sqlConn.Open();

    //        DAL dalObj = new DAL();
    //        dtFinalTenderersInfo = new System.Data.DataTable("FilteredTenderersInfo");
    //        if (!mIsWorkOrder)
    //        {
    //            dtFinalTenderersInfo.Columns.Add("TendererName");
    //            dtFinalTenderersInfo.Columns.Add("printDeliveredBy");
    //            dtFinalTenderersInfo.Columns.Add("NoOfEnvelopes");
    //            dtFinalTenderersInfo.Columns.Add("TenderSubmissionRemarks");
    //            dtFinalTenderersInfo.Columns.Add("Submission");
    //            dtFinalTenderersInfo.Columns.Add("TenderSubmittedTime");
    //            dtFinalTenderersInfo.Columns.Add("TenderSubmissionReturnedSerialNumber");
    //            dtFinalTenderersInfo.Columns.Add("PrintVoucher");
    //            if (mUserRightsColl.Count() == 0 || mIsHeadOfSection)
    //            {
    //                dtFinalTenderersInfo.Columns.Add("ResetSubmissionData");
    //            }
    //            //dtFinalTenderersInfo.Columns.Add("TenderSubmissionNo");
    //            dtFinalTenderersInfo.Columns.Add("VersionNo");
    //            dtFinalTenderersInfo.Columns.Add("Date_Id");
    //            dtFinalTenderersInfo.Columns.Add("employee_id");
    //            dtFinalTenderersInfo.Columns.Add("co_id");
    //            //dtFinalTenderersInfo.Columns.Add("ID", typeof(Int16));

    //        }
    //        else
    //        {
    //            dtFinalTenderersInfo.Columns.Add("TendererName");
    //            dtFinalTenderersInfo.Columns.Add("printDeliveredBy");
    //            dtFinalTenderersInfo.Columns.Add("NoOfEnvelopes");
    //            dtFinalTenderersInfo.Columns.Add("TenderSubmissionRemarks");
    //            dtFinalTenderersInfo.Columns.Add("Submission");
    //            dtFinalTenderersInfo.Columns.Add("TenderSubmittedTime");
    //            dtFinalTenderersInfo.Columns.Add("TenderSubmissionReturnedSerialNumber");
    //            dtFinalTenderersInfo.Columns.Add("PrintVoucher");
    //            if (mUserRightsColl.Count() == 0 || mIsHeadOfSection)
    //            {
    //                dtFinalTenderersInfo.Columns.Add("ResetSubmissionData");
    //            }
    //            //dtFinalTenderersInfo.Columns.Add("TenderSubmissionNo");
    //            dtFinalTenderersInfo.Columns.Add("VersionNo");
    //            //dtFinalTenderersInfo.Columns.Add("workOrderID");
    //            dtFinalTenderersInfo.Columns.Add("bidder_id");
    //            dtFinalTenderersInfo.Columns.Add("workOrderSubmissionID");

    //        }
    //        dtFinalTenderersInfo.AcceptChanges();

    //        dtFirstTenderersInfo = dalObj.GetDataFromDB("NotNullTendererInfo", buildSqlQuery.ToString());

    //        if (dtFirstTenderersInfo == null)
    //            MessageBox.Show("Error occurred while retrieving the records", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

    //        if (mIsWorkOrder)
    //        {
    //            if (dtFirstTenderersInfo.Rows.Count != 0)
    //            {
    //                WOTendererInfo(dtFirstTenderersInfo, mUserRightsColl, mIsHeadOfSection, false, noOfDaysForClosing);

    //                //dtFirstTenderersInfo = dalObj.GetDataFromDB("NotNullTendererInfo", buildSqlQuery.ToString());
    //                //WOTendererInfo(dtFirstTenderersInfo, mUserRightsColl, mIsHeadOfSection);
    //                StringBuilder bidderIDs = new StringBuilder();
    //                foreach (DataRow dr in dtFinalTenderersInfo.Rows)
    //                {
    //                    bidderIDs.Append(dr["bidder_id"].ToString() + ",");

    //                }
    //                buildSqlQuery = new StringBuilder();
    //                if (bidderIDs.Length != 0)
    //                {
    //                    buildSqlQuery.Append("SELECT COMPANY.co_name AS TendererName, CONTRACTORS.bidder_id FROM CONTRACTORS INNER JOIN COMPANY ON COMPANY.co_id = CONTRACTORS.co_id " +
    //                    "WHERE CONTRACTORS.proj_id = " + mProjId + " and (CONTRACTORS.stage_Id = 4) and CONTRACTORS.bidder_id not in(" + bidderIDs.ToString().Substring(0, bidderIDs.ToString().Length - 1) + ")");
    //                }
    //                dtFirstTenderersInfo = dalObj.GetDataFromDB("NullTendererInfo", buildSqlQuery.ToString());
    //                if (dtFirstTenderersInfo.Rows.Count != 0)
    //                {
    //                    WOTendererInfo(dtFirstTenderersInfo, mUserRightsColl, mIsHeadOfSection, true, noOfDaysForClosing);
    //                }
    //            }
    //            else
    //            {
    //                buildSqlQuery = new StringBuilder();
    //                buildSqlQuery.Append("SELECT COMPANY.co_name AS TendererName, CONTRACTORS.bidder_id FROM CONTRACTORS INNER JOIN COMPANY ON COMPANY.co_id = CONTRACTORS.co_id " +
    //                    "WHERE CONTRACTORS.proj_id = " + mProjId + " and (CONTRACTORS.stage_Id = 4)");

    //                dtFirstTenderersInfo = dalObj.GetDataFromDB("NotNullTendererInfo", buildSqlQuery.ToString());
    //                WOTendererInfo(dtFirstTenderersInfo, mUserRightsColl, mIsHeadOfSection, true, noOfDaysForClosing);
    //            }

    //        }
    //        else
    //        {
    //            if (dtFirstTenderersInfo.Rows.Count != 0)
    //                NonWOTendererInfo(dtFirstTenderersInfo, mUserRightsColl, mIsHeadOfSection, noOfDaysForClosing, isTenderClosingDateStage2);
    //        }


    //        buildSqlQuery.Remove(0, buildSqlQuery.Length);
    //        if (!mIsWorkOrder)
    //        {
    //            if (!isTenderClosingDateStage2)
    //            {
    //                buildSqlQuery.Append("SELECT COMPANY.co_name AS TendererName,TenderDatesInfo.printDeliveredBy,TenderDatesInfo.NoOfEnvelopes, TenderDatesInfo.TenderSubmissionRemarks, TenderDatesInfo.PrintStatus AS Submission,TenderDatesInfo.TenderSubmittedTime, " +
    //                " TenderDatesInfo.VersionNo, TenderDatesInfo.date_id,TenderDatesInfo.employee_id,TenderDatesInfo.co_id FROM TenderDatesInfo INNER JOIN COMPANY ON TenderDatesInfo.co_id = COMPANY.co_id WHERE (TenderDatesInfo.proj_id = " + mProjId + ") AND (TenderDatesInfo.Tender_Issued = 1) and " + //AND (NOT (TenderDatesInfo.remarks LIKE '%regret%') OR TenderDatesInfo.remarks IS NULL)
    //                " (TenderDatesInfo.eval_tendersubmission_stage = 1 or eval_tendersubmission_stage is Null) and TenderDatesInfo.TenderSubmittedTime is NULL");
    //            }
    //            else
    //            {
    //                if (dtFinalTenderersInfo.AsEnumerable().Select(x => x["co_id"].ToString()).ToArray().Count() != 0)
    //                {
    //                    buildSqlQuery.Append("SELECT COMPANY.co_name AS TendererName,TenderDatesInfo.printDeliveredBy,TenderDatesInfo.NoOfEnvelopes, TenderDatesInfo.TenderSubmissionRemarks, TenderDatesInfo.PrintStatus AS Submission,TenderDatesInfo.TenderSubmittedTime, " +
    //                    " TenderDatesInfo.VersionNo, TenderDatesInfo.date_id,TenderDatesInfo.employee_id,TenderDatesInfo.co_id FROM TenderDatesInfo INNER JOIN COMPANY ON TenderDatesInfo.co_id = COMPANY.co_id WHERE (TenderDatesInfo.proj_id = " + mProjId + ") AND (TenderDatesInfo.Tender_Issued = 1) and (TenderDatesInfo.eval_tendersubmission_stage = 1) " + //AND (NOT (TenderDatesInfo.remarks LIKE '%regret%') OR TenderDatesInfo.remarks IS NULL)
    //                    " and TenderDatesInfo.co_id not in (" + string.Join(",", dtFinalTenderersInfo.AsEnumerable().Select(x => x["co_id"].ToString()).ToArray()) + ") and TenderDatesInfo.TenderSubmittedTime is not NULL order by TenderDatesInfo.TenderSubmittedTime");
    //                }
    //                else
    //                {
    //                    buildSqlQuery.Append("SELECT COMPANY.co_name AS TendererName,TenderDatesInfo.printDeliveredBy,TenderDatesInfo.NoOfEnvelopes, TenderDatesInfo.TenderSubmissionRemarks, TenderDatesInfo.PrintStatus AS Submission,TenderDatesInfo.TenderSubmittedTime, " +
    //                    " TenderDatesInfo.VersionNo, TenderDatesInfo.date_id,TenderDatesInfo.employee_id,TenderDatesInfo.co_id FROM TenderDatesInfo INNER JOIN COMPANY ON TenderDatesInfo.co_id = COMPANY.co_id WHERE (TenderDatesInfo.proj_id = " + mProjId + ") AND (TenderDatesInfo.Tender_Issued = 1) " +
    //                    "and (TenderDatesInfo.eval_tendersubmission_stage = 1) and TenderDatesInfo.TenderSubmittedTime is not NULL order by TenderDatesInfo.TenderSubmittedTime"); //+ AND (NOT (TenderDatesInfo.remarks LIKE '%regret%') OR TenderDatesInfo.remarks IS NULL)                            
    //                }
    //            }
    //            dtSecondTenderersInfo = dalObj.GetDataFromDB("NullTendererInfo", buildSqlQuery.ToString());
    //            if (dtSecondTenderersInfo == null)
    //                MessageBox.Show("Error occurred while retrieving the records", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
    //        }


    //        if (dtFinalTenderersInfo.Rows.Count != 0)
    //        {

    //            if (!mIsWorkOrder)
    //            {
    //                if (dtSecondTenderersInfo.Rows.Count != 0)
    //                {
    //                    NonWOTendererInfo(dtSecondTenderersInfo, mUserRightsColl, mIsHeadOfSection, noOfDaysForClosing, isTenderClosingDateStage2);
    //                    dgvTendererInfo.DataSource = dtFinalTenderersInfo;
    //                }
    //                else
    //                    dgvTendererInfo.DataSource = dtFinalTenderersInfo;
    //            }
    //            else
    //            {
    //                dgvTendererInfo.DataSource = dtFinalTenderersInfo;
    //            }
    //        }
    //        else
    //        {
    //            if (!mIsWorkOrder)
    //            {
    //                if (dtSecondTenderersInfo.Rows.Count != 0)
    //                {
    //                    NonWOTendererInfo(dtSecondTenderersInfo, mUserRightsColl, mIsHeadOfSection, noOfDaysForClosing, isTenderClosingDateStage2);
    //                    dgvTendererInfo.DataSource = dtFinalTenderersInfo;
    //                }
    //                else
    //                    dgvTendererInfo.DataSource = null;
    //            }
    //            else
    //            {

    //                //dtSecondTenderersInfo = dalObj.GetDataFromDB("NotNullTendererInfo", "SELECT COMPANY.co_name AS TendererName, CONTRACTORS.bidder_id FROM CONTRACTORS INNER JOIN COMPANY ON COMPANY.co_id = CONTRACTORS.co_id " +
    //                //"WHERE CONTRACTORS.proj_id = " + mProjId + " and (CONTRACTORS.stage_Id = 4)");
    //                //if (dtFinalTenderersInfo.Rows.Count != 0)
    //                //{
    //                //    //WOTendererInfo(dtSecondTenderersInfo, false);
    //                //    dgvTendererInfo.DataSource = dtFinalTenderersInfo;
    //                //}
    //                //else
    //                dgvTendererInfo.DataSource = null;

    //            }

    //        }

    //        if (mUserRightsColl.Count() == 0 || mIsHeadOfSection)
    //        {
    //            dgvTendererInfo.Columns[9].Visible = false;
    //            dgvTendererInfo.Columns[10].Visible = false;
    //            if (isTenderClosingDateStage2)
    //            {
    //                dgvTendererInfo.Columns[11].Visible = false;
    //                dgvTendererInfo.Columns[12].Visible = false;
    //            }
    //            if (mIsWorkOrder)
    //            {
    //                dgvTendererInfo.Columns[11].Visible = false;
    //            }
    //            else
    //            {
    //                dgvTendererInfo.Columns[11].Visible = false;
    //                dgvTendererInfo.Columns[12].Visible = false;
    //            }

    //        }
    //        else
    //        {
    //            dgvTendererInfo.Columns[8].Visible = false;
    //            dgvTendererInfo.Columns[9].Visible = false;
    //            dgvTendererInfo.Columns[10].Visible = false;
    //            if (isTenderClosingDateStage2)
    //            {
    //                dgvTendererInfo.Columns[11].Visible = false;
    //                dgvTendererInfo.Columns[12].Visible = false;
    //            }
    //            if (mIsWorkOrder)
    //            {
    //                dgvTendererInfo.Columns[11].Visible = false;
    //            }
    //        }

    //    }
    //    catch (Exception ex)
    //    {
    //        MessageBox.Show("Error occurred while displaying the records", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
    //    }
    //    finally
    //    {
    //        sqlConn.Close();
    //    }

    //}


    private System.Data.DataTable NonWOTendererInfo(System.Data.DataTable dt, IList<string> mUserRightsColl, bool mIsHeadOfSection, int noOfDaysForClosing, bool isTenderClosingDateStage2)
    {
        //short idCounter = 1;
        foreach (DataRow dr in dt.Rows)
        {
            DataRow drNew = dtFinalTenderersInfo.NewRow();
            drNew[0] = dr[0];  //TendererName  

            drNew[1] = dr[1]; //Print DeliveredBy                           
            drNew[2] = dr[2];  //NoOfEnvelopes  
            drNew[3] = dr[3].ToString(); //TenderSubmission Remarks
            drNew[4] = dr[4];  //Submission                             

            if (dr[5] != DBNull.Value)
                drNew[5] = dr[5].ToString();  //Tender Submission Time  

            //!(dr[3].ToString().ToLower().Contains("notapproved") || dr[3].ToString().ToLower().Contains("not approved")) &&                    

            drNew[6] = "";  //Returned
            if (noOfDaysForClosing >= 0)
            {
                if (!dr[3].ToString().ToLower().Contains("regret"))
                {
                    if (mIsHeadOfSection)
                    {
                        drNew[7] = "Issue Voucher"; //VoucherPrint For Original & Copy                        
                        //lblTenderStatus.Text = "Tender is Open";
                    }
                    else if (noOfDaysForClosing == 0)
                    {
                        if (!(DateTime.Now.TimeOfDay.Hours >= 13 && DateTime.Now.TimeOfDay.Minutes <= 30))
                        {
                            drNew[7] = "Issue Voucher"; //VoucherPrint For Original & Copy                                  
                        }
                        else
                        {
                            drNew[7] = "";
                        }
                    }
                    else
                    {
                        drNew[7] = "Issue Voucher";
                        //lblTenderStatus.Text = "Tender is Open";
                    }
                }
                else
                {
                    drNew[7] = "";
                    drNew[4] = "Regret and Not Submitted";
                }
            }
            else
            {
                if (mIsHeadOfSection)
                {
                    drNew[7] = "Issue Voucher"; //VoucherPrint For Original & Copy                        
                    //lblTenderStatus.Text = "Tender is Open";
                }
                else
                {
                    drNew[7] = "";
                }
            }

            if (mUserRightsColl.Count() == 0 || mIsHeadOfSection)
            {
                drNew[8] = "Reset Voucher Submission Data"; //VersionNo
                drNew[9] = dr[6].ToString(); //VersionNo                     
                drNew[10] = dr[7]; //bidderID                           
                drNew[11] = dr[8]; //empID                           
                drNew[12] = dr[9]; //coID                           
                //drNew[11] = dr[8]; //workOrderSubmissionID   
            }
            else
            {
                //drNew[8] = dr[6].ToString();  //TenderSubmissionNo
                drNew[8] = dr[6].ToString(); //VersionNo
                drNew[9] = dr[7]; //DateId                                  
                drNew[10] = dr[8]; //empID                           
                drNew[11] = dr[9]; //coID                           
            }
            dtFinalTenderersInfo.Rows.Add(drNew);
            dtFinalTenderersInfo.AcceptChanges();
        }
        //else
        //{                    
        //    drNew[1] = ""; //Print DeliveredBy                           
        //    drNew[2] = "";  //NoOfEnvelopes  
        //    drNew[3] = ""; //TenderSubmission Remarks
        //    drNew[4] = "";  //Submission                                                 
        //    drNew[5] = "";  //Tender Submission Time  
        //    drNew[6] = "";  //Returned
        //    if (noOfDaysForClosing >= 0)
        //    {                         
        //        if (mIsHeadOfSection)
        //        {
        //            drNew[7] = "Issue Voucher"; //VoucherPrint For Original & Copy                        
        //            //lblTenderStatus.Text = "Tender is Open";
        //        }
        //        else if (noOfDaysForClosing == 0)
        //        {
        //            if (!(DateTime.Now.TimeOfDay.Hours >= 13 && DateTime.Now.TimeOfDay.Minutes <= 30))
        //            {
        //                drNew[7] = "Issue Voucher"; //VoucherPrint For Original & Copy                                  
        //            }
        //            else
        //            {
        //                drNew[7] = "";
        //            }
        //        }
        //        else
        //        {
        //            drNew[7] = "Issue Voucher";
        //            //lblTenderStatus.Text = "Tender is Open";
        //        }

        //    }
        //    else
        //    {
        //        if (mIsHeadOfSection)
        //        {
        //            drNew[7] = "Issue Voucher"; //VoucherPrint For Original & Copy                        
        //            //lblTenderStatus.Text = "Tender is Open";
        //        }
        //        else
        //        {
        //            drNew[7] = "";
        //        }
        //    }

        //    if (mUserRightsColl.Count() == 0 || mIsHeadOfSection)
        //    {
        //        drNew[8] = "Reset Voucher Submission Data"; //VersionNo
        //        drNew[9] = ""; //VersionNo                     
        //        drNew[10] = dr[7]; //bidderID                           
        //        drNew[11] = dr[8]; //empID                           
        //        drNew[12] = dr[9]; //coID                           
        //        //drNew[11] = dr[8]; //workOrderSubmissionID   
        //    }
        //    else
        //    {
        //        //drNew[8] = dr[6].ToString();  //TenderSubmissionNo
        //        drNew[8] = ""; //VersionNo
        //        drNew[9] = dr[7]; //DateId                                  
        //        drNew[10] = dr[8]; //empID                           
        //        drNew[11] = dr[9]; //coID                           
        //    }
        //}




        return dtFinalTenderersInfo;
    }

    private System.Data.DataTable WOTendererInfo(System.Data.DataTable dt, IList<string> mUserRightsColl, bool mIsHeadOfSection, bool isWorkOrderSubmissionNull, int noOfDaysForClosing)
    {
        //short idCounter = 1;
        foreach (DataRow dr in dt.Rows)
        {
            DataRow drNew = dtFinalTenderersInfo.NewRow();
            drNew[0] = dr[0];  //TendererName    
            if (!isWorkOrderSubmissionNull)
            {
                //if (isRecordsFound)
                //{
                drNew[1] = dr[1]; //Print DeliveredBy                           
                drNew[2] = dr[2];  //NoOfEnvelopes  
                drNew[3] = dr[3].ToString(); //TenderSubmission Remarks
                drNew[4] = dr[4];  //Submission                             

                if (dr[5] != DBNull.Value)
                    drNew[5] = dr[5].ToString();  //Tender Submission Time  

                //!(dr[3].ToString().ToLower().Contains("notapproved") || dr[3].ToString().ToLower().Contains("not approved")) &&                                                                       
                drNew[6] = "";  //Returned      
                if (noOfDaysForClosing >= 0)
                {
                    if (mIsHeadOfSection)
                    {
                        drNew[7] = "Issue Voucher"; //VoucherPrint For Original & Copy                        
                        //lblTenderStatus.Text = "Tender is Open";
                    }
                    else if (dr[3].ToString().ToLower().Contains("regret"))
                    {
                        drNew[7] = "";
                    }
                    else if (noOfDaysForClosing == 0)
                    {
                        if (!(DateTime.Now.TimeOfDay.Hours >= 13 && DateTime.Now.TimeOfDay.Minutes <= 30))
                        {
                            drNew[7] = "Issue Voucher"; //VoucherPrint For Original & Copy                                  
                        }
                        else
                        {
                            drNew[7] = "";
                        }
                    }
                    else
                    {
                        drNew[7] = "Issue Voucher";
                    }
                }
                else
                {
                    if (mIsHeadOfSection)
                    {
                        drNew[7] = "Issue Voucher"; //VoucherPrint For Original & Copy                        
                        //lblTenderStatus.Text = "Tender is Open";
                    }
                    else
                    {
                        drNew[7] = "";
                    }
                }
                if (mUserRightsColl.Count() == 0 || mIsHeadOfSection)
                {
                    drNew[8] = "Reset Voucher Submission Data"; //VersionNo
                    drNew[9] = dr[6].ToString(); //VersionNo                                            
                    drNew[10] = dr[7]; //bidderID                           
                    drNew[11] = dr[8]; //workOrderSubmissionID   
                }
                else
                {
                    drNew[8] = dr[6].ToString(); //VersionNo                                     
                    drNew[9] = dr[7]; //bidderID                           
                    drNew[10] = dr[8]; //workOrderSubmissionID   
                }
            }
            else
            {
                drNew[1] = ""; //Print DeliveredBy                           
                drNew[2] = "";  //NoOfEnvelopes  
                drNew[3] = ""; //TenderSubmission Remarks
                drNew[4] = "";  //Submission                             

                drNew[5] = "";  //Tender Submission Time  

                //!(dr[3].ToString().ToLower().Contains("notapproved") || dr[3].ToString().ToLower().Contains("not approved")) &&                                                                       
                drNew[6] = "";  //Returned      
                if (noOfDaysForClosing >= 0)
                {
                    if (mIsHeadOfSection)
                    {
                        drNew[7] = "Issue Voucher"; //VoucherPrint For Original & Copy                        
                        //lblTenderStatus.Text = "Tender is Open";
                    }
                    else if (noOfDaysForClosing == 0)
                    {
                        if (!(DateTime.Now.TimeOfDay.Hours >= 13 && DateTime.Now.TimeOfDay.Minutes <= 30))
                        {
                            drNew[7] = "Issue Voucher"; //VoucherPrint For Original & Copy                                  
                        }
                        else
                        {
                            drNew[7] = "";
                        }
                    }
                    else
                    {
                        drNew[7] = "Issue Voucher";
                    }
                }
                else
                {
                    if (mIsHeadOfSection)
                    {
                        drNew[7] = "Issue Voucher"; //VoucherPrint For Original & Copy                        
                        //lblTenderStatus.Text = "Tender is Open";
                    }
                    else
                    {
                        drNew[7] = "";
                    }
                }
                if (mUserRightsColl.Count() == 0 || mIsHeadOfSection)
                {
                    drNew[8] = ""; //VersionNo
                    drNew[9] = ""; //VersionNo                                            
                    drNew[10] = dr[1]; //bidderID                           
                    drNew[11] = ""; //workOrderSubmissionID   
                }
                else
                {
                    drNew[8] = ""; //VersionNo                                     
                    drNew[9] = dr[1]; //bidderID                           
                    drNew[10] = ""; //workOrderSubmissionID   
                }
            }
            dtFinalTenderersInfo.Rows.Add(drNew);
            dtFinalTenderersInfo.AcceptChanges();
        }
        return dtFinalTenderersInfo;
    }

    // getBarCodeImage function created by Varun on 01/Jun/2015
    ////private iTextSharp.text.Image getBarCodeImage(iTextSharp.text.pdf.PdfReader pdfReader, string barCodeSerialNo, string sysDate, int dpi, float pageWidth, float pageHeight, iTextSharp.text.pdf.PdfContentByte pdfPage, string versionNo, ref string[] arrInfo, string cmtShortName, bool isWorkOrder, bool isTenderClosingDateStage2)
    ////{
    ////    string serialNo = null;
    ////    iTextSharp.text.Image barcodeImage1 = null;
    ////    //4.1. Generate the UPC-A CCB composite barcode. 
    ////    using (Neodynamic.SDK.Barcode.BarcodeProfessional bc1 = new Neodynamic.SDK.Barcode.BarcodeProfessional())
    ////    {

    ////        bc1.Symbology = Neodynamic.SDK.Barcode.Symbology.Code39;

    ////        if (versionNo != null)
    ////            serialNo = DateTime.Now.Year + "/" + barCodeSerialNo + "/" + arrInfo[8] + "/" + versionNo;
    ////        else if (arrInfo.Length >= 9)
    ////            serialNo = DateTime.Now.Year + "/" + barCodeSerialNo + "/" + arrInfo[8];
    ////        else if (cmtShortName != null)
    ////            serialNo = DateTime.Now.Year + "/" + barCodeSerialNo + "/" + cmtShortName;
    ////        else if (cmtShortName == null)
    ////            serialNo = DateTime.Now.Year + "/" + barCodeSerialNo;

    ////        //bc1.Text = serialNo;
    ////        //bc1.TextAlignment = Neodynamic.SDK.Barcode.Alignment.BelowCenter;

    ////        bc1.Code = serialNo;
    ////        bc1.CodeAlignment = Neodynamic.SDK.Barcode.Alignment.BelowCenter;

    ////        //bc1.Code = sysDate;
    ////        // bc1.CodeAlignment = Neodynamic.SDK.Barcode.Alignment.AboveCenter;

    ////        bc1.Text = sysDate;
    ////        bc1.TextAlignment = Neodynamic.SDK.Barcode.Alignment.AboveCenter;

    ////        bc1.AddChecksum = false;

    ////        //set the barcode unit and sizes... 
    ////        bc1.BarcodeUnit = Neodynamic.SDK.Barcode.BarcodeUnit.Inch;
    ////        bc1.BarWidth = 0.009; //the narrow bar width a.k.a. X value 
    ////        bc1.BarHeight = 0.3; //the height of the barcode bars
    ////        // bc1.GuardBarHeight = bc1.BarHeight + 5 * bc1.BarWidth; //the height of the guard bars only available for EAN/UPC barcodes 
    ////        bc1.GuardBarHeight = bc1.BarHeight + 5 * bc1.BarWidth; //the height of the guard bars only available for EAN/UPC barcodes 
    ////        // bc1.QuietZoneWidth = 9 * bc1.BarWidth; //the quiet zone for UPC-A is 9 times the BarWidth value per GS1 spec 
    ////        bc1.QuietZoneWidth = 9 * bc1.BarWidth; //the quiet zone for UPC-A is 9 times the BarWidth value per GS1 spec 
    ////        //Generate the barcode image content for inserting it into the PDF page   //For high quality, you can generated the barcode at, for instance, 300 dpi 
    ////        barcodeImage1 = iTextSharp.text.Image.GetInstance(bc1.GetBarcodeImage(System.Drawing.Imaging.ImageFormat.Png, dpi));
    ////        //set the position of the barcode image. PDF uses Points as unit (1 point = 1/72 inch)  //the starting point (x=0, y=0) in the PDF coord is the bottom-left corner!!!                 
    ////        // barcodeImage1.SetAbsolutePosition(pageWidth - 4.25f * 72f + ((3.25f - (barcodeImage1.Width / dpi)) / 2) * 72f, pageHeight - ((barcodeImage1.Height / dpi) * 72f) - (2.5f * 72f));                
    ////        barcodeImage1.SetAbsolutePosition(pageWidth - 3.47f * 72f + ((3.25f - (barcodeImage1.Width / dpi)) / 2) * 72f, pageHeight - ((barcodeImage1.Height / dpi) * 72f) - (0.90f * 72f));
    ////        //scale the image based on the image dpi 
    ////        barcodeImage1.ScalePercent(72f / (float)dpi * 100f);
    ////        //add the image object to the pdf page 
    ////        pdfPage.AddImage(barcodeImage1);
    ////    }

    ////    if (versionNo != null)
    ////    {
    ////        try
    ////        {
    ////            using (SqlConnection sqlConn = new SqlConnection(connStr))
    ////            {
    ////                sqlConn.Open();
    ////                SqlCommand cmd = null;
    ////                if (!isWorkOrder)
    ////                {
    ////                    if (!isTenderClosingDateStage2)
    ////                    {
    ////                        cmd = new SqlCommand("update TenderDatesInfo set TenderSubmissionReturnedSerialNumber=@fullSerialNo where date_id=@dateId", sqlConn);
    ////                        cmd.Parameters.AddWithValue("@fullSerialNo", serialNo);
    ////                        cmd.Parameters.AddWithValue("@dateId", arrInfo[3].ToString());
    ////                        cmd.ExecuteNonQuery();
    ////                    }
    ////                    else
    ////                    {
    ////                        cmd = new SqlCommand("select date_id from TenderDatesInfo where eval_tendersubmission_stage=@evalTendersubmissionStage and date_id=@dateId", sqlConn);
    ////                        cmd.Parameters.AddWithValue("@dateId", arrInfo[3].ToString());
    ////                        cmd.Parameters.AddWithValue("@evalTendersubmissionStage", 2);
    ////                        SqlDataReader sqlDtReader = cmd.ExecuteReader();
    ////                        if (sqlDtReader.HasRows)
    ////                        {
    ////                            sqlDtReader.Close();
    ////                            cmd.Dispose();
    ////                            cmd = new SqlCommand("update TenderDatesInfo set TenderSubmissionReturnedSerialNumber=@fullSerialNo,eval_tendersubmission_stage=@evalTendersubmissionStage where date_id=@dateId", sqlConn);
    ////                            cmd.Parameters.AddWithValue("@fullSerialNo", serialNo);
    ////                            cmd.Parameters.AddWithValue("@dateId", arrInfo[3].ToString());
    ////                            cmd.Parameters.AddWithValue("@evalTendersubmissionStage", 2);
    ////                            cmd.ExecuteNonQuery();
    ////                            cmd.Dispose();
    ////                        }
    ////                        else
    ////                        {
    ////                            sqlDtReader.Close();
    ////                            cmd.Dispose();
    ////                            CommonClass comCls = new CommonClass("");
    ////                            int bid_dateID = comCls.GetMaxInfo("SELECT MAX(date_id) FROM TenderDatesInfo", 'Y');
    ////                            arrInfo[3] = bid_dateID.ToString();
    ////                            cmd = new SqlCommand("insert into TenderDatesInfo (TenderSubmissionReturnedSerialNumber,eval_tendersubmission_stage,date_id,proj_id,employee_id,co_id) " +
    ////                            "values(@fullSerialNo,@evalTendersubmissionStage,@dateId,@projId,@employeeId,@coId)", sqlConn);
    ////                            cmd.Parameters.AddWithValue("@fullSerialNo", serialNo);
    ////                            cmd.Parameters.AddWithValue("@evalTendersubmissionStage", 2);
    ////                            cmd.Parameters.AddWithValue("@dateId", bid_dateID);
    ////                            cmd.Parameters.AddWithValue("@projId", arrInfo[0]);
    ////                            cmd.Parameters.AddWithValue("@employeeId", arrInfo[10]);
    ////                            cmd.Parameters.AddWithValue("@coId", arrInfo[11]);
    ////                            cmd.ExecuteNonQuery();
    ////                        }
    ////                    }
    ////                }
    ////                else
    ////                {
    ////                    if (arrInfo[13].ToString() != "")
    ////                    {
    ////                        cmd = new SqlCommand("update WorkOrderSubmissions set tenderSubmissionSerialNumber=@fullSerialNo where workOrderSubmissionID=@workOrderSubmissionID", sqlConn);
    ////                        cmd.Parameters.AddWithValue("@fullSerialNo", serialNo);
    ////                        cmd.Parameters.AddWithValue("@workOrderSubmissionID", arrInfo[13].ToString());
    ////                        cmd.ExecuteNonQuery();
    ////                    }
    ////                    else
    ////                    {
    ////                        cmd = new SqlCommand("insert into WorkOrderSubmissions (tenderSubmissionSerialNumber,workOrderID,bidder_id) values(@fullSerialNo,@workOrderID,@bidderId)", sqlConn);
    ////                        cmd.Parameters.AddWithValue("@fullSerialNo", serialNo);
    ////                        cmd.Parameters.AddWithValue("@workOrderID", arrInfo[3].ToString());
    ////                        cmd.Parameters.AddWithValue("@bidderId", arrInfo[12].ToString());
    ////                        cmd.ExecuteNonQuery();

    ////                    }

    ////                }

    ////            }
    ////        }
    ////        catch (Exception ex)
    ////        {
    ////            MessageBox.Show("Exception occurred while updating the serial number in the table", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
    ////        }
    ////    }

    ////    return barcodeImage1;
    ////}

    //private void test()
    //{
    //    using (Neodynamic.SDK.Barcode.BarcodeProfessional bc1 = new Neodynamic.SDK.Barcode.BarcodeProfessional())
    //    {
    //        bc1.Symbology = Neodynamic.SDK.Barcode.Symbology.Code93;
    //        //bc1.CodeTextAlignment = System.Drawing.StringAlignment.Center;
    //        //bc1.CodeLocation = CodeLocation.Above;

    //        string sysDate = System.DateTime.Now.ToString();
    //        bc1.Code = sysDate;

    //        bc1.CodeAlignment = Neodynamic.SDK.Barcode.Alignment.AboveCenter;

    //        bc1.Code = "2015/" + barCodeSerielNo + "/" + cmtName + "/";

    //        bc1.CodeAlignment = Neodynamic.SDK.Barcode.Alignment.AboveJustify;   

    //        bc1.BarcodeUnit = Neodynamic.SDK.Barcode.BarcodeUnit.Inch;
    //        bc1.BarWidth = 0.006; 
    //        bc1.BarHeight = 0.3;               
    //        bc1.GuardBarHeight = bc1.BarHeight + 5 * bc1.BarWidth;                 
    //        bc1.QuietZoneWidth = 9 * bc1.BarWidth;                
    //        iTextSharp.text.Image barcodeImage1 = iTextSharp.text.Image.GetInstance(bc1.GetBarcodeImage(System.Drawing.Imaging.ImageFormat.Png, dpi));                              
    //        barcodeImage1.SetAbsolutePosition(pageWidth - 3.47f * 72f + ((3.25f - (barcodeImage1.Width / dpi)) / 2) * 72f, pageHeight - ((barcodeImage1.Height / dpi) * 72f) - (0.90f * 72f));              
    //        barcodeImage1.ScalePercent(72f / (float)dpi * 100f);              
    //        pdfPage.AddImage(barcodeImage1);
    //    } 
    //}
    private void putBarcode(bool isWorkOrder, SqlConnection sqlConn, string barCodeSerialNo)
    {
        int val2 = 0;
        string strQuery = null;
        val2 = DateTime.Now.Year;
        if (!isWorkOrder)
            strQuery = "INSERT INTO IssueVoucherBarcodesSeq(barcodeNO,barcodeyear) Values('" + barCodeSerialNo + "', " + val2 + ")";
        else
            strQuery = "INSERT INTO IssueVoucherWOBarcodesSeq(barcodeNO,barcodeyear) Values('" + barCodeSerialNo + "', " + val2 + ")";
        SqlCommand cmd = new SqlCommand(strQuery, sqlConn);
        cmd.ExecuteNonQuery();
        //sqlConn.Close();                        
    }

    //private string getPDF_Next(string pdfFile, string pdfFileOut)
    //{
    //    //string pdfFile = @"D:\March.pdf";
    //    //string pdfFileOut = @"D:\May.pdf";



    //    pdfFile = "";
    //    pdfFile = pdfFileOut.Substring(0, (pdfFileOut.Length - 4));
    //    pdfFile = pdfFile + " _" + "OutFile" + ".pdf";

    //    // pdfFile = @"C:\Users\ebsd_svadakapuram\AppData\Local\Temp\Al Jaber and Partners for Construction & Energy Projects (WLL)-MRPSC-001-2014-2015-L_451.pdf";

    //    int dpi = 300;
    //    iTextSharp.text.pdf.PdfReader pdfReader = new iTextSharp.text.pdf.PdfReader(pdfFileOut);
    //    iTextSharp.text.pdf.PdfStamper pdfStamper = new iTextSharp.text.pdf.PdfStamper(pdfReader, new System.IO.FileStream(pdfFile, System.IO.FileMode.Create, System.IO.FileAccess.Write));
    //    iTextSharp.text.pdf.PdfContentByte pdfPage = pdfStamper.GetOverContent(1);
    //    float pageWidth = pdfReader.GetPageSize(1).Width;
    //    float pageHeight = pdfReader.GetPageSize(1).Height;

    //    //4.1. Generate the UPC-A CCB composite barcode. 
    //    using (Neodynamic.SDK.Barcode.BarcodeProfessional bc1 = new Neodynamic.SDK.Barcode.BarcodeProfessional())
    //    {
    //        //set the desired barcode symbology e.g. UPC-A CCB 
    //        bc1.Symbology = Neodynamic.SDK.Barcode.Symbology.Code93;     //  Code93   // UpcACCB
    //        //set the value to encode e.g. Primary Data = 01234567890 and Secondary Data = 991234-abcd 
    //        bc1.Code = "2014/0016620/9";
    //        //set the barcode unit and sizes... 
    //        bc1.BarcodeUnit = Neodynamic.SDK.Barcode.BarcodeUnit.Inch;
    //        bc1.BarWidth = 0.006; //the narrow bar width a.k.a. X value 
    //        bc1.BarHeight = 0.3; //the height of the barcode bars
    //        // bc1.GuardBarHeight = bc1.BarHeight + 5 * bc1.BarWidth; //the height of the guard bars only available for EAN/UPC barcodes 
    //        bc1.GuardBarHeight = bc1.BarHeight + 5 * bc1.BarWidth; //the height of the guard bars only available for EAN/UPC barcodes 
    //        // bc1.QuietZoneWidth = 9 * bc1.BarWidth; //the quiet zone for UPC-A is 9 times the BarWidth value per GS1 spec 
    //        bc1.QuietZoneWidth = 9 * bc1.BarWidth; //the quiet zone for UPC-A is 9 times the BarWidth value per GS1 spec 
    //        //Generate the barcode image content for inserting it into the PDF page   //For high quality, you can generated the barcode at, for instance, 300 dpi 
    //        iTextSharp.text.Image barcodeImage1 = iTextSharp.text.Image.GetInstance(bc1.GetBarcodeImage(System.Drawing.Imaging.ImageFormat.Png, dpi));
    //        //set the position of the barcode image. PDF uses Points as unit (1 point = 1/72 inch)  //the starting point (x=0, y=0) in the PDF coord is the bottom-left corner!!!                 
    //        // barcodeImage1.SetAbsolutePosition(pageWidth - 4.25f * 72f + ((3.25f - (barcodeImage1.Width / dpi)) / 2) * 72f, pageHeight - ((barcodeImage1.Height / dpi) * 72f) - (2.5f * 72f));                
    //        barcodeImage1.SetAbsolutePosition(pageWidth - 3.47f * 72f + ((3.25f - (barcodeImage1.Width / dpi)) / 2) * 72f, pageHeight - ((barcodeImage1.Height / dpi) * 72f) - (6.0399f * 72f));
    //        //scale the image based on the image dpi 
    //        barcodeImage1.ScalePercent(72f / (float)dpi * 100f);
    //        //add the image object to the pdf page 
    //        pdfPage.AddImage(barcodeImage1);

    //        return pdfFile;
    //    }



    //    using (Neodynamic.SDK.Barcode.BarcodeProfessional bc1 = new Neodynamic.SDK.Barcode.BarcodeProfessional())
    //    {
    //        //set the desired barcode symbology e.g. UPC-A CCB 
    //        bc1.Symbology = Neodynamic.SDK.Barcode.Symbology.Code93;     //  Code93   // UpcACCB
    //        //set the value to encode e.g. Primary Data = 01234567890 and Secondary Data = 991234-abcd 
    //        bc1.Code = "2014/0016620/9";
    //        //set the barcode unit and sizes... 
    //        bc1.BarcodeUnit = Neodynamic.SDK.Barcode.BarcodeUnit.Inch;
    //        bc1.BarWidth = 0.006; //the narrow bar width a.k.a. X value 
    //        bc1.BarHeight = 0.3; //the height of the barcode bars
    //        // bc1.GuardBarHeight = bc1.BarHeight + 5 * bc1.BarWidth; //the height of the guard bars only available for EAN/UPC barcodes 
    //        bc1.GuardBarHeight = bc1.BarHeight + 5 * bc1.BarWidth; //the height of the guard bars only available for EAN/UPC barcodes 
    //        // bc1.QuietZoneWidth = 9 * bc1.BarWidth; //the quiet zone for UPC-A is 9 times the BarWidth value per GS1 spec 
    //        bc1.QuietZoneWidth = 9 * bc1.BarWidth; //the quiet zone for UPC-A is 9 times the BarWidth value per GS1 spec 
    //        //Generate the barcode image content for inserting it into the PDF page   //For high quality, you can generated the barcode at, for instance, 300 dpi 
    //        iTextSharp.text.Image barcodeImage1 = iTextSharp.text.Image.GetInstance(bc1.GetBarcodeImage(System.Drawing.Imaging.ImageFormat.Png, dpi));
    //        //set the position of the barcode image. PDF uses Points as unit (1 point = 1/72 inch)  //the starting point (x=0, y=0) in the PDF coord is the bottom-left corner!!!                 
    //        // barcodeImage1.SetAbsolutePosition(pageWidth - 4.25f * 72f + ((3.25f - (barcodeImage1.Width / dpi)) / 2) * 72f, pageHeight - ((barcodeImage1.Height / dpi) * 72f) - (2.5f * 72f));                
    //        barcodeImage1.SetAbsolutePosition(pageWidth - 3.47f * 72f + ((3.25f - (barcodeImage1.Width / dpi)) / 2) * 72f, pageHeight - ((barcodeImage1.Height / dpi) * 72f) - (0.90f * 72f));
    //        //scale the image based on the image dpi 
    //        barcodeImage1.ScalePercent(72f / (float)dpi * 100f);
    //        //add the image object to the pdf page 
    //        pdfPage.AddImage(barcodeImage1);
    //    }        



    //    pdfStamper.Close();
    //    pdfReader.Close();
    //    // MessageBox.Show(pdfFileOut.ToString());

    //    // System.Diagnostics.Process.Start(pdfFileOut);

    //    //System.Diagnostics.Process.Start(pdfFile);
    //}

    //public void RenderImage(string filePath)
    //{
    //   // FileStream fs = File.OpenRead(@"reader.pdf");
    //    FileStream fs = File.OpenRead(filePath);
    //    byte[] data = new byte[fs.Length];
    //    fs.Read(data, 0, (int)fs.Length);

    //    List<System.Drawing.Image> ImgList = new List<System.Drawing.Image>();

    //    iTextSharp.text.pdf.RandomAccessFileOrArray RAFObj = null;
    //    iTextSharp.text.pdf.PdfReader PDFReaderObj = null;
    //    iTextSharp.text.pdf.PdfObject PDFObj = null;
    //    iTextSharp.text.pdf.PdfStream PDFStremObj = null;

    //    try
    //    {
    //        RAFObj = new iTextSharp.text.pdf.RandomAccessFileOrArray(data);
    //        PDFReaderObj = new iTextSharp.text.pdf.PdfReader(RAFObj, null);

    //        for (int i = 0; i <= PDFReaderObj.XrefSize - 1; i++)
    //        {
    //            PDFObj = PDFReaderObj.GetPdfObject(i);

    //            if ((PDFObj != null) && PDFObj.IsStream())
    //            {
    //                PDFStremObj = (iTextSharp.text.pdf.PdfStream)PDFObj;
    //                iTextSharp.text.pdf.PdfObject subtype = PDFStremObj.Get(iTextSharp.text.pdf.PdfName.SUBTYPE);

    //              //  MessageBox.Show(subtype.ToString());

    //                if ((subtype != null) && subtype.ToString() == iTextSharp.text.pdf.PdfName.IMAGE.ToString())
    //                {
    //                    byte[] bytes = iTextSharp.text.pdf.PdfReader.GetStreamBytesRaw((iTextSharp.text.pdf.PRStream)PDFStremObj);

    //                    if ((bytes != null))
    //                    {
    //                        try
    //                        {
    //                            System.IO.MemoryStream MS = new System.IO.MemoryStream(bytes);
    //                            MS.Position = 0;
    //                            System.Drawing.Image ImgPDF = System.Drawing.Image.FromStream(MS);
    //                            ImgList.Add(ImgPDF);
    //                        }
    //                        catch (Exception)
    //                        {
    //                        }
    //                    }
    //                }
    //            }
    //        }

    //        PDFReaderObj.Close();
    //    }
    //    catch (Exception ex)
    //    {
    //        throw new Exception(ex.Message);
    //    }
    //}


    //protected PdfTemplate total;
    //protected BaseFont helv;

    //public void OnEndPage(PdfWriter writer, Document document)
    //{
    //    total = writer.DirectContent.CreateTemplate(100, 100);
    //    total.BoundingBox = new Rectangle(-20, -20, 100, 100);

    //    helv = BaseFont.CreateFont(BaseFont.HELVETICA, BaseFont.WINANSI, BaseFont.NOT_EMBEDDED);

    //    PdfContentByte cb = writer.DirectContent;
    //    cb.SaveState();
    //    string text = "Page " + writer.PageNumber + " of ";
    //    float textBase = document.Bottom - 20;

    //    float textSize = 12; //helv.GetWidthPoint(text, 12);
    //    cb.BeginText();
    //    cb.SetFontAndSize(helv, 12);
    //    if ((writer.PageNumber % 2) == 1)
    //    {
    //        cb.SetTextMatrix(document.Left, textBase);
    //        cb.ShowText(text);
    //        cb.EndText();

    //        // cb.AddTemplate(total, document.Left + textSize, textBase);

    //        float heightPdf = writer.PageSize.Height;
    //        float widthPdf = writer.PageSize.Width;
    //        heightPdf = heightPdf / 2;

    //        cb.AddTemplate(total, heightPdf, textBase);
    //    }
    //    else
    //    {
    //        float adjust = helv.GetWidthPoint("0", 12);
    //        cb.SetTextMatrix(document.Right - textSize - adjust, textBase);
    //        cb.ShowText(text);
    //        cb.EndText();
    //        cb.AddTemplate(total, document.Right - adjust, textBase);
    //    }
    //    cb.RestoreState();
    //}

    public void CreateOutlookEmail(string userFrom, Object pdfFile, string tenderNo)
    {
        try
        {
            Microsoft.Office.Interop.Outlook._Application outlookApp = new Microsoft.Office.Interop.Outlook.Application();
            Microsoft.Office.Interop.Outlook._MailItem mailItem = (Microsoft.Office.Interop.Outlook._MailItem)outlookApp.CreateItem(Microsoft.Office.Interop.Outlook.OlItemType.olMailItem);
            if (pdfFile != null)
            {
                mailItem.Attachments.Add(pdfFile, Microsoft.Office.Interop.Outlook.OlAttachmentType.olEmbeddeditem, 1, Type.Missing);
                mailItem.Display(false);
            }
            else
            {
                string subject = null;
                if (tenderNo.Contains("Tender"))
                    subject = tenderNo;
                else if (tenderNo.Contains("My"))
                    subject = "My Subject";
                else
                    subject = "Tender No.:- " + tenderNo;
                if (userFrom.Contains(","))
                    userFrom = userFrom.Replace(',', ';');
                string tempStr = "mailto:" + userFrom + "?subject={0}";
                string emailTag = string.Format(tempStr, subject);
                System.Diagnostics.Process.Start(emailTag);
            }
        }
        catch (Exception eX)
        {
          /////  MessageBox.Show("Document: Error occurred while trying to Create an Outlook Email, Please Install Microsoft Outlook software or configure it.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }
    //public string chkAccessRightsAndSelectedCompanies(char chChkSubmit, IList<string> userRightsCollParam, string strTenderNo, MaskedTextBox msk_dtp_tsStage1, CheckBox chkLocal, CheckBox chkInternational, CheckBox chkJointVenture)
    //{
    //    string strSelectedCompanies = string.Empty;
    //    if (chChkSubmit != 'V' && chChkSubmit != 'S')
    //    {
    //        if (strTenderNo == "" && chChkSubmit != 'A')
    //        {
    //            MessageBox.Show("Please assign Tender No before issuing Tender");
    //            return "R";
    //        }
    //        if (strTenderNo == "" && chChkSubmit == 'A')
    //        {
    //            MessageBox.Show("Please assign Tender No before Adding to ShortList");
    //            return "R";
    //        }
    //        if (msk_dtp_tsStage1.Text == "" && chChkSubmit != 'A')
    //        {
    //            MessageBox.Show("Closing Date is not yet set.Please enter the closing date before issuing a Tender.");
    //            msk_dtp_tsStage1.Focus();
    //            return "R";
    //        }
    //        if (msk_dtp_tsStage1.Text == "" && chChkSubmit == 'A')
    //        {
    //            MessageBox.Show("Closing Date is not yet set.Please enter the closing date before Adding to ShortList.");
    //            msk_dtp_tsStage1.Focus();
    //            return "R";
    //        }
    //    }
    //    if (chkLocal.Checked == true)
    //    {
    //        strSelectedCompanies = "1";
    //    }
    //    if (chkInternational.Checked == true)
    //    {
    //        if (strSelectedCompanies != "")
    //            strSelectedCompanies = strSelectedCompanies + "," + "2";
    //        else
    //            strSelectedCompanies = "2";
    //    }
    //    if (chkJointVenture.Checked == true)
    //    {
    //        if (strSelectedCompanies != "")
    //            strSelectedCompanies = strSelectedCompanies + "," + "3";
    //        else
    //            strSelectedCompanies = "3";
    //    }
    //    return strSelectedCompanies;
    //}
    //public DataTable LoadCircularOrNonCircularData(int docType, char circularSelected, DataGridView dgViewBidders, int prjID, ComboBox cmbCircularNo, Label lblCircularNo, DataTable dtCircularOrNonCircular, char chFirstRun, char paramCheckShortList)
    //{
    //    string strCon = ConfigurationManager.AppSettings["TCMSConnString"].ToString();
    //    BindingSource myBindingSource = null;
    //    if (dgViewBidders != null)
    //        dgViewBidders.DataSource = null;
    //    SqlCommand sqlCom = new SqlCommand();
    //    try
    //    {
    //        if (dtCircularOrNonCircular != null)
    //            dtCircularOrNonCircular.Rows.Clear();
    //        else
    //        {
    //            dtCircularOrNonCircular = new DataTable("BiddersInfo");
    //            dtCircularOrNonCircular.Columns.Add("");
    //            dtCircularOrNonCircular.Columns.Add("SN");
    //            dtCircularOrNonCircular.Columns.Add("CompanyName");
    //            dtCircularOrNonCircular.Columns.Add("Nationality");
    //            dtCircularOrNonCircular.Columns.Add("DateOfIssue");
    //            dtCircularOrNonCircular.Columns.Add("ReceiptNo");
    //            dtCircularOrNonCircular.Columns.Add("FaxNo");
    //            dtCircularOrNonCircular.Columns.Add("TelNo");
    //            dtCircularOrNonCircular.Columns.Add("MobileNo");
    //            dtCircularOrNonCircular.Columns.Add("EmailAddress");
    //            //Addition By Varun
    //            dtCircularOrNonCircular.Columns.Add("Remarks");
    //            dtCircularOrNonCircular.AcceptChanges();
    //        }

    //        sqlConn = new SqlConnection(strCon);
    //        sqlConn.Open();

    //        StringBuilder strBuild = new StringBuilder();
    //        //Modified by Varun on 21/04/2014 based on change request of modifying the email address of the company and inserting it into TenderDatesInfo table and then retrieving from the same table instead of Company table
    //        // this is only in case of non-short list companies view

    //        if (docType == 2 && dgViewBidders != null && (paramCheckShortList == 'V' || paramCheckShortList == '3') && cmbCircularNo.Items.Count != 0)
    //        {
    //            strBuild.Append("SELECT DISTINCT COMPANY.co_name, COMPANY.nationality, TenderDatesInfo.ts_tender_issue, TenderDatesInfo.ts_receipt_no,COMPANY.co_fax,COMPANY.co_tel,Contacts.MobilePhone," +
    //            " TenderDatesInfo.Company_EmailID, DOCUMENTS.CircularIssued, DOCUMENTS.doc_issue_date,DOCUMENTS.collectionFile,TenderDatesInfo.remarks,TenderDatesInfo.date_id,DOCUMENTS.doc_id,DOCUMENTS.CircularNo,TenderDatesInfo.SN,TenderDatesInfo.proj_id" +
    //            " FROM TenderDatesInfo INNER JOIN COMPANY ON TenderDatesInfo.co_id = COMPANY.co_id LEFT OUTER JOIN Contacts ON TenderDatesInfo.employee_id = Contacts.employee_id LEFT OUTER JOIN " +
    //            "DOCUMENTS ON TenderDatesInfo.date_id = DOCUMENTS.date_id WHERE (TenderDatesInfo.proj_id = " + prjID + ") AND (TenderDatesInfo.stage_id = 2) AND (TenderDatesInfo.ts_tender_issue IS NOT NULL) and " +
    //            "(DOCUMENTS.doc_type_id = 2) and DOCUMENTS.doc_category_id=1 and TenderDatesInfo.Tender_Issued=1 AND (DOCUMENTS.proj_id =" + prjID + ")");

    //            strBuild = PopulateCircularCmb(ref strBuild, ref cmbCircularNo, ref lblCircularNo, prjID, circularSelected);
    //        }

    //        else if (docType == 1 && (paramCheckShortList == 'V'))
    //        {
    //            strBuild.Append("SELECT DISTINCT TenderDatesInfo.SN,COMPANY.co_name, COMPANY.nationality, TenderDatesInfo.ts_tender_issue, TenderDatesInfo.ts_receipt_no,COMPANY.co_fax,COMPANY.co_tel,Contacts.MobilePhone," +
    //            " TenderDatesInfo.Company_EmailID, TenderDatesInfo.remarks,TenderDatesInfo.date_id,TenderDatesInfo.proj_id " +
    //            " FROM TenderDatesInfo INNER JOIN COMPANY ON TenderDatesInfo.co_id = COMPANY.co_id LEFT OUTER JOIN Contacts ON TenderDatesInfo.employee_id = Contacts.employee_id" +
    //            " WHERE (TenderDatesInfo.proj_id = " + prjID + ") AND (TenderDatesInfo.stage_id = 2) and TenderDatesInfo.Tender_Issued=1"); //AND (TenderDatesInfo.ts_tender_issue <> '1/1/1947 12:00:00 AM') order by TenderDatesInfo.SN                   
    //        }
    //        else if (docType == 1 && (paramCheckShortList == '3' || paramCheckShortList == 'S'))
    //        {
    //            strBuild.Append("SELECT DISTINCT TenderDatesInfo.SN,COMPANY.co_name, COMPANY.nationality, TenderDatesInfo.ts_tender_issue, TenderDatesInfo.ts_receipt_no,COMPANY.co_fax,COMPANY.co_tel,Contacts.MobilePhone," +
    //            " COMPANY.co_email_address, TenderDatesInfo.remarks,TenderDatesInfo.date_id,TenderDatesInfo.proj_id " +
    //            " FROM TenderDatesInfo INNER JOIN COMPANY ON TenderDatesInfo.co_id = COMPANY.co_id LEFT OUTER JOIN Contacts ON TenderDatesInfo.employee_id = Contacts.employee_id" +
    //            " WHERE (TenderDatesInfo.proj_id = " + prjID + ") AND (TenderDatesInfo.stage_id = 2) and TenderDatesInfo.Tender_Issued=1"); //AND (TenderDatesInfo.ts_tender_issue <> '1/1/1947 12:00:00 AM')  order by TenderDatesInfo.SN                 
    //        }
    //        else if (docType == 0 && (paramCheckShortList == 'V' || paramCheckShortList == ' '))
    //        {
    //            strBuild.Append("SELECT DISTINCT TenderDatesInfo.SN,COMPANY.co_name, COMPANY.nationality, TenderDatesInfo.ts_tender_issue, TenderDatesInfo.ts_receipt_no,COMPANY.co_fax,COMPANY.co_tel,Contacts.MobilePhone," +
    //             " TenderDatesInfo.Company_EmailID,TenderDatesInfo.remarks " +
    //             " FROM TenderDatesInfo INNER JOIN COMPANY ON TenderDatesInfo.co_id = COMPANY.co_id LEFT OUTER JOIN Contacts ON TenderDatesInfo.employee_id = Contacts.employee_id" +
    //             " WHERE (TenderDatesInfo.proj_id = " + prjID + ") AND (TenderDatesInfo.stage_id = 2) AND (TenderDatesInfo.ts_tender_issue <> '1/1/1947')");// +
    //            //" order by TenderDatesInfo.SN");                    
    //        }
    //        else if (docType == 0 && (paramCheckShortList == 'S' || paramCheckShortList == '3' || paramCheckShortList == 'Y'))
    //        {
    //            strBuild.Append("SELECT DISTINCT TenderDatesInfo.SN,COMPANY.co_name, COMPANY.nationality, TenderDatesInfo.ts_tender_issue, TenderDatesInfo.ts_receipt_no,COMPANY.co_fax,COMPANY.co_tel,Contacts.MobilePhone," +
    //             " TenderDatesInfo.Company_EmailID,TenderDatesInfo.remarks " +
    //             " FROM TenderDatesInfo INNER JOIN COMPANY ON TenderDatesInfo.co_id = COMPANY.co_id LEFT OUTER JOIN Contacts ON TenderDatesInfo.employee_id = Contacts.employee_id" +
    //             " WHERE (TenderDatesInfo.proj_id = " + prjID + ") AND (TenderDatesInfo.stage_id = 2) AND (TenderDatesInfo.ts_tender_issue <> '1/1/1947')");
    //            //order by TenderDatesInfo.SN
    //        }
    //        else if (docType == 3 && (paramCheckShortList == 'S')) //||paramCheckShortList == '3'
    //        {
    //            strBuild.Append("SELECT DISTINCT TenderDatesInfo.SN,COMPANY.co_name,COMPANY.nationality,COMPANY.co_tel,Contacts.MobilePhone,COMPANY.co_email_address,TenderDatesInfo.Tender_Issued,TenderDatesInfo.ts_tender_issue,TenderDatesInfo.ts_receipt_no," +
    //            " TenderDatesInfo.remarks,TenderDatesInfo.date_id,TenderDatesInfo.proj_id" +
    //            " FROM TenderDatesInfo INNER JOIN COMPANY ON TenderDatesInfo.co_id = COMPANY.co_id INNER JOIN Contacts ON TenderDatesInfo.employee_id = Contacts.employee_id" +
    //            " LEFT OUTER JOIN DOCUMENTS ON TenderDatesInfo.date_id = DOCUMENTS.date_id WHERE (TenderDatesInfo.proj_id = " + prjID + ") AND (TenderDatesInfo.stage_id = 2) and" +
    //            " (COMPANY.co_name IS NOT NULL)");  //order by TenderDatesInfo.SN
    //        }

    //        if (strBuild.Length != 0)
    //        {
    //            //DataView dvViewBidders = dalObj.GetDataFromDB("ViewBidders", strBuild.ToString()).DefaultView;
    //            DataTable dtViewBidders = dalObj.GetDataFromDB("ViewBidders", strBuild.ToString());
    //            dtViewBidders.DefaultView.Sort = "SN";

    //            foreach (DataRow drVB in dtViewBidders.Rows)
    //            {
    //                DataRow dr = dtCircularOrNonCircular.NewRow();
    //                if (docType == 2)
    //                {
    //                    dr[1] = drVB[15].ToString();   //sn
    //                    dr[2] = drVB[0].ToString();   //co_name
    //                    dr[3] = drVB[1].ToString();   //nationality 
    //                    if (drVB[2].ToString() != "")
    //                    {
    //                        dr[4] = Convert.ToDateTime(drVB[2]).ToString("dd/MMM/yyyy");         //ts_tender_issue
    //                    }
    //                    dr[5] = drVB[3].ToString();   //ts_receipt_no
    //                    dr[6] = drVB[4].ToString();   //co_fax
    //                    dr[7] = drVB[5].ToString();   //co_tel
    //                    dr[8] = drVB[6].ToString();   //MobilePhone                                 
    //                    dr[9] = drVB[7].ToString().Replace(";", "; ");   //co_email_address                                     
    //                    dr[10] = drVB[8];   //CircularIssued
    //                    if (drVB[9] != DBNull.Value)
    //                        dr[11] = Convert.ToDateTime(drVB[9]).ToString("dd/MMM/yyyy"); //DocIssueDate .ToString("dd-MMM-yyyy") Convert.ToDateTime(
    //                    dr[12] = drVB[10];   //CollectionFile
    //                    dr[13] = drVB[11].ToString();   //remarks          
    //                    dr[14] = drVB[12].ToString();   //date_id                                   
    //                    dr[15] = drVB[13].ToString();   //doc_id  
    //                    dr[16] = drVB[14].ToString();   //circularno  
    //                    dr[17] = drVB[16].ToString();   //proj_id   
    //                }
    //                else if (docType == 1 || docType == 0)
    //                {
    //                    dr[1] = drVB[0].ToString();   //SN
    //                    dr[2] = drVB[1].ToString();   //co_name
    //                    dr[3] = drVB[2].ToString();   //nationality 
    //                    if (drVB[3].ToString() != "")
    //                    {
    //                        dr[4] = Convert.ToDateTime(drVB[3]).ToString("dd/MMM/yyyy");         //ts_tender_issue
    //                    }
    //                    dr[5] = drVB[4].ToString();   //ts_receipt_no
    //                    dr[6] = drVB[5].ToString();   //co_fax
    //                    dr[7] = drVB[6].ToString();   //co_tel
    //                    dr[8] = drVB[7].ToString();   //MobilePhone
    //                    dr[9] = drVB[8].ToString().Replace(";", "; ");   //co_email_address                         
    //                    dr[10] = drVB[9].ToString();   //remarks                                   
    //                    if (docType == 1)
    //                    {
    //                        dr[11] = drVB[10].ToString();   //date_id                                   
    //                        dr[12] = drVB[11].ToString();   //proj_id                                                        
    //                        if (lblCircularNo != null)
    //                        {
    //                            lblCircularNo.Visible = false;
    //                            cmbCircularNo.Visible = false;
    //                        }
    //                    }
    //                }
    //                else
    //                {
    //                    dr = populateDataGridView(ref dr, drVB);
    //                }
    //                if (docType == 3)
    //                {
    //                    if (dr[11] != System.DBNull.Value || dr[11].ToString() != "")
    //                    {
    //                        dtCircularOrNonCircular.Rows.Add(dr);
    //                        dtCircularOrNonCircular.AcceptChanges();
    //                    }
    //                }
    //                else
    //                {
    //                    dtCircularOrNonCircular.Rows.Add(dr);
    //                    dtCircularOrNonCircular.AcceptChanges();
    //                }
    //            }

    //        }

    //        if (dgViewBidders != null && docType == 2)
    //        {
    //            myBindingSource = new BindingSource(dtCircularOrNonCircular, null);
    //            dgViewBidders.DataSource = myBindingSource;
    //            dgViewBidders.Columns[14].Visible = false;
    //            dgViewBidders.Columns[15].Visible = false;
    //            dgViewBidders.Columns[16].Visible = false;
    //            dgViewBidders.Columns[17].Visible = false;
    //        }
    //        else if (docType == 1 || docType == 3)
    //        {
    //            myBindingSource = new BindingSource(dtCircularOrNonCircular, null);
    //            dgViewBidders.DataSource = myBindingSource;
    //            dgViewBidders.Columns[11].Visible = false;
    //            dgViewBidders.Columns[12].Visible = false;
    //        }
    //    }
    //    catch (Exception ex)
    //    {
    //        MessageBox.Show("Error Occurred while Re-Populating the Bidders Informations" + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
    //    }
    //    finally
    //    {
    //        sqlConn.Close();
    //    }
    //    return dtCircularOrNonCircular;
    //}

    private DataRow populateDataGridView(ref DataRow dr, DataRow drVB)
    {
        dr[1] = drVB[0].ToString();   //SN
        dr[2] = drVB[1].ToString();   //co_name
        dr[3] = drVB[2].ToString();   //nationality 
        dr[4] = drVB[3].ToString();   //co_tel
        dr[5] = drVB[4].ToString();   //MobilePhone
        dr[6] = drVB[5].ToString().Replace(";", "; ");   //co_email_address                                      
        dr[7] = drVB[6];
        if (drVB[7].ToString() != "" && !((drVB[7].ToString().Contains("1947")) || (drVB[7].ToString().Contains("01/Jan/47")) || (drVB[7].ToString().Contains("01-Jan-47")) || (drVB[7].ToString().Contains("01/01/47")))) // Added by Varun the date should not be equal to 1/1/1947 12:00:00 AM hardcoded                       
            dr[8] = Convert.ToDateTime(drVB[7]).ToString("dd/MMM/yyyy");         //ts_tender_issue
        dr[9] = drVB[8].ToString();   //receipt_no
        dr[10] = drVB[9].ToString();   //remarks                         
        dr[11] = drVB[10].ToString();   //date_id
        dr[12] = drVB[11].ToString();   //proj_id             
        return dr;
    }
    //private StringBuilder PopulateCircularCmb(ref StringBuilder paramStrBuild, ref ComboBox paramCmbCircularNo, ref Label paramLblCircularNo, int paramProjId, char paramCircularSelected)
    //{
    //    if (paramCircularSelected == 'N') //&& (paramCmbCircularNo.Items[paramCmbCircularNo.Items.Count - 1].ToString() != "0")
    //    {
    //        paramCmbCircularNo.SelectedIndex = paramCmbCircularNo.Items.Count - 1;
    //        paramStrBuild.Append(" and DOCUMENTS.CircularNo =" + paramCmbCircularNo.Items[paramCmbCircularNo.SelectedIndex]); //+ " order by TenderDatesInfo.SN"       
    //    }
    //    else if (paramCircularSelected == 'Y') //&& (paramCmbCircularNo.Items[paramCmbCircularNo.Items.Count - 1].ToString() != "0")                            
    //        paramStrBuild.Append(" and DOCUMENTS.CircularNo =" + paramCmbCircularNo.Items[paramCmbCircularNo.SelectedIndex]); //+ " order by TenderDatesInfo.SN"                        
    //    else
    //    {
    //        paramStrBuild.Remove(0, paramStrBuild.Length);
    //        //paramStrBuild.Append("No Circulars");
    //    }

    //    return paramStrBuild;
    //}

    //Added By Varun

    public void InsertRecordsInDocumentsTable(int projId, SqlCommand cmd, int maxDateID, SqlConnection sqlConn, CommonClass comCls, Int16 compID, Int16 empID)
    {
        Int16 docLoopCtr = 0;
        int maxDocId = 0;
        int totRowDocs = 0;
        int exUpdated = 0;
        DAL dalObj = new DAL("");

        DataTable dtDocuments = dalObj.GetDataFromDB("CircularDocs", "select doc_type_id, stage_id, doc_status_id,ref_no,cross_ref_no,doc_date,doc_issue_date,days_to_act,subject,CircularNo from DOCUMENTS " +
        " where proj_id=" + projId + " AND (date_id IS NULL) AND (CircularNo IS NOT NULL) and stage_id=2 ORDER BY doc_id");
        totRowDocs = dtDocuments.Rows.Count;

        if (totRowDocs != 0)
        {
            maxDocId = comCls.GetMaxInfo("SELECT MAX(doc_id) FROM DOCUMENTS", 'Y');
            while (docLoopCtr < totRowDocs)
            {
                cmd.Connection = sqlConn;
                comCls.insertStatement(cmd, maxDocId, maxDateID, Convert.ToInt32(dtDocuments.Rows[docLoopCtr][0]), projId, Convert.ToInt32(dtDocuments.Rows[docLoopCtr][1]), Convert.ToInt16(dtDocuments.Rows[docLoopCtr][2]), dtDocuments.Rows[docLoopCtr][3].ToString(), dtDocuments.Rows[docLoopCtr][4].ToString(), empID, dtDocuments.Rows[docLoopCtr][5].ToString(), dtDocuments.Rows[docLoopCtr][6].ToString(), null, dtDocuments.Rows[docLoopCtr][6].ToString(), dtDocuments.Rows[docLoopCtr][7].ToString(), dtDocuments.Rows[docLoopCtr][8].ToString(), compID, Convert.ToInt16(dtDocuments.Rows[docLoopCtr][9]), 'C');
                exUpdated = cmd.ExecuteNonQuery();
                cmd.Parameters.Clear();
                if ((docLoopCtr + 1) != totRowDocs)
                {
                    maxDocId++;
                }

                docLoopCtr++;
            }
        }
    }

    public void ReNumberSNCol(int projID, string strConnParam, char chParamCheckShortList)
    {
        DAL dalObj = new DAL("");
        string strQuery = null;
        if (chParamCheckShortList == 'S')
            strQuery = "select date_id from TenderDatesInfo where proj_id=" + projID + " and (SN IS NOT NULL) ORDER BY SN";
        else if (chParamCheckShortList == '3')
            strQuery = "select date_id from TenderDatesInfo where proj_id=" + projID + " and Tender_Issued=1 AND (SN IS NOT NULL) ORDER BY SN";
        if (chParamCheckShortList == 'V')
            strQuery = "select date_id from TenderDatesInfo where proj_id=" + projID + " and (SN IS NOT NULL) ORDER BY SN";
        DataTable dtTenderInfo = dalObj.GetDataFromDB("TenderDatesInfo", strQuery);
        int totRowCount = dtTenderInfo.Rows.Count;
        int tenderLoopCtr = 0;
        using (SqlConnection sqlConn = new SqlConnection(strConnParam))
        {
            sqlConn.Open();
            while (tenderLoopCtr < totRowCount)
            {
                using (SqlCommand sqlCom = new SqlCommand("Update TenderDatesInfo set SN = " + (tenderLoopCtr + 1) + " where Date_ID =" + Convert.ToInt32(dtTenderInfo.Rows[tenderLoopCtr][0]), sqlConn))
                {
                    sqlCom.ExecuteNonQuery();
                    sqlCom.Dispose();
                }
                tenderLoopCtr++;
            }
            sqlConn.Close();
        }

    }
    //public class PageEventHelper : PdfPageEventHelper
    //{
    //    PdfTemplate pageNoTemplate;
    //    PdfTemplate textTemplate1;
    //    PdfTemplate textTemplate2;
    //    protected BaseFont bf;
    //    protected BaseFont bArabicFont;
    //    Font arabicNormalBlackFont;
    //    private char chReceipt = ' ';
    //    public char CheckReceipt
    //    {
    //        set { chReceipt = value; }
    //        get { return chReceipt; }
    //    }
    //    public char CheckTypePDF
    //    {
    //        set { chReceipt = value; }
    //        get { return chReceipt; }
    //    }

    //    private string typeOfDoc = "";
    //    public string TypeOfDoc
    //    {
    //        set { typeOfDoc = value; }
    //        get { return typeOfDoc; }
    //    }

    //    //public override void OnStartPage(PdfWriter writer, Document document)
    //    //{
    //    //    try
    //    //    {
    //    //        PdfContentByte cb = writer.DirectContentUnder;
    //    //        //BaseFont baseFont = BaseFont.CreateFont(BaseFont.TIMES_ROMAN, BaseFont.WINANSI, BaseFont.EMBEDDED);
    //    //        cb.BeginText();
    //    //        cb.SetColorFill(BaseColor.LIGHT_GRAY);

    //    //        PdfGState gState = new PdfGState();
    //    //        gState.FillOpacity = 0.25f;
    //    //        gState.StrokeOpacity = 0.25f;
    //    //        cb.SetGState(gState);
    //    //        //iTextSharp.text.Rectangle pageSize = document.PageSize;
    //    //        if (CheckReceipt == 'I' || CheckReceipt == 'T')
    //    //        {
    //    //            Font pdfWaterMarkArialFont = new Font(BaseFont.CreateFont("c:/windows/fonts/arial.ttf", BaseFont.IDENTITY_H, BaseFont.EMBEDDED), 70);
    //    //            pdfWaterMarkArialFont.Color = CMYKColor.DARK_GRAY;
    //    //            cb.SetFontAndSize(pdfWaterMarkArialFont.BaseFont, 50f);

    //    //            if (typeOfDoc == "Original" || typeOfDoc == "Issue Voucher")
    //    //                ColumnText.ShowTextAligned(writer.DirectContentUnder, Element.ALIGN_CENTER, new Phrase("Original", pdfWaterMarkArialFont), 300, 600, 45);

    //    //            else if (typeOfDoc == "Copy" || typeOfDoc == "Print_File_Copy")
    //    //                ColumnText.ShowTextAligned(writer.DirectContentUnder, Element.ALIGN_CENTER, new Phrase("File Copy", pdfWaterMarkArialFont), 300, 600, 45);
    //    //        }
    //    //        else if (CheckReceipt == 'O') //O means other (View Report) or (View Short List) or (Export To Pdf)
    //    //        {
    //    //            Font pdfWaterMarkArialFont = new Font(BaseFont.CreateFont("c:/windows/fonts/arial.ttf", BaseFont.IDENTITY_H, BaseFont.EMBEDDED), 70);
    //    //            pdfWaterMarkArialFont.Color = CMYKColor.DARK_GRAY;
    //    //            cb.SetFontAndSize(pdfWaterMarkArialFont.BaseFont, 50f);
    //    //            ColumnText.ShowTextAligned(writer.DirectContentUnder, Element.ALIGN_CENTER, new Phrase("Confidential", pdfWaterMarkArialFont), 300, 350, 45);
    //    //        }
    //    //        //else Commented by Varun on 3 Jun 15 not required
    //    //        //{
    //    //        //    pdfWaterMarkArialFont = new Font(BaseFont.CreateFont("c:/windows/fonts/arial.ttf", BaseFont.IDENTITY_H, BaseFont.EMBEDDED), 80);
    //    //        //    ColumnText.ShowTextAligned(writer.DirectContentUnder, Element.ALIGN_CENTER, new Phrase("Original", pdfWaterMarkArialFont), pageSize.Width / 2, pageSize.Height / 2, 45); //fWidth, pageSize.Bottom + (document.TopMargin / 2)
    //    //        //}

    //    //        //if (typeOfDoc == "Original")
    //    //        //    ColumnText.ShowTextAligned(writer.DirectContentUnder, Element.ALIGN_CENTER, new Phrase("Original", pdfWaterMarkArialFont), pageSize.Width / 2, pageSize.Height / 2, 0); //fWidth, pageSize.Bottom + (document.TopMargin / 2)
    //    //        //else if (typeOfDoc == "Copy")
    //    //        //    ColumnText.ShowTextAligned(writer.DirectContentUnder, Element.ALIGN_CENTER, new Phrase("File Copy", pdfWaterMarkArialFont), pageSize.Width / 4, pageSize.Height / 4, 45);

    //    //        cb.EndText();

    //    //    }
    //    //    catch (DocumentException docEx)
    //    //    {
    //    //        throw docEx;
    //    //    }
    //    //}

    //    //public override void OnOpenDocument(PdfWriter writer, Document document)
    //    //{
    //    //    if (chReceipt == 'O')
    //    //    {
    //    //        pageNoTemplate = writer.DirectContent.CreateTemplate(100, 100);
    //    //        pageNoTemplate.BoundingBox = new iTextSharp.text.Rectangle(-20, -20, 100, 100);
    //    //        textTemplate1 = writer.DirectContent.CreateTemplate(100, 100);
    //    //        textTemplate1.BoundingBox = new iTextSharp.text.Rectangle(-20, -20, 100, 100);
    //    //        textTemplate2 = writer.DirectContent.CreateTemplate(100, 100);
    //    //        textTemplate2.BoundingBox = new iTextSharp.text.Rectangle(-20, -20, 100, 100);
    //    //    }
    //    //    if (chReceipt == 'I' || chReceipt == 'T')
    //    //    {
    //    //        textTemplate1 = writer.DirectContent.CreateTemplate(100, 100);
    //    //        textTemplate1.BoundingBox = new iTextSharp.text.Rectangle(-20, -20, 100, 100);
    //    //        textTemplate2 = writer.DirectContent.CreateTemplate(100, 100);
    //    //        textTemplate2.BoundingBox = new iTextSharp.text.Rectangle(-20, -20, 100, 100);
    //    //    }

    //    //    bf = BaseFont.CreateFont("c:/windows/fonts/arial.ttf", BaseFont.CP1252, BaseFont.EMBEDDED);
    //    //    bArabicFont = BaseFont.CreateFont(@"C:\Windows\Fonts\arialuni.ttf", BaseFont.IDENTITY_H, BaseFont.EMBEDDED);
    //    //    arabicNormalBlackFont = new Font(bArabicFont, 12, Font.NORMAL, BaseColor.BLACK);

    //    //}

    //    //public override void OnEndPage(PdfWriter writer, Document document)
    //    //{
    //    //    //base.OnEndPage(writer, document);

    //    //    if (chReceipt == 'O')
    //    //    {
    //    //        try
    //    //        {
    //    //            float[] colWidth = new float[1];
    //    //            colWidth[0] = 500f;

    //    //            PdfPTable footerTable = new PdfPTable(1);
    //    //            footerTable.SetTotalWidth(colWidth);
    //    //            footerTable.DefaultCell.Border = 0;
    //    //            footerTable.WidthPercentage = 100;

    //    //            BaseFont bfArial = BaseFont.CreateFont(@"C:\Windows\Fonts\arial.ttf", BaseFont.IDENTITY_H, BaseFont.EMBEDDED);
    //    //            iTextSharp.text.Font plainText_9 = new iTextSharp.text.Font(bfArial, 9f);
    //    //            iTextSharp.text.Font plainText_8 = new iTextSharp.text.Font(bfArial, 8f);
    //    //            iTextSharp.text.Font digitFont_6 = new iTextSharp.text.Font(bfArial, 6f, iTextSharp.text.Font.NORMAL, iTextSharp.text.BaseColor.BLUE);

    //    //            var text = " إدارة العقود، هيئة الأشغال العامة، هاتف: 0077 4495 974+ ، فاكس: 0780 4495 974+ ، ص. ب.: 22188 الدوحة – قطر ";
    //    //            PdfPCell cellNew = new PdfPCell(new Phrase(text, plainText_9));
    //    //            cellNew.Border = 0;
    //    //            cellNew.RunDirection = PdfWriter.RUN_DIRECTION_RTL;
    //    //            cellNew.HorizontalAlignment = PdfPCell.ALIGN_CENTER;
    //    //            cellNew.VerticalAlignment = iTextSharp.text.Element.ALIGN_CENTER;
    //    //            footerTable.AddCell(cellNew);

    //    //            text = "Contracts Department, Public Works Authority Tel : + 97444950077,Fax : + 974 4495 0780,P.O Box 22188, Doha - Qatar";
    //    //            cellNew = new PdfPCell(new Phrase(text, plainText_8));
    //    //            cellNew.Border = 0;
    //    //            cellNew.RunDirection = PdfWriter.RUN_DIRECTION_RTL;
    //    //            cellNew.HorizontalAlignment = PdfPCell.ALIGN_CENTER;
    //    //            cellNew.VerticalAlignment = iTextSharp.text.Element.ALIGN_CENTER;
    //    //            footerTable.AddCell(cellNew);

    //    //            text = "www.ashghal.gov.qa";
    //    //            cellNew = new PdfPCell(new Phrase(text, digitFont_6));
    //    //            cellNew.Border = 0;
    //    //            cellNew.RunDirection = PdfWriter.RUN_DIRECTION_RTL;
    //    //            cellNew.HorizontalAlignment = PdfPCell.ALIGN_CENTER;
    //    //            cellNew.VerticalAlignment = iTextSharp.text.Element.ALIGN_CENTER;
    //    //            footerTable.AddCell(cellNew);
    //    //            footerTable.WriteSelectedRows(0, -1, 40, footerTable.TotalHeight + 10, writer.DirectContent);

    //    //        }
    //    //        catch (DocumentException de)
    //    //        {
    //    //            throw de;
    //    //        }

    //    //        PdfContentByte cb = writer.DirectContent;
    //    //        int pageN = writer.PageNumber;
    //    //        string text1 = "Page " + pageN + " of ";
    //    //        float len = bf.GetWidthPoint(text1, 9);

    //    //        iTextSharp.text.Rectangle pageSize = document.PageSize;

    //    //        cb.BeginText();
    //    //        cb.SetFontAndSize(bf, 9);
    //    //        cb.SetTextMatrix(pageSize.GetRight(70), pageSize.GetBottom(30));
    //    //        cb.ShowText(text1);
    //    //        cb.EndText();

    //    //        cb.AddTemplate(pageNoTemplate, pageSize.GetRight(70) + len, pageSize.GetBottom(30));

    //    //        cb.BeginText();
    //    //        cb.SetFontAndSize(bf, 9);
    //    //        cb.ShowTextAligned(PdfContentByte.ALIGN_RIGHT,
    //    //            "",
    //    //            pageSize.GetRight(70),
    //    //            pageSize.GetBottom(30), 0);
    //    //        cb.EndText();
    //    //    }
    //    //}
    //    //public override void OnCloseDocument(PdfWriter writer, Document document)
    //    //{
    //    //    if (chReceipt == 'O')
    //    //    {
    //    //        pageNoTemplate.BeginText();
    //    //        pageNoTemplate.SetFontAndSize(bf, 9);
    //    //        pageNoTemplate.SetTextMatrix(0, 0);
    //    //        pageNoTemplate.ShowText("" + (writer.PageNumber - 1));
    //    //        pageNoTemplate.EndText();
    //    //    }
    //    //}
    //}
    public void AlertOnNewTenderNo(string tenderNo, string projCode, string projTitle)
    {
        MailMessage mailMessage = new MailMessage();
        mailMessage.From = new MailAddress(ConfigurationManager.AppSettings["MailFrom"].ToString());
        mailMessage.To.Add(new MailAddress(ConfigurationManager.AppSettings["MailTo"].ToString()));

        mailMessage.Subject = "TCMS Alert: Tender No. " + tenderNo + " was assigned";
        mailMessage.Body = "This is an automated alert from Tender & Contract Management System." + "\n" +
        "\n" +
        "Project Code: " + projCode + "\n" +
        "Project Title: " + projTitle + "\n" +
        "\n" +
        "Tender No. " + tenderNo + " was assigned to above project.";

        SmtpClient client = new SmtpClient();
        client.Host = ConfigurationManager.AppSettings["SmtpHostIP"].ToString();
        client.Port = Convert.ToInt32(ConfigurationManager.AppSettings["SmtpHostPort"]);
        client.Send(mailMessage);
    }

    public void AlertOnTransferTenderNoToAnotherTenderCommittee(string prevTenderNo, string newTenderNo, string projCode, string projTitle, string oldComtyName, string newComtyName)
    {
        MailMessage mailMessage = new MailMessage();

        mailMessage.From = new MailAddress(ConfigurationManager.AppSettings["MailFrom"].ToString());
        mailMessage.To.Add(new MailAddress(ConfigurationManager.AppSettings["MailTo"].ToString()));

        mailMessage.Subject = "TCMS Alert: Transfer of Tender from " + oldComtyName + " to " + newComtyName;
        mailMessage.Body = "This is an automated alert from Tender & Contract Management System." + "\n" +
        "\n" +
        "Project Code: " + projCode.ToString() + "\n" +
        "Project Title: " + projTitle + "\n" +
        "\n" +
        "The above Project was formerly assigned to " + oldComtyName + " with assigned Tender No. " + prevTenderNo + " is now being transferred to " + newComtyName + " with assigned Tender No. " + "\n" +
        newTenderNo;

        SmtpClient client = new SmtpClient();
        client.Host = ConfigurationManager.AppSettings["SmtpHostIP"].ToString();
        client.Port = Convert.ToInt32(ConfigurationManager.AppSettings["SmtpHostPort"]);
        client.Send(mailMessage);
    }
    char _save;
    public char chkSave
    {
        get
        {
            return this._save;
        }
        set
        {
            this._save = value;
        }
    }

    public DataTable GetDataTable(string sqlQuery, SqlConnection sqlConn)
    {
        DataTable dtWorkOrders = null;
        DataSet ds = new DataSet();
        try
        {
            SqlDataAdapter da = new SqlDataAdapter(sqlQuery, sqlConn);
            da.Fill(ds);
            dtWorkOrders = ds.Tables[0];
        }
        catch (Exception ex)
        {

        }
        return dtWorkOrders;
    }

    public DataSet FillData(string cmdText)
    {
        DataSet ds = new DataSet();
        try
        {
            using (SqlConnection sqlConn = new SqlConnection(connStr))
            {
                using (SqlDataAdapter da = new SqlDataAdapter(cmdText, sqlConn))
                    da.Fill(ds);
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
        return ds;
    }
    public void insertToDB(string str)
    {
        using (SqlConnection sqlConn = new SqlConnection(connStr))
        {
            SqlCommand cmd = new SqlCommand(str, sqlConn);
            sqlConn.Open();
            cmd.ExecuteNonQuery();
        }
    }
    public Int16 maxValue(string str)
    {
        object max;
        using (SqlConnection sqlConn = new SqlConnection(connStr))
        {
            SqlCommand cmd = new SqlCommand(str, sqlConn);
            sqlConn.Open();
            max = cmd.ExecuteScalar();
        }
        return Convert.ToInt16(max);
    }
    private void InsertData_TenderStage()
    {
        using (SqlConnection sqlConn = new SqlConnection(connStr))
        {

        }
    }
    //public void FillGridReceivedDocsInfo(int prjId, DataGridView dgGrid, int stageID)
    //{
    //    try
    //    {
    //        DataTable finalDt = new DataTable("ReceivedDoc");
    //        finalDt.Columns.Add("FileName");
    //        finalDt.Columns.Add("ReferenceNo");
    //        finalDt.Columns.Add("Status");
    //        finalDt.Columns.Add("DocId");
    //        finalDt.AcceptChanges();
    //        //using (SqlConnection sqlConn = new SqlConnection(connStr))
    //        //{
    //        //    sqlConn.Open();
    //        string sqlDocQuery = "SELECT distinct replace(attFileName,',','') As [FileName], ref_no As [ReferenceNo],doc_status_id, " +
    //        "doc_id,create_date FROM DOCUMENTS WHERE (doc_category_id = 2) AND (proj_id = " + prjId + ") AND (stage_id = " + stageID + ")"; //doc_category_id = 2 is Received
    //        DataTable docDt = dalObj.GetDataFromDB("DOCUMENTS", sqlDocQuery);

    //        string sqlDocStatQuery = "SELECT doc_status_id,doc_status_name As [Status] from DocumentStatus";
    //        DataTable docStatDt = dalObj.GetDataFromDB("DocumentStatus", sqlDocStatQuery);

    //        IEnumerable<object> iEnum = null;
    //        iEnum = (from doc in docDt.AsEnumerable()
    //                 join docStatus in docStatDt.AsEnumerable() on doc.Field<int>("doc_status_id") equals docStatus.Field<int>("doc_status_id")
    //                 select new
    //                 {
    //                     DocId = doc.Field<int>("doc_id"),
    //                     FileName = doc.Field<string>("FileName"),
    //                     ReferenceNo = doc.Field<string>("ReferenceNo"),
    //                     Status = docStatus.Field<string>("Status"),
    //                     create_date = doc.Field<DateTime?>("create_date"),
    //                 }).OrderByDescending(item => item.create_date).ToList(); // AsEnumerable();//.ToList();


    //        int rowId = 1;
    //        foreach (object doc in iEnum)
    //        {
    //            DataRow dr = finalDt.NewRow();

    //            dr[3] = doc.ToString().Split(',')[0].Split('=')[1].Trim();  //doc_id
    //            //dr[1] = doc.ToString().Split(',')[1].Split('=')[1].Trim();  //CircularNo
    //            dr[0] = doc.ToString().Split(',')[1].Split('=')[1].Trim();  //FileName                   

    //            dr[1] = doc.ToString().Split(',')[2].Split('=')[1].Trim();  //ReferenceNo
    //            dr[2] = doc.ToString().Split(',')[3].Split('=')[1].Trim();  //StatusName                                                  

    //            rowId++;
    //            finalDt.Rows.Add(dr);
    //            finalDt.AcceptChanges();
    //        }

    //        if (finalDt.Rows.Count != 0)
    //        {
    //            BindingSource myBindingSource = new BindingSource(finalDt, null);
    //            dgGrid.DataSource = myBindingSource;
    //            dgGrid.Columns[3].Visible = false;
    //        }
    //        else
    //            dgGrid.DataSource = null;
    //        //    sqlConn.Close();
    //        //}
    //    }
    //    catch (Exception ex)
    //    {
    //        MessageBox.Show("Error occurred while retrieving the Received documents");
    //    }

    //}


    //public void FillGridSentDocsInfo(int prjId, DataGridView dgGrid, int stageID)
    //{
    //    try
    //    {
    //        DataTable finalDt = new DataTable("SentDocs");
    //        finalDt.Columns.Add("DocId");
    //        finalDt.Columns.Add("CircularNo");
    //        finalDt.Columns.Add("FileName");
    //        finalDt.Columns.Add("ReferenceNo");
    //        finalDt.Columns.Add("Status");
    //        finalDt.AcceptChanges();
    //        //using (SqlConnection sqlConn = new SqlConnection(connStr))
    //        //{
    //        //    sqlConn.Open();

    //        string sqlDocQuery = "SELECT distinct docs.doc_id,docs.CircularNo,replace(docs.attFileName,',','') As [FileName],docs.ref_no As [ReferenceNo]," +
    //        "docs.create_date,doc_status_id FROM DOCUMENTS docs where docs.proj_id = " + prjId + " AND docs.stage_id = " + stageID + " and docs.date_id is null and doc_category_id=1"; //SentDocs category is 1
    //        DataTable docDt = dalObj.GetDataFromDB("DOCUMENTS", sqlDocQuery);

    //        string sqlDocStatQuery = "SELECT doc_status_id,doc_status_name As [Status] from DocumentStatus";
    //        DataTable docStatDt = dalObj.GetDataFromDB("DocumentStatus", sqlDocStatQuery);

    //        IEnumerable<object> iEnum = null;
    //        iEnum = (from doc in docDt.AsEnumerable()
    //                 join docStatus in docStatDt.AsEnumerable() on doc.Field<int>("doc_status_id") equals docStatus.Field<int>("doc_status_id")
    //                 select new
    //                 {
    //                     DocId = doc.Field<int>("doc_id"),
    //                     CircularNo = doc.Field<int?>("CircularNo"),
    //                     FileName = doc.Field<string>("FileName"),
    //                     ReferenceNo = doc.Field<string>("ReferenceNo"),
    //                     Status = docStatus.Field<string>("Status"),
    //                     create_date = doc.Field<DateTime?>("create_date"),
    //                 }).OrderByDescending(item => item.create_date).ToList(); // AsEnumerable();//.ToList();


    //        int rowId = 1;
    //        foreach (object doc in iEnum)
    //        {
    //            DataRow dr = finalDt.NewRow();

    //            dr[0] = doc.ToString().Split(',')[0].Split('=')[1].Trim();  //doc_id                         
    //            dr[1] = doc.ToString().Split(',')[1].Split('=')[1].Trim();  //CircularNo                         
    //            dr[2] = doc.ToString().Split(',')[2].Split('=')[1].Trim();  //FileName                   
    //            dr[3] = doc.ToString().Split(',')[3].Split('=')[1].Trim();  //ReferenceNo
    //            dr[4] = doc.ToString().Split(',')[4].Split('=')[1].Trim();  //StatusName                                                  

    //            rowId++;
    //            finalDt.Rows.Add(dr);
    //            finalDt.AcceptChanges();
    //        }

    //        if (finalDt.Rows.Count != 0)
    //        {
    //            BindingSource myBindingSource = new BindingSource(finalDt, null);
    //            dgGrid.DataSource = myBindingSource;
    //            dgGrid.Columns[0].Visible = false;
    //            dgGrid.Columns[1].Visible = false;
    //        }
    //        else
    //            dgGrid.DataSource = null;
    //        //    sqlConn.Close();
    //        //}
    //    }
    //    catch (Exception ex)
    //    {
    //        MessageBox.Show("Error occurred while retrieving the Send documents");
    //    }

    //}

    DAL dalObj = new DAL("");
    public void Users_LogIn_System(string _userName)
    {
        try
        {
            SqlConnection sqlConn = new SqlConnection(connStr);
            sqlConn.Open();
            string strUpdate = "Update Users SET LogOn = 1 where user_name = '" + _userName + "'";
            SqlCommand sqlCmd = new SqlCommand(strUpdate, sqlConn);
            sqlCmd.ExecuteNonQuery();
            sqlConn.Close();
        }
        catch (Exception ex)
        {
            // MessageBox.Show(ex.Message);
        }
    }
    public void Users_LogOut_System(string _userName)
    {
        try
        {
            SqlConnection sqlConn = new SqlConnection(connStr);
            sqlConn.Open();
            string strUpdate = "Update Users SET LogOn = 0 Where user_name = '" + _userName + "'";
            SqlCommand sqlCmd = new SqlCommand(strUpdate, sqlConn);
            sqlCmd.ExecuteNonQuery();
            sqlConn.Close();
        }
        catch (Exception ex)
        {
            // MessageBox.Show(ex.Message);
        }
    }
    public int ChkDeleteRec_TenderDatesInfo(int _prjID, SqlConnection sqlConn)
    {
        int docID = 0;
        try
        {
            using (sqlCmd = new SqlCommand("SELECT date_iD FROM TenderDatesInfo where Proj_Id = " + _prjID + "", sqlConn))
            {
                docID = Convert.ToInt16(sqlCmd.ExecuteScalar());
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }

        return docID;
    }
    public int ChkDeleteRec_Contractors(int _prjID, SqlConnection sqlConn)
    {
        int bidID = 0;
        try
        {
            using (sqlCmd = new SqlCommand("SELECT bidder_id FROM CONTRACTORS where Proj_Id = " + _prjID + "", sqlConn))
            {
                bidID = Convert.ToInt16(sqlCmd.ExecuteScalar());
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
        return bidID;
    }
    public int ChkDeleteRec_ProjectCost(int _prjID, SqlConnection sqlConn)
    {
        int prjCost = 0;
        try
        {
            using (sqlCmd = new SqlCommand("SELECT cost_item_id FROM PROJECTCOST where Proj_Id = " + _prjID + "", sqlConn))
            {
                prjCost = Convert.ToInt16(sqlCmd.ExecuteScalar());
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
        return prjCost;
    }
    public int ChkDeleteRec_Documents(int _prjID, SqlConnection sqlConn)
    {
        int docID = 0;
        try
        {
            using (sqlCmd = new SqlCommand("SELECT doc_id FROM DOCUMENTS where Proj_Id = " + _prjID + "", sqlConn))
            {
                docID = Convert.ToInt16(sqlCmd.ExecuteScalar());
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
        return docID;
    }
    public int ExecuteNonQuery(string sqlString, SqlConnection sqlConn)
    {
        int exeResult = 0;
        SqlCommand sqlCommand = new SqlCommand(sqlString, sqlConn);
        exeResult = sqlCommand.ExecuteNonQuery();
        sqlCommand.Dispose();
        return exeResult;
    }
    public double ExecuteNonQueryForDouble(string sqlString, SqlConnection sqlConn)
    {
        double exeResult = 0;
        SqlCommand sqlCommand = new SqlCommand(sqlString, sqlConn);
        exeResult = sqlCommand.ExecuteNonQuery();
        sqlCommand.Dispose();
        return exeResult;
    }

    // Added by Varun on 20-Oct-2015
    public SqlDataReader ExecuteReader(string sqlString, SqlConnection sqlConn)
    {
        SqlCommand sqlCommand = new SqlCommand(sqlString, sqlConn);
        SqlDataReader sqlReader = sqlCommand.ExecuteReader();
        return sqlReader;
    }

    public int ExecuteReaderQuery(string sqlString, SqlConnection sqlConn)
    {
        int exeResult = 0;
        SqlCommand sqlCommand = new SqlCommand(sqlString, sqlConn);
        sqlDtReader = sqlCommand.ExecuteReader();
        if (sqlDtReader.Read())
            exeResult = sqlDtReader.GetInt32(0);
        sqlCommand.Dispose();
        sqlDtReader.Close();
        return exeResult;
    }

    public string CheckWorkOrder(string sqlString, SqlConnection sqlConn)
    {
        string columnValue = null;
        SqlCommand sqlCommand = new SqlCommand(sqlString, sqlConn);
        sqlDtReader = sqlCommand.ExecuteReader();
        if (sqlDtReader.Read())
            columnValue = sqlDtReader[0].ToString();
        sqlCommand.Dispose();
        sqlDtReader.Close();
        return columnValue;
    }

    public int GetMaxInfo(string sqlQuery, char doIncrement)
    {
        int docId = 0;
        try
        {
            using (SqlConnection sqlConn = new SqlConnection(connStr))
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.CommandTimeout = 80;
                    cmd.CommandText = sqlQuery;
                    sqlConn.Open();
                    cmd.Connection = sqlConn;
                    SqlDataReader sqlDtReader = cmd.ExecuteReader();
                    if (sqlDtReader.Read())
                    {
                        if (sqlDtReader[0] != DBNull.Value)
                        {
                            docId = Convert.ToInt32(sqlDtReader[0]);
                            if (doIncrement != 'N')
                                docId = docId + 1;
                        }
                        else
                            docId = 1;
                    }
                    //sqlConn.Close();
                }
            }
        }
        catch (Exception ex)
        {
            //MessageBox.Show("Exception occurred while fetching the latest Circular No., Try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        return docId;
    }

    clsTs_Stage clsForTS = new clsTs_Stage(_userName);

    public string AssignTenderNo(IList<string> userRightsColl, int _projID, string _tndrType, string projCode, string projTitle, char assign, string oldCommittee, string prevTenderNo, ref string tndrTypeName, ref string _userDept, ref string prjCreated, ref string affairs)
    {
        string tenderNo = string.Empty;
        try
        {

            string tempTndrNo = string.Empty;
            string cmtyShortName = string.Empty;
            string fiscalYear = string.Empty;
            string tndrType = string.Empty;
            string newFiscalYear = string.Empty;

            int cmtID = 0; int fiscalID = 0;
            clsForTS.GetCommitee_FiscalYear(ref cmtID, ref fiscalID, ref cmtyShortName, ref newFiscalYear, _projID, ref tndrTypeName, ref _userDept, ref prjCreated, ref affairs);
            tempTndrNo = clsForTS.getMaxTenderNo("SELECT MAX(tender_no) AS tenderNo FROM PROJECTS WHERE (committee_id = " + cmtID + ") AND (FYID = " + fiscalID + ")");

            if (tempTndrNo != "")
            {
                string[] strColl = tempTndrNo.Split('/');
                for (int i = 0; i < strColl.Length; i++)
                {
                    if (strColl[i] == cmtyShortName)
                    {
                        tempTndrNo = strColl[i + 1];
                        int ino = Convert.ToInt16(tempTndrNo) + 1;
                        if (ino.ToString().Length == 1)
                        { tempTndrNo = "00" + ino; }
                        else if (ino.ToString().Length == 2)
                        { tempTndrNo = "0" + ino; }
                        if (ino.ToString().Length == 3)
                        { tempTndrNo = ino.ToString(); }
                    }
                }
            }
            else
            {
                tempTndrNo = "001";
            }

            if (_tndrType.Equals("PQ"))
            {
                tenderNo = "PWA/" + cmtyShortName + "/" + tempTndrNo + "/" + newFiscalYear + "/" + _tndrType;
            }
            else
            {

                if (!cmtyShortName.Equals("MRPSC"))
                {
                    if (_tndrType.Equals("PT"))
                        tenderNo = "PWA/" + cmtyShortName + "/" + tempTndrNo + "/" + newFiscalYear;
                    else
                        tenderNo = "PWA/" + cmtyShortName + "/" + tempTndrNo + "/" + newFiscalYear + "/" + _tndrType;
                }
                else
                {
                    if (_tndrType.Equals("PT"))
                        tenderNo = cmtyShortName + "/" + tempTndrNo + "/" + newFiscalYear;
                    else
                        tenderNo = cmtyShortName + "/" + tempTndrNo + "/" + newFiscalYear + "/" + _tndrType;
                }
            }

            string executionStatus = clsForTS.UpdateTenderNo(_projID, tenderNo, _userName, fiscalID);
            // Added by Varun on 10 Feb 2014 for checking the exception occurence and to stop sending email alerts if there is a problem in assigning the Tender No.
            if (executionStatus == "Exception")
                tenderNo = "Exception";

        }
        catch (Exception ex)
        {
           ////  MessageBox.Show("Exception occurred while assigning the Tender No." + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            // Added by Varun on 10 Feb 2014 for checking the exception occurence and to stop sending email alerts if there is a problem in assigning the Tender No.
            tenderNo = "Exception";
        }
        finally
        {

        }
        return tenderNo;
    }
    string newFiscalYear = string.Empty;
    public string AssignTenderNo_For_Transfor(IList<string> userRightsColl, int _projID, string _tndrType, string projCode, string projTitle, char assign, string oldCommittee, string prevTenderNo, ref string tndrTypeName, ref string _userDept, ref string prjCreated, ref string affairs, ref string newFiscalYear)
    {
        string tenderNo = string.Empty;
        try
        {

            string tempTndrNo = string.Empty;
            string cmtyShortName = string.Empty;
            string fiscalYear = string.Empty;
            string tndrType = string.Empty;


            int cmtID = 0; int fiscalID = 0;
            clsForTS.GetCommitee_FiscalYear_For_Transfor(ref cmtID, ref fiscalID, ref cmtyShortName, ref newFiscalYear, _projID, ref tndrTypeName, ref _userDept, ref prjCreated, ref affairs);
            tempTndrNo = clsForTS.getMaxTenderNo("SELECT MAX(tender_no) AS tenderNo FROM PROJECTS WHERE (committee_id = " + cmtID + ") AND (FYID = " + fiscalID + ")");

            if (tempTndrNo != "")
            {
                string[] strColl = tempTndrNo.Split('/');
                for (int i = 0; i < strColl.Length; i++)
                {
                    if (strColl[i] == cmtyShortName)
                    {
                        tempTndrNo = strColl[i + 1];
                        int ino = Convert.ToInt16(tempTndrNo) + 1;
                        if (ino.ToString().Length == 1)
                        { tempTndrNo = "00" + ino; }
                        else if (ino.ToString().Length == 2)
                        { tempTndrNo = "0" + ino; }
                        if (ino.ToString().Length == 3)
                        { tempTndrNo = ino.ToString(); }
                    }
                }
            }
            else
            {
                tempTndrNo = "001";
            }

            if (_tndrType.Equals("PT"))
                tenderNo = "PWA/" + cmtyShortName + "/" + tempTndrNo + "/" + newFiscalYear;
            else
                tenderNo = "PWA/" + cmtyShortName + "/" + tempTndrNo + "/" + newFiscalYear + "/" + _tndrType;

            clsForTS.UpdateTenderNo(_projID, tenderNo, _userName, fiscalID);

        }
        catch (Exception ex)
        {
            // MessageBox.Show("Exception occurred while assigning the Tender No.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
        }

        return tenderNo;
    }
    public void insertStatement(SqlCommand cmd, int docId, int dateId, int docTypeId, int projId, int stageId, int docStatusId, string strRefNo, string crossRefNo, int empId, string docDate, string docissueDate, byte[] attFile, string strFileName, string daysToAct, string docSubject, int compId, int circularNo, Char alpha)
    {
        if (alpha == 'C' && dateId == 0 && attFile != null)
            cmd.CommandText = @"Insert Into DOCUMENTS(doc_id,date_id,doc_category_id,doc_type_id, proj_id, stage_id, doc_status_id,ref_no,cross_ref_no,employee_id,doc_date,doc_issue_date,days_to_act,subject,co_id,create_date,create_user,attFileName,attFile,CircularNo,filepath)" +
            " values(@docid,@dateId,@doccatId,@doctypeId,@projId,@stageId,@docStatusId,@refNo,@crsRefNo,@empId,@docdate,@docIssuedate,@daystoact,@Docsubject,@cmpID,@createDate,@createUser,@attFileName,@attFile,@circularNo,@filepath)";
        else if (alpha == 'C' && dateId == 0 && attFile == null)
            cmd.CommandText = @"Insert Into DOCUMENTS(doc_id,date_id,doc_category_id,doc_type_id, proj_id, stage_id, doc_status_id,ref_no,cross_ref_no,employee_id,doc_date,doc_issue_date,days_to_act,subject,co_id,create_date,create_user,attFileName,CircularNo,filepath)" +
            " values(@docid,@dateId,@doccatId,@doctypeId,@projId,@stageId,@docStatusId,@refNo,@crsRefNo,@empId,@docdate,@docIssuedate,@daystoact,@Docsubject,@cmpID,@createDate,@createUser,@attFileName,@circularNo,@filepath)";
        else if (alpha == 'C' && dateId != 0)
            cmd.CommandText = @"Insert Into DOCUMENTS(doc_id,date_id,doc_category_id,doc_type_id, proj_id, stage_id, doc_status_id,ref_no,cross_ref_no,employee_id,doc_date,days_to_act,subject,co_id,create_date,create_user,attFileName,CircularNo,filepath)" +
            " values(@docid,@dateId,@doccatId,@doctypeId,@projId,@stageId,@docStatusId,@refNo,@crsRefNo,@empId,@docdate,@daystoact,@Docsubject,@cmpID,@createDate,@createUser,@attFileName,@circularNo,@filepath)";
        else if (alpha == 'O' && attFile != null)
            cmd.CommandText = @"Insert Into DOCUMENTS(doc_id,doc_category_id,doc_type_id, proj_id, stage_id, doc_status_id,ref_no,cross_ref_no,employee_id,doc_date,doc_issue_date,days_to_act,subject,co_id,create_date,create_user,attFileName,attFile,filepath)" +
            " values(@docid,@doccatId,@doctypeId,@projId,@stageId,@docStatusId,@refNo,@crsRefNo,@empId,@docdate,@docIssuedate,@daystoact,@Docsubject,@cmpID,@createDate,@createUser,@attFileName,@attFile,@filepath)";
        else if (alpha == 'O' && attFile == null)
            cmd.CommandText = @"Insert Into DOCUMENTS(doc_id,doc_category_id,doc_type_id, proj_id, stage_id, doc_status_id,ref_no,cross_ref_no,employee_id,doc_date,doc_issue_date,days_to_act,subject,co_id,create_date,create_user,attFileName,filepath)" +
            " values(@docid,@doccatId,@doctypeId,@projId,@stageId,@docStatusId,@refNo,@crsRefNo,@empId,@docdate,@docIssuedate,@daystoact,@Docsubject,@cmpID,@createDate,@createUser,@attFileName,@filepath)";

        cmd.Parameters.AddWithValue("@docid", docId);
        if (dateId != 0)
            cmd.Parameters.AddWithValue("@dateId", dateId);
        else
            cmd.Parameters.AddWithValue("@dateId", DBNull.Value);
        cmd.Parameters.AddWithValue("@doccatId", 1);           //  Sent Doc
        cmd.Parameters.AddWithValue("@doctypeId", docTypeId);
        cmd.Parameters.AddWithValue("@projId", projId);
        cmd.Parameters.AddWithValue("@stageId", stageId);
        cmd.Parameters.AddWithValue("@docStatusId", docStatusId);
        cmd.Parameters.AddWithValue("@refNo", strRefNo);
        cmd.Parameters.AddWithValue("@crsRefNo", crossRefNo);
        cmd.Parameters.AddWithValue("@empId", empId);
        cmd.Parameters.AddWithValue("@docdate", docDate);
        if ((alpha == 'C' && dateId == 0) || (alpha == 'O'))
            cmd.Parameters.AddWithValue("@docIssuedate", docissueDate);

        if (strFileName != null)
        {
            cmd.Parameters.AddWithValue("@attFileName", strFileName);
            cmd.Parameters.AddWithValue("@filepath", docId + "_" + strRefNo);
        }
        else
        {
            cmd.Parameters.AddWithValue("@attFileName", DBNull.Value);
            cmd.Parameters.AddWithValue("@filepath", DBNull.Value);
        }

        if (dateId == 0 && (alpha == 'C' || alpha == 'O'))
        {
            if (attFile != null)
            {
                cmd.Parameters.AddWithValue("@attFile", attFile);
            }
        }

        if (daysToAct != "")
        { cmd.Parameters.AddWithValue("@daystoact", Convert.ToInt16(daysToAct)); }
        else
        { cmd.Parameters.AddWithValue("@daystoact", 0); }
        cmd.Parameters.AddWithValue("@Docsubject", docSubject);
        cmd.Parameters.AddWithValue("@cmpID", compId);
        cmd.Parameters.AddWithValue("@createDate", System.DateTime.Now);
        cmd.Parameters.AddWithValue("@createUser", _userName);
        if (alpha == 'C' && stageId == 2)
            cmd.Parameters.AddWithValue("@circularNo", circularNo);
        else if (alpha == 'C' && stageId != 2)
            cmd.Parameters.AddWithValue("@circularNo", DBNull.Value);

    }

    //Added by Varun on 01 Dec 2015
    private string CheckArabicCharactersInFileName(string fileName)
    {
        StringBuilder strBuildFileName = new StringBuilder();
        foreach (char c in fileName)
        {
            if (c >= 32 && c <= 126)
            {
                strBuildFileName.Append(c);
            }

        }
        string fileNameWithoutSpace = strBuildFileName.ToString().Replace(" ", "").ToString();
        if (fileNameWithoutSpace.Split('.')[0].Length == 0)
            fileName = "FileName_With_Arabic_Text." + fileName.Split('.')[1];
        else
            fileName = fileNameWithoutSpace;
        return fileName;
    }

    //private PdfPTable createTable(int totRowCount, PdfPTable table2, iTextSharp.text.Font plainText, iTextSharp.text.Font boldText, DataGridView dgViewBidders, DataView dv, char isTenderExpiry)
    //{
    //    if (isTenderExpiry == 'N')
    //    {

    //        PdfPCell tabCell = null;
    //        Paragraph snPg = null;
    //        // storing header part in pdf file
    //        for (int i = 1; i < 11; i++)
    //        {
    //            tabCell = new PdfPCell();
    //            tabCell.HorizontalAlignment = PdfPCell.ALIGN_CENTER;
    //            if (dgViewBidders != null)
    //            {
    //                if (i < 10)
    //                    snPg = new Paragraph(dgViewBidders.Columns[i].HeaderText, boldText);
    //                else if (dgViewBidders.ColumnCount != 18 && i == 10)
    //                    snPg = new Paragraph(dgViewBidders.Columns[10].HeaderText, boldText);
    //                else if (dgViewBidders.ColumnCount == 18 && i == 10)
    //                    snPg = new Paragraph(dgViewBidders.Columns[13].HeaderText, boldText);
    //            }
    //            else
    //                snPg = new Paragraph(dv.Table.Columns[i].ColumnName, boldText);

    //            snPg.Alignment = iTextSharp.text.pdf.PdfContentByte.ALIGN_CENTER;
    //            tabCell.AddElement(snPg);
    //            table2.AddCell(tabCell);
    //        }
    //        table2.HeaderRows = 1;

    //        DataTable finalDt = new DataTable();

    //        finalDt.Columns.Add("SN");
    //        finalDt.Columns.Add("CompanyName");
    //        finalDt.Columns.Add("Nationality");
    //        finalDt.Columns.Add("DateOfIssue");
    //        finalDt.Columns.Add("ReceiptNo");
    //        finalDt.Columns.Add("FaxNo");
    //        finalDt.Columns.Add("TelNo");
    //        finalDt.Columns.Add("MobileNo");
    //        finalDt.Columns.Add("EmailAddress");
    //        finalDt.Columns.Add("Remarks");
    //        finalDt.AcceptChanges();

    //        if (dgViewBidders != null)
    //        {
    //            for (int iRowCounter = 0; iRowCounter < dgViewBidders.Rows.Count; iRowCounter++)
    //            {
    //                DataRow dr = finalDt.NewRow();
    //                dr[0] = dgViewBidders.Rows[iRowCounter].Cells[1].Value;
    //                dr[1] = dgViewBidders.Rows[iRowCounter].Cells[2].Value;
    //                dr[2] = dgViewBidders.Rows[iRowCounter].Cells[3].Value;
    //                dr[3] = dgViewBidders.Rows[iRowCounter].Cells[4].Value;
    //                dr[4] = dgViewBidders.Rows[iRowCounter].Cells[5].Value;
    //                dr[5] = dgViewBidders.Rows[iRowCounter].Cells[6].Value;
    //                dr[6] = dgViewBidders.Rows[iRowCounter].Cells[7].Value;
    //                dr[7] = dgViewBidders.Rows[iRowCounter].Cells[8].Value;
    //                dr[8] = dgViewBidders.Rows[iRowCounter].Cells[9].Value;
    //                if (dgViewBidders.ColumnCount != 18)
    //                    dr[9] = dgViewBidders.Rows[iRowCounter].Cells[10].Value;
    //                else
    //                    dr[9] = dgViewBidders.Rows[iRowCounter].Cells[13].Value;
    //                finalDt.Rows.Add(dr);
    //                finalDt.AcceptChanges();
    //            }
    //        }
    //        else
    //        {
    //            foreach (DataRow drViewBidders in dv.Table.Rows)
    //            {
    //                DataRow dr = finalDt.NewRow();
    //                dr[0] = drViewBidders[1];
    //                dr[1] = drViewBidders[2];
    //                dr[2] = drViewBidders[3];
    //                dr[3] = drViewBidders[4];
    //                dr[4] = drViewBidders[5];
    //                dr[5] = drViewBidders[6];
    //                dr[6] = drViewBidders[7];
    //                dr[7] = drViewBidders[8];
    //                dr[8] = drViewBidders[9];
    //                dr[9] = drViewBidders[10];
    //                finalDt.Rows.Add(dr);
    //                finalDt.AcceptChanges();
    //            }
    //        }

    //        // storing Each row and column value to pdf file
    //        for (int i = 0; i < totRowCount; i++)
    //        {
    //            for (int j = 0; j < finalDt.Columns.Count; j++)
    //            {
    //                if (finalDt.Rows[i][9].ToString().ToLower().Contains("regret") || finalDt.Rows[i][9].ToString().ToLower().Contains("declined"))
    //                {
    //                    tabCell = new PdfPCell();
    //                    tabCell.BackgroundColor = new BaseColor(255, 255, 0);
    //                    tabCell.HorizontalAlignment = PdfPCell.ALIGN_CENTER;
    //                    snPg = new Paragraph(finalDt.Rows[i][j].ToString(), plainText);
    //                    snPg.Alignment = iTextSharp.text.pdf.PdfContentByte.ALIGN_CENTER;
    //                    tabCell.AddElement(snPg);
    //                    table2.AddCell(tabCell);
    //                }
    //                else
    //                {
    //                    tabCell = new PdfPCell();
    //                    tabCell.HorizontalAlignment = PdfPCell.ALIGN_CENTER;
    //                    snPg = new Paragraph(finalDt.Rows[i][j].ToString(), plainText);
    //                    snPg.Alignment = iTextSharp.text.pdf.PdfContentByte.ALIGN_CENTER;
    //                    tabCell.AddElement(snPg);
    //                    table2.AddCell(tabCell);
    //                }
    //            }
    //        }

    //        table2.SpacingBefore = 10f;
    //        table2.HorizontalAlignment = iTextSharp.text.pdf.PdfContentByte.ALIGN_CENTER;
    //    }
    //    else
    //    {
    //        // storing header part in pdf file
    //        for (int i = 0; i < 7; i++)
    //        {
    //            PdfPCell tabCell = new PdfPCell();
    //            tabCell.HorizontalAlignment = PdfPCell.ALIGN_CENTER;
    //            tabCell.BorderWidth = 1f;
    //            Paragraph snPg = null;

    //            boldText.Color = new BaseColor(255, 255, 255);
    //            if (i == 0)
    //                snPg = new Paragraph("Days To Expire", boldText);
    //            if (i == 1)
    //                snPg = new Paragraph("Tender No.", boldText);
    //            if (i == 2)
    //                snPg = new Paragraph("Project Title", boldText);
    //            if (i == 3)
    //                snPg = new Paragraph("Project Code", boldText);
    //            if (i == 4)
    //                snPg = new Paragraph("Committee", boldText);
    //            if (i == 5)
    //                snPg = new Paragraph("Tender Status", boldText);
    //            if (i == 6)//dv.Table.Columns[i].ColumnName == "Department"
    //                snPg = new Paragraph("Department", boldText);

    //            snPg.Alignment = iTextSharp.text.pdf.PdfContentByte.ALIGN_CENTER;
    //            tabCell.BackgroundColor = new BaseColor(153, 0, 76);
    //            tabCell.AddElement(snPg);
    //            table2.AddCell(tabCell);
    //        }
    //        table2.HeaderRows = 1;
    //        DataTable finalDt = new DataTable();

    //        finalDt.Columns.Add("ExpiryDays");
    //        finalDt.Columns.Add("TenderNo");
    //        finalDt.Columns.Add("ProjectTitle");
    //        finalDt.Columns.Add("ProjectCode");
    //        finalDt.Columns.Add("TenderCommittee");
    //        finalDt.Columns.Add("TenderStatus");
    //        finalDt.Columns.Add("UserDepartment");
    //        finalDt.AcceptChanges();

    //        foreach (DataRow drProj in dv.Table.Rows)
    //        {
    //            DataRow dr = finalDt.NewRow();
    //            dr[0] = drProj[0];  //ExpiryDays
    //            dr[1] = drProj[4];  //TenderNo
    //            dr[2] = drProj[3];  //ProjectTitle
    //            dr[3] = drProj[2];  //ProjectCode
    //            dr[4] = drProj[8];  //TenderCommittee
    //            dr[5] = drProj[6];  //TenderStatus
    //            dr[6] = drProj[11];  //UserDepartment                
    //            finalDt.Rows.Add(dr);
    //            finalDt.AcceptChanges();
    //        }

    //        // storing Each row and column value to pdf file
    //        for (int i = 0; i < totRowCount; i++)
    //        {
    //            for (int j = 0; j < 7; j++)
    //            {
    //                PdfPCell tabCell = new PdfPCell();
    //                tabCell.HorizontalAlignment = PdfPCell.ALIGN_CENTER;
    //                Paragraph snPg = null;
    //                snPg = new Paragraph(finalDt.Rows[i][j].ToString(), plainText);
    //                snPg.Alignment = iTextSharp.text.pdf.PdfContentByte.ALIGN_CENTER;
    //                tabCell.AddElement(snPg);
    //                table2.AddCell(tabCell);
    //            }

    //        }

    //        table2.SpacingBefore = 10f;
    //        table2.HorizontalAlignment = iTextSharp.text.pdf.PdfContentByte.ALIGN_CENTER;
    //    }
    //    return table2;
    //}
 
}