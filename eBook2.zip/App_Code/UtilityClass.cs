﻿using System; 
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Security.Principal;
//using System.DirectoryServices;
using System.Configuration;
using System.Text;
using System.Security.Cryptography;
using System.Data.SqlClient;
using System.Data;
using System.Threading;
using System.ServiceModel;
using System.Globalization;
using DataLayer;

/// <summary>
/// Summary description for UtilityClass
/// </summary>
public class UtilityClass:Page
{
    Page pageCls = null;
    private string connValue = ConfigurationManager.ConnectionStrings["EBSDEBookConn"].ToString();
    DAL dal = null;

    public UtilityClass(Page page)
	{
		//
		// TODO: Add constructor logic here
		//
        pageCls = page;
        //dal = new DAL(connValue);       
	}

    public Boolean getStaffStatus(string srvID)
    {
        Boolean chkStaffStatus = false;

        try
        {
            SqlConnection sqlConn = new SqlConnection(connValue);
            sqlConn.Open();

            string strValue = "SELECT jobOwnerID FROM JobOwner join EBDServiceRequests ON JobOwner.srID=EBDServiceRequests.serviceReqID JOIN Contact on JobOwner.contactID=Contact.contactID WHERE (JobOwner.srID = @srID) AND (JobOwner.sectionID = 9) AND (JobOwner.jobOwnerStatusID = 7) "+
            "and (Contact.isTeamLeader=0) and (EBDServiceRequests.statusID=3)";

            SqlCommand sqlCom = new SqlCommand(strValue, sqlConn);
            sqlCom.CommandText = strValue;

            sqlCom.Parameters.AddWithValue("@srID", srvID);
            SqlDataReader sqlReader = sqlCom.ExecuteReader();

            if (sqlReader.HasRows)
                chkStaffStatus = true;
            else
                chkStaffStatus = false;

            sqlReader.Close();
            sqlConn.Close();
        }
        catch (Exception ex)
        {
            throw ex;
        }

        return chkStaffStatus;
    }

    public Boolean AuthenticateUserCredentialsDirect(string systemName, string userName)
    {
        UtilityClass utilCls = new UtilityClass(Page);
        Boolean chkUserExist = false;
        using (SqlConnection cn = new SqlConnection(connValue))
        {
            using (SqlCommand sqlCmd = new SqlCommand())
            {
                sqlCmd.Connection = cn;
                //string strQuery = "SELECT  Contact.firstName + '  ' + Contact.lastName AS displayName, Contact.emailAddress, Contact.contactID, Contact.companyID, UserSecurityProfile.profileName, " +
                //            " Contact.systemUserName, Contact.sectionID, Contact.isActive, Contact.userProfileID, Section.sectionName,Contact.userName, Contact.password,Contact.teamLeaderID,Contact.User_ID " +
                //              " FROM Contact INNER JOIN " +
                //              " Section ON Contact.sectionID = Section.sectionID INNER JOIN " +
                //             " UserSecurityProfile ON Contact.userProfileID = UserSecurityProfile.userProfileID WHERE (Contact.computerName = @computerName) and (systemUserName =@systemUserName) and (Contact.isActive =1)";


                string strQuery = "SELECT  Contact.firstName + ' ' + Contact.lastName AS displayName, Contact.emailAddress, Contact.contactID, Contact.companyID, UserSecurityProfile.profileName, " + 
                        "  Contact.systemUserName, Contact.sectionID, Contact.isActive, Contact.userProfileID, Section.sectionName, Contact.userName, Contact.password, " + 
                       "  Contact.teamLeaderID, Contact.User_ID, Company.cmpName FROM  Contact INNER JOIN  Section ON Contact.sectionID = Section.sectionID INNER JOIN  UserSecurityProfile ON Contact.userProfileID = UserSecurityProfile.userProfileID INNER JOIN " + 
                       "  Company ON Contact.companyID = Company.companyID WHERE (Contact.computerName = @computerName) AND (Contact.systemUserName = @systemUserName) AND (Contact.isActive = 1)";


                try
                {
                    sqlCmd.CommandText = strQuery;
                    sqlCmd.Parameters.AddWithValue("@computerName", systemName.ToString());
                    sqlCmd.Parameters.AddWithValue("@systemUserName", userName.ToString());

                    cn.Open();
                    using (SqlDataReader sqlDtRead = sqlCmd.ExecuteReader())
                    {
                        if (sqlDtRead.HasRows)
                        {
                            while (sqlDtRead.Read())
                            {
                                pageCls.Session["UserDisplayName"] = sqlDtRead["displayName"].ToString().Trim();
                                pageCls.Session["IssuedByEmailAddress"] = sqlDtRead["emailAddress"].ToString();
                                pageCls.Session["UserID"] = sqlDtRead["contactID"].ToString();

                                pageCls.Session["CmpID"] = sqlDtRead["companyID"].ToString();
                                pageCls.Session["ProfileName"] = sqlDtRead["profileName"].ToString();
                                pageCls.Session["UserName"] = sqlDtRead["systemUserName"].ToString();

                                pageCls.Session["SectionID"] = sqlDtRead["sectionID"].ToString();
                                pageCls.Session["SectionName"] = sqlDtRead["sectionName"].ToString();
                                pageCls.Session["IsActive"] = sqlDtRead["isActive"].ToString();
                                pageCls.Session["userProfileID"] = sqlDtRead["userProfileID"].ToString();
                               
                                pageCls.Session["teamLeaderID"] = sqlDtRead["teamLeaderID"].ToString();
                                pageCls.Session["LoginUserName"] = sqlDtRead["UserName"].ToString();
                                pageCls.Session["systemUserName"] = sqlDtRead["User_ID"].ToString();

                                pageCls.Session["cmpName"] = sqlDtRead["cmpName"].ToString();

                                CheckCurrentDateSeparator();
                                IList<string> userRightsColl = new List<string>();
                                Session["UserRightsColl"] = utilCls.GetUserAccessList(Session["UserID"].ToString(), userRightsColl);
                            }

                            chkUserExist = true;
                        }
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
        }

        return chkUserExist;
    }

    public void PopulateDropDownBox(DropDownList ddlBox, string sqlQuery, string valueMember, string displayName, bool isDDLDisabled)
    {
        DataTable table = new DataTable();
        try
        {
            using (SqlConnection sqlConn = new SqlConnection(connValue))
            {
                using (SqlDataAdapter da = new SqlDataAdapter(sqlQuery, sqlConn))
                {
                    sqlConn.Open();
                    da.Fill(table);
                }
            }
            //cmbBox.Items.Add("Select");
            ddlBox.Items.Clear();            
            ddlBox.DataSource = table;
            ddlBox.DataTextField = displayName;
            ddlBox.DataValueField = valueMember;            
            ddlBox.DataBind();
            if (!isDDLDisabled)
            {
                ddlBox.SelectedIndex = -1;
                ddlBox.Items.Insert(0, new ListItem(""));
            }
        }
        catch (System.Exception ex)
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "alert('Error Occurred while filling the " + ddlBox.ID + " dropdownlist')", true);
        }
    }

    public string CheckIsTeamLead(string userName, DAL dal)
    {
        string result = null;
        try
        {
            UtilityClass utilCls = new UtilityClass(pageCls);
            SqlCommand sqlCmd = new SqlCommand();
            if (dal.SqlConnection.State != ConnectionState.Open)
                dal.SqlConnection.Open();
            sqlCmd.Connection = dal.SqlConnection;

            //string strQuery = "SELECT  Contact.firstName + '  ' + Contact.lastName AS displayName, Contact.emailAddress, Contact.contactID, Contact.companyID, UserSecurityProfile.profileName, " +
            //            " Contact.systemUserName, Contact.sectionID, Contact.isActive, Contact.userProfileID, Section.sectionName,Contact.userName, Contact.password,Contact.teamLeaderID,Contact.User_ID   " +
            //              " FROM Contact INNER JOIN " +
            //              " Section ON Contact.sectionID = Section.sectionID INNER JOIN " +
            //             " UserSecurityProfile ON Contact.userProfileID = UserSecurityProfile.userProfileID WHERE (Contact.userName = @userName) and (password = HashBytes('SHA1', '" + pwd + "')) and (Contact.isActive =1)";

            string strQuery = "SELECT teamLeaderID from EBSDTeamLeaders WHERE (contactID = @contactID)"; //

            sqlCmd.CommandText = strQuery;

            sqlCmd.Parameters.AddWithValue("@contactID", Session["UserID"].ToString());
            // sqlCmd.Parameters.AddWithValue("@userPassword", pwd.ToString());
            SqlDataReader sqlDtRead = sqlCmd.ExecuteReader();
            if (sqlDtRead.HasRows)
            {
             
                    // if (utilCls.VerifyHash(pwd, sqlDtRead["password"].ToString()))
                    //{                         
                    //    pageCls.Session["UserID"] = sqlDtRead["contactID"].ToString();
                    //    pageCls.Session["teamLeaderID"] = sqlDtRead["teamLeaderID"].ToString();                        
                    //    if (sqlDtRead["teamLeadContactID"].ToString().Equals(Session["UserID"].ToString()))
                    //    {
                 pageCls.Session["isTeamLeader"] = "1";                                          
              

               
            }           
            else
            {
                pageCls.Session["isTeamLeader"] = "0";
            }   
            dal.DisconnectDB();

        }
        catch (Exception ex)
        {
            result = "Ex";
        }
        return result;
    }

    public static string dateFormat = null;
    public string AuthenticateUserCredentials(string userName, string pwd, DAL dal)
    {
        string result = null;
        try
        {
            UtilityClass utilCls = new UtilityClass(pageCls);
            SqlCommand sqlCmd = new SqlCommand();
            if (dal.SqlConnection.State != ConnectionState.Open)
                dal.SqlConnection.Open();
            sqlCmd.Connection = dal.SqlConnection;

            //string strQuery = "SELECT  Contact.firstName + '  ' + Contact.lastName AS displayName, Contact.emailAddress, Contact.contactID, Contact.companyID, UserSecurityProfile.profileName, " +
            //            " Contact.systemUserName, Contact.sectionID, Contact.isActive, Contact.userProfileID, Section.sectionName,Contact.userName, Contact.password,Contact.teamLeaderID,Contact.User_ID   " +
            //              " FROM Contact INNER JOIN " +
            //              " Section ON Contact.sectionID = Section.sectionID INNER JOIN " +
            //             " UserSecurityProfile ON Contact.userProfileID = UserSecurityProfile.userProfileID WHERE (Contact.userName = @userName) and (password = HashBytes('SHA1', '" + pwd + "')) and (Contact.isActive =1)";

            string strQuery = "SELECT Contact.firstName + ' ' + Contact.lastName AS displayName, Contact.emailAddress, Contact.contactID, Contact.companyID,Company.cmpShortName, UserSecurityProfile.profileName, " +
            " Contact.systemUserName, Contact.sectionID, Contact.isActive, Contact.userProfileID, Section.sectionName, Contact.userName, Contact.password,  Contact.teamLeaderID, Contact.User_ID, Company.cmpName FROM Contact " + //,Contact.isTeamLeader, Contact.isHeadOfSection 
            " INNER JOIN Section ON Contact.sectionID = Section.sectionID INNER JOIN " +
            " UserSecurityProfile ON Contact.userProfileID = UserSecurityProfile.userProfileID INNER JOIN Company ON Contact.companyID = Company.companyID " +
            " WHERE (Contact.userName = @userName)"; //and (password = HashBytes('SHA1', '" + pwd + "')) AND (Contact.isActive = 1)";
                        
            sqlCmd.CommandText = strQuery;

            sqlCmd.Parameters.AddWithValue("@userName", userName.ToString());
            // sqlCmd.Parameters.AddWithValue("@userPassword", pwd.ToString());
            SqlDataReader sqlDtRead = sqlCmd.ExecuteReader();
            if (sqlDtRead.HasRows)
            {
                if (sqlDtRead.Read())
                {
                    // if (utilCls.VerifyHash(pwd, sqlDtRead["password"].ToString()))
                    {
                        pageCls.Session["UserDisplayName"] = sqlDtRead["displayName"].ToString().Trim();
                        pageCls.Session["IssuedByEmailAddress"] = sqlDtRead["emailAddress"].ToString();
                        pageCls.Session["UserID"] = sqlDtRead["contactID"].ToString();
                        pageCls.Session["CmpID"] = sqlDtRead["companyID"].ToString();
                        pageCls.Session["CmpShortName"] = sqlDtRead["cmpShortName"].ToString();
                        pageCls.Session["ProfileName"] = sqlDtRead["profileName"].ToString();

                        pageCls.Session["UserName"] = userName; // sqlDtRead["systemUserName"].ToString();

                        pageCls.Session["SectionID"] = sqlDtRead["sectionID"].ToString();
                        pageCls.Session["SectionName"] = sqlDtRead["sectionName"].ToString();
                        pageCls.Session["IsActive"] = sqlDtRead["isActive"].ToString();
                        pageCls.Session["userProfileID"] = sqlDtRead["userProfileID"].ToString();
                       
                        pageCls.Session["teamLeaderID"] = sqlDtRead["teamLeaderID"].ToString();
                        pageCls.Session["LoginUserName"] = sqlDtRead["UserName"].ToString();

                        pageCls.Session["systemUserName"] = sqlDtRead["User_ID"].ToString();

                        pageCls.Session["cmpName"] = sqlDtRead["cmpName"].ToString();
                         
                        //pageCls.Session["isTeamLeader"] = sqlDtRead["isTeamLeader"].ToString();
                        
                        //pageCls.Session["isHeadOfSection"] = sqlDtRead["isHeadOfSection"].ToString();
                        CheckCurrentDateSeparator();
                        IList<string> userRightsColl = new List<string>();
                        Session["UserRightsColl"] = utilCls.GetUserAccessList(Session["UserID"].ToString(), userRightsColl);
                        result = "1";
                    }

                }

                if (Session["userProfileID"].ToString().Equals("26")) //26=="EOIAdmin Profile" for TSS Module
                {
                    DataTable dtContactID = dal.GetDataFromDB("ContactID", "select contactID from Contact where userProfileID=26 and userName='EOIAdmin'");
                    if (dtContactID.Rows.Count != 0)
                    {
                        Session["UserID"] = dtContactID.Rows[0][0];
                    }
                }
                 
            }
            else
                result = "0";
            dal.DisconnectDB();

        }
        catch (Exception ex)
        {
            result = "Ex";
        }
        return result;
    }



    public bool AuthenticateUserPassword(string systemUserName, string emailAddress, string oldPwd, DAL dal)
    {
        bool isValidated = false;
        try
        {
            //dal.ConnectDB();
            SqlCommand sqlCmd = new SqlCommand();
            if (dal.SqlConnection.State != ConnectionState.Open)
                dal.SqlConnection.Open();
            sqlCmd.Connection = dal.SqlConnection;
            //sqlCmd.CommandType = System.Data.CommandType.StoredProcedure;
            sqlCmd.CommandText = "select contactID from Contact where UserName=@systemUserName and emailAddress=@emailAddress and password = HashBytes('SHA1', '" + oldPwd + "')";
            sqlCmd.Parameters.AddWithValue("@systemUserName", systemUserName);
            sqlCmd.Parameters.AddWithValue("@emailAddress", emailAddress);
            SqlDataReader sqlDtReader = sqlCmd.ExecuteReader();
            if (sqlDtReader.Read())
            {
                isValidated = true;
            }
            sqlDtReader.Close();
        }
        catch (Exception ex)
        {
           // WriteToLog(DateTime.Now.ToString(UtilityClass.dateFormat) + " " + ex.Message, " Inside UtilityClass.cs->AuthenticateUserPassword Method");
            //DisplayJavaScriptMessage(pageCls, "Error occurred while performing database operation");
        }
        finally
        {
            dal.DisconnectDB();
        }
        return isValidated;
    }
    public void FillDropDownList(DropDownList ddl, string ddlType, DropDownList ddlCmp, DropDownList ddlAffairs, DropDownList ddlDept, string paramValue, DataTable dtMyDocSearch, string userID)
    {
        try
        {
            if (ddlType == "ContractNo" || ddlType == "TenderNo" || ddlType == "ProjectId")
            {
                connValue = ConfigurationManager.ConnectionStrings["TCMSConn"].ToString();
                dal = new DAL(connValue);
                if (dal.ConnectDB(pageCls) == 'E')
                    return;
            }
            else
            {
                connValue = ConfigurationManager.ConnectionStrings["EBSDEBookConn"].ToString();
                dal = new DAL(connValue);
                if (dal.ConnectDB(pageCls) == 'E')
                    return;
            }

            SqlCommand sqlCmd = new SqlCommand();
            sqlCmd.Connection = dal.SqlConnection;

            if (ddlType == "ContractNo")
            {
                sqlCmd.CommandText = "select distinct proj_id,contract_no from CONTRACTORS where contract_no is not NULL and contract_no<>' ' order by contract_no";
                SqlDataReader sqlDtRead = sqlCmd.ExecuteReader();
                ListItem lstItem = new ListItem("Select CNo.", "0");
                ddl.Items.Add(lstItem);
                while (sqlDtRead.Read())
                {
                    lstItem = new ListItem(sqlDtRead["contract_no"].ToString(), sqlDtRead["proj_id"].ToString());
                    ddl.Items.Add(lstItem);
                }
                sqlDtRead.Close();
            }           
            else if (ddlType == "FillDeptForMyDocs" || ddlType == "FillDeptForDocDetails" || ddlType == "FillDeptForCreateProfile" || ddlType == "FillDeptForUserRegis")
            {

                if (ddlCmp.SelectedValue == "1") //ddlType == "FillDeptForMyDocs" || ddlType == "FillDeptForCreateProfile" || ddlType == "FillDeptForDocDetails" &&
                    sqlCmd.CommandText = "SELECT distinct Department.departmentID, Department.deptName FROM Department INNER JOIN  Affair ON Department.affairID = Affair.affairID INNER JOIN " +
                    "Company ON Company.companyID = Affair.companyID WHERE (Company.companyID =1)"; //Company.companyID =1 is PWA
                else if (ddlAffairs == null)
                    sqlCmd.CommandText = "SELECT distinct Department.departmentID,Department.deptName FROM Contact INNER JOIN Company ON Contact.companyID = Company.companyID INNER JOIN Department ON Department.departmentID = Contact.deptID " +
                    "WHERE Company.companyID=" + ddlCmp.SelectedValue;  //Company.companyID is other than PWA                                          
                else if (ddlAffairs != null)
                    sqlCmd.CommandText = "SELECT distinct Department.departmentID,Department.deptName FROM Contact INNER JOIN Company ON Contact.companyID = Company.companyID INNER JOIN Department ON Department.departmentID = Contact.deptID " +
                    "WHERE Contact.contactID=" + ddlAffairs.SelectedValue + " and Contact.companyID=" + ddlCmp.SelectedValue;

                ListItem lstItem = null;
                ddl.Items.Clear();
                if (ddlType == "FillDeptForMyDocs")
                {
                    lstItem = new ListItem("", "0");
                    ddl.Items.Add(lstItem);
                }

                SqlDataReader sqlDtRead = sqlCmd.ExecuteReader();
                while (sqlDtRead.Read())
                {
                    lstItem = new ListItem(sqlDtRead["deptName"].ToString().Trim(), sqlDtRead["departmentID"].ToString());
                    ddl.Items.Add(lstItem);
                }
                if (ddlType == "FillDeptForMyDocs")
                    Session["DDLDept"] = ddl;
                sqlDtRead.Close();
            } 
            else if (ddlType == "UserGroup")
            {
                ddl.Items.Clear();
                sqlCmd.CommandText = "select UserSecurityProfile.profileName from Users inner join UserSecurityProfile on Users.userProfileID = UserSecurityProfile.userProfileID where Users.userName='" + paramValue + "'";
                SqlDataReader sqlDtRead = sqlCmd.ExecuteReader();
                string profileName = null;
                if (sqlDtRead.Read())
                    profileName = sqlDtRead["profileName"].ToString();
                sqlDtRead.Close();

                sqlCmd.CommandText = "select userProfileID,profileName from UserSecurityProfile";
                sqlDtRead = sqlCmd.ExecuteReader();


                while (sqlDtRead.Read())
                {
                    if (profileName == "Administrator")
                    {
                        ListItem lstItem = new ListItem(sqlDtRead["profileName"].ToString(), sqlDtRead["userProfileID"].ToString());
                        ddl.Items.Add(lstItem);
                    }
                    else
                    {
                        ListItem lstItem = null;
                        if (sqlDtRead["profileName"].ToString() != "Administrator")
                        {
                            lstItem = new ListItem(sqlDtRead["profileName"].ToString(), sqlDtRead["userProfileID"].ToString());
                            ddl.Items.Add(lstItem);
                        }
                    }
                }
                if (profileName != null)
                    ddl.Items.FindByText(profileName).Selected = true;
            }
            else if (ddlType == "ReportsMainMenu" || ddlType == "ReportsSubMenu")
            {
                if (ddlType == "ReportsMainMenu")
                    sqlCmd.CommandText = "select rptMainMenuID,rptMainMenuDescription from ReportsMainMenu where rptMainMenuID <> 0";
                else
                    sqlCmd.CommandText = "select rptSubMenuID,rptSubMenuDescription from ReportsSubMenu where rptSubMenuID <> 0";

                SqlDataReader sqlDtRead = sqlCmd.ExecuteReader();
                ListItem lstItem = new ListItem("", "0");
                ddl.Items.Add(lstItem);
                while (sqlDtRead.Read())
                {
                    if (ddlType == "ReportsMainMenu")
                        lstItem = new ListItem(sqlDtRead["rptMainMenuDescription"].ToString(), sqlDtRead["rptMainMenuID"].ToString());
                    else
                        lstItem = new ListItem(sqlDtRead["rptSubMenuDescription"].ToString(), sqlDtRead["rptSubMenuID"].ToString());
                    ddl.Items.Add(lstItem);
                }
                sqlDtRead.Close();
            }
           
            else if (ddlType == "Affairs")
            {
                sqlCmd.CommandText = "select affairID, affairName from Affair join Company on Affair.companyID = Company.companyID where Affair.companyID=" + ddlCmp.SelectedValue;
                SqlDataReader sqlDtRead = sqlCmd.ExecuteReader();

                while (sqlDtRead.Read())
                {
                    ListItem lstItem = new ListItem(sqlDtRead["affairName"].ToString(), sqlDtRead["affairID"].ToString());
                    ddl.Items.Add(lstItem);
                }
                sqlDtRead.Close();
            }
            else if (ddlType == "Department")
            {
                sqlCmd.CommandText = "select departmentID, deptName from Department join Affair on Department.affairID = Affair.affairID where Department.affairID=" + ddlAffairs.SelectedValue;
                SqlDataReader sqlDtRead = sqlCmd.ExecuteReader();
                while (sqlDtRead.Read())
                {
                    ListItem lstItem = new ListItem(sqlDtRead["deptName"].ToString(), sqlDtRead["departmentID"].ToString());
                    ddl.Items.Add(lstItem);
                }
                sqlDtRead.Close();
            }
            else if (ddlType == "Section")
            {
                sqlCmd.CommandText = "select sectionID,sectionName from Section where Section.sectionID between 39 and 51";
                SqlDataReader sqlDtRead = sqlCmd.ExecuteReader();
                while (sqlDtRead.Read())
                {
                    ListItem lstItem = new ListItem(sqlDtRead["sectionName"].ToString(), sqlDtRead["sectionID"].ToString());
                    ddl.Items.Add(lstItem);
                }
                sqlDtRead.Close();
            }
            else if (ddlType == "TeamLeaders")
            {
                sqlCmd.CommandText = "select teamLeaderID,teamLeaderName from EBSDTeamLeaders";
                SqlDataReader sqlDtRead = sqlCmd.ExecuteReader();
                ListItem lstItem = new ListItem("", "0");
                ddl.Items.Add(lstItem);
                while (sqlDtRead.Read())
                {
                    lstItem = new ListItem(sqlDtRead["teamLeaderName"].ToString(), sqlDtRead["teamLeaderID"].ToString());
                    ddl.Items.Add(lstItem);
                }
                sqlDtRead.Close();
            }
            dal.DisconnectDB();
        }
        catch (Exception ex)
        {
            //WriteToLog(DateTime.Now.ToString(UtilityClass.dateFormat) + " " + ex.Message, " Inside UtilityClass.cs->FillDropDownList Method");
            DisplayJavaScriptMessage(pageCls, "Error occurred while performing database operation");
        }
    }
    public void PopulateMenus(Menu menu, char isAdmin,DAL dal)
    {
        DataTable dtMenu = null;
        if (pageCls.Session["Menu"] == null)
        {
            dtMenu = new DataTable();
            string sql = "Select ParentID,MenuID,MenuName,MenuLocation from MenuItems";
            SqlDataAdapter da = new SqlDataAdapter(sql, dal.SqlConnection);
            da.Fill(dtMenu);
            pageCls.Session["Menu"] = dtMenu;
        }
        else
            dtMenu = (DataTable)pageCls.Session["Menu"];
        
        for (int counter = 1; counter <= 4; counter++)
        {
            DataRow[] drowpar = dtMenu.Select("ParentID=" + counter);

            foreach (DataRow drParent in drowpar)
            {
                if (counter == 1)
                {
                    menu.Items.Add(new MenuItem(drParent["MenuName"].ToString(),
                                       drParent["MenuID"].ToString(),
                                       "", drParent["MenuLocation"].ToString()));
                }
                else
                    menu.Items.Add(new MenuItem(drParent["MenuName"].ToString(),
                        drParent["ParentID"].ToString()));               

                foreach (DataRow drChild in dtMenu.Select("ParentID=-" + counter))
                {
                    MenuItem mnu = null;
                    if (!((drChild["MenuName"].ToString() == "New Registration And Profile Management" || drChild["MenuName"].ToString() == "Forgot Password") && isAdmin == 'N'))
                    {
                        mnu = new MenuItem(drChild["MenuName"].ToString(),
                                       drChild["MenuID"].ToString(),
                                       "", drChild["MenuLocation"].ToString());

                        menu.FindItem(drParent["ParentID"].ToString()).ChildItems.Add(mnu);
                    }
                }
            }
        }   
    }

    
    public void DisplayLabels(DAL dal,bool isDisplayNavMenu)
    {     
        if (Session["UserName"] == null)
        {
            //ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Your Session got Expired, Please Login again.')</script>", false);
            //pageCls.Response.Redirect("~/Default.aspx");
            pageCls.Response.Redirect("~/LoginPage.aspx");
            return;
        }
        else
        {
            IList<string> userRightsColl = (IList<string>)Session["UserRightsColl"];
            Label welcomeName = (Label)pageCls.Master.FindControl("welcomeName");
            welcomeName.Visible = true;
            welcomeName.Text = "Welcome " + pageCls.Session["UserDisplayName"];            

            LinkButton lnkBtn = (LinkButton)pageCls.Master.FindControl("lnkLogOutBtn");
            lnkBtn.Visible = true;
            lnkBtn.Text = "LogOut";

            if (isDisplayNavMenu)
            {
                Menu menu = (Menu)pageCls.Master.FindControl("NavigationMenu");

                if (menu.Items.Count == 0)
                {
                    if (userRightsColl.Count != 0)
                        PopulateMenus(menu, 'N', dal);
                    else
                        PopulateMenus(menu, 'Y', dal);
                }
            }
        }        
    }

 

    public void DisplayJavaScriptMessage(Page page,string strMessage)
    {
        page.ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('" + strMessage + "')</script>", false);
    }

    public void DisplayJavaScriptMessageAndRedirect(Page page, string strMessage, string url)
    {
        page.ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('" + strMessage + "');document.location.href='" + url + "';</script>", false);
    }

    public void PopulateListBox(ListBox lstBox)
    {
        //connValue = ConfigurationManager.ConnectionStrings["EBSDEBookConn"].ToString();
        dal = new DAL(connValue);

        if (dal.ConnectDB(pageCls) == 'E')
            return;
        SqlDataReader sqlDtReader = dal.ExecuteReader("select DBSValues.dbsDescription,DBSValues.dbsID from DBSValues join DBSValuePerDocument on DBSValues.dbsID = DBSValuePerDocument.dbsID where DBSValuePerDocument.documentID=" + pageCls.Session["DocID"].ToString(), dal.SqlConnection, false, null);
        while (sqlDtReader.Read())
        {
            ListItem lstItem = new ListItem(sqlDtReader["dbsDescription"].ToString(), sqlDtReader["dbsID"].ToString());
            lstBox.Items.Add(lstItem);
        }
        sqlDtReader.Close();
        dal.DisconnectDB();
    }

      
   

    public StringBuilder GetDistributionName(DataTable dtToRecords, int rowCounter,string fromPage)
    {
        int colCounter = 0;
        if (fromPage == "MyDocuments.aspx")
            colCounter = 22;
         
        StringBuilder distributionName = new StringBuilder();
        if (dtToRecords.Rows[rowCounter][colCounter].ToString() != "")
            distributionName.Append(dtToRecords.Rows[rowCounter][colCounter].ToString().Trim());
        if (dtToRecords.Rows[rowCounter][++colCounter].ToString() != "")
            distributionName.Append(" " + dtToRecords.Rows[rowCounter][colCounter].ToString().Trim());
        if (dtToRecords.Rows[rowCounter][++colCounter].ToString() != "")
            distributionName.Append(" " + dtToRecords.Rows[rowCounter][colCounter].ToString().Trim());
        return distributionName;
    }

   
    public void ResetTheSessionVariables()
    {
        //Session["DevelopingSearchQuery"] = null;
        Session["SqlQueryForMyUploadDocs"] = null;
        Session["SqlQueryForMyReceivedDocs"] = null;
        Session["SqlSearchQueryForMyUploadDocs"] = null;
        Session["SqlSearchQueryForMyReceivedDocs"] = null;
        Session["MyChartClickDocStatus"] = null;
        Session["DtMyDocsOnFirstExecution"] = null;
        Session["CheckDBSSelection"] = null;
        Session["DocStatus"] = null;
        Session["IssuedByID"] = null;
        Session["RefNo"] = null;
        Session["ProjTitle"] = null;
        Session["TypeOfDoc"] = null;
        Session["CommitmentNo"] = null;
        Session["MyDocSearchStatus"] = null;
        Session["ProjectID"] = null;
        Session["DistributionNameID"] = null;
        Session["OriginSender"] = null;
        Session["TenderNo"] = null;
        Session["CompanyNo"] = null;
        Session["Subject"] = null;
        Session["DepartmentID"] = null;
        Session["DocDescription"] = null;
        Session["DBSMajorSubject"] = null;
        Session["IssuedByID"] = null;
        Session["DBSDetailedSubject"] = null;
        Session["SectionWiseDocStatus"] = null;
        Session["SectionWiseSearch"] = null;
        Session["MyChartClickDocStatus"] = null;
        Session["SearchAllDocs"] = null;
        Session["SearchMyDocs"] = null;         
    }

   

    public IList<string> GetUserAccessList(string userID, IList<string> userRightsColl)
    {         
        SqlConnection sqlConn = new SqlConnection(connValue);
        string sqlQuery = "SELECT UserPrivilege.accessID FROM UserSecurityProfile INNER JOIN UserPrivilege ON UserSecurityProfile.userProfileID = UserPrivilege.userProfileID INNER JOIN Contact ON UserSecurityProfile.userProfileID = Contact.userProfileID " +
        "WHERE (UserPrivilege.hasPrivilege = 0) AND (Contact.contactID = " + userID + ")";

        try
        {
            sqlConn.Open();
            SqlCommand sqlCom = new SqlCommand(sqlQuery, sqlConn);
            SqlDataReader sqlReader = sqlCom.ExecuteReader();
            while (sqlReader.Read())            
                userRightsColl.Add(sqlReader[0].ToString());                           
            sqlReader.Close();
        }
        catch (Exception ex)
        {
            DisplayJavaScriptMessage(pageCls, "Error occurred while performing database operation");
        }
        finally
        {
            sqlConn.Close();
        }
        return userRightsColl;
    }


    public short GetDaysByGivenEndDate(string endDate)
    {
        DateTime endDt = DateTime.ParseExact(endDate, "dd/MMM/yyyy", CultureInfo.InvariantCulture);         

        SqlConnection con = new SqlConnection(connValue);
        con.Open();
        SqlCommand cmd = new SqlCommand();

        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Connection = con;

        cmd.CommandText = "testSP";

        SqlParameter prm = cmd.Parameters.Add("@ad_startDate", SqlDbType.DateTime);
        prm.Value =DateTime.ParseExact(System.DateTime.Now.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture), "dd/MMM/yyyy", CultureInfo.InvariantCulture);
         //Convert.ToDateTime(, CultureInfo.InvariantCulture);

        prm = cmd.Parameters.Add("@ad_endDate", SqlDbType.DateTime);
        prm.Value = endDt;

        prm = cmd.Parameters.Add("@ai_workDays", SqlDbType.Int);
        prm.Direction = ParameterDirection.Output;

        //prm = cmd.Parameters.Add("@as_errMsg", SqlDbType.VarChar);
        //prm.Direction = ParameterDirection.Output;

        
        SqlDataReader dr = cmd.ExecuteReader();        
        con.Dispose();
        con.Close();

        return Convert.ToInt16(cmd.Parameters[2].Value);
    }

    public void RedirectToSpecificPage()
    {
        object refUrl = Session["UrlRef"];
        if (refUrl != null)
            pageCls.Response.Redirect(refUrl.ToString(), false);
        else
            pageCls.Response.Redirect("~/LoginPage.aspx", false);
    }


    public string GetEndDateByGivenNumberOfDays(short workDays,DateTime dtStartDate)
    {
        string endDate = null;
        try
        {
            SqlConnection con = new SqlConnection(connValue);
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Connection = con;
            con.Open();
            cmd.CommandText = "AddWorkdays";
            SqlParameter prm = cmd.Parameters.Add("@ad_startDate", SqlDbType.DateTime);
            prm.Value = dtStartDate; // System.DateTime.Now;
            prm = cmd.Parameters.Add("@actual_workDays", SqlDbType.Int);
            prm.Value = workDays;
            prm = cmd.Parameters.Add("@endDate", SqlDbType.DateTime);
            prm.Direction = ParameterDirection.Output;
            SqlDataReader dr = cmd.ExecuteReader();
            con.Dispose();
            con.Close();
            endDate =Convert.ToDateTime(cmd.Parameters[2].Value).ToString("dd/MMM/yyyy");
        }
        catch (Exception ex)
        {
            DisplayJavaScriptMessage(pageCls, "Error occurred while performing database operation");
        }
        return endDate;
    }

   
    public int GetNthIndex(string s, char t, int n)
    {
        int count = 0;
        for (int i = 0; i < s.Length; i++)
        {
            if (s[i] == t)
            {
                count++;
                if (count == n)
                {
                    return i;
                }
            }
        }
        return -1;
    }

    
  
    
   

    public void CheckCurrentDateSeparator()
    {
        if (System.DateTime.Now.ToString().Contains("-"))
            dateFormat = "dd-MMM-yyyy";
        else if (System.DateTime.Now.ToString().Contains("/"))
            dateFormat = "dd/MMM/yyyy";
    }

    

   
    public string AuthenticateEmailID(string emailAddress, DAL dal)
    {         
        string userName = null;
        //string contactId = null;
        try
        {
            //dal.ConnectDB();
            SqlCommand sqlCmd = new SqlCommand();
            if (dal.SqlConnection.State != ConnectionState.Open)
                dal.SqlConnection.Open();
            sqlCmd.Connection = dal.SqlConnection;
            //sqlCmd.CommandType = System.Data.CommandType.StoredProcedure;
            sqlCmd.CommandText = "select userName from Contact where emailAddress=@emailAddress";
            sqlCmd.Parameters.AddWithValue("@emailAddress", emailAddress);
            SqlDataReader sqlDtReader = sqlCmd.ExecuteReader();
            if (sqlDtReader.Read())
                userName = sqlDtReader["userName"].ToString();
            sqlDtReader.Close();

            //if (contactId != "")
            //{
            //    sqlCmd = null;
            //    sqlCmd = new SqlCommand();
            //    sqlCmd.Connection = dal.SqlConnection;
            //    sqlCmd.CommandText = "select userName from Users where emailAddress=@emailAddress";
            //    sqlCmd.Parameters.AddWithValue("@emailAddress", emailAddress);
            //    sqlDtReader = sqlCmd.ExecuteReader();
            //    if (sqlDtReader.Read())
            //        userName = sqlDtReader["userName"].ToString();
            //    sqlDtReader.Close();
            //}
        }
        catch (Exception ex)
        {

        }
        //finally
        //{
        //    dal.DisconnectDB();
        //}
        return userName;
    }

    

    public string AuthenticateUserNameOrEmailID(string userName, string emailAddress,DAL dal)
    {
        string result = "";
        try
        {
            //dal.ConnectDB();
            SqlCommand sqlCmd = new SqlCommand();
            if (dal.SqlConnection.State != ConnectionState.Open)
                dal.SqlConnection.Open();            
            sqlCmd.Connection = dal.SqlConnection;
            sqlCmd.CommandType = System.Data.CommandType.StoredProcedure;
            sqlCmd.CommandText = "AuthenticateUser";
            if (userName != "")
                sqlCmd.Parameters.AddWithValue("@userName", userName); 
            else
                sqlCmd.Parameters.AddWithValue("@userName", DBNull.Value);
            if(emailAddress!="")
                sqlCmd.Parameters.AddWithValue("@emailAddress", emailAddress);
            else
                sqlCmd.Parameters.AddWithValue("@emailAddress", DBNull.Value);
            sqlCmd.Parameters.AddWithValue("@contactID", SqlDbType.SmallInt).Direction = ParameterDirection.Output;
            sqlCmd.ExecuteNonQuery();
            result = sqlCmd.Parameters["@contactID"].Value.ToString();                       
        }
        catch (Exception ex)
        {
            result = "Exception";
        }
        //finally
        //{
        //    dal.DisconnectDB();
        //}
        return result;
    }

    public int AuthenticateUserName(string userName, string emailAddress, DAL dal, bool isLogin)
    {
        int result = 0;
        try
        {
            //dal.ConnectDB();
            SqlCommand sqlCmd = new SqlCommand();
            if (dal.SqlConnection.State != ConnectionState.Open)
                dal.SqlConnection.Open();
            sqlCmd.Connection = dal.SqlConnection;
            sqlCmd.CommandType = System.Data.CommandType.StoredProcedure;
            sqlCmd.CommandText = "AuthenticateUser";
            sqlCmd.Parameters.AddWithValue("@userName", userName);
            //if (emailAddress != "")
            sqlCmd.Parameters.AddWithValue("@emailAddress", DBNull.Value);
            sqlCmd.Parameters.AddWithValue("@userID", SqlDbType.SmallInt).Direction = ParameterDirection.Output;
            sqlCmd.ExecuteNonQuery();
            result = (int)sqlCmd.Parameters["@userID"].Value;
            
        }
        catch (Exception ex)
        {

        }
        //finally
        //{
        //    dal.DisconnectDB();
        //}
        return result;
    }



   


   

   
    public string EncryptPassword(string passWord, ref string userGuid)
    {
        // First create a new Guid for the user. This will be unique for each user
        Guid guid = System.Guid.NewGuid();
        userGuid = guid.ToString();
        // Hash the password together with our unique userGuid

        string hashedPassword = null; // Create(passWord + userGuid).ToString();
        return hashedPassword;
    }

    // encrypt password
    public string authenticatePassword(string passWord, string userGuid)
    {
        //Hash the password together with our unique userGuid
        string hashedPassword = System.Security.Cryptography.HMACSHA1.Create(passWord + userGuid).ToString();
        return hashedPassword;
    }

    public void SetBackColorOfGridViewRows(GridViewRowEventArgs e, System.Drawing.Color backColor, string docType, string owner, int totalCols)
    {
        if (owner == "No")
            e.Row.Cells[0].BackColor = backColor; //e.Row.Cells[0].ForeColor = System.Drawing.Color.Blue;            
         
        e.Row.Cells[1].BackColor = backColor;
        e.Row.Cells[2].BackColor = backColor;         
        if (docType == "MyDocuments")
        {
            e.Row.Cells[3].BackColor = backColor;
            e.Row.Cells[4].BackColor = backColor;
            e.Row.Cells[5].BackColor = backColor;
            e.Row.Cells[6].BackColor = backColor;
            if (totalCols == 8)
                e.Row.Cells[7].BackColor = backColor;
        }
    }
   
}