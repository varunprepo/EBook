﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.Services;
using System.Data.SqlClient;
using System.Configuration;
using System.Web.Script.Services;
using PropertyLayer;

/// <summary>
/// Summary description for Service_CS
/// </summary>
[WebService(Namespace = "http://tempuri.org/")]
[WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
// To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
[System.Web.Script.Services.ScriptService]
public class Service : System.Web.Services.WebService {

    public Service () {

        //Uncomment the following line if using designed components 
        //InitializeComponent(); 
    }
    [WebMethod]
    [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
    public string[] GetCustomers(string prefix) 
    {
        List<string> customers = new List<string>();
        string strQuery = string.Empty;      
        
        using (SqlConnection conn = new SqlConnection())
        {
            conn.ConnectionString = ConfigurationManager.ConnectionStrings["EBSDEBookConn"].ConnectionString;
            strQuery = "SELECT Distinct commitment_no, commitment_no FROM  PCM_CNMT_TABLE WHERE commitment_no like '%' + @SearchText + '%'";
            
            using (SqlCommand cmd = new SqlCommand())
            {
                cmd.CommandText = strQuery;
                cmd.Parameters.AddWithValue("@SearchText", prefix);
                cmd.Connection = conn;
                conn.Open();
                using (SqlDataReader sdr = cmd.ExecuteReader())
                {
                    while (sdr.Read())
                    {
                        customers.Add(string.Format("{0}-{1}", sdr["commitment_no"], sdr["commitment_no"]));                        
                    }
                }
                conn.Close();
            }
        }
     
        getContractData(customers,strQuery,prefix);
        return customers.ToArray();
    }

    [WebMethod]
    [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
    public string[] GetCustomersNCP(string prefix)
    {
        List<string> customers = new List<string>();
        string strQuery = string.Empty;
       
        using (SqlConnection conn = new SqlConnection())
        {
            conn.ConnectionString = ConfigurationManager.ConnectionStrings["TCMSConn"].ConnectionString;
            strQuery = "SELECT bidder_ID,Contract_No FROM CONTRACTORS WHERE Contract_No like '%' + @SearchText + '%'";

            using (SqlCommand cmd = new SqlCommand())
            {
                cmd.CommandText = strQuery;
                cmd.Parameters.AddWithValue("@SearchText", prefix);
                cmd.Connection = conn;
                conn.Open();
                using (SqlDataReader sdr = cmd.ExecuteReader())
                {
                    while (sdr.Read())
                    {
                        customers.Add(string.Format("{0}-{1}", sdr["Contract_No"], sdr["bidder_ID"]));
                    }
                }
                conn.Close();
            }
        }

        getContractData(customers, strQuery, prefix);
        return customers.ToArray();
    }

    [WebMethod]
    [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
    public string[] GetC_NoPayment(string prefix)
    {
        List<string> customers = new List<string>();
        string strQuery = string.Empty;

        using (SqlConnection conn = new SqlConnection())
        {
            conn.ConnectionString = ConfigurationManager.ConnectionStrings["EBSDEBookConn"].ConnectionString;
            strQuery = "SELECT payID,commitmentNo FROM Payment WHERE commitmentNo like '%' + @SearchText + '%'";

            using (SqlCommand cmd = new SqlCommand())
            {
                cmd.CommandText = strQuery;
                cmd.Parameters.AddWithValue("@SearchText", prefix);
                cmd.Connection = conn;
                conn.Open();
                using (SqlDataReader sdr = cmd.ExecuteReader())
                {
                    while (sdr.Read())
                    {
                        customers.Add(string.Format("{0}-{1}", sdr["commitmentNo"], sdr["payID"]));
                    }
                }
                conn.Close();
            }
        }

        getContractData(customers, strQuery, prefix);
        return customers.ToArray();
    }
    private void getContractData(List<string> customers, string strQuery, string prefix)
    {
        
    }//
}
