﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Activation;
using System.ServiceModel.Web;
using System.Text;

[ServiceContract(Namespace = "")]
[AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Allowed)]
public class TSSService
{
	// To use HTTP GET, add [WebGet] attribute. (Default ResponseFormat is WebMessageFormat.Json)
	// To create an operation that returns XML,
	//     add [WebGet(ResponseFormat=WebMessageFormat.Xml)],
	//     and include the following line in the operation body:
	//         WebOperationContext.Current.OutgoingResponse.ContentType = "text/xml";
	[OperationContract]
    [WebInvoke(Method = "GET", ResponseFormat = WebMessageFormat.Json)]
    public string[] GetProjCodes(string prefix)
	{
        string[] options = ExecuteSql_TCMS("SELECT proj_id,project_code FROM PROJECTS WHERE project_code like '%' + @SearchText + '%' ORDER BY project_code", prefix);
        return options;
    }

    public static string ConnectionString_TCMS
    {
        get
        {
            return System.Configuration.ConfigurationManager.ConnectionStrings["TCMSConn"].ConnectionString;
        }
    }
    public string[] ExecuteSql_TCMS(string strQuery, string prefix)
    {
        List<string> projCodes = new List<string>();
        SqlDataAdapter da;
        DataSet ds;
        ds = new DataSet();
        //StringBuilder options = new StringBuilder();
        string json = null;
        SqlConnection conn = new SqlConnection(ConnectionString_TCMS);
        try
        {
            if (conn.State == ConnectionState.Open)
            {
                conn.Close();
            }
            conn.Open();
            using (SqlCommand cmd = new SqlCommand())
            {
                cmd.CommandText = strQuery;
                cmd.Parameters.AddWithValue("@SearchText", prefix);
                cmd.Connection = conn;
                
                using (SqlDataReader sdr = cmd.ExecuteReader())
                {
                    while (sdr.Read())
                    {
                        projCodes.Add(string.Format("{0}", sdr["project_code"]));
                    }
                }
                //conn.Close();
            }
            //da = new SqlDataAdapter(sql, conn);
            //da.Fill(ds);
            //json = Newtonsoft.Json.JsonConvert.SerializeObject(ds.Tables[0]); //   JsonConvert.SerializeObject(dataSet, Formatting.Indented);
            //options = Newtonsoft.Json.JsonConvert.SerializeObject(ds.Tables[0]);
            //foreach (DataRow row in ds.Tables["Table"].Rows)
            //{
            //    //options.Append("<option value='" + row["proj_id"] + "'>" + row["project_code"] + "</option>");
            //    options.Append(row["proj_id"] + "," + row["project_code"]);
            //    //options += "<option value='" + row["proj_id"] + "'>" + row["project_code"] + "</option>";
            //}
           
        }
        catch (Exception ex)
        {
            return null;
        }
        finally
        {
            conn.Close();
            conn.Dispose();
        }
        return projCodes.ToArray();//.ToString();
    }
	 
}
