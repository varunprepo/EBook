﻿using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Activation;
using System.ServiceModel.Web;
using System.Text;

[ServiceContract(Namespace = "")]
[AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Allowed)]
public class SurveyRequest
{
    // To use HTTP GET, add [WebGet] attribute. (Default ResponseFormat is WebMessageFormat.Json)
    // To create an operation that returns XML,
    //     add [WebGet(ResponseFormat=WebMessageFormat.Xml)],
    //     and include the following line in the operation body:
    //         WebOperationContext.Current.OutgoingResponse.ContentType = "text/xml";
    [OperationContract]
    [WebInvoke(Method = "GET", ResponseFormat = WebMessageFormat.Json)]
    public string InsertData(string reqID, string objID)
    {
        // For finding the max value and inserting into LUT table
        return Insert_LUT_LocationTable(reqID, objID);
    }

    private string Insert_LUT_LocationTable(string requestId, string objID)
    {
        string locID = null;

        OracleConnection con = new OracleConnection(ConfigurationManager.ConnectionStrings["SurveyConnNewOracle"].ConnectionString);
        OracleCommand cmd = new OracleCommand();
        cmd.CommandType = CommandType.Text;
        cmd.Connection = con;

        string sqlstring = null;
        //string sqlstring = "select max(location_id) as MaxLoc_ID from SERVICE_LOCATION";
        //cmd.CommandText = sqlstring;

        try
        {
            con.Open();
            //OracleDataReader oraReader = cmd.ExecuteReader();

            //if(oraReader.Read())
            //{
            //locID = oraReader["MaxLoc_ID"].ToString();
            //oraReader.Close();
            //oraReader.Dispose();
            sqlstring = "update SERVICE_LOCATION set LOCATION_ID=:LOCATIONID where OBJECTID=:OBJECTID"; // + locID + "," + locID + ", " + requestId + ")";
            cmd.Parameters.Add(new OracleParameter("OBJECTID", objID));
            cmd.Parameters.Add(new OracleParameter("LOCATIONID", objID));
            //cmd.Parameters.Add(new OracleParameter("REQUESTID", requestId));
            cmd.CommandText = sqlstring;
            cmd.ExecuteNonQuery();
            cmd.Dispose();

            cmd = new OracleCommand();
            cmd.CommandType = CommandType.Text;
            cmd.Connection = con;
            sqlstring = "INSERT INTO SERVICE_LUT_LOCATION_SURVEY(OBJECTID,LOCATION_ID, REQUEST_ID) VALUES(:OBJECTID,:LOCATIONID,:REQUESTID)"; // + locID + "," + locID + ", " + requestId + ")";
            cmd.Parameters.Add(new OracleParameter("OBJECTID", objID));
            cmd.Parameters.Add(new OracleParameter("LOCATIONID", objID));
            cmd.Parameters.Add(new OracleParameter("REQUESTID", requestId));
            cmd.CommandText = sqlstring;
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            locID = objID;
            //}

        }
        catch (Exception ex)
        {
            locID = "Error";
        }
        finally
        {
            con.Close();
        }
        return locID = "Error";
    }


    // Add more operations here and mark them with [OperationContract]
}
