﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Web.UI;

/// <summary>
/// Summary description for DAL
/// </summary>
public class DAL
{
        private string dbPath = null;
        private SqlConnection mConnection = null;
        SqlDataAdapter da;
        SqlCommand sqlCmd;
        SqlDataReader sqlDtReader;
        public SqlConnection SqlConnection
        {
            set { mConnection = value; }
            get { return mConnection; }
        }

        public DAL(string databasePath)
        {
           dbPath = databasePath;            
        }
        public char ConnectDB(Page pg)
        {
            try
            {
                if (mConnection != null)
                {
                    //Close the connection if already opened 
                    if (mConnection.State == System.Data.ConnectionState.Open)
                    {
                        mConnection.Close();
                    }
                }
                             
                mConnection = new SqlConnection();
                mConnection.ConnectionString = dbPath;
                mConnection.Open();
                SqlConnection = mConnection;     
            }
            catch (Exception ex)
            {
                pg.ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Error occurred "+ex.Message+"')</script>", false);

                
                return 'E';
            }
            return ' ';
        }


        public void DisconnectDB()
        {
            if (mConnection != null)
            {
                mConnection.Close();
                mConnection.Dispose();
            }
            
            if (SqlConnection != null)
                    SqlConnection.Close();
                          
        }

        public DataSet FillDropdown(string sFillDdl)
        {
            return ExecuteSql(sFillDdl);
        }

        public DataSet ExecuteSql(string sql)
        {
            SqlDataAdapter da;
            DataSet ds;
            ds = new DataSet();
            try
            {
                if (mConnection.State == ConnectionState.Open)
                {
                    mConnection.Close();
                }
                mConnection.Open();
                da = new SqlDataAdapter(sql, mConnection);
                da.Fill(ds);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                mConnection.Close();
                mConnection.Dispose();
            }
            return ds;
        }
        public DataTable GetDataFromDB(string dataTabName, string sqlQuery)
        {
            DataTable table = null;
            SqlConnection conn = null;
            try
            {
                table = new DataTable(dataTabName);
                conn = new SqlConnection(dbPath);
                conn.Open();
                sqlCmd = new SqlCommand(@sqlQuery, conn);
                sqlCmd.CommandTimeout = 80;
                da = new SqlDataAdapter(sqlCmd);
                da.Fill(table);
            }
            catch (Exception ex)
            {
                return null;
            }
            finally
            {
                da.Dispose();
                conn.Close();
            }
            return table;
        }

        public int ExecuteNonQuery(string sqlString, SqlConnection sqlConn,bool isTransaction,SqlTransaction sqlTrans)
        {
            int exeResult = 0;
            SqlCommand sqlCommand = new SqlCommand(sqlString, sqlConn);
            if (isTransaction)
                sqlCommand.Transaction = sqlTrans;
            exeResult = sqlCommand.ExecuteNonQuery();
            sqlCommand.Dispose();
            return exeResult;
        }

        public SqlDataReader ExecuteReader(string sqlString, SqlConnection sqlConn, bool isTransaction, SqlTransaction sqlTrans)
        {
            SqlDataReader sqlReader = null;
            SqlCommand sqlCommand = new SqlCommand(sqlString, sqlConn);
            if (isTransaction)
                sqlCommand.Transaction = sqlTrans;
            sqlReader = sqlCommand.ExecuteReader();
            return sqlReader;
        }      
        
}