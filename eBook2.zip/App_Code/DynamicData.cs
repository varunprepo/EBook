﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Data;

using System.IO;
using System.Drawing;
using Datalayer;
using System.Configuration;
using System.Collections;
using System.Web.UI;  


/// <summary>
/// Summary description for DynamicData
/// </summary>
public class DynamicData
{
    string connValue = System.Configuration.ConfigurationManager.ConnectionStrings["EBSDEBookConn"].ConnectionString;
	public DynamicData()
	{
		//
		// TODO: Add constructor logic here
		//
	}


    public DataTable getHourrlyData(string _year, string _Month, string _section) //, string x_Value, string y_Value, string z_Value
    {
        string sqlQuery = " SELECT * FROM (SELECT CAST(Createdate AS DATE) [Date],  DATEPART(hour,Createdate) [Hour], Count(1)  [Sales Count]  FROM Job where year(Createdate) = " + _year + " and Month(Createdate) = " + _Month + " " +
          " GROUP BY CAST(Createdate AS DATE),  DATEPART(hour,Createdate)) AS HourlySalesData PIVOT( SUM([Sales Count]) FOR [Hour] IN ([1], [2], [3], [4], [5], [6], [7], [8], [9], [10],[11], [12], [13], [14], [15], [16], " +
                     "  [17], [18], [19], [20], [21], [22], [23],[24])) AS DatePivot";     


        SqlConnection objCon = new SqlConnection(connValue);
        SqlCommand objCmd = new SqlCommand(sqlQuery, objCon);

        DataSet dsTndrStaff = new DataSet();
        objCmd.CommandText = sqlQuery;
        objCmd.Connection = objCon;

        SqlDataAdapter daTndrStaff = new SqlDataAdapter(objCmd);
        daTndrStaff.Fill(dsTndrStaff);

        return dsTndrStaff.Tables[0];
             
    }
    public DataTable getQuaterlyData(string _year, string _Month, string _section) //, string x_Value, string y_Value, string z_Value
    {
        string sqlQuery = " SELECT Year, QPivot.[1] As Q1, QPivot.[2] As Q2,  QPivot.[3] As Q3, QPivot.[4] As Q4 FROM (SELECT YEAR(jobReceivedDate) [Year], " +
                    " DATEPART(QUARTER, jobReceivedDate) [Quarter],   COUNT(1) [Sales Count]  FROM Job where sectionID = " + _section + " GROUP BY YEAR(jobReceivedDate), DATEPART(QUARTER,jobReceivedDate)) AS QuarterlyData " +
              " PIVOT( SUM([Sales Count]) FOR QUARTER IN ([1],[2],[3],[4])) AS QPivot order by year desc";
      
        SqlConnection objCon = new SqlConnection(connValue);
        SqlCommand objCmd = new SqlCommand(sqlQuery, objCon);

        DataSet dsTndrStaff = new DataSet();
        objCmd.CommandText = sqlQuery;
        objCmd.Connection = objCon;


        SqlDataAdapter daTndrStaff = new SqlDataAdapter(objCmd);
        daTndrStaff.Fill(dsTndrStaff);

   
        return dsTndrStaff.Tables[0];

    }
    public DataTable getYearAndmonthWiseJobCount(string _section)
    {
        // http://sqlhints.com/tag/monthly-sum-data-in-sql-serve/

        //https://www.plus2net.com/sql_tutorial/date-group-by.php

       
       string sqlQuery = string.Empty;

       sqlQuery = "SELECT * FROM (SELECT YEAR(Job.jobReceivedDate) [Year], DATENAME(MONTH, Job.jobReceivedDate) [Month], COUNT(1) [Sales Count] FROM Job where job.sectionID = " + _section + " " +
       " GROUP BY YEAR(Job.jobReceivedDate), DATENAME(MONTH, Job.jobReceivedDate)) AS MontlySalesData PIVOT( SUM([Sales Count]) FOR Month IN ([January],[February],[March],[April],[May], " +
       " [June],[July],[August],[September],[October],[November], [December])) AS MNamePivot order by year desc";       

        SqlConnection objCon = new SqlConnection(connValue);
        SqlCommand objCmd = new SqlCommand(sqlQuery, objCon);

        DataSet dsTndrStaff = new DataSet();
        objCmd.CommandText = sqlQuery;
        objCmd.Connection = objCon;

        SqlDataAdapter daTndrStaff = new SqlDataAdapter(objCmd);
        daTndrStaff.Fill(dsTndrStaff);

        return dsTndrStaff.Tables[0];
    }

    public IList<string> getTableFieldsFromSP(string tblName)
    {
        IList<string> feildsColl = new List<string>();

        if (tblName.Equals("JobOrder Info"))
        {
            feildsColl.Add("Job.jobNo");
            feildsColl.Add("Job.contractNo");
            feildsColl.Add("Job.projectTitle");

            feildsColl.Add("JobType.jobTypeName");
            feildsColl.Add("JobStatus.jobStatusName");

            feildsColl.Add("Job.jobReceivedDate");
            feildsColl.Add("Job.jobStatusClosedDate");

            feildsColl.Add("Job.Remarks");

            feildsColl.Add("Affair.affairName");
            feildsColl.Add("Department.deptName");

            feildsColl.Add("Company.cmpName AS Contractor");
            feildsColl.Add("Company_1.cmpName AS Consultant");
        }

        if (tblName.Equals("Document Info"))
        {
            feildsColl.Add("[Document].DocSubject");
            feildsColl.Add("[Document].referenceNo AS OpenLetter");
            feildsColl.Add("Document_1.referenceNo AS ClosedLetter");
        }

        if (tblName.Equals("Cost Info"))
        {
            feildsColl.Add("JobVOSI.contractorAmt");
            feildsColl.Add("JobVOSI.ebsdAmt");
            feildsColl.Add("JobVOSI.Remarks");
        }

        if (tblName.Equals("EOT Info"))
        {
            feildsColl.Add("JobVOSI.contractorEOT");
            feildsColl.Add("JobVOSI.ebsdEOT");
            feildsColl.Add("JobVOSI.RemarksForTime");
            feildsColl.Add("Contact.displayName AS VOCreatedBY");
        }

        if (tblName.Equals("Staff Info"))
        {
            feildsColl.Add("Contact.firstName");
            feildsColl.Add("Contact_1.displayName");
            feildsColl.Add("Contact_2.displayName");
        }


        if (tblName.Equals("Payment Info"))
        {
            feildsColl.Add("Payment.ContractStartDate");
            feildsColl.Add("Payment.ContractAmount");
            feildsColl.Add("Payment.AdjustedContractAmt");

            feildsColl.Add("Payment.ProvisionNumber");
            feildsColl.Add("Payment.BudgetReferenceNo");
            feildsColl.Add("Payment.RemainingCost");

            feildsColl.Add("Payment.PrevNetCertifiedAmount");
            feildsColl.Add("Payment.PrevTotalCertifiedAmount");
            feildsColl.Add("Payment.djustedCompletionDate");

            feildsColl.Add("Payment.RetentionReleasedAmt");
        }

        return feildsColl;
    }

    public void getJobTypeChart(SqlCommand _sqlCmd, System.Web.UI.DataVisualization.Charting.Chart onGoingTasksPerSectionChart, string _section)
    {
        DataSet dsTndr = new DataSet();
        string sqlQueryChart = null;
        string strSeriesName = string.Empty;

        strSeriesName = "jobTypeName";


        sqlQueryChart = "SELECT COUNT(Job.jobID) AS JobCnt, JobType.jobTypeName " +
                                 " FROM JobVOSI INNER JOIN Job ON JobVOSI.jobID = Job.jobID INNER JOIN " +
                         " JobStatus ON Job.jobStatusID = JobStatus.jobStatusID INNER JOIN JobType ON Job.jobTypeID = JobType.jobTypeID INNER JOIN [Document] ON Job.docRefID = [Document].documentID INNER JOIN " +
                         " Company ON Job.contractorID = Company.companyID INNER JOIN Company AS Company_1 ON Job.consultantID = Company_1.companyID LEFT OUTER JOIN Contact ON JobVOSI.createdBy = Contact.contactID LEFT OUTER JOIN " +
                          " [Document] AS Document_1 ON Job.closedDocRefID = Document_1.documentID LEFT OUTER JOIN PSACostDesc ON JobVOSI.voCatID = PSACostDesc.jobCostID LEFT OUTER JOIN PSAJobTime ON JobVOSI.voTimeCatID = PSAJobTime.jobTimeID LEFT OUTER JOIN " +
                         " StakeHolder ON JobVOSI.invSH = StakeHolder.stakeID WHERE        (@jobTypeID IS NULL OR Job.jobTypeID = @jobTypeID) AND (@contractNo IS NULL OR Job.contractNo = @contractNo) AND (@datefrom IS NULL OR Job.jobReceivedDate >= CONVERT(NVARCHAR, @datefrom, 106)) " +
        " AND (@dateTo IS NULL OR Job.jobReceivedDate <= CONVERT(NVARCHAR, @dateTo, 106)) AND (@jobStatusID IS NULL OR Job.jobStatusID = @jobStatusID) AND (@voCreatedBy IS NULL OR JobVOSI.createdBy = @voCreatedBy) AND (Job.SectionID = " + _section + ")  GROUP BY JobType.jobTypeName";

        strSeriesName = "jobTypeName";


        _sqlCmd.CommandText = sqlQueryChart;

        SqlDataAdapter daTndr = new SqlDataAdapter(_sqlCmd);
        daTndr.Fill(dsTndr);
        if (dsTndr.Tables[0].Rows.Count != 0)
        {
            onGoingTasksPerSectionChart.DataSource = dsTndr.Tables[0].DefaultView;

            onGoingTasksPerSectionChart.Series["Series1"].XValueMember = strSeriesName;
            onGoingTasksPerSectionChart.Series["Series1"].YValueMembers = "JobCnt";

            dsTndr.Tables.Clear();

            onGoingTasksPerSectionChart.ChartAreas[0].AxisX.MajorGrid.Enabled = false;
            onGoingTasksPerSectionChart.ChartAreas[0].AxisX.MinorGrid.Enabled = false;
            onGoingTasksPerSectionChart.ChartAreas[0].AxisY.MajorGrid.Enabled = false;
            onGoingTasksPerSectionChart.ChartAreas[0].AxisY.MinorGrid.Enabled = false;

            onGoingTasksPerSectionChart.ChartAreas[0].AxisX.LabelStyle.Angle = 30;
            onGoingTasksPerSectionChart.ChartAreas[0].AxisX.LabelStyle.ForeColor = Color.Maroon;

            onGoingTasksPerSectionChart.ChartAreas[0].AxisX.Interval = 1;
        }
    }

    private void EBDAmountChart(SqlCommand _sqlCmd, System.Web.UI.DataVisualization.Charting.Chart chartForCost, string _section)
    {       

        string sqlQuery = string.Empty;   

        string  strSeriesName = "jobTypeName";

        sqlQuery = "SELECT SUM(JobVOSI.ebsdAmt) AS EBSDAmount, JobType.jobTypeName " +
                                 " FROM JobVOSI INNER JOIN Job ON JobVOSI.jobID = Job.jobID INNER JOIN " +
                         " JobStatus ON Job.jobStatusID = JobStatus.jobStatusID INNER JOIN JobType ON Job.jobTypeID = JobType.jobTypeID INNER JOIN [Document] ON Job.docRefID = [Document].documentID INNER JOIN " +
                         " Company ON Job.contractorID = Company.companyID INNER JOIN Company AS Company_1 ON Job.consultantID = Company_1.companyID LEFT OUTER JOIN Contact ON JobVOSI.createdBy = Contact.contactID LEFT OUTER JOIN " +
                          " [Document] AS Document_1 ON Job.closedDocRefID = Document_1.documentID LEFT OUTER JOIN PSACostDesc ON JobVOSI.voCatID = PSACostDesc.jobCostID LEFT OUTER JOIN PSAJobTime ON JobVOSI.voTimeCatID = PSAJobTime.jobTimeID LEFT OUTER JOIN " +
                         " StakeHolder ON JobVOSI.invSH = StakeHolder.stakeID WHERE        (@jobTypeID IS NULL OR Job.jobTypeID = @jobTypeID) AND (@contractNo IS NULL OR Job.contractNo = @contractNo) AND (@datefrom IS NULL OR Job.jobReceivedDate >= CONVERT(NVARCHAR, @datefrom, 106)) " +
        " AND (@dateTo IS NULL OR Job.jobReceivedDate <= CONVERT(NVARCHAR, @dateTo, 106)) AND (@jobStatusID IS NULL OR Job.jobStatusID = @jobStatusID) AND (@voCreatedBy IS NULL OR JobVOSI.createdBy = @voCreatedBy) GROUP BY JobType.jobTypeName";

        strSeriesName = "jobTypeName";

        _sqlCmd.CommandText = sqlQuery;

        DataSet dsTndr = new DataSet();
        SqlDataAdapter daTndr = new SqlDataAdapter(_sqlCmd);

        daTndr.Fill(dsTndr);

        if (dsTndr.Tables[0].Rows.Count != 0)
        {
            chartForCost.DataSource = dsTndr.Tables[0].DefaultView;

            chartForCost.Series["Series1"].XValueMember = strSeriesName;
            chartForCost.Series["Series1"].YValueMembers = "EBSDAmount";

            dsTndr.Tables.Clear();

            chartForCost.ChartAreas[0].AxisX.MajorGrid.Enabled = false;
            chartForCost.ChartAreas[0].AxisX.MinorGrid.Enabled = false;
            chartForCost.ChartAreas[0].AxisY.MajorGrid.Enabled = false;
            chartForCost.ChartAreas[0].AxisY.MinorGrid.Enabled = false;

            chartForCost.ChartAreas[0].AxisX.LabelStyle.Angle = 30;
            chartForCost.ChartAreas[0].AxisX.LabelStyle.ForeColor = Color.Maroon;

            chartForCost.ChartAreas[0].AxisX.Interval = 1;
        }

    }

    public void v(SqlCommand _sqlCmd, System.Web.UI.DataVisualization.Charting.Chart chartStaffCount, string _section)
    {
        DataSet ds = new DataSet();
        SqlDataAdapter da = new SqlDataAdapter(_sqlCmd);
        da.Fill(ds);

        if (ds.Tables[0].Rows.Count != 0)
        {
            chartStaffCount.DataSource = ds.Tables[0].DefaultView;

            chartStaffCount.Series["Series1"].XValueMember = "firstName";
            chartStaffCount.Series["Series1"].YValueMembers = "jCnt";

            ds.Tables.Clear();

            chartStaffCount.ChartAreas[0].AxisX.MajorGrid.Enabled = false;
            chartStaffCount.ChartAreas[0].AxisX.MinorGrid.Enabled = false;
            chartStaffCount.ChartAreas[0].AxisY.MajorGrid.Enabled = false;
            chartStaffCount.ChartAreas[0].AxisY.MinorGrid.Enabled = false;

            chartStaffCount.ChartAreas[0].AxisX.LabelStyle.Angle = 30;
            chartStaffCount.ChartAreas[0].AxisX.LabelStyle.ForeColor = Color.Maroon;

            chartStaffCount.ChartAreas[0].AxisX.Interval = 1;
        }
    }

    public void GetChartData(DataTable dtNew, System.Web.UI.DataVisualization.Charting.Chart inputChart, string _section,string xValue,string yValue)
    {
        if (dtNew.Rows.Count != 0)
        {
            inputChart.DataSource = dtNew.DefaultView;

            inputChart.Series["Series1"].XValueMember = xValue;
            inputChart.Series["Series1"].YValueMembers = yValue;

            dtNew.Clear();

            inputChart.ChartAreas[0].AxisX.MajorGrid.Enabled = false;
            inputChart.ChartAreas[0].AxisX.MinorGrid.Enabled = false;
            inputChart.ChartAreas[0].AxisY.MajorGrid.Enabled = false;
            inputChart.ChartAreas[0].AxisY.MinorGrid.Enabled = false;

            inputChart.ChartAreas[0].AxisX.LabelStyle.Angle = 30;
            inputChart.ChartAreas[0].AxisX.LabelStyle.ForeColor = Color.Maroon;

            inputChart.ChartAreas[0].AxisX.Interval = 1;
        }
    }
    public DataTable GetData(string sqlQuery,  string _fromDate, string _toDate, string _cntrNo, string _jobTypeID, string _StaffName)
    {
        DataTable dt = new DataTable();
       
        Int16 jobType;
        Int16.TryParse(_jobTypeID, out jobType); 

        string prjCode = string.Empty;
        prjCode = _cntrNo;

        string txtfrom = string.Empty;
        if (_fromDate != "")
            txtfrom = _fromDate;

        string txtTo = string.Empty;
        if (_toDate != "")
            txtTo = _toDate;        

        using (SqlConnection objCon = new SqlConnection(connValue))
        {
            using (SqlCommand objCmd = new SqlCommand(sqlQuery, objCon))
            {
                SqlDataAdapter objDA = new SqlDataAdapter(objCmd);

                objDA.SelectCommand.CommandText = objCmd.CommandText.ToString();

                objCmd.Parameters.AddWithValue("@jobTypeID", System.DBNull.Value);

                if (prjCode != "")
                    objCmd.Parameters.AddWithValue("@contractNo", prjCode);
                else
                    objCmd.Parameters.AddWithValue("@contractNo", System.DBNull.Value);

                if (txtfrom != "")
                    objCmd.Parameters.AddWithValue("@datefrom", txtfrom);
                else
                    objCmd.Parameters.AddWithValue("@datefrom", System.DBNull.Value);

                if (txtTo != "")
                    objCmd.Parameters.AddWithValue("@dateTo", txtTo);
                else
                    objCmd.Parameters.AddWithValue("@dateTo", System.DBNull.Value);

                objCmd.Parameters.AddWithValue("@jobStatusID", System.DBNull.Value);

                objCmd.Parameters.AddWithValue("@voCreatedBy", System.DBNull.Value);

                if (_StaffName != "")       
                    objCmd.Parameters.AddWithValue("@StaffName", _StaffName);             
                else        
                    objCmd.Parameters.AddWithValue("@StaffName", System.DBNull.Value);           

                objDA.Fill(dt);
            }
        }
        
        return dt;
    }
}