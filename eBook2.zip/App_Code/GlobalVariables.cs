﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Configuration;

/// <summary>
/// Summary description for GlobalVariables
/// </summary>
public class GlobalVariables
{
    string _appId = "SRVYREQ";
    string _connectionString = ConfigurationManager.AppSettings["ConnectionString"];
    string _generalExceptionMessage = "An exception has occured in Function :- ";
    string _surveyInfoTable = "SURVEY_INFO";
    string _attachmentTable = "SERVICE_ATTACHMENT";
   
    public GlobalVariables()
    {
    }

   

    public string AppId
    {
        get { return _appId; }
    }

    public string ConnectionString
    {
        get { return _connectionString; }
    }

    public string GeneralExceptionMessage
    {
        get { return _generalExceptionMessage; }
    }
    public string SurveyInfoTable
    {
        get { return _surveyInfoTable; }
    }

    public string AttachmentTable
    {
        get { return _attachmentTable; }
    }
}


