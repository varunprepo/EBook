﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for JsonCTSCls
/// </summary>
public class JsonCTSCls
{
	public JsonCTSCls()
	{
		//
		// TODO: Add constructor logic here
		//
	}

    public class Info
    {
        public string name { get; set; }
        public string _postman_id { get; set; }
        public string description { get; set; }
        public string schema { get; set; }
    }

    public class Formdata
    {
        public string key { get; set; }
        public string value { get; set; }
        public string description { get; set; }
        public string type { get; set; }
    }

    public class Body
    {
        public string mode { get; set; }
        public List<Formdata> formdata { get; set; }
        public string raw { get; set; }
    }

    public class Request
    {
        public object url { get; set; }
        public string method { get; set; }
        public List<object> header { get; set; }
        public Body body { get; set; }
        public string description { get; set; }
    }

    public class Item2
    {
        public string name { get; set; }
        public Request request { get; set; }
        public List<object> response { get; set; }
    }

    public class Item
    {
        public string name { get; set; }
        public string description { get; set; }
        public List<Item2> item { get; set; }
    }

    public class RootObject
    {
        public List<object> variables { get; set; }
        public Info info { get; set; }
        public List<Item> item { get; set; }
    }
}