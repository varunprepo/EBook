﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

public class CustomReportCredentials
{
    private string p;
    private string p_2;
    private string p_3;

    public CustomReportCredentials(string p, string p_2, string p_3)
    {
        // TODO: Complete member initialization
        this.p = p;
        this.p_2 = p_2;
        this.p_3 = p_3;
    }
}
