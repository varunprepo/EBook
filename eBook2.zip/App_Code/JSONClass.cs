﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

public class JSONClass
{
    public string name { get; set; }
    public string url { get; set; }
    public bool visibility { get; set; }
    public string idField { get; set; }
    public bool defaultEvents { get; set; }
    public string type { get; set; }       


}
