﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;
using System.Web.UI;

/// <summary>
/// Summary description for TCMS_Stage1
/// </summary>
public class TCMS_Stage1
{
    Page pageCls = null;
    string connStr = ConfigurationManager.ConnectionStrings["TCMSConn"].ConnectionString;
    public TCMS_Stage1()    //Page page
	{
      //  pageCls = page;
		
	}
    public DataTable GetStage1_grid(int _stageID, string _prjID)
    {
        string sqlQuery = "SELECT date_ID, ptd_receive_on, ptd_purpose, ptd_assign_qs, ptd_sent_for_rev, ptd_qs_working_status, ptd_tendec_doc_cur_status, ptd_forwarded_to_dep FROM TenderDatesInfo WHERE (stage_id = @stage_id) AND (proj_id = @prjID)";

        SqlConnection objCon = new SqlConnection(connStr);
        objCon.Open();
        SqlCommand sqlCom = new SqlCommand(sqlQuery, objCon);

        sqlCom.CommandType = System.Data.CommandType.Text;
        sqlCom.CommandText = sqlQuery;

        sqlCom.Parameters.AddWithValue("@stage_id", _stageID);
        sqlCom.Parameters.AddWithValue("@prjID", _prjID);

        SqlDataAdapter da = new SqlDataAdapter(sqlCom);

        System.Data.DataSet ds = new System.Data.DataSet();
        da.Fill(ds);    

        return ds.Tables[0];
    }
    public int MaxDateID()
    {
        SqlConnection sqlConn = null;
        int dateId = 0;
        try
        {
            using (sqlConn = new SqlConnection(connStr))
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    sqlConn.Open();
                    cmd.Connection = sqlConn;
                    cmd.CommandText = @"SELECT MAX(DATE_ID)+1 FROM TenderDatesInfo";
                    dateId = Convert.ToInt16(cmd.ExecuteScalar());
                }
            }
        }
        catch (Exception ex)
        {

        }
        finally
        {
            sqlConn.Close();
        }
        return dateId;
    }


}