﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

public class Employee
{

    public string EmployeeName { get; set; }
    public string EmployeeCode { get; set; }
}
