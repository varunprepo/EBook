﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.IO;
using System.Data.SqlClient;
using System.Drawing;
using System.Data;
using Datalayer;

public partial class GenaralService_GSExportData : System.Web.UI.Page
{
    static string reqNo = string.Empty;
    string connValue = System.Configuration.ConfigurationManager.ConnectionStrings["EBSDEBookConn"].ConnectionString;



    // =================================================================================================================================================

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            IList<string> tblColle = new List<string>();
            tblColle.Add("JobOrder Info");
            tblColle.Add("Cost Info");
            tblColle.Add("EOT Info");
            tblColle.Add("Document Info");

            DataTable dtNew = new DataTable();
            dtNew = ReadData().Tables[0];

            TreeNode tn = new TreeNode();
            tn.Value = reqNo;
            TreeView1.Nodes.Add(tn);

            foreach (var item in tblColle)
            {
                IList<string> fieldsColle = new List<string>();
                TreeNode tnSub = new TreeNode();

                fieldsColle = getTableFieldsFromSP(item);
                tnSub.Value = item;
                tn.ChildNodes.Add(tnSub);

                foreach (var subitem in fieldsColle)
                {
                    TreeNode tnSub_1 = new TreeNode();
                    tnSub_1.Text = subitem;
                    tnSub_1.Value = subitem;
                    tnSub.ChildNodes.Add(tnSub_1);
                }
            }


            tblGrid.Visible = false;
        }
    }
    private IList<string> getTableFieldsFromSP(string tblName)
    {
        IList<string> feildsColl = new List<string>();

        if (tblName.Equals("JobOrder Info"))
        {
            feildsColl.Add("Job.jobNo");
            feildsColl.Add("Job.contractNo");
            feildsColl.Add("Job.projectTitle");

            feildsColl.Add("JobType.jobTypeName");
            feildsColl.Add("JobStatus.jobStatusName");

            feildsColl.Add("Job.jobReceivedDate");
            feildsColl.Add("Job.jobStatusClosedDate");

            feildsColl.Add("Job.Remarks");

            feildsColl.Add("Affair.affairName");
            feildsColl.Add("Department.deptName");

            feildsColl.Add("Company.cmpName AS Contractor");
            feildsColl.Add("Company_1.cmpName AS Consultant");
        }

        if (tblName.Equals("Document Info"))
        {
            feildsColl.Add("[Document].DocSubject");
            feildsColl.Add("[Document].referenceNo AS OpenLetter");
            feildsColl.Add("Document_1.referenceNo AS ClosedLetter");
        }

        if (tblName.Equals("Cost Info"))
        {
            feildsColl.Add("JobVOSI.contractorAmt");
            feildsColl.Add("JobVOSI.ebsdAmt");
            feildsColl.Add("JobVOSI.Remarks");
        }

        if (tblName.Equals("EOT Info"))
        {
            feildsColl.Add("JobVOSI.contractorEOT");
            feildsColl.Add("JobVOSI.ebsdEOT");
            feildsColl.Add("JobVOSI.RemarksForTime");
            feildsColl.Add("Contact.displayName AS VOCreatedBY");
        }

        if (tblName.Equals("Staff Info"))
        {
            feildsColl.Add("Contact.displayName");
            feildsColl.Add("Contact_1.displayName");
            feildsColl.Add("Contact_2.displayName");
        }

        return feildsColl;
    }


    private DataSet ReadData()
    {
        DataSet ds = new DataSet();
        try
        {


            Int32 _jobtypeID;
            Int32.TryParse("0", out _jobtypeID);

            Int32 _jobStatusID;
            Int32.TryParse("0", out _jobStatusID);

            Boolean _chkActive;
            Boolean.TryParse(true.ToString(), out _chkActive);

            string _contractNo = string.Empty;
            string txtfrom = string.Empty;
            string txtTo = string.Empty;


            Int32 _voCreatedBY;
            Int32.TryParse("0", out _voCreatedBY);

           // ds = (new JobOrderData().GetDetails_JOBVOSI_Stake_Dynamic(_jobtypeID, _chkActive, _contractNo, txtfrom, txtTo, _jobStatusID, _voCreatedBY));  //SelectedData  

        }
        catch (Exception ex)
        {

        }

        return ds;
    }



    // =================================================================================================================================================

    private void oldPageload()
    {
        IList<string> tblColle = getTables();

        TreeNode tn = new TreeNode();
        tn.Value = reqNo;
        TreeView1.Nodes.Add(tn);

        foreach (var item in tblColle)
        {
            IList<string> fieldsColle = new List<string>();
            TreeNode tnSub = new TreeNode();

            if ((item.Equals("Job")) || (item.Equals("JobOwner")) || (item.Equals("JobVOSI")) || (item.Equals("Contact")) || (item.Equals("JobType")))
            {
                fieldsColle = getTableFields(item);

                tnSub.Value = item;
                tn.ChildNodes.Add(tnSub);


                foreach (var subitem in fieldsColle)
                {
                    // string[] subfolders_1 = System.IO.Directory.GetDirectories(subitem, "*", System.IO.SearchOption.TopDirectoryOnly); //TopDirectoryOnly

                    TreeNode tnSub_1 = new TreeNode();

                    tnSub_1.Text = subitem;

                    tnSub_1.Value = subitem;

                    tnSub.ChildNodes.Add(tnSub_1);
                }
            }
        }
    }
    IList<string> tblColl = new List<string>();
    private IList<string> getTables()
    {
        string sqlQuery = "SELECT TABLE_NAME FROM  INFORMATION_SCHEMA.TABLES  WHERE (TABLE_TYPE = 'BASE TABLE') ORDER BY TABLE_NAME ";


        using (SqlConnection cn = new SqlConnection(connValue))
        {
            cn.Open();
            using (SqlCommand cmd = new SqlCommand(sqlQuery, cn))
            {
                using (SqlDataReader dr = cmd.ExecuteReader())
                {
                    while (dr.Read())
                    {
                        tblColl.Add(dr["TABLE_NAME"].ToString());
                    }
                }
            }
        }
        return tblColl;
    }

    private IList<string> getTableFields(string tblName)
    {


        string sqlQuery = "SELECT TABLE_NAME, COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE (TABLE_NAME = '" + tblName + "')";

        IList<string> tblColl = new List<string>();

        using (SqlConnection cn = new SqlConnection(connValue))
        {
            cn.Open();
            using (SqlCommand cmd = new SqlCommand(sqlQuery, cn))
            {
                using (SqlDataReader dr = cmd.ExecuteReader())
                {
                    while (dr.Read())
                    {
                        if (!dr["COLUMN_NAME"].ToString().Contains("ID"))
                        {
                            if ((dr["COLUMN_NAME"].ToString().Equals("CreateDate")) || (dr["COLUMN_NAME"].ToString().Equals("UpdateDate")) || (dr["COLUMN_NAME"].ToString().Equals("CreateUser")) || (dr["COLUMN_NAME"].ToString().Equals("UpdateUser")))
                            {

                            }
                            else
                            {
                                tblColl.Add(dr["COLUMN_NAME"].ToString());
                            }
                        }
                    }
                }
            }
        }
        return tblColl;
    }

 
    protected void btnBack_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/JobOrder/CostControlHomePage.aspx", false);
    }
    protected void Select_Change(object sender, EventArgs e)
    {
        string strClmnName = TreeView1.SelectedNode.Text;
        ListBox1.Items.Add(strClmnName);

        //if (TreeView1.SelectedNode.Text.Contains(".")) //TreeView1.SelectedNode.Text.Contains(".dwg")
        //{
        //  //  string filePath = TreeView1.SelectedNode.Text;

        //    lblFilePathName.Text = filePath;           
        //}
        //else
        //{
        //    ListViewDataItem lItem = new ListViewDataItem(1,1);    

        //    ListView1.Items.Add(lItem);

        //}
    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        string strQuery = string.Empty;
        string queryColl = string.Empty;

        foreach (var item in ListBox1.Items)
        {
            queryColl = item + ",";
        }

        GridView2.DataSource = "";
        GridView2.DataBind();
    }
   

    protected void btnSubmit_Click1(object sender, EventArgs e)
    {
        tblMain.Visible = false;

        tblGrid.Visible = true;

        // DataTable dt = new DataTable();
        IList<string> lst = new List<string>();
        lst.Add("");
        foreach (var item in ListBox1.Items)
        {
            lst.Add(item.ToString());
        }
        ddlSortBy.DataSource = lst;
        ddlSortBy.DataBind();

        string queryColl = string.Empty;
        foreach (var item in ListBox1.Items)
        {
            queryColl += item + ",";
        }

        queryColl = queryColl + " Job.CreateDate ";

        string sqlQuery = string.Empty;

        //  AND (@chkVOActive IS NULL OR JobVOSI.isVOActive = @chkVOActive)

        sqlQuery = "SELECT " + queryColl + " " +
           " FROM JobVOSI INNER JOIN Job ON JobVOSI.jobID = Job.jobID INNER JOIN JobStatus ON Job.jobStatusID = JobStatus.jobStatusID INNER JOIN " +
                         " JobType ON Job.jobTypeID = JobType.jobTypeID INNER JOIN [Document] ON Job.docRefID = [Document].documentID INNER JOIN " +
                         " Company ON Job.contractorID = Company.companyID INNER JOIN Company AS Company_1 ON Job.consultantID = Company_1.companyID INNER JOIN " +
                         " Department ON Job.deptID = Department.departmentID INNER JOIN  Affair ON Department.affairID = Affair.affairID LEFT OUTER JOIN " +
                         " Contact ON JobVOSI.CreatedBy = Contact.contactID LEFT OUTER JOIN [Document] AS Document_1 ON Job.closedDocRefID = Document_1.documentID LEFT OUTER JOIN " +
                         " PSACostDesc ON JobVOSI.voCatID = PSACostDesc.jobCostID LEFT OUTER JOIN PSAJobTime ON JobVOSI.voTimeCatID = PSAJobTime.jobTimeID LEFT OUTER JOIN " +
                         " StakeHolder ON JobVOSI.invSH = StakeHolder.stakeID WHERE (@jobTypeID IS NULL OR Job.jobTypeID = @jobTypeID)  AND (@contractNo IS NULL OR Job.contractNo = @contractNo) AND (@datefrom IS NULL OR " +
                         " Job.jobReceivedDate >= CONVERT(NVARCHAR, @datefrom, 106)) AND (@dateTo IS NULL OR Job.jobReceivedDate <= CONVERT(NVARCHAR, @dateTo, 106)) AND (@jobStatusID IS NULL OR " +
                        " Job.jobStatusID = @jobStatusID) AND (@voCreatedBy IS NULL OR JobVOSI.CreatedBy = @voCreatedBy) ORDER BY Job.jobReceivedDate DESC";

        //AND (@chkVOActive IS NULL OR JobVOSI.isVOActive = @chkVOActive)

        Int16 jobid;
        Int16.TryParse(txtCntrNo.Text, out jobid);

        Int16 afrID;
        Int16.TryParse("0", out afrID);

        Int16 dptID;
        Int16.TryParse("0", out dptID);

        Int16 consID;
        Int16.TryParse("0", out consID);

        Int16 jobType;
        Int16.TryParse(txtJobType.Text, out jobType);

        Int16 jobStatus;
        Int16.TryParse("0", out jobStatus);

        Int16 docRefID;
        Int16.TryParse("0", out docRefID);

        Int16 docClsRefID;
        Int16.TryParse("0", out docClsRefID);

        Int16 qsID = 0;
        Int16 ceID = 0;
        Int16 peID = 0;
        string prjTitle = string.Empty;
        string docSubject = string.Empty;

        Int16 cntrID;
        Int16.TryParse("0", out cntrID);


        Int16 consultID;
        Int16.TryParse("0", out consultID);

        string prjCode = string.Empty;
        prjCode = txtCntrNo.Text;

        string txtfrom = string.Empty;
        if (txtdept.Text != "")
            txtfrom = txtdept.Text;


        string txtTo = string.Empty;
        if (txtToDate.Text != "")
            txtTo = txtToDate.Text;

        Int16 VOID;
        Int16.TryParse("0", out VOID);

        Int16 EOTID;
        Int16.TryParse("0", out EOTID);


        Int16 leadID;
        Int16.TryParse("0", out leadID);


        Int16 teamMemID;
        Int16.TryParse("0", out teamMemID);



        SqlConnection objCon = new SqlConnection(connValue);
        SqlCommand objCmd = new SqlCommand(sqlQuery, objCon);
        SqlDataAdapter objDA = new SqlDataAdapter(objCmd);

        objDA.SelectCommand.CommandText = objCmd.CommandText.ToString();

        //cmd.Connection = conn;

        objCmd.Parameters.AddWithValue("@jobTypeID", System.DBNull.Value);

        //  objCmd.Parameters.AddWithValue("@chkVOActive", true);

        if (prjCode != "")
            objCmd.Parameters.AddWithValue("@contractNo", prjCode);
        else
            objCmd.Parameters.AddWithValue("@contractNo", System.DBNull.Value);

        if (txtfrom != "")
            objCmd.Parameters.AddWithValue("@datefrom", txtfrom);
        else
            objCmd.Parameters.AddWithValue("@datefrom", System.DBNull.Value);

        if (txtTo != "")
            objCmd.Parameters.AddWithValue("@dateTo", txtTo);
        else
            objCmd.Parameters.AddWithValue("@dateTo", System.DBNull.Value);


        objCmd.Parameters.AddWithValue("@jobStatusID", System.DBNull.Value);

        objCmd.Parameters.AddWithValue("@voCreatedBy", System.DBNull.Value);



        DataTable dt = new DataTable();
        objDA.Fill(dt);

        Session["ChartJobs"] = dt;

        lblCnt.Text = dt.Rows.Count.ToString();

        if (dt.Rows.Count != 0)
            GridView2.DataSource = dt.DefaultView;
        else
        {
            GridView2.DataSource = null;
        }
        GridView2.DataBind();

        // trStartDate

        // getOnGoingTasksPerSection_New();


        DataSet dsTndr = new DataSet();
        string sqlQueryChart = null;
        string strSeriesName = string.Empty;

        strSeriesName = "jobTypeName";


        sqlQueryChart = "SELECT COUNT(Job.jobID) AS JobCnt, JobType.jobTypeName " +
                                 " FROM JobVOSI INNER JOIN Job ON JobVOSI.jobID = Job.jobID INNER JOIN " +
                         " JobStatus ON Job.jobStatusID = JobStatus.jobStatusID INNER JOIN JobType ON Job.jobTypeID = JobType.jobTypeID INNER JOIN [Document] ON Job.docRefID = [Document].documentID INNER JOIN " +
                         " Company ON Job.contractorID = Company.companyID INNER JOIN Company AS Company_1 ON Job.consultantID = Company_1.companyID LEFT OUTER JOIN Contact ON JobVOSI.createdBy = Contact.contactID LEFT OUTER JOIN " +
                          " [Document] AS Document_1 ON Job.closedDocRefID = Document_1.documentID LEFT OUTER JOIN PSACostDesc ON JobVOSI.voCatID = PSACostDesc.jobCostID LEFT OUTER JOIN PSAJobTime ON JobVOSI.voTimeCatID = PSAJobTime.jobTimeID LEFT OUTER JOIN " +
                         " StakeHolder ON JobVOSI.invSH = StakeHolder.stakeID WHERE        (@jobTypeID IS NULL OR Job.jobTypeID = @jobTypeID) AND (@contractNo IS NULL OR Job.contractNo = @contractNo) AND (@datefrom IS NULL OR Job.jobReceivedDate >= CONVERT(NVARCHAR, @datefrom, 106)) " +
        " AND (@dateTo IS NULL OR Job.jobReceivedDate <= CONVERT(NVARCHAR, @dateTo, 106)) AND (@jobStatusID IS NULL OR Job.jobStatusID = @jobStatusID) AND (@voCreatedBy IS NULL OR JobVOSI.createdBy = @voCreatedBy) GROUP BY JobType.jobTypeName";

        strSeriesName = "jobTypeName";


        objCmd.CommandText = sqlQueryChart;

        SqlDataAdapter daTndr = new SqlDataAdapter(objCmd);
        daTndr.Fill(dsTndr);
        if (dsTndr.Tables[0].Rows.Count != 0)
        {
            onGoingTasksPerSectionChart.DataSource = dsTndr.Tables[0].DefaultView;

            onGoingTasksPerSectionChart.Series["Series1"].XValueMember = strSeriesName;
            onGoingTasksPerSectionChart.Series["Series1"].YValueMembers = "JobCnt";

            dsTndr.Tables.Clear();

            onGoingTasksPerSectionChart.ChartAreas[0].AxisX.MajorGrid.Enabled = false;
            onGoingTasksPerSectionChart.ChartAreas[0].AxisX.MinorGrid.Enabled = false;
            onGoingTasksPerSectionChart.ChartAreas[0].AxisY.MajorGrid.Enabled = false;
            onGoingTasksPerSectionChart.ChartAreas[0].AxisY.MinorGrid.Enabled = false;

            onGoingTasksPerSectionChart.ChartAreas[0].AxisX.LabelStyle.Angle = 30;
            onGoingTasksPerSectionChart.ChartAreas[0].AxisX.LabelStyle.ForeColor = Color.Maroon;

            onGoingTasksPerSectionChart.ChartAreas[0].AxisX.Interval = 1;
        }

        // ===================================================================================================

        //DataSet dschartForCost = new DataSet();
        //string sqlQuerychartForCost = null;
        //string strSeriesNamechartForCost = string.Empty;

        //strSeriesNamechartForCost = "jobTypeName";

        //sqlQuerychartForCost = "SELECT COUNT(Job.jobID) AS JobCnt, JobType.jobTypeName " +
        //                         " FROM JobVOSI INNER JOIN Job ON JobVOSI.jobID = Job.jobID INNER JOIN " +
        //                 " JobStatus ON Job.jobStatusID = JobStatus.jobStatusID INNER JOIN JobType ON Job.jobTypeID = JobType.jobTypeID INNER JOIN [Document] ON Job.docRefID = [Document].documentID INNER JOIN " +
        //                 " Company ON Job.contractorID = Company.companyID INNER JOIN Company AS Company_1 ON Job.consultantID = Company_1.companyID LEFT OUTER JOIN Contact ON JobVOSI.createdBy = Contact.contactID LEFT OUTER JOIN " +
        //                  " [Document] AS Document_1 ON Job.closedDocRefID = Document_1.documentID LEFT OUTER JOIN PSACostDesc ON JobVOSI.voCatID = PSACostDesc.jobCostID LEFT OUTER JOIN PSAJobTime ON JobVOSI.voTimeCatID = PSAJobTime.jobTimeID LEFT OUTER JOIN " +
        //                 " StakeHolder ON JobVOSI.invSH = StakeHolder.stakeID WHERE        (@jobTypeID IS NULL OR Job.jobTypeID = @jobTypeID) AND (@contractNo IS NULL OR Job.contractNo = @contractNo) AND (@datefrom IS NULL OR Job.jobReceivedDate >= CONVERT(NVARCHAR, @datefrom, 106)) " +
        //" AND (@dateTo IS NULL OR Job.jobReceivedDate <= CONVERT(NVARCHAR, @dateTo, 106)) AND (@jobStatusID IS NULL OR Job.jobStatusID = @jobStatusID) AND (@voCreatedBy IS NULL OR JobVOSI.createdBy = @voCreatedBy) GROUP BY JobType.jobTypeName";



        //objCmd.CommandText = sqlQuerychartForCost;

        //SqlDataAdapter dachartForCost = new SqlDataAdapter(objCmd);
        //dachartForCost.Fill(dschartForCost);
        //if (dschartForCost.Tables[0].Rows.Count != 0)
        //{
        //    onGoingTasksPerSectionChart.DataSource = dschartForCost.Tables[0].DefaultView;

        //    chartForCost.Series["Series1"].XValueMember = strSeriesNamechartForCost;
        //    chartForCost.Series["Series1"].YValueMembers = "JobCnt";

        //    dschartForCost.Tables.Clear();

        //    chartForCost.ChartAreas[0].AxisX.MajorGrid.Enabled = false;
        //    chartForCost.ChartAreas[0].AxisX.MinorGrid.Enabled = false;
        //    chartForCost.ChartAreas[0].AxisY.MajorGrid.Enabled = false;
        //    chartForCost.ChartAreas[0].AxisY.MinorGrid.Enabled = false;

        //    chartForCost.ChartAreas[0].AxisX.LabelStyle.Angle = 30;
        //    chartForCost.ChartAreas[0].AxisX.LabelStyle.ForeColor = Color.Maroon;

        //    chartForCost.ChartAreas[0].AxisX.Interval = 1;
        //}

        // ===================================================================================================

        // getAmountData();


        EBDAmount();


    }
    private void getAmountData()
    {
        DataSet dsTndr = new DataSet();
        string sqlQueyAmnt = "SELECT SUM(JobVOSI.ebsdAmt) AS EBSDAmount, SUM(JobVOSI.contractorAmt) AS contractorAmt, YEAR(Job.jobReceivedDate) AS YearName " +
             " FROM            JobVOSI INNER JOIN  Job ON JobVOSI.jobID = Job.jobID INNER JOIN   JobType ON Job.jobTypeID = JobType.jobTypeID WHERE  (JobType.CategoryID IN (4, 7)) GROUP BY YEAR(Job.jobReceivedDate) ORDER BY YearName";

        string strSeriesName = "EBSDAmount";


        //   objCmd.CommandText = sqlQueryChart;

        SqlDataAdapter daTndr = new SqlDataAdapter(sqlQueyAmnt, connValue);
        daTndr.Fill(dsTndr);
        if (dsTndr.Tables[0].Rows.Count != 0)
        {
            onGoingTasksPerSectionChart.DataSource = dsTndr.Tables[0].DefaultView;

            onGoingTasksPerSectionChart.Series["Series1"].XValueMember = strSeriesName;
            onGoingTasksPerSectionChart.Series["Series1"].YValueMembers = "YearName";

            dsTndr.Tables.Clear();

            onGoingTasksPerSectionChart.ChartAreas[0].AxisX.MajorGrid.Enabled = false;
            onGoingTasksPerSectionChart.ChartAreas[0].AxisX.MinorGrid.Enabled = false;
            onGoingTasksPerSectionChart.ChartAreas[0].AxisY.MajorGrid.Enabled = false;
            onGoingTasksPerSectionChart.ChartAreas[0].AxisY.MinorGrid.Enabled = false;

            onGoingTasksPerSectionChart.ChartAreas[0].AxisX.LabelStyle.Angle = 30;
            onGoingTasksPerSectionChart.ChartAreas[0].AxisX.LabelStyle.ForeColor = Color.Maroon;

            onGoingTasksPerSectionChart.ChartAreas[0].AxisX.Interval = 1;
        }


    }
    private void ChartForJobType()
    {
        SqlCommand objCmd = new SqlCommand();

        DataSet dsTndr = new DataSet();
        string sqlQueryChart = null;
        string strSeriesName = string.Empty;

        strSeriesName = "jobTypeName";

        sqlQueryChart = "SELECT COUNT(Job.jobID) AS JobCnt, JobType.jobTypeName " +
                                 " FROM JobVOSI INNER JOIN Job ON JobVOSI.jobID = Job.jobID INNER JOIN " +
                         " JobStatus ON Job.jobStatusID = JobStatus.jobStatusID INNER JOIN JobType ON Job.jobTypeID = JobType.jobTypeID INNER JOIN [Document] ON Job.docRefID = [Document].documentID INNER JOIN " +
                         " Company ON Job.contractorID = Company.companyID INNER JOIN Company AS Company_1 ON Job.consultantID = Company_1.companyID LEFT OUTER JOIN Contact ON JobVOSI.createdBy = Contact.contactID LEFT OUTER JOIN " +
                          " [Document] AS Document_1 ON Job.closedDocRefID = Document_1.documentID LEFT OUTER JOIN PSACostDesc ON JobVOSI.voCatID = PSACostDesc.jobCostID LEFT OUTER JOIN PSAJobTime ON JobVOSI.voTimeCatID = PSAJobTime.jobTimeID LEFT OUTER JOIN " +
                         " StakeHolder ON JobVOSI.invSH = StakeHolder.stakeID WHERE        (@jobTypeID IS NULL OR Job.jobTypeID = @jobTypeID) AND (@contractNo IS NULL OR Job.contractNo = @contractNo) AND (@datefrom IS NULL OR Job.jobReceivedDate >= CONVERT(NVARCHAR, @datefrom, 106)) " +
        " AND (@dateTo IS NULL OR Job.jobReceivedDate <= CONVERT(NVARCHAR, @dateTo, 106)) AND (@jobStatusID IS NULL OR Job.jobStatusID = @jobStatusID) AND (@voCreatedBy IS NULL OR JobVOSI.createdBy = @voCreatedBy) GROUP BY JobType.jobTypeName";

        strSeriesName = "jobTypeName";


        objCmd.CommandText = sqlQueryChart;

        SqlDataAdapter daTndr = new SqlDataAdapter(objCmd);
        daTndr.Fill(dsTndr);
        if (dsTndr.Tables[0].Rows.Count != 0)
        {
            onGoingTasksPerSectionChart.DataSource = dsTndr.Tables[0].DefaultView;

            onGoingTasksPerSectionChart.Series["Series1"].XValueMember = strSeriesName;
            onGoingTasksPerSectionChart.Series["Series1"].YValueMembers = "JobCnt";

            dsTndr.Tables.Clear();

            onGoingTasksPerSectionChart.ChartAreas[0].AxisX.MajorGrid.Enabled = false;
            onGoingTasksPerSectionChart.ChartAreas[0].AxisX.MinorGrid.Enabled = false;
            onGoingTasksPerSectionChart.ChartAreas[0].AxisY.MajorGrid.Enabled = false;
            onGoingTasksPerSectionChart.ChartAreas[0].AxisY.MinorGrid.Enabled = false;

            onGoingTasksPerSectionChart.ChartAreas[0].AxisX.LabelStyle.Angle = 30;
            onGoingTasksPerSectionChart.ChartAreas[0].AxisX.LabelStyle.ForeColor = Color.Maroon;

            onGoingTasksPerSectionChart.ChartAreas[0].AxisX.Interval = 1;
        }
    }
   
    protected void btnExcel_Click(object sender, EventArgs e)
    {
        ExportToExcel_Sree();
    }

    #region MyRegion

    private void ExportToExcel_Sree()
    {
        Response.Clear();
        Response.Buffer = true;
        Response.AddHeader("content-disposition", "attachment;filename=GridViewExport.xls");
        Response.Charset = "";
        Response.ContentType = "application/vnd.ms-excel";
        using (StringWriter sw = new StringWriter())
        {
            HtmlTextWriter hw = new HtmlTextWriter(sw);

            //To Export all pages
            GridView2.AllowPaging = false;

            GridView2.DataSource = Session["ChartJobs"];
            GridView2.DataBind();

            GridView2.HeaderRow.BackColor = Color.White;
            foreach (TableCell cell in GridView2.HeaderRow.Cells)
            {
                cell.BackColor = GridView2.HeaderStyle.BackColor;
            }
            foreach (GridViewRow row in GridView2.Rows)
            {
                row.BackColor = Color.White;
                foreach (TableCell cell in row.Cells)
                {
                    if (row.RowIndex % 2 == 0)
                    {
                        cell.BackColor = GridView2.AlternatingRowStyle.BackColor;
                    }
                    else
                    {
                        cell.BackColor = GridView2.RowStyle.BackColor;
                    }
                    cell.CssClass = "textmode";
                }
            }

            GridView2.RenderControl(hw);

            //style to format numbers to string
            string style = @"<style> .textmode { } </style>";
            Response.Write(style);
            Response.Output.Write(sw.ToString());
            Response.Flush();
            Response.End();
        }
    }
    public override void VerifyRenderingInServerForm(Control control)
    {
        /* Verifies that the control is rendered */
    }

    #endregion
    protected void btnClrAll_Click(object sender, EventArgs e)
    {
        ListBox1.Items.Clear();

        txtdept.Text = "";
        txtToDate.Text = "";
        txtCntrNo.Text = "";
        txtJobType.Text = "";
    }



    protected void ddlProfileType_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlProfileType.SelectedValue.Equals("Dates Between"))
        {
            trStartDate.Visible = true;
            trEndDate.Visible = true;
        }
        else if (ddlProfileType.SelectedValue.Equals("Contract No."))
        {
            trCntr.Visible = true;
        }
        else if (ddlProfileType.SelectedValue.Equals("Job Type"))
        {
            trType.Visible = true;
        }
        else if (ddlProfileType.SelectedValue.Equals("Job Status"))
        {
            // trStartDate.Visible = true;
        }
        else
        {
            trStartDate.Visible = false;
            trEndDate.Visible = false;
            trCntr.Visible = false;
            trType.Visible = false;

        }
    }
    protected void btnStrDt_Click(object sender, EventArgs e)
    {
        trStartDate.Visible = false;
        trEndDate.Visible = false;

        txtToDate.Text = "";
        txtToDate.Text = "";
    }
    protected void btnEndDt_Click(object sender, EventArgs e)
    {
        trStartDate.Visible = false;
        trEndDate.Visible = false;

        txtToDate.Text = "";
        txtToDate.Text = "";
    }
    protected void btnCntr_Click(object sender, EventArgs e)
    {
        trCntr.Visible = false;
        txtCntrNo.Text = "";
    }
    protected void btnType_Click(object sender, EventArgs e)
    {
        trType.Visible = false;
        txtJobType.Text = "";
    }




    #region MyRegion



    private void getOnGoingTasksPerSection_New()
    {
        DataSet dsTndr = new DataSet();

        string sqlQuery = null;

        //int secID = Convert.ToInt32(Session["SectionID"]);

        string strSeriesName = string.Empty;

        //#region MyRegion



        //if (Session["userProfileID"].ToString().Equals("1"))   // For Admin
        //{
        //    sqlQuery = " SELECT  COUNT(Job.jobID) AS JobCnt, Section.sectionName FROM  JobType INNER JOIN  Job ON JobType.jobTypeID = Job.jobTypeID INNER JOIN Section ON JobType.sectionID = Section.sectionID " +
        //       " WHERE (Job.jobDueDate < GETDATE()-1) AND (Job.jobStatusID IN (3, 8))  GROUP BY Section.sectionName, JobType.sectionID  UNION " +
        //            "SELECT  COUNT(JobOwner.jobOwnerID) AS Expr1, Section.sectionName FROM  JobOwner INNER JOIN  Section ON JobOwner.sectionID = Section.sectionID " +
        //                  " WHERE  (JobOwner.payID IS NOT NULL) AND (JobOwner.actionDueDate < GETDATE()-1) AND (JobOwner.jobOwnerStatusID <> 7) GROUP BY Section.sectionName";
        //    strSeriesName = "sectionName";

        //    lblOngoingJobs.Text = "Over Due Job Order In All Sections";
        //}
        //else if (!Session["userProfileID"].ToString().Equals("1") && Session["SectionID"].ToString().Equals("7") && !userRightsColl.Contains("1"))    // User Not Admin but he belongs to all section and he contain user rights no  -1   (  7 for all section )
        //{
        //    sqlQuery = " SELECT  COUNT(Job.jobID) AS JobCnt, Section.sectionName FROM  JobType INNER JOIN  Job ON JobType.jobTypeID = Job.jobTypeID INNER JOIN   Section ON JobType.sectionID = Section.sectionID " +
        //       " WHERE (Job.jobDueDate < GETDATE()-1) AND (Job.jobStatusID IN (3, 8))  GROUP BY Section.sectionName, JobType.sectionID  UNION " +
        //            "SELECT  COUNT(JobOwner.jobOwnerID) AS Expr1, Section.sectionName FROM  JobOwner INNER JOIN  Section ON JobOwner.sectionID = Section.sectionID " +
        //                  " WHERE  (JobOwner.payID IS NOT NULL) AND (JobOwner.actionDueDate < GETDATE()-1) AND (JobOwner.jobOwnerStatusID <> 7) GROUP BY Section.sectionName";

        //    strSeriesName = "sectionName";

        //    lblOngoingJobs.Text = "Over Due Job Order In All Sections";
        //}
        //else if (Session["SectionID"].ToString().Equals("1"))          // Cost Control Section
        //{
        //    if (Session["UserProfileID"].ToString().Contains("2"))        // Admin Section
        //    {
        //        sqlQuery = "SELECT COUNT(Job.jobID) AS JobCnt, JobType_1.jobTypeName FROM JobType AS JobType_1 INNER JOIN JobType ON JobType_1.jobTypeID = JobType.CategoryID INNER JOIN  Job ON JobType.jobTypeID = Job.jobTypeID INNER JOIN " +
        //           " Section ON JobType.sectionID = Section.sectionID WHERE (JobType.sectionID = " + secID + ") AND (Job.jobDueDate < GETDATE()-1) AND (Job.jobStatusID IN (3,8)) GROUP BY JobType_1.jobTypeName";

        //        strSeriesName = "jobTypeName";
        //        lblOngoingJobs.Text = "Over Due Job Order In Cost Control Section";
        //    }
        //    else if (Session["UserProfileID"].ToString().Contains("4"))        // Cost Control Admin 
        //    {
        //        sqlQuery = "SELECT COUNT(Job.jobID) AS JobCnt, JobType_1.jobTypeName FROM JobType AS JobType_1 INNER JOIN JobType ON JobType_1.jobTypeID = JobType.CategoryID INNER JOIN  Job ON JobType.jobTypeID = Job.jobTypeID INNER JOIN " +
        //        " Section ON JobType.sectionID = Section.sectionID WHERE (JobType.sectionID = " + secID + ") AND (Job.jobDueDate < GETDATE()-1) AND (Job.jobStatusID IN (3,8)) GROUP BY JobType_1.jobTypeName";

        //        strSeriesName = "jobTypeName";
        //        lblOngoingJobs.Text = "Over Due Job Order In Cost Control Section";
        //    }
        //    else if (Session["UserProfileID"].ToString().Contains("9"))        // Document Control Admin 
        //    {
        //        sqlQuery = "SELECT COUNT(Job.jobID) AS JobCnt, JobType_1.jobTypeName FROM JobType AS JobType_1 INNER JOIN JobType ON JobType_1.jobTypeID = JobType.CategoryID INNER JOIN  Job ON JobType.jobTypeID = Job.jobTypeID INNER JOIN " +
        //        " Section ON JobType.sectionID = Section.sectionID WHERE (JobType.sectionID = " + secID + ") AND (Job.jobDueDate < GETDATE()-1) AND (Job.jobStatusID IN (3,8)) GROUP BY JobType_1.jobTypeName";

        //        strSeriesName = "jobTypeName";
        //        lblOngoingJobs.Text = "Over Due Job Order In Cost Control Section";
        //    }
        //    else                                                            // Cost Control User 
        //    {
        //        sqlQuery = "SELECT  COUNT(JobOwner.jobOwnerID) AS JobCnt, JobType_1.jobTypeName FROM   JobType INNER JOIN  JobOwner ON JobType.jobTypeID = JobOwner.JobTypeID INNER JOIN " +
        //                " Section ON JobOwner.sectionID = Section.sectionID INNER JOIN  JobType AS JobType_1 ON JobType.CategoryID = JobType_1.jobTypeID  WHERE (JobOwner.jobOwnerStatusID = 3) AND (JobOwner.contactID = " + _currentUserID + ") GROUP BY JobType_1.jobTypeName";
        //        strSeriesName = "jobTypeName";

        //        lblOngoingJobs.Text = "My On Going Tasks";
        //    }
        //}
        //else if (Session["SectionID"].ToString().Equals("6"))          // Cost Control Section
        //{
        //    if (Session["UserProfileID"].ToString().Contains("2"))        // Admin Section
        //    {
        //        sqlQuery = "SELECT COUNT(Job.jobID) AS JobCnt, JobType_1.jobTypeName FROM JobType AS JobType_1 INNER JOIN JobType ON JobType_1.jobTypeID = JobType.CategoryID INNER JOIN  Job ON JobType.jobTypeID = Job.jobTypeID INNER JOIN " +
        //           " Section ON JobType.sectionID = Section.sectionID WHERE (Job.sectionID = " + secID + ") AND (Job.jobDueDate < GETDATE()-1) AND (Job.jobStatusID IN (3,8)) GROUP BY JobType_1.jobTypeName";

        //        strSeriesName = "jobTypeName";
        //        lblOngoingJobs.Text = "Over Due Job Order In Cost Control Section";    // Planning and Schedule
        //    }
        //    else if (Session["UserProfileID"].ToString().Contains("4"))        // Cost Control Admin 
        //    {
        //        sqlQuery = "SELECT COUNT(Job.jobID) AS JobCnt, JobType_1.jobTypeName FROM JobType AS JobType_1 INNER JOIN JobType ON JobType_1.jobTypeID = JobType.CategoryID INNER JOIN  Job ON JobType.jobTypeID = Job.jobTypeID INNER JOIN " +
        //        " Section ON JobType.sectionID = Section.sectionID WHERE (Job.sectionID = " + secID + ") AND (Job.jobDueDate < GETDATE()-1) AND (Job.jobStatusID IN (3,8)) GROUP BY JobType_1.jobTypeName";

        //        strSeriesName = "jobTypeName";
        //        lblOngoingJobs.Text = "Over Due Job Order In Cost Control Section";       // Planning and Schedule
        //    }
        //    else if (Session["UserProfileID"].ToString().Contains("9"))        // Document Control Admin 
        //    {
        //        sqlQuery = "SELECT COUNT(Job.jobID) AS JobCnt, JobType_1.jobTypeName FROM JobType AS JobType_1 INNER JOIN JobType ON JobType_1.jobTypeID = JobType.CategoryID INNER JOIN  Job ON JobType.jobTypeID = Job.jobTypeID INNER JOIN " +
        //        " Section ON JobType.sectionID = Section.sectionID WHERE (Job.sectionID = " + secID + ") AND (Job.jobDueDate < GETDATE()-1) AND (Job.jobStatusID IN (3,8)) GROUP BY JobType_1.jobTypeName";

        //        strSeriesName = "jobTypeName";
        //        lblOngoingJobs.Text = "Over Due Job Order In Cost Control Section";
        //    }
        //    else                                                            // Cost Control User 
        //    {
        //        sqlQuery = "SELECT  COUNT(JobOwner.jobOwnerID) AS JobCnt, JobType_1.jobTypeName FROM   JobType INNER JOIN  JobOwner ON JobType.jobTypeID = JobOwner.JobTypeID INNER JOIN " +
        //                " Section ON JobOwner.sectionID = Section.sectionID INNER JOIN  JobType AS JobType_1 ON JobType.CategoryID = JobType_1.jobTypeID  WHERE (JobOwner.jobOwnerStatusID = 3) AND (JobOwner.contactID = " + _currentUserID + ") GROUP BY JobType_1.jobTypeName";
        //        strSeriesName = "jobTypeName";

        //        lblOngoingJobs.Text = "My On Going Tasks";
        //    }
        //}
        //else if (Session["SectionID"].ToString().Equals("3"))          // Document Control Section
        //{
        //    if (Session["UserProfileID"].ToString().Contains("2"))        // Admin Section
        //    {
        //        sqlQuery = "SELECT COUNT(Job.jobID) AS JobCnt, JobType_1.jobTypeName FROM JobType AS JobType_1 INNER JOIN JobType ON JobType_1.jobTypeID = JobType.CategoryID INNER JOIN  Job ON JobType.jobTypeID = Job.jobTypeID INNER JOIN " +
        //           " Section ON JobType.sectionID = Section.sectionID WHERE (JobType.sectionID = " + secID + ") AND (Job.jobDueDate < GETDATE()-1) AND (Job.jobStatusID IN (3,8)) GROUP BY JobType_1.jobTypeName";

        //        strSeriesName = "jobTypeName";
        //        lblOngoingJobs.Text = "Over Due Job Order In Document Control";
        //    }
        //    else if (Session["UserProfileID"].ToString().Contains("9"))        // Document Control Admin 
        //    {
        //        sqlQuery = "SELECT    COUNT(JobOwner.jobOwnerID) AS JobCnt, JobType_1.jobTypeName  FROM  JobType INNER JOIN     JobOwner ON JobType.jobTypeID = JobOwner.JobTypeID INNER JOIN   Section ON JobOwner.sectionID = Section.sectionID INNER JOIN " +
        //                " JobType AS JobType_1 ON JobType.CategoryID = JobType_1.jobTypeID WHERE (JobOwner.jobOwnerStatusID = 3) AND (JobType.sectionID = 3) GROUP BY JobType_1.jobTypeName";

        //        strSeriesName = "jobTypeName";
        //        lblOngoingJobs.Text = "On-going Jobs In Document Control";
        //    }
        //    else                                                            // Document Control User 
        //    {
        //        sqlQuery = "SELECT  COUNT(JobOwner.jobOwnerID) AS JobCnt, JobType_1.jobTypeName FROM   JobType INNER JOIN  JobOwner ON JobType.jobTypeID = JobOwner.JobTypeID INNER JOIN " +
        //                " Section ON JobOwner.sectionID = Section.sectionID INNER JOIN  JobType AS JobType_1 ON JobType.CategoryID = JobType_1.jobTypeID  WHERE (JobOwner.jobOwnerStatusID = 3) AND (JobOwner.contactID = " + _currentUserID + ") GROUP BY JobType_1.jobTypeName";

        //        strSeriesName = "jobTypeName";
        //        lblOngoingJobs.Text = "My On Going Tasks";
        //    }
        //}
        //else if (Session["SectionID"].ToString().Equals("2"))          // Payment Section
        //{
        //    if (Session["UserProfileID"].ToString().Contains("2"))        // Admin Section
        //    {
        //        sqlQuery = "SELECT  COUNT(JobOwner.jobOwnerID) AS JobCnt, JobType.jobTypeName FROM  JobOwner INNER JOIN   JobType ON JobOwner.JobTypeID = JobType.jobTypeID " +
        //                         " WHERE (JobOwner.payID IS NOT NULL) AND (JobOwner.actionDueDate < GETDATE()-1) AND (JobOwner.jobOwnerStatusID <> 7) GROUP BY JobType.jobTypeName";

        //        strSeriesName = "jobTypeName";
        //        lblOngoingJobs.Text = "Over Due Job Order In Payment Section";
        //    }
        //    else if (Session["UserProfileID"].ToString().Contains("4"))        // Payment Admin 
        //    {
        //        sqlQuery = "SELECT  COUNT(JobOwner.jobOwnerID) AS JobCnt, JobType.jobTypeName FROM  JobOwner INNER JOIN   JobType ON JobOwner.JobTypeID = JobType.jobTypeID " +
        //                         " WHERE (JobOwner.payID IS NOT NULL) AND (JobOwner.actionDueDate < GETDATE()-1) AND (JobOwner.jobOwnerStatusID <> 7) GROUP BY JobType.jobTypeName";

        //        strSeriesName = "jobTypeName";
        //        lblOngoingJobs.Text = "Over Due Job Order In Payment Section";
        //    }
        //    else                                                            // Payment User 
        //    {
        //        sqlQuery = "SELECT  COUNT(JobOwner.jobOwnerID) AS JobCnt, JobType_1.jobTypeName FROM   JobType INNER JOIN  JobOwner ON JobType.jobTypeID = JobOwner.JobTypeID INNER JOIN " +
        //                " Section ON JobOwner.sectionID = Section.sectionID INNER JOIN  JobType AS JobType_1 ON JobType.CategoryID = JobType_1.jobTypeID  WHERE (JobOwner.jobOwnerStatusID = 3) AND (JobOwner.contactID = " + _currentUserID + ") GROUP BY JobType_1.jobTypeName";

        //        strSeriesName = "jobTypeName";
        //        lblOngoingJobs.Text = "My On Going Tasks";
        //    }
        //}
        //else if (Session["SectionID"].ToString().Equals("10"))          // Mngr Control Section
        //{
        //    if (Session["UserProfileID"].ToString().Contains("2"))        // Admin Section
        //    {
        //        sqlQuery = " SELECT COUNT(Job.jobID) AS JobCnt, JobType.jobTypeName FROM  JobType INNER JOIN  Job ON JobType.jobTypeID = Job.jobTypeID INNER JOIN " +
        //                 " Section ON JobType.sectionID = Section.sectionID WHERE (JobType.sectionID = 10) AND (Job.jobDueDate < GETDATE() - 1) AND (Job.jobStatusID IN (3, 8)) GROUP BY JobType.jobTypeName";

        //        strSeriesName = "jobTypeName";
        //        lblOngoingJobs.Text = "Over Due Task In Manager Request";
        //    }
        //    else if (Session["UserProfileID"].ToString().Contains("15"))        // Req Control Admin 
        //    {
        //        sqlQuery = " SELECT COUNT(Job.jobID) AS JobCnt, JobType.jobTypeName FROM  JobType INNER JOIN  Job ON JobType.jobTypeID = Job.jobTypeID INNER JOIN " +
        //                " Section ON JobType.sectionID = Section.sectionID WHERE (JobType.sectionID = 10) AND (Job.jobDueDate < GETDATE() - 1) AND (Job.jobStatusID IN (3, 8)) GROUP BY JobType.jobTypeName";

        //        strSeriesName = "jobTypeName";
        //        lblOngoingJobs.Text = "Over Due Task In Manager Request";
        //    }

        //    else                                                            // Req Control User 
        //    {
        //        sqlQuery = "SELECT  COUNT(JobOwner.jobOwnerID) AS JobCnt, JobType_1.jobTypeName FROM   JobType INNER JOIN  JobOwner ON JobType.jobTypeID = JobOwner.JobTypeID INNER JOIN " +
        //                " Section ON JobOwner.sectionID = Section.sectionID INNER JOIN  JobType AS JobType_1 ON JobType.CategoryID = JobType_1.jobTypeID  WHERE (JobOwner.jobOwnerStatusID = 3) AND (JobOwner.contactID = " + _currentUserID + ") GROUP BY JobType_1.jobTypeName";

        //        strSeriesName = "jobTypeName";

        //        lblOngoingJobs.Text = "My On Going Tasks";
        //    }

        //}
        //else if (Session["SectionID"].ToString().Equals("22"))          // Mngr Control Section
        //{
        //    if (Session["UserProfileID"].ToString().Contains("2"))        // Admin Section
        //    {
        //        sqlQuery = " SELECT COUNT(Job.jobID) AS JobCnt, JobType.jobTypeName FROM  JobType INNER JOIN  Job ON JobType.jobTypeID = Job.jobTypeID INNER JOIN " +
        //                 " Section ON JobType.sectionID = Section.sectionID WHERE (JobType.sectionID = 10) AND (Job.jobDueDate < GETDATE() - 1) AND (Job.jobStatusID IN (3, 8)) GROUP BY JobType.jobTypeName";

        //        strSeriesName = "jobTypeName";
        //        lblOngoingJobs.Text = "Over Due Task In General Service Section";
        //    }
        //    else if (Session["UserProfileID"].ToString().Contains("15"))        // Req Control Admin 
        //    {
        //        sqlQuery = " SELECT COUNT(Job.jobID) AS JobCnt, JobType.jobTypeName FROM  JobType INNER JOIN  Job ON JobType.jobTypeID = Job.jobTypeID INNER JOIN " +
        //                " Section ON JobType.sectionID = Section.sectionID WHERE (JobType.sectionID = 10) AND (Job.jobDueDate < GETDATE() - 1) AND (Job.jobStatusID IN (3, 8)) GROUP BY JobType.jobTypeName";

        //        strSeriesName = "jobTypeName";
        //        lblOngoingJobs.Text = "Over Due Task In General Service Section";
        //    }

        //    else                                                            // Req Control User 
        //    {
        //        sqlQuery = "SELECT  COUNT(JobOwner.jobOwnerID) AS JobCnt, JobType_1.jobTypeName FROM   JobType INNER JOIN  JobOwner ON JobType.jobTypeID = JobOwner.JobTypeID INNER JOIN " +
        //                " Section ON JobOwner.sectionID = Section.sectionID INNER JOIN  JobType AS JobType_1 ON JobType.CategoryID = JobType_1.jobTypeID  WHERE (JobOwner.jobOwnerStatusID = 3) AND (JobOwner.contactID = " + _currentUserID + ") GROUP BY JobType_1.jobTypeName";

        //        strSeriesName = "jobTypeName";

        //        lblOngoingJobs.Text = "My On Going Tasks";
        //    }

        //}
        //else if (Session["SectionID"].ToString().Equals("9"))          // BS Control Section
        //{
        //    if (Session["UserProfileID"].ToString().Contains("2"))        // Admin Section
        //    {
        //        sqlQuery = " SELECT    COUNT(EBDServiceRequests.serviceReqID) AS JobCnt, ServiceType.serviceTypeDescription as jobTypeName FROM EBDServiceRequests INNER JOIN " +
        //                 " ServiceType ON EBDServiceRequests.serviceTypeID = ServiceType.serviceTypeID GROUP BY ServiceType.serviceTypeDescription";

        //        strSeriesName = "jobTypeName";
        //        lblOngoingJobs.Text = "Over Due Task In BS Request";
        //    }
        //    else if (Session["UserProfileID"].ToString().Contains("15"))        // Req Control Admin 
        //    {
        //        sqlQuery = " SELECT    COUNT(EBDServiceRequests.serviceReqID) AS JobCnt, ServiceType.serviceTypeDescription as jobTypeName FROM EBDServiceRequests INNER JOIN " +
        //                 " ServiceType ON EBDServiceRequests.serviceTypeID = ServiceType.serviceTypeID GROUP BY ServiceType.serviceTypeDescription";

        //        strSeriesName = "jobTypeName";
        //        lblOngoingJobs.Text = "Over Due Task In BS Request";
        //    }
        //    else                                                            // Req Control User 
        //    {
        //        sqlQuery = "SELECT  COUNT(JobOwner.jobOwnerID) AS JobCnt, ServiceType.serviceTypeDescription as jobTypeName FROM JobOwner INNER JOIN ServiceType ON JobOwner.JobTypeID = ServiceType.serviceTypeID " +
        //                           " WHERE (JobOwner.jobOwnerStatusID = 3) AND (JobOwner.contactID = " + _currentUserID + ") GROUP BY ServiceType.serviceTypeDescription";

        //        strSeriesName = "jobTypeName";
        //        lblOngoingJobs.Text = "My On Going Tasks";
        //    }
        //}
        //else
        //{
        //    sqlQuery = "SELECT  COUNT(JobOwner.jobOwnerID) AS JobCnt, JobType_1.jobTypeName FROM   JobType INNER JOIN  JobOwner ON JobType.jobTypeID = JobOwner.JobTypeID INNER JOIN " +
        //               " Section ON JobOwner.sectionID = Section.sectionID INNER JOIN  JobType AS JobType_1 ON JobType.CategoryID = JobType_1.jobTypeID  WHERE (JobOwner.jobOwnerStatusID = 3) AND (JobOwner.contactID = " + _currentUserID + ") GROUP BY JobType_1.jobTypeName";

        //    strSeriesName = "jobTypeName";
        //    lblOngoingJobs.Text = "My On Going Tasks";
        //}

        //#endregion


        // Chart_OverDueJobs

        sqlQuery = "SELECT COUNT(Job.jobID) AS JobCnt, JobType.jobTypeName " +
          " FROM JobVOSI INNER JOIN   Job ON JobVOSI.jobID = Job.jobID INNER JOIN JobStatus ON Job.jobStatusID = JobStatus.jobStatusID INNER JOIN " +
                          " JobType ON Job.jobTypeID = JobType.jobTypeID INNER JOIN [Document] ON Job.docRefID = [Document].documentID INNER JOIN " +
                          " Company ON Job.contractorID = Company.companyID INNER JOIN Company AS Company_1 ON Job.consultantID = Company_1.companyID LEFT OUTER JOIN " +
                          " Contact ON JobVOSI.createdBy = Contact.contactID LEFT OUTER JOIN [Document] AS Document_1 ON Job.closedDocRefID = Document_1.documentID LEFT OUTER JOIN " +
                          " PSACostDesc ON JobVOSI.voCatID = PSACostDesc.jobCostID LEFT OUTER JOIN PSAJobTime ON JobVOSI.voTimeCatID = PSAJobTime.jobTimeID LEFT OUTER JOIN " +
                          " StakeHolder ON JobVOSI.invSH = StakeHolder.stakeID " +
          " WHERE (@jobTypeID IS NULL OR  Job.jobTypeID = @jobTypeID)  AND (@contractNo IS NULL OR Job.contractNo = @contractNo) AND (@datefrom IS NULL OR " +
                      " Job.jobReceivedDate >= CONVERT(NVARCHAR, @datefrom, 106)) AND (@dateTo IS NULL OR  Job.jobReceivedDate <= CONVERT(NVARCHAR, @dateTo, 106)) AND (@jobStatusID IS NULL OR Job.jobStatusID = @jobStatusID) AND (@voCreatedBy IS NULL OR " +
                         "  JobVOSI.createdBy = @voCreatedBy) ORDER BY Job.jobReceivedDate DESC";


        //sqlQuery = "SELECT COUNT(Job.jobID) AS JobCnt, JobType_1.jobTypeName FROM JobType AS JobType_1 INNER JOIN JobType ON JobType_1.jobTypeID = JobType.CategoryID INNER JOIN  Job ON JobType.jobTypeID = Job.jobTypeID INNER JOIN " +
        //       " Section ON JobType.sectionID = Section.sectionID WHERE (JobType.sectionID = 1) AND (Job.jobDueDate < GETDATE()-1) AND (Job.jobStatusID IN (3,8)) GROUP BY JobType_1.jobTypeName";

        strSeriesName = "jobTypeName";

        SqlDataAdapter daTndr = new SqlDataAdapter(sqlQuery, connValue);
        daTndr.Fill(dsTndr);
        if (dsTndr.Tables[0].Rows.Count != 0)
        {
            onGoingTasksPerSectionChart.DataSource = dsTndr.Tables[0].DefaultView;

            onGoingTasksPerSectionChart.Series["Series1"].XValueMember = strSeriesName;
            onGoingTasksPerSectionChart.Series["Series1"].YValueMembers = "JobCnt";

            dsTndr.Tables.Clear();

            onGoingTasksPerSectionChart.ChartAreas[0].AxisX.MajorGrid.Enabled = false;
            onGoingTasksPerSectionChart.ChartAreas[0].AxisX.MinorGrid.Enabled = false;
            onGoingTasksPerSectionChart.ChartAreas[0].AxisY.MajorGrid.Enabled = false;
            onGoingTasksPerSectionChart.ChartAreas[0].AxisY.MinorGrid.Enabled = false;

            onGoingTasksPerSectionChart.ChartAreas[0].AxisX.LabelStyle.Angle = 30;
            onGoingTasksPerSectionChart.ChartAreas[0].AxisX.LabelStyle.ForeColor = Color.Maroon;

            onGoingTasksPerSectionChart.ChartAreas[0].AxisX.Interval = 1;
        }

    }



    #endregion











    private void EBDAmount()
    {
        string queryColl = string.Empty;

        foreach (var item in ListBox1.Items)
        {
            queryColl += item + ",";
        }

        queryColl = queryColl + " Job.CreateDate ";

        string sqlQuery = string.Empty;

        Int16 jobid;
        Int16.TryParse(txtCntrNo.Text, out jobid);

        Int16 afrID;
        Int16.TryParse("0", out afrID);

        Int16 dptID;
        Int16.TryParse("0", out dptID);

        Int16 consID;
        Int16.TryParse("0", out consID);

        Int16 jobType;
        Int16.TryParse(txtJobType.Text, out jobType);

        Int16 jobStatus;
        Int16.TryParse("0", out jobStatus);

        Int16 docRefID;
        Int16.TryParse("0", out docRefID);

        Int16 docClsRefID;
        Int16.TryParse("0", out docClsRefID);

        Int16 qsID = 0;
        Int16 ceID = 0;
        Int16 peID = 0;
        string prjTitle = string.Empty;
        string docSubject = string.Empty;

        Int16 cntrID;
        Int16.TryParse("0", out cntrID);


        Int16 consultID;
        Int16.TryParse("0", out consultID);

        string prjCode = string.Empty;
        prjCode = txtCntrNo.Text;

        string txtfrom = string.Empty;
        if (txtdept.Text != "")
            txtfrom = txtdept.Text;


        string txtTo = string.Empty;
        if (txtToDate.Text != "")
            txtTo = txtToDate.Text;

        Int16 VOID;
        Int16.TryParse("0", out VOID);

        Int16 EOTID;
        Int16.TryParse("0", out EOTID);


        Int16 leadID;
        Int16.TryParse("0", out leadID);


        Int16 teamMemID;
        Int16.TryParse("0", out teamMemID);

        DataSet dsTndr = new DataSet();

        string sqlQueryChart = null;
        string strSeriesName = string.Empty;

        strSeriesName = "jobTypeName";

        sqlQueryChart = "SELECT SUM(JobVOSI.ebsdAmt) AS EBSDAmount, JobType.jobTypeName " +
                                 " FROM JobVOSI INNER JOIN Job ON JobVOSI.jobID = Job.jobID INNER JOIN " +
                         " JobStatus ON Job.jobStatusID = JobStatus.jobStatusID INNER JOIN JobType ON Job.jobTypeID = JobType.jobTypeID INNER JOIN [Document] ON Job.docRefID = [Document].documentID INNER JOIN " +
                         " Company ON Job.contractorID = Company.companyID INNER JOIN Company AS Company_1 ON Job.consultantID = Company_1.companyID LEFT OUTER JOIN Contact ON JobVOSI.createdBy = Contact.contactID LEFT OUTER JOIN " +
                          " [Document] AS Document_1 ON Job.closedDocRefID = Document_1.documentID LEFT OUTER JOIN PSACostDesc ON JobVOSI.voCatID = PSACostDesc.jobCostID LEFT OUTER JOIN PSAJobTime ON JobVOSI.voTimeCatID = PSAJobTime.jobTimeID LEFT OUTER JOIN " +
                         " StakeHolder ON JobVOSI.invSH = StakeHolder.stakeID WHERE        (@jobTypeID IS NULL OR Job.jobTypeID = @jobTypeID) AND (@contractNo IS NULL OR Job.contractNo = @contractNo) AND (@datefrom IS NULL OR Job.jobReceivedDate >= CONVERT(NVARCHAR, @datefrom, 106)) " +
        " AND (@dateTo IS NULL OR Job.jobReceivedDate <= CONVERT(NVARCHAR, @dateTo, 106)) AND (@jobStatusID IS NULL OR Job.jobStatusID = @jobStatusID) AND (@voCreatedBy IS NULL OR JobVOSI.createdBy = @voCreatedBy) GROUP BY JobType.jobTypeName";

        strSeriesName = "jobTypeName";

        SqlConnection objCon = new SqlConnection(connValue);
        SqlCommand objCmd = new SqlCommand();
        objCmd.CommandText = sqlQueryChart;
        objCmd.Connection = objCon;

        objCmd.Parameters.AddWithValue("@jobTypeID", System.DBNull.Value);

        if (prjCode != "")
            objCmd.Parameters.AddWithValue("@contractNo", prjCode);
        else
            objCmd.Parameters.AddWithValue("@contractNo", System.DBNull.Value);

        if (txtfrom != "")
            objCmd.Parameters.AddWithValue("@datefrom", txtfrom);
        else
            objCmd.Parameters.AddWithValue("@datefrom", System.DBNull.Value);

        if (txtTo != "")
            objCmd.Parameters.AddWithValue("@dateTo", txtTo);
        else
            objCmd.Parameters.AddWithValue("@dateTo", System.DBNull.Value);

        objCmd.Parameters.AddWithValue("@jobStatusID", System.DBNull.Value);

        objCmd.Parameters.AddWithValue("@voCreatedBy", System.DBNull.Value);

        SqlDataAdapter daTndr = new SqlDataAdapter(objCmd);

        daTndr.Fill(dsTndr);

        if (dsTndr.Tables[0].Rows.Count != 0)
        {
            chartForCost.DataSource = dsTndr.Tables[0].DefaultView;

            chartForCost.Series["Series1"].XValueMember = strSeriesName;
            chartForCost.Series["Series1"].YValueMembers = "EBSDAmount";

            dsTndr.Tables.Clear();

            chartForCost.ChartAreas[0].AxisX.MajorGrid.Enabled = false;
            chartForCost.ChartAreas[0].AxisX.MinorGrid.Enabled = false;
            chartForCost.ChartAreas[0].AxisY.MajorGrid.Enabled = false;
            chartForCost.ChartAreas[0].AxisY.MinorGrid.Enabled = false;

            chartForCost.ChartAreas[0].AxisX.LabelStyle.Angle = 30;
            chartForCost.ChartAreas[0].AxisX.LabelStyle.ForeColor = Color.Maroon;

            chartForCost.ChartAreas[0].AxisX.Interval = 1;
        }

    }
    private void AmountWise()
    {

        //        "SELECT        SUM(JobVOSI.ebsdAmt) AS EBSDAmount, SUM(JobVOSI.pmcAmt) AS PMCAmount, SUM(JobVOSI.consultantAmt) AS ConsultantAmount, SUM(JobVOSI.contractorAmt) 
        //                         AS ContractorAmount, Job.contractNo
        //FROM            JobVOSI INNER JOIN
        //                         Job ON JobVOSI.jobID = Job.jobID INNER JOIN
        //                         JobStatus ON Job.jobStatusID = JobStatus.jobStatusID INNER JOIN
        //                         JobType ON Job.jobTypeID = JobType.jobTypeID INNER JOIN
        //                         [Document] ON Job.docRefID = [Document].documentID INNER JOIN
        //                         Company ON Job.contractorID = Company.companyID INNER JOIN
        //                         Company AS Company_1 ON Job.consultantID = Company_1.companyID LEFT OUTER JOIN
        //                         Contact ON JobVOSI.createdBy = Contact.contactID LEFT OUTER JOIN
        //                         [Document] AS Document_1 ON Job.closedDocRefID = Document_1.documentID LEFT OUTER JOIN
        //                         PSACostDesc ON JobVOSI.voCatID = PSACostDesc.jobCostID LEFT OUTER JOIN
        //                         PSAJobTime ON JobVOSI.voTimeCatID = PSAJobTime.jobTimeID LEFT OUTER JOIN
        //                         StakeHolder ON JobVOSI.invSH = StakeHolder.stakeID
        //WHERE        (@jobTypeID IS NULL OR
        //                         Job.jobTypeID = @jobTypeID) AND (@contractNo IS NULL OR
        //                         Job.contractNo = @contractNo) AND (@datefrom IS NULL OR
        //                         Job.jobReceivedDate >= CONVERT(NVARCHAR, @datefrom, 106)) AND (@dateTo IS NULL OR
        //                         Job.jobReceivedDate <= CONVERT(NVARCHAR, @dateTo, 106)) AND (@jobStatusID IS NULL OR
        //                         Job.jobStatusID = @jobStatusID) AND (@voCreatedBy IS NULL OR
        //                         JobVOSI.createdBy = @voCreatedBy)
        //GROUP BY Job.contractNo";


    }

    protected void ListBox1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void ddlChartType_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void btnBackReport_Click(object sender, EventArgs e)
    {
        tblMain.Visible = true;

        tblGrid.Visible = false;

        // tblGrid.Visible = false;
    }
    protected void btnRmvRow_Click(object sender, EventArgs e)
    {
        if (ListBox1.SelectedItem.Text != "")
        {
            while (ListBox1.SelectedIndex != -1)
            {
                ListBox1.Items.RemoveAt(ListBox1.SelectedIndex);
            }
        }
    }
}