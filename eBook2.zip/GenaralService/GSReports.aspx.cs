﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using System.Data.SqlClient;
using System.Drawing;
using System.Data;
using Datalayer;


using System.Configuration;
using System.Collections;  

public partial class GenaralService_GSReports : System.Web.UI.Page
{
    static string reqNo = string.Empty;
    string connValue = System.Configuration.ConfigurationManager.ConnectionStrings["EBSDEBookConn"].ConnectionString;

    DynamicData dynmicCls = new DynamicData();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            IList<string> tblColle = new List<string>();
            tblColle.Add("JobOrder Info");
            tblColle.Add("Cost Info");
            tblColle.Add("EOT Info");
            tblColle.Add("Document Info");

            DataTable dtNew = new DataTable();
            dtNew = ReadData().Tables[0];

            TreeNode tn = new TreeNode();
            tn.Value = reqNo;
            TreeView1.Nodes.Add(tn);

            foreach (var item in tblColle)
            {
                IList<string> fieldsColle = new List<string>();
                TreeNode tnSub = new TreeNode();

                fieldsColle = getTableFieldsFromSP(item);
                tnSub.Value = item;
                tn.ChildNodes.Add(tnSub);

                foreach (var subitem in fieldsColle)
                {
                    TreeNode tnSub_1 = new TreeNode();
                    tnSub_1.Text = subitem;
                    tnSub_1.Value = subitem;
                    tnSub.ChildNodes.Add(tnSub_1);
                }
            }


            tblGrid.Visible = false;
        }
    }
    private IList<string> getTableFieldsFromSP(string tblName)
    {
        IList<string> feildsColl = new List<string>();

        if (tblName.Equals("JobOrder Info"))
        {
            feildsColl.Add("Job.jobNo");
            feildsColl.Add("Job.contractNo");
            feildsColl.Add("Job.projectTitle");

            feildsColl.Add("JobType.jobTypeName");
            feildsColl.Add("JobStatus.jobStatusName");

            feildsColl.Add("Job.jobReceivedDate");
            feildsColl.Add("Job.jobStatusClosedDate");

            feildsColl.Add("Job.Remarks");

            feildsColl.Add("Affair.affairName");
            feildsColl.Add("Department.deptName");

            feildsColl.Add("Company.cmpName AS Contractor");
            feildsColl.Add("Company_1.cmpName AS Consultant");
        }
        if (tblName.Equals("Staff Info"))
        {
            feildsColl.Add("Contact.displayName");
            feildsColl.Add("Contact_1.displayName");
            feildsColl.Add("Contact_2.displayName");
        }

        return feildsColl;
    }


    private DataSet ReadData()
    {
        DataSet ds = new DataSet();
        try
        {


            Int32 _jobtypeID;
            Int32.TryParse("0", out _jobtypeID);

            Int32 _jobStatusID;
            Int32.TryParse("0", out _jobStatusID);

            Boolean _chkActive;
            Boolean.TryParse(true.ToString(), out _chkActive);

            string _contractNo = string.Empty;
            string txtfrom = string.Empty;
            string txtTo = string.Empty;


            Int32 _voCreatedBY;
            Int32.TryParse("0", out _voCreatedBY);

            // ds = (new JobOrderData().GetDetails_JOBVOSI_Stake_Dynamic(_jobtypeID, _chkActive, _contractNo, txtfrom, txtTo, _jobStatusID, _voCreatedBY));  //SelectedData  

        }
        catch (Exception ex)
        {

        }

        return ds;
    }


    protected void btnBackReport_Click(object sender, EventArgs e)
    {       
        string _section = string.Empty; int chkStaffWise = 0;   

        IList<string> lst = new List<string>();
        lst.Add("Job.JObNo");
        lst.Add("Job.projectTitle");
        lst.Add("Job.JObNo");


        lst.Add("Job.jobReceivedDate");
        lst.Add("Job.jobDueDate");
        lst.Add("Job.jobStatusClosedDate");

        lst.Add("Contact.firstName");
        

        lst.Add("Job.remarks");
  
        string queryColl = string.Empty;
        foreach (var item in lst)
        {
            queryColl += item + ",";
        }

        queryColl = queryColl + " Job.CreateDate ";

        string sqlQuery = string.Empty;
        string sqlQueryStaff = string.Empty; string sqlQueryType = string.Empty; string sqlQueryAmount = string.Empty; string sqlQueryGroupBY = string.Empty;

        chkStaffWise = 1;

        if (chkStaffWise != 1)
        {
            sqlQuery = "SELECT " + queryColl + " " +
               " FROM JobVOSI INNER JOIN Job ON JobVOSI.jobID = Job.jobID INNER JOIN JobStatus ON Job.jobStatusID = JobStatus.jobStatusID INNER JOIN " +
                             " JobType ON Job.jobTypeID = JobType.jobTypeID INNER JOIN [Document] ON Job.docRefID = [Document].documentID INNER JOIN " +
                             " Company ON Job.contractorID = Company.companyID INNER JOIN Company AS Company_1 ON Job.consultantID = Company_1.companyID INNER JOIN " +
                             " Department ON Job.deptID = Department.departmentID INNER JOIN  Affair ON Department.affairID = Affair.affairID LEFT OUTER JOIN " +
                             " Contact ON JobVOSI.CreatedBy = Contact.contactID LEFT OUTER JOIN [Document] AS Document_1 ON Job.closedDocRefID = Document_1.documentID LEFT OUTER JOIN " +
                             " PSACostDesc ON JobVOSI.voCatID = PSACostDesc.jobCostID LEFT OUTER JOIN PSAJobTime ON JobVOSI.voTimeCatID = PSAJobTime.jobTimeID LEFT OUTER JOIN " +
                             " StakeHolder ON JobVOSI.invSH = StakeHolder.stakeID WHERE (@jobTypeID IS NULL OR Job.jobTypeID = @jobTypeID)  AND (@contractNo IS NULL OR Job.contractNo = @contractNo) AND (@datefrom IS NULL OR " +
                             " Job.jobReceivedDate >= CONVERT(NVARCHAR, @datefrom, 106)) AND (@dateTo IS NULL OR Job.jobReceivedDate <= CONVERT(NVARCHAR, @dateTo, 106)) AND (@jobStatusID IS NULL OR " +
                            " Job.jobStatusID = @jobStatusID) AND (@voCreatedBy IS NULL OR JobVOSI.CreatedBy = @voCreatedBy) ORDER BY Job.jobReceivedDate DESC";

        }
        else
        {
            sqlQuery = "SELECT " + queryColl + " " +
                       " FROM JobType INNER JOIN Job ON JobType.jobTypeID = Job.jobTypeID INNER JOIN Department ON Job.deptID = Department.departmentID INNER JOIN " +
                       "  Affair ON Department.affairID = Affair.affairID INNER JOIN JobOwner ON Job.jobID = JobOwner.jobID INNER JOIN Contact ON JobOwner.contactID = Contact.contactID LEFT OUTER JOIN " +
                        " [Document] ON Job.docRefID = [Document].documentID LEFT OUTER JOIN Company ON Job.contractorID = Company.companyID LEFT OUTER JOIN " +
                        " Company AS Company_1 ON Job.consultantID = Company_1.companyID LEFT OUTER JOIN JobVOSI ON Job.jobID = JobVOSI.jobID LEFT OUTER JOIN " +
                        " JobStatus ON Job.jobStatusID = JobStatus.jobStatusID LEFT OUTER JOIN [Document] AS Document_1 ON Job.closedDocRefID = Document_1.documentID LEFT OUTER JOIN " +
                        " Contact AS Contact_1 ON JobVOSI.createdBy = Contact_1.contactID LEFT OUTER JOIN PSACostDesc ON JobVOSI.voCatID = PSACostDesc.jobCostID LEFT OUTER JOIN " +
                        " PSAJobTime ON JobVOSI.voTimeCatID = PSAJobTime.jobTimeID WHERE (@jobTypeID IS NULL OR Job.jobTypeID = @jobTypeID) AND (@contractNo IS NULL OR " +
                        " Job.contractNo = @contractNo) AND (@datefrom IS NULL OR Job.jobReceivedDate >= CONVERT(NVARCHAR, @datefrom, 106)) AND (@dateTo IS NULL OR Job.jobReceivedDate <= CONVERT(NVARCHAR, @dateTo, 106)) AND (@jobStatusID IS NULL OR " +
                        " Job.jobStatusID = @jobStatusID) AND (@voCreatedBy IS NULL OR JobVOSI.createdBy = @voCreatedBy) AND (@StaffName IS NULL OR Contact.firstName = @StaffName) AND (Job.sectionID = " + _section + ") ORDER BY Job.jobReceivedDate ";


            sqlQueryStaff = "SELECT  count(*) as JobCnt,Contact.firstName  " +
             " FROM JobType INNER JOIN Job ON JobType.jobTypeID = Job.jobTypeID INNER JOIN Department ON Job.deptID = Department.departmentID INNER JOIN " +
                       "  Affair ON Department.affairID = Affair.affairID INNER JOIN JobOwner ON Job.jobID = JobOwner.jobID INNER JOIN Contact ON JobOwner.contactID = Contact.contactID LEFT OUTER JOIN " +
                        " [Document] ON Job.docRefID = [Document].documentID LEFT OUTER JOIN Company ON Job.contractorID = Company.companyID LEFT OUTER JOIN " +
                        " Company AS Company_1 ON Job.consultantID = Company_1.companyID LEFT OUTER JOIN JobVOSI ON Job.jobID = JobVOSI.jobID LEFT OUTER JOIN " +
                        " JobStatus ON Job.jobStatusID = JobStatus.jobStatusID LEFT OUTER JOIN [Document] AS Document_1 ON Job.closedDocRefID = Document_1.documentID LEFT OUTER JOIN " +
                        " Contact AS Contact_1 ON JobVOSI.createdBy = Contact_1.contactID LEFT OUTER JOIN PSACostDesc ON JobVOSI.voCatID = PSACostDesc.jobCostID LEFT OUTER JOIN " +
                        " PSAJobTime ON JobVOSI.voTimeCatID = PSAJobTime.jobTimeID WHERE (@jobTypeID IS NULL OR Job.jobTypeID = @jobTypeID) AND (@contractNo IS NULL OR " +
                        " Job.contractNo = @contractNo) AND (@datefrom IS NULL OR Job.jobReceivedDate >= CONVERT(NVARCHAR, @datefrom, 106)) AND (@dateTo IS NULL OR Job.jobReceivedDate <= CONVERT(NVARCHAR, @dateTo, 106)) AND (@jobStatusID IS NULL OR " +
                        " Job.jobStatusID = @jobStatusID) AND (@voCreatedBy IS NULL OR JobVOSI.createdBy = @voCreatedBy) AND (@StaffName IS NULL OR Contact.firstName = @StaffName) AND (Job.sectionID = " + _section + ") GROUP BY Contact.firstName";


            sqlQueryType = "SELECT  count(*) as JobCnt,JobType.jobTypeName " +
             " FROM JobType INNER JOIN Job ON JobType.jobTypeID = Job.jobTypeID INNER JOIN Department ON Job.deptID = Department.departmentID INNER JOIN " +
                       "  Affair ON Department.affairID = Affair.affairID INNER JOIN JobOwner ON Job.jobID = JobOwner.jobID INNER JOIN Contact ON JobOwner.contactID = Contact.contactID LEFT OUTER JOIN " +
                        " [Document] ON Job.docRefID = [Document].documentID LEFT OUTER JOIN Company ON Job.contractorID = Company.companyID LEFT OUTER JOIN " +
                        " Company AS Company_1 ON Job.consultantID = Company_1.companyID LEFT OUTER JOIN JobVOSI ON Job.jobID = JobVOSI.jobID LEFT OUTER JOIN " +
                        " JobStatus ON Job.jobStatusID = JobStatus.jobStatusID LEFT OUTER JOIN [Document] AS Document_1 ON Job.closedDocRefID = Document_1.documentID LEFT OUTER JOIN " +
                        " Contact AS Contact_1 ON JobVOSI.createdBy = Contact_1.contactID LEFT OUTER JOIN PSACostDesc ON JobVOSI.voCatID = PSACostDesc.jobCostID LEFT OUTER JOIN " +
                        " PSAJobTime ON JobVOSI.voTimeCatID = PSAJobTime.jobTimeID WHERE (@jobTypeID IS NULL OR Job.jobTypeID = @jobTypeID) AND (@contractNo IS NULL OR " +
                        " Job.contractNo = @contractNo) AND (@datefrom IS NULL OR Job.jobReceivedDate >= CONVERT(NVARCHAR, @datefrom, 106)) AND (@dateTo IS NULL OR Job.jobReceivedDate <= CONVERT(NVARCHAR, @dateTo, 106)) AND (@jobStatusID IS NULL OR " +
                        " Job.jobStatusID = @jobStatusID) AND (@voCreatedBy IS NULL OR JobVOSI.createdBy = @voCreatedBy) AND (@StaffName IS NULL OR Contact.firstName = @StaffName) AND (Job.sectionID = " + _section + ") GROUP BY JobType.jobTypeName";


            sqlQueryAmount = "SELECT  SUM(JobVOSI.ebsdAmt) AS EBSDAmount, SUM(JobVOSI.pmcAmt) AS PMCAmount, SUM(JobVOSI.consultantAmt) AS ConsultantAmount, SUM(JobVOSI.contractorAmt) AS ContractorAmount, Job.contractNo  " +
                      " FROM JobType INNER JOIN Job ON JobType.jobTypeID = Job.jobTypeID INNER JOIN Department ON Job.deptID = Department.departmentID INNER JOIN " +
                      "  Affair ON Department.affairID = Affair.affairID INNER JOIN JobOwner ON Job.jobID = JobOwner.jobID INNER JOIN Contact ON JobOwner.contactID = Contact.contactID LEFT OUTER JOIN " +
                      " [Document] ON Job.docRefID = [Document].documentID LEFT OUTER JOIN Company ON Job.contractorID = Company.companyID LEFT OUTER JOIN " +
                      " Company AS Company_1 ON Job.consultantID = Company_1.companyID LEFT OUTER JOIN JobVOSI ON Job.jobID = JobVOSI.jobID LEFT OUTER JOIN " +
                      " JobStatus ON Job.jobStatusID = JobStatus.jobStatusID LEFT OUTER JOIN [Document] AS Document_1 ON Job.closedDocRefID = Document_1.documentID LEFT OUTER JOIN " +
                      " Contact AS Contact_1 ON JobVOSI.createdBy = Contact_1.contactID LEFT OUTER JOIN PSACostDesc ON JobVOSI.voCatID = PSACostDesc.jobCostID LEFT OUTER JOIN " +
                      " PSAJobTime ON JobVOSI.voTimeCatID = PSAJobTime.jobTimeID WHERE (@jobTypeID IS NULL OR Job.jobTypeID = @jobTypeID) AND (@contractNo IS NULL OR " +
                      " Job.contractNo = @contractNo) AND (@datefrom IS NULL OR Job.jobReceivedDate >= CONVERT(NVARCHAR, @datefrom, 106)) AND (@dateTo IS NULL OR Job.jobReceivedDate <= CONVERT(NVARCHAR, @dateTo, 106)) AND (@jobStatusID IS NULL OR " +
                      " Job.jobStatusID = @jobStatusID) AND (@voCreatedBy IS NULL OR JobVOSI.createdBy = @voCreatedBy) AND (@StaffName IS NULL OR Contact.firstName = @StaffName) AND (Job.sectionID = " + _section + ") GROUP BY Job.contractNo";


            sqlQueryGroupBY = "SELECT job.contractNo, job.projectTitle, job.jobTypeID,job.jobNo " +
                      " FROM JobType INNER JOIN Job ON JobType.jobTypeID = Job.jobTypeID INNER JOIN Department ON Job.deptID = Department.departmentID INNER JOIN " +
                      "  Affair ON Department.affairID = Affair.affairID INNER JOIN JobOwner ON Job.jobID = JobOwner.jobID INNER JOIN Contact ON JobOwner.contactID = Contact.contactID LEFT OUTER JOIN " +
                       " [Document] ON Job.docRefID = [Document].documentID LEFT OUTER JOIN Company ON Job.contractorID = Company.companyID LEFT OUTER JOIN " +
                       " Company AS Company_1 ON Job.consultantID = Company_1.companyID LEFT OUTER JOIN JobVOSI ON Job.jobID = JobVOSI.jobID LEFT OUTER JOIN " +
                       " JobStatus ON Job.jobStatusID = JobStatus.jobStatusID LEFT OUTER JOIN [Document] AS Document_1 ON Job.closedDocRefID = Document_1.documentID LEFT OUTER JOIN " +
                       " Contact AS Contact_1 ON JobVOSI.createdBy = Contact_1.contactID LEFT OUTER JOIN PSACostDesc ON JobVOSI.voCatID = PSACostDesc.jobCostID LEFT OUTER JOIN " +
                       " PSAJobTime ON JobVOSI.voTimeCatID = PSAJobTime.jobTimeID WHERE (@jobTypeID IS NULL OR Job.jobTypeID = @jobTypeID) AND (@contractNo IS NULL OR " +
                       " Job.contractNo = @contractNo) AND (@datefrom IS NULL OR Job.jobReceivedDate >= CONVERT(NVARCHAR, @datefrom, 106)) AND (@dateTo IS NULL OR Job.jobReceivedDate <= CONVERT(NVARCHAR, @dateTo, 106)) AND (@jobStatusID IS NULL OR " +
                       " Job.jobStatusID = @jobStatusID) AND (@voCreatedBy IS NULL OR JobVOSI.createdBy = @voCreatedBy) AND (@StaffName IS NULL OR Contact.firstName = @StaffName) AND (Job.sectionID = " + _section + ") ORDER BY Job.jobReceivedDate ";



        }

        DataTable dtNew = dynmicCls.GetData(sqlQuery, txtFromDate.Text, txtToDate.Text, "", "", txtStaffName.Text);
        grvMain.DataSource = dtNew;
        grvMain.DataBind();

        DataTable dtStaff = dynmicCls.GetData(sqlQueryStaff, txtFromDate.Text, txtToDate.Text, "","", txtStaffName.Text);
        GetChartData(dtStaff, chartStaffCount, _section, "firstName", "JobCnt");

        DataTable dtJobType = dynmicCls.GetData(sqlQueryType, txtFromDate.Text, txtToDate.Text, "", "", txtStaffName.Text);
        GetChartData(dtJobType, chartJobType, _section, "jobTypeName", "JobCnt");

        DataTable dtAmnt = dynmicCls.GetData(sqlQueryAmount, txtFromDate.Text, txtToDate.Text, "", "", txtStaffName.Text);
        GetChartData(dtAmnt, chartForCost, _section, "EBSDAmount", "contractNo");

        //string strDate = System.DateTime.Now.Date.AddDays(-30).ToString();
        //string endDate = System.DateTime.Now.Date.ToString();

        string strDate = txtFromDate.Text;
        string endDate = txtToDate.Text;     
  
    }
    public void GetChartData(DataTable dtNew, System.Web.UI.DataVisualization.Charting.Chart inputChart, string _section, string xValue, string yValue)
    {
        if (dtNew.Rows.Count != 0)
        {
            inputChart.DataSource = dtNew.DefaultView;

            inputChart.Series["Series1"].XValueMember = xValue;
            inputChart.Series["Series1"].YValueMembers = yValue;

            // dtNew.Clear();

            inputChart.ChartAreas[0].AxisX.MajorGrid.Enabled = false;
            inputChart.ChartAreas[0].AxisX.MinorGrid.Enabled = false;
            inputChart.ChartAreas[0].AxisY.MajorGrid.Enabled = false;
            inputChart.ChartAreas[0].AxisY.MinorGrid.Enabled = false;

            inputChart.ChartAreas[0].AxisX.LabelStyle.Angle = 30;
            inputChart.ChartAreas[0].AxisX.LabelStyle.ForeColor = Color.Maroon;

            inputChart.ChartAreas[0].AxisX.Interval = 1;
        }
    }

    protected void btnExcel_Click(object sender, EventArgs e)
    {

    }
   

    protected void btnSubmit_Click1(object sender, EventArgs e)
    {
        tblMain.Visible = false;

        tblGrid.Visible = true;

        // DataTable dt = new DataTable();
        IList<string> lst = new List<string>();
        lst.Add("");
        foreach (var item in ListBox1.Items)
        {
            lst.Add(item.ToString());
        }
        ddlSortBy.DataSource = lst;
        ddlSortBy.DataBind();

        string queryColl = string.Empty;
        foreach (var item in ListBox1.Items)
        {
            queryColl += item + ",";
        }

        queryColl = queryColl + " Job.CreateDate ";

        string sqlQuery = string.Empty;

        //  AND (@chkVOActive IS NULL OR JobVOSI.isVOActive = @chkVOActive)

        sqlQuery = "SELECT " + queryColl + " " +
           " FROM JobVOSI INNER JOIN Job ON JobVOSI.jobID = Job.jobID INNER JOIN JobStatus ON Job.jobStatusID = JobStatus.jobStatusID INNER JOIN " +
                         " JobType ON Job.jobTypeID = JobType.jobTypeID INNER JOIN [Document] ON Job.docRefID = [Document].documentID INNER JOIN " +
                         " Company ON Job.contractorID = Company.companyID INNER JOIN Company AS Company_1 ON Job.consultantID = Company_1.companyID INNER JOIN " +
                         " Department ON Job.deptID = Department.departmentID INNER JOIN  Affair ON Department.affairID = Affair.affairID LEFT OUTER JOIN " +
                         " Contact ON JobVOSI.CreatedBy = Contact.contactID LEFT OUTER JOIN [Document] AS Document_1 ON Job.closedDocRefID = Document_1.documentID LEFT OUTER JOIN " +
                         " PSACostDesc ON JobVOSI.voCatID = PSACostDesc.jobCostID LEFT OUTER JOIN PSAJobTime ON JobVOSI.voTimeCatID = PSAJobTime.jobTimeID LEFT OUTER JOIN " +
                         " StakeHolder ON JobVOSI.invSH = StakeHolder.stakeID WHERE (@jobTypeID IS NULL OR Job.jobTypeID = @jobTypeID)  AND (@contractNo IS NULL OR Job.contractNo = @contractNo) AND (@datefrom IS NULL OR " +
                         " Job.jobReceivedDate >= CONVERT(NVARCHAR, @datefrom, 106)) AND (@dateTo IS NULL OR Job.jobReceivedDate <= CONVERT(NVARCHAR, @dateTo, 106)) AND (@jobStatusID IS NULL OR " +
                        " Job.jobStatusID = @jobStatusID) AND (@voCreatedBy IS NULL OR JobVOSI.CreatedBy = @voCreatedBy) ORDER BY Job.jobReceivedDate DESC";

        //AND (@chkVOActive IS NULL OR JobVOSI.isVOActive = @chkVOActive)

        Int16 jobid;
        Int16.TryParse(txtCntrNo.Text, out jobid);

        Int16 afrID;
        Int16.TryParse("0", out afrID);

        Int16 dptID;
        Int16.TryParse("0", out dptID);

        Int16 consID;
        Int16.TryParse("0", out consID);

        Int16 jobType;
        Int16.TryParse(txtJobType.Text, out jobType);

        Int16 jobStatus;
        Int16.TryParse("0", out jobStatus);

        Int16 docRefID;
        Int16.TryParse("0", out docRefID);

        Int16 docClsRefID;
        Int16.TryParse("0", out docClsRefID);

        Int16 qsID = 0;
        Int16 ceID = 0;
        Int16 peID = 0;
        string prjTitle = string.Empty;
        string docSubject = string.Empty;

        Int16 cntrID;
        Int16.TryParse("0", out cntrID);


        Int16 consultID;
        Int16.TryParse("0", out consultID);

        string prjCode = string.Empty;
        prjCode = txtCntrNo.Text;

        string txtfrom = string.Empty;
        if (txtdept.Text != "")
            txtfrom = txtdept.Text;


        string txtTo = string.Empty;
        if (txtToDate.Text != "")
            txtTo = txtToDate.Text;

        Int16 VOID;
        Int16.TryParse("0", out VOID);

        Int16 EOTID;
        Int16.TryParse("0", out EOTID);


        Int16 leadID;
        Int16.TryParse("0", out leadID);


        Int16 teamMemID;
        Int16.TryParse("0", out teamMemID);



        SqlConnection objCon = new SqlConnection(connValue);
        SqlCommand objCmd = new SqlCommand(sqlQuery, objCon);
        SqlDataAdapter objDA = new SqlDataAdapter(objCmd);

        objDA.SelectCommand.CommandText = objCmd.CommandText.ToString();

        //cmd.Connection = conn;

        objCmd.Parameters.AddWithValue("@jobTypeID", System.DBNull.Value);

        //  objCmd.Parameters.AddWithValue("@chkVOActive", true);

        if (prjCode != "")
            objCmd.Parameters.AddWithValue("@contractNo", prjCode);
        else
            objCmd.Parameters.AddWithValue("@contractNo", System.DBNull.Value);

        if (txtfrom != "")
            objCmd.Parameters.AddWithValue("@datefrom", txtfrom);
        else
            objCmd.Parameters.AddWithValue("@datefrom", System.DBNull.Value);

        if (txtTo != "")
            objCmd.Parameters.AddWithValue("@dateTo", txtTo);
        else
            objCmd.Parameters.AddWithValue("@dateTo", System.DBNull.Value);


        objCmd.Parameters.AddWithValue("@jobStatusID", System.DBNull.Value);

        objCmd.Parameters.AddWithValue("@voCreatedBy", System.DBNull.Value);
        
        DataTable dt = new DataTable();
        objDA.Fill(dt);

        Session["ChartJobs"] = dt;

        lblCnt.Text = dt.Rows.Count.ToString();
     
    }
    protected void btnClrAll_Click(object sender, EventArgs e)
    {

    }
    protected void btnBack_Click(object sender, EventArgs e)
    {

    }
    protected void btnStrDt_Click(object sender, EventArgs e)
    {

    }
    protected void btnEndDt_Click(object sender, EventArgs e)
    {

    }
    protected void btnCntr_Click(object sender, EventArgs e)
    {

    }
    protected void btnType_Click(object sender, EventArgs e)
    {

    }
    protected void ddlSortBy_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void btnRmvRow_Click(object sender, EventArgs e)
    {

    }
    protected void ddlProfileType_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void ListBox1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
}