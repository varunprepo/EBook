﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;


using System.IO;
using System.Data.SqlClient;
using System.Drawing;
using System.Data;
using Datalayer;


using System.Configuration;
using System.Collections;  


public partial class GenaralService_GSDynamicReport : System.Web.UI.Page
{
     static string reqNo = string.Empty;
    string connValue = System.Configuration.ConfigurationManager.ConnectionStrings["EBSDEBookConn"].ConnectionString;

    DynamicData dynmicCls = new DynamicData();
    
    protected void btnSubmit_Click1(object sender, EventArgs e)
    {
       // txtToDate.Text = System.DateTime.Now.Date.ToString();

        string _section = string.Empty; int chkStaffWise = 0; 

        tblMain.Visible = false;
        tblGrid.Visible = true;       

        IList<string> lst = new List<string>();
        lst.Add("");

        foreach (var item in ListBox1.Items)
        {
            string[] strColl = item.ToString().Split('.');

            lst.Add(strColl[1].ToString());
            if (item.ToString().Contains("Name"))
            {
                chkStaffWise = 1; // Staff included
            }
        }

        ddlSortBy.DataSource = lst;
        ddlSortBy.DataBind();

        ddl_X.DataSource = lst;
        ddl_X.DataBind();

        ddl_Y.DataSource = lst;
        ddl_Y.DataBind();

        ddl_Z.DataSource = lst;
        ddl_Z.DataBind();

        if (ddlSection.SelectedValue != "")
        {
            _section = ddlSection.SelectedValue;
        }
        else
            _section = "1";

        string queryColl = string.Empty;
        foreach (var item in ListBox1.Items)
        {
            queryColl += item + ",";
        }

        queryColl = queryColl + " Job.CreateDate ";

        string sqlQuery = string.Empty;
        string sqlQueryStaff = string.Empty; string sqlQueryType = string.Empty; string sqlQueryAmount = string.Empty; string sqlQueryGroupBY = string.Empty; 



        if (chkStaffWise != 1)
        {
            sqlQuery = "SELECT " + queryColl + " " +
               " FROM JobVOSI INNER JOIN Job ON JobVOSI.jobID = Job.jobID INNER JOIN JobStatus ON Job.jobStatusID = JobStatus.jobStatusID INNER JOIN " +
                             " JobType ON Job.jobTypeID = JobType.jobTypeID INNER JOIN [Document] ON Job.docRefID = [Document].documentID INNER JOIN " +
                             " Company ON Job.contractorID = Company.companyID INNER JOIN Company AS Company_1 ON Job.consultantID = Company_1.companyID INNER JOIN " +
                             " Department ON Job.deptID = Department.departmentID INNER JOIN  Affair ON Department.affairID = Affair.affairID LEFT OUTER JOIN " +
                             " Contact ON JobVOSI.CreatedBy = Contact.contactID LEFT OUTER JOIN [Document] AS Document_1 ON Job.closedDocRefID = Document_1.documentID LEFT OUTER JOIN " +
                             " PSACostDesc ON JobVOSI.voCatID = PSACostDesc.jobCostID LEFT OUTER JOIN PSAJobTime ON JobVOSI.voTimeCatID = PSAJobTime.jobTimeID LEFT OUTER JOIN " +
                             " StakeHolder ON JobVOSI.invSH = StakeHolder.stakeID WHERE (@jobTypeID IS NULL OR Job.jobTypeID = @jobTypeID)  AND (@contractNo IS NULL OR Job.contractNo = @contractNo) AND (@datefrom IS NULL OR " +
                             " Job.jobReceivedDate >= CONVERT(NVARCHAR, @datefrom, 106)) AND (@dateTo IS NULL OR Job.jobReceivedDate <= CONVERT(NVARCHAR, @dateTo, 106)) AND (@jobStatusID IS NULL OR " +
                            " Job.jobStatusID = @jobStatusID) AND (@voCreatedBy IS NULL OR JobVOSI.CreatedBy = @voCreatedBy) ORDER BY Job.jobReceivedDate DESC";

        }
        else
        {            
            sqlQuery = "SELECT " + queryColl + " " +
               "FROM JobType INNER JOIN   Job ON JobType.jobTypeID = Job.jobTypeID INNER JOIN  Department ON Job.deptID = Department.departmentID INNER JOIN " +
                        " Affair ON Department.affairID = Affair.affairID LEFT OUTER JOIN  JobStatus ON Job.jobStatusID = JobStatus.jobStatusID WHERE    (@jobTypeID IS NULL OR  Job.jobTypeID = @jobTypeID) AND " + 
                          " (@contractNo IS NULL OR   Job.contractNo = @contractNo) AND (@datefrom IS NULL OR  Job.jobReceivedDate >= CONVERT(NVARCHAR, @datefrom, 106)) AND (@dateTo IS NULL OR " +
                         " Job.jobReceivedDate <= CONVERT(NVARCHAR, @dateTo, 106)) AND (@jobStatusID IS NULL OR  Job.jobStatusID = @jobStatusID) AND (Job.sectionID = 22) ORDER BY Job.jobReceivedDate";


            sqlQueryStaff = "SELECT  count(*) as JobCnt,Contact.firstName  " +
             " FROM JobType INNER JOIN   Job ON JobType.jobTypeID = Job.jobTypeID INNER JOIN  Department ON Job.deptID = Department.departmentID INNER JOIN    Affair ON Department.affairID = Affair.affairID INNER JOIN " + 
                        " JobOwner ON Job.jobID = JobOwner.jobID INNER JOIN   Contact ON JobOwner.contactID = Contact.contactID LEFT OUTER JOIN JobStatus ON Job.jobStatusID = JobStatus.jobStatusID " + 
                          "WHERE        (@jobTypeID IS NULL OR   Job.jobTypeID = @jobTypeID) AND (@contractNo IS NULL OR Job.contractNo = @contractNo) AND (@datefrom IS NULL OR    Job.jobReceivedDate >= CONVERT(NVARCHAR, @datefrom, 106)) AND (@dateTo IS NULL OR " + 
                        " Job.jobReceivedDate <= CONVERT(NVARCHAR, @dateTo, 106)) AND (@jobStatusID IS NULL OR   Job.jobStatusID = @jobStatusID) AND (Job.sectionID = 22) AND (@StaffName IS NULL OR  Contact.firstName = @StaffName) GROUP BY Contact.firstName";
            
            sqlQueryType = "SELECT  count(*) as JobCnt,JobType.jobTypeName " +
             "  FROM JobType INNER JOIN  Job ON JobType.jobTypeID = Job.jobTypeID INNER JOIN   Department ON Job.deptID = Department.departmentID INNER JOIN Affair ON Department.affairID = Affair.affairID LEFT OUTER JOIN JobStatus ON Job.jobStatusID = JobStatus.jobStatusID " + 
                        " WHERE        (@jobTypeID IS NULL OR   Job.jobTypeID = @jobTypeID) AND (@contractNo IS NULL OR  Job.contractNo = @contractNo) AND (@datefrom IS NULL OR " + 
                         " Job.jobReceivedDate >= CONVERT(NVARCHAR, @datefrom, 106)) AND (@dateTo IS NULL OR  Job.jobReceivedDate <= CONVERT(NVARCHAR, @dateTo, 106)) AND (@jobStatusID IS NULL OR" + 
                         " Job.jobStatusID = @jobStatusID) AND (Job.sectionID = 22) GROUP BY JobType.jobTypeName";


            sqlQueryGroupBY = "SELECT job.contractNo, job.projectTitle, JobType.JobTypeName,job.jobNo " +
                     "FROM  JobType INNER JOIN   Job ON JobType.jobTypeID = Job.jobTypeID INNER JOIN  Department ON Job.deptID = Department.departmentID INNER JOIN  Affair ON Department.affairID = Affair.affairID LEFT OUTER JOIN " +
                        " JobStatus ON Job.jobStatusID = JobStatus.jobStatusID  WHERE        (@jobTypeID IS NULL OR  Job.jobTypeID = @jobTypeID) AND (@contractNo IS NULL OR   Job.contractNo = @contractNo) AND (@datefrom IS NULL OR " +
                        " Job.jobReceivedDate >= CONVERT(NVARCHAR, @datefrom, 106)) AND (@dateTo IS NULL OR  Job.jobReceivedDate <= CONVERT(NVARCHAR, @dateTo, 106)) AND (@jobStatusID IS NULL OR  Job.jobStatusID = @jobStatusID) AND (Job.sectionID = 22) ORDER BY Job.jobRec";



        }

      DataTable dtNew =  dynmicCls.GetData(sqlQuery, txtFromDate.Text, txtToDate.Text, txtCntrNo.Text, txtJobType.Text, txtStaffName.Text);
      grvMain.DataSource = dtNew;
      grvMain.DataBind();

      lblCnt.Text = dtNew.Rows.Count.ToString();

      DataTable dtStaff = dynmicCls.GetData(sqlQueryStaff,  txtFromDate.Text, txtToDate.Text, txtCntrNo.Text, txtJobType.Text, txtStaffName.Text);
      GetChartData(dtStaff, chartStaffCount, _section, "firstName", "JobCnt");

      if (dtStaff.Rows.Count < 15)
      {
          chartStaffCount.Width = Panel1.Width;
          chartStaffCount.Height = Panel1.Height;
      }
      else if (dtStaff.Rows.Count < 30)
      {
          chartStaffCount.Width = new Unit(400 + Panel1.Width.Value, UnitType.Pixel);
      }  
      else
          chartStaffCount.Width = new Unit(2*Panel1.Width.Value, UnitType.Pixel);          //chartStaffCount.Width.Value

      DataTable dtJobType = dynmicCls.GetData(sqlQueryType, txtFromDate.Text, txtToDate.Text, txtCntrNo.Text, txtJobType.Text, txtStaffName.Text);
      GetChartData(dtJobType, chartJobType, _section, "jobTypeName", "JobCnt");

     

      string strDate = txtFromDate.Text;
      string endDate = txtToDate.Text;

    
      getYearAndmonthWiseJobCount();
  
    }
    public void GetChartData(DataTable dtNew, System.Web.UI.DataVisualization.Charting.Chart inputChart, string _section, string xValue, string yValue)
    {
        if (dtNew.Rows.Count != 0)
        {
            inputChart.DataSource = dtNew.DefaultView;

            inputChart.Series["Series1"].XValueMember = xValue;
            inputChart.Series["Series1"].YValueMembers = yValue;

           // dtNew.Clear();

            inputChart.ChartAreas[0].AxisX.MajorGrid.Enabled = false;
            inputChart.ChartAreas[0].AxisX.MinorGrid.Enabled = false;
            inputChart.ChartAreas[0].AxisY.MajorGrid.Enabled = false;
            inputChart.ChartAreas[0].AxisY.MinorGrid.Enabled = false;

            inputChart.ChartAreas[0].AxisX.LabelStyle.Angle = 30;
            inputChart.ChartAreas[0].AxisX.LabelStyle.ForeColor = Color.Maroon;

            inputChart.ChartAreas[0].AxisX.Interval = 1;
        }
    }

    

    // =================================================================================================================================================

    protected void Page_Load(object sender, EventArgs e)
    {      
        if (!IsPostBack)
        {           
            IList<string> tblColle = new List<string>();

            tblColle.Add("JobOrder Info");            
            tblColle.Add("Staff Info");        

            TreeNode tn = new TreeNode();
            tn.Value = reqNo;
            TreeView1.Nodes.Add(tn);

            foreach (var item in tblColle)
            {
                IList<string> fieldsColle = new List<string>();
                TreeNode tnSub = new TreeNode();

                fieldsColle = dynmicCls.getTableFieldsFromSP(item);
                tnSub.Value = item;
                tn.ChildNodes.Add(tnSub);

                foreach (var subitem in fieldsColle)
                {
                    TreeNode tnSub_1 = new TreeNode();
                    tnSub_1.Text = subitem;
                    tnSub_1.Value = subitem;
                    tnSub.ChildNodes.Add(tnSub_1);
                }
            }

           // tblGrid.Visible = false;
           // tblGroup.Visible = false;
            
        }
    }
   
 

    // =================================================================================================================================================

    private void getAmountChart()
    {
        string queryColl = string.Empty;

        foreach (var item in ListBox1.Items)
        {
            queryColl += item + ",";
        }

        queryColl = queryColl + " Job.CreateDate ";
    }   
    protected void btnBack_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/JobOrder/CostControlHomePage.aspx", false);
    }
    protected void Select_Change(object sender, EventArgs e)
    {
        string strClmnName = TreeView1.SelectedNode.Text;
        ListBox1.Items.Add(strClmnName);
    }
   
   
    private void getAmountData()
    {
        DataSet dsTndr = new DataSet();
        string sqlQueyAmnt = "SELECT SUM(JobVOSI.ebsdAmt) AS EBSDAmount, SUM(JobVOSI.contractorAmt) AS contractorAmt, YEAR(Job.jobReceivedDate) AS YearName " +
             " FROM            JobVOSI INNER JOIN  Job ON JobVOSI.jobID = Job.jobID INNER JOIN   JobType ON Job.jobTypeID = JobType.jobTypeID WHERE  (JobType.CategoryID IN (4, 7)) GROUP BY YEAR(Job.jobReceivedDate) ORDER BY YearName";

        string strSeriesName = "EBSDAmount";


     //   objCmd.CommandText = sqlQueryChart;

        SqlDataAdapter daTndr = new SqlDataAdapter(sqlQueyAmnt,connValue);
        daTndr.Fill(dsTndr);
        if (dsTndr.Tables[0].Rows.Count != 0)
        {
            chartJobType.DataSource = dsTndr.Tables[0].DefaultView;

            chartJobType.Series["Series1"].XValueMember = strSeriesName;
            chartJobType.Series["Series1"].YValueMembers = "YearName";

            dsTndr.Tables.Clear();

            chartJobType.ChartAreas[0].AxisX.MajorGrid.Enabled = false;
            chartJobType.ChartAreas[0].AxisX.MinorGrid.Enabled = false;
            chartJobType.ChartAreas[0].AxisY.MajorGrid.Enabled = false;
            chartJobType.ChartAreas[0].AxisY.MinorGrid.Enabled = false;

            chartJobType.ChartAreas[0].AxisX.LabelStyle.Angle = 30;
            chartJobType.ChartAreas[0].AxisX.LabelStyle.ForeColor = Color.Maroon;

            chartJobType.ChartAreas[0].AxisX.Interval = 1;
        }


    }
    private void ChartForJobType()
    {
        SqlCommand objCmd = new SqlCommand();

        DataSet dsTndr = new DataSet();
        string sqlQueryChart = null;
        string strSeriesName = string.Empty;

        strSeriesName = "jobTypeName";

        sqlQueryChart = "SELECT COUNT(Job.jobID) AS JobCnt, JobType.jobTypeName " +
                                 " FROM JobVOSI INNER JOIN Job ON JobVOSI.jobID = Job.jobID INNER JOIN " +
                         " JobStatus ON Job.jobStatusID = JobStatus.jobStatusID INNER JOIN JobType ON Job.jobTypeID = JobType.jobTypeID INNER JOIN [Document] ON Job.docRefID = [Document].documentID INNER JOIN " +
                         " Company ON Job.contractorID = Company.companyID INNER JOIN Company AS Company_1 ON Job.consultantID = Company_1.companyID LEFT OUTER JOIN Contact ON JobVOSI.createdBy = Contact.contactID LEFT OUTER JOIN " +
                          " [Document] AS Document_1 ON Job.closedDocRefID = Document_1.documentID LEFT OUTER JOIN PSACostDesc ON JobVOSI.voCatID = PSACostDesc.jobCostID LEFT OUTER JOIN PSAJobTime ON JobVOSI.voTimeCatID = PSAJobTime.jobTimeID LEFT OUTER JOIN " +
                         " StakeHolder ON JobVOSI.invSH = StakeHolder.stakeID WHERE  (@jobTypeID IS NULL OR Job.jobTypeID = @jobTypeID) AND (@contractNo IS NULL OR Job.contractNo = @contractNo) AND (@datefrom IS NULL OR Job.jobReceivedDate >= CONVERT(NVARCHAR, @datefrom, 106)) " +
        " AND (@dateTo IS NULL OR Job.jobReceivedDate <= CONVERT(NVARCHAR, @dateTo, 106)) AND (@jobStatusID IS NULL OR Job.jobStatusID = @jobStatusID) AND (@voCreatedBy IS NULL OR JobVOSI.createdBy = @voCreatedBy) GROUP BY JobType.jobTypeName";

        strSeriesName = "jobTypeName";


        objCmd.CommandText = sqlQueryChart;

        SqlDataAdapter daTndr = new SqlDataAdapter(objCmd);
        daTndr.Fill(dsTndr);
        if (dsTndr.Tables[0].Rows.Count != 0)
        {
            chartJobType.DataSource = dsTndr.Tables[0].DefaultView;

            chartJobType.Series["Series1"].XValueMember = strSeriesName;
            chartJobType.Series["Series1"].YValueMembers = "JobCnt";

            dsTndr.Tables.Clear();

            chartJobType.ChartAreas[0].AxisX.MajorGrid.Enabled = false;
            chartJobType.ChartAreas[0].AxisX.MinorGrid.Enabled = false;
            chartJobType.ChartAreas[0].AxisY.MajorGrid.Enabled = false;
            chartJobType.ChartAreas[0].AxisY.MinorGrid.Enabled = false;

            chartJobType.ChartAreas[0].AxisX.LabelStyle.Angle = 30;
            chartJobType.ChartAreas[0].AxisX.LabelStyle.ForeColor = Color.Maroon;

            chartJobType.ChartAreas[0].AxisX.Interval = 1;
        }
    }
   
    protected void btnExcel_Click(object sender, EventArgs e)
    {
        ExportToExcel_Sree();
    }

   
    protected void btnClrAll_Click(object sender, EventArgs e)
    {
        ListBox1.Items.Clear();

        txtFromDate.Text = "";
        txtToDate.Text = "";
        txtCntrNo.Text = "";
        txtJobType.Text = "";
    }

   

    protected void ddlProfileType_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlProfileType.SelectedValue.Equals("Dates Between"))
        {
            trStartDate.Visible = true;
            trEndDate.Visible = true;
        }
        else if (ddlProfileType.SelectedValue.Equals("Contract No."))
        {
            trCntr.Visible = true;
        }
        else if (ddlProfileType.SelectedValue.Equals("Job Type"))
        {
            trType.Visible = true;
        }
        else if (ddlProfileType.SelectedValue.Equals("Job Status"))
        {
           // trStartDate.Visible = true;
        }
        else
        {
            trStartDate.Visible = false;
            trEndDate.Visible = false;
            trCntr.Visible = false;
            trType.Visible = false;

        }
    }
    protected void btnStrDt_Click(object sender, EventArgs e)
    {
        trStartDate.Visible = false;
        trEndDate.Visible = false;

        txtToDate.Text = "";
        txtToDate.Text = "";
    }
    protected void btnEndDt_Click(object sender, EventArgs e)
    {
        trStartDate.Visible = false;
        trEndDate.Visible = false;

        txtToDate.Text = "";
        txtToDate.Text = "";
    }
    protected void btnCntr_Click(object sender, EventArgs e)
    {
        trCntr.Visible = false;
        txtCntrNo.Text = "";
    }
    protected void btnType_Click(object sender, EventArgs e)
    {
        trType.Visible = false;
        txtJobType.Text = "";
    }




    #region MyRegion



    private void getOnGoingTasksPerSection_New()
    {
        DataSet dsTndr = new DataSet();

        string sqlQuery = null;
        
        //int secID = Convert.ToInt32(Session["SectionID"]);

        string strSeriesName = string.Empty;

        //#region MyRegion
  


        // Chart_OverDueJobs

        sqlQuery = "SELECT COUNT(Job.jobID) AS JobCnt, JobType.jobTypeName " + 
          " FROM JobVOSI INNER JOIN   Job ON JobVOSI.jobID = Job.jobID INNER JOIN JobStatus ON Job.jobStatusID = JobStatus.jobStatusID INNER JOIN " +
                          " JobType ON Job.jobTypeID = JobType.jobTypeID INNER JOIN [Document] ON Job.docRefID = [Document].documentID INNER JOIN " +
                          " Company ON Job.contractorID = Company.companyID INNER JOIN Company AS Company_1 ON Job.consultantID = Company_1.companyID LEFT OUTER JOIN " +
                          " Contact ON JobVOSI.createdBy = Contact.contactID LEFT OUTER JOIN [Document] AS Document_1 ON Job.closedDocRefID = Document_1.documentID LEFT OUTER JOIN " +
                          " PSACostDesc ON JobVOSI.voCatID = PSACostDesc.jobCostID LEFT OUTER JOIN PSAJobTime ON JobVOSI.voTimeCatID = PSAJobTime.jobTimeID LEFT OUTER JOIN " +
                          " StakeHolder ON JobVOSI.invSH = StakeHolder.stakeID " +
          " WHERE (@jobTypeID IS NULL OR  Job.jobTypeID = @jobTypeID)  AND (@contractNo IS NULL OR Job.contractNo = @contractNo) AND (@datefrom IS NULL OR " +
                      " Job.jobReceivedDate >= CONVERT(NVARCHAR, @datefrom, 106)) AND (@dateTo IS NULL OR  Job.jobReceivedDate <= CONVERT(NVARCHAR, @dateTo, 106)) AND (@jobStatusID IS NULL OR Job.jobStatusID = @jobStatusID) AND (@voCreatedBy IS NULL OR " +
                         "  JobVOSI.createdBy = @voCreatedBy) ORDER BY Job.jobReceivedDate DESC";


        //sqlQuery = "SELECT COUNT(Job.jobID) AS JobCnt, JobType_1.jobTypeName FROM JobType AS JobType_1 INNER JOIN JobType ON JobType_1.jobTypeID = JobType.CategoryID INNER JOIN  Job ON JobType.jobTypeID = Job.jobTypeID INNER JOIN " +
        //       " Section ON JobType.sectionID = Section.sectionID WHERE (JobType.sectionID = 1) AND (Job.jobDueDate < GETDATE()-1) AND (Job.jobStatusID IN (3,8)) GROUP BY JobType_1.jobTypeName";

        strSeriesName = "jobTypeName";

        SqlDataAdapter daTndr = new SqlDataAdapter(sqlQuery, connValue);
        daTndr.Fill(dsTndr);
        if (dsTndr.Tables[0].Rows.Count != 0)
        {
            chartJobType.DataSource = dsTndr.Tables[0].DefaultView;

            chartJobType.Series["Series1"].XValueMember = strSeriesName;
            chartJobType.Series["Series1"].YValueMembers = "JobCnt";

            dsTndr.Tables.Clear();

            chartJobType.ChartAreas[0].AxisX.MajorGrid.Enabled = false;
            chartJobType.ChartAreas[0].AxisX.MinorGrid.Enabled = false;
            chartJobType.ChartAreas[0].AxisY.MajorGrid.Enabled = false;
            chartJobType.ChartAreas[0].AxisY.MinorGrid.Enabled = false;

            chartJobType.ChartAreas[0].AxisX.LabelStyle.Angle = 30;
            chartJobType.ChartAreas[0].AxisX.LabelStyle.ForeColor = Color.Maroon;

            chartJobType.ChartAreas[0].AxisX.Interval = 1;
        }

    }



    #endregion











   
  

    protected void ListBox1_SelectedIndexChanged(object sender, EventArgs e)
    {
       
    }
    protected void ddlChartType_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void btnBackReport_Click(object sender, EventArgs e)
    {
        tblMain.Visible = true;

        tblGrid.Visible = false;

       // tblGrid.Visible = false;
    }
    protected void btnRmvRow_Click(object sender, EventArgs e)
    {
        if (ListBox1.SelectedItem.Text != "")
        {
            while (ListBox1.SelectedIndex != -1)
            {
                ListBox1.Items.RemoveAt(ListBox1.SelectedIndex);
            }
        }
    }



    #region MyRegion
        
    
  
      void ShowingGroupingDataInGridView(GridViewRowCollection gridViewRows, int startIndex, int totalColumns)  
        {  
            if (totalColumns == 0) return;  
            int i, count = 1;  
            ArrayList lst = new ArrayList();  
            lst.Add(gridViewRows[0]);  
            var ctrl = gridViewRows[0].Cells[startIndex];  
            for (i = 1; i < gridViewRows.Count; i++)  
            {  
                TableCell nextTbCell = gridViewRows[i].Cells[startIndex];  
                if (ctrl.Text == nextTbCell.Text)  
                {  
                    count++;  
                    nextTbCell.Visible = false;  
                    lst.Add(gridViewRows[i]);   
                }  
                else  
                {  
                    if (count > 1)  
                    {  
                        ctrl.RowSpan = count;   
                        ShowingGroupingDataInGridView(new GridViewRowCollection(lst), startIndex + 1, totalColumns - 1);  
                    }  
                    count = 1;  
                    lst.Clear();                      
                    ctrl = gridViewRows[i].Cells[startIndex];  
                    lst.Add(gridViewRows[i]);  
                }  
            }  
            if (count > 1)  
            {  
                ctrl.RowSpan = count;                  
                ShowingGroupingDataInGridView(new GridViewRowCollection(lst), startIndex + 1, totalColumns - 1);  
            }  
            count = 1;  
            lst.Clear();  
        }  
     
   
    #endregion



        protected void btnStaff_Click(object sender, EventArgs e)
        {

        }

       
        private void getPivotTable(DataTable dtNew,string xValue,string yValue)
        {
            //SELECT COUNT(JobOwner.jobOwnerID) AS jCnt, { fn MONTHNAME(JobOwner.staffIssueDate) } AS Month, Contact.firstName FROM  JobOwner INNER JOIN
            //             Contact ON JobOwner.contactID = Contact.contactID WHERE        (JobOwner.sectionID = 3) AND (YEAR(JobOwner.staffIssueDate) = 2016) GROUP BY JobOwner.contactID, { fn MONTHNAME(JobOwner.staffIssueDate) }, Contact.firstName
                        
            var dataTable = new DataTable();
            dataTable = dtNew;

            var pivotedDataTable = new DataTable(); //the pivoted result
            var firstColumnName = xValue;
            var pivotColumnName = yValue;

            pivotedDataTable.Columns.Add(firstColumnName);

            pivotedDataTable.Columns.AddRange(dataTable.Rows.Cast<DataRow>().Select(x => new DataColumn(x[pivotColumnName].ToString())).ToArray());

            for (var index = 1; index < dataTable.Columns.Count; index++)
            {
                pivotedDataTable.Rows.Add(new List<object> { dataTable.Columns[index].ColumnName }.Concat(dataTable.Rows.Cast<DataRow>().Select(x => x[dataTable.Columns[index].ColumnName])).ToArray());
            }

            GridView3.DataSource = dataTable;
            GridView3.DataBind();
        }      
        public static DataTable GetInversedDataTable(DataTable table, string columnX, string columnY, string columnZ, string nullValue, bool sumValues)
        {
            //Create a DataTable to Return
            DataTable returnTable = new DataTable();

            if (columnX == "")
                columnX = table.Columns[0].ColumnName;

            //Add a Column at the beginning of the table
            returnTable.Columns.Add(columnY);


            //Read all DISTINCT values from columnX Column in the provided DataTale
            List<string> columnXValues = new List<string>();

            foreach (DataRow dr in table.Rows)
            {

                string columnXTemp = dr[columnX].ToString();
                if (!columnXValues.Contains(columnXTemp))
                {
                    //Read each row value, if it's different from others provided, add to 
                    //the list of values and creates a new Column with its value.
                    columnXValues.Add(columnXTemp);
                    returnTable.Columns.Add(columnXTemp);
                }
            }

            //Verify if Y and Z Axis columns re provided
            if (columnY != "" && columnZ != "")
            {
                //Read DISTINCT Values for Y Axis Column
                List<string> columnYValues = new List<string>();

                foreach (DataRow dr in table.Rows)
                {
                    if (!columnYValues.Contains(dr[columnY].ToString()))
                        columnYValues.Add(dr[columnY].ToString());
                }

                //Loop all Column Y Distinct Value
                foreach (string columnYValue in columnYValues)
                {
                    //Creates a new Row
                    DataRow drReturn = returnTable.NewRow();
                    drReturn[0] = columnYValue;
                    //foreach column Y value, The rows are selected distincted
                    DataRow[] rows = table.Select(columnY + "='" + columnYValue + "'");

                    //Read each row to fill the DataTable
                    foreach (DataRow dr in rows)
                    {
                        string rowColumnTitle = dr[columnX].ToString();

                        //Read each column to fill the DataTable
                        foreach (DataColumn dc in returnTable.Columns)
                        {
                            if (dc.ColumnName == rowColumnTitle)
                            {
                                //If Sum of Values is True it try to perform a Sum
                                //If sum is not possible due to value types, the value 
                                // displayed is the last one read
                                if (sumValues)
                                {
                                    try
                                    {
                                        drReturn[rowColumnTitle] =
                                             Convert.ToDecimal(drReturn[rowColumnTitle]) +
                                             Convert.ToDecimal(dr[columnZ]);
                                    }
                                    catch
                                    {
                                        drReturn[rowColumnTitle] = dr[columnZ];
                                    }
                                }
                                else
                                {
                                    drReturn[rowColumnTitle] = dr[columnZ];
                                }
                            }
                        }
                    }
                    returnTable.Rows.Add(drReturn);
                }
            }
            else
            {
                throw new Exception("The columns to perform inversion are not provided");
            }

            //if a nullValue is provided, fill the datable with it
            if (nullValue != "")
            {
                foreach (DataRow dr in returnTable.Rows)
                {
                    foreach (DataColumn dc in returnTable.Columns)
                    {
                        if (dr[dc.ColumnName].ToString() == "")
                            dr[dc.ColumnName] = nullValue;
                    }
                }
            }

            return returnTable;
        }
        protected void btnPivot_Click(object sender, EventArgs e)
        {
            // Staff Wise data count
            getPivot_Staff();

        }
        protected void btnPivotTYpe_Click(object sender, EventArgs e)
        {
            getPivot_JobType();
        }
        protected void btnPivot3_Click(object sender, EventArgs e)
        {
            


            string x_Value = ddl_X.SelectedValue; string y_Value = ddl_Y.SelectedValue; string z_Value = ddl_Z.SelectedValue;

             DataTable dtNew = Session["MainGrid"] as DataTable;
             getPivotTable(dtNew, x_Value, y_Value);
        }


        private void getPivot_Staff()
        {
            //SELECT        CAST(jobReceivedDate AS DATE) AS Date, COUNT(1) AS [Sales Count] 

            string x_Value = string.Empty; string y_Value = string.Empty; string z_Value = string.Empty;
            x_Value = ddl_X.SelectedValue; y_Value = ddl_Y.SelectedValue; z_Value = ddl_Z.SelectedValue;

            string sqlQuery = string.Empty;
            if ((ddlMonth.SelectedValue != "") & (ddlYear.SelectedValue != ""))
            {
                 sqlQuery = "SELECT Contact.firstName, Job.jobReceivedDate, COUNT(*) AS count FROM Job INNER JOIN JobOwner ON Job.jobID = JobOwner.jobID INNER JOIN " +
                 " Contact ON JobOwner.contactID = Contact.contactID WHERE (YEAR(Job.jobReceivedDate) = " + ddlYear.SelectedValue + ") AND (MONTH(Job.jobReceivedDate) = " + ddlMonth.SelectedValue + ") AND (Job.sectionID = 1) " +
                 " GROUP BY Contact.firstName, Job.jobReceivedDate";
            }
            else
            {
                 sqlQuery = "SELECT Contact.firstName, Job.jobReceivedDate, COUNT(*) AS count FROM Job INNER JOIN JobOwner ON Job.jobID = JobOwner.jobID INNER JOIN " +
                 " Contact ON JobOwner.contactID = Contact.contactID WHERE (YEAR(Job.jobReceivedDate) = " + System.DateTime.Now.Year + ") AND (MONTH(Job.jobReceivedDate) = " + System.DateTime.Now.Month + ") AND (Job.sectionID = 1) " +
                 " GROUP BY Contact.firstName, Job.jobReceivedDate";      
            }            
          
            SqlConnection objCon = new SqlConnection(connValue);
            SqlCommand objCmd = new SqlCommand(sqlQuery, objCon);

            DataSet dsTndrStaff = new DataSet();
            objCmd.CommandText = sqlQuery;
            objCmd.Connection = objCon;


            SqlDataAdapter daTndrStaff = new SqlDataAdapter(objCmd);
            daTndrStaff.Fill(dsTndrStaff);

            DataTable dtNew = dsTndrStaff.Tables[0];

            // DataTable dtNew = Session["MainGrid"] as DataTable;

          

            //  DataTable dtReturn = GetInversedDataTable(dtNew, "firstName", "jobReceivedDate", "Count", "-", true);

            DataTable dtReturn = GetInversedDataTable(dtNew, x_Value, y_Value, "Count", "-", true);

            GridView3.DataSource = dtReturn;
            GridView3.DataBind();
        }



        private void getPivot_JobType()
        {
            string x_Value = string.Empty; string y_Value = string.Empty; string z_Value = string.Empty;
             x_Value = ddl_X.SelectedValue;  y_Value = ddl_Y.SelectedValue;  z_Value = ddl_Z.SelectedValue;

             string sqlQuery = string.Empty;

             string _year = string.Empty; string _section = string.Empty;

             if ((ddlYear.SelectedValue != ""))
             {
                 _year = ddlYear.SelectedValue;
             }
             else
                 _year = System.DateTime.Now.Year.ToString();


             if (ddlSection.SelectedValue != "")
             {
                 _section = ddlSection.SelectedValue;
             }
             else
                 _section = "1";

             if ((x_Value.Contains("Status") || (y_Value.Contains("Status"))))
             {
                 sqlQuery = "SELECT { fn MONTHNAME(Job.jobReceivedDate) } AS Month, JobStatus.jobStatusName, COUNT(*) AS count FROM   Job INNER JOIN  JobStatus ON Job.jobStatusID = JobStatus.jobStatusID " +
                    " WHERE (YEAR(Job.jobReceivedDate) = " + _year + ") AND (Job.sectionID = " + _section + ") GROUP BY { fn MONTHNAME(Job.jobReceivedDate) }, JobStatus.jobStatusName";


             }
             else if ((x_Value.Contains("Type") || (y_Value.Contains("Type"))))
             {
                 //sqlQuery = "SELECT Job.jobReceivedDate, JobType.jobTypeName, COUNT(*) AS count FROM    Job INNER JOIN   JobType ON Job.jobTypeID = JobType.jobTypeID " +
                 //"WHERE (YEAR(Job.jobReceivedDate) = 2018) AND (MONTH(Job.jobReceivedDate) = 9) AND (Job.sectionID = 1) GROUP BY Job.jobReceivedDate, JobType.jobTypeName";

                 sqlQuery = "SELECT { fn MONTHNAME(Job.jobReceivedDate) } AS Month, JobType.jobTypeName, COUNT(*) AS count FROM  Job INNER JOIN  JobType ON Job.jobTypeID = JobType.jobTypeID " +
                            "WHERE (YEAR(Job.jobReceivedDate) = " + _year + ") AND (Job.sectionID = " + _section + ") GROUP BY { fn MONTHNAME(Job.jobReceivedDate) }, JobType.jobTypeName ORDER BY Month";
             }
             else if ((x_Value.Contains("firstName") || (y_Value.Contains("firstName"))))
             {
                 sqlQuery = "SELECT Contact.firstName, { fn MONTHNAME(Job.jobReceivedDate) } AS Month, COUNT(*) AS count, MONTH(Job.jobReceivedDate) AS MonthID " +
                      " FROM Job INNER JOIN   JobOwner ON Job.jobID = JobOwner.jobID INNER JOIN  Contact ON JobOwner.contactID = Contact.contactID WHERE (YEAR(Job.jobReceivedDate) = " + _year + ") AND (Job.sectionID = " + _section + ") " + 
                    " GROUP BY Contact.firstName, { fn MONTHNAME(Job.jobReceivedDate) }, MONTH(Job.jobReceivedDate) ORDER BY MonthID";

                 //sqlQuery = "SELECT Contact.firstName, { fn MONTHNAME(Job.jobReceivedDate) } AS Month, COUNT(*) AS count FROM Job INNER JOIN JobOwner ON Job.jobID = JobOwner.jobID INNER JOIN " +
                 // " Contact ON JobOwner.contactID = Contact.contactID WHERE (YEAR(Job.jobReceivedDate) = " + _year + ") AND (Job.sectionID = 1) " +
                 // " GROUP BY Contact.firstName, { fn MONTHNAME(Job.jobReceivedDate) } ";

                  //sqlQuery = "SELECT Contact.firstName, Job.jobReceivedDate, COUNT(*) AS count FROM Job INNER JOIN JobOwner ON Job.jobID = JobOwner.jobID INNER JOIN " +
                  //" Contact ON JobOwner.contactID = Contact.contactID WHERE (YEAR(Job.jobReceivedDate) = 2018) AND (MONTH(Job.jobReceivedDate) = 9) AND (Job.sectionID = 1) " +
                  //" GROUP BY Contact.firstName, Job.jobReceivedDate";
             }


            SqlConnection objCon = new SqlConnection(connValue);
            SqlCommand objCmd = new SqlCommand(sqlQuery, objCon);

            DataSet dsTndrStaff = new DataSet();
            objCmd.CommandText = sqlQuery;
            objCmd.Connection = objCon;


            SqlDataAdapter daTndrStaff = new SqlDataAdapter(objCmd);
            daTndrStaff.Fill(dsTndrStaff);

            DataTable dtNew = dsTndrStaff.Tables[0];

            // DataTable dtNew = Session["MainGrid"] as DataTable;           

           // DataTable dtReturn = GetInversedDataTable(dtNew, "Month", "jobTypeName", "Count", "-", true);

            if (x_Value.Equals("jobReceivedDate"))
            {
                x_Value = "Month";
            }
            if (y_Value.Equals("jobReceivedDate"))
            {
                y_Value = "Month";
            }


            DataTable dtReturn = GetInversedDataTable(dtNew, x_Value, y_Value, "Count", "-", true);

            GridView3.DataSource = dtReturn;
            GridView3.DataBind();
        }



        private void getYearAndmonthWiseJobCount()
        {
            string _section = string.Empty;
            if (ddlSection.SelectedValue != "")
            {
                _section = ddlSection.SelectedValue;
            }
            else
                _section = "1";


            DynamicData dynmicCls = new DynamicData();

            GridView3.DataSource = dynmicCls.getYearAndmonthWiseJobCount(_section);
            GridView3.DataBind();

        }








  
        protected void btnPivotYearly_Click(object sender, EventArgs e)
        {
            getYearAndmonthWiseJobCount();
        }

        private void getQuaterlyData()
        {
            string _section = string.Empty;
            if (ddlSection.SelectedValue != "")
            {
                _section = ddlSection.SelectedValue;
            }
            else
                _section = "1";

            DynamicData dynmicCls = new DynamicData();

            GridView3.DataSource = dynmicCls.getQuaterlyData("", "", _section);
            GridView3.DataBind();

        }
        protected void btnQuaterly_Click(object sender, EventArgs e)
        {
            getQuaterlyData();
        }
        protected void btnHourly_Click(object sender, EventArgs e)
        {
            getHourrlyData();
        }
        private void getHourrlyData()
        {
            string _section = string.Empty;
            if (ddlSection.SelectedValue != "")            
                _section = ddlSection.SelectedValue;            
            else
                _section = "1";

            string _year = string.Empty; string _Month = string.Empty;

            if ((ddlYear.SelectedValue != ""))        
                _year = ddlYear.SelectedValue;           
            else
                _year = System.DateTime.Now.Year.ToString();

            if ((ddlMonth.SelectedValue != ""))     
                _Month = ddlMonth.SelectedValue;         
            else
                _Month = System.DateTime.Now.Month.ToString();

            

            GridView3.DataSource = dynmicCls.getHourrlyData(_year, _Month, _section);
            GridView3.DataBind();
        }














        #region MyRegion

        private void ExportToExcel_Sree()
        {
            Response.Clear();
            Response.Buffer = true;
            Response.AddHeader("content-disposition", "attachment;filename=GridViewExport.xls");
            Response.Charset = "";
            Response.ContentType = "application/vnd.ms-excel";
            using (StringWriter sw = new StringWriter())
            {
                HtmlTextWriter hw = new HtmlTextWriter(sw);

                //To Export all pages
                grvMain.AllowPaging = false;

                grvMain.DataSource = Session["MainGrid"];
                grvMain.DataBind();

                grvMain.HeaderRow.BackColor = Color.White;
                foreach (TableCell cell in grvMain.HeaderRow.Cells)
                {
                    cell.BackColor = grvMain.HeaderStyle.BackColor;
                }
                foreach (GridViewRow row in grvMain.Rows)
                {
                    row.BackColor = Color.White;
                    foreach (TableCell cell in row.Cells)
                    {
                        if (row.RowIndex % 2 == 0)
                        {
                            cell.BackColor = grvMain.AlternatingRowStyle.BackColor;
                        }
                        else
                        {
                            cell.BackColor = grvMain.RowStyle.BackColor;
                        }
                        cell.CssClass = "textmode";
                    }
                }

                grvMain.RenderControl(hw);

                //style to format numbers to string
                string style = @"<style> .textmode { } </style>";
                Response.Write(style);
                Response.Output.Write(sw.ToString());
                Response.Flush();
                Response.End();
            }
        }
        public override void VerifyRenderingInServerForm(Control control)
        {
            /* Verifies that the control is rendered */
        }

        #endregion







}
