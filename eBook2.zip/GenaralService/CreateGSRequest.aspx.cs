﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;


using System.Data.SqlClient;
using System.Data;
using System.Configuration;
using PropertyLayer;
using Datalayer;
using System.Globalization;
using System.Text;
using System.IO;

public partial class GenaralService_CreateGSRequest : System.Web.UI.Page
{
    string connValue = System.Configuration.ConfigurationManager.ConnectionStrings["EBSDEBookConn"].ConnectionString;
    private SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["EBSDEBookConn"].ConnectionString);
    string _userProfile = string.Empty;
    string _userDisplayName = string.Empty;
    int _jobID = 0;

    //static int jobdocID = 0;
    int jobdocID = 0;
    int teamleadID = 0;
    JobOrderProperty x = new JobOrderProperty();


    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["UserName"] == null)
        {
            Response.Redirect("~/LoginPage.aspx", false);
            return;
        }

        _jobID = Convert.ToInt32(Request.QueryString["JobID"]);

        teamleadID = Convert.ToInt32(Session["teamLeaderID"]);

        if (!IsPostBack)
        {
            FillDropBox();

            txtRecDate.Text = System.DateTime.Now.ToString();

            CreateJobNO();

            ddlReqBy.SelectedValue = "5"; // EBD Manager
            // trCntr.Visible = false;

            ddlCoordinator.SelectedIndex = 1; 

            ddlReqBy.SelectedIndex = 1;   // Head

            trOthers.Visible = false;
            trCntrNO.Visible = false;
            trJobNO.Visible = false;
            trCoord.Visible = false;

           
        }
    }
    private void InsertNewJobOrder123() 
    {
        string docRecDate = string.Empty; IList<string> userInfoColl = new List<string>();

        _jobID = PassJobOrderData(0);

        Session["Mngr_JobID"] = _jobID;

       // new JobOrderData().SendEmailAlert(new JobOrderData().getEmail(ddlActionBy.SelectedValue), _jobID.ToString(), txtCntrNO.Text, "A new Service Request was created and the details are as follows");

        Response.Redirect("~/GenaralService/GSDetails.aspx", false);

        ////Response.Redirect("~/JobOrder/DefaultWindow.aspx?JobID = " + _jobID + "", false);

        ////Response.Redirect("~/ManagerTask/MngrTaskDetails.aspx?JobID = " + _jobID + "", false);    
    }
    public int PassJobOrderData(int _docID)
    {
        _addJob.jobNo = txtJobNo.Text;

        if (ddlTaskType.SelectedIndex != 0)
        {
            _addJob.jobTypeID = Convert.ToInt32(ddlTaskType.SelectedValue);
            _addJob.jobCatID = 46;
        }
        else
        {
            _addJob.jobCatID = 46;
            _addJob.jobTypeID = 46;
        }


        _addJob.jobStatusID = 3;  //jobOrder        

        if (ddlDept.SelectedIndex == 0)
        {
            _addJob.deptID = 22;     // EBD
            _addJob.affID = 5;          // Technical
        }
        else
        {
            _addJob.deptID = Convert.ToInt32(ddlDept.SelectedValue);
            _addJob.affID = 5;
        }

        _addJob.contractorID = 1;
        _addJob.prjCode = "";


        if (txtCntrNO.Text == "")
            _addJob.commitmentNo = "";
        else
            _addJob.commitmentNo = txtCntrNO.Text;

        _addJob.tenderNo = "";

        _addJob.prjTitle = txtDescription.Text;
        _addJob.jobDesc = txtDescription.Text;

        _addJob.qsID = 0; _addJob.ceID = 0; _addJob.peID = 0;
        _addJob.addendumNO = 0;

        _addJob.contractTypeID = 0; // Supervision      

        _addJob.docRefID = 1;

        _addJob.gradeID = 3;

        _addJob.qsID = 0;
        _addJob.peID = 0;
        _addJob.ceID = 0;

        if (ddlActionBy.SelectedIndex != 0)
            _addJob.dcID = Convert.ToInt32(ddlActionBy.SelectedValue);

        _addJob.actionDueDate = Convert.ToDateTime(txtDueDate123.Text).ToString("dd/MMM/yyyy");
        _addJob.daysToAct = 1;
        _addJob.jobCreatedByID = Convert.ToInt32(Session["UserID"]);

        _addJob.SectionID = 22;       //Convert.ToInt32(Session["SectionID"].ToString());
        _addJob.JobReceivedDate = Convert.ToDateTime(txtRecDate.Text).ToString("dd/MMM/yyyy");
        _addJob.staffRoleID = 1;
        _addJob.jobPurposeID = 1;

        _addJob.inchargeActionDueDate = Convert.ToDateTime(txtDueDate123.Text).ToString();
        _addJob.inchargeWorkDays = 1;

        _jobID = InsertJobOrder_Mngr(_addJob, Session["UserName"].ToString(), _docID); // GS_CreateRequest

        return _jobID;
    }

    static DataTable dtDocument = new DataTable();

    private int getCompanyID(int contactID)
    {
        int CmpID = 0;
        SqlConnection sqlConn = new SqlConnection(connValue);
        string sqlQuery = "SELECT companyID From Contact where contactID = " + contactID + "";

        try
        {
            sqlConn.Open();
            SqlCommand sqlCom = new SqlCommand(sqlQuery, sqlConn);
            SqlDataReader sqlReader = sqlCom.ExecuteReader();
            while (sqlReader.Read())
            {
                CmpID = Convert.ToInt32(sqlReader["companyID"]);
            }
            sqlReader.Close();
        }
        catch (Exception ex)
        {
            // Response.Write("Error getting while reading data !" + ex.Message);
        }
        finally
        {
            sqlConn.Close();
        }
        return CmpID;
    }



    # region


    private void FillDropBox()
    {
        PopulateDropDownBox(ddlTaskType, "SELECT  jobTypeID, jobTypeName, CategoryID, sectionID FROM   JobType WHERE  (sectionID = 22)", "jobTypeID", "jobTypeName");   // AND (jobTypeID <> CategoryID)

        PopulateDropDownBox(ddlTaskSubType, "SELECT  subTypeID, subTypeName, typeID FROM  SubTaskType  Where typeID = 67 ", "subTypeID", "subTypeName");

        PopulateDropDownBox(ddlReqBy, "SELECT contactID, (firstName + ' ' + LastName) as UserName FROM Contact Where isAuthRepres =1 and sectionID = 22 Order By UserName", "contactID", "UserName");

        PopulateDropDownBox(ddlReqVia, "SELECT ReqID, ReqVia FROM RequestService", "ReqID", "ReqVia");

        // PopulateDropDownBox(ddlCoordinator, "SELECT prjCoordID, coordName FROM ProjCoordinator where SectionID = 10 ORDER BY coordName", "prjCoordID", "coordName");

        PopulateDropDownBox(ddlCoordinator, "SELECT contactID, (firstName + ' ' + lastname) as UserName FROM Contact where isCoordinator = 1 and sectionID = 22", "contactID", "UserName");

        PopulateDropDownBox(ddlActionBy, "SELECT contactID, (firstName + ' ' + lastname) as UserName FROM Contact where sectionID = 22  Order By UserName", "contactID", "UserName");       // Where isAuthRepres =1

        PopulateDropDownBox(ddlDept, "SELECT departmentID, deptName FROM  Department where affairID is not null ORDER BY deptName ", "departmentID", "deptName");
    }
    public static void FillCombo(DropDownList dropDownList, string dataValueField, string dataTextField, DataTable dataTbl, bool bHasBlank)
    {
        dropDownList.DataTextField = dataTextField;
        dropDownList.DataValueField = dataValueField;
        dropDownList.DataSource = dataTbl;
        dropDownList.DataBind();

        ListItem emptyItem = new ListItem("", "");
        dropDownList.Items.Insert(0, emptyItem);

        //if (bHasBlank)
        //    dropDownList.Items.Insert(0, new ListItem());
    }

    public static DataTable ExecuteQuery(string SQLstring)
    {
        string sConstr = ConfigurationManager.ConnectionStrings["EBSDEBookConn"].ConnectionString;
        SqlConnection Conn = new SqlConnection(sConstr);
        DataTable dt = new DataTable("tbl");

        using (Conn)
        {
            Conn.Open();
            SqlCommand comm = new SqlCommand(SQLstring, Conn);
            comm.CommandTimeout = 0;
            SqlDataAdapter da = new SqlDataAdapter(comm);
            da.Fill(dt);
        }
        return dt;
    }
    private void PopulateDropDownBox(DropDownList ddlBox, string sqlQuery, string valueMember, string displayName)
    {
        ddlBox.DataBound += new EventHandler(this.ddlBox_DataBound);
        ddlBox.DataSource = new JobOrderData().FillDropdown(sqlQuery);
        ddlBox.DataTextField = displayName;
        ddlBox.DataValueField = valueMember;
        ddlBox.SelectedIndex = -1;
        ddlBox.DataBind();
    }
    protected void ddlBox_DataBound(object sender, EventArgs e)
    {
        DropDownList ddl = (DropDownList)sender;
        ListItem emptyItem = new ListItem("", "");
        ddl.Items.Insert(0, emptyItem);
    }
    private void PopulateDropDownBox_TCMS(DropDownList ddlBox, string sqlQuery, string valueMember, string displayName)
    {
        ddlBox.DataBound += new EventHandler(this.ddlBox_DataBound);
        ddlBox.DataSource = new JobOrderData().FillDropdown_TCMS(sqlQuery);
        ddlBox.DataTextField = displayName;
        ddlBox.DataValueField = valueMember;
        ddlBox.SelectedIndex = -1;
        ddlBox.DataBind();
    }
    protected void btnSave_Click(object sender, EventArgs e)
    {
        //FillDropdown(); 
        InsertNewJobOrder123();

        string script = "this.window.opener.location=this.window.opener.location;this.window.close();";
        if (!ClientScript.IsClientScriptBlockRegistered("REFRESH_PARENT"))
            ClientScript.RegisterClientScriptBlock(typeof(string), "REFRESH_PARENT", script, true);

    }
    JobOrderProperty _addJob = new JobOrderProperty();

    public DataTable GetDataFromDB(string dataTabName, string sqlQuery)
    {
        DataTable table = null;
        SqlConnection sqlConn = new SqlConnection(connValue);
        sqlConn.Open();
        SqlDataAdapter sqlDtAdptr = null;
        table = new DataTable(dataTabName);
        sqlDtAdptr = new SqlDataAdapter(@sqlQuery, sqlConn);
        sqlDtAdptr.Fill(table);
        sqlConn.Close();
        return table;
    }


    public int InsertJobOrder_Mngr(JobOrderProperty _insrttData, string userName, int _outDocID)
    {
        List<string> projData = Session["sessprjColl"] as List<string>;

        SqlConnection con = new SqlConnection(connValue);
        SqlCommand cmd = new SqlCommand();
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Connection = con;
        cmd.CommandText = "GS_CreateRequest";   // SP

        //cmd.Parameters.AddWithValue("@jobID", _insrttData.jobID);

        // cmd.Parameters.AddWithValue("@jobID", SqlDbType.SmallInt).Direction = ParameterDirection.Output;           

        // cmd.Parameters.AddWithValue("@JobNo", SqlDbType.NVarChar).Direction = ParameterDirection.Output;

        cmd.Parameters.AddWithValue("@JobNo", txtJobNo.Text);

        // we have to Change below code
        if (_insrttData.jobTypeID != 0)
        {
            cmd.Parameters.AddWithValue("@jobTypeID", _insrttData.jobTypeID);
            cmd.Parameters.AddWithValue("@jobCatID", _insrttData.jobCatID);
        }
        else
        {
            cmd.Parameters.AddWithValue("@jobCatID", _insrttData.jobCatID);
            cmd.Parameters.AddWithValue("@jobTypeID", _insrttData.jobCatID);
        }

        if (_insrttData.affID != 0)
            cmd.Parameters.AddWithValue("@affairID", _insrttData.affID);
        else
            cmd.Parameters.AddWithValue("@affairID", System.DBNull.Value);

        if (_insrttData.deptID != 0)
            cmd.Parameters.AddWithValue("@deptID", _insrttData.deptID);
        else
            cmd.Parameters.AddWithValue("@deptID", System.DBNull.Value);

        if (_insrttData.commitmentNo != "" & _insrttData.commitmentNo != null)
            cmd.Parameters.AddWithValue("@contractNo", _insrttData.commitmentNo);
        else if (_insrttData.prjCode != "" & _insrttData.prjCode != null)
            cmd.Parameters.AddWithValue("@contractNo", _insrttData.prjCode);
        else if (_insrttData.tenderNo != "" & _insrttData.tenderNo != null)
            cmd.Parameters.AddWithValue("@contractNo", _insrttData.tenderNo);
        else
            cmd.Parameters.AddWithValue("@contractNo", System.DBNull.Value);

        cmd.Parameters.AddWithValue("@projectTitle", _insrttData.prjTitle);
        cmd.Parameters.AddWithValue("@jobDesc", _insrttData.jobDesc);


        if (_insrttData.contractorID != 0)
            cmd.Parameters.AddWithValue("@contractorID", _insrttData.contractorID);
        else
            cmd.Parameters.AddWithValue("@contractorID", System.DBNull.Value);

        cmd.Parameters.AddWithValue("@jobStatusID", 3); // on-going 

        if (_insrttData.docRefID != 0)
            cmd.Parameters.AddWithValue("@docRefID", _insrttData.docRefID);
        else
            cmd.Parameters.AddWithValue("@docRefID", System.DBNull.Value);

        if (_insrttData.addendumNO != 0)
            cmd.Parameters.AddWithValue("@addendumNO", _insrttData.addendumNO);
        else
            cmd.Parameters.AddWithValue("@addendumNO", System.DBNull.Value);

        cmd.Parameters.AddWithValue("@contractTypeID", System.DBNull.Value);    //any

        if (_insrttData.gradeID != 0)
            cmd.Parameters.AddWithValue("@gradeID", _insrttData.gradeID);
        else
            cmd.Parameters.AddWithValue("@gradeID", System.DBNull.Value);

        if (_insrttData.qsID != 0)
            cmd.Parameters.AddWithValue("@qsID", _insrttData.qsID);
        else
            cmd.Parameters.AddWithValue("@qsID", System.DBNull.Value);

        if (_insrttData.peID != 0)
            cmd.Parameters.AddWithValue("@peID", _insrttData.peID);
        else
            cmd.Parameters.AddWithValue("@peID", System.DBNull.Value);

        if (_insrttData.ceID != 0)
            cmd.Parameters.AddWithValue("@ceID", _insrttData.ceID);
        else
            cmd.Parameters.AddWithValue("@ceID", System.DBNull.Value);

        if (_insrttData.dcID != 0)
            cmd.Parameters.AddWithValue("@dcID", _insrttData.dcID);
        else
            cmd.Parameters.AddWithValue("@dcID", System.DBNull.Value);

        cmd.Parameters.AddWithValue("@actionDueDate", Convert.ToDateTime(_insrttData.actionDueDate).ToString("dd/MMM/yyyy"));
        cmd.Parameters.AddWithValue("@workDays", _insrttData.daysToAct);

        cmd.Parameters.AddWithValue("@JobDueDate", Convert.ToDateTime(_insrttData.actionDueDate).ToString("dd/MMM/yyyy"));
        cmd.Parameters.AddWithValue("@jobCreatedByID", _insrttData.jobCreatedByID);

        cmd.Parameters.AddWithValue("@SectionID", _insrttData.SectionID);

        cmd.Parameters.AddWithValue("@JobReceivedDate", Convert.ToDateTime(_insrttData.JobReceivedDate).ToString("dd/MMM/yyyy"));

        cmd.Parameters.AddWithValue("@createDate", System.DateTime.Now.ToString("dd/MMM/yyyy"));
        cmd.Parameters.AddWithValue("@createUser", userName);

        cmd.Parameters.AddWithValue("@StaffRoleID", _insrttData.staffRoleID); // pass value need

        //  cmd.Parameters.AddWithValue("@docID", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

        cmd.Parameters.AddWithValue("@docID", _outDocID);

        cmd.Parameters.AddWithValue("@jobPurposeID", _insrttData.jobPurposeID);


        cmd.Parameters.AddWithValue("@inchargeDueDate", Convert.ToDateTime(_insrttData.inchargeActionDueDate).ToString("dd/MMM/yyyy"));
        cmd.Parameters.AddWithValue("@daysToAct", _insrttData.inchargeWorkDays);


        cmd.Parameters.AddWithValue("@jobOwnerStatusID", 3);
        cmd.Parameters.AddWithValue("@docCreatedByID", System.DBNull.Value);

        cmd.Parameters.AddWithValue("@originID", ddlActionBy.SelectedValue);

        cmd.Parameters.AddWithValue("@jobOwnerID", System.DBNull.Value);

        cmd.Parameters.AddWithValue("@docReceivedDate", System.DBNull.Value);

        cmd.Parameters.AddWithValue("@docDate", System.DBNull.Value);

        if (projData != null)
            cmd.Parameters.AddWithValue("@ministryCode", projData[1].ToString());
        else
            cmd.Parameters.AddWithValue("@ministryCode", System.DBNull.Value);

        if (projData != null)
            cmd.Parameters.AddWithValue("@budgetRefNo", projData[2].ToString());
        else
            cmd.Parameters.AddWithValue("@budgetRefNo", System.DBNull.Value);

        if (projData != null)
            cmd.Parameters.AddWithValue("@provisionNo", projData[3].ToString());
        else
            cmd.Parameters.AddWithValue("@provisionNo", System.DBNull.Value);


        cmd.Parameters.AddWithValue("@JobID", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

        // For DCLog

        cmd.Parameters.AddWithValue("@projStstusID", System.DBNull.Value);

        if (_insrttData.commitmentNo != null)
            cmd.Parameters.AddWithValue("@committmentNo", _insrttData.commitmentNo);
        else
            cmd.Parameters.AddWithValue("@committmentNo", System.DBNull.Value);

        if (_insrttData.prjCode != null)
            cmd.Parameters.AddWithValue("@projectCode", _insrttData.prjCode);
        else
            cmd.Parameters.AddWithValue("@projectCode", System.DBNull.Value);

        cmd.Parameters.AddWithValue("@reqViaID", ddlReqVia.SelectedValue);

        cmd.Parameters.AddWithValue("@requesterName", ddlReqBy.SelectedValue);

        if (ddlCoordinator.SelectedIndex != 0)
            cmd.Parameters.AddWithValue("@CoordinatorID", ddlCoordinator.SelectedValue);
        else
            cmd.Parameters.AddWithValue("@CoordinatorID", System.DBNull.Value);

        cmd.Parameters.AddWithValue("@requestedBy", ddlReqBy.SelectedValue);

        if (ddlTaskSubType.SelectedIndex != 0)
            cmd.Parameters.AddWithValue("@taskSubTypeID", ddlTaskSubType.SelectedValue);
        else
            cmd.Parameters.AddWithValue("@taskSubTypeID", System.DBNull.Value);

        if (txtOthers.Text == "")
            cmd.Parameters.AddWithValue("@externalDept", System.DBNull.Value);
        else
            cmd.Parameters.AddWithValue("@externalDept", txtOthers.Text);


        try
        {
            con.Open();
            cmd.ExecuteNonQuery();
            con.Dispose();
        }
        catch (Exception ex)
        {

            throw ex;
        }
        finally
        {
            con.Close();
        }

        return (int)cmd.Parameters["@JobID"].Value;

        // return _insrttData.jobID;
    }
    public void PassJobInchargeData(int maxJobID, int docCreatedID, ref int _InchargeID, string docRecDate)
    {
        _addJob.contactID = Convert.ToInt32(Session["userID"]);
        _addJob.docCreatedByID = docCreatedID;

        _addJob.daysToAct = 1;
        _addJob.completionDate = "";


        _addJob.actionDueDate = Convert.ToDateTime(txtDueDate123.Text).ToString("dd/MMM/yyyy");

        _addJob.staffIssueDate = Convert.ToDateTime(docRecDate).ToString("dd/MMM/yyyy");

        _addJob.userDisplayName = _userDisplayName;

        _addJob.jobID = maxJobID;

        _addJob.jobNo = txtJobNo.Text;

        _addJob.jobTypeID = 1;

        _addJob.jobCatID = 1;

        _addJob.jobStatusID = 3;

        _addJob.deptID = 1;

        _addJob.affID = 1;

        _addJob.consultID = 1;

        _addJob.contractorID = 1;

        _addJob.prjCode = "";

        _addJob.prjTitle = txtDescription.Text;

        _addJob.qsID = 0; _addJob.ceID = 0; _addJob.peID = 0;

        _addJob.letterDate = ""; _addJob.createDate = ""; _addJob.ebsdDateReceived = "";

        _addJob.letterRefNo = "";

        _addJob.contractTypeID = 2;

        _addJob.docRefID = 1;

        _addJob.jobSubject = "";

        _addJob.staffRoleID = Convert.ToInt32(1);

        _addJob.jobPurposeID = Convert.ToInt32(1);

        _addJob.SectionID = Convert.ToInt32(Session["SectionID"]);

        Insert_JobOwner(_addJob, ref _InchargeID);
    }
    public void Insert_JobOwner(JobOrderProperty _insertIncharge, ref int _ownerID)
    {
        SqlConnection con = new SqlConnection(connValue);
        SqlCommand cmd = new SqlCommand();
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Connection = con;
        cmd.CommandText = "[Insert_JobOwner]";
        cmd.Parameters.AddWithValue("@jobID", _insertIncharge.jobID);

        cmd.Parameters.AddWithValue("@contactID", _insertIncharge.contactID);

        cmd.Parameters.AddWithValue("@payID", System.DBNull.Value);

        cmd.Parameters.AddWithValue("@changeID", System.DBNull.Value);

        cmd.Parameters.AddWithValue("@momID", System.DBNull.Value);

        cmd.Parameters.AddWithValue("@docID", _insertIncharge.docRefID);

        cmd.Parameters.AddWithValue("@projectCode", _insertIncharge.prjCode);

        cmd.Parameters.AddWithValue("@projectTitle", _insertIncharge.prjTitle);

        cmd.Parameters.AddWithValue("@jobNo", _insertIncharge.jobNo);

        cmd.Parameters.AddWithValue("@jobOwnerCatID", _insertIncharge.jobCatID);

        cmd.Parameters.AddWithValue("@distributedBy", _insertIncharge.docCreatedByID);

        cmd.Parameters.AddWithValue("@actionDueDate", _insertIncharge.actionDueDate);
        cmd.Parameters.AddWithValue("@daysToAct", _insertIncharge.daysToAct);
        cmd.Parameters.AddWithValue("@completionDate", System.DBNull.Value);          //_insertIncharge.completionDate

        cmd.Parameters.AddWithValue("@jobDone", 0);
        cmd.Parameters.AddWithValue("@docRead", 0);

        cmd.Parameters.AddWithValue("@dateRead", System.DBNull.Value);
        cmd.Parameters.AddWithValue("@createUser", _insertIncharge.userDisplayName);
        cmd.Parameters.AddWithValue("@createDate", System.DateTime.Now.ToString("dd/MMM/yyyy"));
        cmd.Parameters.AddWithValue("@updateUser", System.DBNull.Value);
        cmd.Parameters.AddWithValue("@updateDate", System.DBNull.Value);
        cmd.Parameters.AddWithValue("@jobOwnerStatusID", 3);
        cmd.Parameters.AddWithValue("@StaffRoleID", _insertIncharge.staffRoleID); // pass value need
        cmd.Parameters.AddWithValue("@jobPurposeID", _insertIncharge.jobPurposeID);
        cmd.Parameters.AddWithValue("@sectionID", _insertIncharge.SectionID);
        cmd.Parameters.AddWithValue("@staffIssueDate", _insertIncharge.staffIssueDate);
        cmd.Parameters.AddWithValue("@jobOwnerID", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

        try
        {
            con.Open();
            cmd.ExecuteNonQuery();
            con.Dispose();
            _ownerID = (int)cmd.Parameters["@jobOwnerID"].Value;
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            con.Close();
        }
    }

    protected void ddlJobCat_SelectedIndexChanged(object sender, EventArgs e)
    {
        //if (ddlJobCat.SelectedIndex == -1)
        //    disableJobControls();
        //getJobNo();
    }

    private void CreateJobNO()
    {
        string strYear = System.DateTime.Now.Year.ToString().Substring(2, 2);

        string jobTypeSHname = "GS";
        string autoJobNO = string.Empty;

        autoJobNO = GenarateAutomate_JobNo(jobTypeSHname);
        autoJobNO = jobTypeSHname + strYear + autoJobNO;
        txtJobNo.Text = autoJobNO;

    }
    private string GenarateAutomate_JobNo(string jobType)
    {
        string _jobNo = string.Empty;
        int _maxjobNo = 0;
        string tempJobNo = string.Empty;

        _jobNo = new JobOrderData().getMaxJobNoSeries(jobType);

        if (_jobNo != "")
        {
            tempJobNo = _jobNo.Substring(_jobNo.Length - 4, 4);
            _maxjobNo = Convert.ToInt32(tempJobNo) + 1;

            // _maxjobNo = Convert.ToInt32(_jobNo) + 1;

            if (_maxjobNo.ToString().Length == 1)
                tempJobNo = "000" + _maxjobNo;

            if (_maxjobNo.ToString().Length == 2)
                tempJobNo = "00" + _maxjobNo;

            if (_maxjobNo.ToString().Length == 3)
                tempJobNo = "0" + _maxjobNo;

            if (_maxjobNo.ToString().Length == 4)
                tempJobNo = _maxjobNo.ToString();

            _jobNo = tempJobNo;
        }
        else
        {
            _jobNo = "0001";
        }

        return _jobNo;
    }



    private string getDocReceivedDate(int docID)
    {
        string docRecDate = string.Empty;
        SqlConnection sqlConn = new SqlConnection(connValue);
        string sqlQuery = "SELECT docReceivedDate from Document where documentID =" + docID + "";

        try
        {
            sqlConn.Open();
            SqlCommand sqlCom = new SqlCommand(sqlQuery, sqlConn);
            SqlDataReader sqlReader = sqlCom.ExecuteReader();
            while (sqlReader.Read())
            {
                docRecDate = sqlReader[0].ToString();
            }
            sqlReader.Close();
        }
        catch (Exception ex)
        {
            // Response.Write("Error getting while reading data !" + ex.Message);
        }
        finally
        {
            sqlConn.Close();
        }
        return docRecDate;
    }
    protected void lnkDocuments_Click(object sender, EventArgs e)
    {
        string str = Request.Url.AbsoluteUri;
        Session["UrlRef"] = str;
        Session["JobID"] = null;
        Session["DocID"] = null;
        Session["DocCategoryID"] = "1";
        Response.Redirect("~/Documents/DocumentDetailsWindow.aspx", false);
    }




    protected void txtDueDate123_TextChanged(object sender, EventArgs e)
    {



    }


    static DateTime _inchareDueDate = System.DateTime.Now;
    protected void ddlJobPurpose_SelectedIndexChanged(object sender, EventArgs e)
    {

        string docDate = Convert.ToDateTime(txtRecDate.Text).ToString("dd/MM/yyyy", CultureInfo.InvariantCulture);
        _inchareDueDate = ConvertToDateTime(docDate);
        _inchareDueDate = _inchareDueDate.AddDays(1);

    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        string strUpdate = "Update TempJobNo Set sessionUser =@sessionUser, confirmed =0 WHERE  (sessionUser = '" + Session["UserName"].ToString() + "') ";

        SqlConnection cn = new SqlConnection(connValue);
        SqlCommand sqlCmd = new SqlCommand();
        sqlCmd.CommandType = CommandType.Text;
        sqlCmd.CommandText = strUpdate;
        sqlCmd.Connection = cn;

        sqlCmd.Parameters.AddWithValue("@sessionUser", System.DBNull.Value);

        try
        {
            cn.Open();
            sqlCmd.ExecuteNonQuery();
        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
        finally
        {
            cn.Close();
        }

        Response.Redirect("~/JobOrder/DefaultWindow.aspx", false);
    }

    # endregion




    protected void ddlJobType_SelectedIndexChanged(object sender, EventArgs e)
    {


        #region MyRegion


        genarateJobNo(1, 11, 11);          // 1- for Cost Section

        #endregion


       


    }


    #region GenarateJobNO


    private void genarateJobNo(int sectionID, int seriesID, int CategID)
    {
        // lblmsg.Text = "";       

        string userSessionJobNo = string.Empty;


        string strYear = System.DateTime.Now.Year.ToString().Substring(2, 2);

        string jobShortName = getJobTypeShortName(CategID);      // for payment seriesID = 2


        string tempAutojobNo = GenarateAutomate_JobNo(seriesID);

        txtJobNo.Text = jobShortName + strYear + tempAutojobNo;

        string strTempJobNo = strYear + tempAutojobNo;

        new JobOrderData().InsertTemJobNo(strTempJobNo, Session["UserName"].ToString(), sectionID, seriesID, CategID);


    }


    string strYear = string.Empty;
    private string GenarateAutomate_JobNo(int seriesID)
    {
        strYear = System.DateTime.Now.Year.ToString().Substring(2, 2);
        string _jobNo = string.Empty;
        int _maxjobNo = 0;
        string tempJobNo = string.Empty;

        //   _jobNo = new JobOrderData().getMaxJobNoSeriesOfPayment();

        // _jobNo =  new JobOrderData().getMaxPayJobNo("PR" + strYear + "%");

        _jobNo = new JobOrderData().getMaxJobOrderJobNo(strYear + "%", seriesID);

        if (_jobNo != "")
        {
            tempJobNo = _jobNo.Substring(_jobNo.Length - 4, 4);
            _maxjobNo = Convert.ToInt32(tempJobNo) + 1;

            // _maxjobNo = Convert.ToInt32(_jobNo) + 1;

            if (_maxjobNo.ToString().Length == 1)
                tempJobNo = "000" + _maxjobNo;

            if (_maxjobNo.ToString().Length == 2)
                tempJobNo = "00" + _maxjobNo;

            if (_maxjobNo.ToString().Length == 3)
                tempJobNo = "0" + _maxjobNo;

            if (_maxjobNo.ToString().Length == 4)
                tempJobNo = _maxjobNo.ToString();

            _jobNo = tempJobNo;
        }
        else
        {
            _jobNo = "0001";
        }

        return _jobNo;
    }


    private string getJobTypeShortName(int seriesID)
    {
        string jobType = string.Empty;
        using (SqlConnection con = new SqlConnection(connValue))
        {
            con.Open();
            using (SqlCommand sqlCom = new SqlCommand())
            {
                // sqlCom.CommandType = CommandType.StoredProcedure;
                sqlCom.CommandType = CommandType.Text;
                sqlCom.Connection = con;
                sqlCom.CommandText = "SELECT jobTypeShortName FROM JobType WHERE seriesTypeID = " + seriesID;

                using (SqlDataReader sqlReader = sqlCom.ExecuteReader())
                {
                    while (sqlReader.Read())
                    {
                        jobType = sqlReader["jobTypeShortName"].ToString();
                    }
                }
            }
        }
        return jobType;
    }


    #endregion



    #region GetDatesFunctions

    private string getDaysByGivenEndDate(string strDate, DateTime endDate)
    {
        strDate = Convert.ToDateTime(strDate).ToString("MM/dd/yyyy", CultureInfo.InvariantCulture);
        //endDate = Convert.ToDateTime(endDate).ToString("MM/dd/yyyy", CultureInfo.InvariantCulture);

        //DateTime dt = DateTime.ParseExact(endDate, "d/M/yyyy", null);
        //endDate = dt.ToString("dd/MM/yyyy");

        DateTime strDt = DateTime.ParseExact(strDate, "MM/dd/yyyy", CultureInfo.InvariantCulture);
        //DateTime endDt = DateTime.ParseExact(endDate, "MM/dd/yyyy", CultureInfo.InvariantCulture);

        SqlConnection con = new SqlConnection(connValue);
        SqlCommand cmd = new SqlCommand();

        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Connection = con;

        cmd.CommandText = "testSP";

        SqlParameter prm = cmd.Parameters.Add("@ad_startDate", SqlDbType.DateTime);
        prm.Value = strDt;

        prm = cmd.Parameters.Add("@ad_endDate", SqlDbType.DateTime);
        prm.Value = endDate;

        prm = cmd.Parameters.Add("@ai_workDays", SqlDbType.Int);
        prm.Direction = ParameterDirection.Output;

        //prm = cmd.Parameters.Add("@as_errMsg", SqlDbType.VarChar);
        //prm.Direction = ParameterDirection.Output;

        con.Open();
        SqlDataReader dr = cmd.ExecuteReader();
        while (dr.Read())
            Console.WriteLine(dr.GetString(0));
        con.Dispose();
        con.Close();

        return cmd.Parameters[2].Value.ToString();
    }

    private string getDaysByGivenEndDate(string strDate, string endDate)
    {
        strDate = Convert.ToDateTime(strDate).ToString("MM/dd/yyyy", CultureInfo.InvariantCulture);
        endDate = Convert.ToDateTime(endDate).ToString("MM/dd/yyyy", CultureInfo.InvariantCulture);

        DateTime strDt = DateTime.ParseExact(strDate, "MM/dd/yyyy", CultureInfo.InvariantCulture);
        DateTime endDt = DateTime.ParseExact(endDate, "MM/dd/yyyy", CultureInfo.InvariantCulture);

        SqlConnection con = new SqlConnection(connValue);
        SqlCommand cmd = new SqlCommand();

        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Connection = con;

        cmd.CommandText = "testSP";

        SqlParameter prm = cmd.Parameters.Add("@ad_startDate", SqlDbType.DateTime);
        prm.Value = strDt;

        prm = cmd.Parameters.Add("@ad_endDate", SqlDbType.DateTime);
        prm.Value = endDt;

        prm = cmd.Parameters.Add("@ai_workDays", SqlDbType.Int);
        prm.Direction = ParameterDirection.Output;

        //prm = cmd.Parameters.Add("@as_errMsg", SqlDbType.VarChar);
        //prm.Direction = ParameterDirection.Output;

        con.Open();
        SqlDataReader dr = cmd.ExecuteReader();
        while (dr.Read())
            Console.WriteLine(dr.GetString(0));
        con.Dispose();
        con.Close();

        return cmd.Parameters[2].Value.ToString();
    }

    private string getEndDateByGivenDays(int _days, string strDate)
    {
        SqlConnection con = new SqlConnection(connValue);
        SqlCommand cmd = new SqlCommand();
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Connection = con;

        cmd.CommandText = "AddWorkdays";
        SqlParameter prm = cmd.Parameters.Add("@ad_startDate", SqlDbType.DateTime);
        prm.Value = strDate;
        prm = cmd.Parameters.Add("@actual_workDays", SqlDbType.Int);
        prm.Value = Convert.ToInt32(_days);
        prm = cmd.Parameters.Add("@endDate", SqlDbType.DateTime);
        prm.Direction = ParameterDirection.Output;
        con.Open();
        SqlDataReader dr = cmd.ExecuteReader();
        while (dr.Read())
            Console.WriteLine(dr.GetString(0));
        con.Dispose();
        con.Close();

        return cmd.Parameters[2].Value.ToString();
    }



    private DateTime ConvertToDateTime(string strDateTime)
    {
        DateTime dtFinaldate; string sDateTime;
        try
        {
            //dtFinaldate = Convert.ToDateTime(strDateTime); 

            string[] sDate = strDateTime.Split('/');
            sDateTime = sDate[1] + '/' + sDate[0] + '/' + sDate[2];
            dtFinaldate = Convert.ToDateTime(sDateTime);
        }
        catch (Exception e)
        {
            string[] sDate = strDateTime.Split('/');
            sDateTime = sDate[0] + '/' + sDate[1] + '/' + sDate[2];
            dtFinaldate = Convert.ToDateTime(sDateTime);
        }
        return dtFinaldate;
    }


    #endregion


    protected void btnAdd_Click(object sender, EventArgs e)
    {
        InsertNewJobOrder123(); // GS_CreateRequest
    }
    protected void ddlTaskType_SelectedIndexChanged(object sender, EventArgs e)
    {
       // PopulateDropDownBox(ddlTaskSubType, "SELECT  subTypeID, subTypeName, typeID FROM  SubTaskType Where typeID = " + ddlTaskType.SelectedValue + "", "subTypeID", "subTypeName");

            //67	General services               //68	Safety 	e	68	22	15	            //69	Maintenance	e	69	22	            //70	Transport 	we	70	22	            //71	Warehouse 	            //72	Security  	

        if (ddlTaskType.SelectedValue == "67")             //Gen Section	Service Adel Ali M Ashkanani
            ddlReqBy.SelectedValue = "415";
        else if (ddlTaskType.SelectedValue == "69")    // Maintenance Adel Ali M Ashkanani
            ddlReqBy.SelectedValue = "415";
        else if (ddlTaskType.SelectedValue == "68")      // Safety    Adel Ali M Ashkanani   
            ddlReqBy.SelectedValue = "415";

        else if (ddlTaskType.SelectedValue == "72")   // Security Services Section	Services Nasser Mamdouh M A Al-Shammari
            ddlReqBy.SelectedValue = "452";
        else if (ddlTaskType.SelectedValue == "70")  //Trans Nasser Mamdouh M A Al-Shammari
            ddlReqBy.SelectedValue = "452";
        else if (ddlTaskType.SelectedValue == "71")   //Warehouse Hussain Khalaf H M Aljabri
            ddlReqBy.SelectedValue = "418";

        else if (ddlTaskType.SelectedValue == "73")   //Archive  Adel Mohammed N A Al-Yafei
            ddlReqBy.SelectedValue = "90";

       // ================================================================================================

        //    // production Database 

        //if (ddlTaskType.SelectedValue == "67")             //Gen Section	Service Adel Ali M Ashkanani
        //    ddlReqBy.SelectedValue = "482";
        //else if (ddlTaskType.SelectedValue == "69")    // Maintenance Adel Ali M Ashkanani
        //    ddlReqBy.SelectedValue = "482";
        //else if (ddlTaskType.SelectedValue == "68")      // Safety    Adel Ali M Ashkanani   
        //    ddlReqBy.SelectedValue = "482";

        //else if (ddlTaskType.SelectedValue == "72")   // Security Services Section	Services Nasser Mamdouh M A Al-Shammari
        //    ddlReqBy.SelectedValue = "557";
        //else if (ddlTaskType.SelectedValue == "70")  //Trans Nasser Mamdouh M A Al-Shammari
        //    ddlReqBy.SelectedValue = "557";
        //else if (ddlTaskType.SelectedValue == "71")   //Warehouse Hussain Khalaf H M Aljabri
        //    ddlReqBy.SelectedValue = "484";

        //else if (ddlTaskType.SelectedValue == "73")   //Archive  Adel Mohammed N A Al-Yafei
        //    ddlReqBy.SelectedValue = "90";  
       
    }
    protected void ddlDept_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlDept.SelectedValue == "35")
        {
            trOthers.Visible = true;
        }
        else
        {
            trOthers.Visible = false;
            txtOthers.Text = "";
        }
    }
    
}