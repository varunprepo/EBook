﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
using System.Text;
public partial class ForgotPassword : System.Web.UI.Page
{
    UtilityClass uCls = null;
    string connValue = ConfigurationManager.ConnectionStrings["EBSDEBookConn"].ToString();
    DAL dal = null;
    protected void Page_Load(object sender, EventArgs e)
    {
         
    }
    protected void btnValidateUser_Click(object sender, EventArgs e)
    {
        UtilityClass uCls = new UtilityClass(this.Page);
        DAL dal = null;
        try
        {
            dal = new DAL(connValue);
            if (dal.ConnectDB(this.Page) == 'E')
                return;
            // uCls.DisplayLabels(dal, true);
            string authResult = uCls.AuthenticateUserNameOrEmailID(txtUserName.Text, txtEmailAddress.Text, dal);
            if (authResult == "0" || authResult == "")
            {
                ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('You are not an authenticated user, Enter valid User Name and Email address');</script>", false);
                txtUserName.Text = "";
                txtEmailAddress.Text = "";
                txtUserName.Focus();
                return;
            }
            else
            {
                string code = Guid.NewGuid().ToString();
                string emailID = txtEmailAddress.Text.Trim();
                string userName = txtUserName.Text.Trim();
                SqlCommand sqlCommand = null;
                if (userName != "" && emailID != "")
                {
                    sqlCommand = new SqlCommand("update Contact set code=@code where emailAddress=@emailAddress and userName=@userName", dal.SqlConnection);
                    sqlCommand.Parameters.AddWithValue("@emailAddress", emailID);
                    sqlCommand.Parameters.AddWithValue("@userName", userName);
                }
                else if (userName == "" && emailID != "")
                {
                    sqlCommand = new SqlCommand("update Contact set code=@code where emailAddress=@emailAddress", dal.SqlConnection);
                    sqlCommand.Parameters.AddWithValue("@emailAddress", emailID);
                }
                else if (userName != "" && emailID == "")
                {
                    sqlCommand = new SqlCommand("update Contact set code=@code where userName=@userName", dal.SqlConnection);
                    sqlCommand.Parameters.AddWithValue("@userName", userName);
                }
                                
                sqlCommand.Parameters.AddWithValue("@code", code);          
                 
                if (sqlCommand.ExecuteNonQuery() == 1)
                {
                    StringBuilder sbody = new StringBuilder();                 
                    sbody.Append("Dear Sir/Madam,</br>");
                    sbody.Append("<br/>");
                    sbody.Append("Based on your Forgot Password request. The following is the link for reseting your EBook application password:- <br/>");
                    sbody.Append("<br/>");
                    // here i am sending a link to the user's mail address with the three values email,code,uname
                    // these three values i am sending  this link with the values using querystring method.
                    string url = Request.Url.AbsoluteUri;
                    if (url.Contains(":"))
                        url = url.Substring(0, uCls.GetNthIndex(url, '/', 4));
                    else
                        url = url.Substring(0, uCls.GetNthIndex(url, '/', 2));
                    url = url + "/ResetPassword.aspx";
                    sbody.Append("<a href=" + url + "?code=" + code + ">Click here to change your password</a><br/><br/>");
                    sbody.Append("Thanks & Regards,<br/>EBSD EBook Team<br/>");
                    //in the below line i am sending mail with the link to the user.
                    //in this line i am passing four parameters 1st sender's mail address ,2nd receiever mail address, 3rd Subject,4th sbody.ToString() there will be complete link
                    // inside the sbody
                    System.Net.Mail.MailMessage mail = new System.Net.Mail.MailMessage("vpuchnanda@ashghal.gov.qa", emailID, "Reset Your Password", sbody.ToString());
                    //mail.CC.Add("any other email address if u want for cc");                
                    System.Net.Mail.SmtpClient mailclient = new System.Net.Mail.SmtpClient();

                    // here am setting the property IsBodyHtml true because i am using html tags inside the mail's code
                    mail.IsBodyHtml = true;
                    mailclient.Host = ConfigurationManager.AppSettings["SmtpHostIP"].ToString();
                    mailclient.Port = Convert.ToInt32(ConfigurationManager.AppSettings["SmtpHostPort"].ToString());
                    mailclient.Send(mail);
                    ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('An Email has been send to your emailid, with a link to reset your password');</script>", false);
                }
                sqlCommand.Dispose();                
            }
            
        }
        catch(Exception ex)
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Error occurred while performing database operation')</script>", false);
        }
        finally{
            if(dal!=null)
                dal.DisconnectDB();
        }        
    }     
}