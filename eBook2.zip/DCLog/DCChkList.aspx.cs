﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Data.SqlClient;
using System.Text.RegularExpressions;
using System.IO;
using Microsoft.Office.Interop.Word;
using System.Runtime.InteropServices;
using System.Reflection;
using System.Drawing;


using Spire.Doc.Documents;


public partial class DCLog_DCChkList : System.Web.UI.Page
{
    string connValue = System.Configuration.ConfigurationManager.ConnectionStrings["EBSDEBookConn"].ConnectionString;

    IList<string> lsttxtColl = new List<string>();
    IList<string> lstChkBoxColl = new List<string>();
    private int numOfRows = 0;
    private int _jobID = 0;

    private void GenerateTable(int rowsCount)
    {
        System.Web.UI.WebControls.Table table = new System.Web.UI.WebControls.Table();

        table.ID = "Table1";
        // table.HorizontalAlign = HorizontalAlign.Left;       


        Page.Form.Controls.Add(table);

       // MainTbl.Controls.Add(table);

        PlaceHolder1.Controls.Add(table);

        TableRow rowHeader = new TableRow();
        TableCell cellHeader = new TableCell();
        cellHeader.Text = "Terms of Reference for Check";
        cellHeader.ForeColor = Color.Maroon;
        rowHeader.Cells.Add(cellHeader);
        table.Rows.Add(rowHeader);
        const int colsCount = 2;
        for (int i = 0; i < numOfRows; i++)
        {
            TableRow row = new TableRow();
            for (int j = 0; j < colsCount; j++)
            {
                if (j == 0)
                {
                    TableCell cell = new TableCell();
                    TextBox tb = new TextBox();
                    tb.Text = lsttxtColl[i].ToString();

                    tb.ID = "TextBoxRow_" + i + "Col_" + j;
                    tb.Width = 800;
                    cell.Controls.Add(tb);
                    row.Cells.Add(cell);
                }
                else if (j == 1)
                {
                    TableCell cell2 = new TableCell();

                    System.Web.UI.WebControls.DropDownList drpList = new System.Web.UI.WebControls.DropDownList();
                    drpList.AutoPostBack = true;

                    drpList.SelectedIndexChanged += new EventHandler(SelectedIndexChanged);
                    //lstChkBoxColl[i]

                    drpList.ID = "check" + (i + 1);

                    if (drpList.DataSource == null)
                        PopulateDropDownBox(drpList, "SELECT dcChkTypeID,chkName FROM DcCheckType", "dcChkTypeID", "chkName");  // where JobStatusid in(5,6,7,8)

                    drpList.SelectedValue = lstChkBoxColl[i];

                    cell2.Controls.Add(drpList);
                    row.Cells.Add(cell2);
                }

                table.Rows.Add(row);
            }
            rowsCount++;
            ViewState["RowsCount"] = rowsCount;
        }
    }
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            getDCJobData(_jobID); 
        }
    }
    int chkListType = 0;
    protected void Page_Init(object sender, EventArgs e)
    {
        if (Session["UserName"] == null)
        {
            Response.Redirect("~/LoginPage.aspx", false);
            return;
        }

        if (Session["ChkListPayID"] != null)
            _jobID = Convert.ToInt32(Session["ChkListPayID"]);
        else
            return;

        if ((Session["CntrTypeChk"].ToString().Equals("1")) || (Session["CntrTypeChk"].ToString().Equals("2")))
        {
            chkListType = 1;
            lblTitle.Text = "Document Control Checklist (Construction Project) ";
        }
        else if (Session["CntrTypeChk"].ToString().Equals("5"))
        {
            chkListType = 5;
            lblTitle.Text = "Document Control Checklist (Design Project) ";
        }
        else if (Session["CntrTypeChk"].ToString().Equals("6"))
        {
            chkListType = 6;
            lblTitle.Text = "Document Control Checklist (Supervision Project)";
        }
        else
        {
            chkListType = 10;
            lblTitle.Text = "Document Control Checklist  (Other Project) ";
        }

        lblPayType.Text = chkListType.ToString();

        IList<int> isApplicable = new List<int>();
        fillData(chkListType, ref isApplicable);

        //foreach (int rowNo in isApplicable)
        //{
        //    string clmnName = "check" +rowNo;
        //    int chkStat = 0;
        //    updateCheckListColumnDataPageLoad(_jobID, clmnName, chkStat);
        //}

        fillCheckedData(_jobID, chkListType);
        numOfRows = lsttxtColl.Count();

       

        GenerateTable(numOfRows);

    }
    private void updateCheckListColumnDataPageLoad(int jobID, string clmName, int chkStat)
    {
        string UpdateQuery = "Update dcCheckList Set " + clmName + "  ='" + chkStat + "',isUpdate = 1 Where jobID = " + _jobID + " ";
        SqlConnection con = new SqlConnection(connValue);
        con.Open();
        SqlCommand com = new SqlCommand(UpdateQuery, con);
        com.ExecuteNonQuery();
        con.Close();
    }
    private void updateCheckListColumnData(int jobID, string clmName, int chkStat)
    {
        string UpdateQuery = "Update dcCheckList Set " + clmName + "  ='" + chkStat + "',isUpdate = 1 Where jobID = " + _jobID + " ";
        SqlConnection con = new SqlConnection(connValue);
        con.Open();
        SqlCommand com = new SqlCommand(UpdateQuery, con);
        com.ExecuteNonQuery();
        con.Close();
    }
    private IList<string> fillCheckedData(int jobID, int chkListType)
    {

        string sqlQuery = " SELECT check1, check2, check3, check4, check5, check6, check7, check8, check9, check10, check11, check12, check13, check14, check15, check16, check17, check18  from dcCheckList where jobID =" + _jobID + " and listTypeID = " + chkListType + "";

        using (SqlConnection objCon = new SqlConnection(connValue))
        {
            objCon.Open();
            SqlCommand objCmd = new SqlCommand(sqlQuery, objCon);
            using (SqlDataReader dr = objCmd.ExecuteReader())
            {
                while (dr.Read())
                {

                    lstChkBoxColl.Add(dr["check1"].ToString());
                    lstChkBoxColl.Add(dr["check2"].ToString());
                    lstChkBoxColl.Add(dr["check3"].ToString());
                    lstChkBoxColl.Add(dr["check4"].ToString());
                    lstChkBoxColl.Add(dr["check5"].ToString());
                    lstChkBoxColl.Add(dr["check6"].ToString());
                    lstChkBoxColl.Add(dr["check7"].ToString());
                    lstChkBoxColl.Add(dr["check8"].ToString());
                    lstChkBoxColl.Add(dr["check9"].ToString());
                    lstChkBoxColl.Add(dr["check10"].ToString());
                    lstChkBoxColl.Add(dr["check11"].ToString());
                    lstChkBoxColl.Add(dr["check12"].ToString());
                    lstChkBoxColl.Add(dr["check13"].ToString());
                    lstChkBoxColl.Add(dr["check14"].ToString());
                    lstChkBoxColl.Add(dr["check15"].ToString());
                    lstChkBoxColl.Add(dr["check16"].ToString());
                    lstChkBoxColl.Add(dr["check17"].ToString());
                    lstChkBoxColl.Add(dr["check18"].ToString());
                }
            }
        }
        return lstChkBoxColl;
    }   
    private void PopulateDropDownBox(DropDownList ddlBox, string sqlQuery, string valueMember, string displayName)
    {
        System.Data.DataTable table = new System.Data.DataTable();

        try
        {
            using (SqlConnection sqlConn = new SqlConnection(connValue))
            {
                using (SqlDataAdapter da = new SqlDataAdapter(sqlQuery, sqlConn))
                {
                    sqlConn.Open();
                    da.Fill(table);
                }
            }
            //cmbBox.Items.Add("Select");
            ddlBox.DataSource = table;
            ddlBox.DataTextField = displayName;
            ddlBox.DataValueField = valueMember;
            ddlBox.SelectedIndex = -1;

            ddlBox.DataBind();
            ddlBox.Items.Insert(0, new ListItem("--Select--"));
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    protected void SelectedIndexChanged(object sender, EventArgs e)
    {
        DropDownList ddl = (DropDownList)sender;
        if (ddl.SelectedIndex != 0)
        {
            string ID = ddl.ID;
            string DcreqID = ddl.SelectedValue;
            string jobID = ddl.ToolTip;
            UpdateJobDCRequest(Convert.ToInt32(DcreqID), ID);
        }
        else
        {
            string ID = ddl.ID;
           // string DcreqID = ddl.SelectedValue;
            string jobID = ddl.ToolTip;
            UpdateJobDCRequest(0, ID);       // not Select null 
        }
    }
    private void UpdateJobDCRequest(int reqID, string clmName)
    {
        // SELECT dcChkTypeID,chkName FROM DcCheckType

        string UpdateQuery = "Update dcCheckList Set " + clmName + "  =" + reqID + ",isUpdate = 1 Where jobID = " + _jobID + " ";
        SqlConnection con = new SqlConnection(connValue);
        con.Open();
        SqlCommand com = new SqlCommand(UpdateQuery, con);
        com.ExecuteNonQuery();
        con.Close();
    }
    protected void chk_CheckedChanged(object sender, EventArgs e)
    {

        System.Web.UI.WebControls.CheckBox currentCheckbox = sender as System.Web.UI.WebControls.CheckBox;
        string clmName = currentCheckbox.ID;
        updateWordData(clmName, currentCheckbox.Checked);
        string extractInteger = Regex.Match(currentCheckbox.ID, @"\d+").Value;
        //Label currentlabel = (Label)Labeldiv.FindControl("Label" + extractInteger);
    }


    private void update_IfApplicable(string clmName, Boolean chkStat)
    {
        //string UpdateQuery = "Update payCheckList Set isChk ='" + chkStat + "' Where transID = " + privID + " ";

        string UpdateQuery = "Update dcCheckList Set " + clmName + "  ='" + chkStat + "',isUpdate = 1 Where jobID = " + _jobID + " ";
        SqlConnection con = new SqlConnection(connValue);
        con.Open();
        SqlCommand com = new SqlCommand(UpdateQuery, con);
        com.ExecuteNonQuery();
        con.Close();

        fillCheckedData(100,1);
    }

    private void updateWordData(string clmName, Boolean chkStat)
    {
        //string UpdateQuery = "Update payCheckList Set isChk ='" + chkStat + "' Where transID = " + privID + " ";

        string UpdateQuery = "Update dcCheckList Set " + clmName + "  ='" + chkStat + "',isUpdate = 1 Where jobID = " + _jobID + " ";
        SqlConnection con = new SqlConnection(connValue);
        con.Open();
        SqlCommand com = new SqlCommand(UpdateQuery, con);
        com.ExecuteNonQuery();
        con.Close();

        //fillCheckedData(100);
    }
    private IList<string> fillData(int chkListTypeID,ref IList<int> isApplicableColl)
    {

        // string sqlQuery = " SELECT CheckNo, CheckList  from dcCheckListData where listTypID = " + chkListTypeID + "";

        string sqlQuery = "SELECT dcChkListID, checkNo, checkList FROM DCCheckListData WHERE listTypeID =  " + chkListTypeID + "";

        using (SqlConnection objCon = new SqlConnection(connValue))
        {
            objCon.Open();
            SqlCommand objCmd = new SqlCommand(sqlQuery, objCon);
            using (SqlDataReader dr = objCmd.ExecuteReader())
            {
                int iCnt = 0;
                while (dr.Read())
                { 
                    iCnt = iCnt+1;
                    lsttxtColl.Add(dr["CheckList"].ToString());

                    if (dr["CheckList"].ToString().Contains("if applicable"))
                    {
                        isApplicableColl.Add(iCnt);
                    }
                }
            }
        }

        return lsttxtColl;
    }
    protected void Button1_Click1(object sender, EventArgs e)
    {

    }
    protected void btnWord_Click(object sender, EventArgs e)
    {

    }
    protected void txtPrjMngr_TextChanged(object sender, EventArgs e)
    {

    }
    private void getDCJobData(int jobID)
    {
        string sqlQuery = "SELECT job.jobID, Job.jobNo, Department.deptName, Company.cmpName, ProjCoordinator.coordName, Job.committmentNo, Job.submissionNoDC, Job.reviewDateDC, " + 
                        " Job.projectTitle, Job.jobReceivedDate, [Document].referenceNo FROM  Job INNER JOIN Department ON Job.deptID = Department.departmentID INNER JOIN  [Document] ON Job.docRefID = [Document].documentID LEFT OUTER JOIN " + 
                         " ProjCoordinator ON Job.projCoordinatorID = ProjCoordinator.prjCoordID LEFT OUTER JOIN  Company ON Job.contractorID = Company.companyID WHERE  (Job.jobID =" + _jobID + ")";

        using (SqlConnection objCon = new SqlConnection(connValue))
        {
            objCon.Open();
            using (SqlCommand objCmd = new SqlCommand(sqlQuery, objCon))
            {
                using (SqlDataReader dr = objCmd.ExecuteReader())
                {
                    while (dr.Read())
                    {
                        lblPM.Text = dr["coordName"].ToString();
                        lblDept.Text = dr["deptName"].ToString();
                        lblCntr.Text = dr["cmpName"].ToString();
                        lblCommitmentNo.Text = dr["committmentNo"].ToString();
                        lblSubmNo.Text = dr["submissionNoDC"].ToString();

                        lblProjTitle.Text = dr["projectTitle"].ToString();

                        if (dr["reviewDateDC"].ToString() != "")
                          lblReviewDate.Text = Convert.ToDateTime(dr["reviewDateDC"]).ToString("dd/MMM/yyyy");
                        if (dr["jobReceivedDate"].ToString() != "")
                           lblRefDate.Text = Convert.ToDateTime(dr["jobReceivedDate"]).ToString("dd/MMM/yyyy");

                        lblLatestRefNo.Text = dr["referenceNo"].ToString();

                        lblCheckedBy.Text = Session["UserName"].ToString();  //dr["reviewDateDC"].ToString()   

                    }
                }
            }
        }
    }
    private void CreateDCCheckList(string userName)
    {
        string srcPath = string.Empty;
        string destPath = string.Empty;

        lnkDownload.Text = "Create Link";

        string strTemp = string.Empty;

        // 1-5-6-10        

        try
        {
            if (chkListType == 6)
            {
                srcPath = @"C:\DcChkList\DCChecklist_Supervision.docx";
                strTemp = "C:\\DcChkList_Out\\" + _jobID + "_" + "DCChecklist_Supervision.docx";
            }
            else if (chkListType == 1)
            {
                srcPath = @"C:\DcChkList\DCChecklist_Construction.docx";
                strTemp = "C:\\DcChkList_Out\\" + _jobID + "_" + "DCChecklist_Construction.docx";
            }
            else if (chkListType == 5)
            {
                srcPath = @"C:\DcChkList\DCChecklist_Design.docx";
                strTemp = "C:\\DcChkList_Out\\" + _jobID + "_" + "DCChecklist_Design.docx";
            }
            else if (chkListType == 10)
            {
                srcPath = @"C:\DcChkList\DCChecklist_Other.docx";
                strTemp = "C:\\DcChkList_Out\\" + _jobID + "_" + "DCChecklist_Other.docx";
            }
            else 
            {
                srcPath = @"C:\DcChkList\DCChecklist_Other.docx"; //DCChecklist_Other
                strTemp = "C:\\DcChkList_Out\\" + _jobID + "_" + "DCChecklist_Other.docx";
            }
        }
        catch (Exception ex)
        {
            Response.Write("Error in Reading filePath");           
        }
        try
        {
            Session["DCOutPath"] = strTemp;
            destPath = strTemp;

            CreateWordDocNew(srcPath, destPath, userName);

 

            lnkDownload.Enabled = true;
            lnkDownload.Text = "DownLoad CheckList";
        }
        catch (Exception ex)
        {
            //Response.Write("Error Afetr Reading filePath");

            lblSummary.Text = lblSummary.Text + "" + "Error Afetr Reading filePath";
        }
    }
    protected void lnkDownload_Click1(object sender, EventArgs e)
    {
        LinkButton lnkbtn = sender as LinkButton;
        GridViewRow gvrow = lnkbtn.NamingContainer as GridViewRow;
        string filePath = string.Empty;
        
        //filePath = "C:\\DcChkList_Out\\" + _jobID + "_" + "DCChecklist_Supervision.docx";

        //if (Session["DCOutPath"] != null)
        //{

        //}

        filePath = Session["DCOutPath"].ToString();

        Response.ContentType = "image/jpg";
        Response.AddHeader("Content-Disposition", "attachment;filename=\"" + filePath + "\"");
        Response.TransmitFile(filePath);
        Response.End();
    }
    protected void btnDClist_Click(object sender, EventArgs e)
    {
        try
        {        
            if (Session["UserDisplayName"] != null)
            {
                CreateDCCheckList(Session["UserDisplayName"].ToString());        //Session["LoginUserName"]
                lnkDownload.Visible = true;
            } 
        }
        catch (Exception)
        {
            Response.Write("UserDisplayName Not Exist");
        }
    }

    private void CreateWordDocNew_Old(Object fileName, object saveAs, string _userName)
    {
        IList<string> strDCColl = getDcCkeckListData();
        Spire.Doc.Document document = null;

        try
        {
            if (File.Exists((string)fileName))
            {
                lblSummary.Text = "Step-1 File Read Success";
            }
        }
        catch (Exception ex)
        {
            // Response.Write(" THis Source File is Not exist");
        }

        try
        {
            if (File.Exists((string)fileName))
            {

                lblSummary.Text = lblSummary.Text + " - " + " Step-2 Success";

                try
                {
                    document = new Spire.Doc.Document();
                    document.LoadFromFile(fileName.ToString());
                }
                catch (Exception ex)
                {
                    lblSummary.Text = lblSummary.Text + " - " + "Source File is Not exist";
                }

                #region MyRegion

                /*
                * On Bookmark set the users specific data
                */

                Spire.Doc.Bookmark book = document.Bookmarks["txtContractor"];
                Spire.Doc.Documents.Paragraph par1 = book.BookmarkStart.OwnerParagraph;
                par1.AppendText(lblCntr.Text);


                book = document.Bookmarks["txtContractNo"];
                par1 = book.BookmarkStart.OwnerParagraph;
                par1.AppendText(lblCommitmentNo.Text);


                book = document.Bookmarks["txtSubmitNo"];
                par1 = book.BookmarkStart.OwnerParagraph;
                par1.AppendText(lblSubmNo.Text);


                book = document.Bookmarks["txtUser"];
                par1 = book.BookmarkStart.OwnerParagraph;
                par1.AppendText(_userName);


                book = document.Bookmarks["txtDate"];
                par1 = book.BookmarkStart.OwnerParagraph;
                par1.AppendText(System.DateTime.Now.Date.ToShortDateString());


                try
                {
                    for (int iCnt = 1; iCnt < strDCColl.Count; iCnt++)
                    {
                        string chkName = "Text" + iCnt;
                        if (document.Bookmarks[chkName] != null)
                        {

                            if (strDCColl[iCnt].ToString() == "")
                            {
                                book = document.Bookmarks[chkName];
                                par1 = book.BookmarkStart.OwnerParagraph;
                                par1.AppendText("");
                            }
                            else if (strDCColl[iCnt].Equals("1"))
                            {
                                book = document.Bookmarks[chkName];
                                par1 = book.BookmarkStart.OwnerParagraph;
                                par1.AppendText("Received");
                            }
                            else if (strDCColl[iCnt].Equals("2"))
                            {
                                book = document.Bookmarks[chkName];
                                par1 = book.BookmarkStart.OwnerParagraph;
                                par1.AppendText("Not Received");
                            }
                            else if (strDCColl[iCnt].Equals("3"))
                            {
                                book = document.Bookmarks[chkName];
                                par1 = book.BookmarkStart.OwnerParagraph;
                                par1.AppendText("Partially received");
                            }
                            else if (strDCColl[iCnt].Equals("4"))
                            {
                                book = document.Bookmarks[chkName];
                                par1 = book.BookmarkStart.OwnerParagraph;
                                par1.AppendText("Not available");
                            }
                            else if (strDCColl[iCnt].Equals("5"))
                            {
                                book = document.Bookmarks[chkName];
                                par1 = book.BookmarkStart.OwnerParagraph;
                                par1.AppendText("Not applicable");
                            }
                            else if (strDCColl[iCnt].Equals("6"))
                            {
                                book = document.Bookmarks[chkName];
                                par1 = book.BookmarkStart.OwnerParagraph;
                                par1.AppendText("Not Provided");
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    lblSummary.Text = lblSummary.Text + " - " + " Try error at Parameters Read";
                }
                #endregion

                lblSummary.Text = lblSummary.Text + " - " + " Step-3 Success (Parameters Read)";

            }
            else
            {
                lblSummary.Text = lblSummary.Text + " - " + "Source File is Not exist-1";
            }

            try
            {
                // Save this document as the users name followed by .docx
                document.SaveToFile(saveAs.ToString());
                // Release this document from memory
                //aDoc.SaveAs(ref saveAs, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing);
                lblSummary.Text = lblSummary.Text + " - " + " Step-4 Success (SaveAs out file )";

            }
            catch (Exception ex)
            {
                lblSummary.Text = lblSummary.Text + " - " + "Destination File is Not exist";
            }

            lblSummary.Text = lblSummary.Text + " - " + " Step-6 Success";
        }
        catch (Exception ex)
        {
            lblSummary.Text = lblSummary.Text + " - " + "Source File is Not exist-2";
            //throw ex;           
        }
    }


    private void CreateWordDocNew(Object fileName, object saveAs, string _userName)
    {
        IList<string> strDCColl = getDcCkeckListData();
        Spire.Doc.Document document = null;

        try
        {
            if (File.Exists((string)fileName))
            {
                lblSummary.Text = "Step-1 File Read Success";
            }
        }
        catch (Exception ex)
        {
            // Response.Write(" THis Source File is Not exist");
        }

        try
        {
            if (File.Exists((string)fileName))
            {

                lblSummary.Text = lblSummary.Text + " - " + " Step-2 Success";

                try
                {
                    document = new Spire.Doc.Document();
                    document.LoadFromFile(fileName.ToString());
                }
                catch (Exception ex)
                {
                    lblSummary.Text = lblSummary.Text + " - " + "Source File is Not exist";
                }

                #region MyRegion

                /*
                * On Bookmark set the users specific data
                */

                Spire.Doc.Bookmark book = document.Bookmarks["bookConsultant"];
                //Spire.Doc.Documents.Paragraph par1 = book.BookmarkStart.OwnerParagraph;
                BookmarksNavigator bookmarkNavigator = new BookmarksNavigator(document);
                // //locate the bookmark
                bookmarkNavigator.MoveToBookmark("bookConsultant");
                //replace the content of bookmark
                bookmarkNavigator.ReplaceBookmarkContent(lblCntr.Text, false);

                bookmarkNavigator.MoveToBookmark("bookDeptName");
                //replace the content of bookmark
                bookmarkNavigator.ReplaceBookmarkContent(lblDept.Text, false);

                bookmarkNavigator.MoveToBookmark("bookCommitmentNo");
                //replace the content of bookmark
                bookmarkNavigator.ReplaceBookmarkContent(lblCommitmentNo.Text, false);

                bookmarkNavigator.MoveToBookmark("bookSubmissionNo");
                //replace the content of bookmark
                bookmarkNavigator.ReplaceBookmarkContent(lblSubmNo.Text, false);

                bookmarkNavigator.MoveToBookmark("bookLatestRefNo");
                //replace the content of bookmark
                bookmarkNavigator.ReplaceBookmarkContent(lblLatestRefNo.Text, false);

                bookmarkNavigator.MoveToBookmark("bookReviewDate");
                //replace the content of bookmark
                bookmarkNavigator.ReplaceBookmarkContent(lblReviewDate.Text, false);

                bookmarkNavigator.MoveToBookmark("bookProjTitle");
                //replace the content of bookmark
                bookmarkNavigator.ReplaceBookmarkContent(lblProjTitle.Text.Replace("\r", "").Replace("\n", ""), false);

                bookmarkNavigator.MoveToBookmark("bookRefDate");
                //replace the content of bookmark
                bookmarkNavigator.ReplaceBookmarkContent(lblRefDate.Text, false);

                bookmarkNavigator.MoveToBookmark("bookCheckedBy");
                //replace the content of bookmark
                bookmarkNavigator.ReplaceBookmarkContent(lblCheckedBy.Text, false);


                try
                {
                    for (int iCnt = 1; iCnt < strDCColl.Count; iCnt++)
                    {
                        string chkName = "Text" + iCnt;
                        if (document.Bookmarks[chkName] != null)
                        {

                            if (strDCColl[iCnt].ToString() == "")
                            {
                                // //locate the bookmark
                                bookmarkNavigator.MoveToBookmark(chkName);
                                //replace the content of bookmark
                                bookmarkNavigator.ReplaceBookmarkContent("", false);
                            }
                            else if (strDCColl[iCnt].Equals("1"))
                            {
                                // //locate the bookmark
                                bookmarkNavigator.MoveToBookmark(chkName);
                                //replace the content of bookmark
                                bookmarkNavigator.ReplaceBookmarkContent("Received", false);
                            }
                            else if (strDCColl[iCnt].Equals("2"))
                            {
                                // //locate the bookmark
                                bookmarkNavigator.MoveToBookmark(chkName);
                                //replace the content of bookmark
                                bookmarkNavigator.ReplaceBookmarkContent("Not Received", false);
                            }
                            else if (strDCColl[iCnt].Equals("3"))
                            {
                                // //locate the bookmark
                                bookmarkNavigator.MoveToBookmark(chkName);
                                //replace the content of bookmark
                                bookmarkNavigator.ReplaceBookmarkContent("Partially Received", false);
                            }
                            else if (strDCColl[iCnt].Equals("4"))
                            {
                                // //locate the bookmark
                                bookmarkNavigator.MoveToBookmark(chkName);
                                //replace the content of bookmark
                                bookmarkNavigator.ReplaceBookmarkContent("Not available", false);
                            }
                            else if (strDCColl[iCnt].Equals("5"))
                            {
                                // //locate the bookmark
                                bookmarkNavigator.MoveToBookmark(chkName);
                                //replace the content of bookmark
                                bookmarkNavigator.ReplaceBookmarkContent("Not applicable", false);
                            }
                            else if (strDCColl[iCnt].Equals("6"))
                            {
                                // //locate the bookmark
                                bookmarkNavigator.MoveToBookmark(chkName);
                                //replace the content of bookmark
                                bookmarkNavigator.ReplaceBookmarkContent("Not Provided", false);
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    lblSummary.Text = lblSummary.Text + " - " + " Try error at Parameters Read";
                }
                #endregion

                lblSummary.Text = lblSummary.Text + " - " + " Step-3 Success (Parameters Read)";

            }
            else
            {
                lblSummary.Text = lblSummary.Text + " - " + "Source File is Not exist-1";
            }

            try
            {
                // Save this document as the users name followed by .docx
                document.SaveToFile(saveAs.ToString());
                // Release this document from memory
                //aDoc.SaveAs(ref saveAs, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing);
                lblSummary.Text = lblSummary.Text + " - " + " Step-4 Success (SaveAs out file )";

            }
            catch (Exception ex)
            {
                lblSummary.Text = lblSummary.Text + " - " + "Destination File is Not exist";
            }

            lblSummary.Text = lblSummary.Text + " - " + " Step-6 Success";
        }
        catch (Exception ex)
        {
            lblSummary.Text = lblSummary.Text + " - " + "Source File is Not exist-2";
            //throw ex;           
        }
    }



    private IList<string> getDcCkeckListData()
    {
        IList<string> strColl= new List<string>();
        string sqlQuery = "SELECT jobID, check1, check2, check3, check4, check5, check6, check7, check8, check9, check10, check11, check12, check13, check14, check15 FROM  DcCheckList WHERE (jobID = " + _jobID + ")";
        using (SqlConnection objCon = new SqlConnection(connValue))
        {
            objCon.Open();
            using (SqlCommand objCmd = new SqlCommand(sqlQuery, objCon))
            {
                using (SqlDataReader dr = objCmd.ExecuteReader())
                {
                    while (dr.Read())
                    {
                         strColl.Add(dr["jobID"].ToString());
                         strColl.Add(dr["check1"].ToString());
                         strColl.Add(dr["check2"].ToString());
                         strColl.Add(dr["check3"].ToString());

                         strColl.Add(dr["check4"].ToString());
                         strColl.Add(dr["check5"].ToString());
                         strColl.Add(dr["check6"].ToString());

                         strColl.Add(dr["check7"].ToString());
                         strColl.Add(dr["check8"].ToString());
                         strColl.Add(dr["check9"].ToString());

                         strColl.Add(dr["check10"].ToString());
                    }
                }
            }
        }
        return strColl;
    }
    private void CreateWordDocNew_Sree(Object fileName, object saveAs,string _userName)
    {
        IList<string> strDCColl = getDcCkeckListData();

        object missing = System.Reflection.Missing.Value;
        Microsoft.Office.Interop.Word.Application wordApp = new Microsoft.Office.Interop.Word.ApplicationClass();
        Microsoft.Office.Interop.Word.Document aDoc = null;
        wordApp.Visible = true;
        wordApp.DisplayAlerts = Microsoft.Office.Interop.Word.WdAlertLevel.wdAlertsNone;
        wordApp.DisplayAlerts = WdAlertLevel.wdAlertsNone;

        try
        {
            if (File.Exists((string)fileName))
            {
                lblSummary.Text =  "Step-1 File Read Success";
            }
        }
        catch (Exception ex)
        {
           // Response.Write(" THis Source File is Not exist");
        }

        try
        {
            if (File.Exists((string)fileName))
            {  
                object readOnly = false;
                object isVisible = false;
                wordApp.Visible = false;

               lblSummary.Text = lblSummary.Text + " - " +  " Step-2 Success";

                try
                {
                  aDoc = wordApp.Documents.Open(ref fileName, ref missing, ref readOnly, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref isVisible, ref missing, ref missing, ref missing, ref missing);
                //aDoc.Activate();
                }
                catch (Exception ex)
                {
                    lblSummary.Text = lblSummary.Text + " - " +  "Source File is Not exist";
                }

                #region MyRegion

                if (aDoc.Bookmarks.Exists("txtContractor"))
                {
                    Microsoft.Office.Interop.Word.Bookmark bm = aDoc.Bookmarks["txtContractor"];
                    Microsoft.Office.Interop.Word.Range range = bm.Range.Duplicate;
                    aDoc.FormFields["txtContractor"].Result = lblCntr.Text;
                }
                if (aDoc.Bookmarks.Exists("txtContractNo"))
                {
                    Microsoft.Office.Interop.Word.Bookmark bm = aDoc.Bookmarks["txtContractNo"];
                    Microsoft.Office.Interop.Word.Range range = bm.Range.Duplicate;
                    aDoc.FormFields["txtContractNo"].Result = lblCommitmentNo.Text;
                }
                if (aDoc.Bookmarks.Exists("txtSubmitNo"))
                {
                    Microsoft.Office.Interop.Word.Bookmark bm = aDoc.Bookmarks["txtSubmitNo"];
                    Microsoft.Office.Interop.Word.Range range = bm.Range.Duplicate;
                    aDoc.FormFields["txtSubmitNo"].Result = lblSubmNo.Text;
                }
                if (aDoc.Bookmarks.Exists("txtUser"))
                {
                    Microsoft.Office.Interop.Word.Bookmark bm = aDoc.Bookmarks["txtUser"];
                    Microsoft.Office.Interop.Word.Range range = bm.Range.Duplicate;
                    aDoc.FormFields["txtUser"].Result = _userName;         //  Session["UserName"].ToString();
                }
                if (aDoc.Bookmarks.Exists("txtDate"))
                {
                    Microsoft.Office.Interop.Word.Bookmark bm = aDoc.Bookmarks["txtDate"];
                    Microsoft.Office.Interop.Word.Range range = bm.Range.Duplicate;
                    aDoc.FormFields["txtDate"].Result = System.DateTime.Now.Date.ToShortDateString();
                }

                try
                {
                    for (int iCnt = 1; iCnt < strDCColl.Count; iCnt++)
                    {
                        string chkName = "Text" + iCnt;
                        if (aDoc.Bookmarks.Exists(chkName))
                        {
                            Microsoft.Office.Interop.Word.Bookmark bm = aDoc.Bookmarks[chkName];
                            Microsoft.Office.Interop.Word.Range range = bm.Range.Duplicate;

                            if (strDCColl[iCnt].ToString() == "")
                                aDoc.FormFields[chkName].Result = "";
                            else if (strDCColl[iCnt].Equals("1"))
                                aDoc.FormFields[chkName].Result = "Received";
                            else if (strDCColl[iCnt].Equals("2"))
                                aDoc.FormFields[chkName].Result = "Not received";
                            else if (strDCColl[iCnt].Equals("3"))
                                aDoc.FormFields[chkName].Result = "Partially received";
                            else if (strDCColl[iCnt].Equals("4"))
                                aDoc.FormFields[chkName].Result = "Not available";
                            else if (strDCColl[iCnt].Equals("5"))
                                aDoc.FormFields[chkName].Result = "Not applicable";
                            else if (strDCColl[iCnt].Equals("6"))
                                aDoc.FormFields[chkName].Result = "Not Provided";
                        }
                    }
                }
                catch (Exception ex)
                {
                    lblSummary.Text = lblSummary.Text + " - " + " Try error at Parameters Read";
                }
                #endregion

              lblSummary.Text = lblSummary.Text + " - " +  " Step-3 Success (Parameters Read)";

            }
            else
            {
               lblSummary.Text = lblSummary.Text + " - " +  "Source File is Not exist-1";
               // return;
            }

            try
            {
                aDoc.SaveAs(ref saveAs, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing);
                lblSummary.Text = lblSummary.Text + " - " +  " Step-4 Success (SaveAs out file )";
            
            }
            catch (Exception ex)
            {
                lblSummary.Text = lblSummary.Text + " - " +  "Destination File is Not exist";
            }
           
            object saveChanges = Microsoft.Office.Interop.Word.WdSaveOptions.wdPromptToSaveChanges;
            object originalFormat = Microsoft.Office.Interop.Word.WdOriginalFormat.wdWordDocument;
            object routeDocument = true;

           // Response.Write(" Step-5 Success");

            object missingValue = Type.Missing;

            ((Microsoft.Office.Interop.Word._Document)aDoc).Close(ref saveChanges, ref originalFormat, ref routeDocument);
            ((Microsoft.Office.Interop.Word._Application)wordApp.Application).Quit(ref missingValue, ref missingValue, ref missingValue);

           lblSummary.Text = lblSummary.Text + " - " + " Step-6 Success";
        }
        catch (Exception ex)
        {
           lblSummary.Text = lblSummary.Text + " - " + "Source File is Not exist-2";
            //throw ex;           
        }
        finally
        {
            if (aDoc != null)
                System.Runtime.InteropServices.Marshal.ReleaseComObject(aDoc);

            if (wordApp != null)
                System.Runtime.InteropServices.Marshal.ReleaseComObject(wordApp);

            wordApp = null;
            aDoc = null;
            GC.Collect();
            GC.WaitForPendingFinalizers();
        }
    }
    public void EndProcess()
    {
        System.Diagnostics.Process[] p = System.Diagnostics.Process.GetProcesses();
        for (int l = 0; l < p.Length; l++)
        {
            if (p[l].ProcessName.ToLower() == "winword")
            {
                p[l].Kill();
            }
        }
    }
    private void CreateWordDoc(Object fileName, object saveAs)
    {
        // Commitment No.  Submission No. :  Consultant Name :  Checked by:   Date  : 

        object missing = System.Reflection.Missing.Value;
        Microsoft.Office.Interop.Word.Application wordApp = new Microsoft.Office.Interop.Word.ApplicationClass();
        Microsoft.Office.Interop.Word.Document aDoc = null;

        if (File.Exists((string)fileName))
        {
            object readOnly = false; object isVisible = false; wordApp.Visible = false;
            aDoc = wordApp.Documents.Open(ref fileName, ref missing, ref readOnly, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref isVisible, ref missing, ref missing, ref missing, ref missing);
            aDoc.Activate();

            if (aDoc.Bookmarks.Exists("txtContractor"))
            {
                Microsoft.Office.Interop.Word.Bookmark bm = aDoc.Bookmarks["txtContractor"];
                Microsoft.Office.Interop.Word.Range range = bm.Range.Duplicate;
                aDoc.FormFields["txtContractor"].Result = lblCntr.Text;
            }
            if (aDoc.Bookmarks.Exists("txtContractNo"))
            {
                Microsoft.Office.Interop.Word.Bookmark bm = aDoc.Bookmarks["txtContractNo"];
                Microsoft.Office.Interop.Word.Range range = bm.Range.Duplicate;
                aDoc.FormFields["txtContractNo"].Result = lblCommitmentNo.Text;
            }
        }


        // aDoc.SaveAs2(ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing); 
        // aDoc.SaveAs(ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing); 
        // aDoc.Close(ref missing, ref missing, ref missing);


        Object fileNameNew = (Object)saveAs;
        Object fileformat = Microsoft.Office.Interop.Word.WdSaveFormat.wdFormatDocument;
        Object SaveChange = Microsoft.Office.Interop.Word.WdSaveOptions.wdDoNotSaveChanges;
        Object OrianalForamt = Microsoft.Office.Interop.Word.WdOriginalFormat.wdOriginalDocumentFormat;

        aDoc.Activate();



        aDoc.SaveAs2(ref fileNameNew, ref fileformat, ref missing, ref missing, ref missing, ref missing,
                  ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing);

        aDoc.Saved = true;
        //  aDoc.Close(ref SaveChange, ref missing, ref missing);

        //  aDoc.Quit(ref SaveChange, ref OrianalForamt, ref missing);
    }

    private void createDocForDC(string SavePath)
    {
        object oMissing = System.Reflection.Missing.Value;
        object oEndOfDoc = "\\endofdoc";

        object missing = System.Reflection.Missing.Value;

        object confirmConversions = Type.Missing;
        object readOnly = Type.Missing;
        object addToRecentFiles = Type.Missing;
        object passwordDoc = Type.Missing;
        object passwordTemplate = Type.Missing;
        object revert = Type.Missing;
        object writepwdoc = Type.Missing;
        object writepwTemplate = Type.Missing;
        object format = Type.Missing;
        object encoding = Type.Missing;
        object visible = Type.Missing;
        object openRepair = Type.Missing;
        object docDirection = Type.Missing;
        object notEncoding = Type.Missing;
        object xmlTransform = Type.Missing;

        Microsoft.Office.Interop.Word._Application oWord;
        Microsoft.Office.Interop.Word._Document oDoc;
        oWord = new Microsoft.Office.Interop.Word.Application();
        oWord.Visible = true;

        Object fileName = (Object)SavePath;
        Object fileformat = Microsoft.Office.Interop.Word.WdSaveFormat.wdFormatPDF;
        Object SaveChange = Microsoft.Office.Interop.Word.WdSaveOptions.wdDoNotSaveChanges;
        Object OrianalForamt = Microsoft.Office.Interop.Word.WdOriginalFormat.wdOriginalDocumentFormat;

        oDoc = oWord.Documents.Open(ref fileName, ref confirmConversions, ref readOnly, ref addToRecentFiles,
            ref passwordDoc, ref passwordTemplate, ref revert, ref writepwdoc, ref writepwTemplate, ref format, ref encoding, ref visible, ref openRepair,
            ref docDirection, ref notEncoding, ref xmlTransform);

        oDoc.Activate();

        if (oDoc.Bookmarks.Exists("txtContractor"))
        {
            Microsoft.Office.Interop.Word.Bookmark bm = oDoc.Bookmarks["txtContractor"];
            Microsoft.Office.Interop.Word.Range range = bm.Range.Duplicate;
            oDoc.FormFields["txtContractor"].Result = lblCntr.Text;
        }
        if (oDoc.Bookmarks.Exists("txtContractNo"))
        {
            Microsoft.Office.Interop.Word.Bookmark bm = oDoc.Bookmarks["txtContractNo"];
            Microsoft.Office.Interop.Word.Range range = bm.Range.Duplicate;
            oDoc.FormFields["txtContractNo"].Result = lblCommitmentNo.Text;
        }

        oDoc.Saved = true;

        oDoc.SaveAs(ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing);


        //oDoc.Close(ref SaveChange, ref oMissing, ref oMissing);
        // oWord.Quit(ref SaveChange, ref OrianalForamt, ref oMissing);

    }

    private void button1_Click(object sender, EventArgs e)
    {
        object fileName = "";
        string filePath = "";
        string strSaveasPath = "";

        List<string> _list = new List<string>();
        _list.Add("tridip");
        _list.Add("arijit");


        object textToFind = "test";
        object readOnly = false;
        Microsoft.Office.Interop.Word._Application word = new Microsoft.Office.Interop.Word.Application();
        Microsoft.Office.Interop.Word.Document doc = new Microsoft.Office.Interop.Word.Document();
        object missing = Type.Missing;
        try
        {
            doc = word.Documents.Open(ref fileName, ref missing, ref readOnly, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing);
            doc.Activate();

            object matchPhrase = false;
            object matchCase = false;
            object matchPrefix = false;
            object matchSuffix = false;
            object matchWholeWord = false;
            object matchWildcards = false;
            object matchSoundsLike = false;
            object matchAllWordForms = false;
            object matchByte = false;
            object ignoreSpace = false;
            object ignorePunct = false;

            object highlightedColor = Microsoft.Office.Interop.Word.WdColor.wdColorGreen;
            object textColor = Microsoft.Office.Interop.Word.WdColor.wdColorLightOrange;

            object missingp = false;
            Microsoft.Office.Interop.Word.Range range = doc.Range();

            foreach (string line in _list)
            {
                textToFind = line;
                bool highlighted = range.Find.HitHighlight(ref textToFind, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing);
            }

            System.Diagnostics.Process.Start(fileName.ToString());
        }
        catch (Exception ex)
        {
            Console.WriteLine("Error : " + ex.Message);
            //Console.ReadKey(true);
        }
        finally
        {
            //doc.Close(missing, missing, missing);
            if (doc != null)
                System.Runtime.InteropServices.Marshal.ReleaseComObject(doc);

            if (word != null)
                System.Runtime.InteropServices.Marshal.ReleaseComObject(word);

            word = null;
            doc = null;
            GC.Collect();
            GC.WaitForPendingFinalizers();
        }
    }
    protected void btnSearchJob_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/DCLog/SearchDCLog.aspx", false);
    }
    protected void btnBack_Click(object sender, EventArgs e)
    {
        //string strUpdateJob = Request.Url.AbsoluteUri;
        //Session["UrlRef"] = strUpdateJob;


        if (Session["UrlRef"] != null)
            Response.Redirect(Session["UrlRef"].ToString(), false);
        else
            Response.Redirect("~/DCLog/SearchDCLog.aspx", false);

        
    }
   
}