﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

using System.Data.SqlClient;
using System.Drawing;
public partial class DCLog_DcRejectionCauses : System.Web.UI.Page
{
    string connValue = System.Configuration.ConfigurationManager.ConnectionStrings["EBSDEBookConn"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
    {        
        if (!Page.IsPostBack)
        {
            SqlConnection con = new SqlConnection(connValue);
            string sqlQueryRej = "SELECT DcRejectionCauses.dcRejectionID, DcRejectionCauses.rejectionDesc,DCJobRejection.jobID FROM DcRejectionCauses INNER JOIN  DCJobRejection ON DcRejectionCauses.dcRejectionID = DCJobRejection.dcRejectionCauseID WHERE (DCJobRejection.jobID = 16558)";
            SqlDataAdapter da = new SqlDataAdapter(sqlQueryRej, con);
            DataSet ds123 = new DataSet();
            da.Fill(ds123, "FillComent");
            ListView123.DataSource = ds123.Tables["FillComent"];
            ListView123.DataBind();

            //var table = new DataTable();
            //table.Columns.Add("id");
            //table.Columns.Add("rejectionDesc");

            //table.Rows.Add("1", "Item 1");
            //table.Rows.Add("2", "Item 2");
            //table.Rows.Add("3", "Item 3");

            string sqlQuery = "SELECT dcRejectionID,rejectionDesc FROM DcRejectionCauses  WHERE (rejIsActive = 1)";
            SqlConnection con2 = new SqlConnection(connValue);
            SqlDataAdapter da2 = new SqlDataAdapter(sqlQuery, con2);
            DataSet ds = new DataSet();
            da2.Fill(ds, "DcRejection");            

            ListView2.DataSource = ds.Tables["DcRejection"];
            ListView2.DataBind();

           // var r = ListView2.Items.Cast<ListItem>().Where(i => i.Selected).Select(i => i.Value);
           // ListView2.Items.Cast<ListItem>().Where(i => i.Selected).Select(i => i.Value);
        }
    }
    protected void GetChecked(object sender, EventArgs e)
    {
        var items = ListView2.Items.Where(i => ((CheckBox)i.FindControl("Checkbox")).Checked);
        IList<string> strColl = new List<string>();
        foreach (ListViewItem item in items)
        {
            Label IdLabel = item.FindControl("IdLabel") as Label;
            Label NameLabel = item.FindControl("NameLabel") as Label;

            if (IdLabel != null && NameLabel != null)
            {
                string id = IdLabel.Text;
                string name = NameLabel.Text;

                InsertData(Convert.ToInt16(id), 100);
            }
        }
    }


    private void InsertData(int rejID,int _jobID)
    {
        string sqlQuery = "INSERT INTO DCREJECTIONCAUSES(dcRejID,dcJobID) VALUES(" + rejID + ",'" + _jobID + "')";
        using (SqlConnection con = new SqlConnection(connValue))
        {
            con.Open();

            using (SqlCommand cmd = new SqlCommand())
            {
                cmd.Connection = con;
                cmd.CommandText = sqlQuery;
                cmd.ExecuteNonQuery();
            }
        }
    }
   
}