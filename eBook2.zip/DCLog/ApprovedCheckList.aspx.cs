﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

public partial class DCLog_ApprovedCheckList : System.Web.UI.Page
{
 
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["UserName"] == null)
        {
            Response.Redirect("~/LoginPage.aspx", false);
            return;
        }

        string dateOfDoc = string.Empty;
        if (Session["DocIssueDate"] != null)
            dateOfDoc = Session["DocIssueDate"].ToString();
        else
            dateOfDoc = " -  - - ";
       

        if (Session["ChkTYpe"].ToString().Equals("1"))
        {
            TextBox1.Text = "SUBJECT:   " + Session["CntrNo"].ToString() + " - DC Clearance Certificate  " + Environment.NewLine + "  " + Environment.NewLine +               
                  " PROJECT: " + Session["PrjTitle"].ToString() + " " + Environment.NewLine + "  " + Environment.NewLine + 
                     " With reference to your letter ref. no. " + Session["refNo"].ToString() + "  dated " + dateOfDoc + "," + Environment.NewLine +
              " we are pleased to inform you that the requirements for the issuance of the DC clearance certificate for the above mentioned project have been found complete." + Environment.NewLine + "  " + Environment.NewLine + " " + Environment.NewLine +              
              " Therefore,  the Clearance Certificate has been issued and copy of the original is attached herewith " + Environment.NewLine + "  " + Environment.NewLine + " " + Environment.NewLine +
              " With Regards,"; 
   
             // Session["UserName"].ToString(); 
        }
        else
        {
            TextBox1.Text = "SUBJECT:   " + Session["CntrNo"].ToString() + " DC Clearance Certificate     " + Environment.NewLine + "  " + Environment.NewLine +
                " PROJECT:  " + Session["PrjTitle"].ToString() + " " + Environment.NewLine + "  " + Environment.NewLine + 
                           " With reference to your letter ref. no. " + Session["refNo"].ToString() + " dated " + dateOfDoc + ", regarding the request for DC clearance certificate of the above-mentioned project, please be informed that your submission has been reviewed and kindly find attached with this letter the status of the checklist items with our remarks. " + Environment.NewLine +
                                       " Kindly complete the pending items at your earliest." + Environment.NewLine + "  " + Environment.NewLine + " " + Environment.NewLine + 
                                      " With Regards,";
           // Session["UserName"].ToString();

        }      

       // TextBox1.Text.Replace(",", Environment.NewLine);
    }
   
}