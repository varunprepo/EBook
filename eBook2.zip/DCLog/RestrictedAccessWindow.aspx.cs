﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Datalayer;


using System.Threading;
using System.Configuration;
using System.Web.UI.HtmlControls;
using System.Net.Mail;
using System.Net;

using System.Net.Security;
using System.Security.Cryptography.X509Certificates;

using Microsoft.Office.Interop.Word;
using System.IO;
using System.Diagnostics;
using System.Data.SqlClient;
public partial class DCLog_RestrictedAccessWindow : System.Web.UI.Page
{
    string connValue = System.Configuration.ConfigurationManager.ConnectionStrings["EBSDEBookConn"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["UserName"] == null)
        {
            Response.Redirect("~/LoginPage.aspx", false);
            return;
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        // new JobOrderData().UpdateDocumentStatusForActionDate(Convert.ToInt32(Session["statusdocID"].ToString()), 4, Convert.ToInt32(Session["contactID"].ToString()));

        new JobOrderData().UpdateDocumentStatusForInchargeStatusCompleted(4, Convert.ToInt32(Session["_InchargeID"]));

        //new JobOrderData().UpdateJobStatus(Convert.ToInt32(Session["_InchargeID"]), Convert.ToInt32(Session["StatusValCurrent"].ToString()));

        //string _staffName = string.Empty; string _userName = string.Empty;
        //string eMail = getMailAddress(Convert.ToInt32(Session["_InchargeID"]), ref _staffName,ref _userName);
        //OutLookAlert(eMail, "", _staffName, _userName);

        Session["contactID"] = null; Session["statusdocID"] = null; Session["_InchargeID"] = null;

        string script = "this.window.opener.location=this.window.opener.location;this.window.close();";
        if (!ClientScript.IsClientScriptBlockRegistered("REFRESH_PARENT"))
            ClientScript.RegisterClientScriptBlock(typeof(string), "REFRESH_PARENT", script, true);
    }
    protected void btnNo_Click(object sender, EventArgs e)
    {
        // new JobOrderData().UpdateJobStatus(Convert.ToInt32(Session["_InchargeID"]), Convert.ToInt32(Session["StatusValCurrent"]));

        Session["StatusValCurrent"] = null; Session["_InchargeID"] = null;
        string script = "this.window.opener.location=this.window.opener.location;this.window.close();";
        if (!ClientScript.IsClientScriptBlockRegistered("REFRESH_PARENT"))
            ClientScript.RegisterClientScriptBlock(typeof(string), "REFRESH_PARENT", script, true);
    }
    private string getMailAddress(int _inchargeID, ref string staffName, ref string userName)
    {
        string _eMail = string.Empty;
        SqlConnection cnn = new SqlConnection(connValue);
        cnn.Open();
        SqlCommand cmm = new SqlCommand();
        cmm.Connection = cnn;
        cmm.CommandText = "SELECT  Contact.firstName, Contact_1.emailAddress,Contact_1.firstName as UserName  FROM JobOwner INNER JOIN    Contact ON JobOwner.contactID = Contact.contactID INNER JOIN  Contact AS Contact_1 ON JobOwner.distributedBy = Contact_1.contactID WHERE   (JobOwner.jobOwnerID = " + _inchargeID + ")"; //open n Follwup
        SqlDataReader sqlDtReader = cmm.ExecuteReader();
        if (sqlDtReader.HasRows)
        {
            while (sqlDtReader.Read())
            {
                _eMail = sqlDtReader["emailAddress"].ToString();
                staffName = sqlDtReader["firstName"].ToString();
                userName = sqlDtReader["UserName"].ToString();
            }
        }
        sqlDtReader.Close();
        cnn.Close();
        return _eMail;
    }
    private void OutLookAlert(string eMail, string mailBody, string _staffName, string _userName)
    {
        string jobNo = "";
        SmtpClient smtpclient = new SmtpClient("10.250.50.201", 587);
        System.Net.Mail.MailMessage mail = new System.Net.Mail.MailMessage();
        MailAddress fromaddress = new MailAddress("EBSD@ashghal.gov.qa");
        mail.From = fromaddress;
        mail.To.Add(eMail);
        mail.Subject = ("eBook Job No. " + jobNo);
        mail.IsBodyHtml = true;

        mail.Body = "<html><body><i style='font-family:Calibri; font-size:15'>Dear " + _userName + " ,</i><br/><br/><i style='font-family:Calibri; font-size:15'>This is an automated alert from Document & Task Management System.</i><br/><br/><i style='font-family:Calibri;font-size:15'>" +
                           "Please be noted that</i><i style='color:Maroon;font-family:Calibri; font-size:15'> Job No. " + Session["jobNo"].ToString() + "</i><i style='font-family:Calibri; font-size:15'> was completed by " + _staffName + " . Please log in to eBook on the following link:-</i><br /><br />" +
                           "<table style='width:80%' border='1'><tr><td align='center' colspan='2' style='background-color:Maroon;color:White;font-family:Calibri;font-size:18;font-weight:bold'>JOB NO: " + Session["jobNo"].ToString() + "</td>" +
                           "</tr><tr><td style='background-color:#B58AA5;font-family:Calibri;font-size:15'><i>Contract No / Project Code </i></td><td style='font-family:Calibri;font-size:15'>" + Session["contractNo"].ToString() + "</td></tr>" +
                           "<tr><td style='background-color:#B58AA5;font-family:Calibri;font-size:15'><i>eBook URL</i></td><td style='font-family:Calibri;font-size:15'>   http://mv2ebdbookp01/eBook/LoginPage.aspx   </td></tr>" +
                           "<tr><td style='background-color:#B58AA5;font-family:Calibri;font-size:15'><i>Date of Creation</i></td><td style='font-family:Calibri;font-size:15'>" + System.DateTime.Now + "</td></tr>" +
                           "</table><br/><br/><div style='font-family:Calibri; font-size:15'>Best Regards,<br/>eBook Team</div></body></html>";


        smtpclient.EnableSsl = true;
        smtpclient.UseDefaultCredentials = true;

        try
        {
            smtpclient.Credentials = new System.Net.NetworkCredential(@"Ashghal\EBSD", ConfigurationManager.AppSettings["passWordForReport"].ToString()); 
            ServicePointManager.ServerCertificateValidationCallback = delegate(object s, X509Certificate certificate, X509Chain chain, SslPolicyErrors sslPolicyErrors) { return true; };
            smtpclient.Send(mail);
        }
        catch (System.Exception ex)
        {
            Console.WriteLine(ex);
            if (ex.InnerException != null)
            {
                Console.WriteLine("InnerException is: {0}", ex.InnerException);
            }
        }
        finally
        {
            mail.Dispose();
            mail = null;
            smtpclient = null;
        }
    }
   
}