﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

public partial class DCLog_RestrictedMsgWindow : System.Web.UI.Page
{
    string connValue = System.Configuration.ConfigurationManager.ConnectionStrings["EBSDEBookConn"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["UserName"] == null)
        {
            Response.Redirect("~/LoginPage.aspx", false);
            return;
        }

        if (Session["lblText"]!=null)
           lblText.Text = Session["lblText"].ToString();      
    }
    protected void btnConfirm_Click(object sender, EventArgs e)
    {
        //RestrictedMsgWindow.aspx

         //getAdminData();

    }
    private void getAdminData()
    {
        SqlConnection sqlConn = new SqlConnection(connValue);
        string sqlQuery = "Select emailAddress from Contact where UserProfileID = 1";

        try
        {
            sqlConn.Open();
            SqlCommand sqlCom = new SqlCommand(sqlQuery, sqlConn);
            SqlDataReader sqlReader = sqlCom.ExecuteReader();
            while (sqlReader.Read())
            {
                string emailAdr = sqlReader["emailAddress"].ToString();

                // Restricted Access to Add New Job Order

                // This is in reference to Restricted Access to Add New Job Order. I would like to inquire about the restriction.

                Microsoft.Office.Interop.Outlook.Application oApp = new Microsoft.Office.Interop.Outlook.Application();
                Microsoft.Office.Interop.Outlook._MailItem oMailItem = (Microsoft.Office.Interop.Outlook._MailItem)oApp.CreateItem(Microsoft.Office.Interop.Outlook.OlItemType.olMailItem);
                oMailItem.To = emailAdr;
                oMailItem.Subject = Session["lblSub"].ToString();

                oMailItem.Body = Session["lblBody"].ToString();

                oMailItem.Display(true);

            }
            sqlReader.Close();
        }
        catch (Exception ex)
        {
            Response.Write("Error getting while reading data !" + ex.Message);
        }
        finally
        {
            sqlConn.Close();
        }
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        this.ClientScript.RegisterClientScriptBlock(this.GetType(), "Close", "window.close()", true);
    }
}