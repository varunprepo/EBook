﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using Datalayer;
using System.Threading;
using System.Globalization;
using System.Configuration;
using System.Web.UI.HtmlControls;
using System.Net.Mail;
using System.Net;

using System.Net.Security;
using System.Security.Cryptography.X509Certificates;
using System.Net;
using Microsoft.Office.Interop.Word;
using System.IO;
using System.Diagnostics;


public partial class DCLog_DCDetails : System.Web.UI.Page
{
    string connValue = System.Configuration.ConfigurationManager.ConnectionStrings["EBSDEBookConn"].ConnectionString;
    string _jobNo = string.Empty;
    int _jobID = 0;
    IList<string> userRightsColl = new List<string>();
    string profile_Name = string.Empty;
    int _tabType = 0;

    protected void Page_Init(object sender, EventArgs e)
    {
        if (Session["UserName"] == null)
        {
            Response.Redirect("~/LoginPage.aspx", false);
            return;
        }

        if (_jobID == 0)
            _jobID = Convert.ToInt32(Request.QueryString["JobID"]);

        Session["StaffJobID"] = Convert.ToInt32(Request.QueryString["JobID"]);

        _tabType = Convert.ToInt32(Request.QueryString["tabType"]);

        gvJoborder.DataSource = new JobOrderData().GetJobOwnerDetails(_jobID);
        gvJoborder.DataBind();

      //  gvJoborder.Rows[0].Cells[8].Enabled = false;

        Session["DocRecDate"] = getDocReceivedDate(_jobID);

        tdRej.Visible = false;
        ddlReject.Visible = false;          

        // tblRowVO.Visible = false;       
    }
    protected void Page_Load(object sender, EventArgs e)
    {
        userRightsColl = (IList<string>)Session["UserRightsColl"];
        Label2.Text = "UserColl Count " + userRightsColl.Count.ToString();

        Session["PayID"] = null;          //  killing session becuease of link document button when user action on updatepay[PaymentDetails.aspx]/ updatejob[DefaultGrid.aspx] 

        if (IsPostBack == false)
        {
            Session["Upd_jobID"] = _jobID;

            LoadDrpData();

            // PopulateDropDownBox(ddlCntrType, "SELECT contractTypeID, contractTypeName FROM  ContractType Order by contractTypeName ", "contractTypeID", "contractTypeName");
                      
            // userRightsColl = new JobOrderData().GetUserAccessList(Convert.ToInt32(Session["userID"]));

            //  fillDocumentStatus(_jobID);

            // If access No 6 of the current user is False then Disable the Grade and Job Status

            if (!userRightsColl.Contains("6"))
            {
                ddlGrade.Enabled = true;
                txtDueDate.Enabled = true;
                txtWorkDays.Enabled = true;

                ddlJobStatus.Enabled = true;
            }
            else
            {
                ddlGrade.Enabled = false;
                txtDueDate.Enabled = false;
                txtWorkDays.Enabled = false;

                ddlJobStatus.Enabled = false;
            }

            if (_tabType == 3)            
                ddlVendor.Enabled = false;           
            else          
               //txtAddendum.Enabled = false;                
          

            Fill_JobOrder_Information(_jobID);

            gridReceived.DataSource = new JobOrderData().getJobDocumetReceivedDate(_jobID);
            gridReceived.DataBind();

            gridSent.DataSource = new JobOrderData().getJobDocumetSentDate(_jobID);
            gridSent.DataBind();

            int catID = Convert.ToInt32(Session["jobCatID"]);
            string typeID = Session["jobTypeID"].ToString();

            PopulateDropDownBox_JobType(ddlJobType, "SELECT jobTypeID, jobTypeName FROM JobType Where CategoryID = " + catID + " and jobTypeID<>CategoryID ORDER BY jobTypeName", "jobTypeID", "jobTypeName");         //and jobTypeID<>CategoryID

            if ((typeID != "") & (catID.ToString() != ddlJobType.SelectedItem.Value))
                ddlJobType.SelectedItem.Value = typeID;
            else
                ddlJobType.SelectedIndex = 0;

            Session["prjCode"] = txtPrjCode.Text;
            Session["JobNo"] = txtJobNo.Text;

            getPrjCodeAndCntrNO(txtCntrNo.Text, txtPrjCode.Text,ddlCntrType.SelectedValue);

            Session["old_ReqStatusID"] = ddlReqType.SelectedValue;

            //Session["JobCatID"] = ((HtmlGenericControl)gvr.FindControl("divJobCatID")).InnerText;
            //UpdateJobOwner(Convert.ToInt32(lnkJobID.ToolTip));          
            // For Update DateRead

            int _inchargeID = 0;
            if (_jobID != 0)
            {
                if (checkUserExistDateRead(ref _inchargeID, _jobID))
                    new JobOrderData().UpdateJobInchargeDateRead(_inchargeID, Convert.ToInt32(Session["UserID"]));
            }

            GetSurveyRequestNo(202);
        }

        //if (ddlCntrType.SelectedIndex == 0)
        //   btnCheckListDC.Enabled = false;
        //else
        //   btnCheckListDC.Enabled = true;
        
    }
    private void LoadDrpData()
    {
        PopulateDropDownBox(ddlDept, "SELECT departmentID, deptName FROM  Department  where affairID is not null ORDER BY deptName ", "departmentID", "deptName");

        PopulateDropDownBox(ddlJobType, "SELECT jobTypeID, jobTypeName FROM JobType ORDER BY jobTypeName", "jobTypeID", "jobTypeName");            //Where jobTypeID not in(1,2,3,4,5,6,7,8)        

        PopulateDropDownBox_TCMS(ddlVendor, "SELECT co_id, co_name FROM Company ORDER BY co_name", "co_id", "co_name");

        PopulateDropDownBox_TCMS(ddlConsultantNo, "SELECT co_id, co_name FROM Company ORDER BY co_name", "co_id", "co_name");

        PopulateDropDownBox(ddlJobStatus, "SELECT JobStatusID, JobStatusName FROM JobStatus Where JobStatusID in(1,2,3,5,6,7) ORDER BY JobStatusName", "JobStatusID", "JobStatusName");   //4, Ongoing and Pending

        PopulateDropDownBox(ddlQS, "Select contactID,UserShortName From Contact  order by firstName", "contactID", "UserShortName");        // added where sectionID = 3

        PopulateDropDownBox(ddlReqType, "Select contactID,UserShortName From Contact order by firstName", "contactID", "UserShortName");

        // PopulateDropDownBox(ddlPE, "Select contactID,UserShortName From Contact order by firstName", "contactID", "UserShortName");

        // PopulateDropDownBox(ddlCntrType, "SELECT contractTypeID, contractTypeName FROM  ContractType Order by contractTypeName ", "contractTypeID", "contractTypeName");

        PopulateDropDownBox(ddlPrjCoordinator, "Select prjCoordID,CoordName From ProjCoordinator order by CoordName", "prjCoordID", "CoordName");

        PopulateDropDownBox(ddlReqType, "SELECT reqStatusID, reqStatusName FROM  DCRequestStatus  ", "reqStatusID", "reqStatusName"); // Order by reqStatusName

        PopulateDropDownBox(ddlCntrType, "SELECT contractTypeID, tcms_CntrName FROM  ContractType Order by tcms_CntrName ", "contractTypeID", "tcms_CntrName");

        PopulateDropDownBox(ddlGrade, "SELECT jobPriorityID, jobPriorityName FROM JobPriority ORDER BY jobPriorityID", "jobPriorityID", "jobPriorityName");
    }
    private Boolean checkUserExistDateRead(ref int _disribID, int jobID)
    {
        string prjTitle = string.Empty;

        using (SqlConnection cnn = new SqlConnection(connValue))
        {
            cnn.Open();
            using (SqlCommand cmm = new SqlCommand())
            {
                cmm.Connection = cnn;
                cmm.CommandText = "SELECT contactID,JobOwnerID  FROM Jobowner WHERE dateread is null and JobID = " + jobID + " and  contactID  = " + Convert.ToInt32(Session["UserID"]) + " ";
                using (SqlDataReader sqlDtReader = cmm.ExecuteReader())
                {
                    if (sqlDtReader.HasRows)
                    {
                        while (sqlDtReader.Read())
                        {
                            _disribID = Convert.ToInt32(sqlDtReader["JobOwnerID"].ToString());
                            return true;
                        }
                    }
                }
            }
        }
        return false;
    }  

    private string getDocReceivedDate(int JobID)
    {
        string docRecDate = string.Empty;
        SqlConnection sqlConn = new SqlConnection(connValue);
        string sqlQuery = "SELECT JobReceivedDate from Job where JobID =" + JobID + "";

        try
        {
            sqlConn.Open();
            SqlCommand sqlCom = new SqlCommand(sqlQuery, sqlConn);
            SqlDataReader sqlReader = sqlCom.ExecuteReader();
            while (sqlReader.Read())
            {
                docRecDate = sqlReader[0].ToString();
               
            }
            sqlReader.Close();
        }
        catch (Exception ex)
        {
            // Response.Write("Error getting while reading data !" + ex.Message);
        }
        finally
        {
            sqlConn.Close();
        }
        return docRecDate;
    }
    private void WorkingDaysCaluclationByGrade(string gradeValue, string endDate)
    {
        //string endDate = string.Empty;
        switch (gradeValue)
        {
            case "1":
                txtWorkDays.Text = "5"; // Working Days
                endDate = new JobOrderData().getEndDateByGivenDays(5);
                txtDueDate.Text = Convert.ToDateTime(endDate).ToString("dd/MMM/yyyy");

                //txtDueDate.Text = System.DateTime.Now.AddDays(5).ToString("dd/MMM/yyyy");
                break;
            case "2":
                endDate = new JobOrderData().getEndDateByGivenDays(8);
                txtDueDate.Text = Convert.ToDateTime(endDate).ToString("dd/MMM/yyyy");
                txtWorkDays.Text = "7";
                break;

            case "3":
                endDate = new JobOrderData().getEndDateByGivenDays(10);
                txtDueDate.Text = Convert.ToDateTime(endDate).ToString("dd/MMM/yyyy");
                txtWorkDays.Text = "10";
                break;

            case "4":
                endDate = new JobOrderData().getEndDateByGivenDays(15);
                txtDueDate.Text = Convert.ToDateTime(endDate).ToString("dd/MMM/yyyy");
                txtWorkDays.Text = "15";
                break;                       

            default:
                break;
        }
    }    

    # region


    protected void QSlnkAddStaff_Click(object sender, EventArgs e)
    {
        if (Convert.ToInt32(ddlQS.SelectedIndex) != 0 && (!userRightsColl.Contains("4"))) // Access Right is 4 
        {
            Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Don't have the permission to Add QS')</script>", false);
            return;
        }
        else
        {
            string url = "AddStaff.aspx";
            string s = "window.open('" + url + "', 'popup_window', 'width=900,height=700,left=100,top=100,resizable=yes');";
            Page.ClientScript.RegisterStartupScript(this.GetType(), "script", s, true);
        }
    }    
    protected void CElnkAddStaff_Click(object sender, EventArgs e)
    {
        if (Convert.ToInt32(ddlReqType.SelectedIndex) != 0 && (!userRightsColl.Contains("4"))) // Access Right is 4 
        {
            Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Don't have the permission to Add CE ')</script>", false);
            return;
        }
        else
        {
            string url = "AddStaff.aspx";
            string s = "window.open('" + url + "', 'popup_window', 'width=900,height=700,left=100,top=100,resizable=yes');";
            ClientScript.RegisterStartupScript(this.GetType(), "script", s, true);
        }
    }
    protected void popup452_Click(object sender, EventArgs e)
    {
        if (Convert.ToInt32(ddlQS.SelectedIndex) == 0 && (Convert.ToInt32(Session["userID"]) == 1)) // Access Right is 4 
            Response.Write("<script language='javascript'> window.open('AddStaff.aspx','','width=846,Height=400,fullscreen=1,location=0,scrollbars=0,menubar=1,toolbar=1, align=center,top=100,left=500'); </script>");
    }

    private void PopulateDropDownBox_TCMS(DropDownList ddlBox, string sqlQuery, string valueMember, string displayName)
    {
        ddlBox.DataSource = new JobOrderData().FillDropdown_TCMS(sqlQuery);
        ddlBox.DataTextField = displayName;
        ddlBox.DataValueField = valueMember;
        ddlBox.SelectedIndex = -1;
        ddlBox.DataBind();
        ddlBox.Items.Insert(0, new ListItem("--Select--"));
    }
    public void Fill_JobOrder_Information(int _jobID)
    {
        try
        {
            SqlConnection sqlConn = new SqlConnection(connValue);
            sqlConn.Open();
           
            //string strValue = "SELECT Job.jobNo, Job.jobTypeID, Job.jobPriorityID, Job.jobStatusID, Job.remarks AS Instruction, Job.deptID, Job.contractNo, Job.qsID, Job.ceID, Job.peID, Job.dcID, Job.contractTypeID AS Contract_Type_id, Job.projectTitle, Job.remarks, Job.contractorID, Job.consultantID, Job.jobID, Job.addendumNO, Job.jobTypeID AS Expr1, " +
            //            " Job.jobDesc, Job.docRefID, Job.workDays, Job.jobDueDate, Job.jobReceivedDate, Job.jobStatusClosedDate, Job.jobClosedDate, Job.docRefID AS Expr2,   JobType.CategoryID AS JobCatID, Job.projectCode, Job.committmentNo, Job.attRcvdDateDC, Job.reviewDateDC, Job.sentToSurveyTeamDC, Job.receivedBySurveyTeamDC, " +
            //            " Job.reqStatusID, Job.submissionNoDC, Job.projCoordinatorID, ProjCoordinator.CoordName,Job.dcRejectionID, Job.closedDocRefID,job.jobPriorityID FROM   Job INNER JOIN  JobType ON Job.jobTypeID = JobType.jobTypeID LEFT OUTER JOIN   ProjCoordinator ON Job.projCoordinatorID = ProjCoordinator.prjCoordID  WHERE  (Job.jobID = " + _jobID + ")";



           // SqlCommand sqlCom = new SqlCommand(strValue, sqlConn);
            
            SqlCommand sqlCom = new SqlCommand();
            sqlCom.Connection = sqlConn;
            sqlCom.CommandType = CommandType.StoredProcedure;
            sqlCom.CommandText = "dcu_GetDcLogInfo";
            sqlCom.Parameters.AddWithValue("@JobID", _jobID);

            SqlDataReader sqlReader = sqlCom.ExecuteReader();

            while (sqlReader.Read())
            {
                txtJobNo.Text = sqlReader["JobNo"].ToString();

              //  ddlJobCat.SelectedValue = sqlReader["jobCatID"].ToString();

                if (!sqlReader["jobCatID"].ToString().Equals(sqlReader["jobTypeID"].ToString()))
                {
                    //if (!sqlReader["jobTypeID"].ToString().Equals(4) || !sqlReader["jobTypeID"].ToString().Equals(5) || !sqlReader["jobTypeID"].ToString().Equals(6))
                    {
                        ddlJobType.SelectedValue = sqlReader["jobTypeID"].ToString();
                        Session["jobTypeID"] = sqlReader["jobTypeID"].ToString();
                    }
                }
                else
                {
                    Session["jobTypeID"] = "";
                }

                //ddlJobStatus.SelectedValue = sqlReader["jobStatusID"].ToString();


                ddlJobStatus.SelectedValue = sqlReader["jobStatusID"].ToString();

                if (sqlReader["closedDocRefID"].ToString() == "")
                    ddlJobStatus.Enabled = true;
                else if ((sqlReader["closedDocRefID"].ToString() == null))           
                    ddlJobStatus.Enabled = true;        
                else
                    ddlJobStatus.Enabled = false;               

                Session["jobCatID"] = sqlReader["jobCatID"].ToString();
                Session["jobTypeID"] = sqlReader["jobTypeID"].ToString();
                Session["JobStatusID"] = sqlReader["jobStatusID"].ToString();
                Session["opendocRefID"] = sqlReader["docRefID"].ToString();

                if (sqlReader["deptID"].ToString() != "")
                    ddlDept.SelectedValue = sqlReader["deptID"].ToString();

                if (sqlReader["dcID"].ToString() != "")
                    ddlQS.SelectedValue = sqlReader["dcID"].ToString();

                //if (sqlReader["peID"].ToString() != "")
                //    ddlPE.SelectedValue = sqlReader["peID"].ToString();

                //if (sqlReader["ceID"].ToString() != "")
                //    ddlReqType.SelectedValue = sqlReader["ceID"].ToString();

                txtPrjCode.Text = sqlReader["contractNo"].ToString();

                Session["contractNo"] = sqlReader["contractNo"].ToString();

                txtPrjTitle.Text = sqlReader["projectTitle"].ToString();

                txtRemarks.Text = sqlReader["remarks"].ToString();
                txtJobDesc.Text = sqlReader["jobDesc"].ToString();

                if (sqlReader["consultantID"].ToString() != "")
                    ddlConsultantNo.SelectedValue = sqlReader["consultantID"].ToString();

                if (sqlReader["Contract_Type_id"].ToString() != "")
                    ddlCntrType.SelectedValue = sqlReader["Contract_Type_id"].ToString();              


                if (sqlReader["contractorID"].ToString() != "")
                    ddlVendor.SelectedValue = sqlReader["contractorID"].ToString();

                if (sqlReader["jobPriorityID"].ToString() != "")
                    ddlGrade.SelectedValue = sqlReader["jobPriorityID"].ToString();

                Session["GradeVal"] = sqlReader["jobPriorityID"].ToString();

                // txtAddendum.Text = sqlReader["addendumNO"].ToString();

                Session["subdocID"] = sqlReader["docRefID"].ToString();

                txtWorkDays.Text = sqlReader["workDays"].ToString();
                txtDueDate.Text = Convert.ToDateTime(sqlReader["jobDueDate"]).ToString("dd/MMM/yyyy");

                if (sqlReader["jobReceivedDate"].ToString() != "")
                    txtReceivedDate.Text = Convert.ToDateTime(sqlReader["jobReceivedDate"]).ToString("dd/MMM/yyyy");
                else
                    txtReceivedDate.Text = "";

                if (sqlReader["jobStatusClosedDate"].ToString() != "")
                    txtStatusClose.Text = Convert.ToDateTime(sqlReader["jobStatusClosedDate"]).ToString("dd/MMM/yyyy");
                else
                    txtStatusClose.Text = "";

                if (sqlReader["jobClosedDate"].ToString() != "")
                    TextBox4.Text = Convert.ToDateTime(sqlReader["jobClosedDate"]).ToString("dd/MMM/yyyy");
                else
                    TextBox4.Text = "";

                txtSubmission.Text = sqlReader["submissionNoDC"].ToString();
                txtPrjCode.Text = sqlReader["projectCode"].ToString();
                txtCntrNo.Text =   sqlReader["committmentNo"].ToString();

                if (sqlReader["attRcvdDateDC"].ToString() != "")
                    txtAttRecDate.Text = Convert.ToDateTime(sqlReader["attRcvdDateDC"]).ToString("dd/MMM/yyyy");

                if (sqlReader["reviewDateDC"].ToString() != "")
                txtReviewDate.Text = Convert.ToDateTime(sqlReader["reviewDateDC"]).ToString("dd/MMM/yyyy");

                if (sqlReader["sentToSurveyTeamDC"].ToString() != "")
                {
                    txtSentOnSurvey.Text = Convert.ToDateTime(sqlReader["sentToSurveyTeamDC"]).ToString("dd/MMM/yyyy");
                    txtSurveyReply.Enabled = true;
                }
                else
                {
                    txtSentOnSurvey.Enabled = false;
                    txtSurveyReply.Enabled = false;
                }

                if (sqlReader["receivedBySurveyTeamDC"].ToString() != "")
                   txtSurveyReply.Text = Convert.ToDateTime(sqlReader["receivedBySurveyTeamDC"]).ToString("dd/MMM/yyyy");

                if (sqlReader["projCoordinatorID"].ToString() != "")
                    ddlPrjCoordinator.SelectedValue = sqlReader["projCoordinatorID"].ToString();

                if (sqlReader["reqStatusID"].ToString() != "")
                {
                    if (ddlReqType.DataSource!=null)
                      ddlReqType.SelectedValue = sqlReader["reqStatusID"].ToString();

                     if (sqlReader["reqStatusID"].ToString() == "2")
                     {
                         ddlReject.Visible = true;
                         lblDcRej.Visible = true;
                         tdRej.Visible = true;
                     }
                     else if ((sqlReader["reqStatusID"].ToString() == "4") || (sqlReader["reqStatusID"].ToString() == "5"))
                     {
                         // lnkDownload.Visible = true;
                         // lblReqName.Visible = true;
                     }
                     else
                     {
                         //lnkDownload.Visible = false;
                         //lblReqName.Visible = false;
                     }                                   
                }
                if (sqlReader["reqStatusID"].ToString() != "")
                {
                     if (sqlReader["reqStatusID"].ToString() == "2")
                     {
                         ddlReject.Visible = true;
                         lblDcRej.Visible = true;
                         tdRej.Visible = true;

                         if (ddlReject.DataSource == null)
                             PopulateDropDownBox(ddlReject, "SELECT dcRejectionID, rejectionDesc FROM  DCRejection ", "dcRejectionID", "rejectionDesc"); // Order by reqStatusName
                     }                     
                     else
                     {
                         //lnkDownload.Visible = false;
                         //lblReqName.Visible = false;
                     }

                     if (sqlReader["dcRejectionID"].ToString() != "")
                     {
                          if (sqlReader["dcRejectionID"].ToString()!= "0")
                             ddlReject.SelectedValue = sqlReader["dcRejectionID"].ToString();
                     }      
                }

                if (sqlReader["jobPriorityID"].ToString() != "")
                {
                    ddlGrade.SelectedValue = sqlReader["jobPriorityID"].ToString();
                } 
            }
            sqlReader.Close();
            sqlConn.Close();
        }
        catch (Exception ex)
        {
            throw ex;
        }

        //  WorkingDaysCaluclationByGrade(Session["GradeVal"].ToString());

        if (Session["subDocID"].ToString()!="")
           getDocuemnetSubject(Convert.ToInt32(Session["subdocID"]));

    }
    public string getDocuemnetSubject(int docID)
    {
        string strSubject = string.Empty;
        SqlConnection sqlConn = new SqlConnection(connValue);
        string sqlQuery = "SELECT docSubject,referenceNo from document where documentID =" + docID + "";

        try
        {
            sqlConn.Open();
            SqlCommand sqlCom = new SqlCommand(sqlQuery, sqlConn);
            SqlDataReader sqlReader = sqlCom.ExecuteReader();
            while (sqlReader.Read())
            {
                strSubject = sqlReader[0].ToString();

                Session["referenceNo"] = sqlReader["referenceNo"].ToString(); 
            }
            sqlReader.Close();
        }
        catch (Exception ex)
        {
            // Response.Write("Error getting while reading data !" + ex.Message);
        }
        finally
        {
            sqlConn.Close();
        }
        return strSubject;
    }



    private void PopulateDropDownBox(DropDownList ddlBox, string sqlQuery, string valueMember, string displayName)
    {
        System.Data.DataTable table = new System.Data.DataTable();

        try
        {
            using (SqlConnection sqlConn = new SqlConnection(connValue))
            {
                using (SqlDataAdapter da = new SqlDataAdapter(sqlQuery, sqlConn))
                {
                    sqlConn.Open();
                    da.Fill(table);
                }
            }
            //cmbBox.Items.Add("Select");
            ddlBox.DataSource = table;
            ddlBox.DataTextField = displayName;
            ddlBox.DataValueField = valueMember;
            ddlBox.SelectedIndex = -1;

            ddlBox.DataBind();
            ddlBox.Items.Insert(0, new ListItem("--Select--"));
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    private void PopulateDropDownBox_JobType(DropDownList ddlBox, string sqlQuery, string valueMember, string displayName)
    {
        System.Data.DataTable table = new System.Data.DataTable();
        try
        {
            using (SqlConnection sqlConn = new SqlConnection(connValue))
            {
                using (SqlDataAdapter da = new SqlDataAdapter(sqlQuery, sqlConn))
                {
                    sqlConn.Open();
                    da.Fill(table);
                }
            }

            //cmbBox.Items.Add("Select");

            ddlBox.DataSource = table;
            ddlBox.DataTextField = displayName;
            ddlBox.DataValueField = valueMember;

            // ddlBox.SelectedIndex = -1;

            ddlBox.DataBind();
            ddlBox.Items.Insert(0, new ListItem("--Select--"));
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    private void GetSurveyRequestNo(int SurveyID)
    {
        using (SqlConnection cnn = new SqlConnection(connValue))
        {
            cnn.Open();
            using (SqlCommand cmm = new SqlCommand())
            {
                cmm.Connection = cnn;
                cmm.CommandText = "SELECT JobNo FROM JobOwner WHERE jobID = " + _jobID +" and ContactID  = " + SurveyID + "";
                using (SqlDataReader sqlDtReader = cmm.ExecuteReader())
                {
                    if (sqlDtReader.HasRows)
                    {
                        while (sqlDtReader.Read())
                        {
                            lnkRequestNo.Text = sqlDtReader["JobNo"].ToString();
                        }
                    }
                    else
                      lnkRequestNo.Text = "";
                }
            }
        }       
    }
    public void UpdateJobOrder(int upd_JobID)
    {
        SqlConnection sqlCon = new SqlConnection(connValue);
        SqlCommand cmd = new SqlCommand();
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.CommandText = "dcu_UpdateDCLog";
        cmd.Connection = sqlCon;

        cmd.Parameters.AddWithValue("@Job_id", upd_JobID);

        if (ddlJobType.SelectedIndex != 0)
            cmd.Parameters.AddWithValue("@Job_Type_id", ddlJobType.SelectedValue);
        else
            cmd.Parameters.AddWithValue("@Job_Type_id", ddlJobType.SelectedValue);

        if (ddlJobStatus.SelectedIndex != 0)
            cmd.Parameters.AddWithValue("@Job_Status_id", ddlJobStatus.SelectedValue);
        else
            cmd.Parameters.AddWithValue("@Job_Status_id", System.DBNull.Value);

        cmd.Parameters.AddWithValue("@Project_Code", txtPrjCode.Text);

        cmd.Parameters.AddWithValue("@jobDesc", txtJobDesc.Text);
        cmd.Parameters.AddWithValue("@Project_Title", txtPrjTitle.Text);

        if (ddlVendor.SelectedIndex != 0)
            cmd.Parameters.AddWithValue("@ContractorID", ddlVendor.SelectedValue);
        else
            cmd.Parameters.AddWithValue("@ContractorID", System.DBNull.Value);

        if (ddlConsultantNo.SelectedIndex != 0)
            cmd.Parameters.AddWithValue("@ConsultantID", ddlConsultantNo.SelectedValue);
        else
            cmd.Parameters.AddWithValue("@ConsultantID", System.DBNull.Value);

        if (ddlDept.SelectedIndex != 0)
            cmd.Parameters.AddWithValue("@DepartmentID", ddlDept.SelectedValue);
        else
            cmd.Parameters.AddWithValue("@DepartmentID", System.DBNull.Value);

        //  cmd.Parameters.AddWithValue("@AffairID", Convert.ToInt32(Session["AffairID"]));

        if (ddlQS.SelectedIndex != 0)
            cmd.Parameters.AddWithValue("@QSID", ddlQS.SelectedValue);
        else
            cmd.Parameters.AddWithValue("@QSID", System.DBNull.Value);

        //if (ddlPE.SelectedIndex != 0)
        //    cmd.Parameters.AddWithValue("@PEID", ddlPE.SelectedValue);
        //else
        //    cmd.Parameters.AddWithValue("@PEID", System.DBNull.Value);

        cmd.Parameters.AddWithValue("@PEID", System.DBNull.Value);

        if (ddlReqType.SelectedIndex != 0)
            cmd.Parameters.AddWithValue("@CEID", ddlReqType.SelectedValue);
        else
            cmd.Parameters.AddWithValue("@CEID", System.DBNull.Value);

        if (ddlGrade.SelectedIndex != 0)
            cmd.Parameters.AddWithValue("@gradeID", ddlGrade.SelectedValue);
        else
            cmd.Parameters.AddWithValue("@gradeID", System.DBNull.Value);

        cmd.Parameters.AddWithValue("@remarks", txtRemarks.Text);

        cmd.Parameters.AddWithValue("@addendumNO", System.DBNull.Value);

        if (ddlCntrType.SelectedIndex != 0)
            cmd.Parameters.AddWithValue("@contractTypeID", ddlCntrType.SelectedValue);
        else
            cmd.Parameters.AddWithValue("@contractTypeID", System.DBNull.Value);

        cmd.Parameters.AddWithValue("@workDays", txtWorkDays.Text);
        cmd.Parameters.AddWithValue("@dueDate", Convert.ToDateTime(txtDueDate.Text).ToString("dd/MMM/yyyy"));

        cmd.Parameters.AddWithValue("@updateUser", Session["UserName"]);


        // For DC Log

         cmd.Parameters.AddWithValue("@submissionNo", txtSubmission.Text);    

         if (txtAttRecDate.Text != "")
            cmd.Parameters.AddWithValue("@attRecDate",  Convert.ToDateTime(txtAttRecDate.Text).ToString("dd/MMM/yyyy"));   
         else
           cmd.Parameters.AddWithValue("@attRecDate", System.DBNull.Value);

       //  cmd.Parameters.AddWithValue("@dcRejectionID", 1); // Temporary  // Sree


         if (ddlReject.SelectedIndex != 0)
             cmd.Parameters.AddWithValue("@dcRejectionID", ddlReject.SelectedValue);  // Srre 
         else
             cmd.Parameters.AddWithValue("@dcRejectionID", System.DBNull.Value);

        if (ddlReqType.SelectedIndex != 0)
           cmd.Parameters.AddWithValue("@projStstusID", ddlReqType.SelectedValue);  // Srre 
        else
            cmd.Parameters.AddWithValue("@projStstusID", System.DBNull.Value);

        if (txtSurveyReply.Text !="")
            cmd.Parameters.AddWithValue("@receivedSurveyTeamOn", Convert.ToDateTime(txtSurveyReply.Text).ToString("dd/MMM/yyyy"));  
        else
            cmd.Parameters.AddWithValue("@receivedSurveyTeamOn", System.DBNull.Value);

        if (txtSentOnSurvey.Text != "")
           cmd.Parameters.AddWithValue("@sentOnSurveyTeam", Convert.ToDateTime(txtSentOnSurvey.Text).ToString("dd/MMM/yyyy"));
        else
            cmd.Parameters.AddWithValue("@sentOnSurveyTeam", System.DBNull.Value);
        
        if (txtReviewDate.Text != "")
          cmd.Parameters.AddWithValue("@reviewDate", Convert.ToDateTime(txtReviewDate.Text).ToString("dd/MMM/yyyy"));
         else
            cmd.Parameters.AddWithValue("@reviewDate", System.DBNull.Value);

        cmd.Parameters.AddWithValue("@committmentNo", txtCntrNo.Text);

        cmd.Parameters.AddWithValue("@projectCode", txtPrjCode.Text);

        if (ddlPrjCoordinator.SelectedIndex != 0)
            cmd.Parameters.AddWithValue("@projCoordinatorID", ddlPrjCoordinator.SelectedValue);        // Sree
        else
            cmd.Parameters.AddWithValue("@projCoordinatorID", System.DBNull.Value);


        try
        {
            sqlCon.Open();
            cmd.ExecuteNonQuery();
            sqlCon.Close();
        }
        catch (Exception ex)
        {
            throw ex;
        }
        //lblResult.Text = "Data Updated Successfully";
        // Response.Write();
    }
    protected void btnUpdate_Click(object sender, EventArgs e)
    {
        if (userRightsColl.Contains("7"))
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "Popup", "<script>alert('You have no privilege to Update this Job')</script>", false);
            return;
        }
        else
        {
            if (!checkIsProjectCodeChange(Convert.ToInt32(Session["Upd_jobID"])))
            {
                string chageDesc = "Project Code of Job No.  " + txtJobNo.Text + " was changed From " + Session["contractNo"] + " in to " + txtPrjCode.Text;
                string windowName = "Job Order Details";
                string oldPrjCode = Session["contractNo"].ToString();
                PrjCodeChangeLog(chageDesc, windowName, txtPrjCode.Text, oldPrjCode);
            }

            UpdateJobOrder(Convert.ToInt32(Session["Upd_jobID"]));
        }
    }
    private Boolean checkIsProjectCodeChange(int _jobid)
    {
        using (SqlConnection cnn = new SqlConnection(connValue))
        {
            cnn.Open();
            using (SqlCommand cmm = new SqlCommand())
            {
                cmm.Connection = cnn;
                cmm.CommandText = "SELECT contractNo  FROM Job WHERE JobID = " + _jobid + " and contractNo = '" + txtPrjCode.Text.Trim() + "'";
                using (SqlDataReader sqlDtReader = cmm.ExecuteReader())
                {
                    if (sqlDtReader.HasRows)
                    {
                        return true;
                    }
                }
            }
        }
        return false;
    }
    protected void btnAddStaff_Click(object sender, EventArgs e)
    {
        if (userRightsColl.Contains("4")) // Access Right is 4 
        {
            Session["lblText"] = "You are not allowed to Add New Job Incharge.Please contact system Administrator for further inquiry.";
            Session["lblSub"] = "Restricted Access to Add New Job Order.";
            Session["lblBody"] = "This is in reference to Restricted Access to Add New Job Order. I would like to inquire about the restriction.";

            string url = "RestrictedMsgWindow.aspx";
            string s = "window.open('" + url + "', 'popup_window', 'width=500,height=250,left=100,top=100,resizable=yes,scrollbars=yes');";
            ClientScript.RegisterStartupScript(this.GetType(), "script", s, true);

            //ClientScript.RegisterClientScriptBlock(this.GetType(), "Popup", "<script>alert('You have no privilege to add this Staff')</script>", false);
            //return;
        }
        else
        {
            Session["jobNo"] = txtJobNo.Text;
            Session["jobType"] = ddlJobType.SelectedValue;
            Session["contractNo"] = txtCntrNo.Text;

            string url = "AddStaff.aspx";
            string s = "window.open('" + url + "', 'popup_window', 'width=700,height=500,left=100,top=100,resizable=yes');";
            Page.ClientScript.RegisterStartupScript(this.GetType(), "script", s, true);
        }
    }




    // ------------------------------------------------- Job Incharge GridView Code ----------------------------------------------------------------------------------------------------



    protected void gvJoborder_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            DropDownList l = (DropDownList)e.Row.FindControl("ddljobtype");

            PopulateDropDownBox(l, "SELECT JobStatusid,JobStatusName as JobStatus FROM jobStatus where JobStatusid in(2,3,6,7) ", "JobStatusid", "JobStatus");  // where JobStatusid in(5,6,7,8)

            TextBox lm = (TextBox)e.Row.FindControl("jobid");
            TextBox afr = (TextBox)e.Row.FindControl("TextBox1");
            TextBox InchargeID = (TextBox)e.Row.FindControl("txtInchargeID");

            Session["InchargeID"] = InchargeID.Text;

            string lk = lm.Text;
            l.ToolTip = InchargeID.Text;

            l.SelectedValue = afr.Text;

            Session["StatusVal"] = l.SelectedValue;

            l.SelectedIndexChanged += new EventHandler(SelectedIndexChanged);

            TextBox txtdate = (TextBox)e.Row.FindControl("lblJoindate");            // ActionDueDate 
            txtdate.ToolTip = InchargeID.Text;
            txtdate.TextChanged += new EventHandler(txtdate_TextChanged);
            Session["JobActionDueDate"] = txtdate.Text;

            System.Web.UI.WebControls.CheckBox chkstate = (System.Web.UI.WebControls.CheckBox)e.Row.FindControl("ad");
            chkstate.ToolTip = InchargeID.Text;
            chkstate.CheckedChanged += new EventHandler(chkstate_CheckedChanged);

            //CheckBox chkstateTL = (CheckBox)e.Row.FindControl("chkTL");
            //chkstateTL.ToolTip = InchargeID.Text;
            //chkstateTL.CheckedChanged += new EventHandler(chkstateTL_CheckedChanged);

            Label lblStaff = (Label)e.Row.FindControl("txtStaff");
            
            Label lblDistributedBy = (Label)e.Row.FindControl("txtDistrubed");

            Label lblConactID = (Label)e.Row.FindControl("txtCnctID");

            TextBox _txtDocID = (TextBox)e.Row.FindControl("txtDocID");
            Session["statusdocID"] = _txtDocID.Text;
            Session["contactID"] = lblConactID.Text;

            Label lblDistribID = (Label)e.Row.FindControl("txtDistributedBy");
            Label lblTeamLeadID = (Label)e.Row.FindControl("lblTeamLead");

            //Label lblRoleID = (Label)e.Row.FindControl("txtRoleID");
            // chkDelete.CheckedChanged += new EventHandler(chkstate_CheckedChanged);                        

            if ((!lblConactID.Text.Equals(Session["userID"])) & (!lblTeamLeadID.Text.Equals(Session["userID"])))
            {
                l.Enabled = false;
                chkstate.Enabled = false;
                // txtdate.Enabled = false;
            }
            if (lblConactID.Text.Equals(Session["userID"]))
            {
              //  btnOutlook.Enabled = true;
                Session["ActionDate"] = txtdate.Text;
            }
            if (!lblDistribID.Text.Equals(Session["userID"]))
            {
                txtdate.Enabled = false;
            }

            Label lblIsActive = (Label)e.Row.FindControl("txtisActive");    //txtDistisActive
            if (lblIsActive.Text.Equals("False"))
            {
                HyperLink _lnkStaff = (HyperLink)e.Row.FindControl("lnkStaff"); //
                HyperLink _lnkDistribStaff = (HyperLink)e.Row.FindControl("DistibActive");
                _lnkStaff.Enabled = false;
                //_lnkDistribStaff.Enabled = false;
            }

            Label lblDistIsActive = (Label)e.Row.FindControl("txtDistisActive");
            if (lblDistIsActive.Text.Equals("False"))
            {
                HyperLink _lnkDistribStaff = (HyperLink)e.Row.FindControl("lnkDistirbStaff");
                _lnkDistribStaff.Enabled = false;
            }

            if (txtdate.Text != "")
            {
                if ((Convert.ToDateTime(txtdate.Text) < System.DateTime.Today) & (l.SelectedValue != "7"))
                {
                    e.Row.Cells[3].BackColor = System.Drawing.Color.Red;
                    e.Row.Cells[3].ForeColor = System.Drawing.Color.White;

                    txtdate.ForeColor = System.Drawing.Color.White;
                    txtdate.BackColor = System.Drawing.Color.Red;
                }
            }

            //if (lblConactID.Text.Equals("202"))
            //{
            //    lnkRequestNo.Text = "";
            //}



            //gvJoborder.Rows[0].Cells[4].Enabled = false;
        }
    }
    //
    protected void chkstate_CheckedChanged(object sender, EventArgs e)
    {
        System.Web.UI.WebControls.CheckBox chk = (System.Web.UI.WebControls.CheckBox)sender;

        int inchargeID = Convert.ToInt32(chk.ToolTip);

        Session["_InchargeID"] = inchargeID;

        new JobOrderData().UpdateStatus(inchargeID, Convert.ToBoolean(chk.Checked));
        new JobOrderData().UpdateCompletionDate(inchargeID, Convert.ToBoolean(chk.Checked));

        IList<int> docIDColl = new List<int>();

        if (chk.Checked) // true
        {            
            Boolean chkDoc = checkDocExist(inchargeID);

            string _staffName = string.Empty; string _userName = string.Empty;
            string eMail = getMailAddress(Convert.ToInt32(Session["_InchargeID"]), ref _staffName, ref _userName);
            OutLookAlertJobComplete(eMail, "", _staffName, _userName);
           
            if (chkDoc == true)
            {
                string url = "RestrictedAccessWindow.aspx";
                string s = "window.open('" + url + "', 'popup_window', 'width=520,height=200,left=100,top=100,resizable=no');";
                Page.ClientScript.RegisterStartupScript(this.GetType(), "script", s, true);
            }
        }
        else
        {           
            Boolean chkDoc = checkDocExist(inchargeID);
            if (chkDoc == false)
            {
                string url = "Restricted.aspx";
                string s = "window.open('" + url + "', 'popup_window', 'width=520,height=200,left=100,top=100,resizable=no');";
                Page.ClientScript.RegisterStartupScript(this.GetType(), "script", s, true);
            }
        }

        gvJoborder.DataSource = new JobOrderData().GetJobOwnerDetails(_jobID);
        gvJoborder.DataBind();
    
    }
    protected void chkstateTL_CheckedChanged(object sender, EventArgs e)
    {
        System.Web.UI.WebControls.CheckBox chk = (System.Web.UI.WebControls.CheckBox)sender;
        int inchargeID = Convert.ToInt32(chk.ToolTip);
        if (chk.Checked) // true
        {
            new JobOrderData().UpdateTLApproveStatus(Convert.ToInt32(inchargeID), Convert.ToBoolean(chk.Checked));
        }
        else
        {
            new JobOrderData().UpdateTLApproveStatus(Convert.ToInt32(inchargeID), Convert.ToBoolean(chk.Checked));
        }

        gvJoborder.DataSource = new JobOrderData().GetJobOwnerDetails(_jobID);
        gvJoborder.DataBind();
    }
    public IList<int> getDocIDCollection()
    {
        IList<int> docIDColl = new List<int>();
        IList<int> docStatusColl = new List<int>();

        try
        {
            SqlConnection sqlConn = new SqlConnection(connValue);
            sqlConn.Open();

            string strQuery = "SELECT DISTINCT DocumentDistribution.documentID,DocumentDistribution.docStatusID, [Document].jobID FROM  [Document] INNER JOIN DocumentDistribution ON [Document].documentID = DocumentDistribution.documentID  WHERE  ([Document].jobID = " + _jobID + ")";

            SqlCommand sqlCom = new SqlCommand(strQuery, sqlConn);
            SqlDataReader sqlReader = sqlCom.ExecuteReader();
            while (sqlReader.Read())
            {
                docIDColl.Add(Convert.ToInt32(sqlReader["DocumentID"]));
                docStatusColl.Add(Convert.ToInt32(sqlReader["docStatusID"]));
            }
            Session["docStatusColl"] = docStatusColl;

            sqlReader.Close();
            sqlConn.Close();
        }
        catch (System.Exception ex)
        {
            throw ex;
        }
        return docIDColl;
    }
    protected void SelectedIndexChanged(object sender, EventArgs e)
    {
        //1	Closed	 ,        2	Rejected	,        3	On-going	,        4	Pending	PEN	
        //5	Cancelled	,        6	On Hold	,        7	Completed	COM	,        8	Under Process with EBSD	UPE	
        //9	Waiting Consultant Signature	WCS	,        10	Pending with the Committee	PWC	,        11	Waiting Dept. Manager Signature	WMS,  
        // 12	Waiting PB From Consultant	WPB	,        13	Waiting President Signature	WPS	



        DropDownList ddl = (DropDownList)sender;
        if (ddl.SelectedIndex != 0)
        {
            string ID = ddl.ID;
            string g = ddl.SelectedValue;
            string inchargeID = ddl.ToolTip;
            Session["_InchargeID"] = inchargeID;
            Session["StatusValCurrent"] = ddl.SelectedValue;

            if (ddl.SelectedValue == "3" || ddl.SelectedValue == "7")
                new JobOrderData().UpdateJobDoneCheckBox(Convert.ToInt32(inchargeID), Convert.ToInt32(ddl.SelectedValue));

            if (ddl.SelectedValue != "7")
            {
                new JobOrderData().UpdateCompletionDate(Convert.ToInt32(inchargeID));
                //string eMail = getMailAddress(Convert.ToInt32(inchargeID));
                //OutLookAlert(eMail, "");
            }

            new JobOrderData().UpdateJobStatus(Convert.ToInt32(inchargeID), Convert.ToInt32(ddl.SelectedValue), Session["UserName"].ToString());

            if (ddl.SelectedValue == "7")
            {
                Boolean chkDoc = checkDocExist(Convert.ToInt32(inchargeID));

                string _staffName = string.Empty; string _userName = string.Empty;
                string eMail = getMailAddress(Convert.ToInt32(Session["_InchargeID"]), ref _staffName, ref _userName);
                OutLookAlertJobComplete(eMail, "", _staffName, _userName);

                if (chkDoc == true)
                {
                    string url = "RestrictedAccessWindow.aspx";
                    string s = "window.open('" + url + "', 'popup_window', 'width=520,height=200,left=100,top=100,resizable=no');";
                    Page.ClientScript.RegisterStartupScript(this.GetType(), "script", s, true);
                }
            }
            else if (ddl.SelectedValue == "3")
            {
                Boolean chkDoc = checkDocExist(Convert.ToInt32(inchargeID));
                if (chkDoc == false)
                {
                    string url = "Restricted.aspx";
                    string s = "window.open('" + url + "', 'popup_window', 'width=520,height=200,left=100,top=100,resizable=no');";
                    Page.ClientScript.RegisterStartupScript(this.GetType(), "script", s, true);
                }
            }

            gvJoborder.DataSource = new JobOrderData().GetJobOwnerDetails(_jobID);
            gvJoborder.DataBind();
        }
    }
    private string getMailAddress(int _inchargeID, ref string staffName, ref string userName)
    {
        string _eMail = string.Empty;
        SqlConnection cnn = new SqlConnection(connValue);
        cnn.Open();
        SqlCommand cmm = new SqlCommand();
        cmm.Connection = cnn;
        cmm.CommandText = "SELECT  Contact.firstName, Contact_1.emailAddress,Contact_1.firstName as UserName  FROM JobOwner INNER JOIN    Contact ON JobOwner.contactID = Contact.contactID INNER JOIN  Contact AS Contact_1 ON JobOwner.distributedBy = Contact_1.contactID WHERE   (JobOwner.jobOwnerID = " + _inchargeID + ")"; //open n Follwup
        SqlDataReader sqlDtReader = cmm.ExecuteReader();
        if (sqlDtReader.HasRows)
        {
            while (sqlDtReader.Read())
            {
                _eMail = sqlDtReader["emailAddress"].ToString();
                staffName = sqlDtReader["firstName"].ToString();
                userName = sqlDtReader["UserName"].ToString();
            }
        }
        sqlDtReader.Close();
        cnn.Close();
        return _eMail;
    }
    private void OutLookAlertJobComplete(string eMail, string mailBody, string _staffName, string _userName)
    {
        string jobNo = "";
        SmtpClient smtpclient = new SmtpClient("10.250.50.201", 587);
        System.Net.Mail.MailMessage mail = new System.Net.Mail.MailMessage();
        MailAddress fromaddress = new MailAddress("EBSD@ashghal.gov.qa");
        mail.From = fromaddress;
        mail.To.Add(eMail);
        mail.Subject = ("eBook Job No. " + jobNo);
        mail.IsBodyHtml = true;

        mail.Body = "<html><body><i style='font-family:Calibri; font-size:15'>Dear " + _userName + " ,</i><br/><br/><i style='font-family:Calibri; font-size:15'>This is an automated alert from Document & Task Management System.</i><br/><br/><i style='font-family:Calibri;font-size:15'>" +
                           "Please be noted that</i><i style='color:Maroon;font-family:Calibri; font-size:15'> Job No. " + Session["jobNo"].ToString() + "</i><i style='font-family:Calibri; font-size:15'> was completed by " + _staffName + " . Please log in to eBook on the following link:-</i><br /><br />" +
                           "<table style='width:80%' border='1'><tr><td align='center' colspan='2' style='background-color:Maroon;color:White;font-family:Calibri;font-size:18;font-weight:bold'>JOB NO: " + Session["jobNo"].ToString() + "</td>" +
                           "</tr><tr><td style='background-color:#B58AA5;font-family:Calibri;font-size:15'><i>Contract No / Project Code </i></td><td style='font-family:Calibri;font-size:15'>" + Session["contractNo"].ToString() + "</td></tr>" +
                           "<tr><td style='background-color:#B58AA5;font-family:Calibri;font-size:15'><i>eBook URL</i></td><td style='font-family:Calibri;font-size:15'>  http://mv2ebdbookp01/eBook/LoginPage.aspx </td></tr>" +
                           "<tr><td style='background-color:#B58AA5;font-family:Calibri;font-size:15'><i>Date of Creation</i></td><td style='font-family:Calibri;font-size:15'>" + System.DateTime.Now + "</td></tr>" +
                           "</table><br/><br/><div style='font-family:Calibri; font-size:15'>Best Regards,<br/>eBook Team</div></body></html>";


        smtpclient.EnableSsl = true;
        smtpclient.UseDefaultCredentials = true;

        try
        {
            smtpclient.Credentials = new System.Net.NetworkCredential(@"Ashghal\EBSD", ConfigurationManager.AppSettings["passWordForReport"].ToString()); 
            ServicePointManager.ServerCertificateValidationCallback = delegate(object s, X509Certificate certificate, X509Chain chain, SslPolicyErrors sslPolicyErrors) { return true; };
            smtpclient.Send(mail);
        }
        catch (System.Exception ex)
        {
            Console.WriteLine(ex);
            if (ex.InnerException != null)
            {
                Console.WriteLine("InnerException is: {0}", ex.InnerException);
            }
        }
        finally
        {
            mail.Dispose();
            mail = null;
            smtpclient = null;
        }
    }
    private string getMailAddress(int _inchargeID)
    {
        string _eMail = string.Empty;
        SqlConnection cnn = new SqlConnection(connValue);
        cnn.Open();
        SqlCommand cmm = new SqlCommand();
        cmm.Connection = cnn;
        cmm.CommandText = "SELECT   Contact.emailAddress, Contact_1.emailAddress AS distBy  FROM   JobOwner INNER JOIN    Contact ON JobOwner.contactID = Contact.contactID INNER JOIN  Contact AS Contact_1 ON JobOwner.distributedBy = Contact_1.contactID WHERE   (JobOwner.jobOwnerID = " + _inchargeID + ")"; //open n Follwup
        SqlDataReader sqlDtReader = cmm.ExecuteReader();
        if (sqlDtReader.HasRows)
        {
            while (sqlDtReader.Read())
                _eMail = sqlDtReader["emailAddress"].ToString();
        }       
        sqlDtReader.Close();
        cnn.Close();
        return _eMail;
    }
    private void OutLookAlert(string eMail, string mailBody)
    {
        string jobNo = "";
        SmtpClient smtpclient = new SmtpClient("10.250.50.201", 587);
        System.Net.Mail.MailMessage mail = new System.Net.Mail.MailMessage();
        MailAddress fromaddress = new MailAddress("EBSD@ashghal.gov.qa");
        mail.From = fromaddress;
        mail.To.Add(eMail);
        mail.Subject = ("eBook Job No. " + jobNo);
        mail.IsBodyHtml = true;
      
        mail.Body = "<html><body><i style='font-family:Calibri; font-size:15'>Dear eBook Team,</i><br/><br/><i style='font-family:Calibri; font-size:15'>This is an automated alert from Document & Task Management System.</i><br/><br/><i style='font-family:Calibri;font-size:15'>" +
                           "Please be noted that</i><i style='color:Maroon;font-family:Calibri; font-size:15'> Job No. " + Session["jobNo"].ToString() + "</i><i style='font-family:Calibri; font-size:15'> a new Job Order was assigned to you and the details are as follows:-</i><br /><br />" +
                           "<table style='width:80%' border='1'><tr><td align='center' colspan='2' style='background-color:Maroon;color:White;font-family:Calibri;font-size:18;font-weight:bold'>JOB NO: " + Session["jobNo"].ToString() + "</td>" +
                           "</tr><tr><td style='background-color:#B58AA5;font-family:Calibri;font-size:15'><i>Contract No / Project Code </i></td><td style='font-family:Calibri;font-size:15'>" + Session["contractNo"].ToString() + "</td></tr>" +
                           "<tr><td style='background-color:#B58AA5;font-family:Calibri;font-size:15'><i>eBook URL</i></td><td style='font-family:Calibri;font-size:15'>  http://mv2ebdbookp01/eBook/LoginPage.aspx  </td></tr>" +
                           "<tr><td style='background-color:#B58AA5;font-family:Calibri;font-size:15'><i>Date of Creation</i></td><td style='font-family:Calibri;font-size:15'>" + System.DateTime.Now + "</td></tr>" +
                           "</table><br/><br/><div style='font-family:Calibri; font-size:15'>Best Regards,<br/>eBook Team</div></body></html>";


        smtpclient.EnableSsl = true;
        smtpclient.UseDefaultCredentials = true;

        try
        {
            smtpclient.Credentials = new System.Net.NetworkCredential(@"Ashghal\EBSD", ConfigurationManager.AppSettings["passWordForReport"].ToString()); 
            ServicePointManager.ServerCertificateValidationCallback = delegate(object s, X509Certificate certificate, X509Chain chain, SslPolicyErrors sslPolicyErrors) { return true; };
            smtpclient.Send(mail);
        }
        catch (System.Exception ex)
        {
            Console.WriteLine(ex);
            if (ex.InnerException != null)
            {
                Console.WriteLine("InnerException is: {0}", ex.InnerException);
            }
        }
        finally
        {
            mail.Dispose();
            mail = null;
            smtpclient = null;
        }
    }
    private Boolean checkDocExist(int inChargeID)
    {
        Boolean chkDocExist = false;
        string prjTitle = string.Empty;
        SqlConnection cnn = new SqlConnection(connValue);
        cnn.Open();
        SqlCommand cmm = new SqlCommand();
        cmm.Connection = cnn;
        cmm.CommandText = "SELECT *  FROM DocumentDistribution WHERE JobOwnerID = " + inChargeID + " and docStatusID in(1,2)"; //open n Follwup
        SqlDataReader sqlDtReader = cmm.ExecuteReader();
        if (sqlDtReader.HasRows)
        {
            chkDocExist = true;
        }
        else
        {
            prjTitle = "NA";
        }
        sqlDtReader.Close();
        cnn.Close();

        return chkDocExist;
    }
    protected void txtdate_TextChanged(object sender, EventArgs e)
    {
        TextBox tdate = (TextBox)sender;
        //string format = "dd/mm/yyyy";

        string dfs = tdate.Text;


        DateTime dd = new DateTime();
        Thread.CurrentThread.CurrentCulture = new CultureInfo("en-GB");
        CultureInfo ci = System.Threading.Thread.CurrentThread.CurrentCulture;
        DateTime dt;

        //dt = DateTime.Parse(tdate.Text, ci); 
        // DateTime dt = DateTime.Parse(tdate.Text, CultureInfo.GetCultureInfo("en-gb"));
        // new JobOrderData().UpdateJobDate(Convert.ToInt32(tdate.ToolTip), dd.ToString());

        new JobOrderData().UpdateJobDate(Convert.ToInt32(tdate.ToolTip), dfs);

        gvJoborder.DataSource = new JobOrderData().GetJobOwnerDetails(_jobID);
        gvJoborder.DataBind();
    }

    private void FillTab2()
    {
        try
        {
            DataSet ds = new DataSet();

            int x;
            x = 0;

            ds = (new JobOrderData().GetJobOrderDetails(0, "", 0, 0, "", "", 0));
            gvJoborder.DataSource = ds;
            gvJoborder.DataBind();

            //   Convert.ToInt32(txtjobid.Text), txtJobNo.Text, Convert.ToInt32(txtaffair.Text), Convert.ToInt32(txtdept.Text), txtprojcode.Text, txtprojtitle.Text, Convert.ToInt32(txtconsult.Text)));
        }
        catch (Exception ex)
        {

        }
    }


    protected void Button1_Click(object sender, EventArgs e)
    {
        Response.Write("<script language='javascript'> window.open('VODemo.aspx','','width=846,Height=400,fullscreen=1,location=0,scrollbars=0,menubar=1,toolbar=1, align=center,top=100,left=500'); </script>");

        // Response.Write("<script language='javascript'> window.open('EOTDetailsWindow.aspx','','width=846,Height=400,fullscreen=1,location=0,scrollbars=0,menubar=1,toolbar=1, align=center,top=100,left=500'); </script>");       
    }
    protected void btnReceive_Click(object sender, EventArgs e)
    {
        string strUpdateJob = Request.Url.AbsoluteUri;
        try
        {
            if (userRightsColl.Contains("8")) // Access Right is 4 
            {
                ClientScript.RegisterClientScriptBlock(this.GetType(), "Popup", "<script>alert('You have no privilege to add this Document')</script>", false);
                return;
            }
            else
            {
                Session["UrlRef"] = strUpdateJob;
                Session["jobID"] = _jobID;
                Response.Redirect("~/Documents/DocumentDetailsWindow.aspx?RecSentCatID=1&Reply=0", false);
            }
        }
        catch (Exception ex)
        {

        }
    }

    protected void ddlGrade_SelectedIndexChanged(object sender, EventArgs e)
    {
        string upDateQuery = string.Empty;
        upDateQuery = "UPDATE Job SET jobPriorityID = @jobPriority WHERE JobID = @JobID";

        using (SqlConnection sqlCon = new SqlConnection(connValue))
        {
            using (SqlCommand cmd = new SqlCommand())
            {
                cmd.CommandText = upDateQuery;
                cmd.Connection = sqlCon;

                cmd.Parameters.AddWithValue("@JobID", _jobID);
                cmd.Parameters.AddWithValue("@jobPriority", ddlGrade.SelectedValue);

                try
                {
                    sqlCon.Open();
                    cmd.ExecuteNonQuery();
                    sqlCon.Close();
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
        }


    }
    private void WorkingDaysCaluclationByGrade(string strDate)
    {
        string endDate = string.Empty;
        switch (ddlGrade.SelectedItem.ToString())
        {
            case "1":
                txtWorkDays.Text = "5"; // Working Days
                endDate = getEndDateByGivenDays(5, strDate);
                txtDueDate.Text = Convert.ToDateTime(endDate).ToString("dd/MMM/yyyy");

                //txtDueDate.Text = System.DateTime.Now.AddDays(5).ToString("dd/MMM/yyyy");
                break;
            case "2":
                endDate = getEndDateByGivenDays(8, strDate);
                txtDueDate.Text = Convert.ToDateTime(endDate).ToString("dd/MMM/yyyy");
                txtWorkDays.Text = "7";
                break;

            case "3":
                endDate = getEndDateByGivenDays(10, strDate);
                txtDueDate.Text = Convert.ToDateTime(endDate).ToString("dd/MMM/yyyy");
                txtWorkDays.Text = "10";
                break;

            case "4":
                endDate = getEndDateByGivenDays(15, strDate);
                txtDueDate.Text = Convert.ToDateTime(endDate).ToString("dd/MMM/yyyy");
                txtWorkDays.Text = "15";
                break;

            case "":
                txtDueDate.Text = "";
                txtWorkDays.Text = "";
                break;

            default:
                break;
        }
    }
    private string getEndDateByGivenDays(int _days, string strDate)
    {
        SqlConnection con = new SqlConnection(connValue);
        SqlCommand cmd = new SqlCommand();
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Connection = con;

        cmd.CommandText = "AddWorkdays";
        SqlParameter prm = cmd.Parameters.Add("@ad_startDate", SqlDbType.DateTime);
        prm.Value = strDate;
        prm = cmd.Parameters.Add("@actual_workDays", SqlDbType.Int);
        prm.Value = Convert.ToInt32(_days);
        prm = cmd.Parameters.Add("@endDate", SqlDbType.DateTime);
        prm.Direction = ParameterDirection.Output;
        con.Open();
        SqlDataReader dr = cmd.ExecuteReader();
        while (dr.Read())
            Console.WriteLine(dr.GetString(0));
        con.Dispose();
        con.Close();

        return cmd.Parameters[2].Value.ToString();
    }
    protected void btnSent_Click(object sender, EventArgs e)
    {
        string strUpdateJob = Request.Url.AbsoluteUri;
        try
        {
            if (userRightsColl.Contains("8")) // Access Right is 4 
            {
                ClientScript.RegisterClientScriptBlock(this.GetType(), "Popup", "<script>alert('You have no privilege to add Document')</script>", false);
                return;
            }
            else
            {
                Session["DocCategoryID"] = "2";    // It shoul be 2
                Session["DocID"] = null;
                Session["UrlRef"] = strUpdateJob;
                Session["JobID"] = _jobID;
                Response.Redirect("~/Documents/DocumentDetailsWindow.aspx?RecSentCatID=2&Reply=0", false);
            }
        }
        catch (Exception ex)
        {

        }
    }
    protected void ddlDept_SelectedIndexChanged(object sender, EventArgs e)
    {
        Session["AffairID"] = new JobOrderData().getAffairID(Convert.ToInt32(ddlDept.SelectedValue));
    }
    //protected void ddlJobCat_SelectedIndexChanged(object sender, EventArgs e)
    //{
    //    if (ddlJobPriority.SelectedIndex > 0)
    //    {
    //        FillCombo(ddlJobType, "JobTypeID", "JobTypeName", ExecuteQuery("SELECT JobTypeID,JobTypeName FROM JobType WHERE CategoryID= " + ddlJobPriority.SelectedValue + " and jobTypeID<>CategoryID"), false);
    //        ddlJobType.Items.Insert(0, new ListItem("--Select--"));
    //    }
    //    else
    //        ddlJobType.Items.Clear();
    //}
    public static void FillCombo(DropDownList dropDownList, string dataValueField, string dataTextField, System.Data.DataTable dataTbl, bool bHasBlank)
    {
        dropDownList.DataTextField = dataTextField;
        dropDownList.DataValueField = dataValueField;
        dropDownList.DataSource = dataTbl;
        dropDownList.DataBind();


        if (bHasBlank)
            dropDownList.Items.Insert(0, new ListItem());
    }
    public static System.Data.DataTable ExecuteQuery(string SQLstring)
    {
        string sConstr = ConfigurationManager.ConnectionStrings["EBSDEBookConn"].ConnectionString;
        SqlConnection Conn = new SqlConnection(sConstr);
        System.Data.DataTable dt = new System.Data.DataTable("tbl");

        using (Conn)
        {
            Conn.Open();
            SqlCommand comm = new SqlCommand(SQLstring, Conn);
            comm.CommandTimeout = 0;
            SqlDataAdapter da = new SqlDataAdapter(comm);
            da.Fill(dt);
        }

        return dt;
    }
    protected void nLinkRec_Click(object sender, EventArgs e)
    {
        Session["CatID"] = "1";
        Session["lnkJobID"] = _jobID;

        if (userRightsColl.Contains("8")) // Access Right is 4 
        {
            Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Don't have the permission to Add Staff ')</script>", false);
            return;
        }
        else
        {
            string url = "UploadDoc_DC.aspx";
            string s = "window.open('" + url + "', 'popup_window', 'width=600,height=400,left=100,top=100,resizable=yes');";
            Page.ClientScript.RegisterStartupScript(this.GetType(), "script", s, true);
        }
    }
    protected void btnLinkSent_Click(object sender, EventArgs e)
    {
        Session["CatID"] = "2";
        Session["lnkJobID"] = _jobID;

        if (userRightsColl.Contains("8")) // Access Right is 4 
        {
            Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Don't have the permission to Add Staff ')</script>", false);
            return;
        }
        else
        {
            string url = "UploadDoc_DC.aspx";
            string s = "window.open('" + url + "', 'popup_window', 'width=600,height=400,left=100,top=100,resizable=yes');";
            Page.ClientScript.RegisterStartupScript(this.GetType(), "script", s, true);
        }
    }
    protected void DocSent_Click(Object sender, EventArgs e)
    {
        try
        {
            Session["DocCategoryID"] = "2";
            Session["DocID"] = sentDocID;

            //Session["UrlRef"] = "~/Documents/ReceiveUploadDocuments.aspx";

            Session["JobID"] = _jobID;
            Response.Redirect("~/Documents/DocumentDetailsWindow.aspx", false);
        }
        catch (Exception ex)
        {

        }
    }
    protected void gridSent_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            LinkButton lnkRef = (LinkButton)e.Row.FindControl("lnkSent");

            Label txtDocType = (Label)e.Row.FindControl("SenttxtDocType");
            Label txtDate = (Label)e.Row.FindControl("SenttxtDate");
            TextBox txtDocID = (TextBox)e.Row.FindControl("SenttxtDocID");
            Label lblOpenRef = (Label)e.Row.FindControl("SentlblOpenDocRef");
            Label lblCloseRef = (Label)e.Row.FindControl("SentlblClosedDocRef");
            Control ctrlReceiveCreateUser = e.Row.FindControl("divSentCreateUserID");
            Control ctrlReceiveOriginContactID = e.Row.FindControl("divSentOriginContactID");
            Control ctrlSuperseded = e.Row.FindControl("divSentSuperseded");
            HtmlGenericControl htmlCtrlSuperseded = ctrlSuperseded as HtmlGenericControl;
            HtmlGenericControl htmlCtrlctrlReceiveOriginContactID = ctrlReceiveOriginContactID as HtmlGenericControl;
            HtmlGenericControl htmlCtrlReceiveCreateUser = ctrlReceiveCreateUser as HtmlGenericControl;

            string strDocID = txtDocID.Text;
            string strOpenRef = lblOpenRef.Text;
            string strCloesdRef = lblCloseRef.Text;

            LinkButton lnkView = (LinkButton)e.Row.FindControl("SentbtnDelete");
            if (htmlCtrlSuperseded.InnerText.Equals("True"))
            {
                e.Row.Cells[3].BackColor = System.Drawing.Color.WhiteSmoke;
                e.Row.Cells[3].ForeColor = System.Drawing.Color.Gray;

                e.Row.Cells[4].BackColor = System.Drawing.Color.WhiteSmoke;
                e.Row.Cells[4].ForeColor = System.Drawing.Color.Gray;


                if (htmlCtrlReceiveCreateUser.InnerText.Equals(Session["UserID"].ToString()) || htmlCtrlctrlReceiveOriginContactID.InnerText.Equals(Session["UserID"].ToString()) || Session["UserProfileID"].ToString().Equals("1"))
                {
                    if (lnkRef != null)
                    {
                        lnkRef.Enabled = true;
                        lnkRef.Font.Underline = true;
                    }
                }
                else
                {
                    lnkRef.Enabled = false;
                    lnkRef.Font.Underline = false;
                    lnkRef.ForeColor = System.Drawing.Color.Gray;

                    e.Row.Cells[2].BackColor = System.Drawing.Color.WhiteSmoke;
                    e.Row.Cells[2].ForeColor = System.Drawing.Color.Black;
                }
            }

            if (strDocID.Equals(strOpenRef) || (strDocID.Equals(strCloesdRef)))
            {
                lnkView.ForeColor = System.Drawing.Color.White;
            }
            else
            {
                lnkView.Attributes.Add("onclick", "javascript:return " + "confirm('This will delete this document from this Job Order.')");
                lnkView.CssClass = "SentbtnDelete";
            }

            Session["DocDelete"] = "1";
        }
    }
    string recDocID = string.Empty;
    protected void gridReceived_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        string str = Request.Url.AbsoluteUri;
        if (e.CommandName == "VIEWREC")
        {
            LinkButton lnkView = (LinkButton)e.CommandSource;
            recDocID = lnkView.CommandArgument;
            try
            {
                Session["UrlRef"] = str;
                Session["JobID"] = _jobID;
                Response.Redirect("~/Documents/DocumentDetailsWindow.aspx?docRecID=" + recDocID + "&RecSentCatID=1", false);
            }
            catch (Exception ex)
            {
            }
        }       
       
        if (e.CommandName == "ViewFile")
        {
            LinkButton lnkAdd = (LinkButton)e.CommandSource;
            recDocID = lnkAdd.CommandArgument;
            try
            {
                Session["UrlRef"] = str;
                Session["JobID"] = _jobID;

                if ((Session["File_docID"] == null) || (Session["File_docID"] == "0") || recDocID != "0")
                    Session["File_docID"] = recDocID;

                Session["fileType"] = "";
                Session["fileType"] = "F";


                string url = "/eBook/FileUpload.aspx";
                string s = "window.open('" + url + "', 'popup_window', 'width=810,height=520,left=100,top=100,resizable=yes,scrollbars=yes');";
                ClientScript.RegisterStartupScript(this.GetType(), "script", s, true);
            }
            catch (Exception ex)
            {
            }
        }
        if (e.CommandName == "ViewAttach")
        {
            LinkButton lnkAdd = (LinkButton)e.CommandSource;
            recDocID = lnkAdd.CommandArgument;
            try
            {
                Session["UrlRef"] = str;
                Session["JobID"] = _jobID;

                if ((Session["File_docID"] == null) || (Session["File_docID"] == "0") || recDocID != "0")
                    Session["File_docID"] = recDocID;

                Session["fileType"] = "";
                Session["fileType"] = "A";


                string url = "/eBook/FileUpload.aspx";
                string s = "window.open('" + url + "', 'popup_window', 'width=810,height=520,left=100,top=100,resizable=yes,scrollbars=yes');";
                ClientScript.RegisterStartupScript(this.GetType(), "script", s, true);
            }
            catch (Exception ex)
            {
            }
        }
        if (e.CommandArgument != "")
        {
            int docID = Convert.ToInt32(e.CommandArgument);
            IList<string> docLetterIDs = new List<string>();
            docLetterIDs = (new JobOrderData().chkDocumentRefWithDCJob(_jobID));
            switch (e.CommandName)
            {
                case "RecDeleteDocid":


                    foreach (var item in docLetterIDs)
                    {
                        if (!docID.ToString().Equals(item))
                        {
                            new JobOrderData().DeactivateDocumentForJob(docID);
                            DeleteDistributionForJobIncharge(docID);
                        }
                        else
                            ClientScript.RegisterStartupScript(this.GetType(), "alert", "alert('You can't delete, This document reference with Job');", true);
                    }

                    //if (!docID.ToString().Equals(docLetterIDs[0]))
                    //{
                    //    if (!docID.ToString().Equals(docLetterIDs[1]))
                    //    {
                    //        new JobOrderData().DeactivateDocumentForJob(docID);
                    //        DeleteDistributionForJobIncharge(docID);
                    //    }

                    //    gridReceived.DataSource = new JobOrderData().getJobDocumetReceivedDate(_jobID);
                    //    gridReceived.DataBind();
                    //}
                    //else
                    //{
                    //    ClientScript.RegisterStartupScript(this.GetType(), "alert", "alert('You can't delete, This document reference with Job');", true);
                    //}

                    if (flag > 0)
                    {
                        //  Response.Write("Link Deactivated with Job");
                    }
                    break;
            }
        }
    }
    string sentDocID = string.Empty;
    int flag = 0;
    protected void gridSent_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        string str = Request.Url.AbsoluteUri;
        if (e.CommandName == "VIEW")
        {
            LinkButton lnkView = (LinkButton)e.CommandSource;
            sentDocID = lnkView.CommandArgument;
            try
            {
                Session["UrlRef"] = str;
                Session["JobID"] = _jobID;
                Response.Redirect("~/Documents/DocumentDetailsWindow.aspx?docRecID=" + sentDocID + "&RecSentCatID=2", false);
            }
            catch (Exception ex)
            {

            }
        }
        if (e.CommandName == "ViewFile")
        {
            LinkButton lnkAdd = (LinkButton)e.CommandSource;
            recDocID = lnkAdd.CommandArgument;
            try
            {
                Session["UrlRef"] = str;
                Session["JobID"] = _jobID;

                if ((Session["File_docID"] == null) || (Session["File_docID"] == "0") || recDocID != "0")
                    Session["File_docID"] = recDocID;

                Session["fileType"] = "";
                Session["fileType"] = "F";


                string url = "/eBook/FileUpload.aspx";
                string s = "window.open('" + url + "', 'popup_window', 'width=810,height=520,left=100,top=100,resizable=yes,scrollbars=yes');";
                ClientScript.RegisterStartupScript(this.GetType(), "script", s, true);
            }
            catch (Exception ex)
            {
            }
        }
        if (e.CommandName == "ViewAttach")
        {
            LinkButton lnkAdd = (LinkButton)e.CommandSource;
            recDocID = lnkAdd.CommandArgument;
            try
            {
                Session["UrlRef"] = str;
                Session["JobID"] = _jobID;

                if ((Session["File_docID"] == null) || (Session["File_docID"] == "0") || recDocID != "0")
                    Session["File_docID"] = recDocID;

                Session["fileType"] = "";
                Session["fileType"] = "A";


                string url = "/eBook/FileUpload.aspx";
                string s = "window.open('" + url + "', 'popup_window', 'width=810,height=520,left=100,top=100,resizable=yes,scrollbars=yes');";
                ClientScript.RegisterStartupScript(this.GetType(), "script", s, true);
            }
            catch (Exception ex)
            {
            }
        }

        if (e.CommandArgument != "")
        {
            int docID = Convert.ToInt32(e.CommandArgument);
            IList<string> docLetterIDs = new List<string>();
            docLetterIDs = (new JobOrderData().chkDocumentRefWithDCJob(_jobID));
            switch (e.CommandName)
            {
                case "SentDeleteDocid":

                    foreach (var item in docLetterIDs)
                    {
                        if (!docID.ToString().Equals(item))
                        {
                            new JobOrderData().DeactivateDocumentForJob(docID);
                            DeleteDistributionForJobIncharge(docID);
                        }
                        else
                            ClientScript.RegisterStartupScript(this.GetType(), "alert", "alert('You can't delete, This document reference with Job');", true);
                    }

                    if (flag > 0)
                    {
                        //Response.Write("Link Deactivated with Job");
                    }
                    break;
            }
        }
    }
    protected void ddlJobStatus_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (userRightsColl.Contains("6")) // Access Right is 6
        {
            // Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Don't have the permission to edit this field  ')</script>", false);

            ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Don't have the permission to edit this field ')</script>", false);
            //return;
        }
        else
        {
            //Session["JobStatusID"]
            if (ddlJobStatus.SelectedIndex != 0)
            {
                //Session["DocID"] = "";
                Session["lnkJobID"] = _jobID;

                if ((ddlJobStatus.SelectedValue == "2") || (ddlJobStatus.SelectedValue == "5"))     //Rej or Cancelleted 2 n 5
                {                    
                    UpdateJobStatusByUserSelection(_jobID, Convert.ToInt32(ddlJobStatus.SelectedValue));
                }
                else if ((ddlJobStatus.SelectedValue == "3"))  // ongoing
                {                  
                    UpdateJobStatusByUserSelection(_jobID, Convert.ToInt32(ddlJobStatus.SelectedValue));
                }
                else if (ddlJobStatus.SelectedValue == "7") // Close n Completed 7
                {
                    UpdateJobStatuCompletedsDate(_jobID, Convert.ToInt32(ddlJobStatus.SelectedValue));
                }
                else if (ddlJobStatus.SelectedValue == "1")
                {
                    CloseJob();
                }
                else
                {
                    UpdateJobStatusByUserSelection(_jobID, Convert.ToInt32(ddlJobStatus.SelectedValue));
                }

                Fill_JobOrder_Information(_jobID);
            }
        }
    }    
    public string getDocuemnetCloseRef(int _jobID)
    {
        string strJobRefID = string.Empty;
        SqlConnection sqlConn = new SqlConnection(connValue);
        string sqlQuery = "SELECT closedDocRefID from Job where jobID =" + _jobID + "";

        try
        {
            sqlConn.Open();
            SqlCommand sqlCom = new SqlCommand(sqlQuery, sqlConn);
            SqlDataReader sqlReader = sqlCom.ExecuteReader();
            while (sqlReader.Read())
            {
                strJobRefID = sqlReader[0].ToString();
            }
            sqlReader.Close();
        }
        catch (Exception ex)
        {
            // Response.Write("Error getting while reading data !" + ex.Message);
        }
        finally
        {
            sqlConn.Close();
        }
        return strJobRefID;
    }
    public void UpdateJobCloseRefID(int _jobID, int docClsID)
    {
        string upDateQuery = "UPDATE Document SET jobID =@Job_id WHERE DocumentID = @docClsID";
        SqlConnection sqlCon = new SqlConnection(connValue);
        SqlCommand cmd = new SqlCommand();
        cmd.CommandText = upDateQuery;
        cmd.Connection = sqlCon;

        cmd.Parameters.AddWithValue("@Job_id", System.DBNull.Value);
        cmd.Parameters.AddWithValue("@docClsID", docClsID);

        try
        {
            sqlCon.Open();
            cmd.ExecuteNonQuery();
            sqlCon.Close();
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    public void UpdateJobStatus(int _jobID)
    {
        string upDateQuery = "UPDATE Job SET jobStatusID =@Job_Status_id WHERE Jobid = @Job_id";
        SqlConnection sqlCon = new SqlConnection(connValue);
        SqlCommand cmd = new SqlCommand();
        cmd.CommandText = upDateQuery;
        cmd.Connection = sqlCon;

        cmd.Parameters.AddWithValue("@Job_id", _jobID);
        cmd.Parameters.AddWithValue("@Job_Status_id", 1);        //2- Closed   

        try
        {
            sqlCon.Open();
            cmd.ExecuteNonQuery();
            sqlCon.Close();
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    public void UpdateJobCloseDate(int _jobID, int statID)
    {
        string updateSql = "UPDATE Job SET closedDate = @CompleteDate,closedDocRefID =@closeDocID,jobStatusID=@jobStatusID Where JobID = @jobID";
        SqlConnection sqlCon = new SqlConnection(connValue);
        SqlCommand cmd = new SqlCommand();
        cmd.CommandText = updateSql;
        cmd.Connection = sqlCon;
        try
        {
            sqlCon.Open();
            cmd.Parameters.AddWithValue("@jobID", _jobID);    //Convert.ToInt32(Session["lnkJobID"])            
            cmd.Parameters.AddWithValue("@CompleteDate", System.DBNull.Value);
            cmd.Parameters.AddWithValue("@closeDocID", System.DBNull.Value);
            cmd.Parameters.AddWithValue("@jobStatusID", statID);

            cmd.ExecuteNonQuery();

            sqlCon.Close();
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    public void UpdateJobClosedReference(int _jobID)
    {
        string upDateQuery = "UPDATE Job SET jobStatusID =@Job_Status_id WHERE Jobid = @Job_id";
        SqlConnection sqlCon = new SqlConnection(connValue);
        SqlCommand cmd = new SqlCommand();
        cmd.CommandText = upDateQuery;
        cmd.Connection = sqlCon;

        cmd.Parameters.AddWithValue("@Job_id", _jobID);
        cmd.Parameters.AddWithValue("@Job_Status_id", 1);        //2- Closed   

        try
        {
            sqlCon.Open();
            cmd.ExecuteNonQuery();
            sqlCon.Close();
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    private IList<string> getStaffID(int _jobID, int staffRoleID, int inchargeID)
    {
        IList<string> staffDataColl = new List<string>();
        SqlConnection sqlConn = new SqlConnection(connValue);
        string sqlQuery = "SELECT StaffRoleID,contactID from JobOwner where jobID = " + _jobID + " and StaffRoleID = " + staffRoleID + " and jobOwnerID <> " + inchargeID + " ORDER BY jobOwnerID Desc ";

        // "SELECT  StaffRoleID, jobID FROM   JobOwner  WHERE  (StaffRoleID = 1) ORDER BY jobOwnerID"

        try
        {
            sqlConn.Open();
            SqlCommand sqlCom = new SqlCommand(sqlQuery, sqlConn);
            SqlDataReader sqlReader = sqlCom.ExecuteReader();
            while (sqlReader.Read())
            {
                staffDataColl.Add(sqlReader[0].ToString());
                staffDataColl.Add(sqlReader[1].ToString());
            }
            sqlReader.Close();
        }
        catch (Exception ex)
        {
            // Response.Write("Error getting while reading data !" + ex.Message);
        }
        finally
        {
            sqlConn.Close();
        }

        return staffDataColl;
    }
   
    protected void btnOutlook_Click(object sender, EventArgs e)
    {
        Session["jobNo"] = txtJobNo.Text;
        // Session["emailAdr"] = contactID.Text;
        Session["emailAdr"] = Session["IssuedByEmailAddress"];
        string url = "SetTaskReminder.aspx";
        string s = "window.open('" + url + "', 'popup_window', 'width=700,height=500,left=100,top=100,resizable=yes');";
        Page.ClientScript.RegisterStartupScript(this.GetType(), "script", s, true);

    }
  

    # endregion
    protected void txtWorkDays_TextChanged(object sender, EventArgs e)
    {
        if (userRightsColl.Contains("6")) // Access Right is 4 
        {
            Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Don't have the permission to edit this field  ')</script>", false);
            return;
        }
        string endDate = string.Empty;
        if (txtWorkDays.Text != "0")
        {
            if (txtAttRecDate.Text != "")
                endDate = new JobOrderData().getEndDateByGivenDays(txtAttRecDate.Text, txtWorkDays.Text);
            else
                endDate = new JobOrderData().getEndDateByGivenDays(txtReceivedDate.Text, txtWorkDays.Text);                
          
            txtDueDate.Text = Convert.ToDateTime(endDate).ToString("dd/MMM/yyyy");
        } 
    }
   
   
    protected void txtDueDate_TextChanged(object sender, EventArgs e)
    {
        if (userRightsColl.Contains("6")) // Access Right is 4 
        {
            Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Don't have the permission to edit this field  ')</script>", false);
            return;
        }

        //DateTime dateEnd = System.DateTime.Now;
        //dateEnd = ConvertToDateTime(txtDueDate.Text);

        //DateTime dateEnd = Convert.ToDateTime(TextBox2.Text).ToString("dd/MMM/yyyy");

        DateTime dateEnd = ConvertToDateTime(txtDueDate.Text);
        DateTime strDate = ConvertToDateTime(txtReceivedDate.Text);

        string _strDate = strDate.ToString();

        txtWorkDays.Text = new JobOrderData().getDaysByGivenEndDate(_strDate, dateEnd);
        //txtDueDate.Text = dateEnd.ToString("dd/MMM/yyyy");

        if (txtWorkDays.Text.Equals("5"))
            ddlGrade.SelectedIndex = 1;
        else if (txtWorkDays.Text.Equals("7"))
            ddlGrade.SelectedIndex = 2;
        else if (txtWorkDays.Text.Equals("10"))
            ddlGrade.SelectedIndex = 3;
        else if (txtWorkDays.Text.Equals("15"))
            ddlGrade.SelectedIndex = 4;
        else
            ddlGrade.SelectedIndex = 0;
    }
    private DateTime ConvertToDateTime(string strDateTime)
    {
        DateTime dtFinaldate; string sDateTime;
        try
        {
            //dtFinaldate = Convert.ToDateTime(strDateTime); 

            string[] sDate = strDateTime.Split('/');
            sDateTime = sDate[1] + '/' + sDate[0] + '/' + sDate[2];
            dtFinaldate = Convert.ToDateTime(sDateTime);
        }
        catch (Exception e)
        {
            string[] sDate = strDateTime.Split('/');
            sDateTime = sDate[0] + '/' + sDate[1] + '/' + sDate[2];
            dtFinaldate = Convert.ToDateTime(sDateTime);
        }
        return dtFinaldate;
    }
   
    static Boolean isprjCodeChanged = false;
    protected void txtPrjCode_TextChanged(object sender, EventArgs e)
    {
        isprjCodeChanged = true;

        // string chageDesc = txtPrjCode.Text + " Changed as " + txtPrjCode.Text;
        // PrjCodeChangeLog(chageDesc, "JobOrder", txtPrjCode.Text, txtPrjCode.Text);
    }
    public void PrjCodeChangeLog(string changeDesc, string windowName, string NewprjCode, string oldPrjCode)
    {
        if (txtPrjCode.Text != "")
        {
            string upDateQuery = "INSERT INTO CHANGELOG(ChangeData,windowName,newData,oldData,updateUser) VALUES('" + changeDesc + "','" + windowName + "','" + NewprjCode + "','" + oldPrjCode + "', '" + Session["UserDisplayName"].ToString() + "')";
            SqlConnection sqlCon = new SqlConnection(connValue);
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = upDateQuery;
            cmd.Connection = sqlCon;
            try
            {
                sqlCon.Open();
                cmd.ExecuteNonQuery();
                sqlCon.Close();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }

    public void DeleteDistributionForJobIncharge(int docID)
    {
        string upDateQuery = "DELETE FROM DOCUMENTDISTRIBUTION WHERE documentID = @docID and JobOwnerID is not null";

        SqlConnection sqlCon = new SqlConnection(connValue);
        SqlCommand cmd = new SqlCommand();
        cmd.CommandText = upDateQuery;
        cmd.Connection = sqlCon;

        cmd.Parameters.AddWithValue("@docID", docID);

        try
        {
            sqlCon.Open();
            cmd.ExecuteNonQuery();
            sqlCon.Close();
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    protected void btnBack_Click(object sender, EventArgs e)
    {
        if (Session["UrlRef"] != null)
            Response.Redirect(Session["UrlRef"].ToString(), false);
        else
            Response.Redirect("~/JobOrder/JobOrder.aspx", false);
    }
    protected void gridReceived_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            LinkButton lnkRef = (LinkButton)e.Row.FindControl("lnkRec");
            Label txtDocType = (Label)e.Row.FindControl("RectxtDocType");
            Label txtDate = (Label)e.Row.FindControl("RectxtDate");
            TextBox txtDocID = (TextBox)e.Row.FindControl("RectxtDocID");
            Label lblOpenRef = (Label)e.Row.FindControl("ReclblOpenDocRef");
            Label lblCloseRef = (Label)e.Row.FindControl("ReclblClosedDocRef");
            Control ctrlReceiveCreateUser = e.Row.FindControl("divRecCreateUserID");
            Control ctrlReceiveOriginContactID = e.Row.FindControl("divRecOriginContactID");

            Control ctrlSuperseded = e.Row.FindControl("divRecSuperseded");

            Label lblSuperseded = (Label)e.Row.FindControl("lblSuperseded");
            HtmlGenericControl htmlCtrlSuperseded = ctrlSuperseded as HtmlGenericControl;
            HtmlGenericControl htmlCtrlctrlReceiveOriginContactID = ctrlReceiveOriginContactID as HtmlGenericControl;
            HtmlGenericControl htmlCtrlReceiveCreateUser = ctrlReceiveCreateUser as HtmlGenericControl;

            string strDocID = txtDocID.Text;
            string strOpenRef = lblOpenRef.Text;
            string strCloesdRef = lblCloseRef.Text;

            LinkButton lnkView = (LinkButton)e.Row.FindControl("RecbtnDelete");
            if (lblSuperseded.Text.Equals("True"))
            {

                e.Row.Cells[3].BackColor = System.Drawing.Color.WhiteSmoke;
                e.Row.Cells[3].ForeColor = System.Drawing.Color.Gray;

                e.Row.Cells[4].BackColor = System.Drawing.Color.WhiteSmoke;
                e.Row.Cells[4].ForeColor = System.Drawing.Color.Gray;

                // for superseeded
                if (htmlCtrlReceiveCreateUser.InnerText.Equals(Session["UserID"].ToString()) || htmlCtrlctrlReceiveOriginContactID.InnerText.Equals(Session["UserID"].ToString()) || Session["UserProfileID"].ToString().Equals("1"))
                {
                    if (lnkRef != null)
                    {
                        lnkRef.Enabled = true;
                        lnkRef.Font.Underline = true;
                    }
                }
                else
                {
                    lnkRef.Enabled = false;
                    lnkRef.Font.Underline = false;
                    lnkRef.ForeColor = System.Drawing.Color.Gray;

                    e.Row.Cells[2].BackColor = System.Drawing.Color.WhiteSmoke;
                    e.Row.Cells[2].ForeColor = System.Drawing.Color.Black;
                }
            }

            if (strDocID.Equals(strOpenRef) || (strDocID.Equals(strCloesdRef)))
            {
                lnkView.ForeColor = System.Drawing.Color.White;
            }
            else
            {
                lnkView.Attributes.Add("onclick", "javascript:return " + "confirm('This will delete this document from this Job Order.')");
                lnkView.CssClass = "RecbtnDelete";
            }

            Session["DocDelete"] = "1";
        }
    }
    protected void btnReply_Click(object sender, EventArgs e)
    {
        Session["referenceNo"] = null;
        CloseJob();
    }
    private void CloseJob()
    {
        string strUpdateJob = Request.Url.AbsoluteUri;
        
        Session["UrlRef"] = strUpdateJob;
        Session["JobID"] = _jobID;

        AccessRightsForReply();
        if ((checkJobStatusCompleteDate(_jobID) == "") & (!userRightsColl.Contains("9")))
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Request Status is still In Progress. Please update the Request Status before closing this Job Order.')</script>", false);
        }
        else
        {
            ReplytoCloseCommittedJobs(_jobID);
        }
    }
    private string checkJobStatusCompleteDate(int _jobID)
    {
        string jobStatusClosedDate = string.Empty;
        SqlConnection sqlConn = new SqlConnection(connValue);
        string sqlQuery = "SELECT jobStatusClosedDate From Job Where jobID = '" + _jobID + "' ";

        try
        {
            sqlConn.Open();
            SqlCommand sqlCom = new SqlCommand(sqlQuery, sqlConn);
            SqlDataReader sqlReader = sqlCom.ExecuteReader();
            while (sqlReader.Read())
            {
                jobStatusClosedDate = sqlReader["jobStatusClosedDate"].ToString();
            }
            sqlReader.Close();
        }
        catch (Exception ex)
        {
            Response.Write("Error getting while reading data !" + ex.Message);
        }
        finally
        {
            sqlConn.Close();
        }
        return jobStatusClosedDate;
    }
    private void ReplytoCloseCommittedJobs(int jobid)
    {
        if (userRightsColl.Contains("9"))   //Add New Document
        {
            Session["lblText"] = "You are not allowed to directly Reply and Close a Job Order.Please contact system Administrator for further inquiry.";
            Session["lblSub"] = "Restricted Access to Reply and Close a Job Order.";
            Session["lblBody"] = "This is in reference to Restricted Access to Reply and Close a Job Order. I would like to inquire about the restriction.";

            string url = "RestrictedMsgWindow.aspx";
            string s = "window.open('" + url + "', 'popup_window', 'width=500,height=250,left=100,top=100,resizable=yes,scrollbars=yes');";
            ClientScript.RegisterStartupScript(this.GetType(), "script", s, true);
        }
        else
        {
            if (getJobStatusClosingDate())      //if (Convert.ToBoolean(getJobStatusClosingDate)==true)
            {
                // Session["UrlRef"] = "~/JobOrder/JobOrder.aspx";

               // Session["UrlRef"] = "~/DCLog/DCDetails.aspx";
                Session["JobID"] = jobid;
                Response.Redirect("~/Documents/DocumentDetailsWindow.aspx?RecSentCatID=2&Reply=1", false);
            }
            else
            {
                ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('The job order is not yet completed. Please update the Job Order Status before closing the job.')</script>", false);
            }
        }
    }
    private Boolean getJobStatusClosingDate()
    {
        //jobStatusClosedDate

        return true;
    }

    private void AccessRightsForReply()
    {
        if (userRightsColl.Contains("9"))   //Add New Project
        {
            Session["lblText"] = "You are not allowed to directly Reply and Close a Job Order.Please contact system Administrator for further inquiry.";
            Session["lblSub"] = "Restricted Access to Reply and Close a Job Order.";
            Session["lblBody"] = "This is in reference to Restricted Access to Reply and Close a Job Order. I would like to inquire about the restriction.";


            string url = "RestrictedMsgWindow.aspx";
            string s = "window.open('" + url + "', 'popup_window', 'width=500,height=250,left=100,top=100,resizable=yes,scrollbars=yes');";
            ClientScript.RegisterStartupScript(this.GetType(), "script", s, true);
        }

        return;
    }
    protected void gvDistribution_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            DropDownList l = (DropDownList)e.Row.FindControl("ddljobtype0");

            PopulateDropDownBox(l, "SELECT JobStatusid,JobStatusName as JobStatus FROM jobStatus where JobStatusid in(1,2,3,4) ", "JobStatusid", "JobStatus");  // where JobStatusid in(5,6,7,8)

            TextBox lm = (TextBox)e.Row.FindControl("jobid");
            TextBox afr = (TextBox)e.Row.FindControl("TextBox1");
            TextBox InchargeID = (TextBox)e.Row.FindControl("txtInchargeID");

            Session["InchargeID"] = InchargeID.Text;

            string lk = lm.Text;
            l.ToolTip = InchargeID.Text;

            l.SelectedValue = afr.Text;

            Session["StatusVal"] = l.SelectedValue;

            l.SelectedIndexChanged += new EventHandler(SelectedIndexChanged);

            TextBox txtdate = (TextBox)e.Row.FindControl("lblJoindate");            // ActionDueDate 
            txtdate.ToolTip = InchargeID.Text;
            txtdate.TextChanged += new EventHandler(txtdate_TextChanged);
            Session["JobActionDueDate"] = txtdate.Text;

            System.Web.UI.WebControls.CheckBox chkstate = (System.Web.UI.WebControls.CheckBox)e.Row.FindControl("ad");
            chkstate.ToolTip = InchargeID.Text;
            chkstate.CheckedChanged += new EventHandler(chkstate_CheckedChanged);

            Label lblStaff = (Label)e.Row.FindControl("txtStaff");
            Label lblDistributedBy = (Label)e.Row.FindControl("txtDistrubed");

            System.Web.UI.WebControls.CheckBox chkDelete = (System.Web.UI.WebControls.CheckBox)e.Row.FindControl("deleteRow");
            chkDelete.ToolTip = InchargeID.Text;

            Label lblConactID = (Label)e.Row.FindControl("txtCnctID");
            TextBox _txtDocID = (TextBox)e.Row.FindControl("txtDocID");
            Session["statusdocID"] = _txtDocID.Text;
            Session["contactID"] = lblConactID.Text;

            Label lblDistribID = (Label)e.Row.FindControl("txtDistributedBy");

            //Label lblRoleID = (Label)e.Row.FindControl("txtRoleID");
            // chkDelete.CheckedChanged += new EventHandler(chkstate_CheckedChanged);                        

            if (!lblConactID.Text.Equals(Session["userID"]))
            {
                l.Enabled = false;
                chkstate.Enabled = false;
                // txtdate.Enabled = false;
            }
            if (lblConactID.Text.Equals(Session["userID"]))
            {
                //btnOutlook.Enabled = true;
                Session["ActionDate"] = txtdate.Text;
            }
            if (!lblDistribID.Text.Equals(Session["userID"]))
            {
                txtdate.Enabled = false;
            }
            Label lblIsActive = (Label)e.Row.FindControl("txtisActive");    //txtDistisActive
            if (lblIsActive.Text.Equals("False"))
            {
                HyperLink _lnkStaff = (HyperLink)e.Row.FindControl("lnkStaff"); //
                HyperLink _lnkDistribStaff = (HyperLink)e.Row.FindControl("DistibActive");
                _lnkStaff.Enabled = false;
                //_lnkDistribStaff.Enabled = false;
            }
            Label lblDistIsActive = (Label)e.Row.FindControl("txtDistisActive");
            if (lblDistIsActive.Text.Equals("False"))
            {
                HyperLink _lnkDistribStaff = (HyperLink)e.Row.FindControl("lnkDistirbStaff");
                _lnkDistribStaff.Enabled = false;
            }


            //if (Session["userIsActive"].Equals("True"))
            //{
            //    lblStaff.Enabled = false;
            //}           
        }
    }
    protected void gvDistribution_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandArgument != "")
        {
            int distributeID = Convert.ToInt32(e.CommandArgument);
            switch (e.CommandName)
            {
                case "DeleteDocid":

                    //DeleteDistributionInfo(distributeID);
                    if (flag > 0)
                    {
                        //Response.Write("Link Deactivated with Job");
                    }
                    break;
            }
        }
    }



    protected void gvJoborder_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName.Equals("SelectStaff"))
        {
            string arguments = e.CommandArgument.ToString();
            string[] args = arguments.Split(';');

            IList<string> staffData = new List<string>();
            int roleID = gertRoleID(Convert.ToInt32(args[0]));
            int inchargeID = Convert.ToInt32(args[0]);

            Session["jobNo"] = txtJobNo.Text;

            Session["jobType"] = ddlJobType.SelectedValue;
            Session["contractNo"] = txtCntrNo.Text;

            string url = "AddStaff.aspx?InchargeID=" + inchargeID;
            string s = "window.open('" + url + "', 'popup_window', 'width=700,height=500,left=100,top=100,resizable=yes');";
            Page.ClientScript.RegisterStartupScript(this.GetType(), "script", s, true);

        }
    }
    private int gertRoleID(int inchargeID)
    {
        int roleID = 0;
        using (SqlConnection cn = new SqlConnection(connValue))
        {
            using (SqlCommand cmd = new SqlCommand())
            {
                cmd.Connection = cn;
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "Select StaffRoleID from JobOwner where jobOwnerID =" + inchargeID;

                cn.Open();
                //int roleID = (int)cmd.ExecuteScalar();
                using (SqlDataReader dr = cmd.ExecuteReader())
                {
                    if (dr.HasRows)
                    {
                        while (dr.Read())
                        {
                            roleID = Convert.ToInt32(dr["StaffRoleID"]);
                        }
                    }
                    else
                    {
                        roleID = 0;
                    }
                }
            }
        }
        return roleID;
    }

    
    protected void btnSearchJob_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/DCLog/SearchDCLog.aspx", false);
    }
    public string getPrjCodeAndCntrNO(string commitmentNO,string prjCode,string cntrTypeID)
    {
        string prjCntrNO = string.Empty;

        SqlConnection cnn = new SqlConnection(); 
        cnn.ConnectionString = ConfigurationManager.ConnectionStrings["TCMSConn"].ConnectionString;
        cnn.Open();
        SqlCommand cmm = new SqlCommand();
        cmm.Connection = cnn;
        
        string strQuery = string.Empty;

        if (prjCode == "")
            strQuery = "SELECT  CONTRACTORS.contract_no, PROJECTS.project_code,PROJECTS.contract_type_id FROM CONTRACTORS INNER JOIN   COMPANY ON CONTRACTORS.co_id = COMPANY.co_id INNER JOIN  PROJECTS ON CONTRACTORS.proj_id = PROJECTS.proj_id WHERE (CONTRACTORS.contract_no = '" + commitmentNO + "')";
        else
            strQuery = "SELECT  CONTRACTORS.contract_no, PROJECTS.project_code,PROJECTS.contract_type_id FROM CONTRACTORS INNER JOIN   COMPANY ON CONTRACTORS.co_id = COMPANY.co_id INNER JOIN  PROJECTS ON CONTRACTORS.proj_id = PROJECTS.proj_id WHERE (PROJECTS.project_code = '" + prjCode + "')";

        cmm.CommandText = strQuery;

        SqlDataReader sqlDtReader = cmm.ExecuteReader();
        if (sqlDtReader.HasRows)
        {
            while (sqlDtReader.Read())
            {
                if (txtPrjCode.Text=="")
                    txtPrjCode.Text = sqlDtReader["project_code"].ToString();

                if (txtCntrNo.Text == "")
                    txtCntrNo.Text = sqlDtReader["contract_no"].ToString();

                if (ddlCntrType.SelectedIndex == 0)
                    ddlCntrType.SelectedValue = sqlDtReader["contract_type_id"].ToString(); 
            }
        }

        sqlDtReader.Close();
        cnn.Close();
        return prjCntrNO;
    }
    private void DCApprovedLetter(string refNo) 
    {
        string path = @"C:/temp/" + Session["JobNo"].ToString() + " readme.txt";
                
        if (!File.Exists(path))
        {
            string[] createText = { "SUBJECT:- DC Clearance Certificate ", "PROJECT", "With reference to your letter ref. no. " + refNo + "  dated " + System.DateTime.Now + ", we are pleased to inform you that the requirements for the issuance of the DC clearance certificate for the above mentioned project have been found complete.", " Therefore, the Clearance Certificate has been issued and copy of the original is attached herewith.", "With Regards," };
            File.WriteAllLines(path, createText);
        }

        string appendText = Session["UserName"].ToString() + Environment.NewLine;
        File.AppendAllText(path, appendText);

        Process.Start("notepad.exe", path); // txt file path       
    }
    private void DCNotApprovedLetter(string refNo)
    {
        string path = @"C:/temp/" + Session["JobNo"].ToString() + " readme.txt";

        if (!File.Exists(path))
        {
            string[] createText = { "SUBJECT: - Status of EBD-DC Checklist Items", "PROJECT", "With reference to your letter ref. no. " + refNo + "  dated " + System.DateTime.Now + ", we are pleased to inform you that please be informed that your submission has been reviewed and kindly find attached with this letter the status of the checklist items with our remarks", " Therefore, the Clearance Certificate has been issued and copy of the original is attached herewith.", "With Regards," };
            File.WriteAllLines(path, createText);
        }

        string appendText = Session["UserName"].ToString() + Environment.NewLine;
        File.AppendAllText(path, appendText);

        Process.Start("notepad.exe", path); // txt file path       
    }
    protected void ddlReqType_SelectedIndexChanged(object sender, EventArgs e)
    {
       //  1 - Approved 
        // 2- Not Approved 3 - In Progress	IP 4 -Data Provided	5 - Data Not Available	6 - Records	
                     
        string srcPath = string.Empty;
        string strTemp = string.Empty;
       
        string destPath = string.Empty;

       // lnkDownload.Text = "Create Link";    

        if (ddlReqType.SelectedIndex != 0)
        {          
            Session["lnkJobID"] = _jobID;
            if (ddlReqType.SelectedValue == "1") // Approved  // Just Open Notepad with Subject
            {
                ddlReject.Visible = false;
                tdRej.Visible = false;
                lblDcRej.Visible = false;


                tdRej.Visible = false;
               // lnkDownload.Visible = false;
               // lblReqName.Visible = false;

                UpdateJobStatusDate(_jobID, Convert.ToInt32(ddlReqType.SelectedValue));

              

                Update_RequestStatus();               

               // DCApprovedLetter("xyz");

                string _refNo = getReferenceNo(_jobID);
                Session["refNo"] = _refNo.ToString();

                Session["ChkTYpe"] = "1";
                Session["CntrNo"] = txtCntrNo.Text;
                Session["PrjTitle"] = txtPrjTitle.Text;

                Session["DocIssueDate"] = getDateOfDocument(_jobID); 

                string url = "ApprovedCheckList.aspx";
                string s = "window.open('" + url + "', 'popup_window', 'width=800,height=500,left=100,top=100,resizable=yes');";
                Page.ClientScript.RegisterStartupScript(this.GetType(), "script", s, true);

            }
            else if (ddlReqType.SelectedValue == "2")         // Not Approved
            {
               // Check Row exist in PayCheckList Table

                // Create word Not Approved word file

               // lnkDownload.Visible = false;

                if (IsCheckListApproved(_jobID) == false)
                {
                    ddlReqType.Enabled = true;

                    ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Please Update CheckList First.')</script>", false);
                    return;
                }

                ddlReject.Visible = true;
                lblDcRej.Visible = true;
                tdRej.Visible = true;

                tdRej.Visible = false;
              //  lnkDownload.Visible = false;
               // lblReqName.Visible = false;

                PopulateDropDownBox(ddlReject, "SELECT dcRejectionID, rejectionDesc FROM DCRejection ORDER BY rejectionDesc", "dcRejectionID", "rejectionDesc");

                //srcPath = @"C:\DcChkList\DCNotApprove.docx";
                //strTemp = "C:\\DcChkList_Out\\ " + _jobID + "_" + "DCNotApprove.docx";

                //Session["DCOutPath"] = strTemp;
                //destPath = strTemp;
                //CreateWordDocNew(srcPath, destPath);

                //ReqType.Visible = true;

                //lblReqName.Text = " Down load Link For Request Status  " +  ddlReqType.SelectedItem.Text;

                //lnkDownload.Enabled = true;
                //lnkDownload.Text = "DownLoad_Link";

                Update_RequestStatus();

                UpdateJobStatusDate(_jobID, Convert.ToInt32(ddlReqType.SelectedValue));

                string _refNo = getReferenceNo(_jobID);
                Session["refNo"] = _refNo.ToString();
                Session["ChkTYpe"] = "2";
                Session["CntrNo"] = txtCntrNo.Text;
                Session["PrjTitle"] = txtPrjTitle.Text;

                Session["DocIssueDate"] = getDateOfDocument(_jobID); 

                string url = "ApprovedCheckList.aspx";
                string s = "window.open('" + url + "', 'popup_window', 'width=700,height=500,left=100,top=100,resizable=yes');";
                Page.ClientScript.RegisterStartupScript(this.GetType(), "script", s, true);
            }
            else if (ddlReqType.SelectedValue == "3")       // Inprocess
            {
               // lnkDownload.Visible = false;
               // txtStatusClose.Text = "";
                               

                lblDcRej.Visible = false;
                ddlReject.Visible = false;
                tdRej.Visible = false;


               // lnkDownload.Visible = false;
               // lblReqName.Visible = false;

                ReqType.Visible = false;

                UpdateJobInProcess();

                Update_RequestStatus();
            }
            else if (ddlReqType.SelectedValue == "4")   // Data Provided 
            {
               // lnkDownload.Visible = true;

               // MailNotificationDataProvidedStatus();

                Update_RequestStatus();
                UpdateJobStatusDate(_jobID, Convert.ToInt32(ddlReqType.SelectedValue));

            }
            else if (ddlReqType.SelectedValue == "5")    // Data Not Available
            {
               // MailNotificationForDataNot_Provided();

                ddlReject.Visible = false;
                tdRej.Visible = false;
                lblDcRej.Visible = false;
               
                Update_RequestStatus();  // Looping out when return 
                UpdateJobStatusDate(_jobID, Convert.ToInt32(ddlReqType.SelectedValue));                           
            }
            else if (ddlReqType.SelectedValue == "6")  // Records
            {
                //lnkDownload.Visible = false;
               // lblReqName.Visible = false;

                ReqType.Visible = false;
                Update_RequestStatus();

                UpdateJobStatusDate(_jobID, Convert.ToInt32(ddlReqType.SelectedValue));
            }
            else
            {
                ddlReject.Visible = false;
                tdRej.Visible = false;
                lblDcRej.Visible = false;

                UpdateJobStatusDate(_jobID, Convert.ToInt32(ddlReqType.SelectedValue));

                Update_RequestStatus();
            }          

            Fill_JobOrder_Information(_jobID);
        }
    }
    private void MailNotificationForDataNot_Provided()
    {
        if (ddlPrjCoordinator.SelectedIndex == 0)
        {
            ddlReqType.SelectedValue = Session["old_ReqStatusID"].ToString();

            ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Please update the Project Coordinator.' )</script>", false);
            return;
        }

        string pmName = string.Empty;
        string _eMail = getEmail_PM(ddlPrjCoordinator.SelectedValue, ref pmName);

        if (_eMail == "")
        {
            ddlReqType.SelectedValue = Session["old_ReqStatusID"].ToString();

            ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Please update the Project Coordinator Email Adress.')</script>", false);

            return;
        }

        if (_eMail == "")
        {
            ddlReqType.SelectedValue = Session["old_ReqStatusID"].ToString();
            ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Please update the Project Coordinator Email Adress.')</script>", false);
            return;
        }
        else
        {
            string mailSubject = "Data Request Under Commitment No.: " + txtPrjCode.Text;
            string mailBody = " Dear " + pmName + " , <br/> <br/> With reference to your request, this is to inform you that the data is not available.<br/> <br/> <br/>  Best Regards, <br/>" + Session["LoginUserName"].ToString();
            OutLookAlertToPM(_eMail, mailSubject, mailBody);
        }     

    }
    private void MailNotificationDataProvidedStatus()
    {
        if (ddlPrjCoordinator.SelectedIndex == 0)
        {
            ddlReqType.SelectedValue = Session["old_ReqStatusID"].ToString();

            ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Please update the Project Coordinator.')</script>", false);
            return;
        }

        string pmName = string.Empty;
        string _eMail = getEmail_PM(ddlPrjCoordinator.SelectedValue, ref pmName);

        if (_eMail == "")
        {
            ddlReqType.SelectedValue = Session["old_ReqStatusID"].ToString();
            ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Please update the Project Coordinator Email Adress.')</script>", false);
            return;
        }

        ddlReject.Visible = false;
        tdRej.Visible = false;
        lblDcRej.Visible = false;


        string mailSubject = "Data Request Under Commitment No.:  " + txtPrjCode.Text;         //Abdul Fatah Al Harbi
        string mailBody = "Dear " + pmName + " , <br/> <br/>  With reference to your Request, this is to inform you that the verification of data request for the project is completed. Data requested aforesaid project is available through a CD. Kindly confirm when the data is collected.";

        if (_eMail == "")
        {
            ddlReqType.SelectedValue = Session["old_ReqStatusID"].ToString();

            // SendOutLookMail(mailSubject, mailBody);

            ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Please update the Project Coordinator Email Adress.')</script>", false);
            return;
        }
        else
        {
            // if (!connValue.Contains("eBookProductionDB"))
            OutLookAlertDataProvide(_eMail, mailSubject, mailBody);
        } 
    }
    protected void Update_RequestStatus()
    {
        string upDateQuery = string.Empty;
        upDateQuery = "UPDATE Job SET reqStatusID =@reqStatusID WHERE JobID = @JobID";

        using (SqlConnection sqlCon = new SqlConnection(connValue))
        {
            using (SqlCommand cmd = new SqlCommand())
            {
                cmd.CommandText = upDateQuery;
                cmd.Connection = sqlCon;

                cmd.Parameters.AddWithValue("@JobID", _jobID);         
                cmd.Parameters.AddWithValue("@reqStatusID", ddlReqType.SelectedValue);

                try
                {
                    sqlCon.Open();
                    cmd.ExecuteNonQuery();
                    sqlCon.Close();
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
        }
    }
    private void CreateWordDocNew(Object fileName, object saveAs)
    {
        // IList<string> strDCColl = getDcCkeckListData();

       string _refNo =    getReferenceNo(_jobID);

        object missing = System.Reflection.Missing.Value;
        Microsoft.Office.Interop.Word.Application wordApp = new Microsoft.Office.Interop.Word.ApplicationClass();
        Microsoft.Office.Interop.Word.Document aDoc = null;
        wordApp.Visible = true;
        wordApp.DisplayAlerts = Microsoft.Office.Interop.Word.WdAlertLevel.wdAlertsNone;
        wordApp.DisplayAlerts = WdAlertLevel.wdAlertsNone;

        try
        {
            if (File.Exists((string)fileName))
            {
                object readOnly = false;
                object isVisible = false;
                wordApp.Visible = false;

                aDoc = wordApp.Documents.Open(ref fileName, ref missing, ref readOnly, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref isVisible, ref missing, ref missing, ref missing, ref missing);
                //aDoc.Activate();    

                if (aDoc.Bookmarks.Exists("txtContractNo"))
                {
                    Microsoft.Office.Interop.Word.Bookmark bm = aDoc.Bookmarks["txtContractNo"];
                    Microsoft.Office.Interop.Word.Range range = bm.Range.Duplicate;
                    aDoc.FormFields["txtContractNo"].Result = txtCntrNo.Text;
                }
                if (aDoc.Bookmarks.Exists("txtDocREF"))
                {
                    Microsoft.Office.Interop.Word.Bookmark bm = aDoc.Bookmarks["txtDocREF"];
                    Microsoft.Office.Interop.Word.Range range = bm.Range.Duplicate;
                    aDoc.FormFields["txtDocREF"].Result = _refNo;
                }               
                if (aDoc.Bookmarks.Exists("txtDocDate"))
                {
                    Microsoft.Office.Interop.Word.Bookmark bm = aDoc.Bookmarks["txtDocDate"];
                    Microsoft.Office.Interop.Word.Range range = bm.Range.Duplicate;
                    aDoc.FormFields["txtDocDate"].Result = System.DateTime.Now.Date.ToShortDateString();
                } 
            }
            else
            {
                //Response.Write("Source File is Not exist");
                return;
            }

            aDoc.SaveAs(ref saveAs, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing);

            object saveChanges = Microsoft.Office.Interop.Word.WdSaveOptions.wdPromptToSaveChanges;
            object originalFormat = Microsoft.Office.Interop.Word.WdOriginalFormat.wdWordDocument;
            object routeDocument = true;

            object missingValue = Type.Missing;

            ((Microsoft.Office.Interop.Word._Document)aDoc).Close(ref saveChanges, ref originalFormat, ref routeDocument);
            ((Microsoft.Office.Interop.Word._Application)wordApp.Application).Quit(ref missingValue, ref missingValue, ref missingValue);

        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (aDoc != null)
                System.Runtime.InteropServices.Marshal.ReleaseComObject(aDoc);

            if (wordApp != null)
                System.Runtime.InteropServices.Marshal.ReleaseComObject(wordApp);

            wordApp = null;
            aDoc = null;
            GC.Collect();
            GC.WaitForPendingFinalizers();
        }
    }
    private string getReferenceNo(int jobID)
    {
        string strRefNo = string.Empty;
        try
        {
            SqlConnection sqlConn = new SqlConnection(connValue);
            sqlConn.Open();
            SqlCommand sqlCom = new SqlCommand("Select referenceNo from Document where JobID = " + jobID + "", sqlConn);
            SqlDataReader sqlReader = sqlCom.ExecuteReader();
            while (sqlReader.Read())
            {
                strRefNo = sqlReader["referenceNo"].ToString();
            }
            sqlReader.Close();
            sqlConn.Close();
        }
        catch (System.Exception ex)
        {
            throw ex;
        }
        return strRefNo;
    }

    private string getDateOfDocument(int jobID)
    {
        string strRefNo = string.Empty;
        try
        {
            SqlConnection sqlConn = new SqlConnection(connValue);
            sqlConn.Open();
            SqlCommand sqlCom = new SqlCommand("Select docDate from Document where JobID = " + jobID + "", sqlConn);
            SqlDataReader sqlReader = sqlCom.ExecuteReader();
            
            while (sqlReader.Read())
            {
                strRefNo = Convert.ToDateTime(sqlReader["docDate"]).ToString("dd/MMM/yyyy");
            }

            sqlReader.Close();
            sqlConn.Close();
        }
        catch (System.Exception ex)
        {
            throw ex;
        }
        return strRefNo;
    }


    private Boolean IsCheckListApproved(int jobID)
    {
        Boolean isUpdated = false;
        try
        {
            SqlConnection sqlConn = new SqlConnection(connValue);
            sqlConn.Open();
            SqlCommand sqlCom = new SqlCommand("Select isUpdate from DcCheckList where JobID = " + jobID + "", sqlConn);
            SqlDataReader sqlReader = sqlCom.ExecuteReader();
            while (sqlReader.Read())
            {
                if (sqlReader["isUpdate"].ToString().Equals("True"))
                {
                    isUpdated = true;
                }
            }
            sqlReader.Close();
            sqlConn.Close();
        }
        catch (System.Exception ex)
        {
            throw ex;
        }
        return isUpdated;
    }
    protected void UpdateJobCompleteDate()
    {
        string upDateQuery = string.Empty;
        upDateQuery = "UPDATE Job SET jobStatusID =@jobStatusID,jobStatusClosedDate=@jobStatusClosedDate,reqStatusID =@reqStatusID WHERE JobID = @JobID";

        using (SqlConnection sqlCon = new SqlConnection(connValue))
        {
            using (SqlCommand cmd = new SqlCommand())
            {
                cmd.CommandText = upDateQuery;
                cmd.Connection = sqlCon;

                cmd.Parameters.AddWithValue("@JobID", _jobID);
                cmd.Parameters.AddWithValue("@dcRejectionID", ddlReject.SelectedValue);
                cmd.Parameters.AddWithValue("@jobStatusClosedDate", System.DateTime.Now.ToString("dd/MMM/yyyy"));
                cmd.Parameters.AddWithValue("@jobStatusID", 7);
                cmd.Parameters.AddWithValue("@reqStatusID", ddlReqType.SelectedValue);

                try
                {
                    sqlCon.Open();
                    cmd.ExecuteNonQuery();
                    sqlCon.Close();
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
        }      
    }
    protected void UpdateJobInProcess()
    {
        string upDateQuery = string.Empty;
        upDateQuery = "UPDATE Job SET jobStatusID =@jobStatusID,jobStatusClosedDate=@jobStatusClosedDate,reqStatusID =@reqStatusID WHERE JobID = @JobID";

        using (SqlConnection sqlCon = new SqlConnection(connValue))
        {
            using (SqlCommand cmd = new SqlCommand())
            {
                cmd.CommandText = upDateQuery;
                cmd.Connection = sqlCon;

                cmd.Parameters.AddWithValue("@JobID", _jobID);
                cmd.Parameters.AddWithValue("@dcRejectionID", ddlReject.SelectedValue);

                cmd.Parameters.AddWithValue("@jobStatusClosedDate", System.DBNull.Value);

                cmd.Parameters.AddWithValue("@jobStatusID", 3);
                cmd.Parameters.AddWithValue("@reqStatusID", ddlReqType.SelectedValue);

                try
                {
                    sqlCon.Open();
                    cmd.ExecuteNonQuery();
                    sqlCon.Close();
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
        }
    }
    private void OutLookAlertDataProvide(string eMail, string subject, string mailBody)
    {
        //string mailSubject = "Data Request Under Commitment No.: C2017/000 ";
        //string mailBody = "Dear Abdul Fatah Al Harbi, With reference to your request, this is to inform you that the data is not available. Best regards,   Eng. Maryam Jusaimani";     

        SmtpClient smtpclient = new SmtpClient("10.250.50.201", 587);
        System.Net.Mail.MailMessage mail = new System.Net.Mail.MailMessage();

        MailAddress fromaddress = new MailAddress("EBSD@ashghal.gov.qa");
        mail.From = fromaddress;
        mail.To.Add(eMail);

       // mail.To.Add("ajabinal@ashghal.gov.qa");

        mail.Subject = (subject);
        mail.IsBodyHtml = true;

        mail.Body = mailBody;       

        smtpclient.EnableSsl = true;
        smtpclient.UseDefaultCredentials = true;

        try
        {
            smtpclient.Credentials = new System.Net.NetworkCredential(@"Ashghal\EBSD", ConfigurationManager.AppSettings["passWordForReport"].ToString()); 
            ServicePointManager.ServerCertificateValidationCallback = delegate(object s, X509Certificate certificate, X509Chain chain, SslPolicyErrors sslPolicyErrors) { return true; };
            smtpclient.Send(mail);
        }
        catch (System.Exception ex)
        {
            Console.WriteLine(ex);
            if (ex.InnerException != null)
            {
                Console.WriteLine("InnerException is: {0}", ex.InnerException);
            }
        }
        finally
        {
            mail.Dispose();
            mail = null;
            smtpclient = null;
        }
    }
    private void OutLookAlert(string eMail,string subject,string mailBody)
    {
        //string mailSubject = "Data Request Under Commitment No.: C2017/000 ";
        //string mailBody = "Dear Abdul Fatah Al Harbi, With reference to your request, this is to inform you that the data is not available. Best regards,   Eng. Maryam Jusaimani";     

        SmtpClient smtpclient = new SmtpClient("10.250.50.201", 587);
        System.Net.Mail.MailMessage mail = new System.Net.Mail.MailMessage();
        
        MailAddress fromaddress = new MailAddress("EBSD@ashghal.gov.qa");
        mail.From = fromaddress;
        mail.To.Add(eMail);
        
        //mail.To.Add("ajabinal@ashghal.gov.qa");

        mail.Subject = (subject);
        mail.IsBodyHtml = true;

           // mail.Body = "Please be informed that a new Job Order was assigned to you under the above subject. Please log on to eBook Application to see the details of the Job Order.";

        mail.Body = "<html><body><i style='font-family:Calibri; font-size:15'>Dear eBook Team,</i><br/><br/><i style='font-family:Calibri; font-size:15'>This is an automated alert from Document & Task Management System.</i><br/><br/><i style='font-family:Calibri;font-size:15'>" +
                         "Please be noted that</i><i style='color:Maroon;font-family:Calibri; font-size:15'>  </i><i style='font-family:Calibri; font-size:15'>  " + mailBody + " :-</i><br /><br />" +
                         "<table style='width:80%' border='1'><tr><td align='center' colspan='2' style='background-color:Maroon;color:White;font-family:Calibri;font-size:18;font-weight:bold'> JOB NO: " + Session["jobNo"].ToString() + "</td>" +
                         "</tr><tr><td style='background-color:#B58AA5;font-family:Calibri;font-size:15'><i>Contract No / Project Code </i></td><td style='font-family:Calibri;font-size:15'> " + txtPrjCode.Text + " </td></tr>" +
                         "<tr><td style='background-color:#B58AA5;font-family:Calibri;font-size:15'><i>eBook URL</i></td><td style='font-family:Calibri;font-size:15'>  http://mv2ebdbookp01/eBook/LoginPage.aspx </td></tr>" +
                         "<tr><td style='background-color:#B58AA5;font-family:Calibri;font-size:15'><i>Date of Creation</i></td><td style='font-family:Calibri;font-size:15'>" + System.DateTime.Now + "</td></tr>" +
                         "</table><br/><br/><div style='font-family:Calibri; font-size:15'>Best Regards,<br/>eBook Team</div></body></html>";
        
       
        smtpclient.EnableSsl = true;
        smtpclient.UseDefaultCredentials = true;

        try
        {
            smtpclient.Credentials = new System.Net.NetworkCredential(@"Ashghal\EBSD", ConfigurationManager.AppSettings["passWordForReport"].ToString()); // e
            ServicePointManager.ServerCertificateValidationCallback = delegate(object s, X509Certificate certificate, X509Chain chain, SslPolicyErrors sslPolicyErrors) { return true; };
            smtpclient.Send(mail);
        }
        catch (System.Exception ex)
        {
            Console.WriteLine(ex);
            if (ex.InnerException != null)
            {
                Console.WriteLine("InnerException is: {0}", ex.InnerException);
            }
        }
        finally
        {
            mail.Dispose();
            mail = null;
            smtpclient = null;
        }
    }


    private void OutLookAlertToPM(string eMail, string subject, string mailBody)
    {
        
        SmtpClient smtpclient = new SmtpClient("10.250.50.201", 587);
        System.Net.Mail.MailMessage mail = new System.Net.Mail.MailMessage();

        MailAddress fromaddress = new MailAddress("EBSD@ashghal.gov.qa");
        mail.From = fromaddress;

         mail.To.Add(eMail);


        mail.Subject = (subject);

        mail.IsBodyHtml = true;
        mail.Body = mailBody;
       
        smtpclient.EnableSsl = true;
        smtpclient.UseDefaultCredentials = true;

        try
        {
            smtpclient.Credentials = new System.Net.NetworkCredential(@"Ashghal\EBSD", ConfigurationManager.AppSettings["passWordForReport"].ToString()); //f
            ServicePointManager.ServerCertificateValidationCallback = delegate(object s, X509Certificate certificate, X509Chain chain, SslPolicyErrors sslPolicyErrors) { return true; };
            smtpclient.Send(mail);
        }
        catch (System.Exception ex)
        {
            Console.WriteLine(ex);
            if (ex.InnerException != null)
            {
                Console.WriteLine("InnerException is: {0}", ex.InnerException);
            }
        }
        finally
        {
            mail.Dispose();
            mail = null;
            smtpclient = null;
        }
    }
    private string getEmail(string contactID)
    {
        string streMail = string.Empty;
        try
        {
            SqlConnection sqlConn = new SqlConnection(connValue);
            sqlConn.Open();
            SqlCommand sqlCom = new SqlCommand("Select emailAddress from Contact where ContactID = " + Convert.ToInt32(contactID) + "", sqlConn);
            SqlDataReader sqlReader = sqlCom.ExecuteReader();
            while (sqlReader.Read())
            {
                streMail = sqlReader["emailAddress"].ToString();
            }
            sqlReader.Close();
            sqlConn.Close();
        }
        catch (System.Exception ex)
        {
            throw ex;
        }

        return streMail;
    }
    private string getEmail_PM(string contactID,ref string pmName)
    {
        string streMail = string.Empty;
        try
        {
            SqlConnection sqlConn = new SqlConnection(connValue);
            sqlConn.Open();
            SqlCommand sqlCom = new SqlCommand("Select eMail,coordName from ProjCoordinator where prjCoordID = " + Convert.ToInt32(contactID) + "", sqlConn);
            SqlDataReader sqlReader = sqlCom.ExecuteReader();
            
            while (sqlReader.Read())
            {
                streMail = sqlReader["eMail"].ToString();
                pmName = sqlReader["coordName"].ToString();
            }

            sqlReader.Close();
            sqlConn.Close();
        }
        catch (System.Exception ex)
        {
            throw ex;
        }

        return streMail;
    }
    
    
    public void UpdateJobStatusByUserSelection(int _jobID, int statusID)
    {
        string upDateQuery = string.Empty;
       
            upDateQuery = "UPDATE Job SET jobStatusID =@jobStatusID WHERE JobID = @JobID";          // jobClosedDate =@jobClosedDate,


        using (SqlConnection sqlCon = new SqlConnection(connValue))
        {
            using (SqlCommand cmd = new SqlCommand())
            {
                cmd.CommandText = upDateQuery;
                cmd.Connection = sqlCon;

                cmd.Parameters.AddWithValue("@JobID", _jobID);
                cmd.Parameters.AddWithValue("@jobStatusID", statusID);

                try
                {
                    sqlCon.Open();
                    cmd.ExecuteNonQuery();                    
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
        }
    }
    public void UpdateJobStatuCompletedsDate(int _jobID, int statusID)
    {
        string upDateQuery = string.Empty;

        upDateQuery = "UPDATE Job SET jobStatusID =@jobStatusID,jobStatusClosedDate=@jobStatusClosedDate WHERE JobID = @JobID";          // jobClosedDate =@jobClosedDate,


        SqlConnection sqlCon = new SqlConnection(connValue);
        SqlCommand cmd = new SqlCommand();
        cmd.CommandText = upDateQuery;
        cmd.Connection = sqlCon;

        cmd.Parameters.AddWithValue("@JobID", _jobID);


        if (statusID == 3) // On going
            cmd.Parameters.AddWithValue("@jobStatusClosedDate", System.DBNull.Value);
        else
            cmd.Parameters.AddWithValue("@jobStatusClosedDate", System.DateTime.Now.ToString("dd/MMM/yyyy"));
       
        if (statusID == 3)
            cmd.Parameters.AddWithValue("@jobStatusID", 3);
        else
            cmd.Parameters.AddWithValue("@jobStatusID", 7);       

        try
        {
            sqlCon.Open();
            cmd.ExecuteNonQuery();
            sqlCon.Close();
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    public void UpdateJobStatusDate(int _jobID, int statusID)
    {
        string upDateQuery = string.Empty;

        if (statusID == 3)     // ongoing       
            upDateQuery = "UPDATE Job SET jobClosedDate =@jobClosedDate,jobStatusID =@jobStatusID,jobStatusClosedDate=@jobStatusClosedDate,closedDocRefID=@closedDocRefID,reqStatusID =@reqStatusID WHERE JobID = @JobID";
        else
            upDateQuery = "UPDATE Job SET jobStatusID =@jobStatusID,jobStatusClosedDate=@jobStatusClosedDate,reqStatusID =@reqStatusID  WHERE JobID = @JobID";          // jobClosedDate =@jobClosedDate,


        SqlConnection sqlCon = new SqlConnection(connValue);
        SqlCommand cmd = new SqlCommand();
        cmd.CommandText = upDateQuery;
        cmd.Connection = sqlCon;

        cmd.Parameters.AddWithValue("@JobID", _jobID);

      
        if (statusID == 3) // On going
            cmd.Parameters.AddWithValue("@jobStatusClosedDate", System.DBNull.Value);
        else 
            cmd.Parameters.AddWithValue("@jobStatusClosedDate", System.DateTime.Now.ToString("dd/MMM/yyyy"));

        if (statusID == 3)
        {
            cmd.Parameters.AddWithValue("@closedDocRefID", System.DBNull.Value);
            cmd.Parameters.AddWithValue("@jobClosedDate", System.DBNull.Value);
        }

        if (statusID == 3)
           cmd.Parameters.AddWithValue("@jobStatusID", 3);
        else
           cmd.Parameters.AddWithValue("@jobStatusID", 7);

        cmd.Parameters.AddWithValue("@reqStatusID", statusID);

        try
        {
            sqlCon.Open();
            cmd.ExecuteNonQuery();
            sqlCon.Close();
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    protected void ddlReject_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlReject.SelectedValue != "")
        {
            string upDateQuery = string.Empty;
            upDateQuery = "UPDATE Job SET dcRejectionID =@dcRejectionID,jobStatusID =@jobStatusID,jobStatusClosedDate=@jobStatusClosedDate,reqStatusID =@reqStatusID WHERE JobID = @JobID";

            using (SqlConnection sqlCon = new SqlConnection(connValue))
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.CommandText = upDateQuery;
                    cmd.Connection = sqlCon;

                    cmd.Parameters.AddWithValue("@JobID", _jobID);

                    if (ddlReject.SelectedIndex !=0)
                       cmd.Parameters.AddWithValue("@dcRejectionID", ddlReject.SelectedValue);
                    else
                       cmd.Parameters.AddWithValue("@dcRejectionID", System.DBNull.Value);

                    cmd.Parameters.AddWithValue("@jobStatusClosedDate", System.DateTime.Now.ToString("dd/MMM/yyyy"));
                    cmd.Parameters.AddWithValue("@jobStatusID", 7);

                    if (ddlReqType.SelectedIndex != 0)
                        cmd.Parameters.AddWithValue("@reqStatusID", ddlReqType.SelectedValue);
                    else
                        cmd.Parameters.AddWithValue("@reqStatusID", System.DBNull.Value);

                   

                    try
                    {
                        sqlCon.Open();
                        cmd.ExecuteNonQuery();
                        sqlCon.Close();
                    }
                    catch (Exception ex)
                    {
                        throw ex;
                    }
                }
            }

            Fill_JobOrder_Information(_jobID);
        }
    }
    
    private void SurveyReply()
    {
        if (txtSurveyReply.Text != "")
        {
            DateTime fromDate = Convert.ToDateTime(txtSurveyReply.Text);
            DateTime toDate = Convert.ToDateTime(txtSentOnSurvey.Text);

            DateTime dt = DateTime.Parse(fromDate.ToShortDateString());
            DateTime dt1 = DateTime.Parse(toDate.ToShortDateString());

            double noOfDays = dt.Subtract(dt1).TotalDays;

            if (Convert.ToInt16(noOfDays) < 0)
            {
                txtSurveyReply.Text = "";
                ClientScript.RegisterClientScriptBlock(this.GetType(), "Popup", "<script>alert(': Survey Team Reply Date cannot be less than Sent to Survey Team Date.')</script>", false);
                return;
            }
        }

        UpdateSurveyStaff(202, txtSurveyReply.Text);      // 202 - SurveyQSID

        UpdateAttachedSurveyDate();

        //UpdateJobOwnerStatus();

        Fill_JobOrder_Information(_jobID);

        gvJoborder.DataSource = new JobOrderData().GetJobOwnerDetails(_jobID);
        gvJoborder.DataBind();
    }
    private void UpdateSurveyStaff(int surveyQSID,string completionDate)
    {
        string upDateQuery = string.Empty;
        upDateQuery = "UPDATE JobOwner SET jobOwnerStatusID = @jobOwnerStatusID,completionDate =@completionDate, jobDone =@jobDone  WHERE JobID = @JobID and contactID = " + surveyQSID + "";

        using (SqlConnection sqlCon = new SqlConnection(connValue))
        {
            using (SqlCommand cmd = new SqlCommand())
            {
                cmd.CommandText = upDateQuery;
                cmd.Connection = sqlCon;

                cmd.Parameters.AddWithValue("@JobID", _jobID);

                if (txtSurveyReply.Text != "")
                {
                    cmd.Parameters.AddWithValue("@jobOwnerStatusID", 7);
                    cmd.Parameters.AddWithValue("@completionDate", Convert.ToDateTime(txtSurveyReply.Text).ToString("dd/MMM/yyyy"));
                    cmd.Parameters.AddWithValue("@jobDone", 1);
                }
                else
                {
                    cmd.Parameters.AddWithValue("@jobOwnerStatusID", 3);
                    cmd.Parameters.AddWithValue("@completionDate", System.DBNull.Value);
                    cmd.Parameters.AddWithValue("@jobDone", 0);   
                }

                try
                {
                    sqlCon.Open();
                    cmd.ExecuteNonQuery();
                    sqlCon.Close();
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
        }
    }
    private void UpdateAttachedSurveyDate()
    {
        string upDateQuery = string.Empty;
        upDateQuery = "UPDATE Job SET receivedBySurveyTeamDC = @receivedBySurveyTeamDC  WHERE JobID = @JobID";

        using (SqlConnection sqlCon = new SqlConnection(connValue))
        {
            using (SqlCommand cmd = new SqlCommand())
            {
                cmd.CommandText = upDateQuery;
                cmd.Connection = sqlCon;

                cmd.Parameters.AddWithValue("@JobID", _jobID);
                
                if (txtSurveyReply.Text !="")
                    cmd.Parameters.AddWithValue("@receivedBySurveyTeamDC", Convert.ToDateTime(txtSurveyReply.Text).ToString("dd/MMM/yyyy"));
                else
                    cmd.Parameters.AddWithValue("@receivedBySurveyTeamDC", System.DBNull.Value);

                try
                {
                    sqlCon.Open();
                    cmd.ExecuteNonQuery();
                    sqlCon.Close();
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
        }
    }
    private void UpdateJobOwnerStatus(string strCmpleteDate)
    {
        string upDateQuery = string.Empty;
        upDateQuery = "UPDATE JobOwner SET jobOwnerStatusID = @jobOwnerStatusID,completionDate = @completionDate  WHERE JobID = @JobID";

        using (SqlConnection sqlCon = new SqlConnection(connValue))
        {
            using (SqlCommand cmd = new SqlCommand())
            {
                cmd.CommandText = upDateQuery;
                cmd.Connection = sqlCon;

                cmd.Parameters.AddWithValue("@JobID", _jobID);

                if (txtSurveyReply.Text != "")
                    cmd.Parameters.AddWithValue("@jobOwnerStatusID", 7);
                else
                    cmd.Parameters.AddWithValue("@jobOwnerStatusID", System.DBNull.Value);

                cmd.Parameters.AddWithValue("@completionDate", Convert.ToDateTime(strCmpleteDate).ToString("dd/MMM/yyyy"));

                try
                {
                    sqlCon.Open();
                    cmd.ExecuteNonQuery();
                    sqlCon.Close();
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
        }
    }
    protected void btnCheckListDC_Click(object sender, EventArgs e)
    {
        int cntrTypeID = 1;

        if (ddlCntrType.SelectedIndex!=0)
          cntrTypeID = Convert.ToInt32(ddlCntrType.SelectedValue);

        if (ddlCntrType.SelectedIndex == 0)
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "Popup", "<script>alert('Please update Contract Type before update CheckList.')</script>", false);
            return;
        }

        try
        {
            string strUpdateJob = Request.Url.AbsoluteUri;
            Session["UrlRef"] = strUpdateJob;

            Session["ChkListPayID"] = _jobID;

            Session["CntrTypeChk"] = ddlCntrType.SelectedValue;
            Session["PayForChk"] = ddlCntrType.SelectedValue;

            int chkListType = 0;
            if ((Session["CntrTypeChk"].ToString().Equals("1")) || (Session["CntrTypeChk"].ToString().Equals("2")))
            {
                chkListType = 1;
            }
            else if (Session["CntrTypeChk"].ToString().Equals("5"))
            {
                chkListType = 5;
            }
            else if (Session["CntrTypeChk"].ToString().Equals("6"))
            {
                chkListType = 6;
            }
            else
            {
                chkListType = 10;
            }

            if (!CheckListDataExist(chkListType))
            {
                IList<int> listData = ReadListDisc(Convert.ToInt16(chkListType));
                InsertCheckListData(listData, chkListType);
            }
        }
        catch (Exception ex)
        {
            
            throw ex;
        }  

        Response.Redirect("~/DCLog/DCChkList.aspx", false);

        //string url = "/eBook/DcCheckList.aspx";
        //string s = "window.open('" + url + "', 'popup_window', 'width=960,height=600,left=100,top=100,resizable=yes,scrollbars=yes');";
        //ClientScript.RegisterStartupScript(this.GetType(), "script", s, true);    
    }
    private void InsertCheckListData(IList<int> listData, int chkListType)
    {
        string upDateQuery = string.Empty;

        //int value_1 = 1; int value_2 = 1; int value_3 = 1; int value_4 = 1; int value_5 = 1;
        //int value_6 = 1; int value_7 = 1; int value_8 = 1; int value_9 = 1; int value_10 = 1;
        //int value_11 = 1; int value_12 = 1; int value_13 = 1; int value_14 = 1; int value_15 = 1;
        //int value_16 = 1; int value_17 = 1; int value_18 = 1;       

        //dcCheckID - AutoNo     //createDate
        //upDateQuery = "INSERT INTO DcCheckList(jobID,check1,check2,check3,check4,check5,check6,check7,check8,check9,check10,check11,check12,check13,check14,check15,check16,check17,check18,createUser,isUpdate,listTypeID) " +
        //                               "Values(" + _jobID + "," + value_1 + "," + value_2 + "," + value_3 + "," + value_4 + "," + value_5 + "," + value_6 + "," + value_7 + "," + value_8 + "," + value_9 + "," + value_10 + "," + value_11 + "," + value_12 + "," + value_13 + "," + value_14 + "," + value_15 + "," + value_16 + "," + value_17 + "," + value_18 + ",'" + Session["UserName"].ToString() + "'," + 1 + "," + ddlCntrType.SelectedValue + ")";

        
        upDateQuery = "INSERT INTO DcCheckList(jobID,check1,check2,check3,check4,check5,check6,check7,check8,check9,check10,check11,check12,check13,check14,check15,check16,check17,check18,createUser,isUpdate,listTypeID) " +
                                     "Values(" + _jobID + "," + listData[0] + "," + listData[1] + "," + listData[2] + "," + listData[3] + "," + listData[4] + "," + listData[5] + "," + listData[6] + "," + listData[7] + "," + listData[8] + "," + listData[9] + "," + listData[10] + "," + listData[11] + "," + listData[12] + "," + listData[13] + "," + listData[14] + "," + listData[15] + "," + listData[16] + "," + listData[17] + ",'" + Session["UserName"].ToString() + "'," + 1 + "," + chkListType + ")";

        using (SqlConnection sqlCon = new SqlConnection(connValue))
        {
            using (SqlCommand cmd = new SqlCommand())
            {
                cmd.CommandText = upDateQuery;
                cmd.Connection = sqlCon;                

                try
                {
                    sqlCon.Open();
                    cmd.ExecuteNonQuery();
                    sqlCon.Close();
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
        }
    }
    private Boolean CheckListDataExist(int listTypeID)
    {
        Boolean checkExist = false;
        string sqlQuery = "SELECT jobID FROM  DcCheckList WHERE (jobID = " + _jobID + ") and listTypeID = " + listTypeID  + "";
        using (SqlConnection objCon = new SqlConnection(connValue))
        {
            objCon.Open();
            using (SqlCommand objCmd = new SqlCommand(sqlQuery, objCon))
            {
                using (SqlDataReader dr = objCmd.ExecuteReader())
                {
                    if (dr.HasRows)
                        checkExist = true; ;
                }
            }
        }
        return checkExist;
    }

    private IList<int> ReadListDisc(int cntrTypeID)
    {
        IList<int> listDesc = new List<int>();
        string sqlQuery = "SELECT  checkList, listTypeID FROM  DCCheckListData WHERE (listTypeID  = " + cntrTypeID + ")";

        using (SqlConnection objCon = new SqlConnection(connValue))
        {
            objCon.Open();
            using (SqlCommand objCmd = new SqlCommand(sqlQuery, objCon))
            {
                using (SqlDataReader dr = objCmd.ExecuteReader())
                {
                    while (dr.Read())
                    {
                        if (dr["checkList"].ToString().Contains("if applicable"))
                            listDesc.Add(0);
                        else
                            listDesc.Add(1);
                    }
                }
            }
        }

        IList<int> listVal = new List<int>();
        int icnt = listDesc.Count;
        for (int i = icnt; i < 18; i++)
        {
            listDesc.Add(1);
        }
        return listDesc;
    }
   
    protected void txtAttRecDate_TextChanged(object sender, EventArgs e)
    {
        DateTime fromDate = Convert.ToDateTime(txtAttRecDate.Text);
        DateTime toDate = Convert.ToDateTime(txtReceivedDate.Text);

        DateTime dt = DateTime.Parse(fromDate.ToShortDateString());
        DateTime dt1 = DateTime.Parse(toDate.ToShortDateString());
        
        double noOfDays = dt.Subtract(dt1).TotalDays;

        if (Convert.ToInt16(noOfDays) < 0)
        {
            txtAttRecDate.Text = "";
            ClientScript.RegisterClientScriptBlock(this.GetType(), "Popup", "<script>alert('The Attachment Receive Date cannot be less than the Job Receive Date.')</script>", false);
            return;
        }

        // Code commented for avoid due date change

        // As per Intial requirement the below logic should be implent
        
        //int newWorkDays = 0;
        //if (ddlJobType.SelectedValue == "28")
        //{
        //    ddlGrade.SelectedValue = "2";
        //    newWorkDays = 3;
        //}
        //else if (ddlJobType.SelectedValue == "27")
        //{
        //    ddlGrade.SelectedValue = "3";
        //    newWorkDays = 2;
        //}
        //else if (ddlJobType.SelectedValue == "30")
        //{
        //    ddlGrade.SelectedValue = "4";
        //    newWorkDays = 2;
        //}
        //else if (ddlJobType.SelectedValue == "29")
        //{
        //    ddlGrade.SelectedValue = "5";
        //    newWorkDays = 1;
        //}

        //if (txtAttRecDate.Text != "")
        //{
        //    txtDueDate.Text = Convert.ToDateTime(getEndDateByGivenDays(newWorkDays, txtAttRecDate.Text)).ToString("dd/MMM/yyyy");
        //    txtWorkDays.Text = new JobOrderData().getDaysByGivenDates(txtReceivedDate.Text, txtDueDate.Text);
        //}
        //else
        //{
        //    txtDueDate.Text = Convert.ToDateTime(getEndDateByGivenDays(newWorkDays, txtReceivedDate.Text)).ToString("dd/MMM/yyyy");
        //    txtWorkDays.Text = new JobOrderData().getDaysByGivenDates(txtReceivedDate.Text, txtDueDate.Text);
        //}
    }
    public string getEndDateByGivenDays()
    {
        SqlConnection con = new SqlConnection(connValue);
        SqlCommand cmd = new SqlCommand();
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Connection = con;
        if (txtWorkDays.Text != "")
        {
            cmd.CommandText = "AddWorkdays";
            SqlParameter prm = cmd.Parameters.Add("@ad_startDate", SqlDbType.DateTime);
            prm.Value = System.DateTime.Now;
            prm = cmd.Parameters.Add("@actual_workDays", SqlDbType.Int);
            prm.Value = Convert.ToInt32(txtWorkDays.Text);
            prm = cmd.Parameters.Add("@endDate", SqlDbType.DateTime);
            prm.Direction = ParameterDirection.Output;
            con.Open();
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
                Console.WriteLine(dr.GetString(0));
            con.Dispose();
            con.Close();
        }
        return cmd.Parameters[2].Value.ToString();
    }
    private void UpdateDueDate()
    {
        string upDateQuery = string.Empty;
        upDateQuery = "UPDATE Job SET jobDueDate = @jobDueDate,workDays = @workDays  WHERE JobID = @JobID";

        using (SqlConnection sqlCon = new SqlConnection(connValue))
        {
            using (SqlCommand cmd = new SqlCommand())
            {
                cmd.CommandText = upDateQuery;
                cmd.Connection = sqlCon;

                cmd.Parameters.AddWithValue("@JobID", _jobID);
                
                if (txtSurveyReply.Text !="")
                    cmd.Parameters.AddWithValue("@jobDueDate", Convert.ToDateTime(txtSurveyReply.Text).ToString("dd/MMM/yyyy"));
                else
                    cmd.Parameters.AddWithValue("@jobDueDate", System.DBNull.Value);

                cmd.Parameters.AddWithValue("@workDays", 5);

                try
                {
                    sqlCon.Open();
                    cmd.ExecuteNonQuery();
                    sqlCon.Close();
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
        }
    }

    protected void ddlJobPriority_SelectedIndexChanged(object sender, EventArgs e)
    {
        string upDateQuery = string.Empty;
        upDateQuery = "UPDATE Job SET jobPriority = @jobPriority WHERE JobID = @JobID";

        using (SqlConnection sqlCon = new SqlConnection(connValue))
        {
            using (SqlCommand cmd = new SqlCommand())
            {
                cmd.CommandText = upDateQuery;
                cmd.Connection = sqlCon;

                cmd.Parameters.AddWithValue("@JobID", _jobID);
                cmd.Parameters.AddWithValue("@jobPriority", ddlJobPriority.SelectedValue);

                try
                {
                    sqlCon.Open();
                    cmd.ExecuteNonQuery();
                    sqlCon.Close();
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
        }
    }
    protected void lnkRequestNo_Click(object sender, EventArgs e)
    {
        Session["REQUEST_ID"] = lnkRequestNo.Text;
        Response.Redirect("~/Survey/SurveyDetails.aspx", false);
    }

    protected void txtSurveyReply_TextChanged(object sender, EventArgs e)
    {
        SurveyReply();
    }

}