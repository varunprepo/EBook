﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.Data;
using Datalayer;

public partial class Planning_ViewSRInfo : System.Web.UI.Page
{
    string connValue = System.Configuration.ConfigurationManager.ConnectionStrings["EBSDEBookConn"].ConnectionString;
    IList<string> userRightsColl = new List<string>();
    protected void Page_Load(object sender, EventArgs e)
    {
        userRightsColl = (IList<string>)Session["UserRightsColl"];
        if (!IsPostBack)
        {
            string strQS = "SELECT Distinct jobOwner.contactID, Contact.userShortName AS UserName FROM JobOwner INNER JOIN  Contact ON jobOwner.contactID = Contact.contactID Where jobOwner.SectionID =9 and jobOwner.jobOwnerStatusID <>7 and Contact.userShortName <>''  Order by Contact.userShortName ";

            PopulateDropDownBox(ddlDCU, strQS, "contactID", "UserName");

            if (Session["ActionBy"] != null)
            {
                string strActionBy = Session["ActionBy"].ToString();
                string staffID = ddlDCU.Items.FindByText(strActionBy).Value;
                ddlDCU.SelectedValue = staffID;
            } 

            DataTable dt = new DataTable();

            string _staffID = string.Empty;

            if (ddlDCU.SelectedIndex != 0)
                _staffID = ddlDCU.SelectedValue;   // Selected staff from dropdown           
            else
                _staffID = Session["UserID"].ToString();  // Login User

            dt = ViewOngoingSRJobs(_staffID);  

            Session["getDCJobs"] = dt;

            lblCnt.Text = "Job Count : -  " + dt.Rows.Count.ToString();

            gvSRLogView.DataSource = dt;
            gvSRLogView.DataBind();

        }
    }
    protected void gvSRLogView_RowDataBound(object sender, GridViewRowEventArgs e)
    {

    }
    private void PopulateDropDownBox(DropDownList ddlBox, string sqlQuery, string valueMember, string displayName)
    {
        ddlBox.DataSource = new JobOrderData().FillDropdown(sqlQuery);
        ddlBox.DataTextField = displayName;
        ddlBox.DataValueField = valueMember;
        ddlBox.SelectedIndex = -1;
        ddlBox.DataBind();

        ListItem emptyItem = new ListItem("", "");
        ddlBox.Items.Insert(0, emptyItem);
    }
    protected void lnkJobOrderJobNo_Click(object sender, EventArgs e)
    {
        try
        {
            LinkButton lnkJobID = (LinkButton)sender;
            GridViewRow gvr = (GridViewRow)lnkJobID.NamingContainer;

            Session["JobSrID"] = ((HtmlGenericControl)gvr.FindControl("divJobID")).InnerText;

            Session["UrlRef"] = Request.Url.AbsoluteUri;

            Response.Redirect("~/Planning/BSDetails.aspx?SrJobID= " + Session["JobSrID"] + "", false);
        }
        catch
        {

        }
    }
    private DataTable ViewOngoingSRJobs(string userID)
    {
        DataSet ds = new DataSet();
        Int32 qsID;

        Int32.TryParse(userID, out qsID);
        try
        {
            ds = (new JobOrderData().viewSRData(qsID));    // SpName - SR_ViewLog 
        }
        catch (Exception ex)
        {

        }
        return ds.Tables[0];
    }
    private void getData(string _userID)
    {
        DataSet ds = new DataSet();
        Int32 qsID;

        Int32.TryParse(_userID, out qsID);
     
        using (SqlConnection con = new SqlConnection(connValue))
        {
            using (SqlCommand cmd = new SqlCommand())
            {
                try
                {
                    cmd.CommandType = CommandType.Text;
                    cmd.Connection = con;
                    cmd.CommandType = CommandType.StoredProcedure;
                    string qry = "SR_ViewLog   " + qsID + "";
                    cmd.CommandText = qry;                                
                    con.Open();                             

                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    da.Fill(ds);

                    gvSRLogView.DataSource = ds.Tables[0];
                    gvSRLogView.DataBind();
                    con.Close();
                   
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
        } 
    }
    protected void btnSearchSR_Click(object sender, EventArgs e)
    {

    }
    protected void btnAdd_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/Planning/Search_SRInfo.aspx", false);
    }
    protected void btnNewSR_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/Planning/CreateSRRequest.aspx");
    }
    protected void ddlDCU_SelectedIndexChanged(object sender, EventArgs e)
    {
        DataTable dt = new DataTable();

        string _staffID = string.Empty;

        if (ddlDCU.SelectedIndex != 0)
            _staffID = ddlDCU.SelectedValue;   // Selected staff from dropdown
        else if ((Session["userProfileID"].Equals("1")) || (!userRightsColl.Contains("17")))
            _staffID = "0"; // Admin and the person who have rights -17 
        else
            _staffID = Session["UserID"].ToString();  // Login User

        dt = ViewOngoingSRJobs(_staffID);  

        Session["getDCJobs"] = dt;

        lblCnt.Text = "Job Count : -  " + dt.Rows.Count.ToString();

        gvSRLogView.DataSource = dt;
        gvSRLogView.DataBind();
    }
}