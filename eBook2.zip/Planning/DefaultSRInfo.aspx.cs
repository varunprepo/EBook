﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Data;
using Datalayer;
using System.Web.UI.HtmlControls;

using System.Globalization;
using System.Web.UI.HtmlControls;
using System.IO;
using System.Drawing;
using System.Data.SqlClient;

public partial class Planning_DefaultSRInfo : System.Web.UI.Page
{
    string connValue = System.Configuration.ConfigurationManager.ConnectionStrings["EBSDEBookConn"].ConnectionString;
    int flag;
    JobOrderData jobdata;
    DataSet ds;
    static IList<string> userRightsColl = new List<string>();
    string profile_Name = string.Empty;

    protected void Page_Load(object sender, EventArgs e)
    {
        userRightsColl = (IList<string>)Session["UserRightsColl"];

        if (!IsPostBack)
        {
            FillGridView_Details(10);
        }
    }

    DataView dvCommitted = new DataView();
    private void FillGridView_Details(int jobid)
    {
        if (userRightsColl.Contains("61"))   //Add New Project
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "Popup", "<script>alert('You have no privilege to add this task,Contact administrator.')</script>", false);
            return;
        }

        // Status 6 for Ongoing - Status - 10 for PSA stage

        DataSet ds = null;


        ds = new JobOrderData().GetSRData("False", Convert.ToInt32(Session["UserID"]));

        if (ds.Tables.Count == 0)
            return;
        else
        {
            dvCommitted = new DataView(ds.Tables[0]);
            Session["CommittedInfo"] = dvCommitted;

            grvPlanning.DataSource = ds.Tables[0];
            grvPlanning.DataBind();
        }
    }
    
    protected void lnkPlannigJobNo_Click(object sender, EventArgs e)     //ForCommitted
    {
        try
        {
            LinkButton lnkJobID = (LinkButton)sender;
            GridViewRow gvr = (GridViewRow)lnkJobID.NamingContainer;
            Session["PlanJobID"] = ((HtmlGenericControl)gvr.FindControl("divJobID")).InnerText;

            Session["UrlRef"] = Request.Url.AbsoluteUri;
            Response.Redirect("~/Planning/BSDetails.aspx?JobID = " + Session["PlanJobID"] + "", false);

        }
        catch
        {

        }
    }
    protected void grvPlanning_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        grvPlanning.PageIndex = e.NewPageIndex;
        bindGridView();

        FillGridView_Details(0);
    }
    private void bindGridView()
    {
        grvPlanning.DataSource = Session["CommittedInfo"];
        grvPlanning.DataBind();
    }

    private Boolean getStaffStatus(string srvID)
    {
        Boolean chkStaffStatus = false;

        try
        {
            SqlConnection sqlConn = new SqlConnection(connValue);
            sqlConn.Open();

            string strValue = "SELECT jobOwnerID FROM  JobOwner WHERE (srID = @srvID) AND (jobOwnerStatusID = 3)";

            SqlCommand sqlCom = new SqlCommand(strValue, sqlConn);
            sqlCom.CommandText = strValue;

            sqlCom.Parameters.AddWithValue("@srvID", srvID);
            SqlDataReader sqlReader = sqlCom.ExecuteReader();

            if (sqlReader.HasRows)
                chkStaffStatus = true;
            else
                chkStaffStatus = false;

            sqlReader.Close();
            sqlConn.Close();
        }
        catch (Exception ex)
        {
            throw ex;
        }

        return chkStaffStatus;
    }

    protected void grvPlanning_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (Session["isTeamLeader"] != null)
        {
            if (Session["isTeamLeader"].ToString().Equals("True"))
            {
                if (e.Row.RowType == DataControlRowType.DataRow)
                {
                    TextBox srvID = (TextBox)e.Row.FindControl("divJobID");
                    if (srvID.Text != "")
                    {
                        if (!getStaffStatus(srvID.Text))
                        {
                            e.Row.BackColor = System.Drawing.Color.Yellow;
                        }
                    }
                }
            }
        }
    }
}