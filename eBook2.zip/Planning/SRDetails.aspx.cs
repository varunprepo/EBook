﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Data.SqlClient;
using Datalayer;
using System.Data;
using System.IO;
using System.Configuration;

public partial class Planning_SRDetails : System.Web.UI.Page
{
    string connValue = System.Configuration.ConfigurationManager.ConnectionStrings["EBSDEBookConn"].ConnectionString;
    string _jobNo = string.Empty;
    int _jobID = 0;
    IList<string> userRightsColl = new List<string>();
    string profile_Name = string.Empty;
    int _tabType = 0;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            trStatus.Visible = false;
        }       
    }
    protected void Page_Init(object sender, EventArgs e)
    {
        if (Session["UserName"] == null)
        {
            Response.Redirect("~/LoginPage.aspx", false);
            return;
        }

        if (_jobID == 0)
            _jobID = Convert.ToInt32(Request.QueryString["SrJobID"]);

        Session["StaffJobID"] = Convert.ToInt32(Request.QueryString["SrJobID"]);

        _tabType = Convert.ToInt32(Request.QueryString["tabType"]);

        // _jobID = 10;

        if (!IsPostBack)
        {
            PopulateDropDownBox(ddlTask, "SELECT jobPurposeID, jobPurposeName FROM JobPurpose Where jobPurposeID in(1,8,9,10)", "jobPurposeID", "jobPurposeName");

            //ddlQS.DataSource = null;
            //string getStaff = "SELECT  contactID, userShortName FROM  Contact WHERE (userShortName IS NOT NULL) AND (contactID <> 1) AND (isActive = 1) AND (sectionID =9) AND (companyID = 362) ORDER BY userShortName";
            //PopulateDropDownBox(ddlQS, getStaff, "contactID", "userShortName");


            ddlQS.DataSource = null;
            string getStaff = "SELECT ModuleAccess.ContactID, Contact.userShortName FROM ModuleAccess INNER JOIN Contact ON ModuleAccess.ContactID = Contact.contactID";
            PopulateDropDownBox(ddlQS, getStaff, "contactID", "userShortName");


            PopulateDropDownBox(ddlServiceTypes, "SELECT serviceTypeID, serviceTypeDescription FROM ServiceType ", "serviceTypeID", "serviceTypeDescription");

            PopulateDropDownBox(ddlSysTypes, "SELECT serviceTypeSystemID, serviceTypeSystem FROM ServiceTypeSubCategory ", "serviceTypeSystemID", "serviceTypeSystem");
           
            PopulateDropDownBox(ddlReqStatus, "SELECT JobStatusID, JobStatusName FROM JobStatus Where JobStatusID in(3,6,7) ORDER BY JobStatusName", "JobStatusID", "JobStatusName");   //4, Ongoing and Pending

            PopulateDropDownBox(ddlStaffStatus, "SELECT JobStatusID, JobStatusName FROM JobStatus Where JobStatusID in(1,2,3,5,6,7) ORDER BY JobStatusName", "JobStatusID", "JobStatusName");   //4, Ongoing and Pending
            
            
            Fill_JobOrder_Information(_jobID);

          //  PopulateDropDownBox(ddlSysTypes, "SELECT serviceTypeSystemID, serviceTypeSystem FROM ServiceTypeSubCategory where serviceTypeID= " + ddlServiceTypes.SelectedValue, "serviceTypeSystemID", "serviceTypeSystem");
 
            if (fileUpload1.PostedFile == null)
            {
                UploadFile(CreateFolder(false));
            }

            if (CheckAllStaffStatus() == false)
                ddlReqStatus.Enabled = true;

            if (CheckTeamLead(Convert.ToInt32(Session["UserID"])) == true)
            {
                ddlReqStatus.Enabled = true;
               // trStatus.Visible = true;

                txtReqDueDate.Enabled = true;
            }
            else
            {
                ddlReqStatus.Enabled = false;
               // trStatus.Visible = false;
            }

           
        }

        gvSRJoborderNew.DataSource = new JobOrderData().GetSRJobOwnerDetails(_jobID);
        gvSRJoborderNew.DataBind();
    }
    private void PopulateDropDownBox(DropDownList ddlBox, string sqlQuery, string valueMember, string displayName)
    {
        DataTable table = new DataTable();
        try
        {
            using (SqlConnection sqlConn = new SqlConnection(connValue))
            {
                using (SqlDataAdapter da = new SqlDataAdapter(sqlQuery, sqlConn))
                {
                    sqlConn.Open();
                    da.Fill(table);
                }
            }
            //cmbBox.Items.Add("Select");

            ddlBox.DataSource = table;
            ddlBox.DataTextField = displayName;
            ddlBox.DataValueField = valueMember;

            ddlBox.SelectedIndex = -1;
            ddlBox.DataBind();

            ddlBox.Items.Insert(0, new ListItem("--Select--"));
        }
        catch (System.Exception ex)
        {
            throw ex;
        }
    }

    //private void PopulateDropDownBox(DropDownList ddlBox, string sqlQuery, string valueMember, string displayName)
    //{
    //    DataTable table = new DataTable();
    //    try
    //    {
    //        using (SqlConnection sqlConn = new SqlConnection(connValue))
    //        {
    //            using (SqlDataAdapter da = new SqlDataAdapter(sqlQuery, sqlConn))
    //            {
    //                sqlConn.Open();
    //                da.Fill(table);
    //            }
    //        }
    //        //cmbBox.Items.Add("Select");

    //        ddlBox.DataSource = table;
    //        ddlBox.DataTextField = displayName;
    //        ddlBox.DataValueField = valueMember;

    //        if (!ddlBox.ID.Equals("ddlSysTypes"))
    //        {
    //            ddlBox.SelectedIndex = -1;
    //            ddlBox.DataBind();
    //            ddlBox.Items.Insert(0, new ListItem("--Select--"));
    //        }
    //        else
    //        {
    //            ddlBox.SelectedValue = Session["SysTypesValue"].ToString();
    //            ddlBox.DataBind();
    //        }
    //    }
    //    catch (System.Exception ex)
    //    {
    //        throw ex;
    //    }
    //}

    private void PopulateDropDownBoxForStaffRole(DropDownList ddlBox, string sqlQuery, string valueMember, string displayName)
    {
        DataTable table = new DataTable();
        try
        {
            using (SqlConnection sqlConn = new SqlConnection(connValue))
            {
                using (SqlDataAdapter da = new SqlDataAdapter(sqlQuery, sqlConn))
                {
                    sqlConn.Open();
                    da.Fill(table);
                }
            }

            //cmbBox.Items.Add("Select");

            ddlBox.DataSource = table;
            ddlBox.DataTextField = displayName;
            ddlBox.DataValueField = valueMember;

            ddlBox.SelectedIndex = -1;
            ddlBox.DataBind();

        }
        catch (System.Exception ex)
        {
            throw ex;
        }
    }
    protected void gvSRJoborder_RowCommand(object sender, GridViewCommandEventArgs e)
    {

    }
    protected void gvSRJoborder_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        //DropDownList l = (DropDownList)e.Row.FindControl("ddljobtype");

        //PopulateDropDownBox_Staff(l, "SELECT JobStatusid,JobStatusName as JobStatus FROM jobStatus where JobStatusid in(2,3,6,7) ", "JobStatusid", "JobStatus");  // where JobStatusid in(5,6,7,8)

        //TextBox lm = (TextBox)e.Row.FindControl("jobid");
        //TextBox afr = (TextBox)e.Row.FindControl("TextBox1");
        //TextBox InchargeID = (TextBox)e.Row.FindControl("txtInchargeID");
    
        //string lk = lm.Text;

        //l.ToolTip = InchargeID.Text;

        //l.SelectedValue = afr.Text;

        //Session["StatusVal"] = l.SelectedValue;

        //l.SelectedIndexChanged += new EventHandler(SelectedIndexChanged);      

    }
    public void Fill_JobOrder_Information(int _jobID)
    {
        try
        {
            SqlConnection sqlConn = new SqlConnection(connValue);
            sqlConn.Open();

            string strValue = "SELECT EBDServiceRequests.serviceReqID, EBDServiceRequests.serviceReqNo, EBDServiceRequests.empName, EBDServiceRequests.departmentID, EBDServiceRequests.sectionID, " +
                        " EBDServiceRequests.jobTitle, EBDServiceRequests.phoneNumber, EBDServiceRequests.emailID, EBDServiceRequests.serviceRequestDate, " +
                        " EBDServiceRequests.serviceRequestDescription,  EBDServiceRequests.onBehalfOf, EBDServiceRequests.fileName, EBDServiceRequests.srCompletionDate,EBDServiceRequests.srExpectedDate, " +
                        " EBDServiceRequests.filePath, EBDServiceRequests.serviceTypeID, EBDServiceRequests.serviceTypeSystemID, Section.sectionName, Department.deptName,EBDServiceRequests.StatusID ,EBDServiceRequests.srRemarks " +
                                   " FROM  EBDServiceRequests INNER JOIN Section ON EBDServiceRequests.sectionID = Section.sectionID INNER JOIN Department ON EBDServiceRequests.departmentID = Department.departmentID Where serviceReqID =@JobID";
            
             SqlCommand sqlCom = new SqlCommand(strValue, sqlConn);

           // SqlCommand sqlCom = new SqlCommand();
           // sqlCom.Connection = sqlConn;
           // sqlCom.CommandType = CommandType.StoredProcedure;
           
            sqlCom.CommandText = strValue;

            sqlCom.Parameters.AddWithValue("@JobID", _jobID);

            SqlDataReader sqlReader = sqlCom.ExecuteReader();

            while (sqlReader.Read())
            {
                txtempName.Text = sqlReader["empName"].ToString();

                //ddlServiceTypes.SelectedValue = sqlReader["serviceTypeID"].ToString();

                //if (sqlReader["departmentID"].ToString() != "")
                       //ddlServiceTypes.SelectedValue = sqlReader["departmentID"].ToString();

                if (sqlReader["serviceTypeID"].ToString() != "")
                {
                    ddlServiceTypes.SelectedValue = sqlReader["serviceTypeID"].ToString();
                    Session["MainTypeID"] = sqlReader["serviceTypeID"].ToString();
                }

                txtPhone.Text = sqlReader["phoneNumber"].ToString();

                txtSection.Text = sqlReader["sectionName"].ToString();

                if (sqlReader["serviceRequestDate"].ToString() != "")
                    txtDate.Text = Convert.ToDateTime(sqlReader["serviceRequestDate"]).ToString("dd/MMM/yyyy");
            

               // txtDate.Text = sqlReader["serviceRequestDate"].ToString();

                txtEmail.Text = sqlReader["emailID"].ToString();

                if (sqlReader["serviceTypeSystemID"].ToString() != "")
                {
                    ddlSysTypes.SelectedValue = sqlReader["serviceTypeSystemID"].ToString();
                    Session["SubType"] = sqlReader["serviceTypeSystemID"].ToString();
                }
             
                txtDept.Text = sqlReader["deptName"].ToString();

                txtJobNo.Text = sqlReader["serviceReqNo"].ToString(); 

                txtDesc.Text = sqlReader["serviceRequestDescription"].ToString();

                txtTitle.Text = sqlReader["jobTitle"].ToString();

                if (sqlReader["srCompletionDate"].ToString() != "")
                  txtEndDate.Text = Convert.ToDateTime(sqlReader["srCompletionDate"]).ToString("dd/MMM/yyyy");

                if (sqlReader["StatusID"].ToString() != "")
                    ddlReqStatus.SelectedValue = sqlReader["StatusID"].ToString();

                if (sqlReader["srRemarks"].ToString() != "")
                    txtSRRemarks.Text = sqlReader["srRemarks"].ToString();

                if (sqlReader["fileName"].ToString() != "")
                    Session["fileName"] = sqlReader["fileName"].ToString();

                 txtOnBehalfOf.Text = sqlReader["onBehalfOf"].ToString();

                 if (sqlReader["srExpectedDate"].ToString() != "")
                 {
                     txtReqDueDate.Text = Convert.ToDateTime(sqlReader["srExpectedDate"]).ToString("dd/MMM/yyyy");
                 }              
            }

            sqlReader.Close();
            sqlConn.Close();
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    protected void ddlTask_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void btnAdd_Click(object sender, EventArgs e)
    {
        int InchargeID = 0;

        if (lblInchargeID.Text != "")
            InchargeID = Convert.ToInt32(lblInchargeID.Text);

        if (InchargeID == 0)
        {

           InsertStaffData();



         // Response.Write(" Insert Data");

            // string _eMail = getEmail(ddlQS.SelectedValue);

            //   OutLookAlertQuick(_eMail, "");           

           new JobOrderData().SendEmailAlert(new JobOrderData().getEmail(ddlQS.SelectedValue), txtJobNo.Text, "", "a new Job Order was assigned to you and the details are as follows");

           ClearStaffData();

        }
        else
        {           
            SR_UpdateInchargeData(InchargeID);
        }

        gvSRJoborderNew.DataSource = new JobOrderData().GetSRJobOwnerDetails(_jobID);
        gvSRJoborderNew.DataBind();

       //  ClearStaffData(); 
       
    }
    public void SR_UpdateInchargeData(int inchargeID)
    {      
        using (SqlConnection con = new SqlConnection(connValue))
        {
            using (SqlCommand cmd = new SqlCommand())
            {
                try
                {
                    cmd.CommandType = CommandType.Text;
                    cmd.Connection = con;

                    if (lblDistributedBy.Text.Equals(Session["UserID"].ToString()))
                    {
                        cmd.CommandText = "Update JobOwner Set daysToAct =@daysToAct,remarks =@inchargeRemarks,jobPurposeID = @jobPurposeID,StaffRoleID = @StaffRoleID,actionDueDate =@actionDueDate,staffStartDate = @startDate where jobOwnerID = " + inchargeID;

                        cmd.Parameters.AddWithValue("@actionDueDate", Convert.ToDateTime(txtDueDate.Text).ToString("dd/MMM/yyyy"));

                        cmd.Parameters.AddWithValue("@startDate", Convert.ToDateTime(txtStartDate.Text).ToString("dd/MMM/yyyy"));

                        cmd.Parameters.AddWithValue("@daysToAct", 1);

                       
                    }
                    else if (CheckTeamLead(Convert.ToInt32(Session["UserID"])) == true)
                    {
                        cmd.CommandText = "Update JobOwner Set daysToAct =@daysToAct,remarks =@inchargeRemarks,jobPurposeID = @jobPurposeID, " +
                        "completionDate = @completionDate, StaffRoleID = @StaffRoleID,actionDueDate =@actionDueDate,staffStartDate = @startDate,JobOwnerStatusID =@statusID where jobOwnerID = " + inchargeID;

                        cmd.Parameters.AddWithValue("@actionDueDate", Convert.ToDateTime(txtDueDate.Text).ToString("dd/MMM/yyyy"));

                        cmd.Parameters.AddWithValue("@startDate", Convert.ToDateTime(txtStartDate.Text).ToString("dd/MMM/yyyy"));

                        cmd.Parameters.AddWithValue("@daysToAct", 1);

                        cmd.Parameters.AddWithValue("@statusID", ddlStaffStatus.SelectedValue);

                        cmd.Parameters.AddWithValue("@completionDate", Convert.ToDateTime(System.DateTime.Now).ToString("dd/MMM/yyyy"));
                    }
                    else
                    {
                        cmd.CommandText = "Update JobOwner Set remarks =@inchargeRemarks,jobPurposeID = @jobPurposeID,StaffRoleID = @StaffRoleID where jobOwnerID = " + inchargeID;
                    }

                    cmd.Parameters.AddWithValue("@inchargeRemarks", txtRemarks.Text);
                    cmd.Parameters.AddWithValue("@StaffRoleID", 1);
                    cmd.Parameters.AddWithValue("@jobPurposeID", ddlTask.SelectedValue);
                    cmd.Parameters.AddWithValue("@jobOwnerID", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                    //  cmd.Parameters.AddWithValue("@isTLApprove", chkTLApprove.Checked);

                    con.Open();
                    cmd.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
        }
    }
    private void InsertStaffData()
    {  
        int _ownerID = 0;

        _ownerID = AddInchargeDataBS(Session["Username"].ToString(), Convert.ToInt32(Session["UserID"]), Convert.ToInt32(Session["SectionID"]), txtDueDate.Text);
        
    }
    public int AddInchargeDataBS(string userName, int _currentUserID, int _currentSecID, string staffStartDate)
    {
        int _ownerID = 0;
        using (SqlConnection con = new SqlConnection(connValue))
        {
            using (SqlCommand cmd = new SqlCommand())
            {
                try
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Connection = con;

                    cmd.CommandText = "BS_AddJobIncharge"; 

                    cmd.Parameters.AddWithValue("@jobID", System.DBNull.Value);                   

                    cmd.Parameters.AddWithValue("@contactID", ddlQS.SelectedValue);

                    cmd.Parameters.AddWithValue("@distributedBy", _currentUserID);

                    cmd.Parameters.AddWithValue("@actionDueDate", txtDueDate.Text);

                    cmd.Parameters.AddWithValue("@daysToAct", txtWorkDays.Text);

                    cmd.Parameters.AddWithValue("@createUser", userName);

                    cmd.Parameters.AddWithValue("@StaffRoleID", 1);

                    cmd.Parameters.AddWithValue("@jobPurposeID", ddlTask.SelectedValue);

                    cmd.Parameters.AddWithValue("@sectionID", _currentSecID);

                    cmd.Parameters.AddWithValue("@jobOwnerID", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                    if (staffStartDate != "")
                        cmd.Parameters.AddWithValue("@startDate", Convert.ToDateTime(staffStartDate).ToString("dd/MMM/yyyy"));
                    else
                        cmd.Parameters.AddWithValue("@startDate", System.DBNull.Value);

                    cmd.Parameters.AddWithValue("@srID", _jobID); // For only Service Request

                    //cmd.Parameters.AddWithValue("@jobNo", txtJobNo.Text);

                    con.Open();
                    cmd.ExecuteNonQuery();

                    
                }
                catch (Exception ex)
                {
                    throw ex;
                }

                return _ownerID = (int)cmd.Parameters["@jobOwnerID"].Value;
            }
        }
    }
    protected void btnUpload_Click1(object sender, EventArgs e)
    {
        UploadFile(CreateFolder(true));
    }


    #region FileUpload

    private void downloadAndViewAttachedFile()
    {
        string filePath = HyperLink1.NavigateUrl;

        if (!File.Exists((string)filePath))
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('File is not available at specific path')</script>", false);
            return;
        }
        Response.AddHeader("Content-Disposition", "attachment;filename=\"" + HyperLink1.Text + "\"");
        Response.TransmitFile(filePath);
        Response.End();
    }

    protected void btnDownload_Click(object sender, EventArgs e)
    {
        downloadAndViewAttachedFile();
    }
    protected void lnkFile_Click(object sender, EventArgs e)
    {
        downloadAndViewAttachedFile();
    }
    string filename = string.Empty;
    private void UploadFile(string filePath)
    {
        string _requestID = txtJobNo.Text;
        if (fileUpload1.PostedFile != null)
        {
            filename = Path.GetFileName(fileUpload1.PostedFile.FileName);

            if (fileUpload1.HasFile)
            {
                try
                {
                    filePath = Path.Combine(filePath, _requestID + "_" + filename);
                    HyperLink1.NavigateUrl = filePath;
                    HyperLink1.Text = _requestID + "_" + filename;
                    fileUpload1.SaveAs(filePath);
                }
                catch (Exception ex)
                {

                    string script = "<script type=\"text/javascript\"> displayPopup('" + ex.Message.Replace("'", "") + "'); </script>";
                    ClientScript.RegisterClientScriptBlock(this.GetType(), "myscript", script);
                    return;
                }
            }
            else
            {
                ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Please select file for upload.')</script>", false);
                return;
            }
        }
    }
    private string CreateFolder(bool isUpload)
    {
        string requestID = null;
        requestID = txtJobNo.Text;
        string filePath = null;

        if (!Directory.Exists(ConfigurationManager.AppSettings["ServiceRequestFolderPath"].ToString()))
            Directory.CreateDirectory(ConfigurationManager.AppSettings["ServiceRequestFolderPath"].ToString());
        else
        {
            filePath = ConfigurationManager.AppSettings["ServiceRequestFolderPath"].ToString();
            Directory.CreateDirectory(filePath);
        }
        if (filePath != null)
        {
            if (!isUpload)
            {
                if (Session["fileName"] != null)
                {
                    string fullFilePath = filePath + "\\" + Session["fileName"].ToString(); //getAllFiles(newfolderName);
                    if (fullFilePath != "")
                    {
                        HyperLink1.NavigateUrl = fullFilePath;
                        HyperLink1.Text = Session["fileName"].ToString();
                    }
                }
            }
        }
        else
        {
            HyperLink1.Text = "";
        }
        return filePath;
    }
    private string getAllFiles(string newPath)
    {
        String[] allfiles = System.IO.Directory.GetFiles(newPath, "*.*", System.IO.SearchOption.AllDirectories);
        string foldrfileName = string.Empty;
        if (allfiles.Length != 0)
        {
            //foreach (var file in allfiles)
            //{
            FileInfo info = new FileInfo(allfiles[0]);
            foldrfileName = info.FullName;
        }

        return foldrfileName;
    }

    private void getFile(string subPath)
    {
        //string subPath = "@"\\ebsd-sreedhar\SurveyUnit\Backup_Data\Year_2016""; // your code goes here

        bool IsExists = System.IO.Directory.Exists(Server.MapPath(subPath));
        if (!IsExists)
            System.IO.Directory.CreateDirectory(Server.MapPath(subPath));
        else
            Directory.CreateDirectory(Path.GetDirectoryName(subPath));


        //if (!Directory.Exists(Path.GetDirectoryName(fileName)))
        //{
        //    Directory.CreateDirectory(Path.GetDirectoryName(fileName));
        //}
    }



    #endregion

    protected void lnkFile_Click1(object sender, EventArgs e)
    {
        downloadAndViewAttachedFile();
    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        using (SqlConnection con = new SqlConnection(connValue))
        {
            using (SqlCommand cmd = new SqlCommand())
            {
                try
                {
                    cmd.CommandType = CommandType.Text;
                    cmd.Connection = con;

                    cmd.CommandText = "Update EBDServiceRequests Set serviceRequestDescription =@desc,jobTitle =@jobTitle,serviceTypeSystemID =@systemTypeID,serviceTypeID=@serviceTypeID,srRemarks =@srRemarks, " + 
                    " srExpectedDate = @ActionDate Where serviceReqID =@serviceReqID";

                    cmd.Parameters.AddWithValue("@serviceReqID", _jobID);
                    cmd.Parameters.AddWithValue("@desc", txtDesc.Text);
                    cmd.Parameters.AddWithValue("@jobTitle", txtTitle.Text);

                    if (ddlServiceTypes.SelectedIndex != 0)
                        cmd.Parameters.AddWithValue("@serviceTypeID", ddlServiceTypes.SelectedValue);
                    else
                        cmd.Parameters.AddWithValue("@serviceTypeID", System.DBNull.Value);

                    if (ddlSysTypes.SelectedIndex != 0)
                        cmd.Parameters.AddWithValue("@systemTypeID", ddlSysTypes.SelectedValue);
                    else
                        cmd.Parameters.AddWithValue("@systemTypeID", System.DBNull.Value);

                    cmd.Parameters.AddWithValue("@srRemarks", txtSRRemarks.Text.Trim());

                    if (txtReqDueDate.Text !="")
                      cmd.Parameters.AddWithValue("@ActionDate", Convert.ToDateTime(txtReqDueDate.Text).ToString("dd/MMM/yy"));
                    else
                      cmd.Parameters.AddWithValue("@ActionDate", System.DBNull.Value);


                    con.Open();
                    cmd.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    throw ex;
                }               
            }
        }
    }
    protected void ddlServiceTypes_SelectedIndexChanged(object sender, EventArgs e)
    {
        //ddlSysTypes.DataSource = null;

        //PopulateDropDownBox(ddlSysTypes, "SELECT serviceTypeSystemID, serviceTypeSystem FROM ServiceTypeSubCategory where serviceTypeID = " + ddlServiceTypes.SelectedValue + " ", "serviceTypeSystemID", "serviceTypeSystem");

        if (ddlServiceTypes.SelectedIndex != 0)
        {
            string sqlQueryDept = "SELECT serviceTypeSystemID, serviceTypeSystem FROM ServiceTypeSubCategory where serviceTypeID = " + ddlServiceTypes.SelectedValue + "";

            ddlSysTypes.DataSource = null;
            PopulateDropDownBox(ddlSysTypes, sqlQueryDept, "serviceTypeSystemID", "serviceTypeSystem");
        }
    }
    protected void gvSRJoborderNew_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
           DropDownList l = (DropDownList)e.Row.FindControl("ddljobtype");

           PopulateDropDownBox_Staff(l, "SELECT JobStatusid,JobStatusName as JobStatus FROM jobStatus where JobStatusid in(2,3,6,7) ", "JobStatusid", "JobStatus");  // where JobStatusid in(5,6,7,8)

            TextBox lm = (TextBox)e.Row.FindControl("jobid0");
           TextBox afr = (TextBox)e.Row.FindControl("TextBox1");    // OwnerStatID

           TextBox InchargeID = (TextBox)e.Row.FindControl("txtInchargeID0");

           Session["InchargeID"] = InchargeID.Text;

           string lk = lm.Text;

           l.ToolTip = InchargeID.Text;

           l.SelectedValue = afr.Text;

           Session["StatusVal"] = l.SelectedValue;

           l.SelectedIndexChanged += new EventHandler(SelectedIndexChanged);

           TextBox txtdate = (TextBox)e.Row.FindControl("lblJoindate0");

        //    txtdate.ToolTip = InchargeID.Text;
        ////    txtdate.TextChanged += new EventHandler(txtdate_TextChanged);
        //    Session["JobActionDueDate"] = txtdate.Text;

        //    Label lblStaff = (Label)e.Row.FindControl("txtStaff");

         //  Label lblDistributedBy = (Label)e.Row.FindControl("txtDistrubed");

           Label lblConactID = (Label)e.Row.FindControl("txtCnctID0");

        //    TextBox _txtDocID = (TextBox)e.Row.FindControl("txtDocID");
        //    Session["statusdocID"] = _txtDocID.Text;
        //    Session["contactID"] = lblConactID.Text;

           Label lblDistribID = (Label)e.Row.FindControl("txtDistributedBy0");
        //    Label lblTeamLeadID = (Label)e.Row.FindControl("lblTeamLead");


           if ((!lblConactID.Text.Equals(Session["userID"])))
           {
               l.Enabled = false;
           }
           if (lblConactID.Text.Equals(Session["userID"]))
           {
               //  btnOutlook.Enabled = true;
               Session["ActionDate"] = txtdate.Text;
           }
           if (!lblDistribID.Text.Equals(Session["userID"]))
           {
               txtdate.Enabled = false;
           }
        }
    }
    private int GetStaffRowCount(int staffID)
    {
        int strCnt = 0;

        string qry = "SELECT COUNT(jobOwnerID) AS rCnt FROM JobOwner WHERE (srID = " + staffID + ")";

        using (SqlConnection cn = new SqlConnection(connValue))
        {
            cn.Open();
            using (SqlCommand cmd = new SqlCommand(qry, cn))
            {
                using (SqlDataReader dr = cmd.ExecuteReader())
                {
                    while (dr.Read())
                    {
                       strCnt = Convert.ToInt32(dr["rCnt"].ToString());                       
                    }
                }
            }
        }
        return strCnt;
    }

    private Boolean CheckAllStaffStatus()
    {
        Boolean chkOngoingTask = false;

        string qry = "SELECT jobOwnerID FROM JobOwner WHERE  (srID = " + _jobID + ") AND (jobOwnerStatusID = 3)";

        using (SqlConnection cn = new SqlConnection(connValue))
        {
            cn.Open();
            using (SqlCommand cmd = new SqlCommand(qry, cn))
            {
                using (SqlDataReader dr = cmd.ExecuteReader())
                {
                    if (dr.HasRows)
                    {
                        chkOngoingTask = true;
                    }                    
                }
            }
        }
        return chkOngoingTask;
    }
    protected void SelectedIndexChanged(object sender, EventArgs e)
    {
        DropDownList ddl = (DropDownList)sender;
        if (ddl.SelectedIndex != 0)
        {
            string ID = ddl.ID;
            string g = ddl.SelectedValue;
            string inchargeID = ddl.ToolTip;

            Session["_InchargeID"] = inchargeID;
            Session["StatusValCurrent"] = ddl.SelectedValue;

            // Response.Write(" Staf ID " + inchargeID);          

           
            if (GetStaffRowCount(_jobID) > 1)
            {
                updateOngoingStatus(Convert.ToInt32(inchargeID), Convert.ToInt32(ddl.SelectedValue));
               // ddlReqStatus.Enabled = true;
            }
            else
            {
                ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Please assign this task to staff first')</script>", false);
            }

            if (CheckAllStaffStatus() == false)
            {
                new JobOrderData().SendEmailAlert(new JobOrderData().getEmail("95"),  txtJobNo.Text, "", "all the tasks are completed and the details are as follows");  //105 is Nazar ContactID    
                ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('you have alert message for job complete')</script>", false);

                ddlReqStatus.Enabled = true;
            }

            gvSRJoborderNew.DataSource = new JobOrderData().GetSRJobOwnerDetails(_jobID);
            gvSRJoborderNew.DataBind();
        }
    }
    private void updateOngoingStatus(int _ownerID, int _statusID)
    {
        SqlConnection cnn = new SqlConnection(connValue);
        cnn.Open();
        SqlCommand cmm = new SqlCommand();
        cmm.Connection = cnn;
        cmm.CommandText = "update JobOwner set jobOwnerStatusID = @statID,completionDate = @completionDate where jobOwnerID =@ownerID";
        cmm.CommandType = CommandType.Text;

        cmm.Parameters.AddWithValue("@ownerID", _ownerID);
        cmm.Parameters.AddWithValue("@statID", _statusID);     

        if (_statusID != 3)
            cmm.Parameters.AddWithValue("@completionDate", Convert.ToDateTime(System.DateTime.Now).ToString("dd/MMM/yyyy"));
        else
            cmm.Parameters.AddWithValue("completionDate",System.DBNull.Value);


        cmm.ExecuteNonQuery();
        cnn.Close();
    }
    private void PopulateDropDownBox_Staff(DropDownList ddlBox, string sqlQuery, string valueMember, string displayName)
    {
        DataTable table = new DataTable();
        try
        {
            using (SqlConnection sqlConn = new SqlConnection(connValue))
            {
                using (SqlDataAdapter da = new SqlDataAdapter(sqlQuery, sqlConn))
                {
                    sqlConn.Open();
                    da.Fill(table);
                }
            }
            //cmbBox.Items.Add("Select");

            ddlBox.DataSource = table;
            ddlBox.DataTextField = displayName;
            ddlBox.DataValueField = valueMember;

            ddlBox.SelectedIndex = -1;
            ddlBox.DataBind();

            // ddlBox.Items.Insert(0, new ListItem("--Select--"));
        }
        catch (System.Exception ex)
        {
            throw ex;
        }
    }
    protected void gvSRJoborderNew_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName.Equals("SelectStaff"))
        {
            string arguments = e.CommandArgument.ToString();

            if (arguments == "")
                return;

            string[] args = arguments.Split(';');

            int staffID = Convert.ToInt32(args[0]);

            if ((CheckTeamLead(Convert.ToInt32(Session["UserID"])) == true) || (staffID==105)) //nazar ID
            {
                trStatus.Visible = true;
            }
            else
            {
                trStatus.Visible = false;
            }

            FillstaffData(staffID);

            btnAdd.Text = " Update Data";

        }
    }
    private void FillstaffData(int staffID)
    {
        string qry = "SELECT  jobOwnerID, jobID,srID, contactID, jobNo,REPLACE(CONVERT(NVARCHAR, actionDueDate, 106), ' ', '/') AS actionDueDate,  daysToAct, REPLACE(CONVERT(NVARCHAR, completionDate, 106), ' ', '/') AS completionDate, jobOwnerStatusID, jobPurposeID, JobTypeID, " +
        "REPLACE(CONVERT(NVARCHAR, staffIssueDate, 106), ' ', '/') AS staffIssueDate , distributedBy,   remarks, REPLACE(CONVERT(NVARCHAR, staffStartDate, 106), ' ', '/') AS staffStartDate  FROM  JobOwner WHERE (jobOwnerID = " + staffID + ")";

        using (SqlConnection cn = new SqlConnection(connValue))
        {
            cn.Open();
            using (SqlCommand cmd = new SqlCommand(qry, cn))
            {
                using (SqlDataReader dr = cmd.ExecuteReader())
                {
                    while (dr.Read())
                    {
                        lblInchargeID.Text = dr["JobOwnerID"].ToString();
                        lblDistributedBy.Text = dr["distributedBy"].ToString();

                        ddlQS.SelectedValue = dr["contactID"].ToString();
                        ddlTask.SelectedValue = dr["jobPurposeID"].ToString();
                        txtStartDate.Text = dr["staffIssueDate"].ToString();

                        //  txtWorkDays.Text = dr["daysToAct"].ToString();
                        txtDueDate.Text = dr["actionDueDate"].ToString();
                        txtRemarks.Text = dr["remarks"].ToString();

                        ddlStaffStatus.SelectedValue = dr["jobOwnerStatusID"].ToString();
                    }
                }
            }
        }
    }
    protected void ddlReqStatus_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (userRightsColl.Contains("6")) // Access Right is 6
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Don't have the permission to edit this field ')</script>", false);           
        }
        else if (getStaffStatus() == true)
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('All the staff members has not completed there actions')</script>", false);
            ddlReqStatus.SelectedValue = "3";
        }
        else
        {           
            if (ddlReqStatus.SelectedIndex != 0)
            {              
                Session["lnkJobID"] = _jobID;

                // check is he team lead 

                if (CheckTeamLead(Convert.ToInt32(Session["UserID"])) == true)
                {
                    if ((ddlReqStatus.SelectedValue == "3"))  // ongoing
                    {
                        SR_UpdateJobStatusByUserSelection(_jobID, Convert.ToInt32(ddlReqStatus.SelectedValue));
                    }
                    else
                    {
                        SR_UpdateJobStatuCompletedsDate(_jobID, Convert.ToInt32(ddlReqStatus.SelectedValue));
                    }
                }
                Fill_JobOrder_Information(_jobID);
            }
        }
    }
    private Boolean getStaffStatus()
    {
        Boolean chkStaffStatus = false;

        try
        {
            SqlConnection sqlConn = new SqlConnection(connValue);
            sqlConn.Open();

            string strValue = "SELECT jobOwnerID FROM  JobOwner WHERE (srID = @JobID) AND (jobOwnerStatusID = 3)";

            SqlCommand sqlCom = new SqlCommand(strValue, sqlConn);
            sqlCom.CommandText = strValue;

            sqlCom.Parameters.AddWithValue("@JobID", _jobID);
            SqlDataReader sqlReader = sqlCom.ExecuteReader();

            if (sqlReader.HasRows)
                chkStaffStatus = true;
            else
                chkStaffStatus = false;

            sqlReader.Close();
            sqlConn.Close();
        }
        catch (Exception ex)
        {
            throw ex;
        }

        return chkStaffStatus;
    }
    private Boolean CheckTeamLead(int staffID)
    {
        Boolean chkTeamlead = false;

        // string qry = "SELECT teamLeaderID, teamLeaderName, contactID, sectionID FROM EBSDTeamLeaders WHERE (sectionID = 9) AND (contactID = " + staffID + ")";

        string qry = "SELECT ProfileName FROM ModuleAccess WHERE (contactID = " + staffID + ")";

        using (SqlConnection cn = new SqlConnection(connValue))
        {
            cn.Open();
            using (SqlCommand cmd = new SqlCommand(qry, cn))
            {
                using (SqlDataReader dr = cmd.ExecuteReader())
                {
                    if (dr.HasRows)
                    {
                        while (dr.Read())
                        {

                            if (dr[0].ToString().Equals("BS TeamLead"))
                                chkTeamlead = true;
                        }
                    }
                    //while (dr.Read())
                    //{
                    //    // dr["JobOwnerID"].ToString();

                    //}
                }
            }
        }

        return chkTeamlead;
    }
    public void SR_UpdateJobStatusByUserSelection(int _jobID, int statusID)
    {
        string upDateQuery = string.Empty;

        upDateQuery = "UPDATE EBDServiceRequests SET statusID =@jobStatusID,srCompletionDate =@srCompletionDate WHERE serviceReqID = @JobID";          // jobClosedDate =@jobClosedDate,


        using (SqlConnection sqlCon = new SqlConnection(connValue))
        {
            using (SqlCommand cmd = new SqlCommand())
            {
                cmd.CommandText = upDateQuery;
                cmd.Connection = sqlCon;

                cmd.Parameters.AddWithValue("@JobID", _jobID);
                cmd.Parameters.AddWithValue("@jobStatusID", statusID);
                cmd.Parameters.AddWithValue("@srCompletionDate", System.DBNull.Value);

                try
                {
                    sqlCon.Open();
                    cmd.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
        }
    }

    public void SR_UpdateJobStatuCompletedsDate(int _jobID, int statusID)
    {
        string upDateQuery = string.Empty;

        upDateQuery = "UPDATE EBDServiceRequests SET statusID =@jobStatusID, srCompletionDate =@jobStatusClosedDate WHERE serviceReqID = @JobID";          // srCompletionDate =@jobClosedDate,     ,jobStatusClosedDate=@jobStatusClosedDate

        SqlConnection sqlCon = new SqlConnection(connValue);
        SqlCommand cmd = new SqlCommand();
        cmd.CommandText = upDateQuery;
        cmd.Connection = sqlCon;

        cmd.Parameters.AddWithValue("@JobID", _jobID);

        if (statusID == 3)
            cmd.Parameters.AddWithValue("@jobStatusClosedDate", System.DBNull.Value);
        else
            cmd.Parameters.AddWithValue("@jobStatusClosedDate", System.DateTime.Now.ToString("dd/MMM/yyyy"));

        if (statusID == 3)
            cmd.Parameters.AddWithValue("@jobStatusID", 3);
        else
            cmd.Parameters.AddWithValue("@jobStatusID", 7);

        try
        {
            sqlCon.Open();
            cmd.ExecuteNonQuery();
            sqlCon.Close();
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    protected void ddlSysTypes_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void btnClr_Click(object sender, EventArgs e)
    {
        ClearStaffData();
    }
    protected void btnDelete_Click(object sender, EventArgs e)
    {
        int InchargeID = Convert.ToInt32(lblInchargeID.Text);
        new JobOrderData().DeleteIncharge(InchargeID);

        gvSRJoborderNew.DataSource = new JobOrderData().GetSRJobOwnerDetails(_jobID);
        gvSRJoborderNew.DataBind();
        btnAdd.Text = "Add Staff";
        ClearStaffData();  

    }
    private void ClearStaffData()
    {
        ddlQS.SelectedIndex = 0;
        ddlTask.SelectedIndex = 0;

        txtStartDate.Text = "";
        txtDueDate.Text = "";

        txtRemarks.Text = "";
    }


}