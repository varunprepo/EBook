﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using Datalayer;
using System.Data;
using System.IO;
using System.Configuration;

public partial class Planning_CreateSRRequest : System.Web.UI.Page
{
    string connValue = System.Configuration.ConfigurationManager.ConnectionStrings["EBSDEBookConn"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {            
            PopulateDropDownBox(ddlServiceTypes, "SELECT serviceTypeID, serviceTypeDescription FROM ServiceType ", "serviceTypeID", "serviceTypeDescription");
            PopulateDropDownBox(ddlSysTypes, "SELECT serviceTypeSystemID, serviceTypeSystem FROM ServiceTypeSubCategory ", "serviceTypeSystemID", "serviceTypeSystem");

            txtEmail.Focus();

           // txtDate.Text = Convert.ToDateTime(System.DateTime.Now).ToString("dd/MMM/YYYY");

            txtDate.Text = System.DateTime.Now.ToString();
        }
    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        AddServiceRequest();
    }
    private void PopulateDropDownBox(DropDownList ddlBox, string sqlQuery, string valueMember, string displayName)
    {
        DataTable table = new DataTable();
        try
        {
            using (SqlConnection sqlConn = new SqlConnection(connValue))
            {
                using (SqlDataAdapter da = new SqlDataAdapter(sqlQuery, sqlConn))
                {
                    sqlConn.Open();
                    da.Fill(table);
                }
            }
            //cmbBox.Items.Add("Select");

            ddlBox.DataSource = table;
            ddlBox.DataTextField = displayName;
            ddlBox.DataValueField = valueMember;

            ddlBox.SelectedIndex = -1;
            ddlBox.DataBind();

            ddlBox.Items.Insert(0, new ListItem("--Select--"));
        }
        catch (System.Exception ex)
        {
            throw ex;
        }
    }
    private void AddServiceRequest()
    {
        using (SqlConnection con = new SqlConnection(connValue))
        {
            using (SqlCommand cmd = new SqlCommand())
            {
                try
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Connection = con;

                    cmd.CommandText = "CreateRequest";

                   // cmd.Parameters.AddWithValue("@serviceReqID", 10);

                    cmd.Parameters.AddWithValue("@empName", txtempName.Text);

                    cmd.Parameters.AddWithValue("@departmentID", 22);

                    cmd.Parameters.AddWithValue("@sectionID", 9);

                    cmd.Parameters.AddWithValue("@jobTitle", txtTitle.Text);

                    cmd.Parameters.AddWithValue("@phoneNumber", txtPhone.Text);

                    cmd.Parameters.AddWithValue("@emailID", txtEmail.Text);

                    cmd.Parameters.AddWithValue("@serviceRequestDate", Convert.ToDateTime(txtDate.Text).ToString("dd/MMM/yyyy"));

                    cmd.Parameters.AddWithValue("@serviceRequestDescription", txtDesc.Text); 

                    cmd.Parameters.AddWithValue("@onBehalfOf", "");

                    //cmd.Parameters.AddWithValue("@attachedFiles", System.DBNull.Value);

                    //cmd.Parameters.AddWithValue("@fileName", ddlServiceTypes.SelectedValue);

                   // cmd.Parameters.AddWithValue("@filePath", ddlServiceTypes.SelectedValue);

                    cmd.Parameters.AddWithValue("@serviceTypeID", ddlServiceTypes.SelectedValue);

                    cmd.Parameters.AddWithValue("@serviceTypeSystemID", ddlSysTypes.SelectedValue);

                    cmd.Parameters.AddWithValue("@serviceReqNo", txtJobNo.Text);

                    cmd.Parameters.AddWithValue("@contactID", ViewState["updcontactID"]);

                    //cmd.Parameters.AddWithValue("@serviceReqID", txtJobNo.Text);
                    

                    con.Open();
                    cmd.ExecuteNonQuery();                  
                
                }
                catch (Exception ex)
                {
                    throw ex;
                }

                //  return _ownerID = (int)cmd.Parameters["@serviceReqID"].Value;
            }
        }
    }

    protected void ddlServiceTypes_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlServiceTypes.SelectedIndex != 0)
        {
            string sqlQueryDept = "SELECT serviceTypeSystemID, serviceTypeSystem FROM ServiceTypeSubCategory where serviceTypeID = " + ddlServiceTypes.SelectedValue + "";

            ddlSysTypes.DataSource = null;
            PopulateDropDownBox(ddlSysTypes, sqlQueryDept, "serviceTypeSystemID", "serviceTypeSystem");

        }
    }
    protected void btnUpload_Click1(object sender, EventArgs e)
    {

    }

    DataTable _dtuserDataColl = new DataTable();
    protected void txtEmail_TextChanged(object sender, EventArgs e)
    {
        _dtuserDataColl = checkUserExist(txtEmail.Text.Trim());
        if (_dtuserDataColl.Rows.Count > 0)
        {
            //if (_dtuserDataColl.Rows[0]["userName"].ToString() == "")
            {
                txtempName.Text = _dtuserDataColl.Rows[0]["firstName"].ToString() + "   " + _dtuserDataColl.Rows[0]["lastName"].ToString() + "";
              
               
                txtPhone.Text = _dtuserDataColl.Rows[0]["mobPhone"].ToString();
                txtTitle.Text = _dtuserDataColl.Rows[0]["jobPosition"].ToString();
                txtPhone.Text = _dtuserDataColl.Rows[0]["officePhone"].ToString();

               // ddlCmp.SelectedValue = _dtuserDataColl.Rows[0]["companyID"].ToString();
              

                ViewState["updcontactID"] = Convert.ToInt32(_dtuserDataColl.Rows[0]["contactID"]);
                ViewState["updsectionID"] = Convert.ToInt32(_dtuserDataColl.Rows[0]["sectionID"]);
                ViewState["updteamLeaderID"] = Convert.ToInt32(_dtuserDataColl.Rows[0]["teamLeaderID"]);

                ViewState["upduserProfileID"] = Convert.ToInt32(_dtuserDataColl.Rows[0]["userProfileID"]);


                txtDept.Text = _dtuserDataColl.Rows[0]["deptName"].ToString();
               txtSection.Text = _dtuserDataColl.Rows[0]["sectionName"].ToString();


                //lblContactID.Text = _dtuserDataColl.Rows[0]["contactID"].ToString();

               // Response.Write(" User Profile ID " + ViewState["upduserProfileID"].ToString());             

            }
            //else
            //{
            //    txtEmail.Focus();
            //    ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('This email address was already registered in the system. Please log in using your Username and Password.')</script>", false);
            //}

            // txtUserName.Text = _dtuserDataColl.Rows[0]["userName"].ToString();
        }
        else
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "PopUp", "<script>alert('Please double check entered Email address')</script>", false);
        }
    }
    public DataTable checkUserExist(string userEmail)
    {
        DataTable dt = new DataTable();
        SqlConnection sqlConn = new SqlConnection(connValue);
        try
        {
            sqlConn.Open();

            string strQuery = "SELECT  Contact.firstName, Contact.lastName, Contact.companyID, Contact.jobPosition, Contact.emailAddress, Contact.officePhone, Contact.mobPhone, Contact.officeAddress, " + 
                         " Contact.contactID, Contact.sectionID, Contact.teamLeaderID, Contact.userProfileID, Contact.userName, Contact.password, Contact.deptID, Section.sectionName,  " + 
                         " Department.deptName FROM  Contact INNER JOIN Section ON Contact.sectionID = Section.sectionID INNER JOIN Department ON Section.departmentID = Department.departmentID WHERE (Contact.emailAddress = '" + userEmail + "')";

            //SELECT firstName,lastName,companyID,jobPosition,emailAddress,officePhone,mobPhone,officeAddress, contactID, sectionID, teamLeaderID, userProfileID, userName, password  FROM Contact WHERE (emailAddress = '" + userEmail + "') 

            SqlCommand sqlCom = new SqlCommand(strQuery, sqlConn);

            SqlDataAdapter objDA = new SqlDataAdapter(sqlCom);
            objDA.SelectCommand.CommandText = sqlCom.CommandText.ToString();
            objDA.Fill(dt);

        }
        catch (System.Exception ex)
        {
            throw ex;
        }
        finally
        {
            sqlConn.Close();
        }
        return dt;
    }
}