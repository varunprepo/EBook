﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class OpenFilePath : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void LinkButton1_Click(object sender, EventArgs e)
    {

        string url = "files\\ebsd-sreedhar\\Doc_IN";
        string s = "window.open('" + url + "', 'popup_window', 'width=640,height=520,left=100,top=100,resizable=yes,scrollbars=yes');";
        ClientScript.RegisterStartupScript(this.GetType(), "script", s, true);

        return;

        //Session["Path"] = 
        //string url = "/eBook/OpenFilePath.aspx";
        //string s = "window.open('" + url + "', 'popup_window', 'width=640,height=520,left=100,top=100,resizable=yes,scrollbars=yes');";
        //ClientScript.RegisterStartupScript(this.GetType(), "script", s, true);

        string queryString = "~/eBook/OpenFilePath.aspx?path=" + System.Web.HttpUtility.UrlEncode(Session["Path"].ToString());


        string newWin =

            "window.open('" + queryString + "');";

        ClientScript.RegisterStartupScript

            (this.GetType(), "pop", newWin, true);
    }


}